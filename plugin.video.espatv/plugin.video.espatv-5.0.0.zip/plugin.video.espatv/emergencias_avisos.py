# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Emergencias: avisos meteorológicos de AEMET (dentro de El Tiempo) y teléfonos de emergencia (en Más).

Avisos: feeds RSS 2.0 oficiales de AEMET, uno general (España) y uno por provincia
(`CAP_AFAP{codigo}_RSS.xml`, que ya agrupa todas las zonas de aviso de esa provincia).
Los códigos salen de las páginas oficiales de AEMET https://www.aemet.es/es/rss_info/avisos/<ccaa>
(una por comunidad), consultadas el 2026-11-11.

Teléfonos: tabla fija. Cada entrada lleva anotada la fuente oficial con la que se contrastó.
No hay llamada: al pulsar se muestra el número y para qué sirve.
"""
import datetime
import json
import os
import re
import time
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs
import core_settings

try:
    import requests
except ImportError:
    requests = None

_LOG_TAG = "[EspaTV-AVISOS]"
_URL_BASE = "https://www.aemet.es/documentos_d/eltiempo/prediccion/avisos/rss/"
_URL_ESPANA = _URL_BASE + "CAP_AFAE_wah_RSS.xml"
_URL_PROVINCIA = _URL_BASE + "CAP_AFAP{codigo}_RSS.xml"
_TIMEOUT = 15
_CACHE_TTL = 15 * 60  # los avisos cambian a lo largo del día; 15 min es corto y barato

# (nombre, código de provincia de aviso de AEMET). Canarias y Baleares van por isla,
# como las publica AEMET. Fuente: páginas https://www.aemet.es/es/rss_info/avisos/<ccaa>.
_PROVINCIAS = [
    ("A Coruña", "7115"), ("Alacant/Alicante", "7703"), ("Albacete", "6802"),
    ("Almería", "6104"), ("Araba/Álava", "7501"), ("Asturias", "6333"),
    ("Ávila", "6705"), ("Badajoz", "7006"), ("Barcelona", "6908"),
    ("Bizkaia", "7548"), ("Burgos", "6709"), ("Cáceres", "7010"),
    ("Cádiz", "6111"), ("Cantabria", "6639"), ("Castelló/Castellón", "7712"),
    ("Ceuta", "7851"), ("Ciudad Real", "6813"), ("Córdoba", "6114"),
    ("Cuenca", "6816"), ("El Hierro", "6595"), ("Fuerteventura", "6592"),
    ("Gipuzkoa", "7520"), ("Girona", "6917"), ("Gran Canaria", "6590"),
    ("Granada", "6118"), ("Guadalajara", "6819"), ("Huelva", "6121"),
    ("Huesca", "6222"), ("Ibiza y Formentera", "6453"), ("Jaén", "6123"),
    ("La Gomera", "6594"), ("La Palma", "6593"), ("La Rioja", "7626"),
    ("Lanzarote", "6591"), ("León", "6724"), ("Lleida", "6925"),
    ("Lugo", "7127"), ("Madrid", "7228"), ("Málaga", "6129"),
    ("Mallorca", "6454"), ("Melilla", "7952"), ("Menorca", "6455"),
    ("Murcia", "7330"), ("Navarra", "7431"), ("Ourense", "7132"),
    ("Palencia", "6734"), ("Pontevedra", "7136"), ("Salamanca", "6737"),
    ("Segovia", "6740"), ("Sevilla", "6141"), ("Soria", "6742"),
    ("Tarragona", "6943"), ("Tenerife", "6596"), ("Teruel", "6244"),
    ("Toledo", "6845"), ("València/Valencia", "7746"), ("Valladolid", "6747"),
    ("Zamora", "6749"), ("Zaragoza", "6250"),
]

# Palabras clave del título ("Aviso. Nivel amarillo. Vientos. Zona") -> (rango, color, nombre).
# Orden de la tabla = de más a menos grave: gana la primera que aparezca.
_NIVELES = [
    ("rojo", 3, "red", "ROJO"),
    ("naranja", 2, "orange", "NARANJA"),
    ("amarillo", 1, "yellow", "AMARILLO"),
    ("verde", 0, "lightgreen", "VERDE"),
]
_NIVEL_DESCONOCIDO = (0, "grey", "?")

_MESES_ABREV = {"Jan": 1, "Feb": 2, "Mar": 3, "Apr": 4, "May": 5, "Jun": 6,
                "Jul": 7, "Aug": 8, "Sep": 9, "Oct": 10, "Nov": 11, "Dec": 12}
_RE_PERIODO = re.compile(
    r"de (\d{2}):(\d{2}) (\d{2})-(\d{2})-(\d{4}).*? a (\d{2}):(\d{2}) (\d{2})-(\d{2})-(\d{4})")

# Teléfonos. (id, número, nombre, descripción, fuente oficial contrastada el 2026-11-11).
_TELEFONOS = [
    ("112", "112", "Emergencias",
     "Teléfono único de emergencias. Gratuito, 24 horas, en toda España y la UE. "
     "El centro de coordinación avisa a ambulancia, bomberos, salvamento o policía "
     "según lo que haga falta.",
     # https://www.dgt.es/muevete-con-seguridad/viaja-seguro/consejos-extranjeros/en-caso-de-emergencia/
     "https://www.dgt.es/muevete-con-seguridad/viaja-seguro/consejos-extranjeros/en-caso-de-emergencia/"),
    ("061", "061", "Urgencias sanitarias",
     "Urgencias y emergencias sanitarias, con médico las 24 horas. Solo lo tienen algunas "
     "comunidades (Andalucía, Aragón, Baleares, Cantabria, Cataluña, Galicia, Murcia, Ceuta "
     "y Melilla); en el resto, las urgencias sanitarias se piden al 112.",
     # Ministerio de Sanidad, organización de la urgencia extrahospitalaria del SNS (edición 2022)
     "https://www.sanidad.gob.es/estadEstudios/estadisticas/docs/siap/Organizacion_Urgencia_extrahospitalaria_SNS_2022.pdf"),
    ("091", "091", "Policía Nacional",
     "Sala del 091 de la Policía Nacional: solicitudes urgentes y consultas de la "
     "ciudadanía en todo el territorio nacional.",
     # DGT (lista 112/062/091/092) y Policía Nacional
     "https://www.dgt.es/muevete-con-seguridad/viaja-seguro/consejos-extranjeros/en-caso-de-emergencia/"),
    ("092", "092", "Policía Local",
     "Policía Local de tu municipio. Si en tu localidad no hay Policía Local o no "
     "contesta, llama al 112.",
     # DGT (lista 112/062/091/092)
     "https://www.dgt.es/muevete-con-seguridad/viaja-seguro/consejos-extranjeros/en-caso-de-emergencia/"),
    ("062", "062", "Guardia Civil",
     "Guardia Civil, atención directa las 24 horas del día, los 365 días del año.",
     # Guardia Civil, formas de contacto
     "https://web.guardiacivil.es/es/colaboracion/atencionciudadano_1/"),
    ("016", "016", "Violencia de género",
     "Atención a todas las formas de violencia contra las mujeres: información, "
     "asesoramiento jurídico y atención psicosocial. Gratuito, confidencial y 24 horas. "
     "También por WhatsApp (600 000 016) y chat online. Si no puedes hablar, usa la app ALERTCOPS. "
     "Si estás en peligro inmediato, llama al 112.",
     # Ministerio de Igualdad
     "https://www.igualdad.gob.es/violenciagenero/Paginas/016.aspx"),
    ("024", "024", "Conducta suicida",
     "Línea de atención a la conducta suicida del Ministerio de Sanidad: ayuda para "
     "personas con pensamientos suicidas y para sus familiares y allegados. Gratuita, "
     "confidencial y 24 horas. En una emergencia vital inminente, llama al 112.",
     # Ministerio de Sanidad
     "https://www.sanidad.gob.es/linea024/home.htm"),
    ("toxicologia", "91 562 04 20", "Instituto Nacional de Toxicología",
     "Servicio de Información Toxicológica del Instituto Nacional de Toxicología y "
     "Ciencias Forenses: consejo ante intoxicaciones (medicamentos, productos químicos, "
     "setas, animales venenosos). Atiende al público 24 horas, los 365 días. "
     "Si la persona está grave, llama al 112.",
     # Ministerio de Justicia
     "https://www.mjusticia.gob.es/es/institucional/organismos/instituto-nacional/servicios/servicio-informacion/servicio-informacion1"),
]


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("{0} {1}".format(_LOG_TAG, msg), level)


# ---------------------------------------------------------------------------
# Avisos: parseo
# ---------------------------------------------------------------------------

def nivel_de_titulo(titulo, descripcion=""):
    """Devuelve (rango, color, nombre) deducido del título; si no aparece, de la descripción."""
    for texto in (titulo or "", descripcion or ""):
        bajo = texto.lower()
        for clave, rango, color, nombre in _NIVELES:
            if "nivel " + clave in bajo:
                return rango, color, nombre
    return _NIVEL_DESCONOCIDO


def _periodo(descripcion):
    """'de 21:00 11-11-2026 CET ... a 14:59 12-11-2026 CET' -> '11/11 21:00 - 12/11 14:59'."""
    m = _RE_PERIODO.search(descripcion or "")
    if not m:
        return ""
    h1, mi1, d1, mo1, _a1, h2, mi2, d2, mo2, _a2 = m.groups()
    return "{0}/{1} {2}:{3} - {4}/{5} {6}:{7}".format(d1, mo1, h1, mi1, d2, mo2, h2, mi2)


_DIAS_CORTOS = ("lun", "mar", "mié", "jue", "vie", "sáb", "dom")


def _dia_corto(dia, mes, anio):
    """'jue 12' (día de la semana calculado a mano, sin strptime). '' si la fecha no existe."""
    try:
        return "{0} {1}".format(_DIAS_CORTOS[datetime.date(int(anio), int(mes), int(dia)).weekday()],
                                int(dia))
    except (ValueError, OverflowError):
        return ""


def _periodo_corto(descripcion):
    """Vigencia para distinguir filas: 'jue 12 14:00-23:59' o, si cruza el día,
    'jue 12 14:00 - vie 13 06:00'. '' si el aviso no trae fechas."""
    m = _RE_PERIODO.search(descripcion or "")
    if not m:
        return ""
    h1, mi1, d1, mo1, a1, h2, mi2, d2, mo2, a2 = m.groups()
    ini, fin = _dia_corto(d1, mo1, a1), _dia_corto(d2, mo2, a2)
    if not ini or not fin:
        return ""
    if ini == fin:
        return "{0} {1}:{2}-{3}:{4}".format(ini, h1, mi1, h2, mi2)
    return "{0} {1}:{2} - {3} {4}:{5}".format(ini, h1, mi1, fin, h2, mi2)


def _etiqueta_aviso(a, repetido):
    """Etiqueta de una fila. Si el mismo aviso sale con varios periodos (repetido), añade el periodo."""
    etiqueta = "[COLOR {c}][B]{n}[/B][/COLOR]  {f} - {z}".format(
        c=a["color"], n=a["nivel"], f=a["fenomeno"], z=a["zona"])
    if repetido:
        periodo = _periodo_corto(a.get("descripcion"))
        if periodo:
            etiqueta += "  [COLOR grey]({0})[/COLOR]".format(periodo)
    return etiqueta


def _publicado(texto):
    """Fecha de publicación a mano (strptime no es fiable en Kodi). '' si no se entiende."""
    texto = (texto or "").strip()
    m = re.match(r"(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2})", texto)
    if m:
        a, mo, d, h, mi = m.groups()
        return "{0}/{1}/{2} {3}:{4} UTC".format(d, mo, a, h, mi)
    m = re.search(r"(\d{1,2}) ([A-Za-z]{3}) (\d{4}) (\d{2}):(\d{2})", texto)
    if m and m.group(2) in _MESES_ABREV:
        d, mes, a, h, mi = m.groups()
        return "{0:0>2}/{1:02d}/{2} {3}:{4} UTC".format(d, _MESES_ABREV[mes], a, h, mi)
    return ""


def parse_feed(contenido):
    """Convierte el RSS de AEMET en una lista de avisos, ordenada de más a menos grave.

    Ignora el item 'Estado completo de avisos' (un tar.gz) y cualquier cosa que no sea
    un aviso. Con XML roto o vacío devuelve [].
    """
    if not contenido:
        return []
    try:
        raiz = ET.fromstring(contenido)
    except ET.ParseError as exc:
        _log("XML de avisos no válido: {0}".format(exc), xbmc.LOGWARNING)
        return []
    avisos = []
    for it in raiz.iter("item"):
        titulo = (it.findtext("title") or "").strip()
        desc = (it.findtext("description") or "").strip()
        enlace = (it.findtext("link") or "").strip()
        if not titulo.startswith("Aviso.") or enlace.endswith(".tar.gz"):
            continue
        partes = titulo.split(". ", 3)
        fenomeno = partes[2].strip() if len(partes) > 2 else ""
        zona = partes[3].strip() if len(partes) > 3 else ""
        rango, color, nivel = nivel_de_titulo(titulo, desc)
        avisos.append({
            "titulo": titulo, "nivel": nivel, "rango": rango, "color": color,
            "fenomeno": fenomeno, "zona": zona, "descripcion": desc,
            "periodo": _periodo(desc), "publicado": _publicado(it.findtext("pubDate")),
            "enlace": enlace,
        })
    avisos.sort(key=lambda a: (-a["rango"], a["zona"].lower(), a["fenomeno"].lower()))
    return avisos


# ---------------------------------------------------------------------------
# Avisos: descarga y caché
# ---------------------------------------------------------------------------

def _perfil():
    try:
        return xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
    except Exception:  # noqa: BLE001 - sin perfil no hay caché, pero sigue funcionando
        return None


def _ruta_cache(clave):
    perfil = _perfil()
    if not perfil or not isinstance(perfil, str):
        return None
    return os.path.join(perfil, "avisos_aemet_{0}.json".format(clave))


def _leer_cache(clave, ignorar_caducidad=False):
    ruta = _ruta_cache(clave)
    if not ruta or not os.path.isfile(ruta):
        return None
    try:
        with open(ruta, "r", encoding="utf-8") as fh:
            datos = json.load(fh)
        if not isinstance(datos, dict) or not isinstance(datos.get("avisos"), list):
            return None
        if not ignorar_caducidad and time.time() - float(datos.get("ts", 0)) > _CACHE_TTL:
            return None
        return datos["avisos"]
    except (OSError, ValueError, TypeError):
        return None


def _guardar_cache(clave, avisos):
    ruta = _ruta_cache(clave)
    if not ruta:
        return
    try:
        os.makedirs(os.path.dirname(ruta), exist_ok=True)
        core_settings.atomic_write_json(ruta, {"ts": time.time(), "avisos": avisos})
    except OSError as exc:
        _log("No se pudo guardar la caché de avisos: {0}".format(exc), xbmc.LOGWARNING)


def cargar_avisos(codigo):
    """Avisos de una provincia (`codigo`) o de toda España (`codigo` vacío).

    Devuelve (lista, estado): estado 'ok', 'cache' (red caída, datos antiguos) o
    'error' (sin datos; la lista va vacía). Nunca lanza.
    """
    clave = codigo or "esp"
    fresca = _leer_cache(clave)
    if fresca is not None:
        return fresca, "ok"
    url = _URL_PROVINCIA.format(codigo=codigo) if codigo else _URL_ESPANA
    contenido = None
    if requests is not None:
        try:
            resp = requests.get(url, timeout=_TIMEOUT, headers={"User-Agent": "Kodi/EspaTV"})
            if resp.status_code == 200:
                contenido = resp.content
            else:
                _log("HTTP {0} en {1}".format(resp.status_code, url), xbmc.LOGWARNING)
        except Exception as exc:  # noqa: BLE001 - cualquier fallo de red es 'sin datos'
            _log("Error de red en avisos: {0}".format(exc), xbmc.LOGWARNING)
    if contenido:
        try:
            ET.fromstring(contenido)
        except ET.ParseError:
            contenido = None
    if contenido:
        avisos = parse_feed(contenido)
        _guardar_cache(clave, avisos)
        return avisos, "ok"
    vieja = _leer_cache(clave, ignorar_caducidad=True)
    if vieja is not None:
        return vieja, "cache"
    return [], "error"


# ---------------------------------------------------------------------------
# Avisos: menús
# ---------------------------------------------------------------------------

_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")


def _icono(nombre, respaldo="DefaultIconInfo.png"):
    """Ruta del PNG propio de resources/media; si falta, el icono genérico de Kodi."""
    ruta = os.path.join(_MEDIA, nombre)
    return ruta if os.path.isfile(ruta) else respaldo


def _fin(handle):
    xbmcplugin.endOfDirectory(handle)


def show_avisos_menu(handle, build_url):
    """Menú 'Avisos meteorológicos': Toda España y una entrada por provincia."""
    try:
        li = xbmcgui.ListItem(label="[B][COLOR orange]Toda España[/COLOR][/B]")
        li.setArt({"icon": _icono("avisos_espana.png", "DefaultAddonWeather.png")})
        li.setInfo("video", {"plot": "Todos los avisos vigentes de AEMET en España, "
                                     "de más a menos graves."})
        xbmcplugin.addDirectoryItem(
            handle=handle, url=build_url(action="avisos_aemet", code="", name="Toda España"),
            listitem=li, isFolder=True)
        for nombre, codigo in _PROVINCIAS:
            li = xbmcgui.ListItem(label=nombre)
            li.setArt({"icon": _icono("avisos_provincia.png", "DefaultAddonWeather.png")})
            li.setInfo("video", {"plot": "Avisos vigentes en todas las zonas de {0}.".format(nombre)})
            xbmcplugin.addDirectoryItem(
                handle=handle, url=build_url(action="avisos_aemet", code=codigo, name=nombre),
                listitem=li, isFolder=True)
    except Exception as exc:  # noqa: BLE001 - un menú nunca debe romper el addon
        _log("Error pintando el menú de avisos: {0}".format(exc), xbmc.LOGERROR)
    _fin(handle)


def _texto_aviso(a):
    lineas = [a["titulo"], "", a["descripcion"]]
    if a.get("periodo"):
        lineas += ["", "Vigencia (hora peninsular): " + a["periodo"]]
    if a.get("publicado"):
        lineas.append("Publicado: " + a["publicado"])
    lineas += ["", "Fuente: AEMET (Plan Meteoalerta)."]
    return "\n".join(lineas)


def show_avisos(handle, build_url, codigo, nombre):
    """Lista los avisos de una provincia o de España. Sin red, avisa y cierra bien."""
    try:
        avisos, estado = cargar_avisos(codigo or "")
    except Exception as exc:  # noqa: BLE001
        _log("Error cargando avisos: {0}".format(exc), xbmc.LOGERROR)
        avisos, estado = [], "error"
    if estado == "error":
        xbmcgui.Dialog().notification(
            "EspaTV", "No se pudieron obtener los avisos de AEMET. Inténtalo más tarde.",
            xbmcgui.NOTIFICATION_ERROR, 5000)
        _fin(handle)
        return
    if estado == "cache":
        xbmcgui.Dialog().notification(
            "EspaTV", "Sin conexión: se muestran los últimos avisos guardados.",
            xbmcgui.NOTIFICATION_WARNING, 4000)
    try:
        if not avisos:
            li = xbmcgui.ListItem(label="[COLOR lightgreen]Sin avisos vigentes en {0}[/COLOR]"
                                  .format(nombre or "España"))
            li.setArt({"icon": _icono("avisos_sin.png")})
            li.setInfo("video", {"plot": "AEMET no tiene ningún aviso activo ahora mismo."})
            xbmcplugin.addDirectoryItem(
                handle=handle,
                url=build_url(action="avisos_detalle", titulo="Sin avisos",
                              texto="AEMET no tiene ningún aviso activo ahora mismo en {0}."
                              .format(nombre or "España")),
                listitem=li, isFolder=False)
        cuenta = {}
        for a in avisos:
            clave = (a["nivel"], a["fenomeno"], a["zona"])
            cuenta[clave] = cuenta.get(clave, 0) + 1
        for a in avisos:
            etiqueta = _etiqueta_aviso(a, cuenta[(a["nivel"], a["fenomeno"], a["zona"])] > 1)
            li = xbmcgui.ListItem(label=etiqueta)
            li.setArt({"icon": _icono("avisos_aviso.png", "DefaultAddonWeather.png")})
            li.setInfo("video", {"plot": _texto_aviso(a)})
            xbmcplugin.addDirectoryItem(
                handle=handle,
                url=build_url(action="avisos_detalle", titulo=a["titulo"], texto=_texto_aviso(a)),
                listitem=li, isFolder=False)
    except Exception as exc:  # noqa: BLE001
        _log("Error pintando avisos: {0}".format(exc), xbmc.LOGERROR)
    _fin(handle)


def show_aviso_detalle(titulo, texto):
    xbmcgui.Dialog().textviewer(titulo or "Aviso", texto or "")


# ---------------------------------------------------------------------------
# Teléfonos de emergencia
# ---------------------------------------------------------------------------

def show_telefonos_menu(handle, build_url):
    try:
        for tid, numero, nombre, desc, _fuente in _TELEFONOS:
            li = xbmcgui.ListItem(label="[B][COLOR tomato]{0}[/COLOR][/B]  {1}".format(numero, nombre))
            li.setArt({"icon": _icono("tel_{0}.png".format(tid))})
            li.setInfo("video", {"plot": desc})
            xbmcplugin.addDirectoryItem(
                handle=handle, url=build_url(action="telefono_info", id=tid),
                listitem=li, isFolder=False)
    except Exception as exc:  # noqa: BLE001
        _log("Error pintando teléfonos: {0}".format(exc), xbmc.LOGERROR)
    _fin(handle)


def show_telefono(tid):
    """Diálogo con el número bien visible y para qué sirve. No llama a nadie."""
    for t_id, numero, nombre, desc, _fuente in _TELEFONOS:
        if t_id == tid:
            xbmcgui.Dialog().ok(
                nombre,
                "[B][COLOR tomato]{0}[/COLOR][/B]\n\n{1}".format(numero, desc))
            return
    xbmcgui.Dialog().notification("EspaTV", "Teléfono no encontrado",
                                  xbmcgui.NOTIFICATION_WARNING, 3000)
