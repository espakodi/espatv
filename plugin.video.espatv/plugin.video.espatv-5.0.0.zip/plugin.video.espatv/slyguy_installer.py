# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Instalación de addons del repositorio SlyGuy."""
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from install_helpers import _auto_install_slyguy_repo

_SLYGUY_REPO_ID = "repository.slyguy"

_EXTERNAL_ADDONS = (
    ("Pluto TV", "slyguy.pluto.tv.provider", "tv_pluto.png",
     "TV gratuita con canales temáticos (cine, series, noticias...).\nRequiere addon SlyGuy (se instala automáticamente)."),
    ("Samsung TV Plus", "slyguy.samsung.tv.plus", "tv_samsung.png",
     "Canales de TV gratuitos de Samsung.\nRequiere addon SlyGuy (se instala automáticamente)."),
    ("Roku Channel", "slyguy.roku", "tv_roku.png",
     "Canales de TV gratuitos de Roku.\nPelículas, series y TV en vivo sin suscripción.\nRequiere addon SlyGuy (se instala automáticamente)."),
    ("Plex Live TV", "slyguy.plex.live", "tv_plex.png",
     "Decenas de canales lineales gratuitos de cine, noticias y entretenimiento.\nRequiere el módulo de SlyGuy (se instala automáticamente)."),
)


def _icono(nombre):
    try:
        ruta = os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("path")), "resources", "media", nombre)
        if os.path.isfile(ruta):
            return ruta
    except Exception:
        pass
    return "DefaultAddonPVRClient.png"


def external_addons_menu():
    """Submenú con los addons externos de vídeo gestionados mediante SlyGuy."""
    h = int(sys.argv[1])
    base = sys.argv[0]
    xbmcplugin.setPluginCategory(h, "Addons externos")
    for titulo, addon_id, img, plot in _EXTERNAL_ADDONS:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(titulo))
        ico = _icono(img)
        li.setArt({"icon": ico, "thumb": ico})
        li.setInfo("video", {"title": titulo, "plot": plot})
        url = base + "?" + urllib.parse.urlencode({
            "action": "slyguy_install",
            "addon_id": addon_id,
            "title": titulo,
        })
        xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def install(addon_id, addon_name):
    try:
        xbmcaddon.Addon(addon_id)
        xbmcgui.Dialog().notification("EspaTV", "Abriendo {0}...".format(addon_name), xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("RunAddon({0})".format(addon_id))
        return
    except RuntimeError:
        pass
    try:
        xbmcaddon.Addon(_SLYGUY_REPO_ID)
        if xbmcgui.Dialog().yesno("EspaTV", "{0} no está instalado pero el repositorio SlyGuy sí.\n\n¿Instalar {0} ahora?".format(addon_name)):
            xbmc.executebuiltin("InstallAddon({0})".format(addon_id))
            xbmcgui.Dialog().ok("EspaTV", "Se ha solicitado la instalación de {0}.\n\nSi Kodi te pide confirmación, acepta.\nDespués vuelve y pulsa de nuevo para abrirlo.".format(addon_name))
        return
    except RuntimeError:
        pass
    opts = ["Instalar repositorio automáticamente", "Ver instrucciones manuales"]
    sel = xbmcgui.Dialog().select("Se necesita el repo SlyGuy para {0}".format(addon_name), opts)
    if sel == 0:
        _auto_install_slyguy_repo(addon_id, addon_name)
    elif sel == 1:
        show_instructions(addon_name)


def show_instructions(addon_name):
    t = (
        "[B]Cómo instalar {0}[/B]\n\n"
        "1. Ve a [B]Ajustes → Sistema → Addons[/B]\n"
        "   Activa [B]Orígenes desconocidos[/B]\n\n"
        "2. Ve a [B]Ajustes → Administrador de archivos[/B]\n"
        "   Añade fuente: [B]https://k.slyguy.xyz[/B]\n"
        "   Nombre: [B]slyguy[/B]\n\n"
        "3. Ve a [B]Addons → Instalar desde ZIP[/B]\n"
        "   Selecciona [B]slyguy → repository.slyguy.zip[/B]\n\n"
        "4. Ve a [B]Addons → Instalar desde repositorio[/B]\n"
        "   SlyGuy → Video addons → [B]{0}[/B]\n\n"
        "Tras instalarlo, vuelve a TV en Directo y pulsa de nuevo."
    ).format(addon_name)
    xbmcgui.Dialog().textviewer("Instalar {0}".format(addon_name), t)
