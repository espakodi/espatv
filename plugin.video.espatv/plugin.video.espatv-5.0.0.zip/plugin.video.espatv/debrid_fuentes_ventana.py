# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Ventana propia para elegir fuente Debrid en espatv_fuentes.xml."""
import json
import os
import re

import xbmcgui

import debrid_sources
import torrentio

_XML = "espatv_fuentes.xml"
_RUTA = os.path.dirname(os.path.abspath(__file__))
_PROP_FILTROS = "espatv.debrid.filtros"
_CONTEO_CABECERA_RE = re.compile(r"\s*·\s*\d+\s+de\s+\d+\s*$")

ID_MEJOR = 10
ID_FILTROS = 11
ID_LISTA = 50
ID_SCROLL = 51

ID_F_ORDEN = 201
ID_F_CALIDAD = 202
ID_F_IDIOMA = 203
ID_F_CACHE = 204
ID_F_PACKS = 205
ID_F_SEMILLAS = 206
ID_F_RESET = 207
ID_F_CERRAR = 208

ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_PREVIOUS_MENU = 10
ACTION_STOP = 13
ACTION_NAV_BACK = 92
_CERRAR = (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK, ACTION_STOP)

ORDENES = (
    ("recomendado", "Recomendado"),
    ("castellano", "Castellano primero"),
    ("tamano_desc", "Mayor tamaño"),
    ("tamano_asc", "Menor tamaño"),
    ("calidad", "Mejor calidad"),
    ("semillas", "Más semillas"),
)
CALIDADES = (
    ("", "Todas"),
    ("2160p", "2160p (4K)"),
    ("1080p", "1080p"),
    ("720p", "720p"),
    ("SD", "SD / 480p"),
)
IDIOMAS = (
    ("", "Todos"),
    ("castellano", "Solo castellano"),
    ("espanol", "Español y multi"),
)
SEMILLAS_MIN = (
    (0, "Todas"),
    (1, "Con semillas (>0)"),
    (5, "5 o más"),
    (20, "20 o más"),
)

_FILTROS_DEFECTO = {
    "orden": "recomendado",
    "calidad": "",
    "idioma": "",
    "solo_cache": False,
    "ocultar_packs": False,
    "min_semillas": 0,
}

_CALIDAD_COLOR = {
    "2160p": "FFFBBF24",
    "1440p": "FFFBBF24",
    "1080p": "FF38BDF8",
    "720p": "FF2DD4BF",
    "480p": "FF94A3B8",
    "SD": "FF94A3B8",
}

_CACHE_ESTADO_ORDEN = {True: 0, None: 1, False: 2}


def filtros_defecto():
    return dict(_FILTROS_DEFECTO)


def normalizar_filtros(datos):
    base = dict(_FILTROS_DEFECTO)
    if not isinstance(datos, dict):
        return base
    orden = datos.get("orden")
    if orden in dict(ORDENES):
        base["orden"] = orden
    calidad = datos.get("calidad")
    if calidad in dict(CALIDADES):
        base["calidad"] = calidad
    idioma = datos.get("idioma")
    if idioma in dict(IDIOMAS):
        base["idioma"] = idioma
    base["solo_cache"] = bool(datos.get("solo_cache"))
    base["ocultar_packs"] = bool(datos.get("ocultar_packs"))
    min_sem = datos.get("min_semillas")
    if min_sem in dict(SEMILLAS_MIN):
        base["min_semillas"] = min_sem
    return base


def cargar_filtros():
    try:
        raw = xbmcgui.Window(10000).getProperty(_PROP_FILTROS)
        if isinstance(raw, str) and raw:
            return normalizar_filtros(json.loads(raw))
    except (RuntimeError, ValueError, TypeError):
        pass
    return filtros_defecto()


def guardar_filtros(filtros):
    norm = normalizar_filtros(filtros)
    try:
        xbmcgui.Window(10000).setProperty(_PROP_FILTROS, json.dumps(norm))
    except (RuntimeError, TypeError):
        pass
    return norm


def _coincide_calidad(stream, calidad):
    if not calidad:
        return True
    if calidad == "SD":
        return stream.quality in ("SD", "480p")
    return stream.quality == calidad


def _coincide_idioma(stream, idioma):
    if not idioma:
        return True
    if idioma == "castellano":
        return stream.lang_rank == 0
    if idioma == "espanol":
        return stream.lang_rank in (0, 1, 2)
    return True


def _clave_orden(par, orden):
    idx, s = par
    cache_r = _CACHE_ESTADO_ORDEN.get(s.cached, 1)
    q_r = torrentio.QUALITY_RANK.get(s.quality, 0)
    low = 1 if s.is_low_quality else 0
    if orden == "castellano":
        return (s.lang_rank, low, cache_r, -q_r, -s.seeders, idx)
    if orden == "tamano_desc":
        return (-s.size_bytes, idx)
    if orden == "tamano_asc":
        return (0 if s.size_bytes else 1, s.size_bytes, idx)
    if orden == "calidad":
        return (low, -q_r, cache_r, -s.seeders, -s.size_bytes, idx)
    if orden == "semillas":
        return (-s.seeders, cache_r, -q_r, idx)
    return (idx,)


def filtrar_y_ordenar(streams, filtros=None):
    """Devuelve [(indice_original, stream), ...] aplicando filtros y orden sobre toda la lista."""
    f = normalizar_filtros(filtros)
    pares = []
    for idx, s in enumerate(streams):
        if f["solo_cache"] and s.cached is not True:
            continue
        if f["ocultar_packs"] and s.is_pack:
            continue
        if f["min_semillas"] and s.seeders < f["min_semillas"]:
            continue
        if not _coincide_calidad(s, f["calidad"]):
            continue
        if not _coincide_idioma(s, f["idioma"]):
            continue
        pares.append((idx, s))
    if f["orden"] != "recomendado":
        pares.sort(key=lambda par: _clave_orden(par, f["orden"]))
    return pares


def filtros_activos(filtros):
    f = normalizar_filtros(filtros)
    activos = []
    if f["orden"] != "recomendado":
        activos.append(dict(ORDENES)[f["orden"]])
    if f["calidad"]:
        activos.append(dict(CALIDADES)[f["calidad"]])
    if f["idioma"]:
        activos.append(dict(IDIOMAS)[f["idioma"]])
    if f["solo_cache"]:
        activos.append("Solo en caché")
    if f["ocultar_packs"]:
        activos.append("Sin packs")
    if f["min_semillas"]:
        activos.append(f"{f['min_semillas']}+ semillas")
    return activos


def resumen_filtros(filtros):
    activos = filtros_activos(filtros)
    return " · ".join(activos) if activos else "Sin filtros"


def _limpiar_base_header(header):
    return _CONTEO_CABECERA_RE.sub("", str(header or "")).strip()


def textos_cabecera(header, shown, filtered_total, total, filtros=None):
    """Genera (cabecera, subcabecera) explicando el recorte y mostrando filtros activos."""
    base = _limpiar_base_header(header)
    activos = filtros_activos(filtros)
    hay_recorte_filtro = bool(activos) and filtered_total < total
    if not hay_recorte_filtro:
        if shown < total:
            conteo = f"Mostrando {shown} primeras de {total}"
        else:
            conteo = f"{shown} de {total}"
    else:
        if shown < filtered_total:
            conteo = f"Mostrando {shown} de {filtered_total} filtradas ({total} en total)"
        else:
            conteo = f"{filtered_total} de {total} filtradas"

    partes_cab = [p for p in (base, conteo) if p]
    if activos:
        partes_cab.append(" · ".join(activos))
    cabecera = " · ".join(partes_cab)

    if activos:
        filtro_txt = " · ".join(activos)
        subcabecera = (
            f"[COLOR FF38BDF8][B]Filtros activos:[/B][/COLOR] [COLOR FFFFFFFF]{filtro_txt}[/COLOR]"
            f"   ·   {conteo}"
        )
    elif shown < total:
        subcabecera = (
            f"Mostrando las {shown} primeras de {total} encontradas · "
            "Usa [COLOR FF38BDF8][B]Filtros[/B][/COLOR] para ordenar o filtrar todas"
        )
    else:
        subcabecera = "Elige una fuente o reproduce la mejor"
    return cabecera, subcabecera


def _envolver_texto(texto, ancho=42):
    """Parte nombres largos de release o fichero en líneas legibles sin cortar extensiones."""
    resto = " ".join(str(texto or "").split())
    if len(resto) <= ancho:
        return resto
    lineas = []
    while len(resto) > ancho:
        trozo = resto[:ancho + 1]
        corte = trozo.rfind(" ")
        if corte < 6:
            corte = -1
            # Sin espacios (p. ej. bloques entre paréntesis o puntos), parte en separadores naturales
            # evitando dejar la extensión (.mkv, .avi) sola en la línea siguiente.
            for idx in range(len(trozo) - 1, 5, -1):
                ch = trozo[idx]
                if ch == "(":
                    corte = idx
                    break
                if ch in (")", "-", "_"):
                    corte = idx + 1
                    break
                if ch == "." and len(resto) - idx > 5:
                    corte = idx + 1
                    break
            if corte <= 0:
                corte = ancho
        lineas.append(resto[:corte].strip())
        resto = resto[corte:].strip()
    if resto:
        lineas.append(resto)
    return "\n".join(lineas)


def _envolver_tarjeta(texto, ancho=76):
    lineas = _envolver_texto(texto, ancho=ancho).split("\n")
    if len(lineas) <= 2:
        return "\n".join(lineas)
    segunda = lineas[1]
    if len(segunda) >= ancho:
        segunda = segunda[:ancho - 1].rstrip()
    return f"{lineas[0]}\n{segunda}…"


def _estado_cache(cached):
    if cached is True:
        return "EN CACHÉ", "FF86EFAC", "En caché · al momento"
    if cached is False:
        return "SIN CACHÉ", "FFFCA5A5", "No está en caché"
    return "", "", "Sin comprobar · se probará al reproducir"


def _propiedades(stream):
    """Propiedades de ListItem para una fuente; todas existen siempre como texto."""
    estado, estado_color, estado_texto = _estado_cache(stream.cached)
    idioma = debrid_sources._lang_badge(stream)
    calidad_base = str(stream.quality or "SD")
    calidad_extra = " · ".join(p for p in (stream.codec, stream.hdr) if p)
    release = debrid_sources._clean(str(stream.release or ""))
    fichero = debrid_sources._clean(str(stream.file_hint or ""))
    fichero_panel = _envolver_texto(fichero) if fichero else "No indicado"
    detalle_texto = (
        f"[COLOR FF94A3B8][B]Release[/B][/COLOR]\n{_envolver_texto(release)}\n\n"
        f"[COLOR FF94A3B8][B]Fichero de vídeo[/B][/COLOR]\n{fichero_panel}"
    )
    return {
        "estado": estado,
        "estado_color": estado_color,
        "estado_texto": estado_texto,
        "calidad": debrid_sources._quality_text(stream),
        "calidad_base": calidad_base,
        "calidad_extra": calidad_extra,
        "calidad_color": _CALIDAD_COLOR.get(calidad_base, "FF94A3B8"),
        "tamano": debrid_sources._fmt_size(stream.size_bytes),
        "semillas": (f"{stream.seeders} semilla{'s' if stream.seeders != 1 else ''}"
                     if stream.seeders else ""),
        "semillas_corto": f"{stream.seeders} sem." if stream.seeders else "",
        "idioma": idioma,
        "idioma_color": "FFFFD700" if idioma else "",
        "proveedor": str(stream.provider or ""),
        "pack": "1" if stream.is_pack else "",
        "tipo": "Pack de temporada" if stream.is_pack else "Archivo individual",
        "release": release,
        "release_tarjeta": _envolver_tarjeta(release),
        "fichero": fichero,
        "detalle_texto": detalle_texto,
    }


def _ciclar(opciones, actual, paso=1):
    claves = [k for k, _ in opciones]
    try:
        pos = claves.index(actual)
    except ValueError:
        pos = 0
    return claves[(pos + paso) % len(claves)]


class VentanaFuentes(xbmcgui.WindowXMLDialog):
    """Selector de fuentes Debrid con tarjetas limpias, filtros sobre todas las fuentes y panel de detalle."""

    def __init__(self, *args, header="", streams=(), total=0, params=None,
                 filtros=None, max_shown=None, **kw):
        super().__init__(*args)
        self._header = header
        self._streams = list(streams)
        self._total = total if total else len(self._streams)
        self._params = params or {}
        self._max_shown = max_shown or debrid_sources._SHOWN_MAX
        self._filtros = normalizar_filtros(filtros) if filtros is not None else cargar_filtros()
        self._mostradas = []
        self._filtros_abiertos = False
        self._resultado = -1
        self._error = None

    def onInit(self):
        try:
            self._aplicar_y_pintar(foco_inicial=True)
        except Exception as e:
            self._error = e
            self.close()

    def _aplicar_y_pintar(self, foco_inicial=False):
        filtradas = filtrar_y_ordenar(self._streams, self._filtros)
        self._mostradas = filtradas[:self._max_shown]

        _, subcabecera = textos_cabecera(
            self._header, len(self._mostradas), len(filtradas), self._total, self._filtros
        )
        activos = filtros_activos(self._filtros)
        # La ventana tiene dos líneas: título limpio arriba; recuento y filtros solo en la de abajo.
        # La cabecera completa de textos_cabecera queda para el selector de respaldo, que solo tiene una.
        self.setProperty("cabecera", _limpiar_base_header(self._header))
        self.setProperty("subcabecera", subcabecera)
        self.setProperty("filtros_activos", "1" if activos else "")
        if activos:
            self.setProperty("boton_filtros", f"Filtros ({len(activos)})")
        else:
            self.setProperty("boton_filtros", "Filtros")

        items = []
        for _, stream in self._mostradas:
            props = _propiedades(stream)
            item = xbmcgui.ListItem(label=props["release"])
            item.setProperties(props)
            items.append(item)

        lista = self.getControl(ID_LISTA)
        lista.reset()
        lista.addItems(items)
        if items:
            lista.selectItem(0)

        self._actualizar_panel_filtros(len(filtradas))
        if foco_inicial:
            self.setFocusId(ID_MEJOR)

    def _actualizar_panel_filtros(self, n_coinciden=None):
        if n_coinciden is None:
            n_coinciden = len(filtrar_y_ordenar(self._streams, self._filtros))
        self.setProperty("filtros_coinciden", str(n_coinciden))
        if n_coinciden > self._max_shown:
            self.setProperty(
                "filtros_resumen",
                f"{n_coinciden} de {self._total} fuentes coinciden (se muestran las {self._max_shown} primeras)",
            )
        else:
            self.setProperty("filtros_resumen", f"{n_coinciden} de {self._total} fuentes coinciden")

        self.setProperty("f_orden", f"‹  {dict(ORDENES)[self._filtros['orden']]}  ›")

        cal_actual = self._filtros["calidad"]
        if cal_actual:
            n_cal = sum(1 for s in self._streams if _coincide_calidad(s, cal_actual))
            self.setProperty("f_calidad", f"‹  {dict(CALIDADES)[cal_actual]} ({n_cal})  ›")
        else:
            self.setProperty("f_calidad", "‹  Todas  ›")

        idi_actual = self._filtros["idioma"]
        if idi_actual:
            n_idi = sum(1 for s in self._streams if _coincide_idioma(s, idi_actual))
            self.setProperty("f_idioma", f"‹  {dict(IDIOMAS)[idi_actual]} ({n_idi})  ›")
        else:
            self.setProperty("f_idioma", "‹  Todos  ›")

        self.setProperty("f_cache", "Sí (listas al momento)" if self._filtros["solo_cache"] else "No")
        self.setProperty("f_packs", "Sí (ocultar packs)" if self._filtros["ocultar_packs"] else "No")
        self.setProperty("f_semillas", f"‹  {dict(SEMILLAS_MIN)[self._filtros['min_semillas']]}  ›")

    def _abrir_filtros(self):
        self._filtros_abiertos = True
        self.setProperty("filtros_abiertos", "1")
        self._actualizar_panel_filtros()
        self.setFocusId(ID_F_ORDEN)

    def _cerrar_filtros(self):
        self._filtros_abiertos = False
        self.setProperty("filtros_abiertos", "")
        self.setFocusId(ID_LISTA if self._mostradas else ID_FILTROS)

    def _cambiar_filtro(self, control_id, paso=1):
        if control_id == ID_F_ORDEN:
            self._filtros["orden"] = _ciclar(ORDENES, self._filtros["orden"], paso)
        elif control_id == ID_F_CALIDAD:
            self._filtros["calidad"] = _ciclar(CALIDADES, self._filtros["calidad"], paso)
        elif control_id == ID_F_IDIOMA:
            self._filtros["idioma"] = _ciclar(IDIOMAS, self._filtros["idioma"], paso)
        elif control_id == ID_F_CACHE:
            self._filtros["solo_cache"] = not self._filtros["solo_cache"]
        elif control_id == ID_F_PACKS:
            self._filtros["ocultar_packs"] = not self._filtros["ocultar_packs"]
        elif control_id == ID_F_SEMILLAS:
            self._filtros["min_semillas"] = _ciclar(SEMILLAS_MIN, self._filtros["min_semillas"], paso)
        else:
            return False
        self._filtros = guardar_filtros(self._filtros)
        self._aplicar_y_pintar(foco_inicial=False)
        return True

    def onClick(self, controlId):
        if controlId == ID_MEJOR:
            self._resultado = 0
            self.close()
        elif controlId == ID_FILTROS:
            self._abrir_filtros()
        elif controlId == ID_LISTA:
            pos = self.getControl(ID_LISTA).getSelectedPosition()
            if 0 <= pos < len(self._mostradas):
                self._resultado = self._mostradas[pos][0] + 1
                self.close()
        elif controlId == ID_F_RESET:
            self._filtros = guardar_filtros(filtros_defecto())
            self._aplicar_y_pintar(foco_inicial=False)
        elif controlId == ID_F_CERRAR:
            self._cerrar_filtros()
        elif self._filtros_abiertos:
            self._cambiar_filtro(controlId, paso=1)

    def onAction(self, action):
        aid = action.getId()
        if self._filtros_abiertos:
            if aid in _CERRAR:
                self._cerrar_filtros()
                return
            if aid in (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT):
                paso = -1 if aid == ACTION_MOVE_LEFT else 1
                self._cambiar_filtro(self.getFocusId(), paso=paso)
                return
        if aid in _CERRAR:
            self._resultado = -1
            self.close()


def elegir(header, streams, total, params, max_shown=None):
    """Devuelve -1 si se cancela, 0 para la mejor o i + 1 para streams[i]."""
    ventana = VentanaFuentes(
        _XML, _RUTA, "Default", "1080i",
        header=header, streams=streams, total=total, params=params, max_shown=max_shown,
    )
    try:
        ventana.doModal()
        if ventana._error is not None:
            raise ventana._error
        return ventana._resultado
    finally:
        del ventana
