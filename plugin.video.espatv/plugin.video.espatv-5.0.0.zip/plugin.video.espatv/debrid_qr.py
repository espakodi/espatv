# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
"""QR y ventana de vinculación de una cuenta Debrid.

Todo es opcional: si el QR no se puede generar, quien llama sigue con el diálogo de texto.
"""
import os
import sys

import xbmcgui

_AQUI = os.path.dirname(os.path.abspath(__file__))
_LIB_SEGNO = os.path.join(_AQUI, "resources", "espamando", "espamando_lib")
_FONDO = os.path.join(_AQUI, "resources", "media", "white.png")


def _cargar_segno():
    """Importa segno; solo añade la carpeta del addon al path si no se encuentra sin ella."""
    try:
        import segno
    except ImportError:
        if _LIB_SEGNO not in sys.path:
            sys.path.append(_LIB_SEGNO)
        import segno
    return segno


def make_png(text, path):
    """Guarda el QR de `text` como PNG negro sobre blanco en `path`. True si quedó escrito."""
    try:
        if not isinstance(text, str) or not text.strip() or not path:
            return False
        segno = _cargar_segno()
        segno.make(text).save(path, kind="png", scale=8, border=2)
        return os.path.isfile(path) and os.path.getsize(path) > 0
    except Exception:
        return False


class PinWindow(xbmcgui.WindowDialog):
    """QR a la izquierda; a la derecha la dirección, el código y el estado."""

    _CERRAR = (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_STOP)

    def __init__(self, title, url, code, qr_path):
        super().__init__()
        self.canceled = False
        blanco, gris, azul, amarillo = "0xFFFFFFFF", "0xFFB0B8C0", "0xFF58A6FF", "0xFFFFD700"
        # Fondo oscuro: una textura lisa teñida con colorDiffuse (sin textura no se pinta en todas las skins)
        if os.path.isfile(_FONDO):
            self.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, _FONDO, colorDiffuse="0xF20D1117"))
        x = 560

        def texto(y, cadena, color=blanco, fuente="font14", alto=34):
            etiqueta = xbmcgui.ControlLabel(x, y, 660, alto, cadena, font=fuente, textColor=color)
            self.addControl(etiqueta)
            return etiqueta

        texto(60, str(title or ""), fuente="font20", alto=40)
        texto(150, "Escanea el QR con el móvil o abre")
        texto(190, "[B]{0}[/B]".format(url or ""), azul)
        texto(250, "e introduce el código:")
        texto(295, "[B]{0}[/B]".format(code or ""), amarillo, "font20", 44)
        self._estado = texto(380, "", gris)
        texto(470, "Pulsa Atrás para cancelar.", gris)
        if qr_path and os.path.isfile(qr_path):
            self.addControl(xbmcgui.ControlImage(80, 150, 420, 420, qr_path))
        else:
            self.addControl(xbmcgui.ControlLabel(80, 340, 420, 40, "QR no disponible: usa la dirección",
                                                 font="font14", textColor=gris, alignment=0x00000002))

    def set_status(self, text):
        """Cambia el texto de estado (por ejemplo, la cuenta atrás)."""
        try:
            self._estado.setLabel(text)
        except Exception:
            pass

    def onAction(self, action):
        if action.getId() in self._CERRAR:
            self.canceled = True
            self.close()
