# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
import threading
import time
import xbmc
import xbmcaddon

_ADDON_ID = 'plugin.video.espatv'
_DELAY_MAP    = [0, 5, 10, 15, 30, 60]
_DELAY_LABELS = ['Sin espera', '5 seg', '10 seg', '15 seg', '30 seg', '1 min']


def _log(msg, level=xbmc.LOGDEBUG):
    xbmc.log(f'[EspaTV Service] {msg}', level)


def _parse_delay(raw):
    # El menú interno guarda el texto del label ("30 seg").
    # Compatibilidad: si por algún motivo hay un índice numérico ("4") también funciona.
    try:
        idx = int(raw)
        return _DELAY_MAP[idx] if 0 <= idx < len(_DELAY_MAP) else 0
    except (ValueError, TypeError):
        try:
            return _DELAY_MAP[_DELAY_LABELS.index(raw)]
        except ValueError:
            return 0


def _collect_tasks():
    # Devuelve tareas {'delay', 'cmd', 'check_id'} combinando addons y favoritos.
    # check_id != None solo en addons, para avisar si están desinstalados.
    try:
        addon = xbmcaddon.Addon(_ADDON_ID)
    except RuntimeError:
        _log('No se pudo cargar el addon.', xbmc.LOGERROR)
        return []
    tasks = []
    for i in range(1, 4):
        if addon.getSetting(f'autostart_{i}_enabled') != 'true':
            continue
        addon_id = addon.getSetting(f'autostart_{i}_id').strip()
        if not addon_id:
            continue
        delay = _parse_delay(addon.getSetting(f'autostart_{i}_delay'))
        tasks.append({'delay': delay, 'cmd': f'RunAddon({addon_id})', 'check_id': addon_id})
    for i in range(1, 4):
        if addon.getSetting(f'autofav_{i}_enabled') != 'true':
            continue
        cmd = addon.getSetting(f'autofav_{i}_cmd').strip()
        if not cmd:
            continue
        delay = _parse_delay(addon.getSetting(f'autofav_{i}_delay'))
        tasks.append({'delay': delay, 'cmd': cmd, 'check_id': None})
    tasks.sort(key=lambda t: t['delay'])
    return tasks


def _wait_ready(monitor):
    for _ in range(600):  # max 60 s (100 ms por iteración)
        if monitor.abortRequested():
            return False
        if not xbmc.getCondVisibility('Window.IsVisible(startup)'):
            return True
        xbmc.sleep(100)
    return not monitor.abortRequested()


def _launch(task):
    check_id = task['check_id']
    if check_id:
        try:
            xbmcaddon.Addon(check_id)
        except RuntimeError:
            _log(f'Addon no instalado o desactivado: {check_id}', xbmc.LOGWARNING)
            return
    xbmc.executebuiltin(task['cmd'])
    _log(f'Lanzado: {task["cmd"]}', xbmc.LOGINFO)


def _start_live_lists(monitor):
    """Limpia copias huérfanas de las listas de canales y, si alguna está en la sección TV de
    Kodi, la pone al día en un hilo. Solo se importa lo pesado si hace falta."""
    try:
        import xbmcvfs
        import iptv_store
        profile = xbmcvfs.translatePath(xbmcaddon.Addon(_ADDON_ID).getAddonInfo('profile'))
        store = iptv_store.Store(profile)
        store.cleanup_orphans()
        if not any(lst.get('pvr') for lst in store.lists()):
            return
        import iptv_pvr
        iptv_pvr.service_start(monitor)
    except Exception as e:
        # Las listas de canales jamás deben impedir el autostart.
        _log(f'Listas de canales al arrancar: {e}', xbmc.LOGERROR)


def _sync_custom_icon():
    """Si hay logo personalizado y una actualización de Kodi pisó `icon.png`, lo reaplica."""
    try:
        import core_settings
        if not core_settings.is_custom_icon_active():
            return
        import custom_icon
        custom_icon.sync_after_addon_update()
    except Exception as e:
        _log(f'Sincronización de logo al arrancar: {e}', xbmc.LOGWARNING)


def _sync_tmdbhelper_player():
    """Sincroniza el player 'en EspaTV' en TMDB Helper al arrancar Kodi."""
    try:
        import tmdbhelper_player
        tmdbhelper_player.sync()
    except Exception as e:
        _log(f'Sincronización de player TMDB Helper al arrancar: {e}', xbmc.LOGWARNING)


class _ServiceMonitor(xbmc.Monitor):
    """Detecta cambios de ajustes para encender/apagar el filtro CRT en caliente."""

    def __init__(self):
        super().__init__()
        self._settings_dirty = threading.Event()

    def onSettingsChanged(self):
        self._settings_dirty.set()

    def onNotification(self, sender, method, data):
        if sender == _ADDON_ID and method in ('Other.crt_assets_installed', 'crt_assets_installed'):
            self._settings_dirty.set()

    def consume_settings_dirty(self):
        if self._settings_dirty.is_set():
            self._settings_dirty.clear()
            return True
        return False


def _crt_setting_enabled():
    try:
        return xbmcaddon.Addon(_ADDON_ID).getSetting('crt_enabled') == 'true'
    except Exception:
        return False


def _init_crt_manager():
    try:
        import crt_overlay
        if not crt_overlay.assets_ready():
            _log('Modo CRT activado pero faltan las texturas crt_assets; esperando instalación.', xbmc.LOGWARNING)
            return None
        mgr = crt_overlay.CrtManager()
        _log('Modo CRT activo: overlay en caliente preparado.', xbmc.LOGINFO)
        return mgr
    except Exception as e:
        _log(f'No se pudo iniciar el filtro CRT, se continúa sin él: {e}', xbmc.LOGERROR)
        return None


def _tick_podcast_tracker():
    try:
        import xbmcgui
        raw = xbmcgui.Window(10000).getProperty("espatv_podcast_track")
        if isinstance(raw, str) and raw:
            import podcast_player
            podcast_player.service_tick()
    except Exception:
        pass


def _run_crt_loop(monitor):
    crt = None
    enabled = _crt_setting_enabled()
    needs_init = enabled
    try:
        while not monitor.abortRequested():
            dirty = monitor.consume_settings_dirty()
            if dirty:
                enabled = _crt_setting_enabled()
                needs_init = enabled and crt is None
            if enabled and crt is None:
                if needs_init:
                    needs_init = False
                    crt = _init_crt_manager()
                    if crt is not None:
                        crt.tick()
            elif not enabled and crt is not None:
                crt.cleanup()
                crt = None
            elif crt is not None:
                if dirty:
                    crt.refresh_layers()
                crt.tick()
            _tick_podcast_tracker()
            if monitor.waitForAbort(1):
                break
    finally:
        if crt is not None:
            crt.cleanup()


def run():
    monitor = _ServiceMonitor()
    _sync_custom_icon()
    _sync_tmdbhelper_player()
    _start_live_lists(monitor)
    tasks = _collect_tasks()
    if tasks:
        _log(f'Tareas activas: {[t["cmd"] for t in tasks]}', xbmc.LOGINFO)
        if not _wait_ready(monitor):
            return

        # t0: momento en que Kodi está listo. Los retardos de cada tarea son absolutos
        # respecto a t0, no acumulativos. La lista va ordenada por delay, así que
        # un favorito con retardo corto no espera a un addon con retardo largo.
        t0 = time.time()

        for task in tasks:
            if monitor.abortRequested():
                break
            remaining = task['delay'] - (time.time() - t0)
            if remaining > 0 and monitor.waitForAbort(remaining):
                break
            if not monitor.abortRequested():
                _launch(task)

    _run_crt_loop(monitor)


if __name__ == '__main__':
    run()
