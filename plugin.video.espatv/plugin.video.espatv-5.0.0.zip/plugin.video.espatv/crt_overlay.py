# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Filtro CRT sobre la reproducción de vídeo.

Las texturas no van en el ZIP del addon: `crt_overlay.xml` lee los PNG desde
`special://profile/addon_data/plugin.video.espatv/crt_assets/` (más `white.png`
de `resources/media/`), descargados bajo demanda desde GitHub (URL sobrescribible
con `ESPATV_CRT_ASSETS_URL` en pruebas).

`CrtOverlay` (`WindowXMLDialog` no modal) intercepta el mando mientras está
abierto: `onAction()` comprueba la lista blanca de mando/ratón, cierra en
< 100 ms y reenvía `Action(nombre,fullscreenvideo)`. `service.py` gestiona su
ciclo de vida.
"""
import http.client
import os
import posixpath
import shutil
import threading
import time
import urllib.error
import urllib.request
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import core_settings

ADDON_ID = "plugin.video.espatv"

# Paquete externo de texturas CRT en GitHub (sobrescribible vía ESPATV_CRT_ASSETS_URL).
_DEFAULT_CRT_ASSETS_URL = "https://raw.githubusercontent.com/espakodi/espatv/main/crt_assets.zip"

_PNG_SIG = b"\x89PNG\r\n\x1a\n"
_MAX_PACK_BYTES = 5 * 1024 * 1024  # 5 MB
_REOPEN_COOLDOWN_S = 2.0
_PLAYER_UI = "Window.IsActive(videoosd) | Window.IsActive(seekbar)"
_INSTALL_LOCK = threading.Lock()

EFFECTS = (
    "crt_sepia", "crt_scanlines", "crt_vignette", "crt_bezel",
    "crt_grain", "crt_rollbar", "crt_flicker",
)
VALID_KEYS = ("crt_enabled",) + EFFECTS
HEAVY_EFFECTS = ("crt_grain", "crt_flicker")

REQUIRED_ASSETS = (
    "crt_sepia.png",
    "crt_rollbar.png",
    "crt_scanlines.png",
    "crt_bezel.png",
    "crt_vignette.png",
    "crt_grain/grain_00.png",
    "crt_grain/grain_01.png",
    "crt_grain/grain_02.png",
    "crt_grain/grain_03.png",
    "crt_grain/grain_04.png",
    "crt_grain/grain_05.png",
)
_ALLOWED_ASSET_SET = frozenset(REQUIRED_ASSETS)

# Acciones de mando y ratón reenviadas tras retirar el overlay: (attr_xbmcgui, fallback_id, cmd)
_ACTION_SPECS = (
    # Navegación y menús OSD
    ("ACTION_MOVE_LEFT", 1, "left"),
    ("ACTION_MOVE_RIGHT", 2, "right"),
    ("ACTION_MOVE_UP", 3, "up"),
    ("ACTION_MOVE_DOWN", 4, "down"),
    ("ACTION_SELECT_ITEM", 7, "select"),
    ("ACTION_PREVIOUS_MENU", 10, "back"),
    ("ACTION_NAV_BACK", 92, "back"),
    ("ACTION_SHOW_INFO", 11, "info"),
    ("ACTION_SHOW_OSD", 24, "osd"),
    ("ACTION_CONTEXT_MENU", 117, "contextmenu"),
    # Reproducción y saltos
    ("ACTION_PAUSE", 12, "pause"),
    ("ACTION_STOP", 13, "stop"),
    ("ACTION_PLAYER_FORWARD", 77, "fastforward"),
    ("ACTION_PLAYER_REWIND", 78, "rewind"),
    ("ACTION_PLAYER_PLAY", 79, "play"),
    ("ACTION_PLAYER_PLAYPAUSE", 229, "playpause"),
    ("ACTION_STEP_FORWARD", 20, "stepforward"),
    ("ACTION_STEP_BACK", 21, "stepback"),
    ("ACTION_BIG_STEP_FORWARD", 22, "bigstepforward"),
    ("ACTION_BIG_STEP_BACK", 23, "bigstepback"),
    # Subtítulos y pistas de audio
    ("ACTION_SHOW_SUBTITLES", 25, "showsubtitles"),
    ("ACTION_NEXT_SUBTITLE", 26, "nextsubtitle"),
    ("ACTION_AUDIO_NEXT_LANGUAGE", 56, "audionextlanguage"),
    # Volumen
    ("ACTION_VOLUME_UP", 88, "volumeup"),
    ("ACTION_VOLUME_DOWN", 89, "volumedown"),
    ("ACTION_MUTE", 91, "mute"),
    # Clicks de ratón (mover/rueda/arrastre NO se reenvían para no retirar el filtro)
    ("ACTION_MOUSE_LEFT_CLICK", 100, "osd"),
    ("ACTION_MOUSE_MIDDLE_CLICK", 102, "osd"),
    ("ACTION_MOUSE_DOUBLE_CLICK", 103, "osd"),
    ("ACTION_MOUSE_RIGHT_CLICK", 101, "contextmenu"),
    ("ACTION_MOUSE_LONG_CLICK", 108, "contextmenu"),
)

_LAYER_META = (
    ("crt_scanlines", "Líneas de barrido (scanlines)",
     "Líneas horizontales finas, típicas de una tele de tubo."),
    ("crt_vignette", "Viñeta (bordes oscuros)",
     "Oscurece las esquinas para imitar el brillo desigual del tubo."),
    ("crt_bezel", "Marco curvo del tubo",
     "Marco oscuro con esquinas redondeadas que simula la curvatura de la pantalla."),
    ("crt_sepia", "Tinte cálido (sepia)",
     "Da un tono ámbar cálido a la imagen, como el fósforo de las pantallas viejas."),
    ("crt_grain", "Grano / estática",
     "Ruido animado superpuesto, como la nieve de una señal débil de antena. "
     "(Se desactiva por defecto en Modo ligero / Sin lag)."),
    ("crt_rollbar", "Barra de desincronización",
     "Banda de luz tenue que recorre la pantalla de arriba abajo."),
    ("crt_flicker", "Parpadeo de brillo",
     "Leve parpadeo del brillo, como el barrido inestable de un tubo antiguo. "
     "(Se desactiva por defecto en Modo ligero / Sin lag)."),
)


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("[EspaTV/crt] {0}".format(msg), level)


def _addon():
    return xbmcaddon.Addon(ADDON_ID)


def _addon_path():
    try:
        base = _addon().getAddonInfo("path")
    except RuntimeError:
        base = ""
    if not isinstance(base, str) or not base or base.startswith("special://"):
        base = os.path.dirname(os.path.abspath(__file__))
    return base


def crt_assets_url():
    """URL actual de descarga de `crt_assets.zip`."""
    return (os.environ.get("ESPATV_CRT_ASSETS_URL") or "").strip() or _DEFAULT_CRT_ASSETS_URL


def assets_dir():
    """Ruta en disco de `special://profile/addon_data/plugin.video.espatv/crt_assets`."""
    try:
        prof = xbmcvfs.translatePath(_addon().getAddonInfo("profile"))
    except RuntimeError:
        prof = ""
    if not isinstance(prof, str) or not prof or prof.startswith("special://"):
        prof = os.path.join(os.path.dirname(os.path.abspath(__file__)), "addon_data_fallback")
    return os.path.join(os.path.normpath(prof), "crt_assets")


def assets_ready(base_dir=None):
    """True si todas las texturas CRT requeridas existen y no están vacías."""
    root = base_dir or assets_dir()
    if not os.path.isdir(root):
        return False
    for rel in REQUIRED_ASSETS:
        full = os.path.join(root, rel.replace("/", os.sep))
        try:
            if not os.path.isfile(full) or os.path.getsize(full) <= 0:
                return False
        except OSError:
            return False
    return True


def assets_size_bytes(base_dir=None):
    """Tamaño total en disco del paquete `crt_assets` instalado."""
    root = base_dir or assets_dir()
    if not os.path.isdir(root):
        return 0
    total = 0
    for dirpath, _, filenames in os.walk(root):
        for fn in filenames:
            try:
                total += os.path.getsize(os.path.join(dirpath, fn))
            except OSError:
                pass
    return total


def _any_effect_enabled(addon=None):
    ad = addon or _addon()
    return any(ad.getSetting(k) == "true" for k in EFFECTS)


def is_crt_on(addon=None):
    """True si el interruptor maestro está activo y al menos una capa lo está."""
    ad = addon or _addon()
    return ad.getSetting("crt_enabled") == "true" and _any_effect_enabled(ad)


def apply_modo_ligero_defaults(addon=None, notify=True):
    """En dispositivos modestos desactiva por defecto las capas animadas pesadas."""
    if not core_settings.is_modo_ligero_active():
        return False
    ad = addon or _addon()
    changed = False
    for key in HEAVY_EFFECTS:
        if ad.getSetting(key) == "true":
            ad.setSetting(key, "false")
            changed = True
    if not _any_effect_enabled(ad):
        ad.setSetting("crt_scanlines", "true")
        changed = True
    if notify:
        xbmcgui.Dialog().ok(
            "Filtro CRT en Modo ligero",
            "El [B]Modo ligero / Sin lag[/B] está activado para proteger el rendimiento "
            "en Firestick o TV Box.\n\n"
            "Para evitar tirones durante el vídeo, [B]Grano / estática[/B] y "
            "[B]Parpadeo de brillo[/B] se han desactivado por defecto. "
            "Puedes volver a encenderlas manualmente en este menú si lo prefieres.",
        )
    return changed


def _safe_zip_member_target(dest_real, member_name):
    """Valida que el miembro pertenezca al paquete CRT y nunca salga de `dest_real`."""
    if not isinstance(member_name, str):
        return None
    norm = member_name.replace("\\", "/").lstrip("/")
    if not norm or norm.endswith("/"):
        return None
    clean = posixpath.normpath(norm)
    if clean in ("", ".") or clean.startswith("../") or "/../" in clean or ":" in clean:
        return None
    if clean not in _ALLOWED_ASSET_SET:
        return None
    target = os.path.realpath(os.path.join(dest_real, clean.replace("/", os.sep)))
    try:
        if os.path.commonpath([dest_real, target]) != dest_real:
            return None
    except ValueError:
        return None
    return target


def _extract_assets_zip(zip_path, dest_dir):
    """Extrae y valida el ZIP en un staging temporal antes de sustituir `dest_dir`."""
    parent = os.path.dirname(os.path.normpath(dest_dir))
    if parent:
        os.makedirs(parent, exist_ok=True)
    stamp = "{0}_{1}".format(os.getpid(), time.time_ns())
    staging = os.path.join(parent, "crt_assets.staging.{0}".format(stamp))
    backup = os.path.join(parent, "crt_assets.bak.{0}".format(stamp))
    try:
        os.makedirs(staging, exist_ok=True)
        staging_real = os.path.realpath(staging)
        with zipfile.ZipFile(zip_path, "r") as zf:
            file_infos = [info for info in zf.infolist() if not info.is_dir()]
            declared_total = 0
            for info in file_infos:
                if _safe_zip_member_target(staging_real, info.filename) is None:
                    return False, "Entrada no autorizada en ZIP: {0}".format(info.filename)
                if info.file_size < 0 or info.file_size > _MAX_PACK_BYTES:
                    return False, "El paquete supera el tamaño máximo permitido (5 MB)."
                declared_total += info.file_size
                if declared_total > _MAX_PACK_BYTES:
                    return False, "El paquete supera el tamaño máximo permitido (5 MB)."
            corrupt = zf.testzip()
            if corrupt is not None:
                return False, "El archivo ZIP está dañado en «{0}».".format(corrupt)
            present = set()
            actual_total = 0
            for info in file_infos:
                target = _safe_zip_member_target(staging_real, info.filename)
                with zf.open(info, "r") as fp:
                    data = fp.read(_MAX_PACK_BYTES + 1)
                actual_total += len(data)
                if len(data) > _MAX_PACK_BYTES or actual_total > _MAX_PACK_BYTES:
                    return False, "El paquete supera el tamaño máximo permitido (5 MB)."
                if len(data) < 24 or not data.startswith(_PNG_SIG):
                    return False, "Textura PNG no válida: {0}".format(info.filename)
                os.makedirs(os.path.dirname(target), exist_ok=True)
                with open(target, "wb") as out:
                    out.write(data)
                present.add(posixpath.normpath(info.filename.replace("\\", "/").lstrip("/")))
        missing = sorted(_ALLOWED_ASSET_SET - present)
        if missing:
            return False, "Faltan texturas requeridas en el paquete: {0}".format(", ".join(missing[:3]))
        if not assets_ready(staging):
            return False, "La verificación final de texturas extraídas falló."
        if os.path.exists(dest_dir):
            os.replace(dest_dir, backup)
        try:
            os.replace(staging, dest_dir)
        except OSError:
            if os.path.exists(backup) and not os.path.exists(dest_dir):
                os.replace(backup, dest_dir)
            raise
        if os.path.exists(backup):
            shutil.rmtree(backup, ignore_errors=True)
        return True, ""
    except zipfile.BadZipFile:
        return False, "El archivo descargado no es un ZIP válido."
    except OSError as e:
        return False, "Error instalando las texturas CRT ({0}).".format(e)
    finally:
        if os.path.exists(staging):
            shutil.rmtree(staging, ignore_errors=True)
        if os.path.exists(backup) and os.path.exists(dest_dir):
            shutil.rmtree(backup, ignore_errors=True)


def install_crt_assets(confirm=True, url=None):
    """Descarga bajo confirmación e instala `crt_assets.zip` en `addon_data/crt_assets`."""
    dest_dir = assets_dir()
    src_url = url or crt_assets_url()
    if confirm:
        ok = xbmcgui.Dialog().yesno(
            "Instalar texturas del Filtro CRT",
            "EspaTV necesita descargar el paquete de texturas CRT (~850 KB) para "
            "aplicar scanlines, viñeta, bisel y grano sobre el vídeo.\n\n"
            "[B]Origen:[/B] {0}\n"
            "[B]Destino:[/B] {1}\n\n"
            "¿Descargar e instalar ahora?".format(src_url, dest_dir),
            nolabel="Cancelar",
            yeslabel="Instalar",
        )
        if not ok:
            return False

    with _INSTALL_LOCK:
        parent = os.path.dirname(os.path.normpath(dest_dir))
        os.makedirs(parent, exist_ok=True)
        tmp_zip = os.path.join(parent, "crt_assets.{0}_{1}.zip.tmp".format(os.getpid(), time.time_ns()))
        prog = xbmcgui.DialogProgress()
        prog.create("Filtro CRT Vintage", "Descargando paquete de texturas...")
        prog_open = True
        try:
            req = urllib.request.Request(src_url, headers={"User-Agent": "EspaTV/CRT"})
            with urllib.request.urlopen(req, timeout=20) as resp:
                status = getattr(resp, "status", 200)
                if isinstance(status, int) and status != 200:
                    raise ValueError("Respuesta HTTP inesperada ({0}).".format(status))
                try:
                    content_len = int(resp.headers.get("Content-Length") or 0)
                except (TypeError, ValueError):
                    content_len = 0
                if content_len > _MAX_PACK_BYTES:
                    raise ValueError("El paquete supera el tamaño máximo permitido (5 MB).")
                total = 0
                with open(tmp_zip, "wb") as out:
                    while True:
                        if prog.iscanceled():
                            return False
                        chunk = resp.read(32768)
                        if not chunk:
                            break
                        total += len(chunk)
                        if total > _MAX_PACK_BYTES:
                            raise ValueError("El paquete supera el tamaño máximo permitido (5 MB).")
                        out.write(chunk)
                        if content_len > 0:
                            pct = min(90, int((total * 90) / content_len))
                            prog.update(pct, "Descargando texturas CRT ({0} KB)...".format(total // 1024))
            prog.update(95, "Verificando e instalando texturas...")
            ok_ext, err = _extract_assets_zip(tmp_zip, dest_dir)
            prog.close()
            prog_open = False
            if not ok_ext:
                xbmcgui.Dialog().ok("Filtro CRT Vintage", err)
                return False
            try:
                if _addon().getSetting("crt_enabled") == "true":
                    xbmc.executebuiltin("NotifyAll({0}, crt_assets_installed)".format(ADDON_ID))
            except Exception:
                pass
            xbmcgui.Dialog().notification("EspaTV CRT", "Texturas CRT instaladas.", xbmcgui.NOTIFICATION_INFO)
            _log("Paquete CRT instalado desde {0} en {1}".format(src_url, dest_dir))
            return True
        except (urllib.error.URLError, http.client.HTTPException, ValueError, OSError) as e:
            if prog_open:
                prog.close()
                prog_open = False
            _log("Fallo instalando texturas CRT desde {0}: {1}".format(src_url, e), xbmc.LOGWARNING)
            xbmcgui.Dialog().ok(
                "Filtro CRT Vintage",
                "No se pudo descargar el paquete de texturas CRT.\n\n"
                "[B]Origen:[/B] {0}\n[B]Detalle:[/B] {1}".format(src_url, e),
            )
            return False
        finally:
            if prog_open:
                try:
                    prog.close()
                except Exception:
                    pass
            if os.path.exists(tmp_zip):
                try:
                    os.remove(tmp_zip)
                except OSError:
                    pass


def uninstall_crt_assets():
    """Elimina las texturas CRT descargadas para liberar espacio y apaga el filtro."""
    dest_dir = assets_dir()
    if not os.path.isdir(dest_dir):
        xbmcgui.Dialog().notification("EspaTV CRT", "No hay texturas CRT instaladas.", xbmcgui.NOTIFICATION_INFO)
        return False
    size_b = assets_size_bytes(dest_dir)
    kb = max(1, size_b // 1024) if size_b > 0 else 0
    if not xbmcgui.Dialog().yesno(
        "Desinstalar texturas CRT",
        "¿Eliminar las texturas del Filtro CRT ({0} KB) y desactivar el filtro?".format(kb),
        nolabel="Cancelar",
        yeslabel="Eliminar",
    ):
        return False
    with _INSTALL_LOCK:
        _addon().setSetting("crt_enabled", "false")
        shutil.rmtree(dest_dir, ignore_errors=True)
        if os.path.isdir(dest_dir):
            xbmcgui.Dialog().notification(
                "EspaTV CRT", "No se pudieron eliminar todas las texturas CRT.", xbmcgui.NOTIFICATION_WARNING
            )
            return False
    xbmcgui.Dialog().notification("EspaTV CRT", "Texturas CRT eliminadas.", xbmcgui.NOTIFICATION_INFO)
    return True


def _build_forward_map():
    """Construye la whitelist de IDs de acción -> comando `Action(cmd,fullscreenvideo)`."""
    table = {}
    for attr, fallback, cmd in _ACTION_SPECS:
        table[fallback] = cmd
        val = getattr(xbmcgui, attr, None)
        if isinstance(val, int) and not isinstance(val, bool) and val >= 0:
            table[val] = cmd
    return table


_FORWARD_MAP = _build_forward_map()


def resolve_action_command(action_id):
    """Devuelve el comando `fullscreenvideo` para `action_id`, o None si debe ignorarse."""
    return _FORWARD_MAP.get(action_id)


class CrtOverlay(xbmcgui.WindowXMLDialog):
    """Ventana superpuesta con las 7 capas del filtro CRT durante vídeo."""

    def onInit(self):
        self.refresh_properties()

    def refresh_properties(self):
        try:
            ad = _addon()
            for key in EFFECTS:
                self.setProperty(key, "true" if ad.getSetting(key) == "true" else "false")
        except Exception as e:
            _log("refresh_properties falló: {0}".format(e), xbmc.LOGWARNING)

    def onAction(self, action):
        aid = action.getId()
        name = resolve_action_command(aid)
        if name is None:
            return
        manager = getattr(self, "_manager", None)
        if manager is not None:
            manager.notify_dismissed()
        self.close()
        xbmc.executebuiltin("Action({0},fullscreenvideo)".format(name))


class CrtManager(xbmc.Player):
    """Coordina ciclo de vida del overlay CRT sin bloquear al reproductor."""

    def __init__(self):
        super().__init__()
        self._overlay = None
        self._lock = threading.Lock()
        self._dismissed_at = 0.0

    def onPlayBackStarted(self):
        self._close("onPlayBackStarted")

    def onAVStarted(self):
        try:
            if self.isPlayingVideo() and is_crt_on() and assets_ready():
                self._open("onAVStarted")
        except Exception as e:
            _log("onAVStarted falló: {0}".format(e), xbmc.LOGERROR)

    def onPlayBackStopped(self):
        self._close("onPlayBackStopped")

    def onPlayBackEnded(self):
        self._close("onPlayBackEnded")

    def onPlayBackError(self):
        self._close("onPlayBackError")

    def refresh_layers(self):
        """Aplica cambios de capas o apagado/encendido al instante aunque siga el vídeo."""
        try:
            if not self.isPlayingVideo() or not is_crt_on() or not assets_ready():
                self._close("settings-disabled")
                return
            with self._lock:
                ov = self._overlay
            if ov is not None:
                ov.refresh_properties()
            elif not xbmc.getCondVisibility(_PLAYER_UI):
                self._open("settings-enabled")
        except Exception as e:
            _log("refresh_layers falló: {0}".format(e), xbmc.LOGERROR)

    def tick(self):
        """Comprobación periódica en `service.py`: cierra o reabre tras cooldown."""
        try:
            if not self.isPlayingVideo():
                self._close("tick-idle")
                return
            if self._overlay is not None:
                if not is_crt_on():
                    self._close("tick-disabled")
                return
            if (time.monotonic() - self._dismissed_at >= _REOPEN_COOLDOWN_S
                    and is_crt_on()
                    and not xbmc.getCondVisibility(_PLAYER_UI)
                    and assets_ready()):
                self._open("tick-reopen")
        except Exception as e:
            _log("tick falló: {0}".format(e), xbmc.LOGERROR)

    def notify_dismissed(self):
        # Guardar el timestamp antes de soltar la referencia para no reabrir en el mismo tick.
        self._dismissed_at = time.monotonic()
        with self._lock:
            self._overlay = None

    def _open(self, reason):
        with self._lock:
            if self._overlay is not None:
                return
            overlay = CrtOverlay("crt_overlay.xml", _addon_path(), "Default", "1080i")
            overlay._manager = self
            overlay.show()
            self._overlay = overlay
        _log("overlay ABIERTO ({0})".format(reason), xbmc.LOGDEBUG)

    def _close(self, reason=""):
        with self._lock:
            overlay, self._overlay = self._overlay, None
        if overlay is None:
            return
        try:
            overlay.close()
            _log("overlay CERRADO ({0})".format(reason), xbmc.LOGDEBUG)
        except Exception as e:
            _log("cierre falló ({0}): {1}".format(reason, e), xbmc.LOGERROR)

    def cleanup(self):
        self._close("cleanup")


def layer_metadata():
    """Metadatos ordenados de las 7 capas del filtro CRT."""
    return _LAYER_META
