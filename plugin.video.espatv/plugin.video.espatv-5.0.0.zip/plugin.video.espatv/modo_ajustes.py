# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Ventana del Modo Ajustes: pinta el modelo en espatv_ajustes.xml y traduce las teclas.

La ventana no sabe de ajustes: todo lo decide `ajustes_modelo.Modelo`. Aquí solo se rellenan
las listas 200 (categorías) y 300 (ajustes), se actualiza la ficha 400 y se cierra con Atrás,
la X o el botón Cerrar.
"""
from __future__ import annotations

import os
import re
import threading
import time

import xbmc
import xbmcgui
import xbmcaddon

import ajustes_modelo
import ajustes_registro

_LOG = '[ModoAjustes]'
_XML = 'espatv_ajustes.xml'
_RUTA = os.path.dirname(os.path.abspath(__file__))
_MEDIA = os.path.join(_RUTA, 'resources', 'media')

ID_X = 100
ID_BUSCAR = 110
ID_MODIFICADOS = 111
ID_CATEGORIAS = 200
ID_AJUSTES = 300
ID_FICHA = 400
ID_AYUDA = 401
ID_DESHACER = 501
ID_RESTAURAR = 502
ID_CLASICOS = 503
ID_CERRAR = 504

ACTION_MOVE_LEFT = 1
ACTION_MOVE_RIGHT = 2
ACTION_MOVE_UP = 3
ACTION_MOVE_DOWN = 4
ACTION_SELECT_ITEM = 7
ACTION_PREVIOUS_MENU = 10
ACTION_NAV_BACK = 92
ACTION_CONTEXT_MENU = 117

_ATRAS = (ACTION_PREVIOUS_MENU, ACTION_NAV_BACK)
_PROPIEDADES_FILA = ('tipo', 'cabecera', 'valor', 'on', 'pct', 'modificado',
                     'deshabilitado', 'destructivo', 'color', 'color_valor')


def _ruta_icono(nombre):
    """Ruta completa de un icono de resources/media, con respaldo si el nombre no existe."""
    if not nombre:
        nombre = 'opciones.png'
    ruta = nombre if os.path.isabs(nombre) else os.path.join(_MEDIA, nombre)
    if os.path.isfile(ruta):
        return ruta
    respaldo = os.path.join(_MEDIA, 'opciones.png')
    return respaldo if os.path.isfile(respaldo) else ruta


def _construir_modelo(ganchos):
    """Punto único que los tests parchean: registro -> Modelo con la versión del addon."""
    categorias = ajustes_registro.construir(ganchos)
    try:
        version = xbmcaddon.Addon().getAddonInfo('version')
    except Exception:
        version = ''
    return ajustes_modelo.Modelo(categorias, ajustes_registro.CATEGORIAS, version=version)


PROP_REABRIR = 'espatv_ajustes_reabrir'


def guardar_reapertura(cat, id_):
    xbmcgui.Window(10000).setProperty(PROP_REABRIR, '{0}|{1}'.format(cat or '', id_ or ''))


def leer_reapertura():
    ventana = xbmcgui.Window(10000)
    valor = ventana.getProperty(PROP_REABRIR)
    if not valor:
        return None
    ventana.clearProperty(PROP_REABRIR)
    if '|' not in valor:
        return None
    cat, ident = valor.split('|', 1)
    return cat, ident


def reabrir_si_procede(ganchos):
    datos = leer_reapertura()
    if datos is None:
        return False
    show(ganchos, cat=datos[0], id_=datos[1])
    return True


class ModoAjustes(xbmcgui.WindowXMLDialog):
    def __init__(self, *args, modelo=None, ganchos=None, cat=None, id_=None,
                 inicio=None, **kw):
        super().__init__(*args)
        self.modelo = modelo
        self.ganchos = ganchos or {}
        self._cat_pedida = cat
        self._id_pedido = id_
        self._inicio = inicio if inicio is not None else time.monotonic()
        self._cerrado = False
        self._abrir_clasicos = False
        self._ultima_pos = None
        self._ultima_cat_pos = None
        self._filas = []
        self._vista = []
        self._modo_lista = 'categoria'
        self._accion_pendiente = None
        self._clase_pendiente = ''

    # Arranque

    def onInit(self):
        if self._cat_pedida:
            self._elegir_categoria(self._cat_pedida)
        entrada = self._entrada_pedida()
        if entrada is not None and entrada.categoria in self.modelo.categorias:
            self.modelo.cat_actual = entrada.categoria

        self._aplicar_accesibilidad()
        self.setProperty('version', str(self.modelo.version or ''))
        self.setProperty('focused_fanart', '')
        self.setProperty('n_deshacer', '0')
        self._pintar_categorias()
        self._pintar_ajustes(entrada.id if entrada is not None else None)
        self.setProperty('n_modificados', str(self.modelo.total_modificados()))

        self._hilo_foco = threading.Thread(target=self._vigia_foco, daemon=True)
        self._hilo_foco.start()

        try:
            ms = int((time.monotonic() - self._inicio) * 1000)
            xbmc.log('{0} abierto en {1} ms'.format(_LOG, ms), xbmc.LOGINFO)
        except Exception:
            pass

    def _aplicar_accesibilidad(self):
        """Lo mismo que el resto del addon (default._acc_transform): negrita por defecto y, con
        «sustituir símbolos», * en vez de ●. Con Fantasía al máximo, el resplandor respira."""
        acc = self.ganchos.get('acc_leer')
        try:
            self._negrita = bool(acc('acc_force_bold')) if acc else False
            sin_simbolos = bool(acc('acc_strip_symbols')) if acc else False
        except RuntimeError:
            self._negrita, sin_simbolos = False, False
        self.setProperty('punto', '*' if sin_simbolos else '●')
        try:
            fantasia_max = xbmcaddon.Addon().getSetting('fantasia_nivel') == '2'
        except RuntimeError:
            fantasia_max = False
        self.setProperty('fantasia_max', '1' if fantasia_max else '')

    def _rotulo(self, texto):
        return '[B]{0}[/B]'.format(texto) if getattr(self, '_negrita', False) and '[B]' not in texto else texto

    def _entrada_pedida(self):
        if not self._id_pedido:
            return None
        for entradas in self.modelo.categorias.values():
            for entrada in entradas:
                if entrada.id == self._id_pedido:
                    return entrada
        return None

    def _elegir_categoria(self, clave):
        if clave == ajustes_registro.MODIFICADOS:
            return
        if clave and self.modelo.categorias.get(clave):
            self.modelo.cat_actual = clave

    # Pintado

    def _pintar_categorias(self):
        contadores = self.modelo.contadores()
        control = self.getControl(ID_CATEGORIAS)
        control.reset()
        items = []
        for categoria in self.modelo.orden:
            li = xbmcgui.ListItem(label=self._rotulo(categoria.rotulo))
            li.setArt({'icon': _ruta_icono(categoria.icono)})
            li.setProperty('modificados', str(contadores.get(categoria.clave, 0)))
            items.append(li)
        control.addItems(items)
        for pos, categoria in enumerate(self.modelo.orden):
            if categoria.clave == self.modelo.cat_actual:
                try:
                    control.selectItem(pos)
                except Exception:
                    pass
                break

    def _pintar_ajustes(self, ident_foco=None, enfocar=True, filas=None):
        categoria = self.modelo.categoria()
        if filas is None:
            self._modo_lista = 'categoria'
            if categoria is not None:
                self.setProperty('cat_titulo', categoria.rotulo)
                self.setProperty('cat_subtitulo', categoria.subtitulo)
                # Deshacer o salir de una busqueda cambian de categoria sin pasar por la lista 200:
                # sin esto la columna izquierda seguiria marcando la anterior.
                pos_cat = next((i for i, c in enumerate(self.modelo.orden)
                                if c.clave == categoria.clave), None)
                lista_cat = self.getControl(ID_CATEGORIAS)
                if pos_cat is not None and lista_cat.getSelectedPosition() != pos_cat:
                    lista_cat.selectItem(pos_cat)
                    self._ultima_cat_pos = pos_cat
            filas = self.modelo.filas()
        self.setProperty('focused_fanart', '')
        control = self.getControl(ID_AJUSTES)
        control.reset()
        # Cada cabecera es una fila propia (el XML no puede cambiar de layout por fila); _vista
        # traduce la posicion en la lista a la fila del modelo, None en las cabeceras.
        self._vista = []
        self._filas = filas
        items = []
        for i, fila in enumerate(filas):
            if fila.get('cabecera'):
                cab = xbmcgui.ListItem(label=fila['cabecera'])
                cab.setProperty('tipo', 'cabecera')
                items.append(cab)
                self._vista.append(None)
            li = xbmcgui.ListItem(label=self._rotulo(fila['rotulo']))
            icono = _ruta_icono(fila['icono'])
            li.setArt({'icon': icono})
            for clave in _PROPIEDADES_FILA:
                li.setProperty(clave, str(fila.get(clave, '')))
            li.setProperty('icono', icono)
            items.append(li)
            self._vista.append(i)
        control.addItems(items)

        indice = 0
        if ident_foco is not None:
            indice = next((i for i, fila in enumerate(filas)
                           if fila['entrada'].id == ident_foco), 0)
        pos = self._vista.index(indice) if filas else 0
        if filas:
            try:
                control.selectItem(pos)
            except Exception:
                pass
            if enfocar:
                self.setFocusId(ID_AJUSTES)
            self._actualizar_ficha(pos)
        else:
            self._limpiar_ficha()

    def _cambiar_categoria(self, pos, enfocar=True):
        if 0 <= pos < len(self.modelo.orden):
            self.modelo.cat_actual = self.modelo.orden[pos].clave
            # La lista entra con su animación Visible del XML. Solo al recorrer categorías: si la
            # lista tuviera el foco, al ocultarla Kodi se lo llevaría a otro control.
            animar = not enfocar and self.getFocusId() != ID_AJUSTES
            if animar:
                self.setProperty('recargando', '1')
                time.sleep(0.04)
            self._pintar_ajustes(enfocar=enfocar)
            if animar:
                self.setProperty('recargando', '')

    def _limpiar_ficha(self):
        for clave in ('ficha_titulo', 'ficha_ayuda', 'ficha_actual', 'ficha_defecto',
                      'ficha_tambien', 'ficha_estado', 'ficha_icono', 'ficha_atajos'):
            self.setProperty(clave, '')
        self.setProperty('ficha_estado_color', 'FF94A3B8')

    def _actualizar_ficha(self, pos=None):
        filas = self._filas
        if not filas:
            self._limpiar_ficha()
            return
        if pos is None:
            try:
                pos = self.getControl(ID_AJUSTES).getSelectedPosition()
            except Exception:
                pos = 0
        vista = getattr(self, '_vista', None) or list(range(len(filas)))
        if not (0 <= pos < len(vista)):
            pos = 0
        # En una cabecera, la ficha es la del ajuste que la sigue.
        indice = next((i for i in vista[pos:] if i is not None), 0)
        ficha = self.modelo.ficha(filas[indice]['entrada'])
        for clave, valor in ficha.items():
            if clave == 'ficha_icono':
                valor = _ruta_icono(valor)
            self.setProperty(clave, str(valor or ''))
        try:
            tick = int(self.getProperty('ficha_tick') or 0)
        except (TypeError, ValueError):
            tick = 0
        self.setProperty('ficha_tick', str(1 - tick))

    def _fila_seleccionada(self):
        try:
            pos = self.getControl(ID_AJUSTES).getSelectedPosition()
        except Exception:
            return None, None
        if not (0 <= pos < len(self._vista)):
            return pos, None
        indice = self._vista[pos]
        if indice is None:
            indice = next((i for i in self._vista[pos:] if i is not None), None)
            if indice is None:
                return pos, None
            pos = self._vista.index(indice)
        if not (0 <= indice < len(self._filas)):
            return pos, None
        return pos, self._filas[indice]

    def _actualizar_contadores(self):
        contadores = self.modelo.contadores()
        self.setProperty('n_modificados', str(self.modelo.total_modificados()))
        self.setProperty('n_deshacer', str(self.modelo.n_deshacer))
        control = self.getControl(ID_CATEGORIAS)
        for pos, categoria in enumerate(self.modelo.orden):
            try:
                control.getListItem(pos).setProperty(
                    'modificados', str(contadores.get(categoria.clave, 0)))
            except Exception:
                pass

    def _refrescar_fila(self, pos):
        if not (0 <= pos < len(self._vista)):
            return
        indice = self._vista[pos]
        if indice is None or not (0 <= indice < len(self._filas)):
            return
        fila = self.modelo.fila(self._filas[indice]['entrada'])
        self._filas[indice] = fila
        try:
            item = self.getControl(ID_AJUSTES).getListItem(pos)
        except Exception:
            return
        icono = _ruta_icono(fila['icono'])
        item.setArt({'icon': icono})
        for clave in _PROPIEDADES_FILA:
            item.setProperty(clave, str(fila.get(clave, '')))
        item.setProperty('icono', icono)
        self._actualizar_ficha(pos)

    def _aplicar_en_fila(self, e, valor, pos=None):
        antes = {otra.id: self.modelo.habilitada(otra) for otra in self.modelo.entradas()}
        if not self.modelo.aplicar(e, valor):
            return False
        self._actualizar_contadores()
        # Si el cambio habilita o deshabilita otras filas hay que repintar la lista entera;
        # si no, basta con refrescar la fila para no perder el scroll.
        if self._modo_lista == 'categoria' and any(
                self.modelo.habilitada(otra) != antes[otra.id]
                for otra in self.modelo.entradas()):
            self._pintar_ajustes(ident_foco=e.id)
        elif pos is not None:
            self._refrescar_fila(pos)
        return True

    def _flecha(self, delta):
        pos, fila = self._fila_seleccionada()
        if fila is None:
            return
        entrada = fila['entrada']
        if entrada.tipo not in ajustes_registro.TIPOS_CON_VALOR:
            if delta < 0:
                self.setFocusId(ID_CATEGORIAS)
            return
        nuevo = self.modelo.siguiente_valor(entrada, delta)
        if nuevo is not None:
            self._aplicar_en_fila(entrada, nuevo, pos)

    def _accion_seleccionada(self):
        pos, fila = self._fila_seleccionada()
        if fila is None:
            return
        entrada = fila['entrada']
        if not self.modelo.habilitada(entrada):
            xbmcgui.Dialog().notification(
                'Modo Ajustes', 'Depende de otro ajuste desactivado')
            return
        accion = self.modelo.accion_ok(entrada)
        if accion == 'alternar':
            actual = self.modelo.leer(entrada)
            if actual is not ajustes_modelo.SIN_LEER:
                self._aplicar_en_fila(entrada, not bool(actual), pos)
        elif accion == 'seleccionar':
            self._seleccionar_enum(entrada, pos)
        elif accion == 'numero':
            self._cambiar_numero(entrada, pos)
        elif accion == 'texto':
            self._cambiar_texto(entrada, pos)
        elif accion == 'carpeta':
            self._cambiar_carpeta(entrada, pos)
        elif accion == 'confirmar':
            self._confirmar(entrada, pos)
        elif accion == 'accion':
            self._ejecutar(entrada)
            if not self._cerrado:
                self._actualizar_contadores()
                self._refrescar_fila(pos)
        elif accion == 'clasico':
            self._abrir_clasicos = True
            self._cerrar()

    def _seleccionar_enum(self, entrada, pos):
        opciones = tuple(entrada.opciones or ())
        if not opciones:
            return
        actual = self.modelo.leer(entrada)
        if entrada.guarda_indice:
            try:
                preseleccion = int(actual)
            except (TypeError, ValueError):
                preseleccion = 0
        else:
            texto = '' if actual is ajustes_modelo.SIN_LEER or actual is None else str(actual)
            preseleccion = opciones.index(texto) if texto in opciones else 0
        preseleccion = max(0, min(len(opciones) - 1, preseleccion))
        items = []
        for opcion in opciones:
            item = xbmcgui.ListItem(label=opcion)
            if entrada.ayuda:
                item.setInfo('video', {'plot': entrada.ayuda})
            items.append(item)
        elegido = xbmcgui.Dialog().select(entrada.rotulo, items, useDetails=True,
                                          preselect=preseleccion)
        if elegido < 0:
            return
        self._aplicar_en_fila(entrada, elegido if entrada.guarda_indice else opciones[elegido], pos)

    def _cambiar_numero(self, entrada, pos):
        actual = self.modelo.leer(entrada)
        texto = '' if actual is ajustes_modelo.SIN_LEER or actual is None else str(actual)
        nuevo = xbmcgui.Dialog().numeric(0, entrada.rotulo, texto)
        if not nuevo:
            return
        try:
            valor = int(nuevo)
        except (TypeError, ValueError):
            return
        self._aplicar_en_fila(entrada, valor, pos)

    def _cambiar_texto(self, entrada, pos):
        actual = self.modelo.leer(entrada)
        texto = '' if actual is ajustes_modelo.SIN_LEER or actual is None else str(actual)
        opcion = getattr(xbmcgui, 'ALPHANUM_HIDE_INPUT', 0) if entrada.secreto else 0
        nuevo = xbmcgui.Dialog().input(entrada.rotulo, texto, option=opcion)
        if nuevo is None:
            return
        self._aplicar_en_fila(entrada, nuevo, pos)

    def _cambiar_carpeta(self, entrada, pos):
        actual = self.modelo.leer(entrada)
        texto = '' if actual is ajustes_modelo.SIN_LEER or actual is None else str(actual)
        nueva = xbmcgui.Dialog().browseSingle(0, entrada.rotulo, 'files', '', False, False, texto)
        if nueva is None or nueva == texto:
            return
        self._aplicar_en_fila(entrada, nueva, pos)

    def _confirmar(self, entrada, pos):
        if entrada.id == 'restaurar_todo':
            self._restaurar_todo()
            return
        self._ejecutar(entrada)
        if self._cerrado:
            return
        self._actualizar_contadores()
        if self._modo_lista == 'categoria':
            self._pintar_ajustes(ident_foco=entrada.id)
        else:
            self._refrescar_fila(pos)

    def _ejecutar(self, entrada):
        accion = entrada.accion
        if accion is None:
            return
        clase = entrada.clase_accion or ''
        if clase in ('dialogo', 'pantalla'):
            if clase == 'dialogo':
                guardar_reapertura(self.modelo.cat_actual, entrada.id)
            self._accion_pendiente = accion
            self._clase_pendiente = clase
            self._cerrar()
            return
        if callable(accion):
            accion()
        elif isinstance(accion, str) and accion:
            xbmc.executebuiltin(accion)

    def _vigia_foco(self):
        """La ficha sigue a la selección aunque Kodi cambie la fila después de onAction."""
        monitor = xbmc.Monitor()
        while not self._cerrado:
            try:
                foco = self.getFocusId()
                if foco == ID_AJUSTES:
                    pos = self.getControl(ID_AJUSTES).getSelectedPosition()
                    if pos >= 0 and pos != self._ultima_pos:
                        self._ultima_pos = pos
                        self._actualizar_ficha(pos)
                elif foco == ID_CATEGORIAS:
                    pos = self.getControl(ID_CATEGORIAS).getSelectedPosition()
                    if pos >= 0 and pos != self._ultima_cat_pos:
                        self._ultima_cat_pos = pos
                        if (0 <= pos < len(self.modelo.orden)
                                and self.modelo.orden[pos].clave != self.modelo.cat_actual):
                            self._cambiar_categoria(pos, enfocar=False)
            except Exception:
                pass
            if monitor.waitForAbort(0.2):
                break

    # Entrada

    def onClick(self, controlId):
        if controlId in (ID_X, ID_CERRAR):
            self._cerrar()
            return
        if controlId == ID_CLASICOS:
            self._abrir_clasicos = True
            self._cerrar()
            return
        if controlId == ID_BUSCAR:
            self._buscar()
            return
        if controlId == ID_MODIFICADOS:
            self._ver_modificados()
            return
        if controlId == ID_DESHACER:
            self._deshacer()
            return
        if controlId == ID_RESTAURAR:
            self._restaurar_categoria()
            return
        if controlId == ID_CATEGORIAS:
            try:
                pos = self.getControl(ID_CATEGORIAS).getSelectedPosition()
            except Exception:
                return
            self._cambiar_categoria(pos)
            return
        if controlId == ID_AJUSTES:
            self._accion_seleccionada()

    def _saltar_cabecera(self, paso):
        """Kodi ya ha movido la seleccion cuando llega onAction: si ha caido en una cabecera,
        sigue en la misma direccion; arriba del todo, sube a la cabecera de la ventana."""
        vista = getattr(self, '_vista', None)
        if not vista:
            return
        control = self.getControl(ID_AJUSTES)
        pos = control.getSelectedPosition()
        if not (0 <= pos < len(vista)) or vista[pos] is not None:
            return
        destino = pos + paso
        if 0 <= destino < len(vista):
            control.selectItem(destino)
        elif paso < 0:
            self.setFocusId(ID_BUSCAR)

    # Buscar, modificados y restaurar

    def _buscar(self):
        texto = xbmcgui.Dialog().input('Buscar ajustes')
        if not texto:
            return
        filas = self.modelo.buscar(texto)
        self._modo_lista = 'busqueda'
        self.setProperty('cat_titulo', 'Resultados de «{0}»'.format(texto))
        self.setProperty('cat_subtitulo', '{0} ajustes encontrados'.format(len(filas)))
        self._pintar_ajustes(filas=filas)
        self.setFocusId(ID_AJUSTES)

    def _ver_modificados(self):
        filas = self.modelo.modificados()
        if not filas:
            xbmcgui.Dialog().notification('Modo Ajustes', 'No hay ajustes modificados')
            return
        self._modo_lista = 'modificados'
        self.setProperty('cat_titulo', 'Modificados')
        self.setProperty('cat_subtitulo',
                         '{0} ajustes fuera de su valor de serie'.format(len(filas)))
        self._pintar_ajustes(filas=filas)
        self.setFocusId(ID_AJUSTES)

    def _deshacer(self):
        entrada = self.modelo.deshacer_ultimo()
        if entrada is None:
            return
        self._modo_lista = 'categoria'
        if entrada.categoria in self.modelo.categorias:
            self.modelo.cat_actual = entrada.categoria
        self._pintar_ajustes(ident_foco=entrada.id)
        self._actualizar_contadores()

    def _restaurar_categoria(self):
        categoria = self.modelo.categoria()
        if categoria is None:
            return
        filas = [fila for fila in self.modelo.filas()
                 if fila['modificado'] == '1' and not fila['entrada'].protegido]
        if not filas:
            xbmcgui.Dialog().notification('Restaurar categoría', 'No hay nada que restaurar')
            return
        rotulos = '\n'.join('· ' + fila['rotulo'] for fila in filas[:12])
        if len(filas) > 12:
            rotulos += '\n· y {0} más'.format(len(filas) - 12)
        if not xbmcgui.Dialog().yesno('Restaurar {0}'.format(categoria.rotulo),
                                      'Se devuelven a su valor de serie:\n\n' + rotulos):
            return
        self.modelo.restaurar_categoria(categoria.clave)
        self._modo_lista = 'categoria'
        self._pintar_ajustes()
        self._actualizar_contadores()

    def _restaurar_todo(self):
        tocan, _protegidas = self.modelo.plan_restaurar_todo()
        if not tocan:
            xbmcgui.Dialog().notification('Restaurar ajustes', 'No hay nada que restaurar')
            return
        texto = (
            'Se restauran {0} ajustes.\n\nNo se tocan: favoritos, historial, copias, claves, '
            'tokens, menús, filas del Modo Cine, atajos, tráiler, inicio automático, fanart, '
            'récords, EspaMando.').format(len(tocan))
        if not xbmcgui.Dialog().yesno('Restaurar todos los ajustes', texto,
                                      nolabel='Cancelar', yeslabel='Restaurar'):
            return
        restaurados = self.modelo.restaurar_todo()
        self._modo_lista = 'categoria'
        self._pintar_ajustes()
        self._actualizar_contadores()
        xbmcgui.Dialog().notification(
            'Modo Ajustes', '{0} ajustes restaurados'.format(restaurados))

    def _menu_contextual(self):
        if self.getFocusId() == ID_CATEGORIAS:
            if xbmcgui.Dialog().contextmenu(['Restaurar esta categoría']) == 0:
                self._restaurar_categoria()
            return
        if self.getFocusId() != ID_AJUSTES:
            return
        pos, fila = self._fila_seleccionada()
        if fila is None:
            return
        entrada = fila['entrada']
        elegido = xbmcgui.Dialog().contextmenu([
            'Restaurar de serie', 'Ver en ajustes clásicos', 'Copiar nombre del ajuste'])
        if elegido == 0:
            if self.modelo.restaurar(entrada):
                self._actualizar_contadores()
                if self._modo_lista == 'categoria':
                    self._pintar_ajustes(ident_foco=entrada.id)
                else:
                    self._refrescar_fila(pos)
            elif entrada.protegido:
                xbmcgui.Dialog().notification('Modo Ajustes', 'Este ajuste está protegido')
        elif elegido == 1:
            self._abrir_clasicos = True
            self._cerrar()
        elif elegido == 2:
            xbmc.executebuiltin('CopyToClipboard({0})'.format(entrada.rotulo))

    def onAction(self, action):
        aid = action.getId()
        if aid in (ACTION_MOVE_UP, ACTION_MOVE_DOWN) and self.getFocusId() == ID_AJUSTES:
            self._saltar_cabecera(-1 if aid == ACTION_MOVE_UP else 1)
            return
        if aid == ACTION_MOVE_RIGHT and self.getFocusId() == ID_CATEGORIAS:
            self.setFocusId(ID_AJUSTES)
            return
        if aid in (ACTION_MOVE_LEFT, ACTION_MOVE_RIGHT) and self.getFocusId() == ID_AJUSTES:
            self._flecha(-1 if aid == ACTION_MOVE_LEFT else 1)
            return
        if aid == ACTION_CONTEXT_MENU:
            self._menu_contextual()
            return
        if aid in _ATRAS:
            if self.getFocusId() == ID_AJUSTES:
                if self._modo_lista != 'categoria':
                    self._pintar_ajustes()
                else:
                    self.setFocusId(ID_CATEGORIAS)
            else:
                self._cerrar()

    def _cerrar(self):
        self._cerrado = True
        self.close()


def show(ganchos, cat=None, id_=None):
    inicio = time.monotonic()
    try:
        modelo = _construir_modelo(ganchos)
        ventana = ModoAjustes(_XML, _RUTA, 'Default', '1080i', modelo=modelo,
                              ganchos=ganchos, cat=cat, id_=id_, inicio=inicio)
    except Exception as e:
        xbmc.log('{0} no disponible: {1}'.format(_LOG, e), xbmc.LOGERROR)
        try:
            xbmcgui.Dialog().notification('Modo Ajustes', 'No disponible, abriendo ajustes clásicos')
        finally:
            xbmcaddon.Addon().openSettings()
        return
    try:
        import ui_utils
        ui_utils.visto('modo_ajustes')
    except OSError as e:
        xbmc.log('{0} punto de novedad: {1}'.format(_LOG, e), xbmc.LOGWARNING)
    pendiente = None
    clase_pendiente = ''
    abrir_clasicos = False
    try:
        ventana.doModal()
        pendiente = ventana._accion_pendiente
        clase_pendiente = getattr(ventana, '_clase_pendiente', '')
        abrir_clasicos = ventana._abrir_clasicos
    finally:
        ventana._cerrado = True
        del ventana
    if abrir_clasicos:
        xbmcaddon.Addon().openSettings()
    elif pendiente is not None:
        try:
            consulta = None
            # Solo los diálogos van en el mismo proceso, para reabrir cuando terminan; las
            # pantallas siguen con RunPlugin, que es como se probaron.
            if isinstance(pendiente, str) and clase_pendiente == 'dialogo':
                encontrado = re.match(
                    r'^RunPlugin\(plugin://plugin\.video\.espatv/\?(.+)\)$', pendiente)
                if encontrado:
                    consulta = encontrado.group(1)
            ejecutar = ganchos.get('ejecutar_accion')
            if consulta and callable(ejecutar):
                ejecutar(consulta)
            elif callable(pendiente):
                pendiente()
            elif isinstance(pendiente, str) and pendiente:
                xbmc.executebuiltin(pendiente)
        except Exception as e:
            xbmc.log('{0} la accion externa fallo: {1}'.format(_LOG, e), xbmc.LOGERROR)
        reabrir_si_procede(ganchos)
