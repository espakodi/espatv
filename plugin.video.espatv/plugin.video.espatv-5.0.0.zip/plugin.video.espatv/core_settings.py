# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
import base64
import os
import json
import re
import time

import xbmc
import xbmcaddon
import xbmcvfs

_ESPATV_TMDB_API_KEY = "273ffd2f428df3e0ef479eeb8d632541"

# Id explícito: el puente de YouTube importa este módulo desde plugin.video.youtube,
# y Addon() sin id devolvería el perfil y los ajustes de ese addon.
ADDON_ID = 'plugin.video.espatv'
_PROFILE_PATH = xbmcvfs.translatePath(xbmcaddon.Addon(ADDON_ID).getAddonInfo('profile'))
if not isinstance(_PROFILE_PATH, str) or not _PROFILE_PATH or _PROFILE_PATH.startswith("special://"): _PROFILE_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'tmp')
if _PROFILE_PATH and not os.path.exists(_PROFILE_PATH): os.makedirs(_PROFILE_PATH, exist_ok=True)

# Pool de claves TMDB propias del addon (base64). El usuario puede configurar la suya
# con máxima prioridad desde Ajustes > Opciones > Claves API.
_TMDB_KEY_POOL_B64: list = []
_TMDB_SETTINGS_FILE = os.path.join(_PROFILE_PATH, 'tmdb_settings.json')
_dead_tmdb_keys: set = set()

# Pool de claves MDbList propias del addon (base64). El usuario puede añadir las suyas.
_MDBLIST_KEY_POOL_B64: list = []
_dead_mdblist_keys: set = set()

_DEBUG_FILE = os.path.join(_PROFILE_PATH, 'debug_state.json')
_PRIORITY_FILE = os.path.join(_PROFILE_PATH, 'priority_state.json')
_RECENT_FILE = os.path.join(_PROFILE_PATH, 'recent_state.json')
_FAV_FILE = os.path.join(_PROFILE_PATH, 'favorites.json')
_DL_FILE = os.path.join(_PROFILE_PATH, 'downloads_history.json')
_DURATION_FILE = os.path.join(_PROFILE_PATH, 'min_duration.json')
_DM_SETTINGS_FILE = os.path.join(_PROFILE_PATH, 'dm_settings.json')
_ADVANCED_SEARCH_FILE = os.path.join(_PROFILE_PATH, 'advanced_search_state.json')
_TRAKT_SETTINGS_FILE   = os.path.join(_PROFILE_PATH, 'trakt_settings.json')
_MDBLIST_SETTINGS_FILE = os.path.join(_PROFILE_PATH, 'mdblist_settings.json')
_IPTV_CACHE_FILE = os.path.join(_PROFILE_PATH, 'iptv_cache_settings.json')
_IPTV_CACHE_DIR = os.path.join(_PROFILE_PATH, 'iptv_cache')
_FANART_FILE = os.path.join(_PROFILE_PATH, 'fanart_state.json')
_ICON_STATE_FILE = os.path.join(_PROFILE_PATH, 'icon_state.json')
_ICON_DEFAULT_BACKUP = os.path.join(_PROFILE_PATH, 'icon_default.png')
_ICON_CUSTOM_BACKUP = os.path.join(_PROFILE_PATH, 'custom_icon.png')
_WELCOME_FILE = os.path.join(_PROFILE_PATH, 'welcome_state.json')


def _load_json(path, default):
    if not os.path.exists(path):
        return default
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return default

def atomic_write_json(path, data, ensure_ascii=False, durable=False):
    """Escritura atómica de un JSON: escribe a un temporal en la misma carpeta y
    hace os.replace. Un corte a mitad (o Kodi cerrándose) no deja el fichero a medias.
    El temporal lleva el PID y un contador de nanosegundos para que dos escrituras a
    la vez (Kodi lanza varias invocaciones del plugin, o el Modo Cine en paralelo)
    no compartan nombre.

    `durable=True` añade `flush()` + `fsync()` antes del `os.replace`. **No es el valor por
    defecto a propósito.** Medido en el addon: pasa de 1,1 ms a 3,6 ms en un fichero pequeño
    (x3,2), y en disco lento —una tele con USB o SD— puede ser bastante más. Son 95 los sitios
    que escriben por aquí, y el historial de uso lo hace en **cada reproducción**: cargar 2,5 ms
    en cada una por un corte de luz sería absurdo.

    Lo que `fsync` protege es la caché de páginas del sistema: un cuelgue de Kodi no pierde nada
    (el sistema operativo vuelca igual), solo un corte de corriente o un reinicio duro. Por eso
    se pide **solo donde perder el fichero duele de verdad y se escribe poco**: el estado de
    fuentes (`mis_fuentes.json`, con tus servidores dentro) y la suscripción declarada.
    """
    tmp = "{0}.{1}.{2}.tmp".format(path, os.getpid(), time.time_ns())
    try:
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump(data, f, ensure_ascii=ensure_ascii)
            if durable:
                f.flush()
                os.fsync(f.fileno())
        # En Windows os.replace lanza PermissionError si un lector tiene el destino
        # abierto justo en ese instante (una lectura de caché coincidiendo con la
        # escritura). La ventana es de microsegundos; reintentar la salva sin perder
        # la escritura.
        for intento in range(3):
            try:
                os.replace(tmp, path)
                return True
            except PermissionError:
                if intento == 2:
                    raise
                time.sleep(0.05)
    except (OSError, ValueError, TypeError) as e:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except OSError:
            pass
        xbmc.log("[EspaTV] No se pudo guardar {0}: {1}".format(path, e), xbmc.LOGWARNING)
        return False


def _save_json(path, data):
    return atomic_write_json(path, data, ensure_ascii=False)

def _flag_get(path, key, default=False):
    return _load_json(path, {}).get(key, default)

def _flag_set(path, key, value):
    return _save_json(path, {key: value})


def is_debug_active():
    return _flag_get(_DEBUG_FILE, 'active', False)

def set_debug_active(state):
    _flag_set(_DEBUG_FILE, 'active', state)


def is_prioritize_match_active():
    return _flag_get(_PRIORITY_FILE, 'active', False)

def set_prioritize_match(state):
    _flag_set(_PRIORITY_FILE, 'active', state)


def is_recent_active():
    return _flag_get(_RECENT_FILE, 'active', False)

def set_recent_active(state):
    _flag_set(_RECENT_FILE, 'active', state)


def _fanart_set(key, value):
    data = _load_json(_FANART_FILE, {})
    data[key] = value
    _save_json(_FANART_FILE, data)

def get_custom_fanart():
    p = _flag_get(_FANART_FILE, 'path', '')
    if p and os.path.exists(p):
        return p
    return ''

def set_custom_fanart(path):
    _fanart_set('path', path)

def clear_custom_fanart():
    _fanart_set('path', '')

def is_fanart_disabled():
    return _flag_get(_FANART_FILE, 'disabled', True)

def set_fanart_disabled(state):
    _fanart_set('disabled', state)


def is_custom_icon_active():
    return bool(_flag_get(_ICON_STATE_FILE, 'active', False))


def get_icon_state():
    return _load_json(_ICON_STATE_FILE, {})


def set_icon_state(active, sha256=''):
    return _save_json(_ICON_STATE_FILE, {'active': bool(active), 'sha256': sha256 or ''})


def get_icon_default_backup_path():
    return _ICON_DEFAULT_BACKUP


def get_icon_custom_backup_path():
    return _ICON_CUSTOM_BACKUP


def welcome_last_version():
    return _flag_get(_WELCOME_FILE, 'version', '')

def set_welcome_shown(version):
    _flag_set(_WELCOME_FILE, 'version', version)


def get_favorites():
    """Devuelve solo entradas usables. Una entrada dañada (no es un dict, o le falta
    título, URL o acción) se descarta: si no, tumba la lista 'Mis Favoritos' entera."""
    raw = _load_json(_FAV_FILE, [])
    if not isinstance(raw, list):
        return []
    out = []
    for f in raw:
        if not (isinstance(f, dict) and f.get('title') and f.get('url') and f.get('action')):
            continue
        out.append({
            'title': f['title'],
            'url': f['url'],
            'icon': f.get('icon') or 'DefaultIconInfo.png',
            'platform': f.get('platform', ''),
            'action': f['action'],
            'params': f.get('params') if isinstance(f.get('params'), dict) else {},
        })
    return out

def add_favorite(title, url, icon, platform, action, params=None):
    favs = get_favorites()
    # Por URL también: quitar, renombrar y mover buscan por URL, así que dos entradas con
    # la misma (la misma peli guardada desde dos tops) se quitaban juntas.
    if any(f['url'] == url or (f['title'] == title and f['platform'] == platform) for f in favs):
        return False
    favs.append({
        "title": title, "url": url, "icon": icon,
        "platform": platform, "action": action, "params": params or {}
    })
    return _save_json(_FAV_FILE, favs)

def remove_favorite(url):
    favs = get_favorites()
    new_favs = [f for f in favs if f['url'] != url]
    if len(favs) == len(new_favs):
        return False
    return _save_json(_FAV_FILE, new_favs)

def rename_favorite(url, new_title):
    favs = get_favorites()
    for f in favs:
        if f['url'] == url:
            f['title'] = new_title
            return _save_json(_FAV_FILE, favs)
    return False

def move_favorite(url, direction):
    favs = get_favorites()
    index = next((i for i, f in enumerate(favs) if f['url'] == url), -1)
    if index == -1:
        return False
    if direction == "up" and index > 0:
        favs[index], favs[index - 1] = favs[index - 1], favs[index]
    elif direction == "down" and index < len(favs) - 1:
        favs[index], favs[index + 1] = favs[index + 1], favs[index]
    else:
        return False
    return _save_json(_FAV_FILE, favs)


def get_downloads():
    """Solo entradas usables, como get_favorites. El fichero se restaura tal cual desde un
    backup, y con otra forma reventaban la pantalla Descargas y el final de cada descarga."""
    raw = _load_json(_DL_FILE, [])
    if not isinstance(raw, list):
        return []
    return [dict(d, title=d.get('title') or os.path.basename(d['path']), date=d.get('date') or '')
            for d in raw if isinstance(d, dict) and isinstance(d.get('path'), str) and d['path']]

def log_download(title, path, vid):
    dls = get_downloads()
    dls.insert(0, {
        "title": title, "path": path, "vid": vid,
        "date": time.strftime("%d/%m/%Y %H:%M"),
    })
    _save_json(_DL_FILE, dls[:50])

def remove_download(path):
    dls = get_downloads()
    new_dls = [d for d in dls if d['path'] != path]
    _save_json(_DL_FILE, new_dls)


def _ajuste_leer(clave):
    """Valor de un ajuste nativo, o None si el addon no sabe leer ajustes (algún simulador de
    los tests). En Kodi real siempre se puede."""
    getter = getattr(xbmcaddon.Addon(ADDON_ID), 'getSetting', None)
    if getter is None:
        return None
    try:
        return getter(clave)
    except (RuntimeError, TypeError):
        return None

def _ajuste_escribir(clave, valor):
    setter = getattr(xbmcaddon.Addon(ADDON_ID), 'setSetting', None)
    if setter is None:
        return
    try:
        setter(clave, valor)
    except (RuntimeError, TypeError):
        pass


def get_min_duration():
    """Duración mínima de las búsquedas de DM, en minutos ("Ocultar clips cortos").

    Es un ajuste nativo (dm_min_duracion), así que el mismo valor lo ven la pestaña
    Dailymotion de los ajustes y el submenú Anti-Trailers de Opciones. Con un addon que
    todavía lo tenía en min_duration.json se migra una vez, al leerlo."""
    raw = _ajuste_leer('dm_min_duracion')
    nativo = None
    if raw is not None:
        try:
            nativo = max(0, int(float(raw)))
        except (ValueError, TypeError):
            nativo = None
    # Si el nativo ya trae un valor distinto del de fábrica (0), lo puso el usuario: manda él.
    if nativo:
        return nativo
    old = _load_json(_DURATION_FILE, {})
    # Ya se migró una vez: a partir de aquí manda el nativo (aunque sea 0), para que el usuario
    # pueda dejarlo en 0 sin que se le vuelva a poner el valor viejo del JSON.
    if old.get('migrado'):
        return nativo or 0
    # Nativo en su valor de fábrica (o ilegible): un valor en el JSON es del addon anterior y
    # se conserva (migración única).
    try:
        mins = max(0, min(int(old.get('minutes', 0) or 0), 30))
    except (ValueError, TypeError):
        mins = 0
    if raw is not None and mins != nativo:
        _ajuste_escribir('dm_min_duracion', str(mins))
        old['migrado'] = True
        atomic_write_json(_DURATION_FILE, old)
    return mins

def set_min_duration(minutes):
    try:
        minutes = max(0, int(minutes))
    except (ValueError, TypeError):
        minutes = 0
    _ajuste_escribir('dm_min_duracion', str(minutes))


_DM_CALIDADES = (360, 480, 720, 1080)
# Valor de fábrica de dm_max_quality: con él, un valor en dm_settings.json es del addon
# anterior y se migra; con otro, lo puso el usuario y manda él.
_DM_CALIDAD_DEFECTO = 1080

def _dm_calidad_de(v):
    # El ajuste nativo guarda la etiqueta elegida ("1080p"); sirve también un número suelto.
    try:
        return int(float(str(v).strip().lower().rstrip('p')))
    except (ValueError, TypeError):
        return 0

def get_dm_max_quality():
    """Calidad máxima de reproducción de Dailymotion. Ajuste nativo (dm_max_quality); con un
    addon que todavía lo tenía en dm_settings.json se migra una vez, al leerlo."""
    raw = _ajuste_leer('dm_max_quality')
    nativo = _dm_calidad_de(raw) if raw is not None else 0
    # Si el nativo ya es una calidad distinta de la de fábrica, la puso el usuario: manda ella.
    if nativo in _DM_CALIDADES and nativo != _DM_CALIDAD_DEFECTO:
        return nativo
    old = _load_json(_DM_SETTINGS_FILE, {})
    # Ya se migró una vez: manda el nativo, para que el usuario pueda volver a 1080p sin que se
    # le vuelva a poner la calidad vieja del JSON.
    if old.get('migrado'):
        return nativo if nativo in _DM_CALIDADES else _DM_CALIDAD_DEFECTO
    try:
        q = int(old.get('dm_max_quality', 0) or 0)
    except (ValueError, TypeError):
        q = 0
    if q not in _DM_CALIDADES:
        q = _DM_CALIDAD_DEFECTO
    if raw is not None and q != nativo:
        _ajuste_escribir('dm_max_quality', "{0}p".format(q))
        old['migrado'] = True
        atomic_write_json(_DM_SETTINGS_FILE, old)
    return q

def set_dm_max_quality(q):
    try:
        q = int(q)
    except (ValueError, TypeError):
        q = 1080
    if q not in _DM_CALIDADES:
        q = 1080
    _ajuste_escribir('dm_max_quality', "{0}p".format(q))


def is_advanced_search_active():
    return _flag_get(_ADVANCED_SEARCH_FILE, 'active', True)

def set_advanced_search_active(state):
    _flag_set(_ADVANCED_SEARCH_FILE, 'active', state)


_TRAKT_CLIENT_ID = "bS4meB1pF9rQhl_dGFF2z0llxa-0sIRiMEgh3gUSQUA"

# Listas públicas de Trakt preconfiguradas con contenido disponible.
# Se excluyen listas vacías en origen (ej. 4834057 y 3785062).
_DEFAULT_TRAKT_LIST_IDS = [
    "805405", "1282987", "2748259", "797798", "832943",
    "4737076", "9429302", "851495", "1558961",
    "6544049", "20579314", "11512456", "2142753",
    "2143363", "1211468", "11416887", "801239", "6652041",
    "20770365", "1326415", "1076107", "20492899", "20770267",
    "20772087", "21583416"
]

def get_trakt_settings():
    return _load_json(_TRAKT_SETTINGS_FILE, {"api_key": "", "lists": []})

def save_trakt_settings(data):
    _save_json(_TRAKT_SETTINGS_FILE, data)

def get_trakt_api_key():
    return get_trakt_settings().get("api_key", "") or _TRAKT_CLIENT_ID

def set_trakt_api_key(key):
    data = get_trakt_settings()
    data["api_key"] = key
    save_trakt_settings(data)

def get_trakt_lists():
    return get_trakt_settings().get("lists", [])

def add_trakt_list(list_id, name, user, item_count=0):
    data = get_trakt_settings()
    lists = data.get("lists", [])
    for l in lists:
        if l['id'] == list_id:
            l['name'] = name
            l['user'] = user
            l['item_count'] = item_count
            save_trakt_settings(data)
            return
    lists.append({"id": list_id, "name": name, "user": user, "item_count": item_count})
    data["lists"] = lists
    save_trakt_settings(data)

def remove_trakt_list(list_id):
    data = get_trakt_settings()
    lists = data.get("lists", [])
    if list_id in _DEFAULT_TRAKT_LIST_IDS:
        removed = data.get("removed_defaults", [])
        if list_id not in removed:
            removed.append(list_id)
        data["removed_defaults"] = removed
    data["lists"] = [l for l in lists if l['id'] != list_id]
    save_trakt_settings(data)

def seed_default_trakt_lists(api_key=''):
    data = get_trakt_settings()
    lists = data.get("lists", [])
    removed_defaults = set(data.get("removed_defaults", []))
    existing_ids = {l['id'] for l in lists}
    new_ids = [lid for lid in _DEFAULT_TRAKT_LIST_IDS if lid not in existing_ids and lid not in removed_defaults]
    if not new_ids:
        return
    names = {lid: "Lista Trakt #{0}".format(lid) for lid in new_ids}
    if api_key:
        try:
            import requests as _req
            from concurrent.futures import ThreadPoolExecutor
            headers = {'trakt-api-key': api_key, 'trakt-api-version': '2', 'Content-Type': 'application/json'}
            def fetch_name(lid):
                try:
                    r = _req.get('https://api.trakt.tv/lists/{0}'.format(lid),
                                 headers=headers, timeout=5)
                    if r.status_code == 200:
                        return lid, r.json().get('name', names[lid])
                except (_req.RequestException, ValueError):
                    pass
                return lid, names[lid]
            with ThreadPoolExecutor(max_workers=8) as ex:
                for lid, name in ex.map(fetch_name, new_ids):
                    names[lid] = name
        except (ImportError, RuntimeError):
            pass
    for lid in new_ids:
        lists.append({"id": lid, "name": names[lid], "user": "official", "item_count": 0})
    data["lists"] = lists
    save_trakt_settings(data)


def _decode_pool(pool_b64):
    decoded = []
    for k in pool_b64:
        try:
            decoded.append(base64.b64decode(k).decode('utf-8'))
        except (ValueError, UnicodeDecodeError):
            pass
    return decoded


def get_tmdb_api_key():
    """Devuelve clave activa: usuario > pool (saltando dead). Fallback a legacy."""
    user_key = _load_json(_TMDB_SETTINGS_FILE, {}).get('api_key', '').strip()
    if user_key:
        return user_key
    pool = _decode_pool(_TMDB_KEY_POOL_B64)
    alive = [k for k in pool if k not in _dead_tmdb_keys]
    if not alive and pool:
        _dead_tmdb_keys.clear()
        alive = pool
    return alive[0] if alive else _ESPATV_TMDB_API_KEY

def mark_tmdb_key_dead(key):
    _dead_tmdb_keys.add(key)

def sin_clave(texto):
    """El texto sin el valor de `api_key=` (también codificado, `api_key%3D`). Los errores de
    requests repiten la URL con su query, que en TMDB lleva la clave, y puede ser la del
    usuario, y kodi.log es lo que se adjunta al pedir ayuda. Solo tapa la forma de query."""
    return re.sub(r'(api_key(?:=|%3[Dd]))[^&%\s\'"]+', r'\1***', str(texto))

def get_tmdb_user_key():
    return _load_json(_TMDB_SETTINGS_FILE, {}).get('api_key', '').strip()

def set_tmdb_user_key(key):
    _save_json(_TMDB_SETTINGS_FILE, {'api_key': key.strip()})


def get_mdblist_user_keys():
    """Solo las claves configuradas por el usuario (sin pool). Para gestión de UI."""
    data = _load_json(_MDBLIST_SETTINGS_FILE, {})
    if 'api_keys' in data:
        return [k for k in data['api_keys'] if k and isinstance(k, str)]
    legacy = data.get('api_key', '').strip()
    return [legacy] if legacy else []


def get_mdblist_api_keys():
    """Claves de usuario primero, luego pool, saltando las marcadas dead. Migra formato legacy."""
    user_keys = get_mdblist_user_keys()
    pool = _decode_pool(_MDBLIST_KEY_POOL_B64)
    all_keys = user_keys + [k for k in pool if k not in user_keys]
    alive = [k for k in all_keys if k not in _dead_mdblist_keys]
    if not alive and all_keys:
        _dead_mdblist_keys.clear()
        alive = all_keys
    return alive

def get_mdblist_api_key():
    keys = get_mdblist_api_keys()
    return keys[0] if keys else ''

def set_mdblist_api_keys(keys):
    _save_json(_MDBLIST_SETTINGS_FILE,
               {'api_keys': [k.strip() for k in keys if k and k.strip()]})

def set_mdblist_api_key(key):
    set_mdblist_api_keys([key])

def add_mdblist_api_key(key):
    key = key.strip()
    if not key:
        return
    data = _load_json(_MDBLIST_SETTINGS_FILE, {})
    existing = data.get('api_keys') or ([data['api_key']] if data.get('api_key') else [])
    if key not in existing:
        existing.append(key)
    _save_json(_MDBLIST_SETTINGS_FILE, {'api_keys': existing})

def remove_mdblist_api_key(key):
    data = _load_json(_MDBLIST_SETTINGS_FILE, {})
    keys = data.get('api_keys') or ([data['api_key']] if data.get('api_key') else [])
    _save_json(_MDBLIST_SETTINGS_FILE, {'api_keys': [k for k in keys if k != key]})

def mark_mdblist_key_dead(key):
    _dead_mdblist_keys.add(key)


_MAL_SETTINGS_FILE = os.path.join(_PROFILE_PATH, 'mal_settings.json')

def get_mal_client_id():
    return _load_json(_MAL_SETTINGS_FILE, {}).get('client_id', '')

def set_mal_client_id(key):
    _save_json(_MAL_SETTINGS_FILE, {'client_id': key.strip()})


# TTL en segundos: 0 desactivado, 3600=1h, 43200=12h, 86400=1d, 604800=1sem
_IPTV_CACHE_TTL_OPTIONS = [
    (0, "Desactivada"),
    (3600, "1 hora"),
    (43200, "12 horas"),
    (86400, "1 día"),
    (604800, "1 semana"),
]

def _load_iptv_cache_cfg():
    return _load_json(_IPTV_CACHE_FILE, {"active": None, "ttl": 0})

def _save_iptv_cache_cfg(cfg):
    _save_json(_IPTV_CACHE_FILE, cfg)

def remember_list_position():
    # Opción "Recordar posición en las listas": cuando está activa, las listas que
    # normalmente no se cachean pasan a cacheToDisc=True para que Kodi conserve la
    # posición al volver con ATRÁS. Independiente de la caché IPTV.
    return xbmcaddon.Addon(ADDON_ID).getSetting('remember_list_position') == 'true'


def is_iptv_cache_active():
    return _load_iptv_cache_cfg().get("active") is True

def set_iptv_cache_active(state):
    cfg = _load_iptv_cache_cfg()
    cfg["active"] = state
    if state and cfg.get("ttl", 0) == 0:
        cfg["ttl"] = 43200
    elif not state:
        clear_iptv_cache_files()
    _save_iptv_cache_cfg(cfg)

def get_iptv_cache_ttl(default_ttl=0):
    cfg = _load_iptv_cache_cfg()
    if cfg.get("active") is False:
        return 0
    return cfg.get("ttl", 0) if cfg.get("active") is True else (default_ttl if default_ttl > 0 else 0)

def set_iptv_cache_ttl(ttl_seconds):
    cfg = _load_iptv_cache_cfg()
    cfg["ttl"] = ttl_seconds
    if ttl_seconds > 0:
        cfg["active"] = True
    _save_iptv_cache_cfg(cfg)

def reset_iptv_cache_defaults():
    _save_iptv_cache_cfg({"active": False, "ttl": 0})
    clear_iptv_cache_files()

def clear_iptv_cache_files():
    if not os.path.exists(_IPTV_CACHE_DIR):
        return
    for name in os.listdir(_IPTV_CACHE_DIR):
        try:
            os.remove(os.path.join(_IPTV_CACHE_DIR, name))
        except OSError:
            continue

def get_iptv_cache_dir():
    if not os.path.exists(_IPTV_CACHE_DIR):
        os.makedirs(_IPTV_CACHE_DIR, exist_ok=True)
    return _IPTV_CACHE_DIR


_ESPADAILY_INTEGRATION_FILE = os.path.join(_PROFILE_PATH, 'espadaily_integration_state.json')

def is_espadaily_integration_enabled():
    return _flag_get(_ESPADAILY_INTEGRATION_FILE, 'active', False)

def set_espadaily_integration_enabled(state):
    _flag_set(_ESPADAILY_INTEGRATION_FILE, 'active', bool(state))


_TOPZILLA_INTEGRATION_FILE = os.path.join(_PROFILE_PATH, 'topzilla_integration_state.json')

def is_topzilla_integration_enabled():
    return _flag_get(_TOPZILLA_INTEGRATION_FILE, 'active', False)

def set_topzilla_integration_enabled(state):
    _flag_set(_TOPZILLA_INTEGRATION_FILE, 'active', bool(state))


_TMDBHELPER_PLAYER_FILE = os.path.join(_PROFILE_PATH, 'tmdbhelper_player_state.json')

def is_tmdbhelper_player_enabled():
    return _flag_get(_TMDBHELPER_PLAYER_FILE, 'active', True)

def set_tmdbhelper_player_enabled(state):
    _flag_set(_TMDBHELPER_PLAYER_FILE, 'active', bool(state))


_FLIX_LAZY_FILE = os.path.join(_PROFILE_PATH, 'flix_lazy_state.json')

def is_flix_lazy_enabled():
    return _flag_get(_FLIX_LAZY_FILE, 'active', False)

def set_flix_lazy_enabled(state):
    _flag_set(_FLIX_LAZY_FILE, 'active', bool(state))


_FLIX_REMEMBER_POS_FILE = os.path.join(_PROFILE_PATH, 'flix_remember_pos_state.json')

def is_flix_remember_pos_enabled():
    return _flag_get(_FLIX_REMEMBER_POS_FILE, 'active', True)

def set_flix_remember_pos_enabled(state):
    _flag_set(_FLIX_REMEMBER_POS_FILE, 'active', bool(state))


_SEARCH_SHORTCUTS_FILE = os.path.join(_PROFILE_PATH, 'search_shortcuts.json')
_SEARCH_SHORTCUTS_ORDER_FILE = os.path.join(_PROFILE_PATH, 'search_shortcuts_order.json')


def load_search_shortcuts():
    data = _load_json(_SEARCH_SHORTCUTS_FILE, [])
    if not isinstance(data, list):
        return []
    out = []
    for item in data:
        if not isinstance(item, dict):
            continue
        cmd = item.get('command')
        if not isinstance(cmd, str) or not cmd.strip():
            continue
        out.append({
            'name':     (item.get('name') or cmd[:40]).strip(),
            'icon':     item.get('icon') if isinstance(item.get('icon'), str) else '',
            'command':  cmd.strip(),
            'addon_id': item.get('addon_id') if isinstance(item.get('addon_id'), str) else '',
        })
    return out

def save_search_shortcuts(shortcuts):
    return _save_json(_SEARCH_SHORTCUTS_FILE, shortcuts)

def load_search_shortcuts_order():
    data = _load_json(_SEARCH_SHORTCUTS_ORDER_FILE, [])
    return [x for x in data if isinstance(x, str)] if isinstance(data, list) else []

def save_search_shortcuts_order(order):
    return _save_json(_SEARCH_SHORTCUTS_ORDER_FILE, list(order))

def reset_search_shortcuts_order():
    return _save_json(_SEARCH_SHORTCUTS_ORDER_FILE, [])


_MENU_LAYOUT_FILE = os.path.join(_PROFILE_PATH, 'menu_layout.json')


def load_menu_layout():
    data = _load_json(_MENU_LAYOUT_FILE, {'main': [], 'catalog': [], 'hidden': []})
    if not isinstance(data, dict):
        return {'main': [], 'catalog': [], 'hidden': []}
    main = data.get('main') if isinstance(data.get('main'), list) else []
    catalog = data.get('catalog') if isinstance(data.get('catalog'), list) else []
    hidden = data.get('hidden') if isinstance(data.get('hidden'), list) else []
    return {
        'main': [k for k in main if isinstance(k, str)],
        'catalog': [k for k in catalog if isinstance(k, str)],
        'hidden': [k for k in hidden if isinstance(k, str)],
    }

def save_menu_layout(layout):
    # Escritura atómica: un proceso que lea a la vez (otra navegación del addon)
    # ve el archivo viejo completo o el nuevo completo, nunca uno truncado.
    if isinstance(layout, dict) and 'hidden' not in layout:
        prev = load_menu_layout()
        layout = dict(layout)
        layout['hidden'] = prev.get('hidden', [])
    return _save_json(_MENU_LAYOUT_FILE, layout)

def reset_menu_layout():
    if os.path.exists(_MENU_LAYOUT_FILE):
        try:
            os.remove(_MENU_LAYOUT_FILE)
        except OSError:
            return False
    return True


_SEARCH_DIALOG_LAYOUT_FILE = os.path.join(_PROFILE_PATH, 'search_dialog_layout.json')


def load_search_dialog_layout():
    data = _load_json(_SEARCH_DIALOG_LAYOUT_FILE, {'order': [], 'hidden': []})
    if not isinstance(data, dict):
        return {'order': [], 'hidden': []}
    order = data.get('order') if isinstance(data.get('order'), list) else []
    hidden = data.get('hidden') if isinstance(data.get('hidden'), list) else []
    return {
        'order': [k for k in order if isinstance(k, str)],
        'hidden': [k for k in hidden if isinstance(k, str)],
    }

def save_search_dialog_layout(layout):
    return _save_json(_SEARCH_DIALOG_LAYOUT_FILE, layout)

def reset_search_dialog_layout():
    if os.path.exists(_SEARCH_DIALOG_LAYOUT_FILE):
        try:
            os.remove(_SEARCH_DIALOG_LAYOUT_FILE)
        except OSError:
            return False
    return True


_FLIX_ROWS_FILE = os.path.join(_PROFILE_PATH, 'flix_rows_config.json')


def load_flix_rows(mode):
    """Lista de ids de filas activas del Modo Cine para 'movie'/'show', o None si el
    usuario no ha configurado nada (el llamador usa los defaults)."""
    data = _load_json(_FLIX_ROWS_FILE, {})
    if not isinstance(data, dict):
        return None
    v = data.get(mode)
    if not isinstance(v, list):
        return None
    return [x for x in v if isinstance(x, str)]

def save_flix_rows(mode, ids):
    # Escritura atómica, fusionando con el otro modo ya guardado.
    data = _load_json(_FLIX_ROWS_FILE, {})
    if not isinstance(data, dict):
        data = {}
    data[mode] = [x for x in ids if isinstance(x, str)]
    return _save_json(_FLIX_ROWS_FILE, data)

def reset_flix_rows():
    if os.path.exists(_FLIX_ROWS_FILE):
        try:
            os.remove(_FLIX_ROWS_FILE)
        except OSError:
            return False
    return True


# ── Favoritos de películas/series del Modo Cine ──
# Lista propia del usuario, separada de los Favoritos nativos de Kodi. Se guarda el
# registro normalizado completo para repintar la fila "Mis Favoritos" sin red.
_MOVIE_FAV_FILE = os.path.join(_PROFILE_PATH, 'movie_favorites.json')
_MOVIE_FAV_FIELDS = ('title', 'year', 'poster', 'fanart', 'rating', 'genre',
                     'director', 'cast_str', 'plot', 'runtime', 'imdb_id',
                     'tmdb_id', 'media_type')


def _fav_key(m):
    return str(m.get('tmdb_id') or m.get('imdb_id') or m.get('title') or '').strip()


def _same_movie(a, b):
    """Dos registros son la misma peli si comparten un id fuerte (tmdb_id o imdb_id,
    ambos presentes); a falta de id común, por título. Así un favorito guardado sin
    tmdb_id se sigue reconociendo cuando el item ya viene enriquecido con tmdb_id (y al
    revés), evitando duplicados y el 'no puedo quitarlo'. Límite asumido: dos títulos
    homónimos sin ningún id se tratan como el mismo (caso raro)."""
    at, bt = str(a.get('tmdb_id') or ''), str(b.get('tmdb_id') or '')
    if at and bt:
        return at == bt
    ai, bi = str(a.get('imdb_id') or ''), str(b.get('imdb_id') or '')
    if ai and bi:
        return ai == bi
    ta = str(a.get('title') or '').strip().lower()
    return bool(ta) and ta == str(b.get('title') or '').strip().lower()


def _movie_fav_record(m):
    # rating/runtime se normalizan a número: llegan como string (properties de pelis_flix)
    # o ya numéricos (pelis_grid). Unificar evita un rating no-numérico que reventaría al
    # repintar la fila.
    rec = {k: m.get(k, '') for k in _MOVIE_FAV_FIELDS}
    try:
        rec['rating'] = float(rec['rating'] or 0)
    except (TypeError, ValueError):
        rec['rating'] = 0.0
    try:
        rec['runtime'] = int(rec['runtime'] or 0)
    except (TypeError, ValueError):
        rec['runtime'] = 0
    return rec


def get_movie_favorites(media_type='movie'):
    data = _load_json(_MOVIE_FAV_FILE, {})
    if not isinstance(data, dict):
        return []
    lst = data.get('show' if media_type in ('show', 'tv') else 'movie')
    return lst if isinstance(lst, list) else []


def get_movie_favorites_map():
    """Lee movie_favorites.json una sola vez y devuelve {'movie': [...], 'show': [...]}."""
    data = _load_json(_MOVIE_FAV_FILE, {})
    if not isinstance(data, dict):
        return {'movie': [], 'show': []}
    movies = data.get('movie')
    shows = data.get('show')
    return {
        'movie': movies if isinstance(movies, list) else [],
        'show': shows if isinstance(shows, list) else [],
    }


def is_movie_favorited_in(m, fav_cache, media_type='movie'):
    """Comprueba si `m` está en una lista o mapa precargado de favoritos."""
    if not _fav_key(m):
        return False
    if isinstance(fav_cache, dict):
        bucket = 'show' if media_type in ('show', 'tv') else 'movie'
        lst = fav_cache.get(bucket, [])
    else:
        lst = fav_cache or []
    return any(_same_movie(f, m) for f in lst)


def is_movie_favorited(m, media_type='movie'):
    return is_movie_favorited_in(m, get_movie_favorites(media_type), media_type)


def _write_movie_favs(data):
    return _save_json(_MOVIE_FAV_FILE, data)


def toggle_movie_favorite(m, media_type='movie'):
    """Añade o quita la película de Películas y series favoritas. Devuelve True si quedó añadida,
    False si quedó quitada (o si no se pudo identificar/guardar)."""
    if not _fav_key(m):
        return False
    bucket = 'show' if media_type in ('show', 'tv') else 'movie'
    data = _load_json(_MOVIE_FAV_FILE, {})
    if not isinstance(data, dict):
        data = {}
    lst = data.get(bucket)
    if not isinstance(lst, list):
        lst = []
    was = any(_same_movie(f, m) for f in lst)
    if was:
        lst = [f for f in lst if not _same_movie(f, m)]
    else:
        lst = [_movie_fav_record(m)] + lst  # los nuevos arriba
    data[bucket] = lst
    if not _write_movie_favs(data):
        return was  # guardado falló: el estado sigue como estaba
    return not was


def remove_movie_favorite(m, media_type='movie'):
    """Quita la película de Películas y series favoritas. Devuelve True si se quitó algo."""
    bucket = 'show' if media_type in ('show', 'tv') else 'movie'
    data = _load_json(_MOVIE_FAV_FILE, {})
    if not isinstance(data, dict):
        return False
    lst = data.get(bucket)
    if not isinstance(lst, list):
        return False
    new = [f for f in lst if not _same_movie(f, m)]
    if len(new) == len(lst):
        return False
    data[bucket] = new
    return _write_movie_favs(data)


def update_movie_favorite_meta(m, media_type='movie'):
    """Actualiza en sitio la ficha de un favorito ya existente (sin re-añadirlo si fue borrado)."""
    if not _fav_key(m):
        return False
    bucket = 'show' if media_type in ('show', 'tv') else 'movie'
    data = _load_json(_MOVIE_FAV_FILE, {})
    if not isinstance(data, dict):
        return False
    lst = data.get(bucket)
    if not isinstance(lst, list):
        return False
    updated = False
    new_rec = _movie_fav_record(m)
    out = []
    for f in lst:
        if not updated and _same_movie(f, m):
            merged = dict(f)
            for k, v in new_rec.items():
                if v and (not merged.get(k) or merged.get(k) in (0, 0.0, '')):
                    merged[k] = v
            out.append(_movie_fav_record(merged))
            updated = True
        else:
            out.append(f)
    if not updated:
        return False
    data[bucket] = out
    return _write_movie_favs(data)


def movie_fav_context_items(title, media_type='movie', tmdb_id='', imdb_id='',
                            year='', poster='', rating='', genre='',
                            favs_cache=None, addon_url=None, skip_enrich=False):
    """Devuelve las tuplas de menú contextual para añadir/quitar de
    «Películas y series favoritas» (y añadir a favoritos de Kodi)."""
    title = str(title or '').strip()
    if not title:
        return []
    import sys
    import urllib.parse
    mt = 'show' if media_type in ('show', 'tv') else 'movie'
    probe = {
        'title': title,
        'tmdb_id': str(tmdb_id or '').strip(),
        'imdb_id': str(imdb_id or '').strip(),
    }
    if favs_cache is None:
        in_fav = is_movie_favorited(probe, mt)
    else:
        in_fav = is_movie_favorited_in(probe, favs_cache, mt)
    fav_label = (
        "Quitar de Películas y series favoritas"
        if in_fav else
        "Añadir a Películas y series favoritas"
    )
    base = addon_url or (sys.argv[0] if getattr(sys, 'argv', None) and sys.argv[0] else 'plugin://plugin.video.espatv/')
    fav_params = {'action': 'toggle_movie_fav', 'title': title, 'mode': mt}
    for k, v in (('tmdb_id', tmdb_id), ('imdb_id', imdb_id), ('year', year),
                 ('poster', poster), ('rating', rating), ('genre', genre)):
        s = str(v or '').strip()
        if s:
            fav_params[k] = s
    if skip_enrich:
        fav_params['skip_enrich'] = '1'
    kodi_params = {'action': 'add_kodi_movie_fav', 'title': title, 'mode': mt}
    if probe['tmdb_id']:
        kodi_params['tmdb_id'] = probe['tmdb_id']
    if str(poster or '').strip():
        kodi_params['poster'] = str(poster).strip()
    return [
        (fav_label, "RunPlugin({0}?{1})".format(base, urllib.parse.urlencode(fav_params))),
        ("Añadir a favoritos de Kodi", "RunPlugin({0}?{1})".format(base, urllib.parse.urlencode(kodi_params))),
    ]


# ── Comportamiento del tráiler del Modo Cine ──
_YOUTUBE_TIP_FILE = os.path.join(_PROFILE_PATH, 'youtube_tip.json')


def youtube_tip_shown():
    data = _load_json(_YOUTUBE_TIP_FILE, {})
    return isinstance(data, dict) and data.get('shown') is True

def set_youtube_tip_shown():
    return _flag_set(_YOUTUBE_TIP_FILE, 'shown', True)


_TRAILER_CFG_FILE = os.path.join(_PROFILE_PATH, 'trailer_config.json')
_TRAILER_DEFAULTS = {'enabled': False, 'hide_busy': False, 'hover_s': 8, 'lang': 'es-ES', 'engine': 'auto'}
TRAILER_LANGS = ('en-US', 'es-ES')
TRAILER_ENGINES = ('auto', 'native', 'addon')


def load_trailer_config():
    """Config del tráiler: {'enabled': bool, 'hide_busy': bool, 'hover_s': int, 'lang': str}.
    hover_s = segundos sobre un item antes de reproducir; lang = idioma del tráiler."""
    data = _load_json(_TRAILER_CFG_FILE, {})
    if not isinstance(data, dict):
        data = {}
    cfg = dict(_TRAILER_DEFAULTS)
    if isinstance(data.get('enabled'), bool):
        cfg['enabled'] = data['enabled']
    if isinstance(data.get('hide_busy'), bool):
        cfg['hide_busy'] = data['hide_busy']
    if isinstance(data.get('hover_s'), int) and 2 <= data['hover_s'] <= 30:
        cfg['hover_s'] = data['hover_s']
    if data.get('lang') in TRAILER_LANGS:
        cfg['lang'] = data['lang']
    if data.get('engine') in TRAILER_ENGINES:
        cfg['engine'] = data['engine']
    return cfg


def save_trailer_config(cfg):
    hover = cfg.get('hover_s')
    if not (isinstance(hover, int) and 2 <= hover <= 30):
        hover = _TRAILER_DEFAULTS['hover_s']
    return _save_json(_TRAILER_CFG_FILE, {
        'enabled': bool(cfg.get('enabled')),
        'hide_busy': bool(cfg.get('hide_busy')),
        'hover_s': hover,
        'lang': cfg.get('lang') if cfg.get('lang') in TRAILER_LANGS else _TRAILER_DEFAULTS['lang'],
        'engine': cfg.get('engine') if cfg.get('engine') in TRAILER_ENGINES else _TRAILER_DEFAULTS['engine'],
    })


def get_search_input_sel(titulo):
    """Devuelve 0 (teclado), 1 (móvil/PC) o 2 (control remoto completo) según el ajuste, o muestra el
    diálogo si está en 'Preguntar siempre'.

    'search_input_default' es un labelenum: Kodi guarda el texto del label, no el índice. El orden
    del diálogo es el de los números devueltos, así que las opciones nuevas van siempre al final.
    """
    import xbmcgui
    pref = (xbmcaddon.Addon(ADDON_ID).getSetting('search_input_default') or '').strip()
    if pref == 'Teclado':
        return 0
    if pref == 'Desde móvil/PC':
        return 1
    if pref == 'Control remoto completo':
        return 2
    return xbmcgui.Dialog().select(titulo, ["Teclado", "Desde móvil/PC", "Control remoto completo"])


def get_yt_player_mode():
    val = _ajuste_leer("yt_player_mode")
    if val is not None and str(val).strip():
        try:
            return int(val)
        except (ValueError, TypeError):
            pass
    try:
        import yt_storage
        return int(yt_storage.get_settings().get("player_mode", 0))
    except Exception:
        return 0


def set_yt_player_mode(mode):
    try:
        mode_int = int(mode)
    except (ValueError, TypeError):
        mode_int = 0
    _ajuste_escribir("yt_player_mode", str(mode_int))
    try:
        import yt_storage
        yt_storage.set_setting("player_mode", mode_int)
    except Exception:
        pass


def is_modo_ligero_active():
    val = _ajuste_leer("modo_ligero_sin_lag")
    if val is None:
        return False
    if isinstance(val, bool):
        return val
    return str(val).strip().lower() in ("true", "1", "yes")


def set_modo_ligero_active(state):
    _ajuste_escribir("modo_ligero_sin_lag", "true" if state else "false")
