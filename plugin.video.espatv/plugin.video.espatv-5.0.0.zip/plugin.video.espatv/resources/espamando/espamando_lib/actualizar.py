# -*- coding: utf-8 -*-
# EspaMando - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: GPL-2.0-or-later. Consulta el archivo LICENSE.
"""Actualización automática de service.espamando al arrancar Kodi.

Cada addon anfitrión incluye una plantilla en resources/espamando. Si hay una versión
más reciente que la instalada, el propio servicio se actualiza antes de levantar el
servidor para evitar que dos procesos paren y sustituyan el servidor a la vez.

No depende de Kodi: recibe la carpeta de addons y devuelve lo que ha hecho.
"""
import os
import re
import shutil
import time

MODULO = 'service.espamando'
ANFITRIONES = ('plugin.video.espatv', 'plugin.video.espadaily', 'plugin.video.atresdaily')
_CERROJO_CADUCA = 120


def version(addon_xml):
    try:
        with open(addon_xml, 'r', encoding='utf-8') as f:
            cabecera = f.read(2048)
    except OSError:
        return ()
    m = re.search(r'<addon\b[^>]*\bversion="([0-9.]+)"', cabecera)
    return tuple(int(x) for x in m.group(1).split('.') if x.isdigit()) if m else ()


def plantilla_mas_nueva(addons):
    """Carpeta de la plantilla más nueva entre los anfitriones, si supera a la instalada."""
    mejor, mejor_version = None, version(os.path.join(addons, MODULO, 'addon.xml'))
    for anfitrion in ANFITRIONES:
        carpeta = os.path.join(addons, anfitrion, 'resources', 'espamando')
        v = version(os.path.join(carpeta, 'addon.xml'))
        if v and v > mejor_version:
            mejor, mejor_version = carpeta, v
    return mejor


def coger_cerrojo(ruta, intentos=50, espera=0.1):
    """Cerrojo entre procesos con un fichero. El mismo que usa el cliente de los anfitriones."""
    for _ in range(intentos):
        try:
            fd = os.open(ruta, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, str(time.time()).encode('ascii'))
            os.close(fd)
            return True
        except FileExistsError:
            try:
                if time.time() - os.path.getmtime(ruta) > _CERROJO_CADUCA:
                    os.remove(ruta)
                    continue
            except OSError:
                pass
            time.sleep(espera)
        except OSError:
            return False
    return False


def soltar_cerrojo(ruta):
    try:
        os.remove(ruta)
    except OSError:
        pass


def _borrar_trabajo(addons):
    shutil.rmtree(os.path.join(addons, MODULO + '.trabajo'), ignore_errors=True)


def reemplazar(addons, origen):
    """Pone la plantilla `origen` en addons/service.espamando. Si algo falla, deja la de antes.

    Primero se copia entera a una carpeta de trabajo sin addon.xml en la raíz (Kodi no la carga) y
    luego se intercambian las carpetas. True si quedó la nueva.
    """
    cerrojo = os.path.join(addons, '.' + MODULO + '.lock')
    if not coger_cerrojo(cerrojo):
        return False
    destino = os.path.join(addons, MODULO)
    trabajo = os.path.join(addons, MODULO + '.trabajo')
    try:
        # Con el cerrojo cogido se vuelve a mirar: otro proceso puede haberlo actualizado ya
        if version(os.path.join(origen, 'addon.xml')) <= version(os.path.join(destino, 'addon.xml')):
            return False
        _borrar_trabajo(addons)
        nuevo = os.path.join(trabajo, 'nuevo', MODULO)
        shutil.copytree(origen, nuevo, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
        viejo = os.path.join(trabajo, 'viejo')
        movido = False
        try:
            if os.path.isdir(destino):
                shutil.move(destino, viejo)
                movido = True
            shutil.move(nuevo, destino)
        except OSError:
            if movido and not os.path.isdir(destino):
                shutil.move(viejo, destino)
            raise
        return True
    except OSError:
        return False
    finally:
        _borrar_trabajo(addons)
        soltar_cerrojo(cerrojo)
