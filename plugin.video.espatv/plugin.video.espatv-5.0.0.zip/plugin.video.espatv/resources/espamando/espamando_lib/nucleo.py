# -*- coding: utf-8 -*-
# EspaMando - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: GPL-2.0-or-later. Consulta el archivo LICENSE.
"""Lógica de EspaMando sin dependencias de Kodi: móviles vinculados, vinculación y validaciones."""
import hashlib
import hmac
import json
import os
import secrets
import threading
import time

PUERTO_INICIO = 8110
PUERTOS = 10
MAX_MOVILES = 10
MAX_CUERPO = 4096
MAX_TEXTO = 500
VINCULO_TTL = 300
PIN_FALLOS_MAX = 5
PIN_VENTANA = 60
COOKIE = 'espamando'

# Lo único que el móvil puede pedir. Cada clave corresponde a una llamada concreta en kodi.py;
# nunca se pasa a Kodi un nombre de acción que venga del móvil.
ACCIONES = frozenset({
    'arriba', 'abajo', 'izquierda', 'derecha', 'ok', 'atras', 'inicio', 'menu', 'info', 'osd',
    'vol_mas', 'vol_menos', 'silencio',
    'play_pausa', 'stop', 'adelante', 'atrasar',
    'subtitulos', 'sub_siguiente', 'audio_siguiente',
})


def hash_token(token):
    return hashlib.sha256(token.encode('utf-8')).hexdigest()


class Almacen:
    """Móviles vinculados en un JSON. Solo guarda el hash de cada token.

    Un único proceso escribe (el servidor). La escritura es atómica: fichero temporal, replace y
    relectura. Un fichero corrupto se trata como vacío: obliga a volver a vincular, pero no rompe.
    """

    def __init__(self, ruta):
        self.ruta = ruta
        self._lock = threading.Lock()
        self._moviles = self._leer()

    def _leer(self):
        try:
            with open(self.ruta, 'r', encoding='utf-8') as f:
                datos = json.load(f)
            moviles = datos.get('moviles') if isinstance(datos, dict) else None
            if isinstance(moviles, list):
                return [m for m in moviles if isinstance(m, dict) and isinstance(m.get('h'), str)]
        except (OSError, ValueError):
            pass
        return []

    def _guardar(self):
        carpeta = os.path.dirname(self.ruta)
        if carpeta:
            os.makedirs(carpeta, exist_ok=True)
        tmp = self.ruta + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump({'moviles': self._moviles}, f)
        os.replace(tmp, self.ruta)

    def cuantos(self):
        with self._lock:
            return len(self._moviles)

    def anadir(self, nombre=''):
        """Crea un token nuevo, guarda su hash y devuelve el token (solo existe en la cookie)."""
        token = secrets.token_urlsafe(32)
        with self._lock:
            self._moviles.append({'h': hash_token(token), 'n': str(nombre)[:60], 't': int(time.time())})
            # Si se pasa del máximo sale el más antiguo
            self._moviles = self._moviles[-MAX_MOVILES:]
            self._guardar()
        return token

    def valido(self, token):
        if not token or not isinstance(token, str) or len(token) > 200:
            return False
        h = hash_token(token)
        with self._lock:
            return any(hmac.compare_digest(h, m['h']) for m in self._moviles)

    def olvidar_todos(self):
        with self._lock:
            self._moviles = []
            self._guardar()


class Vinculacion:
    """Una vinculación en curso: un token de un solo uso (va en el QR) y un PIN de 6 cifras.

    Solo vale mientras la ventana de la tele está abierta, como mucho VINCULO_TTL segundos. El PIN
    admite PIN_FALLOS_MAX fallos por minuto; con eso, adivinarlo en 5 minutos es imposible.
    """

    def __init__(self, reloj=time.time):
        self._reloj = reloj
        self._lock = threading.Lock()
        self._token = None
        self._pin = None
        self._caduca = 0.0
        self._fallos = []

    def empezar(self):
        with self._lock:
            self._token = secrets.token_urlsafe(24)
            self._pin = '{0:06d}'.format(secrets.randbelow(1000000))
            self._caduca = self._reloj() + VINCULO_TTL
            self._fallos = []
            return self._token, self._pin

    def cancelar(self):
        with self._lock:
            self._token = self._pin = None
            self._caduca = 0.0

    def activa(self):
        with self._lock:
            return self._activa()

    def _activa(self):
        return self._token is not None and self._reloj() < self._caduca

    def canjear_token(self, token):
        """True si el token es el de esta vinculación. Se gasta al usarlo."""
        with self._lock:
            if not self._activa() or not isinstance(token, str):
                return False
            if hmac.compare_digest(token, self._token):
                self._token = self._pin = None
                return True
            return False

    def canjear_pin(self, pin):
        """'ok', 'mal' o 'bloqueado'. El PIN también se gasta al acertarlo."""
        with self._lock:
            ahora = self._reloj()
            self._fallos = [t for t in self._fallos if ahora - t < PIN_VENTANA]
            if len(self._fallos) >= PIN_FALLOS_MAX:
                return 'bloqueado'
            if not self._activa() or not isinstance(pin, str):
                return 'mal'
            if hmac.compare_digest(pin.strip(), self._pin):
                self._token = self._pin = None
                return 'ok'
            self._fallos.append(ahora)
            return 'mal'


def host_permitido(host, ip_local, puerto):
    """Solo se atiende si la cabecera Host es la IP con la que ha llegado la conexión, o localhost.

    Frena el DNS rebinding: una web ajena que apunte su dominio a la IP de la tele manda su propio
    dominio en Host. Se compara con la IP del socket, así que sigue valiendo si el router cambia
    la IP de la tele.
    """
    if not host:
        return False
    validos = {
        '{0}:{1}'.format(ip_local, puerto),
        'localhost:{0}'.format(puerto),
        '127.0.0.1:{0}'.format(puerto),
    }
    return host.strip().lower() in validos


def ordenar_ips(ips):
    """IPs locales de la tele, de la más probable para el móvil a la menos.

    Con una VPN activa, la ruta por defecto (y la IP que da Kodi) es la del túnel, casi siempre
    10.x, a la que el móvil de casa no llega. Las redes de casa suelen ser 192.168.x; dentro de
    ellas, una que acaba en .1 suele ser un adaptador virtual (VirtualBox, Hyper-V), no la tele.
    """
    def clave(ip):
        partes = ip.split('.')
        if partes[0] == '192' and partes[1] == '168':
            rango = 0
        elif partes[0] == '172' and 16 <= int(partes[1]) <= 31:
            rango = 1
        elif partes[0] == '10':
            rango = 2
        else:
            rango = 3
        return (rango, partes[3] == '1')

    validas = []
    for ip in ips:
        partes = (ip or '').split('.')
        if len(partes) != 4 or not all(p.isdigit() and int(p) < 256 for p in partes):
            continue
        if partes[0] in ('127', '0') or ip.startswith('169.254.') or ip in validas:
            continue
        validas.append(ip)
    return sorted(validas, key=clave)


def limpiar_texto(texto):
    """Texto de una línea, sin caracteres de control, como mucho MAX_TEXTO caracteres."""
    if not isinstance(texto, str):
        return ''
    limpio = ''.join(c if c.isprintable() else ' ' for c in texto)
    return ' '.join(limpio.split())[:MAX_TEXTO]


def token_de_cookie(cabecera):
    if not cabecera:
        return ''
    for trozo in cabecera.split(';'):
        nombre, _, valor = trozo.strip().partition('=')
        if nombre == COOKIE:
            return valor
    return ''


def cookie_set(token):
    return '{0}={1}; Path=/; Max-Age=31536000; HttpOnly; SameSite=Strict'.format(COOKIE, token)
