# -*- coding: utf-8 -*-
# EspaMando - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: GPL-2.0-or-later. Consulta el archivo LICENSE.
"""Lo que el mando hace en Kodi: acciones de la lista blanca, escribir en el teclado y estado."""
import json
import os
import secrets
import socket
import time

import xbmc
import xbmcgui

# Cerrojo entre procesos para no mezclar dos textos en el mismo teclado. Se respeta también el de
# LoioLink (solo se lee): si el usuario escribe a la vez en los dos paneles, uno espera al otro.
_CERROJO = 'espamando.teclado.ocupado'
_CERROJO_LOIOLINK = 'loiolink.keyboard_input.busy'
_CERROJO_CADUCA = 30


def _log(msg, nivel=xbmc.LOGINFO):
    xbmc.log('[EspaMando] {0}'.format(msg), nivel)


def rpc(metodo, params=None):
    peticion = {'jsonrpc': '2.0', 'id': 1, 'method': metodo}
    if params is not None:
        peticion['params'] = params
    try:
        respuesta = json.loads(xbmc.executeJSONRPC(json.dumps(peticion)))
    except (ValueError, TypeError, RuntimeError):
        return None, 'respuesta ilegible'
    if not isinstance(respuesta, dict):
        return None, 'respuesta ilegible'
    if 'error' in respuesta:
        return None, str(respuesta['error'])
    return respuesta.get('result'), None


def _reproductor():
    activos, _ = rpc('Player.GetActivePlayers')
    if isinstance(activos, list) and activos:
        return activos[0].get('playerid')
    return None


def _con_reproductor(metodo, **params):
    pid = _reproductor()
    if pid is None:
        return False
    params['playerid'] = pid
    _, err = rpc(metodo, params)
    return err is None


def _saltar(segundos):
    pid = _reproductor()
    if pid is None:
        return False
    _, err = rpc('Player.Seek', {'playerid': pid, 'value': {'seconds': segundos}})
    if err is None:
        return True
    # Si esta versión de Kodi no admite el salto en segundos, se usa el paso pequeño del usuario
    paso = 'smallforward' if segundos > 0 else 'smallbackward'
    _, err = rpc('Player.Seek', {'playerid': pid, 'value': {'step': paso}})
    return err is None


def _alternar_subtitulos():
    pid = _reproductor()
    if pid is None:
        return False
    props, _ = rpc('Player.GetProperties', {'playerid': pid, 'properties': ['subtitleenabled']})
    activo = bool(props and props.get('subtitleenabled'))
    _, err = rpc('Player.SetSubtitle', {'playerid': pid, 'subtitle': 'off' if activo else 'on'})
    return err is None


_SIMPLES = {
    'arriba': 'Input.Up', 'abajo': 'Input.Down', 'izquierda': 'Input.Left',
    'derecha': 'Input.Right', 'ok': 'Input.Select', 'atras': 'Input.Back',
    'inicio': 'Input.Home', 'menu': 'Input.ContextMenu', 'info': 'Input.Info',
    'osd': 'Input.ShowOSD',
}


def ejecutar(accion):
    """Ejecuta una acción de nucleo.ACCIONES. True si Kodi la aceptó."""
    if accion in _SIMPLES:
        return rpc(_SIMPLES[accion])[1] is None
    if accion == 'vol_mas':
        return rpc('Application.SetVolume', {'volume': 'increment'})[1] is None
    if accion == 'vol_menos':
        return rpc('Application.SetVolume', {'volume': 'decrement'})[1] is None
    if accion == 'silencio':
        return rpc('Application.SetMute', {'mute': 'toggle'})[1] is None
    if accion == 'play_pausa':
        return _con_reproductor('Player.PlayPause')
    if accion == 'stop':
        return _con_reproductor('Player.Stop')
    if accion == 'adelante':
        return _saltar(30)
    if accion == 'atrasar':
        return _saltar(-10)
    if accion == 'subtitulos':
        return _alternar_subtitulos()
    if accion == 'sub_siguiente':
        return _con_reproductor('Player.SetSubtitle', subtitle='next')
    if accion == 'audio_siguiente':
        return _con_reproductor('Player.SetAudioStream', stream='next')
    return False


def _teclado_abierto():
    return xbmc.getCondVisibility('Window.IsActive(virtualkeyboard)')


def _vigente(marca, ahora):
    """True si la marca de tiempo de un cerrojo es de hace menos de _CERROJO_CADUCA segundos.
    Un cerrojo que dejó un proceso caído caduca solo y no bloquea para siempre."""
    try:
        return ahora - float(marca) < _CERROJO_CADUCA
    except ValueError:
        return False


def _coger_cerrojo(ventana, mio, espera_max):
    fin = time.time() + espera_max
    while time.time() < fin:
        ahora = time.time()
        ajeno = _vigente(ventana.getProperty(_CERROJO_LOIOLINK).split(':')[0], ahora)
        actual = ventana.getProperty(_CERROJO)
        libre = not _vigente(actual.split('|')[0], ahora)
        if libre and not ajeno:
            ventana.setProperty(_CERROJO, '{0}|{1}'.format(ahora, mio))
            xbmc.sleep(50)
            # Reclamo y relectura: si otro proceso escribió a la vez, gana el último y el otro espera
            if ventana.getProperty(_CERROJO).endswith('|' + mio):
                return True
        xbmc.sleep(100)
    return False


def escribir(texto, espera_teclado=1.5):
    """Escribe en el teclado de Kodi que esté abierto y lo confirma.

    'ok', 'sin_teclado' u 'ocupado'. Espera a que el teclado aparezca (el móvil puede ir más rápido
    que la tele), deja 500 ms y que se cierre el aviso de «cargando»: en Android, un texto que
    llega nada más abrirse el teclado se pierde (fallo de Kodi #20297).
    """
    fin = time.time() + espera_teclado
    while not _teclado_abierto():
        if time.time() >= fin:
            return 'sin_teclado'
        xbmc.sleep(100)
    ventana = xbmcgui.Window(10000)
    mio = secrets.token_hex(6)
    if not _coger_cerrojo(ventana, mio, 5):
        return 'ocupado'
    try:
        xbmc.sleep(500)
        fin_ocupado = time.time() + 3
        while xbmc.getCondVisibility('Window.IsActive(busydialog)') and time.time() < fin_ocupado:
            xbmc.sleep(100)
        if not _teclado_abierto():
            return 'sin_teclado'
        _, err = rpc('Input.SendText', {'text': texto, 'done': True})
        return 'ok' if err is None else 'sin_teclado'
    finally:
        if ventana.getProperty(_CERROJO).endswith('|' + mio):
            ventana.clearProperty(_CERROJO)


def estado():
    """Qué se está reproduciendo, para la página del móvil. {} si nada."""
    pid = _reproductor()
    if pid is None:
        return {}
    item, _ = rpc('Player.GetItem', {'playerid': pid, 'properties': ['title', 'showtitle']})
    props, _ = rpc('Player.GetProperties', {'playerid': pid,
                                            'properties': ['time', 'totaltime', 'speed']})
    titulo = ''
    if isinstance(item, dict):
        it = item.get('item') or {}
        titulo = it.get('title') or it.get('label') or ''
        if it.get('showtitle'):
            titulo = '{0} · {1}'.format(it['showtitle'], titulo)

    def seg(t):
        if not isinstance(t, dict):
            return 0
        return int(t.get('hours', 0)) * 3600 + int(t.get('minutes', 0)) * 60 + int(t.get('seconds', 0))

    props = props if isinstance(props, dict) else {}
    return {'titulo': str(titulo)[:120], 'pos': seg(props.get('time')),
            'total': seg(props.get('totaltime')), 'pausa': props.get('speed') == 0}


def ips_locales():
    """Todas las IPs locales candidatas, ordenadas con nucleo.ordenar_ips."""
    from espamando_lib import nucleo
    candidatas = []
    try:
        candidatas.append(xbmc.getIPAddress())
    except (AttributeError, RuntimeError):
        pass
    try:
        s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        try:
            s.settimeout(0)
            s.connect(('8.8.8.8', 80))
            candidatas.append(s.getsockname()[0])
        finally:
            s.close()
    except OSError:
        pass
    try:
        # En Windows y Linux da las de todas las interfaces; en Android a veces solo la local
        for info in socket.getaddrinfo(socket.gethostname(), None, socket.AF_INET):
            candidatas.append(info[4][0])
    except (OSError, UnicodeError):
        pass
    return nucleo.ordenar_ips(candidatas)


def ip_local():
    ips = ips_locales()
    return ips[0] if ips else ''


def crear_qr(texto, carpeta):
    """PNG del QR con nombre único (Kodi guarda las imágenes en caché por ruta). '' si falla."""
    try:
        from espamando_lib import segno
        os.makedirs(carpeta, exist_ok=True)
        for viejo in os.listdir(carpeta):
            if viejo.startswith('espamando_qr_') and viejo.endswith('.png'):
                try:
                    os.remove(os.path.join(carpeta, viejo))
                except OSError:
                    pass
        ruta = os.path.join(carpeta, 'espamando_qr_{0}.png'.format(secrets.token_hex(6)))
        segno.make(texto, error='m').save(ruta, scale=10, border=4)
        return ruta
    except Exception as e:  # el QR es opcional: la ventana enseña dirección y PIN sin él
        _log('No se pudo crear el QR: {0}'.format(e), xbmc.LOGWARNING)
        return ''
