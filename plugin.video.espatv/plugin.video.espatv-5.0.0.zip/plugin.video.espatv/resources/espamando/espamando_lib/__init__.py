# EspaMando: lógica del mando (nucleo), acceso a Kodi (kodi), servidor HTTP (web) y página del móvil.
