# -*- coding: utf-8 -*-
# EspaMando - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: GPL-2.0-or-later. Consulta el archivo LICENSE.
"""Página del móvil. Va en un .py y no en un .html porque el empaquetado de los addons
anfitriones solo copia ciertas extensiones al zip."""

PAGINA = r'''<!DOCTYPE html>
<html lang="es">
<head>
<meta charset="utf-8">
<meta name="viewport" content="width=device-width, initial-scale=1, viewport-fit=cover">
<meta name="theme-color" content="#0d1117">
<title>Loiolink Remote</title>
<style>
:root{--fondo:#0d1117;--panel:#161b22;--borde:#30363d;--texto:#e6edf3;--suave:#8b949e;--acento:#2f81f7;--ok:#3fb950;--mal:#f85149}
*{box-sizing:border-box;margin:0;padding:0;-webkit-tap-highlight-color:transparent}
html,body{background:var(--fondo);color:var(--texto);font:16px/1.4 -apple-system,BlinkMacSystemFont,"Segoe UI",Roboto,sans-serif}
body{padding:max(12px,env(safe-area-inset-top)) 16px max(16px,env(safe-area-inset-bottom));max-width:480px;margin:0 auto;user-select:none;-webkit-user-select:none}
[hidden]{display:none!important}
header{display:flex;align-items:center;justify-content:space-between;margin-bottom:12px}
h1{font-size:1.1em;font-weight:600}
#conexion{font-size:.8em;color:var(--suave)}
#conexion::before{content:"";display:inline-block;width:8px;height:8px;border-radius:50%;background:var(--suave);margin-right:6px;vertical-align:middle}
#conexion.on::before{background:var(--ok)}#conexion.off::before{background:var(--mal)}
.tarjeta{background:var(--panel);border:1px solid var(--borde);border-radius:14px;padding:14px;margin-bottom:12px}
.fila{display:flex;gap:8px}
input{flex:1;min-width:0;background:var(--fondo);color:var(--texto);border:1px solid var(--borde);border-radius:10px;padding:12px;font-size:1em;user-select:text;-webkit-user-select:text}
input:focus{outline:2px solid var(--acento);border-color:transparent}
button{background:#21262d;color:var(--texto);border:1px solid var(--borde);border-radius:12px;font-size:1em;min-height:52px;touch-action:manipulation;cursor:pointer}
button:active,button.pulsado{background:var(--acento);border-color:var(--acento)}
.primario{background:var(--acento);border-color:var(--acento);padding:0 18px;font-weight:600}
#aviso,#aviso-pin{min-height:1.4em;font-size:.85em;color:var(--suave);margin-top:8px}
#aviso.mal,#aviso-pin.mal{color:var(--mal)}#aviso.ok{color:var(--ok)}
.cruceta{display:grid;grid-template-columns:repeat(3,1fr);gap:8px;max-width:300px;margin:0 auto}
.cruceta button{min-height:72px;font-size:1.5em}
.cruceta .ok{border-radius:50%;font-size:1em;font-weight:700}
.botones{display:flex;flex-wrap:wrap;justify-content:center;gap:8px;margin-top:10px}
.botones button{font-size:.9em;flex:0 0 calc((100% - 16px) / 3)}
#reproduce{font-size:.9em}
#titulo{white-space:nowrap;overflow:hidden;text-overflow:ellipsis;margin-bottom:6px}
.barra{height:4px;background:var(--borde);border-radius:2px;overflow:hidden}
#progreso{height:100%;width:0;background:var(--acento)}
#tiempo{font-size:.8em;color:var(--suave);margin-top:4px}
.pin{font-size:1.6em;letter-spacing:.4em;text-align:center}
p.pie{text-align:center;font-size:.85em;color:var(--suave);margin:18px 0 6px}
p.pie a{color:var(--acento)}
p.ayuda{color:var(--suave);font-size:.9em;margin-bottom:10px}
</style>
</head>
<body>
<header><h1>Loiolink Remote</h1><span id="conexion">Conectando…</span></header>

<section id="vincular" hidden>
  <div class="tarjeta">
    <p class="ayuda">En la tele, abre <b>Vincular un móvil</b> y escanea el QR, o escribe aquí el PIN que aparece.</p>
    <form id="form-pin" class="fila">
      <input id="pin" class="pin" inputmode="numeric" autocomplete="one-time-code" maxlength="6" placeholder="······" aria-label="PIN de la tele">
      <button class="primario" type="submit">Vincular</button>
    </form>
    <div id="aviso-pin"></div>
  </div>
</section>

<section id="mando" hidden>
  <div class="tarjeta">
    <form id="form-texto" class="fila">
      <input id="texto" maxlength="500" placeholder="Escribe la búsqueda" autocomplete="off" enterkeyhint="send" aria-label="Texto para la tele">
      <button class="primario" type="submit">Enviar</button>
    </form>
    <div id="aviso"></div>
  </div>

  <div class="tarjeta" id="reproduce" hidden>
    <div id="titulo"></div>
    <div class="barra"><div id="progreso"></div></div>
    <div id="tiempo"></div>
  </div>

  <div class="tarjeta">
    <div class="cruceta">
      <button data-a="menu" aria-label="Menú">☰</button>
      <button data-a="arriba" data-repetir aria-label="Arriba">▲</button>
      <button data-a="info" aria-label="Información">ⓘ</button>
      <button data-a="izquierda" data-repetir aria-label="Izquierda">◀</button>
      <button data-a="ok" class="ok" aria-label="Aceptar">OK</button>
      <button data-a="derecha" data-repetir aria-label="Derecha">▶</button>
      <button data-a="atras" aria-label="Atrás">↩</button>
      <button data-a="abajo" data-repetir aria-label="Abajo">▼</button>
      <button data-a="inicio" aria-label="Inicio">⌂</button>
    </div>
    <div class="botones">
      <button data-a="atrasar">−10 s</button>
      <button data-a="play_pausa">⏯</button>
      <button data-a="adelante">+30 s</button>
      <button data-a="vol_menos" data-repetir>Vol −</button>
      <button data-a="silencio">Silencio</button>
      <button data-a="vol_mas" data-repetir>Vol +</button>
      <button data-a="subtitulos">Subtítulos</button>
      <button data-a="sub_siguiente">Otro sub.</button>
      <button data-a="audio_siguiente">Otro audio</button>
      <button data-a="osd">Menú vídeo</button>
      <button data-a="stop">Parar</button>
    </div>
  </div>
</section>

<p class="pie">Loiolink es un sistema más completo: <a href="https://loiolo.io" target="_blank" rel="noopener noreferrer">loiolo.io</a></p>

<script>
(function(){
  'use strict';
  var $ = function(id){ return document.getElementById(id); };
  var ultimoToque = Date.now();
  var sondeo = null;

  function pedir(metodo, ruta, datos){
    var op = {method: metodo, credentials: 'same-origin', headers: {'X-EspaTV': '1'}};
    if (datos !== undefined){
      op.headers['Content-Type'] = 'application/json';
      op.body = JSON.stringify(datos);
    }
    return fetch(ruta, op).then(function(r){
      conexion(true);
      return r.json().catch(function(){ return {}; }).then(function(j){ return {s: r.status, j: j}; });
    }, function(e){ conexion(false); throw e; });
  }

  function conexion(on){
    var c = $('conexion');
    c.className = on ? 'on' : 'off';
    c.textContent = on ? 'Conectado' : 'Sin conexión con la tele';
  }

  function aviso(el, texto, tipo){
    el.textContent = texto;
    el.className = tipo || '';
  }

  function vibrar(){ if (navigator.vibrate) { try { navigator.vibrate(15); } catch (e) {} } }

  function mostrar(vinculado){
    $('vincular').hidden = vinculado;
    $('mando').hidden = !vinculado;
    if (vinculado) { arrancarSondeo(); } else { pararSondeo(); }
  }

  // --- vinculación ---
  function vincularCon(datos){
    return pedir('POST', '/vincular', datos).then(function(r){
      if (r.s === 200) { mostrar(true); return true; }
      if (r.s === 429) aviso($('aviso-pin'), 'Demasiados intentos. Espera un minuto.', 'mal');
      else aviso($('aviso-pin'), datos.v ? 'El QR ha caducado. Vuelve a abrir «Vincular un móvil» en la tele.' : 'PIN incorrecto o caducado.', 'mal');
      mostrar(false);
      return false;
    });
  }

  $('form-pin').addEventListener('submit', function(ev){
    ev.preventDefault();
    var pin = $('pin').value.replace(/\D/g, '');
    if (pin.length !== 6) { aviso($('aviso-pin'), 'El PIN tiene 6 cifras.', 'mal'); return; }
    vincularCon({pin: pin}).catch(function(){});
  });

  // --- texto ---
  $('form-texto').addEventListener('submit', function(ev){
    ev.preventDefault();
    var t = $('texto').value.trim();
    if (!t) return;
    aviso($('aviso'), 'Enviando…');
    pedir('POST', '/texto', {t: t}).then(function(r){
      if (r.s === 200) { $('texto').value = ''; aviso($('aviso'), 'Escrito en la tele.', 'ok'); vibrar(); }
      else if (r.s === 401) mostrar(false);
      else if (r.j && r.j.r === 'ocupado') aviso($('aviso'), 'La tele está recibiendo otro texto. Prueba otra vez.', 'mal');
      else aviso($('aviso'), 'No hay ningún teclado abierto en la tele. Abre un buscador y vuelve a enviar.', 'mal');
    }).catch(function(){ aviso($('aviso'), 'No se pudo enviar.', 'mal'); });
  });

  // --- botones ---
  function accion(a){
    ultimoToque = Date.now();
    pedir('POST', '/accion', {a: a}).then(function(r){ if (r.s === 401) mostrar(false); }).catch(function(){});
  }

  Array.prototype.forEach.call(document.querySelectorAll('button[data-a]'), function(b){
    var retardo = null, repite = null;
    function parar(){
      clearTimeout(retardo); clearInterval(repite); retardo = repite = null;
      b.classList.remove('pulsado');
    }
    b.addEventListener('pointerdown', function(ev){
      ev.preventDefault();
      parar();
      b.classList.add('pulsado');
      vibrar();
      accion(b.dataset.a);
      if (b.hasAttribute('data-repetir')) {
        retardo = setTimeout(function(){ repite = setInterval(function(){ accion(b.dataset.a); }, 150); }, 400);
      }
    });
    ['pointerup', 'pointercancel', 'pointerleave'].forEach(function(t){ b.addEventListener(t, parar); });
    document.addEventListener('visibilitychange', parar);
    b.addEventListener('contextmenu', function(ev){ ev.preventDefault(); });
  });

  // --- estado de reproducción ---
  function hms(s){
    s = Math.max(0, s|0);
    var h = Math.floor(s / 3600), m = Math.floor(s % 3600 / 60), x = s % 60;
    return (h ? h + ':' + (m < 10 ? '0' : '') : '') + m + ':' + (x < 10 ? '0' : '') + x;
  }

  function consultar(){
    if (document.hidden || Date.now() - ultimoToque > 600000) return;
    pedir('GET', '/estado').then(function(r){
      if (r.s === 401) { mostrar(false); return; }
      var e = r.j || {};
      var hay = !!e.titulo || e.total > 0;
      $('reproduce').hidden = !hay;
      if (hay) {
        $('titulo').textContent = (e.pausa ? '⏸ ' : '▶ ') + (e.titulo || 'Reproduciendo');
        $('progreso').style.width = e.total ? Math.min(100, 100 * e.pos / e.total) + '%' : '0';
        $('tiempo').textContent = hms(e.pos) + (e.total ? ' / ' + hms(e.total) : '');
      }
    }).catch(function(){});
  }

  function arrancarSondeo(){ if (!sondeo) { consultar(); sondeo = setInterval(consultar, 2000); } }
  function pararSondeo(){ clearInterval(sondeo); sondeo = null; }

  document.addEventListener('visibilitychange', function(){ if (!document.hidden) { ultimoToque = Date.now(); consultar(); } });
  document.addEventListener('pointerdown', function(){ ultimoToque = Date.now(); }, true);

  // --- inicio ---
  var m = /^#v=([\w-]{10,100})$/.exec(location.hash);
  if (m) {
    // El código del QR se canjea una vez y se borra de la barra de direcciones
    history.replaceState(null, '', '/');
    vincularCon({v: m[1]}).catch(function(){ mostrar(false); });
  } else {
    pedir('GET', '/estado').then(function(r){ mostrar(r.s !== 401); }).catch(function(){ mostrar(false); });
  }
})();
</script>
</body>
</html>
'''
