# -*- coding: utf-8 -*-
# EspaMando - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: GPL-2.0-or-later. Consulta el archivo LICENSE.
"""Servidor HTTP del mando.

Dos clases de cliente:
- el móvil vinculado (cookie + cabecera X-EspaTV), que manda acciones y texto;
- el addon anfitrión en la propia tele (solo desde 127.0.0.1, con la clave que el servidor publica
  en una propiedad de Kodi), que pide vincular, olvidar o parar.

No depende de Kodi: lo que toca Kodi llega como funciones al crear el servidor, para poder
probarlo sin Kodi.
"""
import hmac
import json
import os
import queue
import threading
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer

from espamando_lib import nucleo
from espamando_lib.pagina import PAGINA

_CSP = ("default-src 'none'; script-src 'unsafe-inline'; style-src 'unsafe-inline'; "
        "connect-src 'self'; img-src 'self' data:; base-uri 'none'; frame-ancestors 'none'; "
        "form-action 'none'")


class Servidor(ThreadingHTTPServer):
    daemon_threads = True
    # En Windows SO_REUSEADDR deja abrir un puerto que ya usa otro programa sin dar error
    allow_reuse_address = os.name != 'nt'

    def __init__(self, direccion, almacen, clave_admin, carpeta_qr, kodi):
        """kodi: objeto con ejecutar(accion), escribir(texto), estado(), ip_local() y
        crear_qr(texto, carpeta)."""
        super().__init__(direccion, _Manejador)
        self.puerto = self.server_address[1]
        self.almacen = almacen
        self.vinculacion = nucleo.Vinculacion()
        self.clave_admin = clave_admin
        self.carpeta_qr = carpeta_qr
        self.kodi = kodi
        self.parar = threading.Event()
        # Las acciones se ejecutan de una en una y en orden de llegada. Si cada petición las
        # ejecutara en su hilo, dos pulsaciones rápidas podrían llegar a Kodi al revés. La cola es
        # corta para que mantener pulsado no acumule retraso.
        self.cola = queue.Queue(maxsize=20)
        self.pagina = PAGINA.encode('utf-8')

    def trabajar(self):
        while not self.parar.is_set():
            try:
                accion = self.cola.get(timeout=0.5)
            except queue.Empty:
                continue
            try:
                self.kodi.ejecutar(accion)
            except Exception:  # una acción fallida no puede tumbar el hilo del mando
                pass


class _Manejador(BaseHTTPRequestHandler):
    timeout = 10
    server_version = 'EspaMando'
    sys_version = ''

    def log_message(self, *args):
        pass

    # --- respuestas ---

    def _cabeceras_comunes(self):
        self.send_header('X-Frame-Options', 'DENY')
        self.send_header('X-Content-Type-Options', 'nosniff')
        self.send_header('Referrer-Policy', 'no-referrer')

    def _json(self, codigo, datos, extra=None):
        cuerpo = json.dumps(datos).encode('utf-8')
        self.send_response(codigo)
        self.send_header('Content-Type', 'application/json')
        self.send_header('Content-Length', str(len(cuerpo)))
        self.send_header('Cache-Control', 'no-store')
        self._cabeceras_comunes()
        for nombre, valor in (extra or []):
            self.send_header(nombre, valor)
        self.end_headers()
        self.wfile.write(cuerpo)

    def _vacio(self, codigo):
        self.send_response(codigo)
        self.send_header('Content-Length', '0')
        self._cabeceras_comunes()
        self.end_headers()

    # --- comprobaciones ---

    def _host_ok(self):
        ip_local = self.connection.getsockname()[0]
        return nucleo.host_permitido(self.headers.get('Host'), ip_local, self.server.puerto)

    def _movil_ok(self):
        if self.headers.get('X-EspaTV') != '1':
            return False
        token = nucleo.token_de_cookie(self.headers.get('Cookie'))
        return self.server.almacen.valido(token)

    def _admin_ok(self):
        if self.client_address[0] != '127.0.0.1':
            return False
        clave = self.headers.get('X-Admin') or ''
        return bool(clave) and hmac.compare_digest(clave, self.server.clave_admin)

    def _leer_json(self):
        tipo = (self.headers.get('Content-Type') or '').split(';')[0].strip().lower()
        if tipo != 'application/json':
            return None
        try:
            largo = int(self.headers.get('Content-Length') or 0)
        except ValueError:
            return None
        if largo < 0 or largo > nucleo.MAX_CUERPO:
            return None
        try:
            datos = json.loads(self.rfile.read(largo).decode('utf-8') or '{}')
        except (ValueError, UnicodeDecodeError):
            return None
        return datos if isinstance(datos, dict) else None

    # --- rutas ---

    def do_OPTIONS(self):
        # Sin permisos CORS: una web ajena no puede mandar la cabecera X-EspaTV
        self._vacio(405)

    def do_GET(self):
        if not self._host_ok():
            return self._vacio(403)
        ruta = self.path.split('?', 1)[0]
        if ruta == '/':
            self.send_response(200)
            self.send_header('Content-Type', 'text/html; charset=utf-8')
            self.send_header('Content-Length', str(len(self.server.pagina)))
            self.send_header('Cache-Control', 'no-cache')
            self.send_header('Content-Security-Policy', _CSP)
            self._cabeceras_comunes()
            self.end_headers()
            self.wfile.write(self.server.pagina)
        elif ruta == '/estado':
            if not self._movil_ok():
                return self._json(401, {'error': 'sin_vincular'})
            self._json(200, self.server.kodi.estado())
        elif ruta in ('/admin/ping', '/admin/estado'):
            if not self._admin_ok():
                return self._vacio(403)
            ip = self.server.kodi.ip_local()
            self._json(200, {'moviles': self.server.almacen.cuantos(),
                             'vinculando': self.server.vinculacion.activa(),
                             'url': 'http://{0}:{1}'.format(ip, self.server.puerto) if ip else ''})
        else:
            self._vacio(404)

    def do_POST(self):
        if not self._host_ok():
            return self._vacio(403)
        ruta = self.path.split('?', 1)[0]
        datos = self._leer_json()
        if datos is None:
            return self._json(400, {'error': 'peticion'})
        if ruta.startswith('/admin/'):
            if not self._admin_ok():
                return self._vacio(403)
            return self._admin(ruta, datos)
        if ruta == '/vincular':
            return self._vincular(datos)
        if self.headers.get('X-EspaTV') != '1':
            return self._vacio(403)
        if not self._movil_ok():
            return self._json(401, {'error': 'sin_vincular'})
        if ruta == '/accion':
            accion = datos.get('a')
            if accion not in nucleo.ACCIONES:
                return self._json(400, {'error': 'accion'})
            try:
                self.server.cola.put_nowait(accion)
            except queue.Full:
                return self._json(429, {'error': 'lleno'})
            return self._json(202, {'ok': True})
        if ruta == '/texto':
            texto = nucleo.limpiar_texto(datos.get('t'))
            if not texto:
                return self._json(400, {'error': 'vacio'})
            resultado = self.server.kodi.escribir(texto)
            return self._json(200 if resultado == 'ok' else 409, {'r': resultado})
        self._vacio(404)

    def _vincular(self, datos):
        if self.headers.get('X-EspaTV') != '1':
            return self._vacio(403)
        vinc = self.server.vinculacion
        if 'v' in datos:
            ok = vinc.canjear_token(datos.get('v'))
        else:
            resultado = vinc.canjear_pin(str(datos.get('pin') or ''))
            if resultado == 'bloqueado':
                return self._json(429, {'error': 'bloqueado'})
            ok = resultado == 'ok'
        if not ok:
            return self._json(403, {'error': 'codigo'})
        agente = self.headers.get('User-Agent') or ''
        token = self.server.almacen.anadir(nombre=agente)
        self._json(200, {'ok': True}, extra=[('Set-Cookie', nucleo.cookie_set(token))])

    def _admin(self, ruta, datos):
        srv = self.server
        if ruta == '/admin/vincular':
            ips = srv.kodi.ips_locales()
            if not ips:
                return self._json(200, {'error': 'sin_red'})
            token, pin = srv.vinculacion.empezar()
            urls = ['http://{0}:{1}'.format(ip, srv.puerto) for ip in ips]
            # El token va en el fragmento (#): el navegador no lo manda al servidor ni lo deja
            # en el Referer; la página lo lee y lo canjea.
            completa = '{0}/#v={1}'.format(urls[0], token)
            return self._json(200, {'url': urls[0], 'otras': urls[1:3], 'pin': pin,
                                    'qr': srv.kodi.crear_qr(completa, srv.carpeta_qr),
                                    'moviles': srv.almacen.cuantos()})
        if ruta == '/admin/cancelar':
            srv.vinculacion.cancelar()
            return self._json(200, {'ok': True})
        if ruta == '/admin/olvidar':
            srv.almacen.olvidar_todos()
            return self._json(200, {'ok': True})
        if ruta == '/admin/parar':
            srv.parar.set()
            return self._json(200, {'ok': True})
        self._vacio(404)
