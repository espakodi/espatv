# -*- coding: utf-8 -*-
# EspaMando - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: GPL-2.0-or-later. Consulta el archivo LICENSE.
"""Servidor del mando. Lo lanza el servicio del módulo al arrancar Kodi (si hay móviles
vinculados) o un addon anfitrión con RunScript cuando el usuario usa el modo.

Solo puede haber uno vivo: publica un latido en una propiedad de Kodi y, antes de abrir el
puerto, reclama ser el dueño. Así no salen dos aunque lo lancen el servicio y un addon a la vez.
"""
import json
import os
import secrets
import sys
import threading
import time

_AQUI = os.path.dirname(os.path.abspath(__file__))
if _AQUI not in sys.path:
    sys.path.insert(0, _AQUI)

import xbmc  # noqa: E402
import xbmcgui  # noqa: E402
import xbmcvfs  # noqa: E402

from espamando_lib import kodi, nucleo, web  # noqa: E402

ID = 'service.espamando'
P_PUERTO = 'espamando.puerto'
P_ADMIN = 'espamando.admin'
P_LATIDO = 'espamando.latido'
P_DUENO = 'espamando.dueno'
LATIDO_CADA = 30
LATIDO_VIGENTE = 75


def perfil():
    return xbmcvfs.translatePath('special://profile/addon_data/{0}/'.format(ID))


def _leer_json(ruta):
    try:
        with open(ruta, 'r', encoding='utf-8') as f:
            datos = json.load(f)
        return datos if isinstance(datos, dict) else {}
    except (OSError, ValueError):
        return {}


def _guardar_ultimo_puerto(carpeta, puerto):
    ruta = os.path.join(carpeta, 'estado.json')
    try:
        os.makedirs(carpeta, exist_ok=True)
        with open(ruta + '.tmp', 'w', encoding='utf-8') as f:
            json.dump({'ultimo_puerto': puerto}, f)
        os.replace(ruta + '.tmp', ruta)
    except OSError:
        pass


def _puertos(carpeta):
    """Primero el último que funcionó (el móvil guarda esa dirección), luego el rango."""
    inicio = _leer_json(os.path.join(carpeta, 'config.json')).get('puerto')
    if not isinstance(inicio, int) or not 1024 <= inicio <= 65525:
        inicio = nucleo.PUERTO_INICIO
    rango = list(range(inicio, inicio + nucleo.PUERTOS))
    ultimo = _leer_json(os.path.join(carpeta, 'estado.json')).get('ultimo_puerto')
    if ultimo in rango:
        rango.remove(ultimo)
        rango.insert(0, ultimo)
    return rango


def _ya_hay_otro(ventana):
    try:
        return time.time() - float(ventana.getProperty(P_LATIDO)) < LATIDO_VIGENTE
    except ValueError:
        return False


def _reclamar(ventana):
    mio = secrets.token_hex(8)
    ventana.setProperty(P_DUENO, mio)
    xbmc.sleep(200)
    return mio if ventana.getProperty(P_DUENO) == mio else None


def main():
    ventana = xbmcgui.Window(10000)
    monitor = xbmc.Monitor()
    if _ya_hay_otro(ventana):
        return
    mio = _reclamar(ventana)
    if not mio or _ya_hay_otro(ventana):
        return

    carpeta = perfil()
    almacen = nucleo.Almacen(os.path.join(carpeta, 'moviles.json'))
    clave = secrets.token_urlsafe(24)
    carpeta_qr = xbmcvfs.translatePath('special://temp/')
    servidor = None
    for puerto in _puertos(carpeta):
        try:
            servidor = web.Servidor(('', puerto), almacen, clave, carpeta_qr, kodi)
            break
        except OSError:
            continue
    if servidor is None:
        kodi._log('No hay ningún puerto libre para el mando', xbmc.LOGWARNING)
        if ventana.getProperty(P_DUENO) == mio:
            ventana.clearProperty(P_DUENO)
        return
    # Si mientras abría el puerto otro proceso se ha quedado de dueño, cede: dos servidores
    # tendrían cada uno su lista de móviles en memoria y se desincronizarían
    if ventana.getProperty(P_DUENO) != mio:
        servidor.server_close()
        return

    _guardar_ultimo_puerto(carpeta, servidor.puerto)
    hilo_http = threading.Thread(target=servidor.serve_forever, kwargs={'poll_interval': 0.5},
                                 name='espamando-http', daemon=True)
    hilo_trabajo = threading.Thread(target=servidor.trabajar, name='espamando-cola', daemon=True)
    hilo_http.start()
    hilo_trabajo.start()
    ventana.setProperty(P_ADMIN, clave)
    ventana.setProperty(P_PUERTO, str(servidor.puerto))
    ventana.setProperty(P_LATIDO, str(time.time()))
    kodi._log('Mando escuchando en el puerto {0}'.format(servidor.puerto))

    ultimo_latido = time.time()
    try:
        # Despierta una vez por segundo para ver si le han pedido parar: es una espera, no gasta
        while not monitor.waitForAbort(1):
            if servidor.parar.is_set():
                break
            if time.time() - ultimo_latido >= LATIDO_CADA:
                ultimo_latido = time.time()
                ventana.setProperty(P_LATIDO, str(ultimo_latido))
    finally:
        servidor.parar.set()
        servidor.shutdown()
        servidor.server_close()
        hilo_http.join(timeout=2)
        hilo_trabajo.join(timeout=2)
        # Las propiedades se borran después de soltar el puerto: quien espera a que desaparezca el
        # latido (para actualizar o relanzar) encuentra el puerto ya libre y el móvil no cambia de
        # dirección
        if ventana.getProperty(P_DUENO) == mio:
            for prop in (P_PUERTO, P_ADMIN, P_LATIDO, P_DUENO):
                ventana.clearProperty(prop)
        kodi._log('Mando parado')


if __name__ == '__main__':
    main()
