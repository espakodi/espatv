# -*- coding: utf-8 -*-
# EspaMando - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: GPL-2.0-or-later. Consulta el archivo LICENSE.
"""Al arrancar Kodi: se pone al día y levanta el mando solo si hay móviles vinculados.

Sin móviles termina enseguida. Sin ningún addon anfitrión se desactiva a sí mismo para no volver a
arrancar en los siguientes inicios de Kodi.
"""
import json
import os
import sys

_AQUI = os.path.dirname(os.path.abspath(__file__))
if _AQUI not in sys.path:
    sys.path.insert(0, _AQUI)

import xbmc  # noqa: E402
import xbmcvfs  # noqa: E402

from espamando_lib import actualizar  # noqa: E402


def _hay_anfitrion():
    return any(xbmc.getCondVisibility('System.HasAddon({0})'.format(a)) and
               xbmc.getCondVisibility('System.AddonIsEnabled({0})'.format(a))
               for a in actualizar.ANFITRIONES)


def _desactivarme():
    xbmc.executeJSONRPC(json.dumps({
        'jsonrpc': '2.0', 'id': 1, 'method': 'Addons.SetAddonEnabled',
        'params': {'addonid': actualizar.MODULO, 'enabled': False}}))


def _moviles():
    ruta = xbmcvfs.translatePath(
        'special://profile/addon_data/{0}/moviles.json'.format(actualizar.MODULO))
    try:
        with open(ruta, 'r', encoding='utf-8') as f:
            moviles = json.load(f).get('moviles')
        return len(moviles) if isinstance(moviles, list) else 0
    except (OSError, ValueError, AttributeError):
        return 0


def run():
    if not _hay_anfitrion():
        xbmc.log('[EspaMando] Ningún addon lo usa: se desactiva', xbmc.LOGINFO)
        _desactivarme()
        return
    addons = xbmcvfs.translatePath('special://home/addons')
    origen = actualizar.plantilla_mas_nueva(addons)
    if origen and actualizar.reemplazar(addons, origen):
        xbmc.log('[EspaMando] Actualizado desde {0}'.format(origen), xbmc.LOGINFO)
        xbmc.executebuiltin('UpdateLocalAddons()')
        if _moviles():
            # El código de este proceso es el viejo: el servidor nuevo se lanza aparte
            servidor = os.path.join(addons, actualizar.MODULO, 'servidor.py')
            xbmc.executebuiltin('RunScript("{0}")'.format(servidor))
        return
    if not _moviles():
        return
    import servidor
    servidor.main()


try:
    run()
except Exception as e:  # el arranque de Kodi no se puede ver afectado por el mando
    xbmc.log('[EspaMando] Error al arrancar: {0}'.format(e), xbmc.LOGERROR)
