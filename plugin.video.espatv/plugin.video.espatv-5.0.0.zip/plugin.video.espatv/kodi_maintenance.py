# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Mantenimiento del sistema Kodi: paquetes, miniaturas en desuso, bases de datos
y copia de la configuración de Kodi.

Independiente de storage_manager.py (que gestiona las cachés propias del addon).
No toca datos de EspaTV ni de otros addons.
"""
from datetime import datetime, timedelta, timezone
import glob
import os
import re
import shutil
import sqlite3
import time
import xml.etree.ElementTree as ET
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

_LOG = "[EspaTV-MAINT]"
_ADDON_ID = "plugin.video.espatv"

# glob de stdlib no resuelve special://: se traduce a ruta real una sola vez.
DB_DIR = xbmcvfs.translatePath("special://database/")
THUMBS_DIR = xbmcvfs.translatePath("special://thumbnails/")
LOG_DIR = xbmcvfs.translatePath("special://logpath/")
TEMP_DIR = xbmcvfs.translatePath("special://temp/")
PKG_DIR = xbmcvfs.translatePath("special://home/addons/packages/")
ATEMP_DIR = xbmcvfs.translatePath("special://home/addons/temp/")
USERDATA_DIR = xbmcvfs.translatePath("special://masterprofile/")
HOME_ADDONS = xbmcvfs.translatePath("special://home/addons/")

# Ficheros de configuración de Kodi (planos en userdata). passwords.xml se
# excluye a propósito: contiene credenciales de fuentes SMB/NFS en texto plano.
_CONFIG_FILES = (
    "guisettings.xml", "sources.xml", "favourites.xml",
    "advancedsettings.xml", "RssFeeds.xml", "profiles.xml",
)

# Caché de enlaces resueltos de resolveurl (si está instalado). Son ficheros con
# nombre hash, no una DB abierta -> se pueden borrar sin riesgo de lock.
RESOLVEURL_CACHE = xbmcvfs.translatePath(
    "special://profile/addon_data/script.module.resolveurl/cache/")

# A partir de este tamaño, un VACUUM puede tardar y necesita espacio temporal
# del orden de la propia DB; se pregunta antes de compactar.
_VACUUM_WARN_BYTES = 256 * 1024 * 1024


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"{_LOG} {msg}", level)


def _notify(msg, icon=xbmcgui.NOTIFICATION_INFO, ms=3500):
    xbmcgui.Dialog().notification("EspaTV", msg, icon, ms)


def fmt_size(b):
    if b < 1024:
        return f"{b} B"
    if b < 1024 * 1024:
        return f"{b / 1024:.1f} KB"
    return f"{b / 1024 / 1024:.2f} MB"


def _walk_size(path):
    total = 0
    for root, _dirs, files in os.walk(path):
        for f in files:
            try:
                total += os.path.getsize(os.path.join(root, f))
            except OSError:
                pass
    return total


def _safe_getsize(path):
    try:
        return os.path.getsize(path)
    except OSError:
        return 0


def _within(base, target, base_real=None):
    """True si target queda dentro de base (evita path traversal en el
    borrado de miniaturas y ResolveURL). Acepta `base_real` precalculado para
    evitar llamadas repetidas en bucles grandes."""
    try:
        if base_real is None:
            base_real = os.path.realpath(base)
        return os.path.commonpath([base_real, os.path.realpath(target)]) == base_real
    except (ValueError, OSError):
        return False


def _safe_remove(path):
    """Borra un fichero o carpeta. Devuelve los bytes liberados (0 si falla)."""
    try:
        if os.path.isdir(path):
            sz = _walk_size(path)
            shutil.rmtree(path, ignore_errors=True)
            if not os.path.exists(path):
                return sz
            return max(0, sz - _walk_size(path))
        sz = os.path.getsize(path)
        os.remove(path)
        return sz
    except OSError as e:
        _log(f"No se pudo borrar {path}: {e}", xbmc.LOGWARNING)
        return 0


def _chunks(seq, n):
    for i in range(0, len(seq), n):
        yield seq[i:i + n]


def latest_db(prefix):
    """Ruta del fichero {prefix}NN.db de mayor versión, o None."""
    rx = re.compile(re.escape(prefix) + r"(\d+)\.db$", re.IGNORECASE)
    best, best_ver = None, -1
    for path in glob.glob(os.path.join(DB_DIR, prefix + "*.db")):
        m = rx.search(os.path.basename(path))
        if m and int(m.group(1)) > best_ver:
            best_ver, best = int(m.group(1)), path
    return best


# Limpieza de archivos del sistema (sin UI; devuelven bytes)

def _clear_dir_entries(dirpath):
    if not os.path.isdir(dirpath):
        return 0
    try:
        entries = os.listdir(dirpath)
    except OSError as e:
        _log(f"No se pudo listar {dirpath}: {e}", xbmc.LOGWARNING)
        return 0
    return sum(_safe_remove(os.path.join(dirpath, e)) for e in entries)


def _clear_packages_bytes():
    """Vacía addons/packages: .zip de instaladores cacheados, sus .crc y carpetas
    de descompresión. Todo es regenerable; Kodi lo vuelve a bajar si hace falta."""
    return _clear_dir_entries(PKG_DIR)


def _clear_addons_temp_bytes():
    return _clear_dir_entries(ATEMP_DIR)


def _crash_files():
    """Rutas (sin duplicados) de crashlogs y minidumps. Nunca casa con kodi.log ni
    kodi.old.log ni vacía special://temp/ entero mientras Kodi corre."""
    patterns = (
        os.path.join(LOG_DIR, "*crashlog*.*"),
        os.path.join(TEMP_DIR, "*.dmp"),
    )
    found = set()
    for pat in patterns:
        for entry in glob.glob(pat):
            if os.path.isfile(entry):
                found.add(os.path.realpath(entry))
    return found


def _clear_crashlogs_bytes():
    return sum(_safe_remove(p) for p in _crash_files())


def _resolveurl_cache_size():
    """Tamaño de la caché de enlaces de resolveurl, o 0 si no está instalado o vacía."""
    if not xbmc.getCondVisibility("System.HasAddon(script.module.resolveurl)"):
        return 0
    if not os.path.isdir(RESOLVEURL_CACHE):
        return 0
    return _walk_size(RESOLVEURL_CACHE)


def _clear_resolveurl_cache_bytes():
    """Vacía el contenido de cache/ de resolveurl sin tocar settings.xml del directorio padre."""
    if not os.path.isdir(RESOLVEURL_CACHE):
        return 0
    try:
        entries = os.listdir(RESOLVEURL_CACHE)
    except OSError as e:
        _log(f"No se pudo listar caché de resolveurl: {e}", xbmc.LOGWARNING)
        return 0
    base_real = os.path.realpath(RESOLVEURL_CACHE)
    freed = 0
    for entry in entries:
        full = os.path.join(RESOLVEURL_CACHE, entry)
        if _within(RESOLVEURL_CACHE, full, base_real):
            freed += _safe_remove(full)
    return freed


def _confirm_and_clean(label, size, worker, detail):
    if size == 0:
        return
    if not xbmcgui.Dialog().yesno(
        label, f"{detail}\n\nSe liberarán [B]{fmt_size(size)}[/B].\n\n¿Continuar?"
    ):
        return
    _notify(f"Liberados {fmt_size(worker())}")


def _do_bundle(total):
    if total == 0:
        return
    if not xbmcgui.Dialog().yesno(
        "Limpieza completa segura",
        f"Se borrarán paquetes de instalación, temporales de addons y registros de "
        f"fallos ([B]{fmt_size(total)}[/B]).\n\n"
        "[COLOR lightgreen]No toca tus datos ni los de otros addons.[/COLOR]\n\n¿Continuar?"
    ):
        return
    freed = _clear_packages_bytes() + _clear_addons_temp_bytes() + _clear_crashlogs_bytes()
    _notify(f"Liberados {fmt_size(freed)}")


# --- Miniaturas en desuso ---

def old_thumbs():
    dbfile = latest_db("Textures")
    if not dbfile:
        _notify("No se encontró la base de datos de miniaturas", xbmcgui.NOTIFICATION_WARNING)
        return

    choices = (("7 días", 7), ("30 días", 30), ("90 días", 90))
    idx = xbmcgui.Dialog().select(
        "Borrar miniaturas sin usar desde hace...", [c[0] for c in choices]
    )
    if idx < 0:
        return
    days = choices[idx][1]
    # lastusetime lo escribe Kodi con CURRENT_TIMESTAMP (UTC): el corte va en UTC.
    cutoff = (datetime.now(timezone.utc) - timedelta(days=days)).strftime("%Y-%m-%d %H:%M:%S")

    conn = None
    try:
        conn = sqlite3.connect(dbfile, timeout=2.0, isolation_level=None)
        rows = conn.execute(
            "SELECT t.id, t.cachedurl FROM texture t "
            "WHERE t.id IN (SELECT idtexture FROM sizes "
            "WHERE lastusetime IS NOT NULL AND lastusetime != '' "
            "GROUP BY idtexture HAVING MAX(lastusetime) < ?)",
            (cutoff,),
        ).fetchall()
        rows = [(i, c) for i, c in rows if c]
        if not rows:
            _notify(f"No hay miniaturas sin usar desde hace {days} días")
            return

        thumbs_real = os.path.realpath(THUMBS_DIR)
        total = sum(
            _safe_getsize(p)
            for p in (os.path.join(THUMBS_DIR, c.lstrip("/\\")) for _i, c in rows)
            if _within(THUMBS_DIR, p, thumbs_real)
        )
        if not xbmcgui.Dialog().yesno(
            "Miniaturas en desuso",
            f"Se borrarán [B]{len(rows)}[/B] miniaturas sin usar desde hace {days} días "
            f"([B]{fmt_size(total)}[/B]).\n\n"
            "Kodi las regenera al verlas; no afecta a las que usas.\n\n¿Continuar?"
        ):
            return

        freed, done, interrumpido = 0, 0, False
        prog = xbmcgui.DialogProgressBG()
        prog.create("EspaTV", "Borrando miniaturas en desuso...")
        try:
            for chunk in _chunks(rows, 200):
                ids = [r[0] for r in chunk]
                placeholders = ",".join("?" * len(ids))
                try:
                    # Fila antes que el fichero: el trigger textureDelete limpia sizes.
                    conn.execute(f"DELETE FROM texture WHERE id IN ({placeholders})", ids)
                except sqlite3.DatabaseError:
                    interrumpido = True
                    break
                for _i, cachedurl in chunk:
                    full = os.path.join(THUMBS_DIR, cachedurl.lstrip("/\\"))
                    if _within(THUMBS_DIR, full, thumbs_real) and os.path.isfile(full):
                        freed += _safe_remove(full)
                done += len(chunk)
                prog.update(int(done * 100 / len(rows)), "EspaTV", f"{done}/{len(rows)}")
        finally:
            prog.close()
        if interrumpido:
            _log("Textures DB ocupada durante el borrado por lotes", xbmc.LOGWARNING)
            _notify(
                f"Interrumpido (DB ocupada): {done} borradas, {fmt_size(freed)} liberados",
                xbmcgui.NOTIFICATION_WARNING,
            )
        else:
            _notify(f"Miniaturas: {done} borradas, {fmt_size(freed)} liberados")
    except sqlite3.DatabaseError as e:
        _log(f"No se pudo acceder a Textures DB: {e}", xbmc.LOGWARNING)
        _notify("No se pudo acceder a la base de datos de miniaturas", xbmcgui.NOTIFICATION_WARNING)
    finally:
        if conn is not None:
            conn.close()


# --- Bases de datos de Kodi ---

def integrity_check():
    db_files = sorted(glob.glob(os.path.join(DB_DIR, "*.db")))
    if not db_files:
        _notify("No se encontraron bases de datos", xbmcgui.NOTIFICATION_WARNING)
        return
    lines = []
    prog = xbmcgui.DialogProgressBG()
    prog.create("EspaTV", "Comprobando integridad...")
    try:
        for i, path in enumerate(db_files):
            name = os.path.basename(path)
            prog.update(int(i * 100 / len(db_files)), "EspaTV", name)
            try:
                conn = sqlite3.connect(path, timeout=2.0)
                try:
                    res = conn.execute("PRAGMA quick_check").fetchall()
                finally:
                    conn.close()
                if res == [("ok",)]:
                    lines.append(f"[COLOR lime]OK[/COLOR]      {name}")
                else:
                    lines.append(f"[COLOR red]PROBLEMA[/COLOR]   {name}")
            except sqlite3.OperationalError:
                lines.append(f"[COLOR gold]ocupada[/COLOR]   {name}")
            except sqlite3.DatabaseError:
                lines.append(f"[COLOR red]PROBLEMA[/COLOR]   {name}")
    finally:
        prog.close()
    xbmcgui.Dialog().textviewer("Integridad de bases de datos", "\n".join(lines))


def vacuum_dbs():
    db_files = sorted(glob.glob(os.path.join(DB_DIR, "*.db")))
    if not db_files:
        _notify("No se encontraron bases de datos", xbmcgui.NOTIFICATION_WARNING)
        return
    if not xbmcgui.Dialog().yesno(
        "Compactar bases de datos",
        "Compacta las bases de datos de Kodi para recuperar espacio.\n\n"
        "Si alguna está en uso ahora, se omite. Puede liberar 0 B si ya están "
        "compactas: es normal.\n\n¿Continuar?"
    ):
        return

    large = [p for p in db_files if _safe_getsize(p) > _VACUUM_WARN_BYTES]
    include_large = True
    if large:
        nombres = ", ".join(os.path.basename(p) for p in large)
        include_large = xbmcgui.Dialog().yesno(
            "Bases de datos grandes",
            f"[B]{nombres}[/B] son grandes; compactarlas puede tardar y necesita "
            "espacio temporal del tamaño de cada una.\n\n¿Incluirlas?",
        )

    freed_total, vacuumed, skipped = 0, 0, 0
    prog = xbmcgui.DialogProgressBG()
    prog.create("EspaTV", "Compactando bases de datos...")
    try:
        for i, path in enumerate(db_files):
            name = os.path.basename(path)
            prog.update(int(i * 100 / len(db_files)), "EspaTV", name)
            if not include_large and _safe_getsize(path) > _VACUUM_WARN_BYTES:
                skipped += 1
                continue
            try:
                before = os.path.getsize(path)
                conn = sqlite3.connect(path, timeout=2.0, isolation_level=None)
                try:
                    row = conn.execute("PRAGMA freelist_count").fetchone()
                    if not row or row[0] == 0:
                        skipped += 1
                        continue
                    conn.execute("VACUUM")
                finally:
                    conn.close()
                freed_total += max(0, before - os.path.getsize(path))
                vacuumed += 1
            except sqlite3.DatabaseError as e:
                skipped += 1
                _log(f"VACUUM omitido {name}: {e}", xbmc.LOGDEBUG)
            except OSError as e:
                _log(f"VACUUM {name}: {e}", xbmc.LOGWARNING)
                skipped += 1
    finally:
        prog.close()
    _notify(f"Compactadas {vacuumed}, omitidas {skipped}. Liberados {fmt_size(freed_total)}")


# --- Copia de seguridad de la configuración de Kodi ---

def _backup_dir():
    try:
        prof = xbmcvfs.translatePath(xbmcaddon.Addon(_ADDON_ID).getAddonInfo("profile"))
    except RuntimeError:
        prof = ""
    if not isinstance(prof, str) or not prof or prof.startswith("special://"):
        prof = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tmp")
    p = os.path.join(prof, "kodi_config_backups")
    os.makedirs(p, exist_ok=True)
    return p


def _unique_path(path):
    """Evita pisar un fichero existente añadiendo _2, _3... antes de la extensión."""
    if not os.path.exists(path):
        return path
    root, ext = os.path.splitext(path)
    n = 2
    while os.path.exists(f"{root}_{n}{ext}"):
        n += 1
    return f"{root}_{n}{ext}"


def _sweep_orphan_tmp(dirpath, pattern):
    """Borra temporales huérfanos (>24 h) tras un cierre abrupto previo."""
    cutoff = time.time() - 24 * 3600
    for p in glob.glob(os.path.join(dirpath, pattern)):
        try:
            if os.path.getmtime(p) < cutoff:
                os.remove(p)
        except OSError:
            pass


def _write_config_zip(target):
    """Escribe el ZIP de configuración de forma atómica (.tmp + testzip + os.replace)."""
    tmp = target + ".tmp"
    included = []
    try:
        with zipfile.ZipFile(tmp, "w", zipfile.ZIP_DEFLATED) as zf:
            for name in _CONFIG_FILES:
                fp = os.path.join(USERDATA_DIR, name)
                if not os.path.isfile(fp):
                    continue
                try:
                    with open(fp, "rb") as fh:
                        data = fh.read()
                    # Validar XML íntegro (tolerando BOM UTF-8).
                    ET.fromstring(data[3:] if data.startswith(b"\xef\xbb\xbf") else data)
                    zf.writestr(name, data)
                    included.append(name)
                except (OSError, ET.ParseError) as e:
                    _log(f"Omitido {name} (no legible o íntegro): {e}", xbmc.LOGWARNING)
            ids = []
            if os.path.isdir(HOME_ADDONS):
                try:
                    ids = sorted(
                        d for d in os.listdir(HOME_ADDONS)
                        if d not in ("packages", "temp")
                        and os.path.isdir(os.path.join(HOME_ADDONS, d))
                    )
                except OSError:
                    ids = []
            zf.writestr("installed_addons.txt", "\n".join(ids))
        with zipfile.ZipFile(tmp, "r") as zf:
            if zf.testzip() is not None:
                raise zipfile.BadZipFile("verificación CRC del ZIP falló")
        os.replace(tmp, target)
        return included
    except (OSError, zipfile.BadZipFile):
        if os.path.exists(tmp):
            try:
                os.remove(tmp)
            except OSError:
                pass
        raise


def _create_config_backup():
    target = _unique_path(os.path.join(
        _backup_dir(), f"Kodi_Config_{time.strftime('%Y%m%d_%H%M%S')}.zip"
    ))
    try:
        included = _write_config_zip(target)
        _notify(f"Copia creada: {len(included)} ficheros + lista de addons")
    except (OSError, zipfile.BadZipFile) as e:
        _log(f"Error creando copia: {e}", xbmc.LOGERROR)
        _notify("No se pudo crear la copia", xbmcgui.NOTIFICATION_ERROR)


def _snapshot_before_restore():
    """Copia de la config actual antes de restaurar para poder deshacer."""
    target = _unique_path(os.path.join(
        _backup_dir(), f"Kodi_Config_PRE_RESTORE_{time.strftime('%Y%m%d_%H%M%S')}.zip"
    ))
    try:
        _write_config_zip(target)
        return target
    except (OSError, zipfile.BadZipFile) as e:
        _log(f"No se pudo crear copia previa a la restauración: {e}", xbmc.LOGWARNING)
        return None


def _restore_config_backup():
    bdir = _backup_dir()
    try:
        zips = sorted((f for f in os.listdir(bdir) if f.lower().endswith(".zip")), reverse=True)
    except OSError:
        zips = []
    if not zips:
        _notify("No hay copias guardadas", xbmcgui.NOTIFICATION_WARNING)
        return
    zi = xbmcgui.Dialog().select("Restaurar copia de configuración", zips)
    if zi < 0:
        return
    source = os.path.join(bdir, zips[zi])
    undo = None
    staged = []
    restored = []
    replaced = failed = 0
    try:
        with zipfile.ZipFile(source, "r") as zf:
            # Lista blanca sobre _CONFIG_FILES: Zip-Slip imposible y passwords.xml excluido.
            present = [n for n in zf.namelist() if n in _CONFIG_FILES]
            if not present:
                xbmcgui.Dialog().ok("EspaTV", "Esta copia no contiene configuración reconocida.")
                return
            sel = xbmcgui.Dialog().multiselect("¿Qué quieres restaurar?", present)
            if not sel:
                return
            if not xbmcgui.Dialog().yesno(
                "Restaurar configuración",
                f"Se sobrescribirán [B]{len(sel)}[/B] ficheros de configuración de Kodi.\n\n"
                "Después hay que reiniciar Kodi. [B]guisettings.xml[/B] y [B]profiles.xml[/B] "
                "los reescribe Kodi al cerrarse de forma normal; si los restauras, al terminar "
                "te ofreceré cerrarlo sin que los guarde.\n\n"
                "¿Continuar?"
            ):
                return
            undo = _snapshot_before_restore()
            if undo is None and not xbmcgui.Dialog().yesno(
                "Sin copia de seguridad previa",
                "No se pudo guardar una copia de tu configuración actual (¿disco lleno?).\n\n"
                "Si restauras ahora [COLOR gold]no podrás deshacer automáticamente[/COLOR].\n\n"
                "¿Continuar de todos modos?"
            ):
                return
            # Valida todos los XML y los deja en .maint_tmp antes de sustituir los originales.
            os.makedirs(USERDATA_DIR, exist_ok=True)
            for i in sel:
                name = present[i]
                dst_path = os.path.join(USERDATA_DIR, name)
                tmp_path = f"{dst_path}.maint_tmp"
                staged.append((tmp_path, dst_path))
                with zf.open(name) as src:
                    data = src.read()
                ET.fromstring(data[3:] if data.startswith(b"\xef\xbb\xbf") else data)
                with open(tmp_path, "wb") as dst:
                    dst.write(data)
            # Sustitución atómica desde staging.
            for tmp_path, dst_path in staged:
                try:
                    os.replace(tmp_path, dst_path)
                    replaced += 1
                    restored.append(os.path.basename(dst_path))
                except OSError as e:
                    _log(f"No se pudo aplicar {os.path.basename(dst_path)}: {e}", xbmc.LOGERROR)
                    failed += 1
                    try:
                        os.remove(tmp_path)
                    except OSError:
                        pass
            staged = []
    except (OSError, zipfile.BadZipFile, ET.ParseError) as e:
        _log(f"Error restaurando (fase 1): {e}", xbmc.LOGERROR)
        for tmp_path, _dst in staged:
            try:
                os.remove(tmp_path)
            except OSError:
                pass
        xbmcgui.Dialog().ok(
            "Restauración cancelada",
            "No se aplicó ningún cambio; tu configuración sigue intacta.",
        )
        return
    if failed and replaced:
        msg = (
            f"Se aplicaron {replaced} ficheros y {failed} no.\n\n"
            "[COLOR gold]Tu configuración quedó a medias.[/COLOR]"
        )
        if undo:
            msg += (
                "\nPara volver al estado anterior, restaura la copia:\n"
                f"[B]{os.path.basename(undo)}[/B]"
            )
        xbmcgui.Dialog().ok("Restauración incompleta", msg)
    elif failed:
        _notify(f"No se pudo aplicar la restauración ({failed} ficheros)", xbmcgui.NOTIFICATION_ERROR)
    elif undo:
        xbmcgui.Dialog().ok(
            "Restauración completada",
            "Reinicia Kodi para aplicar los cambios.\n\n"
            "[COLOR lightgreen]Por si quieres deshacer[/COLOR], se guardó tu configuración "
            f"anterior en la lista de copias:\n[B]{os.path.basename(undo)}[/B]",
        )
    else:
        _notify("Configuración restaurada. Reinicia Kodi para aplicar.")

    criticos = [n for n in restored if n in ("guisettings.xml", "profiles.xml")]
    if criticos and not failed and xbmcgui.Dialog().yesno(
        "Cerrar Kodi sin guardar",
        f"Para que se aplique {' y '.join(criticos)}, Kodi tiene que cerrarse ahora sin "
        "guardar su configuración; si lo cierras de forma normal, la sobrescribirá.\n\n"
        "¿Cerrar Kodi ahora?",
        nolabel="Más tarde",
        yeslabel="Cerrar Kodi",
    ):
        _log(f"Cierre forzado tras restaurar {', '.join(criticos)}", xbmc.LOGWARNING)
        os._exit(1)


_BACKUP_HELP = "\n".join([
    "COPIA DE CONFIGURACIÓN DE KODI",
    "-" * 40,
    "",
    "Guarda en un ZIP los ajustes generales de Kodi para",
    "recuperarlos tras reinstalar:",
    "",
    "  - guisettings.xml (ajustes y skin)",
    "  - sources.xml (fuentes de archivos)",
    "  - favourites.xml (favoritos de Kodi)",
    "  - advancedsettings.xml (ajustes avanzados)",
    "  - RssFeeds.xml, profiles.xml",
    "  - lista de addons instalados (texto)",
    "",
    "NO incluye: bases de datos, miniaturas, datos de",
    "addons ni passwords.xml (credenciales de fuentes).",
    "",
    "Al restaurar se guarda antes una copia de tu configuración",
    "previa automática (PRE_RESTORE), que aparece en la lista de copias",
    "a restaurar por si quieres deshacer.",
    "",
    "Esto es la configuración de KODI. Tus datos de",
    "EspaTV se respaldan aparte, en 'Copias de Seguridad'.",
])


def backup_submenu():
    _sweep_orphan_tmp(_backup_dir(), "*.tmp")
    _sweep_orphan_tmp(USERDATA_DIR, "*.maint_tmp")
    while True:
        idx = xbmcgui.Dialog().select("Copia de configuración de Kodi", [
            "[COLOR green]Crear copia de la configuración[/COLOR]",
            "Restaurar una copia...",
            "[COLOR grey]¿Qué incluye? (ayuda)[/COLOR]",
        ])
        if idx == 0:
            _create_config_backup()
        elif idx == 1:
            _restore_config_backup()
        elif idx == 2:
            xbmcgui.Dialog().textviewer("Copia de configuración - ayuda", _BACKUP_HELP)
        else:
            break


# --- Menú principal ---

_HELP = "\n".join([
    "MANTENIMIENTO DE KODI",
    "-" * 40,
    "",
    "Limpia y optimiza KODI en general (no el addon).",
    "Tus datos de EspaTV y los de otros addons no se tocan.",
    "",
    "  - Paquetes .zip: instaladores cacheados; Kodi los",
    "    vuelve a bajar si hace falta.",
    "  - Temporales de addons / registros de fallos: archivos de paso",
    "    (nunca toca kodi.log).",
    "  - Miniaturas en desuso: solo las que no ves desde hace",
    "    tiempo; Kodi las regenera al volver a verlas.",
    "  - Compactar bases de datos: recupera espacio;",
    "    omite las que Kodi esté usando.",
    "  - Integridad: comprueba las bases de datos (solo lectura).",
    "  - Caché de enlaces (resolveurl): si lo tienes instalado,",
    "    vacía enlaces resueltos caducados (arregla links caídos).",
    "  - Copia de configuración: respalda los ajustes de Kodi.",
])


def maintenance_menu():
    while True:
        try:
            pkg = _walk_size(PKG_DIR) if os.path.isdir(PKG_DIR) else 0
            atemp = _walk_size(ATEMP_DIR) if os.path.isdir(ATEMP_DIR) else 0
            crash = sum(_safe_getsize(p) for p in _crash_files())
            resolver = _resolveurl_cache_size()
            bundle = pkg + atemp + crash

            opciones, acciones = [], []
            if bundle > 0:
                opciones.append(f"[COLOR red]Limpieza completa segura ({fmt_size(bundle)})[/COLOR]")
                acciones.append("bundle")
            if pkg > 0:
                opciones.append(f"Paquetes de instalación (.zip)    [COLOR grey]{fmt_size(pkg)}[/COLOR]")
                acciones.append("pkg")
            if atemp > 0:
                opciones.append(f"Temporales de addons    [COLOR grey]{fmt_size(atemp)}[/COLOR]")
                acciones.append("atemp")
            if crash > 0:
                opciones.append(f"Registros de fallos    [COLOR grey]{fmt_size(crash)}[/COLOR]")
                acciones.append("crash")
            if resolver > 0:
                opciones.append(f"Caché de enlaces (resolveurl)    [COLOR grey]{fmt_size(resolver)}[/COLOR]")
                acciones.append("resolver")
            opciones.append("Miniaturas en desuso...")
            acciones.append("thumbs")
            opciones.append("[COLOR orange]Compactar bases de datos[/COLOR]")
            acciones.append("vacuum")
            opciones.append("[COLOR grey]Comprobar integridad de las bases de datos[/COLOR]")
            acciones.append("integrity")
            opciones.append("[COLOR aqua]Copia de seguridad de Kodi (config)...[/COLOR]")
            acciones.append("backup")
            opciones.append("[COLOR grey]¿Qué hace cada opción? (ayuda)[/COLOR]")
            acciones.append("info")

            heading = (
                f"Mantenimiento de Kodi - {fmt_size(bundle)} en limpieza rápida"
                if bundle > 0 else "Mantenimiento de Kodi"
            )
            idx = xbmcgui.Dialog().select(heading, opciones)
            if idx < 0:
                break
            a = acciones[idx]
            if a == "bundle":
                _do_bundle(bundle)
            elif a == "pkg":
                _confirm_and_clean(
                    "Paquetes de instalación", pkg, _clear_packages_bytes,
                    "Se vaciará la carpeta de paquetes (instaladores .zip y "
                    "temporales de descompresión). Kodi los re-descarga si hace falta.",
                )
            elif a == "atemp":
                _confirm_and_clean(
                    "Temporales de addons", atemp, _clear_addons_temp_bytes,
                    "Se borrarán los temporales de instalación de addons.",
                )
            elif a == "crash":
                _confirm_and_clean(
                    "Registros de fallos", crash, _clear_crashlogs_bytes,
                    "Se borrarán registros de fallos y volcados (minidumps). No se toca kodi.log.",
                )
            elif a == "resolver":
                _confirm_and_clean(
                    "Caché de enlaces (resolveurl)", resolver,
                    _clear_resolveurl_cache_bytes,
                    "Se vaciará la caché de enlaces resueltos de resolveurl. "
                    "Se regenera al reproducir; útil si hay enlaces caídos.",
                )
            elif a == "thumbs":
                old_thumbs()
            elif a == "vacuum":
                vacuum_dbs()
            elif a == "integrity":
                integrity_check()
            elif a == "backup":
                backup_submenu()
            elif a == "info":
                xbmcgui.Dialog().textviewer("Mantenimiento de Kodi - ayuda", _HELP)
        except Exception as e:
            _log(f"Error inesperado en el menú: {e}", xbmc.LOGERROR)
            xbmcgui.Dialog().ok("EspaTV", f"Se produjo un error en mantenimiento:\n{e}")
