# -*- coding: utf-8 -*-
"""Sincronización del reproductor de EspaTV en TMDB Helper (`espatv.json`)."""

import json
import os
import threading
import xbmc
import xbmcaddon
import xbmcvfs

_ADDON_ID = 'plugin.video.espatv'
_TMDBHELPER_ID = 'plugin.video.themoviedb.helper'
_PLAYERS_SPECIAL = 'special://profile/addon_data/plugin.video.themoviedb.helper/players'
_PLAYER_FILENAME = 'espatv.json'


def _addon_path():
    local = os.path.dirname(os.path.abspath(__file__))
    if os.path.isfile(os.path.join(local, 'resources', 'tmdbhelper', _PLAYER_FILENAME)):
        return local
    try:
        path = xbmcaddon.Addon(_ADDON_ID).getAddonInfo('path')
        if isinstance(path, str) and path:
            translated = xbmcvfs.translatePath(path)
            if isinstance(translated, str) and translated:
                return translated
    except Exception:
        pass
    return local


def template_path():
    """Ruta de la plantilla del reproductor incluida en el addon."""
    return os.path.join(_addon_path(), 'resources', 'tmdbhelper', _PLAYER_FILENAME)


def target_path():
    """Ruta de destino en `addon_data/plugin.video.themoviedb.helper/players`."""
    players_dir = xbmcvfs.translatePath(_PLAYERS_SPECIAL)
    if (not isinstance(players_dir, str)
            or not players_dir
            or players_dir.startswith(('special://', 'MagicMock', '<MagicMock'))
            or not os.path.isabs(players_dir)):
        return ''
    return os.path.join(players_dir, _PLAYER_FILENAME)


def _load_template():
    with open(template_path(), 'r', encoding='utf-8') as f:
        return json.load(f)


def _is_tmdbhelper_installed():
    return bool(
        xbmc.getCondVisibility(f'System.HasAddon({_TMDBHELPER_ID})')
        or xbmc.getCondVisibility(f'System.AddonIsEnabled({_TMDBHELPER_ID})')
    )


def _write_if_changed(dst, payload_text):
    try:
        if os.path.exists(dst):
            with open(dst, 'r', encoding='utf-8') as f:
                if f.read() == payload_text:
                    return False
    except OSError:
        pass

    os.makedirs(os.path.dirname(dst), exist_ok=True)
    tmp = f'{dst}.{os.getpid()}.{threading.get_ident()}.tmp'
    try:
        with open(tmp, 'w', encoding='utf-8', newline='\n') as f:
            f.write(payload_text)
        os.replace(tmp, dst)
    except Exception:
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except OSError:
            pass
        raise
    return True


def sync(enabled=None):
    """Instala, actualiza o retira `espatv.json` en TMDB Helper según la configuración."""
    try:
        if enabled is None:
            import core_settings
            enabled = core_settings.is_tmdbhelper_player_enabled()

        dst = target_path()
        if not dst:
            return 'noop'
        if not enabled or not _is_tmdbhelper_installed():
            if os.path.exists(dst):
                os.remove(dst)
                xbmc.log('[EspaTV] Player de TMDB Helper retirado.', xbmc.LOGINFO)
                return 'removed'
            return 'noop'

        data = _load_template()
        payload_text = json.dumps(data, ensure_ascii=False, indent=2) + '\n'
        if _write_if_changed(dst, payload_text):
            xbmc.log(f'[EspaTV] Player de TMDB Helper sincronizado en {dst}', xbmc.LOGINFO)
            return 'updated'
        return 'unchanged'
    except Exception as e:
        xbmc.log(f'[EspaTV] Error sincronizando player de TMDB Helper: {e}', xbmc.LOGWARNING)
        return 'error'
