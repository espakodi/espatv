# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""
Resolver Debrid embebido. Convierte enlaces de filehosters y magnets en
streams directos usando la cuenta del usuario, sin depender de ResolveURL.

Proveedores: AllDebrid (apikey), Real-Debrid (OAuth device + refresh),
TorBox (apikey + device), Premiumize (OAuth device) y Offcloud (device + token).
Cada uno es una clase
independiente que hereda de _DebridBase: un fallo en uno solo afecta a ese
proveedor cuando está seleccionado, nunca al resto del addon.

Endpoints y estructuras verificados contra el código real de ResolveURL
(no contra documentación recordada). Solo AllDebrid se ha podido
probar en runtime; los demás siguen las mismas fuentes pero su verificación
real queda pendiente de una cuenta de cada servicio.
"""
import base64
import json
import os
import re
import socket
import time
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui

import core_settings
import debrid_filesel

_VIDEO_EXTS = (
    ".mkv", ".mp4", ".avi", ".ts", ".mov", ".wmv", ".webm", ".m4v", ".mpg", ".mpeg",
)
_HOSTS_TTL = 8 * 3600
_TIMEOUT = 15
_RATE_LIMIT_WAIT_MS = 5000
_RD_PAGE = 100
_RD_MAX_PAGES = 10
_TB_WAIT_S = 40 * 60

_KNOWN_CACHE_FILE = os.path.join(core_settings._PROFILE_PATH, "debrid_known_cache.json")
_KNOWN_TTL = 30 * 86400
_KNOWN_MAX = 2000


class DebridError(Exception):
    pass


class DebridAuthError(DebridError):
    """Token inválido/revocado o cuenta bloqueada: hay que re-vincular."""


class DebridNotSupported(DebridError):
    """El recurso no está soportado: el llamador debe caer al flujo normal."""


class DebridNotPremium(DebridError):
    """La operación requiere cuenta premium activa."""


class DebridNetworkError(DebridError):
    """Fallo de red, timeout o respuesta ilegible: caer al flujo normal."""


class DebridRateLimit(DebridError):
    """HTTP 429 que sigue tras el reintento: la API pide bajar el ritmo."""


class DebridUnavailable(DebridError):
    """El contenido ya no está disponible (retirado por el proveedor): probar otra fuente."""


def _addon():
    return xbmcaddon.Addon()


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("[EspaTV/Debrid] {0}".format(msg), level)


def _http_json(method, url, headers=None, data=None, params=None, json_body=None, timeout=_TIMEOUT):
    """Petición HTTP que devuelve el dict JSON (de éxito o de error de la API).
    Solo lanza DebridNetworkError para fallos de transporte/parseo."""
    if params:
        url += "?" + urllib.parse.urlencode(params, doseq=True)
    h = dict(headers or {})
    body = None
    if json_body is not None:
        body = json.dumps(json_body).encode("utf-8")
        h["Content-Type"] = "application/json"
    elif data is not None:
        body = urllib.parse.urlencode(data, doseq=True).encode("utf-8")
    req = urllib.request.Request(url, data=body, headers=h, method=method)
    for intento in range(2):
        try:
            with urllib.request.urlopen(req, timeout=timeout) as r:
                txt = r.read().decode("utf-8")
            break
        except urllib.error.HTTPError as e:
            if e.code == 429:
                try:
                    espera = int((e.headers or {}).get("Retry-After") or 0)
                except (TypeError, ValueError, AttributeError):
                    espera = 0
                # TorBox puede pedir casi un minuto: no se bloquea Kodi esperando.
                if espera > 10:
                    raise DebridRateLimit("HTTP 429 (Retry-After {0} s)".format(espera))
                if intento == 0:
                    xbmc.sleep(_RATE_LIMIT_WAIT_MS)
                    continue
                raise DebridRateLimit("HTTP 429")
            if e.code == 451:
                raise DebridUnavailable("HTTP 451")
            try:
                txt = e.read().decode("utf-8")
                return json.loads(txt)  # las APIs Debrid devuelven el error en el cuerpo
            except (ValueError, OSError):
                raise DebridNetworkError("HTTP {0}".format(e.code))
        except (urllib.error.URLError, socket.timeout, OSError) as e:
            raise DebridNetworkError(str(e))
    if not txt.strip():
        return {}  # 204 No Content (p.ej. RD selectFiles/delete)
    try:
        return json.loads(txt)
    except ValueError:
        raise DebridNetworkError("respuesta no JSON")


def _flatten_files(files):
    """Aplana la estructura de AllDebrid: 'e' son subcarpetas; los archivos
    tienen 'n' (nombre), 'l' (link interno) y 's' (tamaño)."""
    flat = []
    for f in files or []:
        if "e" in f:
            flat.extend(_flatten_files(f["e"]))
        elif f.get("l"):
            flat.append(f)
    return flat


def _video_files_ad(flat):
    return [f for f in flat if (f.get("n") or "").lower().endswith(_VIDEO_EXTS)]


def _is_video_name(name):
    return bool(name) and name.lower().endswith(_VIDEO_EXTS)


def _fmt_ts(ts):
    try:
        return time.strftime("%d/%m/%Y", time.localtime(int(ts)))
    except (ValueError, OSError, TypeError):
        return ""


def _days_from_ts(ts):
    try:
        return max(0, int((int(ts) - time.time()) / 86400))
    except (TypeError, ValueError):
        return None


def _days_from_iso(iso):
    # Días hasta una fecha ISO 'YYYY-MM-DD...', sin strptime (no fiable en Kodi).
    try:
        import datetime
        y, m, d = iso[:10].split("-")
        return max(0, (datetime.date(int(y), int(m), int(d)) - datetime.date.today()).days)
    except (ValueError, TypeError, AttributeError):
        return None


class _DebridBase:
    name = "base"
    PREFIX = "base"
    TOKEN_KEY = "base_token"
    SUPPORTS_PIN = False  # ¿tiene flujo de vinculación por código en pantalla?
    KNOWN_CACHE = False  # ¿mantiene el almacén local de hashes que ya se vieron en caché?

    def __init__(self):
        addon = _addon()
        self.token = addon.getSetting(self.TOKEN_KEY) or ""
        self.cached_only = addon.getSetting("debrid_cached_only") == "true"
        self.auto_cleanup = addon.getSetting("debrid_auto_cleanup") == "true"
        self.auto_quality = addon.getSetting("debrid_auto_quality") == "true"

    # --- estado/credenciales (sin red) ---

    def is_authorized(self):
        return bool(self.token) and _addon().getSetting(self.PREFIX + "_authorized") == "true"

    def stored_user(self):
        return _addon().getSetting(self.PREFIX + "_user") or ""

    def _save_auth(self, token, user):
        addon = _addon()
        addon.setSetting(self.TOKEN_KEY, token)
        addon.setSetting(self.PREFIX + "_authorized", "true")
        addon.setSetting(self.PREFIX + "_user", str(user or ""))
        self.token = token

    def deauthorize(self):
        addon = _addon()
        addon.setSetting(self.TOKEN_KEY, "")
        addon.setSetting(self.PREFIX + "_authorized", "false")
        addon.setSetting(self.PREFIX + "_user", "")
        addon.setSetting("debrid_hosts_cache", "")
        addon.setSetting("debrid_hosts_ts", "")
        self.token = ""

    # --- cache de hosts compartida ({p: provider, items: [...]}) ---

    def _host_cache(self, fetch_fn):
        addon = _addon()
        raw = addon.getSetting("debrid_hosts_cache") or ""
        ts = addon.getSetting("debrid_hosts_ts") or "0"
        try:
            fresh = (int(time.time()) - int(ts)) < _HOSTS_TTL
        except ValueError:
            fresh = False
        if raw and fresh:
            try:
                obj = json.loads(raw)
                if obj.get("p") == self.name:
                    return obj.get("items", [])
            except ValueError:
                pass
        try:
            items = fetch_fn()
        except DebridError:
            return []
        addon.setSetting("debrid_hosts_cache", json.dumps({"p": self.name, "items": items}))
        addon.setSetting("debrid_hosts_ts", str(int(time.time())))
        return items

    def warm_hosts(self):
        """Precalienta la cache de hosts (llamar tras vincular)."""
        try:
            self.is_supported_hoster("https://example.invalid/")
        except DebridError:
            pass

    # --- interfaz (cada proveedor implementa) ---

    def authorize_pin(self):
        raise NotImplementedError

    def authorize_apikey(self, key):
        raise NotImplementedError

    def account_info(self):
        raise NotImplementedError

    def is_supported_hoster(self, url):
        raise NotImplementedError

    def resolve(self, raw_url):
        raise NotImplementedError

    def list_library(self):
        raise NotImplementedError

    def library_files(self, item_id):
        raise NotImplementedError

    def resolve_library_item(self, item_id):
        raise NotImplementedError

    def resolve_library_file(self, item_id, index):
        raise NotImplementedError

    def delete_library_item(self, item_id):
        raise NotImplementedError

    # --- utilidades de UI compartidas ---

    def _pick_video(self, videos):
        """Elige un archivo de vídeo de una lista [{name, size, ...}].
        Automático (mayor) o diálogo según ajustes."""
        if not videos:
            return None
        if self.auto_quality or len(videos) == 1:
            return max(videos, key=lambda f: f.get("size", 0) or 0)
        labels = ["{0} ({1:.2f} GB)".format(f.get("name", "?"), (f.get("size", 0) or 0) / 1e9) for f in videos]
        sel = xbmcgui.Dialog().select("Selecciona archivo", labels)
        return videos[sel] if sel >= 0 else None

    def _resolve_guard(self, fn):
        """Ejecuta una resolución capturando las excepciones de dominio y
        traduciéndolas a None (fallback) + aviso al usuario cuando procede."""
        try:
            return fn()
        except DebridAuthError as e:
            _addon().setSetting(self.PREFIX + "_authorized", "false")
            xbmcgui.Dialog().notification(self.name, "Cuenta no autorizada", xbmcgui.NOTIFICATION_WARNING, 4000)
            _log("auth: {0}".format(e), xbmc.LOGWARNING)
        except DebridNotPremium as e:
            xbmcgui.Dialog().notification(self.name, "Requiere cuenta premium", xbmcgui.NOTIFICATION_WARNING, 4000)
            _log("premium: {0}".format(e), xbmc.LOGWARNING)
        except DebridNotSupported as e:
            _log("no soportado: {0}".format(e))
        except DebridUnavailable as e:
            self.last_failure = self.FAIL_MISSING
            _log("no disponible: {0}".format(e), xbmc.LOGWARNING)
        except DebridRateLimit as e:
            self.last_failure = self.FAIL_RATE_LIMIT
            _log("rate limit: {0}".format(e), xbmc.LOGWARNING)
        except DebridError as e:
            _log("error: {0}".format(e), xbmc.LOGWARNING)
        return None

    # --- fuentes por hash (sección «Debrid Test») ---

    # Por qué resolve_source devolvió None, para que el llamador sepa si tiene sentido ofrecer
    # descargarla: solo con FAIL_UNCACHED.
    FAIL_UNCACHED = "uncached"   # no está en la caché del proveedor
    FAIL_BUSY = "busy"           # ya está en la cuenta y aún se descarga
    FAIL_MISSING = "missing"     # el torrent no tiene el fichero pedido (otro episodio, sin vídeo)
    FAIL_ERROR = "error"         # error de la API, de red o cancelación
    FAIL_RATE_LIMIT = "rate_limit"  # la API ha respondido 429 y sigue pidiendo esperar
    last_failure = None
    _OWNED_TTL = 30

    def check_cached(self, hashes):
        """{hash: True|False} de lo que el proveedor sabe contestar; un hash ausente es desconocido.

        DebridAuthError se propaga para que el llamador avise una sola vez.
        """
        return {}

    # --- almacén local de hashes ya vistos en caché ({proveedor: {hash: epoch}}) ---

    def _known_store(self):
        """Contenido del almacén, validado. Leer nunca lanza: un fichero roto es un almacén vacío."""
        try:
            with open(_KNOWN_CACHE_FILE, "r", encoding="utf-8") as f:
                raw = json.load(f)
        except (OSError, ValueError):
            return {}
        return raw if isinstance(raw, dict) else {}

    def _known_hashes(self):
        """{hash: epoch} de este proveedor sin los caducados."""
        entries = self._known_store().get(self.name)
        if not isinstance(entries, dict):
            return {}
        limite = time.time() - _KNOWN_TTL
        out = {}
        for h, ts in entries.items():
            try:
                if int(ts) >= limite:
                    out[str(h).lower()] = int(ts)
            except (TypeError, ValueError):
                continue
        return out

    def _known_add(self, info_hash):
        if not self.KNOWN_CACHE:
            return
        data = self._known_store()
        entries = data.get(self.name)
        if not isinstance(entries, dict):
            entries = {}
        entries[str(info_hash).lower()] = int(time.time())
        self._known_write(data, entries)

    def _known_remove(self, info_hash):
        if not self.KNOWN_CACHE:
            return
        data = self._known_store()
        entries = data.get(self.name)
        if not isinstance(entries, dict) or entries.pop(str(info_hash).lower(), None) is None:
            return
        self._known_write(data, entries)

    def _known_write(self, data, entries):
        """Poda al escribir: fuera los caducados y, si aún sobran, los más viejos."""
        limite = time.time() - _KNOWN_TTL
        vigentes = []
        for h, ts in entries.items():
            try:
                ts = int(ts)
            except (TypeError, ValueError):
                continue
            if ts >= limite:
                vigentes.append((str(h).lower(), ts))
        vigentes.sort(key=lambda kv: kv[1], reverse=True)
        data[self.name] = dict(vigentes[:_KNOWN_MAX])
        try:
            core_settings.atomic_write_json(_KNOWN_CACHE_FILE, data)
        except (OSError, ValueError, TypeError) as e:
            _log("caché conocida: {0}".format(e))

    def _check_known_cached(self, hashes, is_ready):
        """Hashes del almacén local o de la cuenta que el proveedor confirma listos."""
        cleaned = _clean_hashes(hashes)
        known = self._known_hashes()  # una sola lectura del fichero, no una por hash
        result = {h: True for h in cleaned if h in known}
        try:
            owned = self._owned_index()
        except DebridAuthError:
            raise
        except DebridError as e:
            _log("cuenta: {0}".format(e), xbmc.LOGWARNING)
            return result
        for h in cleaned:
            if h not in result and any(is_ready(t) for t in owned.get(h, [])):
                result[h] = True
        return result

    def resolve_source(self, info_hash, file_hint=None, episode_key=None, allow_uncached=False):
        """URL directa de un torrent identificado por su hash, o None (motivo en ``last_failure``).

        Sin allow_uncached nunca espera una descarga: lo que no esté en caché se descarta y,
        si hubo que añadirlo para saberlo, se borra. Lo que ya estaba en la cuenta no se borra.
        """
        self.last_failure = None
        if not self.is_authorized():
            self.last_failure = self.FAIL_ERROR
            return None
        url = self._resolve_guard(
            lambda: self._resolve_source(info_hash.lower(), file_hint, episode_key, allow_uncached))
        if not url and self.last_failure is None:
            self.last_failure = self.FAIL_ERROR
        if not url and not allow_uncached and self.last_failure == self.FAIL_UNCACHED:
            self._known_remove(info_hash)
        return url

    def _resolve_source(self, info_hash, file_hint, episode_key, allow_uncached):
        raise NotImplementedError

    def _fail(self, reason):
        self.last_failure = reason
        return None

    def _owned_index(self):
        """{hash: [elementos de la cuenta con ese hash]}; cada proveedor lo implementa."""
        raise NotImplementedError

    def _owned(self, info_hash):
        """Elementos de la cuenta con ese hash. La lista se pide una vez y se reutiliza 30 s:
        «Reproducir la mejor» busca hasta seis hashes seguidos. Un hash que esta instancia ha
        añadido después de pedirla obliga a pedirla de nuevo."""
        memo = getattr(self, "_owned_memo", None)
        if memo is None or time.time() - memo[0] > self._OWNED_TTL or info_hash in memo[2]:
            memo = (time.time(), self._owned_index(), set())
            self._owned_memo = memo
        return memo[1].get(info_hash, [])

    def _mark_added(self, info_hash):
        memo = getattr(self, "_owned_memo", None)
        if memo is not None:
            memo[2].add(info_hash)

    def _pick_source_file(self, videos, file_hint, episode_key):
        select_fn = None if self.auto_quality else self._select_video_dialog
        chosen = debrid_filesel.pick_video(videos, file_hint, episode_key, select_fn)
        if chosen is None:
            # Sin vídeos o sin el episodio pedido; en una película con vídeos, se canceló el selector.
            self.last_failure = self.FAIL_MISSING if (episode_key or not videos) else self.FAIL_ERROR
        return chosen

    @staticmethod
    def _select_video_dialog(videos):
        labels = [f"{v.get('name', '?')} ({(v.get('size') or 0) / 1e9:.2f} GB)" for v in videos]
        sel = xbmcgui.Dialog().select("Selecciona archivo", labels)
        return videos[sel] if sel >= 0 else None

    @staticmethod
    def _notify_busy(provider):
        xbmcgui.Dialog().notification(
            provider, "Ya se está descargando en tu nube", xbmcgui.NOTIFICATION_INFO, 4000)

    @staticmethod
    def _notify_lost(provider):
        xbmcgui.Dialog().notification(
            provider, "Se perdió la conexión. La descarga sigue en tu nube.",
            xbmcgui.NOTIFICATION_WARNING, 4000)


_HASH_RE = re.compile(r"^[0-9a-f]{40}$")


def _clean_hashes(hashes):
    """Hashes en minúsculas, válidos y sin repetir, en el orden recibido."""
    return [h for h in dict.fromkeys(str(h or "").strip().lower() for h in hashes or []) if _HASH_RE.match(h)]


def _chunks(items, size):
    return [items[i:i + size] for i in range(0, len(items), size)]


def _magnet_for(info_hash):
    return f"magnet:?xt=urn:btih:{info_hash}"


def _magnet_hash(magnet):
    m = re.search(r"urn:btih:([a-zA-Z0-9]+)", magnet, re.I)
    return m.group(1) if m else None


# ===================== AllDebrid =====================

class AllDebrid(_DebridBase):
    name = "AllDebrid"
    PREFIX = "alldebrid"
    TOKEN_KEY = "alldebrid_token"
    SUPPORTS_PIN = True
    KNOWN_CACHE = True
    BASE = "https://api.alldebrid.com/v4"
    BASE_1 = "https://api.alldebrid.com/v4.1"
    UA = "EspaTV"

    def _headers(self):
        h = {"User-Agent": self.UA}
        if self.token:
            h["Authorization"] = "Bearer {0}".format(self.token)
        return h

    def _api(self, method, base, path, data=None, params=None):
        payload = _http_json(method, base + path, self._headers(), data=data, params=params)
        if payload.get("status") == "error":
            err = payload.get("error", {})
            code = err.get("code", "")
            msg = err.get("message", code) or "error"
            if code in ("AUTH_BAD_APIKEY", "AUTH_BLOCKED", "AUTH_USER_BANNED", "AUTH_MISSING_APIKEY"):
                raise DebridAuthError(msg)
            if code in ("MUST_BE_PREMIUM", "MAGNET_MUST_BE_PREMIUM"):
                raise DebridNotPremium(msg)
            if code in ("LINK_HOST_NOT_SUPPORTED", "LINK_DOWN", "LINK_HOST_UNAVAILABLE", "LINK_NOT_SUPPORTED"):
                raise DebridNotSupported(msg)
            raise DebridError("{0} ({1})".format(msg, code))
        return payload.get("data", {})

    def authorize_pin(self):
        self.token = ""
        try:
            data = self._api("GET", self.BASE_1, "/pin/get")
        except DebridError as e:
            xbmcgui.Dialog().ok("AllDebrid", "No se pudo iniciar la vinculación:\n{0}".format(e))
            return False
        pin = data.get("pin", "")
        check = data.get("check", "")
        expires_in = int(data.get("expires_in", 600) or 600)
        base_url = data.get("base_url") or "alldebrid.com/pin/"
        apikey = _pin_poll(
            "Vincular AllDebrid", base_url, pin, expires_in,
            lambda: self._pin_check(pin, check), qr_text=data.get("user_url") or base_url)
        return self._finish_apikey(apikey) if apikey else False

    def _pin_check(self, pin, check):
        try:
            chk = self._api("POST", self.BASE, "/pin/check", data={"pin": pin, "check": check})
        except DebridError:
            return None
        return chk.get("apikey") if chk.get("activated") else None

    def authorize_apikey(self, key, silent=False):
        return self._finish_apikey((key or "").strip(), silent)

    def _finish_apikey(self, apikey, silent=False):
        if not apikey:
            return False
        self.token = apikey
        try:
            user = self._api("GET", self.BASE, "/user").get("user", {})
        except DebridError as e:
            self.token = ""
            if silent:
                _log("AllDebrid: la clave no es válida: {0}".format(e), xbmc.LOGWARNING)
            else:
                xbmcgui.Dialog().ok("AllDebrid", "La clave no es válida:\n{0}".format(e))
            return False
        self._save_auth(apikey, user.get("username", ""))
        self.warm_hosts()
        return True

    def account_info(self):
        user = self._api("GET", self.BASE, "/user").get("user", {})
        return {
            "username": user.get("username", ""),
            "premium": bool(user.get("isPremium")),
            "expiry_text": _fmt_ts(user.get("premiumUntil")),
            "days": _days_from_ts(user.get("premiumUntil")),
            "extra": "",
        }

    def _fetch_hosts(self):
        data = self._api("GET", self.BASE_1, "/user/hosts")
        hosts = data.get("hosts", {}) or {}
        patterns = []
        for value in hosts.values():
            rx = value.get("regexp")
            if isinstance(rx, list):
                rx = rx[0] if rx else None
            if rx:
                patterns.append(rx)
        return patterns

    def is_supported_hoster(self, url):
        for pat in self._host_cache(self._fetch_hosts):
            try:
                if re.search(pat, url, re.I):
                    return True
            except re.error:
                continue
        return False

    def resolve(self, raw_url):
        if not self.is_authorized():
            return None
        low = raw_url.lower()
        if low.startswith("magnet:"):
            return self._resolve_guard(lambda: self._resolve_magnet(raw_url))
        if low.endswith(".torrent"):
            return None
        if self.is_supported_hoster(raw_url):
            return self._resolve_guard(lambda: self._resolve_hoster(raw_url))
        return None

    def _resolve_hoster(self, url):
        data = self._api("POST", self.BASE, "/link/unlock", data={"link": url})
        if data.get("link"):
            return data["link"]
        if data.get("host") == "stream":
            streams = [s for s in data.get("streams", []) if "+" not in str(s.get("id", ""))]
            if not streams:
                return None
            streams.sort(key=lambda s: _safe_int(s.get("quality")), reverse=True)
            if self.auto_quality or len(streams) == 1:
                chosen = streams[0]
            else:
                sel = xbmcgui.Dialog().select("Calidad", ["{0}p".format(s.get("quality")) for s in streams])
                chosen = streams[sel] if sel >= 0 else None
            if not chosen:
                return None
            res = self._api("POST", self.BASE, "/link/streaming",
                            data={"id": data.get("id"), "stream": chosen.get("id")})
            return res.get("link")
        return None

    def _resolve_magnet(self, magnet):
        seed = _magnet_hash(magnet) or magnet
        # Un magnet que ya estaba en la cuenta es del usuario: no se borra nunca desde aquí.
        try:
            existed = bool(self._owned(str(seed).lower()))
        except DebridError as e:
            # Sin saber si ya era suyo, se da por propio y no se borra nada.
            _log("estado previo: {0}".format(e), xbmc.LOGWARNING)
            existed = True
        up = self._api("POST", self.BASE, "/magnet/upload", data={"magnets[]": seed})
        magnets = up.get("magnets") or []
        if isinstance(magnets, dict):  # la API puede devolver objeto en vez de lista
            magnets = [magnets]
        if not magnets:
            return None
        mag = magnets[0]
        mid = mag.get("id")
        created = not existed
        if created:
            self._mark_added(str(seed).lower())
        if not mag.get("ready"):
            if self.cached_only:
                if created:
                    self._delete(mid)
                return None
            if not self._wait_transfer(mid, delete_on_fail=created):
                return None
        link = self._pick_magnet_file(mid)
        if not link:
            return None
        final = self._api("POST", self.BASE, "/link/unlock", data={"link": link}).get("link")
        if self.auto_cleanup and created:
            self._delete(mid)
        return final

    def _status(self, mid):
        data = self._api("POST", self.BASE_1, "/magnet/status", data={"id": mid})
        magnets = data.get("magnets")
        if isinstance(magnets, list):
            for m in magnets:
                if str(m.get("id")) == str(mid):
                    return m
            return magnets[0] if magnets else {}
        return magnets or {}

    def _wait_transfer(self, mid, interval=5, delete_on_fail=True):
        dlg = xbmcgui.DialogProgress()
        dlg.create("AllDebrid", "Preparando el torrent en la nube...")
        fallos = 0
        try:
            while True:
                try:
                    info = self._status(mid)
                except DebridNetworkError:
                    fallos += 1
                    if fallos >= 3:
                        self._notify_lost(self.name)
                        return None
                    xbmc.sleep(interval * 1000)
                    continue
                fallos = 0
                code = info.get("statusCode", 0)
                if code == 4:
                    xbmc.sleep(2000)  # ResolveURL: dar tiempo a generar los links
                    return True
                if 5 <= code <= 10:
                    if delete_on_fail:
                        self._delete(mid)
                    return False
                size = float(info.get("size") or 0)
                done = float(info.get("downloaded") or 0)
                pct = int(done / size * 100) if size > 0 else 0
                dlg.update(pct, "{0}\n{1}".format(info.get("filename", ""), info.get("status", "")))
                if dlg.iscanceled():
                    if not xbmcgui.Dialog().yesno("AllDebrid", "¿Mantener la descarga en segundo plano?"):
                        if delete_on_fail:
                            self._delete(mid)
                    return False
                xbmc.sleep(interval * 1000)
        finally:
            dlg.close()

    def _files(self, mid):
        data = self._api("POST", self.BASE, "/magnet/files", data={"id[]": mid})
        magnets = data.get("magnets") or []
        if isinstance(magnets, dict):
            magnets = [magnets]
        files = magnets[0].get("files", []) if magnets and isinstance(magnets[0], dict) else []
        out = []
        for f in _video_files_ad(_flatten_files(files)):
            out.append({"name": f.get("n", ""), "size": f.get("s", 0), "link": f.get("l")})
        return out

    def _pick_magnet_file(self, mid):
        chosen = self._pick_video(self._files(mid))
        return chosen.get("link") if chosen else None

    def _delete(self, mid):
        if mid is None:
            return
        try:
            self._api("GET", self.BASE, "/magnet/delete", params={"id": mid})
        except DebridError as e:
            _log("delete {0}: {1}".format(mid, e), xbmc.LOGWARNING)

    # /magnet/instant desapareció de la API (404 en v4 y v4.1): la caché no se puede consultar de antemano.
    # Se recuerda en local lo que ya se vio listo; lo de la cuenta se consulta con /magnet/status.

    def check_cached(self, hashes):
        return self._check_known_cached(hashes, lambda m: _safe_int(m.get("statusCode")) == 4)

    def _owned_index(self):
        data = self._api("GET", self.BASE_1, "/magnet/status")
        magnets = data.get("magnets") or []
        if isinstance(magnets, dict):
            magnets = [magnets]
        index = {}
        for m in magnets:
            if isinstance(m, dict) and m.get("hash"):
                index.setdefault(str(m["hash"]).lower(), []).append(m)
        return index

    def _source_files(self, mid):
        for _ in range(3):
            files = self._files(mid)
            if files:
                return files
            xbmc.sleep(1000)  # AllDebrid tarda un instante en listar un magnet recién cacheado
        return []

    def _resolve_source(self, info_hash, file_hint, episode_key, allow_uncached):
        owned = self._owned(info_hash)
        # Con el mismo torrent dos veces en la cuenta, vale el que ya está listo.
        mag = next((m for m in owned if _safe_int(m.get("statusCode")) == 4), owned[0] if owned else None)
        created = mag is None
        if created:
            self._mark_added(info_hash)
            up = self._api("POST", self.BASE, "/magnet/upload", data={"magnets[]": info_hash}).get("magnets") or []
            mag = (up if isinstance(up, list) else [up])[0] if up else None
            if not isinstance(mag, dict) or mag.get("id") is None:
                return None
            ready = bool(mag.get("ready"))
        else:
            code = _safe_int(mag.get("statusCode"))
            if code != 4:
                if code < 5:
                    self._notify_busy(self.name)
                    return self._fail(self.FAIL_BUSY)
                return None
            ready = True
        mid = mag.get("id")
        if ready:
            self._known_add(info_hash)

        keep = False  # _wait_transfer ya borró o conservó la descarga si la espera no llega al final
        final = None
        try:
            if not ready:
                if not allow_uncached:
                    return self._fail(self.FAIL_UNCACHED)
                if not self._wait_transfer(mid):
                    keep = True
                    return None
            chosen = self._pick_source_file(self._source_files(mid), file_hint, episode_key)
            if chosen is None:
                return None
            final = self._api("POST", self.BASE, "/link/unlock", data={"link": chosen["link"]}).get("link")
            return final
        except Exception:
            # Aceptada la descarga, un fallo inesperado no borra lo que ya se está bajando.
            if allow_uncached:
                keep = True
            raise
        finally:
            if created and not keep and (final is None or self.auto_cleanup):
                self._delete(mid)

    def unlock(self, link):
        return self._api("POST", self.BASE, "/link/unlock", data={"link": link}).get("link")

    def list_library(self):
        data = self._api("GET", self.BASE_1, "/magnet/status")
        magnets = data.get("magnets", [])
        if not isinstance(magnets, list):
            magnets = [magnets]
        items = []
        for m in magnets:
            items.append({
                "id": m.get("id"),
                "filename": m.get("filename", ""),
                "size": m.get("size", 0),
                "ready": m.get("statusCode") == 4,
                "status": m.get("status", ""),
                "date": m.get("completionDate") or m.get("uploadDate") or 0,
            })
        items.sort(key=lambda x: x.get("date", 0), reverse=True)
        return items

    def library_files(self, item_id):
        return self._files(item_id)

    def resolve_library_item(self, item_id):
        link = self._pick_magnet_file(item_id)
        return self.unlock(link) if link else None

    def resolve_library_file(self, item_id, index):
        files = self._files(item_id)
        if 0 <= index < len(files):
            return self.unlock(files[index].get("link"))
        return None

    def delete_library_item(self, item_id):
        self._delete(item_id)
        return True


# ===================== Real-Debrid =====================

class RealDebrid(_DebridBase):
    name = "Real-Debrid"
    PREFIX = "realdebrid"
    TOKEN_KEY = "realdebrid_token"
    SUPPORTS_PIN = True
    KNOWN_CACHE = True
    BASE = "https://api.real-debrid.com/rest/1.0"
    OAUTH = "https://api.real-debrid.com/oauth/v2"
    CLIENT_ID = "X245A4XAIBGVM"
    UA = "EspaTV"

    def __init__(self):
        super().__init__()
        self._access = None

    def _access_token(self):
        """El token guardado es base64('client_id:client_secret:refresh_token')
        (OAuth, se refresca en cada arranque) o un API token plano de la web."""
        if self._access:
            return self._access
        raw = self.token
        parts = []
        try:
            parts = base64.b64decode(raw).decode().split(":")
        except (ValueError, UnicodeDecodeError):  # binascii.Error hereda de ValueError
            parts = []
        if len(parts) == 3 and all(parts):
            cid, csec, refresh = parts
            tok = _http_json("POST", self.OAUTH + "/token", {"User-Agent": self.UA}, data={
                "client_id": cid, "client_secret": csec,
                "code": refresh, "grant_type": "http://oauth.net/grant_type/device/1.0",
            })
            self._access = tok.get("access_token")
            if not self._access:
                raise DebridAuthError("refresh fallido")
        else:
            self._access = raw  # API token directo (real-debrid.com/apitoken)
        return self._access

    def _headers(self, auth=True):
        h = {"User-Agent": self.UA}
        if auth:
            h["Authorization"] = "Bearer {0}".format(self._access_token())
        return h

    def _api(self, method, path, data=None, params=None, auth=True, _retry=True):
        payload = _http_json(method, self.BASE + path, self._headers(auth), data=data, params=params)
        if isinstance(payload, dict) and "error_code" in payload:
            # error_code 8 = token expirado. Si es OAuth, refrescar y reintentar una vez
            # (cubre sesiones largas, p.ej. polling de una descarga > 1h) antes de fallar.
            if payload.get("error_code") == 8 and auth and _retry:
                self._access = None
                return self._api(method, path, data=data, params=params, auth=auth, _retry=False)
            self._raise_rd(payload)
        return payload

    @staticmethod
    def _raise_rd(payload):
        code = payload.get("error_code")
        msg = payload.get("error") or "Real-Debrid error {0}".format(code)
        if code == 8:
            raise DebridAuthError(msg)
        if code in (16, 17, 19, 20):
            raise DebridNotSupported(msg)
        if code in (5, 34):
            raise DebridRateLimit(msg)
        if code == 21:
            raise DebridError("Tienes demasiadas descargas activas en Real-Debrid")
        if code == 35:
            raise DebridUnavailable(msg)
        if code in (23, 36):
            raise DebridNotPremium(msg)
        if code == 24:
            raise DebridNotSupported(msg)
        raise DebridError("{0} (code {1})".format(msg, code))

    def authorize_pin(self):
        oauth = _http_json("GET", self.OAUTH + "/device/code", {"User-Agent": self.UA},
                           params={"client_id": self.CLIENT_ID, "new_credentials": "yes"})
        device_code = oauth.get("device_code")
        user_code = oauth.get("user_code", "")
        url = oauth.get("direct_verification_url") or oauth.get("verification_url") or "real-debrid.com/device"
        expires_in = int(oauth.get("expires_in", 1800) or 1800)
        interval = int(oauth.get("interval", 5) or 5)
        if not device_code:
            xbmcgui.Dialog().ok("Real-Debrid", "No se pudo iniciar la vinculación.")
            return False

        creds = {}
        def _check():
            res = _http_json("GET", self.OAUTH + "/device/credentials", {"User-Agent": self.UA},
                             params={"client_id": self.CLIENT_ID, "code": device_code})
            if res.get("client_secret"):
                creds["id"] = res["client_id"]
                creds["secret"] = res["client_secret"]
                return True  # señal de activado
            return None

        got = _pin_poll("Vincular Real-Debrid", url, user_code, expires_in, _check, interval=interval,
                        qr_text=oauth.get("direct_verification_url"))
        if not got or "secret" not in creds:
            return False
        tok = _http_json("POST", self.OAUTH + "/token", {"User-Agent": self.UA}, data={
            "client_id": creds["id"], "client_secret": creds["secret"],
            "code": device_code, "grant_type": "http://oauth.net/grant_type/device/1.0",
        })
        if not tok.get("refresh_token"):
            xbmcgui.Dialog().ok("Real-Debrid", "No se obtuvo el token.")
            return False
        stored = base64.b64encode(
            "{0}:{1}:{2}".format(creds["id"], creds["secret"], tok["refresh_token"]).encode()).decode()
        return self._finish_token(stored)

    def authorize_apikey(self, key, silent=False):
        return self._finish_token((key or "").strip(), silent)

    def _finish_token(self, token, silent=False):
        if not token:
            return False
        self.token = token
        self._access = None
        try:
            user = self._api("GET", "/user")
        except DebridError as e:
            self.token = ""
            if silent:
                _log("Real-Debrid: token no válido: {0}".format(e), xbmc.LOGWARNING)
            else:
                xbmcgui.Dialog().ok("Real-Debrid", "Token no válido:\n{0}".format(e))
            return False
        self._save_auth(token, user.get("username", ""))
        self.warm_hosts()
        return True

    def account_info(self):
        user = self._api("GET", "/user")
        exp = user.get("expiration", "") or ""
        return {
            "username": user.get("username", ""),
            "premium": user.get("type") == "premium",
            "expiry_text": exp[:10],
            "days": _days_from_iso(exp),
            "extra": "",
        }

    def _fetch_hosts(self):
        domains = _http_json("GET", self.BASE + "/hosts/domains", self._headers())
        return domains if isinstance(domains, list) else []

    def is_supported_hoster(self, url):
        try:
            host = (urllib.parse.urlparse(url).hostname or "").replace("www.", "")
        except ValueError:
            return False
        if not host:
            return False
        return any(host in d or d in host for d in self._host_cache(self._fetch_hosts))

    def resolve(self, raw_url):
        if not self.is_authorized():
            return None
        low = raw_url.lower()
        if low.startswith("magnet:"):
            return self._resolve_guard(lambda: self._resolve_magnet(raw_url))
        if low.endswith(".torrent"):
            return None
        if self.is_supported_hoster(raw_url):
            return self._resolve_guard(lambda: self._resolve_hoster(raw_url))
        return None

    def _resolve_hoster(self, url):
        res = self._api("POST", "/unrestrict/link", data={"link": url})
        return res.get("download")

    def _resolve_magnet(self, magnet):
        # No se usa /torrents/instantAvailability (RD lo dejó inservible en 2024).
        # En su lugar: añadir, seleccionar el fichero que se va a reproducir, y mirar el
        # estado una vez; si ya está "downloaded" estaba cacheado. Con cached_only, si no
        # lo está, se borra.
        added = self._api("POST", "/torrents/addMagnet", data={"magnet": magnet})
        tid = added.get("id")
        if not tid:
            return None
        info = self._wait_file_list(tid, 15)
        if info is None:
            self._delete(tid)
            return None
        chosen = self._pick_source_file(self._rd_videos(info), None, None)
        if chosen is None:
            self._delete(tid)
            return None
        self._api("POST", "/torrents/selectFiles/{0}".format(tid), data={"files": str(chosen["id"])})
        info = self._settled_info(tid)
        if info.get("status") == "downloaded":
            link = self._link_for(info, chosen["id"])
            if not link:
                self._delete(tid)
                return None
        elif self.cached_only:
            self._delete(tid)
            return None
        else:
            link = self._wait_and_pick(tid)  # la espera ya decide si se borra o se conserva
            if not link:
                return None
        final = self._api("POST", "/unrestrict/link", data={"link": link}).get("download")
        if self.auto_cleanup:
            self._delete(tid)
        return final

    def _wait_and_pick(self, tid, interval=3):
        dlg = xbmcgui.DialogProgress()
        dlg.create("Real-Debrid", "Preparando el torrent en la nube...")
        fallos = 0
        try:
            while True:
                try:
                    info = self._api("GET", "/torrents/info/{0}".format(tid))
                except DebridNetworkError:
                    fallos += 1
                    if fallos >= 3:
                        self._notify_lost(self.name)
                        return None
                    xbmc.sleep(interval * 1000)
                    continue
                fallos = 0
                status = info.get("status", "")
                if status == "downloaded":
                    return self._pick_link(info)
                if status in ("error", "magnet_error", "virus", "dead"):
                    self._delete(tid)
                    return None
                pct = int(info.get("progress", 0) or 0)
                dlg.update(pct, "{0}\n{1}".format(info.get("filename", ""), status))
                if dlg.iscanceled():
                    if not xbmcgui.Dialog().yesno("Real-Debrid", "¿Mantener la descarga en segundo plano?"):
                        self._delete(tid)
                    return None
                xbmc.sleep(interval * 1000)
        finally:
            dlg.close()

    @staticmethod
    def _pick_link(info):
        """Mapea el mayor archivo de vídeo seleccionado a su link RD."""
        files = info.get("files", [])
        links = info.get("links", [])
        selected = [f for f in files if f.get("selected")]
        # 'links' va en paralelo a los archivos seleccionados, en orden
        if len(links) != len(selected):
            return None  # un RAR o varios ficheros seleccionados: no se puede emparejar
        best_idx, best_size = -1, -1
        for i, f in enumerate(selected):
            if _is_video_name(f.get("path", "")) and (f.get("bytes", 0) or 0) > best_size:
                best_size = f.get("bytes", 0) or 0
                best_idx = i
        if best_idx < 0:
            best_idx = 0
        return links[best_idx] if links else None

    def _delete(self, tid):
        if tid is None:
            return
        try:
            self._api("DELETE", "/torrents/delete/{0}".format(tid))
        except DebridError as e:
            _log("delete {0}: {1}".format(tid, e), xbmc.LOGWARNING)

    # Real-Debrid no tiene consulta de caché (instantAvailability murió en 2024): se añade el magnet,
    # se elige un solo fichero y se mira si pasa a "downloaded". Lo ya visto se recuerda en local.

    def check_cached(self, hashes):
        return self._check_known_cached(
            # En /torrents, `links` es la lista de enlaces (uno por fichero seleccionado).
            hashes, lambda t: t.get("status") == "downloaded" and len(t.get("links") or []) == 1)

    _RD_DEAD = ("magnet_error", "virus", "dead", "error")

    @staticmethod
    def _rd_videos(info):
        return [
            {"id": f.get("id"), "name": f.get("path", ""), "size": f.get("bytes") or 0}
            for f in info.get("files") or [] if _is_video_name(f.get("path", ""))
        ]

    @staticmethod
    def _link_for(info, file_id):
        """`links` va en paralelo a los ficheros seleccionados. Solo vale el enlace de ese fichero."""
        selected = [f for f in info.get("files") or [] if f.get("selected")]
        links = info.get("links") or []
        if len(links) != len(selected):
            return None
        for i, f in enumerate(selected):
            if str(f.get("id")) == str(file_id):
                return links[i]
        return None

    def _unrestrict_source(self, info, file_id):
        link = self._link_for(info, file_id)
        return self._api("POST", "/unrestrict/link", data={"link": link}).get("download") if link else None

    def _wait_file_list(self, tid, tries):
        """Info del torrent cuando ya lista sus ficheros (un intento por segundo); None si no llega."""
        for _ in range(tries):
            info = self._api("GET", "/torrents/info/{0}".format(tid))
            if info.get("status") in self._RD_DEAD:
                return None
            if info.get("files") and info.get("status") in ("waiting_files_selection", "downloading", "downloaded"):
                return info
            xbmc.sleep(1000)
        return None

    def _settled_info(self, tid):
        """Info tras selectFiles; un torrent en caché pasa a "downloaded" en un par de segundos."""
        info = {}
        for _ in range(8):
            info = self._api("GET", "/torrents/info/{0}".format(tid))
            if info.get("status") not in (
                    "magnet_conversion", "queued", "waiting_files_selection", "compressing", "uploading"):
                break
            xbmc.sleep(1000)
        return info

    def _wait_downloaded(self, tid, interval=3):
        """Espera con progreso. None si falla o se cancela (ya borrada o conservada según el usuario)."""
        dlg = xbmcgui.DialogProgress()
        dlg.create(self.name, "Preparando el torrent en la nube...")
        fallos = 0
        try:
            while True:
                try:
                    info = self._api("GET", "/torrents/info/{0}".format(tid))
                except DebridNetworkError:
                    fallos += 1
                    if fallos >= 3:
                        self._notify_lost(self.name)
                        return None
                    xbmc.sleep(interval * 1000)
                    continue
                fallos = 0
                status = info.get("status", "")
                if status == "downloaded":
                    return info
                if status in self._RD_DEAD:
                    self._delete(tid)
                    return None
                dlg.update(int(info.get("progress", 0) or 0), "{0}\n{1}".format(info.get("filename", ""), status))
                if dlg.iscanceled():
                    if not xbmcgui.Dialog().yesno(self.name, "¿Mantener la descarga en segundo plano?"):
                        self._delete(tid)
                    return None
                xbmc.sleep(interval * 1000)
        finally:
            dlg.close()

    def _reuse_source(self, info_hash, file_hint, episode_key):
        """(enlace, hay_descarga_en_curso). Reutiliza un torrent propio ya descargado que tenga seleccionado
        el fichero pedido; otro episodio del mismo pack no sirve."""
        busy = False
        for t in self._owned(info_hash):
            if t.get("status") == "downloaded":
                info = self._api("GET", "/torrents/info/{0}".format(t.get("id")))
                chosen = self._pick_source_file(self._rd_videos(info), file_hint, episode_key)
                if chosen is not None:
                    link = self._unrestrict_source(info, chosen["id"])
                    if link:
                        return link, False
            elif t.get("status") in (
                    "downloading", "queued", "compressing", "uploading", "magnet_conversion", "waiting_files_selection"):
                busy = True
        return None, busy

    def _owned_index(self):
        torrents = self._paged("/torrents")
        index = {}
        for t in torrents if isinstance(torrents, list) else []:
            if isinstance(t, dict) and t.get("hash"):
                index.setdefault(str(t["hash"]).lower(), []).append(t)
        return index

    def _paged(self, path):
        """Todas las páginas de un listado de RD. Un 204 llega como {} y corta el bucle."""
        items = []
        for page in range(1, _RD_MAX_PAGES + 1):
            try:
                data = self._api("GET", path, params={"page": page, "limit": _RD_PAGE})
            except DebridError as e:
                if page == 1:
                    raise
                _log("paginando {0}, página {1}: {2}".format(path, page, e), xbmc.LOGWARNING)
                return items
            if not isinstance(data, list):
                break
            items.extend(data)
            if len(data) < _RD_PAGE:
                break
        return items

    def _resolve_source(self, info_hash, file_hint, episode_key, allow_uncached):
        link, busy = self._reuse_source(info_hash, file_hint, episode_key)
        if link:
            return link  # ya era del usuario: nunca se borra
        if busy:
            self._notify_busy(self.name)
            return self._fail(self.FAIL_BUSY)
        self.last_failure = None  # lo que dijera _reuse_source de un torrent propio ya no cuenta

        self._mark_added(info_hash)
        tid = self._api("POST", "/torrents/addMagnet", data={"magnet": _magnet_for(info_hash)}).get("id")
        if not tid:
            return None
        keep = False  # _wait_downloaded ya borró o conservó la descarga si la espera no llega al final
        final = None
        try:
            # Un magnet en caché lista sus ficheros al momento; esperar más solo tiene sentido si se
            # va a descargar.
            info = self._wait_file_list(tid, 15 if allow_uncached else 8)
            if info is None:
                return self._fail(self.FAIL_ERROR if allow_uncached else self.FAIL_UNCACHED)
            chosen = self._pick_source_file(self._rd_videos(info), file_hint, episode_key)
            if chosen is None:
                return None
            self._api("POST", "/torrents/selectFiles/{0}".format(tid), data={"files": str(chosen["id"])})
            info = self._settled_info(tid)
            if info.get("status") == "downloaded":
                # Un pack no se marca: la caché conocida solo sirve para un único vídeo.
                if len(self._rd_videos(info)) == 1:
                    self._known_add(info_hash)
            else:
                if not allow_uncached:
                    return self._fail(self.FAIL_UNCACHED)
                info = self._wait_downloaded(tid)
                if info is None:
                    keep = True
                    return None
            final = self._unrestrict_source(info, chosen["id"])
            return final
        except Exception:
            # Aceptada la descarga, un fallo inesperado no borra lo que ya se está bajando.
            if allow_uncached:
                keep = True
            raise
        finally:
            if not keep and (final is None or self.auto_cleanup):
                self._delete(tid)

    def list_library(self):
        items = []
        for t in self._paged("/torrents"):
            if not isinstance(t, dict):
                continue
            items.append({
                "id": t.get("id"),
                "filename": t.get("filename", ""),
                "size": t.get("bytes", 0),
                "ready": t.get("status") == "downloaded",
                "status": t.get("status", ""),
                "date": t.get("added", ""),
            })
        return items

    def library_files(self, item_id):
        info = self._api("GET", "/torrents/info/{0}".format(item_id))
        out = []
        for v in self._rd_videos(info):
            link = self._link_for(info, v["id"])
            if link:
                out.append({"name": (v["name"] or "").split("/")[-1], "size": v["size"], "link": link})
        return out

    def resolve_library_item(self, item_id):
        chosen = self._pick_video(self.library_files(item_id))
        if not chosen:
            return None
        return self._api("POST", "/unrestrict/link", data={"link": chosen["link"]}).get("download")

    def resolve_library_file(self, item_id, index):
        files = self.library_files(item_id)
        if 0 <= index < len(files):
            return self._api("POST", "/unrestrict/link", data={"link": files[index]["link"]}).get("download")
        return None

    def delete_library_item(self, item_id):
        self._delete(item_id)
        return True


# ===================== TorBox =====================

class TorBox(_DebridBase):
    name = "TorBox"
    PREFIX = "torbox"
    TOKEN_KEY = "torbox_token"
    BASE = "https://api.torbox.app/v1/api"
    UA = "EspaTV"

    def _headers(self):
        h = {"User-Agent": self.UA, "Accept": "application/json"}
        if self.token:
            h["Authorization"] = "Bearer {0}".format(self.token)
        return h

    def _api(self, method, path, data=None, params=None, json_body=None):
        payload = _http_json(method, self.BASE + path, self._headers(),
                             data=data, params=params, json_body=json_body)
        if isinstance(payload, dict) and payload.get("success") is False:
            err = payload.get("error") or ""
            detail = payload.get("detail", "")
            if err in ("BAD_TOKEN", "AUTH_ERROR", "OAUTH_VERIFICATION_ERROR"):
                raise DebridAuthError(detail or err)
            if err == "ACTIVE_LIMIT":
                lleno = DebridError("Tienes demasiadas descargas activas en TorBox")
                lleno.code = err  # createtorrent lo relanza: no es "no está en caché"
                raise lleno
            if err == "COOLDOWN_LIMIT":
                raise DebridRateLimit(detail or err)
            if err in ("MONTHLY_LIMIT", "DOWNLOAD_TOO_LARGE", "PLAN_RESTRICTED_FEATURE"):
                raise DebridNotPremium(detail or err)
            raise DebridError("{0} {1}".format(err, detail).strip())
        return payload.get("data") if isinstance(payload, dict) else payload

    def authorize_apikey(self, key, silent=False):
        key = (key or "").strip()
        if not key:
            return False
        self.token = key
        try:
            data = self._api("GET", "/user/me")
        except DebridError as e:
            self.token = ""
            if silent:
                _log("TorBox: API key no válida: {0}".format(e), xbmc.LOGWARNING)
            else:
                xbmcgui.Dialog().ok("TorBox", "API key no válida:\n{0}".format(e))
            return False
        self._save_auth(key, (data or {}).get("email", ""))
        self.warm_hosts()
        return True

    def authorize_pin(self):
        # TorBox: se utiliza la API key manual (torbox.app/settings/api).
        xbmcgui.Dialog().ok(
            "TorBox",
            "Copia tu API key desde torbox.app (Settings > API) y usa\n"
            "'Introducir API Key manualmente'.")
        return False

    def account_info(self):
        data = self._api("GET", "/user/me") or {}
        exp = data.get("premium_expires_at", "") or ""
        # Caducidad como texto AAAA-MM-DD: sin strptime, que no es fiable en Kodi.
        premium = _safe_int(data.get("plan")) > 0 and exp[:10] > time.strftime("%Y-%m-%d")
        return {
            "username": data.get("email", ""),
            "premium": premium,
            "expiry_text": exp[:10],
            "days": _days_from_iso(exp),
            "extra": "",
        }

    def _fetch_hosts(self):
        try:
            result = self._api("GET", "/webdl/hosters")
        except DebridError:
            return []
        patterns = []
        for h in result or []:
            if not h.get("status", False):
                continue
            domains = h.get("domains") or []
            if domains:
                patterns.extend(domains)
            elif h.get("regex"):
                patterns.append(h["regex"])
        return patterns

    def is_supported_hoster(self, url):
        try:
            host = (urllib.parse.urlparse(url).hostname or "").replace("www.", "")
        except ValueError:
            return False
        if not host:
            return False
        for pat in self._host_cache(self._fetch_hosts):
            try:
                if re.search(pat, url, re.I):
                    return True
            except re.error:
                if host in pat or pat in host:
                    return True
        return False

    def resolve(self, raw_url):
        if not self.is_authorized():
            return None
        low = raw_url.lower()
        if low.startswith("magnet:"):
            return self._resolve_guard(lambda: self._resolve_magnet(raw_url))
        if low.endswith(".torrent"):
            return None
        if self.is_supported_hoster(raw_url):
            return self._resolve_guard(lambda: self._resolve_webdl(raw_url))
        return None

    def _resolve_magnet(self, magnet):
        _hash = _magnet_hash(magnet)
        if self.cached_only and _hash:
            cached = self._api("GET", "/torrents/checkcached",
                               params={"hash": _hash, "format": "list", "list_files": "false"})
            if not cached:
                return None
        created = self._api("POST", "/torrents/createtorrent",
                            data={"magnet": magnet, "seed": 3, "allow_zip": "false"})
        tid = (created or {}).get("torrent_id")
        if tid is None:
            return None
        if not self._wait_ready(tid, "torrents"):
            return None
        info = self._torrent_info(tid)
        files = [f for f in info.get("files", []) if _is_video_name(f.get("name", ""))]
        chosen = self._pick_video([{"name": f.get("name"), "size": f.get("size"), "id": f.get("id")} for f in files])
        if not chosen:
            return None
        link = self._api("GET", "/torrents/requestdl",
                         params={"token": self.token, "torrent_id": tid, "file_id": chosen.get("id")})
        # Sin borrar tras requestdl: no está comprobado que el enlace sobreviva al torrent.
        return link if isinstance(link, str) else None

    def _resolve_webdl(self, url):
        created = self._api("POST", "/webdl/createwebdownload", data={"link": url})
        wid = (created or {}).get("webdownload_id")
        if wid is None:
            return None
        if not self._wait_ready(wid, "webdl"):
            return None
        info = self._api("GET", "/webdl/mylist", params={"id": wid, "bypass_cache": "true"}) or {}
        files = info.get("files", []) if isinstance(info, dict) else []
        file_id = files[0].get("id") if files else 0
        link = self._api("GET", "/webdl/requestdl",
                         params={"token": self.token, "web_id": wid, "file_id": file_id})
        # Igual que con los torrents: borrar justo después de pedir el enlace puede dejarlo seco.
        return link if isinstance(link, str) else None

    def _torrent_info(self, tid):
        info = self._api("GET", "/torrents/mylist", params={"id": tid, "bypass_cache": "true"})
        if isinstance(info, list):
            return info[0] if info else {}
        return info or {}

    def _wait_ready(self, item_id, kind, interval=2):
        dlg = xbmcgui.DialogProgress()
        dlg.create("TorBox", "Preparando en la nube...")
        path = "/torrents/mylist" if kind == "torrents" else "/webdl/mylist"
        fallos = 0
        caducado = 0
        inicio = time.time()
        try:
            while True:
                try:
                    info = self._api("GET", path, params={"id": item_id, "bypass_cache": "true"})
                except DebridNetworkError:
                    fallos += 1
                    if fallos >= 3:
                        self._notify_lost(self.name)
                        return None
                    xbmc.sleep(interval * 1000)
                    continue
                fallos = 0
                if isinstance(info, list):
                    info = info[0] if info else {}
                info = info or {}
                presente = bool(info.get("download_present"))
                # Si la API no manda download_finished se mantiene el criterio de antes.
                if presente and info.get("files") and info.get("download_finished", True):
                    return True
                # Un torrent recién añadido puede verse así un instante: solo es caducado si se repite.
                if info.get("download_finished") and not presente:
                    caducado += 1
                    if caducado >= 3:
                        xbmcgui.Dialog().notification(
                            self.name, "La descarga ha caducado en tu nube",
                            xbmcgui.NOTIFICATION_WARNING, 4000)
                        return False
                else:
                    caducado = 0
                if time.time() - inicio >= _TB_WAIT_S:
                    xbmcgui.Dialog().notification(
                        self.name, "La descarga tarda demasiado; inténtalo más tarde",
                        xbmcgui.NOTIFICATION_WARNING, 4000)
                    return False
                pct = int((info.get("progress", 0) or 0) * 100)
                dlg.update(pct, "{0}\n{1}".format(info.get("name", ""), info.get("download_state", "")))
                if dlg.iscanceled():
                    if not xbmcgui.Dialog().yesno("TorBox", "¿Mantener la descarga en segundo plano?"):
                        if kind == "torrents":
                            self._delete_torrent(item_id)
                    return False
                xbmc.sleep(interval * 1000)
        finally:
            dlg.close()

    def _delete_torrent(self, tid):
        if tid is None:
            return
        try:
            self._api("POST", "/torrents/controltorrent", json_body={"torrent_id": tid, "operation": "delete"})
        except DebridError as e:
            _log("delete {0}: {1}".format(tid, e), xbmc.LOGWARNING)

    def check_cached(self, hashes):
        result = {}
        for batch in _chunks(_clean_hashes(hashes), 100):
            try:
                data = self._api("POST", "/torrents/checkcached",
                                 params={"format": "list", "list_files": "false"},
                                 json_body={"hashes": batch})
            except DebridAuthError:
                raise
            except DebridError as e:
                _log("checkcached: {0}".format(e), xbmc.LOGWARNING)
                continue
            if isinstance(data, dict):
                found = {str(k).lower() for k in data}
            else:
                found = {str(i.get("hash") if isinstance(i, dict) else i).lower() for i in data or []}
            result.update({h: h in found for h in batch})
        return result

    def _mylist_all(self):
        """Todos los torrents de la cuenta: la API devuelve como mucho 1000 por página."""
        out = []
        for pagina in range(5):
            data = self._api("GET", "/torrents/mylist",
                             params={"bypass_cache": "true", "limit": 1000, "offset": pagina * 1000})
            torrents = data if isinstance(data, list) else (data.get("torrents") if isinstance(data, dict) else [])
            torrents = torrents or []
            out.extend(torrents)
            if len(torrents) < 1000:
                break
        return out

    def _owned_index(self):
        index = {}
        for t in self._mylist_all():
            if isinstance(t, dict) and t.get("hash"):
                index.setdefault(str(t["hash"]).lower(), []).append(t)
        return index

    def _resolve_source(self, info_hash, file_hint, episode_key, allow_uncached):
        owned = self._owned(info_hash)
        # Con el mismo torrent dos veces en la cuenta, vale el que ya está listo.
        existing = next((t for t in owned if t.get("download_present")), owned[0] if owned else None)
        created = existing is None
        if created:
            self._mark_added(info_hash)
            body = {"magnet": _magnet_for(info_hash), "seed": 3, "allow_zip": "false",
                    "add_only_if_cached": "false" if allow_uncached else "true"}
            tid = None
            try:
                creado = self._api("POST", "/torrents/createtorrent", data=body) or {}
                tid = creado.get("torrent_id")
                if tid is None and creado.get("queued_id") is not None:
                    xbmcgui.Dialog().notification(
                        self.name, "Tu cuenta tiene la cola llena; se añadirá cuando haya hueco",
                        xbmcgui.NOTIFICATION_INFO, 4000)
                    return self._fail(self.FAIL_BUSY)
            except DebridError as e:
                if isinstance(e, (DebridAuthError, DebridNotPremium, DebridRateLimit, DebridNetworkError)) \
                        or getattr(e, "code", "") == "ACTIVE_LIMIT":
                    raise
                # Duplicado: se localiza el existente (el texto exacto del error está por verificar).
                if any(w in str(e).lower() for w in ("exist", "already")):
                    owned = self._owned(info_hash)
                    existing = owned[0] if owned else None
                if existing is None:
                    if not allow_uncached:
                        # Con add_only_if_cached, TorBox responde con un error si no está en caché.
                        _log("createtorrent: {0}".format(e))
                        return self._fail(self.FAIL_UNCACHED)
                    raise
                created = False
        if not created:
            if not existing.get("download_present"):
                self._notify_busy(self.name)
                return self._fail(self.FAIL_BUSY)
            tid = existing.get("id")
        if tid is None:
            return None

        keep = False  # _wait_ready ya borró o conservó la descarga si la espera no llega al final
        final = None
        try:
            info = self._torrent_info(tid)
            if not info.get("download_present"):
                if not allow_uncached:
                    return self._fail(self.FAIL_UNCACHED)
                if not self._wait_ready(tid, "torrents"):
                    keep = True
                    return None
                info = self._torrent_info(tid)
            videos = [{"id": f.get("id"), "name": f.get("name", ""), "size": f.get("size") or 0}
                      for f in info.get("files") or [] if _is_video_name(f.get("name", ""))]
            chosen = self._pick_source_file(videos, file_hint, episode_key)
            if chosen is None:
                return None
            final = self._requestdl(tid, chosen["id"])
            return final
        except Exception:
            # Aceptada la descarga, un fallo inesperado no borra lo que ya se está bajando.
            if allow_uncached:
                keep = True
            raise
        finally:
            # Sin borrar tras requestdl: no está comprobado que el enlace sobreviva al torrent.
            if created and not keep and final is None:
                self._delete_torrent(tid)

    def list_library(self):
        items = []
        for t in self._mylist_all():
            items.append({
                "id": t.get("id"),
                "filename": t.get("name", ""),
                "size": t.get("size", 0),
                "ready": bool(t.get("download_present")),
                "status": t.get("download_state", ""),
                "date": t.get("created_at", "") or "",
            })
        return items

    def library_files(self, item_id):
        info = self._torrent_info(item_id)
        out = []
        for f in info.get("files", []):
            if _is_video_name(f.get("name", "")):
                out.append({"name": f.get("name"), "size": f.get("size", 0), "id": f.get("id")})
        return out

    def _requestdl(self, item_id, file_id):
        link = self._api("GET", "/torrents/requestdl",
                         params={"token": self.token, "torrent_id": item_id, "file_id": file_id})
        return link if isinstance(link, str) else None

    def resolve_library_item(self, item_id):
        chosen = self._pick_video(self.library_files(item_id))
        return self._requestdl(item_id, chosen.get("id")) if chosen else None

    def resolve_library_file(self, item_id, index):
        files = self.library_files(item_id)
        if 0 <= index < len(files):
            return self._requestdl(item_id, files[index].get("id"))
        return None

    def delete_library_item(self, item_id):
        self._delete_torrent(item_id)
        return True


# ===================== Premiumize =====================

class Premiumize(_DebridBase):
    name = "Premiumize"
    PREFIX = "premiumize"
    TOKEN_KEY = "premiumize_token"
    SUPPORTS_PIN = False  # solo API key del usuario (sin client_id de terceros)
    BASE = "https://www.premiumize.me/api"
    UA = "EspaTV"

    def _headers(self):
        h = {"User-Agent": self.UA, "Accept": "application/json"}
        if self.token:
            h["Authorization"] = "Bearer {0}".format(self.token)
        return h

    def _api(self, method, path, data=None, params=None):
        payload = _http_json(method, self.BASE + path, self._headers(), data=data, params=params)
        if isinstance(payload, dict) and payload.get("status") == "error":
            msg = payload.get("message", "error")
            # El código manda; el texto queda solo como respaldo.
            if payload.get("code") in ("authentication_failed", "permission_denied"):
                raise DebridAuthError(msg)
            if "not logged in" in msg.lower() or "token" in msg.lower():
                raise DebridAuthError(msg)
            raise DebridError(msg)
        return payload

    def authorize_pin(self):
        # Premiumize se autentica con la API key del panel del usuario (sin OAuth
        # de terceros). El device flow requeriría un client_id propio registrado.
        xbmcgui.Dialog().ok(
            "Premiumize",
            "Copia tu API key desde premiumize.me/account (Apikey) y usa\n"
            "'Introducir API Key manualmente'.")
        return False

    def authorize_apikey(self, key, silent=False):
        return self._finish_token((key or "").strip(), silent)

    def _finish_token(self, token, silent=False):
        if not token:
            return False
        self.token = token
        try:
            acc = self._api("GET", "/account/info")
        except DebridError as e:
            self.token = ""
            if silent:
                _log("Premiumize: token no válido: {0}".format(e), xbmc.LOGWARNING)
            else:
                xbmcgui.Dialog().ok("Premiumize", "Token no válido:\n{0}".format(e))
            return False
        self._save_auth(token, acc.get("customer_id", ""))
        self.warm_hosts()
        return True

    def account_info(self):
        acc = self._api("GET", "/account/info")
        limit = acc.get("limit_used")
        extra = "Uso fair-use: {0:.0f}%".format(float(limit) * 100) if isinstance(limit, (int, float)) else ""
        return {
            "username": str(acc.get("customer_id", "")),
            "premium": _safe_int(acc.get("premium_until")) > time.time(),
            "expiry_text": _fmt_ts(acc.get("premium_until")),
            "days": _days_from_ts(acc.get("premium_until")),
            "extra": extra,
        }

    def _fetch_hosts(self):
        result = self._api("GET", "/services/list")
        patterns = []
        for regexes in (result.get("regexpatterns", {}) or {}).values():
            for rx in regexes:
                patterns.append(rx)
        return patterns

    def is_supported_hoster(self, url):
        if not url.endswith("/"):
            url += "/"
        for pat in self._host_cache(self._fetch_hosts):
            try:
                if re.search(pat, url, re.I):
                    return True
            except re.error:
                continue
        return False

    def resolve(self, raw_url):
        if not self.is_authorized():
            return None
        low = raw_url.lower()
        if low.startswith("magnet:") or low.endswith(".torrent"):
            return self._resolve_guard(lambda: self._resolve_src(raw_url, torrent=True))
        if self.is_supported_hoster(raw_url):
            return self._resolve_guard(lambda: self._resolve_src(raw_url, torrent=False))
        return None

    def _check_cache(self, media_id):
        try:
            res = self._api("GET", "/cache/check", params={"items[]": media_id})
        except DebridError:
            return False
        resp = res.get("response")
        return bool(resp[0]) if isinstance(resp, list) and resp else False

    def _resolve_src(self, media_id, torrent):
        # El cache check solo aplica a torrents; un hoster va directo a directdl.
        if torrent and not self._check_cache(media_id):
            if self.cached_only:
                return None
            if not self._wait_transfer(media_id):
                return None
        res = self._api("POST", "/transfer/directdl", data={"src": media_id})
        if res.get("status") != "success":
            return None
        if not torrent:
            link = res.get("location") or res.get("stream_link")
            return link if link and link != media_id else None
        videos = [
            {"name": (c.get("path") or "").split("/")[-1], "size": _safe_int(c.get("size")),
             "link": c.get("link") or c.get("stream_link")}
            for c in res.get("content") or []
            if _is_video_name(c.get("path", "")) and (c.get("link") or c.get("stream_link"))
        ]
        chosen = self._pick_video(videos)
        return chosen.get("link") if chosen and chosen["link"] != media_id else None

    def _wait_transfer(self, media_id, interval=5):
        create = self._api("POST", "/transfer/create", data={"src": media_id})
        if create.get("status") != "success":
            return False
        tid = create.get("id")
        dlg = xbmcgui.DialogProgress()
        dlg.create("Premiumize", "Transfiriendo a la nube...")
        fallos = 0
        vacias = 0
        try:
            while True:
                try:
                    info = self._transfer(tid)
                except DebridNetworkError:
                    fallos += 1
                    if fallos >= 3:
                        self._notify_lost(self.name)
                        return None
                    xbmc.sleep(interval * 1000)
                    continue
                fallos = 0
                if not info:
                    vacias += 1
                    if vacias >= 3:
                        xbmcgui.Dialog().notification(
                            self.name, "La transferencia ya no aparece en tu cuenta",
                            xbmcgui.NOTIFICATION_WARNING, 4000)
                        return None
                else:
                    vacias = 0
                status = info.get("status", "")
                if status == "seeding" or status == "finished":
                    xbmc.sleep(2000)
                    return True
                if status in ("error", "timeout", "deleted", "banned"):
                    self._delete(tid)
                    return False
                pct = int(float(info.get("progress", 0) or 0) * 100)
                dlg.update(pct, "{0}\n{1}".format(info.get("name", ""), info.get("message", "")))
                if dlg.iscanceled():
                    if not xbmcgui.Dialog().yesno("Premiumize", "¿Mantener la transferencia en segundo plano?"):
                        self._delete(tid)
                    return False
                xbmc.sleep(interval * 1000)
        finally:
            dlg.close()

    def _transfer(self, tid):
        lst = self._api("GET", "/transfer/list")
        for t in lst.get("transfers", []) or []:
            if t.get("id") == tid:
                return t
        return {}

    def _delete(self, tid):
        if not tid:
            return
        try:
            self._api("POST", "/transfer/delete", data={"id": tid})
        except DebridError as e:
            _log("delete {0}: {1}".format(tid, e), xbmc.LOGWARNING)

    def check_cached(self, hashes):
        result = {}
        for batch in _chunks(_clean_hashes(hashes), 50):
            try:
                resp = self._api("GET", "/cache/check", params={"items[]": batch}).get("response")
            except DebridAuthError:
                raise
            except DebridError as e:
                _log("cache/check: {0}".format(e), xbmc.LOGWARNING)
                continue
            if isinstance(resp, list) and len(resp) == len(batch):
                result.update({h: bool(v) for h, v in zip(batch, resp)})
            elif isinstance(resp, list):
                _log("cache/check: respuesta desalineada ({0} de {1}), lote descartado".format(
                    len(resp), len(batch)), xbmc.LOGWARNING)
        return result

    def _resolve_source(self, info_hash, file_hint, episode_key, allow_uncached):
        magnet = _magnet_for(info_hash)
        if not self._check_cache(info_hash):
            if not allow_uncached:
                return self._fail(self.FAIL_UNCACHED)
            if not self._wait_transfer(magnet):
                return None
        res = self._api("POST", "/transfer/directdl", data={"src": magnet})
        if res.get("status") != "success":
            return None
        videos = [
            {"name": c.get("path", ""), "size": _safe_int(c.get("size")), "link": c.get("link") or c.get("stream_link")}
            for c in res.get("content") or [] if _is_video_name(c.get("path", "")) and (c.get("link") or c.get("stream_link"))
        ]
        chosen = self._pick_source_file(videos, file_hint, episode_key)
        return chosen["link"] if chosen else None

    def list_library(self):
        lst = self._api("GET", "/transfer/list")
        items = []
        for t in lst.get("transfers", []) or []:
            items.append({
                "id": t.get("id"),
                "filename": t.get("name", ""),
                "size": t.get("size") or "",
                "ready": t.get("status") in ("seeding", "finished"),
                "status": t.get("status", ""),
                "_folder": t.get("folder_id"),
                "_file": t.get("file_id"),
                "_src": t.get("src", ""),
            })
        return items

    def _library_entry(self, item_id):
        for t in self.list_library():
            if t.get("id") == item_id:
                return t
        return {}

    def library_files(self, item_id):
        entry = self._library_entry(item_id)
        if entry.get("_folder"):
            data = self._api("GET", "/folder/list", params={"id": entry["_folder"]})
            out = []
            for c in data.get("content") or []:
                link = c.get("link") or c.get("stream_link")
                if c.get("type", "file") == "file" and _is_video_name(c.get("name", "")) and link:
                    out.append({"name": c.get("name", ""), "size": _safe_int(c.get("size")), "link": link})
            return out
        if entry.get("_file"):
            data = self._api("GET", "/item/details", params={"id": entry["_file"]})
            link = data.get("link") or data.get("stream_link")
            if not (data.get("name") and link):
                return []
            return [{"name": data["name"], "size": _safe_int(data.get("size")), "link": link}]
        src = entry.get("_src")
        if not src:
            return []
        res = self._api("POST", "/transfer/directdl", data={"src": src})
        if res.get("status") != "success":
            return []
        out = []
        for c in res.get("content") or []:
            link = c.get("link") or c.get("stream_link")
            if _is_video_name(c.get("path", "")) and link:
                out.append({"name": (c.get("path") or "").split("/")[-1],
                            "size": _safe_int(c.get("size")), "link": link})
        return out

    def resolve_library_item(self, item_id):
        chosen = self._pick_video(self.library_files(item_id))
        return chosen.get("link") if chosen else None

    def resolve_library_file(self, item_id, index):
        files = self.library_files(item_id)
        return files[index].get("link") if 0 <= index < len(files) else None

    def delete_library_item(self, item_id):
        self._delete(item_id)
        return True


# Offcloud

class Offcloud(_DebridBase):
    """Offcloud: token Bearer (flujo de dispositivo o clave pegada). No tiene documentación
    pública; endpoints y campos salen del plugin de ResolveURL.

    Cada petición lleva el cuerpo en JSON. Los errores llegan como {"error": ...}, a veces como
    HTML con cabecera JSON: ambos acaban en DebridError.
    """
    name = "Offcloud"
    PREFIX = "offcloud"
    TOKEN_KEY = "offcloud_token"
    SUPPORTS_PIN = True
    BASE = "https://offcloud.com/api"
    OAUTH = "https://offcloud.com/oauth"
    UA = "EspaTV"
    _CACHE_BATCH = 1000

    def _headers(self, auth=True):
        h = {"User-Agent": self.UA, "Accept": "application/json"}
        if auth and self.token:
            h["Authorization"] = "Bearer {0}".format(self.token)
        return h

    def _api(self, method, path, json_body=None, params=None):
        try:
            payload = _http_json(method, self.BASE + path, self._headers(),
                                 params=params, json_body=json_body)
        except (ValueError, TypeError) as e:  # cuerpo que no se puede decodificar
            raise DebridError("respuesta no válida") from e
        if isinstance(payload, dict) and payload.get("error"):
            err = str(payload.get("error"))
            if err.upper() == "NOAUTH":
                raise DebridAuthError(err)
            fallo = DebridError(err)
            fallo.code = err  # explore relanza "Bad archive" como caso aparte
            raise fallo
        return payload

    # --- vinculación ---

    def authorize_pin(self):
        oauth = _http_json("POST", self.OAUTH + "/device/code", self._headers(auth=False), json_body={})
        device_code = oauth.get("device_code") if isinstance(oauth, dict) else None
        if not device_code:
            xbmcgui.Dialog().ok("Offcloud", "No se pudo iniciar la vinculación.")
            return False
        url = oauth.get("verification_uri") or "offcloud.com"
        expires_in = _safe_int(oauth.get("expires_in")) or 300
        found = {}

        def _check():
            res = _http_json("POST", self.OAUTH + "/token", self._headers(auth=False), json_body={
                "grant_type": "urn:ietf:params:oauth:grant-type:device_code",
                "device_code": device_code,
            })
            token = res.get("access_token") if isinstance(res, dict) else None
            if token:
                found["token"] = token
                return True
            return None

        got = _pin_poll("Vincular Offcloud", url, oauth.get("user_code", ""), expires_in, _check,
                        interval=_safe_int(oauth.get("interval")) or 5,
                        qr_text=oauth.get("verification_uri_complete"))
        if not got or not found.get("token"):
            return False
        return self._finish_token(found["token"])

    def authorize_apikey(self, key, silent=False):
        return self._finish_token((key or "").strip(), silent)

    def _finish_token(self, token, silent=False):
        if not token:
            return False
        self.token = token
        try:
            acc = self._api("GET", "/account/info")
            if not (isinstance(acc, dict) and acc.get("email")):
                raise DebridAuthError("la cuenta no responde con un usuario")
        except DebridError as e:
            self.token = ""
            if silent:
                _log("Offcloud: clave no válida: {0}".format(e), xbmc.LOGWARNING)
            else:
                xbmcgui.Dialog().ok("Offcloud", "API key no válida:\n{0}".format(e))
            return False
        self._save_auth(token, acc.get("email", ""))
        self.warm_hosts()
        return True

    def account_info(self):
        data = self._api("GET", "/account/info")
        data = data if isinstance(data, dict) else {}
        exp = str(data.get("expiration_date") or "")
        # Caducidad como texto AAAA-MM-DD: sin strptime, que no es fiable en Kodi.
        fecha = exp[:10] if re.match(r"^\d{4}-\d{2}-\d{2}", exp) else ""
        premium = bool(data.get("is_premium")) and (not fecha or fecha >= time.strftime("%Y-%m-%d"))
        return {
            "username": data.get("email", ""),
            "premium": premium,
            "expiry_text": fecha,
            "days": _days_from_iso(fecha) if fecha else None,
            "extra": "",
        }

    # --- hosters y «Abrir URL» ---

    def _fetch_hosts(self):
        try:
            sites = self._api("GET", "/sites")
        except DebridError:
            return []
        return [str(s.get("name")) for s in sites or []
                if isinstance(s, dict) and s.get("name") and s.get("status") == "up"]

    def is_supported_hoster(self, url):
        try:
            host = (urllib.parse.urlparse(url).hostname or "").lower()
        except ValueError:
            return False
        if not host:
            return False
        return any(n.lower() in host for n in self._host_cache(self._fetch_hosts))

    def resolve(self, raw_url):
        if not self.is_authorized():
            return None
        low = raw_url.lower()
        if low.startswith("magnet:"):
            h = (_magnet_hash(raw_url) or "").lower()
            if not _HASH_RE.match(h):
                return None
            return self.resolve_source(h, allow_uncached=not self.cached_only)
        if low.endswith(".torrent"):
            return None
        if self.is_supported_hoster(raw_url):
            return self._resolve_guard(lambda: self._resolve_hoster(raw_url))
        return None

    def _resolve_hoster(self, url):
        rid = self._add_transfer(url)
        if not self._wait_transfer(rid):
            return None
        files = _offcloud_files(self._explore(rid, detailed=False))
        # Sin borrar tras sacar el enlace: no está comprobado que sobreviva a la transferencia.
        return files[0]["url"] if files else None

    # --- caché por hash ---

    def _cache_info(self, hashes):
        """{hash: True|False} del lote. Si la respuesta no cuadra con lo enviado, vacío (desconocido)."""
        data = self._api("POST", "/cache/info", json_body={"urls": [_magnet_for(h) for h in hashes]})
        if not isinstance(data, list) or len(data) != len(hashes):
            _log("cache/info: respuesta desalineada, lote descartado", xbmc.LOGWARNING)
            return {}
        out = {}
        for h, item in zip(hashes, data):
            cached = item.get("cached") if isinstance(item, dict) else None
            if isinstance(cached, (bool, int)):
                out[h] = bool(cached)
        return out

    def check_cached(self, hashes):
        result = {}
        for batch in _chunks(_clean_hashes(hashes), self._CACHE_BATCH):
            try:
                result.update(self._cache_info(batch))
            except DebridAuthError:
                raise
            except DebridError as e:
                _log("cache/info: {0}".format(e), xbmc.LOGWARNING)
        return result

    def _owned_index(self):
        # El historial de Offcloud no trae el hash de cada transferencia: no se puede saber qué
        # hay ya en la cuenta por hash.
        return {}

    # --- transferencias ---

    def _add_transfer(self, url):
        created = self._api("POST", "/cloud", json_body={"url": url})
        rid = created.get("requestId") if isinstance(created, dict) else None
        if not rid:
            estado = created.get("status") if isinstance(created, dict) else ""
            raise DebridError("Offcloud no aceptó la descarga {0}".format(estado or "").strip())
        return str(rid)

    def _transfer_status(self, rid):
        res = self._api("POST", "/cloud/status", json_body={"requestId": rid})
        st = res.get("status") if isinstance(res, dict) else None
        return st if isinstance(st, dict) else {}

    def _delete_transfer(self, rid):
        """True si Offcloud confirma el borrado (campo `success`)."""
        res = self._api("POST", "/cloud/remove", json_body={"requests": [rid]})
        return bool(isinstance(res, dict) and res.get("success"))

    def _explore(self, rid, detailed=True):
        path = "/cloud/explore/" + urllib.parse.quote(str(rid), safe="")
        if not detailed:
            return self._api("GET", path)
        try:
            return self._api("GET", path, params={"format": "detailed"})
        except DebridError as e:
            # Las transferencias de un solo archivo no se pueden explorar al detalle: se piden
            # sin formato, que devuelve solo los enlaces.
            if getattr(e, "code", "") != "Bad archive":
                raise
            return self._api("GET", path)

    def _wait_transfer(self, rid, interval=5):
        """True cuando la transferencia está lista. False si se cancela, falla o tarda demasiado."""
        dlg = xbmcgui.DialogProgress()
        dlg.create("Offcloud", "Preparando en la nube...")
        fallos = 0
        vacias = 0
        inicio = time.time()
        try:
            while True:
                try:
                    st = self._transfer_status(rid)
                except DebridNetworkError:
                    fallos += 1
                    if fallos >= 3:
                        self._notify_lost(self.name)
                        return False
                    xbmc.sleep(interval * 1000)
                    continue
                fallos = 0
                if st.get("status") == "downloaded":
                    return True
                if not st:
                    vacias += 1
                    if vacias >= 3:
                        xbmcgui.Dialog().notification(
                            self.name, "La transferencia ya no aparece en tu cuenta",
                            xbmcgui.NOTIFICATION_WARNING, 4000)
                        return False
                else:
                    vacias = 0
                if time.time() - inicio >= _TB_WAIT_S:
                    xbmcgui.Dialog().notification(
                        self.name, "La descarga tarda demasiado; inténtalo más tarde",
                        xbmcgui.NOTIFICATION_WARNING, 4000)
                    return False
                pct = int((_safe_float(st.get("progress"))) * 100)
                dlg.update(pct, "{0}\n{1}".format(st.get("fileName", ""), st.get("message", "")))
                if dlg.iscanceled():
                    if not xbmcgui.Dialog().yesno("Offcloud", "¿Mantener la descarga en segundo plano?"):
                        try:
                            self._delete_transfer(rid)
                        except DebridError as e:
                            _log("delete {0}: {1}".format(str(rid)[:8], e), xbmc.LOGWARNING)
                    return False
                xbmc.sleep(interval * 1000)
        finally:
            dlg.close()

    # --- fuentes por hash ---

    def _resolve_source(self, info_hash, file_hint, episode_key, allow_uncached):
        # Un hash que no sea de 40 hexadecimales se acepta en Offcloud y se queda parado: ni se envía.
        if not _HASH_RE.match(info_hash or ""):
            _log("hash no válido, no se envía", xbmc.LOGWARNING)
            return self._fail(self.FAIL_ERROR)
        magnet = _magnet_for(info_hash)
        cached = self._cache_info([info_hash]).get(info_hash)  # None: respuesta poco clara
        if cached:
            files = _offcloud_files(self._api("POST", "/cache/download", json_body={"url": magnet}))
            return self._pick_offcloud_url(files, file_hint, episode_key)
        if not allow_uncached:
            return self._fail(self.FAIL_UNCACHED if cached is False else self.FAIL_ERROR)

        rid = None
        keep = False  # una espera que termina sin enlace ya dejó la descarga como el usuario quiso
        final = None
        try:
            rid = self._add_transfer(magnet)
            if not self._wait_transfer(rid):
                keep = True
                return None
            files = _offcloud_files(self._explore(rid))
            final = self._pick_offcloud_url(files, file_hint, episode_key)
            return final
        except Exception:
            # Aceptada la descarga, un fallo inesperado no borra lo que ya se está bajando.
            keep = True
            raise
        finally:
            # Sin borrar tras sacar el enlace: no está comprobado que sobreviva a la transferencia.
            if rid and not keep and final is None:
                try:
                    self._delete_transfer(rid)
                except DebridError as e:
                    _log("delete {0}: {1}".format(rid[:8], e), xbmc.LOGWARNING)

    def _pick_offcloud_url(self, files, file_hint, episode_key):
        videos = [f for f in files if _is_video_name(f["name"])]
        chosen = self._pick_source_file(videos, file_hint, episode_key)
        return chosen["url"] if chosen else None

    # --- nube del usuario ---

    def list_library(self):
        history = self._api("GET", "/cloud/history")
        items = []
        for t in history if isinstance(history, list) else []:
            if not isinstance(t, dict) or not t.get("requestId"):
                continue
            items.append({
                "id": t["requestId"],
                "filename": t.get("fileName", ""),
                "size": "",  # la API no da tamaños
                "ready": t.get("status") == "downloaded",
                "status": t.get("status", ""),
                "date": t.get("createdOn", "") or "",
            })
        return items

    def library_files(self, item_id):
        files = _offcloud_files(self._explore(item_id))
        return [f for f in files if _is_video_name(f["name"])]

    def resolve_library_item(self, item_id):
        chosen = self._pick_video(self.library_files(item_id))
        return chosen.get("url") if chosen else None

    def resolve_library_file(self, item_id, index):
        files = self.library_files(item_id)
        return files[index].get("url") if 0 <= index < len(files) else None

    def delete_library_item(self, item_id):
        if not self._delete_transfer(item_id):
            raise DebridError("Offcloud no confirmó el borrado")
        return True


def _offcloud_files(data):
    """[{name, size, url}] de una respuesta de Offcloud: {files: [...]}, lista de dicts o de enlaces."""
    if isinstance(data, dict):
        data = data.get("files")
    out = []
    for f in data if isinstance(data, list) else []:
        if isinstance(f, str):
            url, name, size = f, "", 0
        elif isinstance(f, dict):
            url, name, size = f.get("url"), f.get("filename") or f.get("name") or "", _safe_int(f.get("size"))
        else:
            continue
        if not url or not isinstance(url, str):
            continue
        if not name:
            name = urllib.parse.unquote(urllib.parse.urlparse(url).path.rsplit("/", 1)[-1])
        out.append({"name": str(name), "size": size, "url": url})
    return out


# ===================== utilidades comunes =====================

def _safe_int(v):
    try:
        return int(v)
    except (TypeError, ValueError):
        return 0


def _safe_float(v):
    try:
        return float(v)
    except (TypeError, ValueError):
        return 0.0


def _pin_poll(title, url, code, expires_in, check_fn, interval=5, qr_text=None):
    """Diálogo o ventana con cuenta atrás mientras se sondea la activación.
    check_fn() devuelve un valor verdadero (token o True) al activarse, None si no."""
    win = None
    png = ""
    if qr_text:
        try:
            import debrid_qr
            png = os.path.join(
                core_settings._PROFILE_PATH, "debrid_qr_{0}.png".format(int(time.time() * 1000)))
            if debrid_qr.make_png(qr_text, png):
                win = debrid_qr.PinWindow(title, url, code, png)
                win.show()
        except Exception as e:  # sin QR se sigue con el diálogo de texto de siempre
            _log("La ventana del QR no está disponible: {0}".format(e), xbmc.LOGWARNING)
            win = None
        if win is None and png:
            try:
                os.remove(png)
            except OSError:
                pass
            png = ""

    if win is not None:
        monitor = xbmc.Monitor()
        start = time.time()
        ultimo = 0
        try:
            while not win.canceled and not monitor.waitForAbort(1):
                now = time.time()
                restante = expires_in - (now - start)
                if restante <= 0:
                    return None
                minutos, segundos = divmod(int(restante), 60)
                win.set_status("Esperando activación... quedan {0}:{1:02d}".format(minutos, segundos))
                if now - ultimo < interval:
                    continue
                ultimo = now
                try:
                    result = check_fn()
                except DebridError:
                    continue
                if result:
                    return result
        finally:
            win.close()
            try:
                os.remove(png)
            except OSError:
                pass
        return None

    dlg = xbmcgui.DialogProgress()
    dlg.create(title, "Abre [B]{0}[/B]\ne introduce el código: [B]{1}[/B]".format(url, code))
    start = time.time()
    try:
        while time.time() - start < expires_in:
            if dlg.iscanceled():
                return None
            xbmc.sleep(interval * 1000)
            if dlg.iscanceled():
                return None
            try:
                result = check_fn()
            except DebridError:
                continue
            if result:
                return result
            pct = int((time.time() - start) / expires_in * 100)
            dlg.update(pct, "Esperando activación...\nCódigo: [B]{0}[/B]".format(code))
    finally:
        dlg.close()
    return None


_PROVIDERS = {
    "AllDebrid": AllDebrid,
    "Real-Debrid": RealDebrid,
    "TorBox": TorBox,
    "Premiumize": Premiumize,
    "Offcloud": Offcloud,
}
_instance = None


def get_resolver():
    """Devuelve la instancia del proveedor configurado (cacheada por proceso)."""
    global _instance
    if _instance is None:
        provider = _addon().getSetting("debrid_provider") or "AllDebrid"
        cls = _PROVIDERS.get(provider, AllDebrid)
        _instance = cls()
    return _instance


def reset_resolver():
    """Fuerza recrear la instancia tras cambiar ajustes/credenciales."""
    global _instance
    _instance = None
