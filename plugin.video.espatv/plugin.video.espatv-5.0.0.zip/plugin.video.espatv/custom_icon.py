# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Selector y restauración del logotipo del addon (`icon.png`) con copia de respaldo."""
import hashlib
import json
import os
import struct
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

import core_settings

ADDON_ID = 'plugin.video.espatv'
_PNG_SIGNATURE = b'\x89PNG\r\n\x1a\n'
_MIN_DIM = 256
_MAX_DIM = 1024
_MAX_FILE_BYTES = 5 * 1024 * 1024  # 5 MB: evita bloquear Kodi leyendo archivos gigantes por red
_VALID_COLOR_TYPES = (2, 3, 6)  # PNG estándar: RGB (2), indexado (3), RGBA (6)


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log('[EspaTV/custom_icon] {0}'.format(msg), level)


def addon_icon_path():
    """Devuelve la ruta absoluta de `icon.png` en la raíz del addon."""
    try:
        base = xbmcaddon.Addon(ADDON_ID).getAddonInfo('path')
    except RuntimeError:
        base = ''
    if not isinstance(base, str) or not base or base.startswith('special://'):
        base = os.path.dirname(os.path.abspath(__file__))
    return os.path.join(base, 'icon.png')


def _sha256_bytes(data):
    return hashlib.sha256(data).hexdigest()


def _read_local_bytes(path, max_bytes=_MAX_FILE_BYTES):
    try:
        if not os.path.isfile(path):
            return None
        if os.path.getsize(path) > max_bytes:
            return None
        with open(path, 'rb') as fh:
            return fh.read()
    except OSError:
        return None


def _atomic_write_bytes(dest_path, data):
    """Escritura atómica (.tmp + os.replace) con reintento breve por bloqueo en Windows."""
    parent = os.path.dirname(dest_path)
    if parent and not os.path.exists(parent):
        os.makedirs(parent, exist_ok=True)
    tmp = '{0}.{1}.{2}.tmp'.format(dest_path, os.getpid(), time.time_ns())
    try:
        with open(tmp, 'wb') as fh:
            fh.write(data)
            fh.flush()
        for intento in range(3):
            try:
                os.replace(tmp, dest_path)
                break
            except PermissionError:
                if intento == 2:
                    raise
                time.sleep(0.05)
        try:
            os.utime(dest_path, None)
        except OSError:
            pass
        return True, ''
    except PermissionError as e:
        _cleanup_tmp(tmp)
        _log('Sin permisos de escritura en {0}: {1}'.format(dest_path, e), xbmc.LOGWARNING)
        return False, 'Sin permisos para escribir en la carpeta del addon (instalación de solo lectura).'
    except OSError as e:
        _cleanup_tmp(tmp)
        _log('Error escribiendo {0}: {1}'.format(dest_path, e), xbmc.LOGWARNING)
        return False, 'No se pudo escribir el archivo ({0}).'.format(e)


def _cleanup_tmp(path):
    try:
        if os.path.exists(path):
            os.remove(path)
    except OSError:
        pass


def validate_png_bytes(data):
    """Valida firma PNG, bloque IHDR, relación 1:1, rango 256-1024 px y color de 8 bits."""
    if not data or len(data) < 33 or data[:8] != _PNG_SIGNATURE:
        return False, (
            'El archivo no es un PNG real.\n'
            'Usa una imagen .png genuina (no un JPG/WEBP renombrado).'
        )
    ihdr_len = struct.unpack('>I', data[8:12])[0]
    if ihdr_len != 13 or data[12:16] != b'IHDR':
        return False, 'Cabecera PNG dañada (bloque IHDR no válido).'
    width, height, bit_depth, color_type, _c, _f, _i = struct.unpack('>IIBBBBB', data[16:29])
    if width <= 0 or height <= 0 or width != height:
        return False, (
            'La imagen debe ser cuadrada (relación 1:1).\n'
            'Resolución detectada: {0} x {1} px.'
        ).format(width, height)
    if width < _MIN_DIM or width > _MAX_DIM:
        return False, (
            'Resolución fuera de rango: {0} x {1} px.\n'
            'Usa un PNG cuadrado entre 256x256 y 1024x1024 px (recomendado 512x512).'
        ).format(width, height)
    if bit_depth != 8 or color_type not in _VALID_COLOR_TYPES:
        return False, (
            'Formato de color PNG no compatible (profundidad={0}, tipo={1}).\n'
            'Usa PNG sRGB/RGB, RGBA o indexado de 8 bits (prohibido CMYK o 16 bits).'
        ).format(bit_depth, color_type)
    return True, ''


def read_vfs_png_bytes(src_path):
    """Lee un archivo vía `xbmcvfs.File` (local, smb://, nfs://) con tope de 5 MB en RAM."""
    if not src_path:
        return None, 'No se seleccionó ningún archivo.'
    try:
        with xbmcvfs.File(src_path, 'rb') as fh:
            sz = fh.size()
            if isinstance(sz, int) and sz > _MAX_FILE_BYTES:
                return None, 'La imagen supera el tamaño máximo permitido (5 MB).'
            raw = bytes(fh.readBytes(_MAX_FILE_BYTES + 1))
    except (OSError, RuntimeError, TypeError) as e:
        _log('No se pudo leer {0}: {1}'.format(src_path, e), xbmc.LOGWARNING)
        return None, 'No se pudo leer el archivo seleccionado.'
    if not raw:
        return None, 'El archivo está vacío o no es accesible.'
    if len(raw) > _MAX_FILE_BYTES:
        return None, 'La imagen supera el tamaño máximo permitido (5 MB).'
    return raw, ''


def _within(base_dir, target):
    try:
        base_real = os.path.realpath(base_dir)
        target_real = os.path.realpath(target)
        return os.path.commonpath([base_real, target_real]) == base_real
    except (ValueError, OSError):
        return False


def _invalidate_kodi_icon_texture():
    """Elimina `icon.png` de `Textures13.db` vía JSON-RPC para que Kodi refresque sin reiniciar.

    No se invoca `ReloadSkin()` automáticamente porque parpadea/cierra diálogos activos
    y rompe la reapertura automática de `Modo Ajustes`.
    """
    payload = {
        'jsonrpc': '2.0',
        'id': 1,
        'method': 'Textures.GetTextures',
        'params': {
            'properties': ['url', 'cachedurl'],
            'filter': {
                'field': 'url',
                'operator': 'contains',
                'value': ADDON_ID,
            },
        },
    }
    try:
        raw = xbmc.executeJSONRPC(json.dumps(payload))
        data = json.loads(raw) if raw else {}
    except (ValueError, TypeError, RuntimeError) as e:
        _log('Textures.GetTextures falló: {0}'.format(e), xbmc.LOGDEBUG)
        return 0

    textures = (data.get('result') or {}).get('textures') or []
    thumbs_dir = xbmcvfs.translatePath('special://thumbnails/')
    removed = 0
    suffix = '{0}/icon.png'.format(ADDON_ID).lower()
    for tex in textures:
        # En Windows, Textures13.db almacena barras invertidas `\` (o URL-encoded en `image://...`).
        url_norm = urllib.parse.unquote(tex.get('url') or '').replace('\\', '/').rstrip('/').lower()
        if url_norm != suffix and not url_norm.endswith('/' + suffix):
            continue
        tex_id = tex.get('textureid')
        if tex_id is not None:
            try:
                xbmc.executeJSONRPC(json.dumps({
                    'jsonrpc': '2.0',
                    'id': 2,
                    'method': 'Textures.RemoveTexture',
                    'params': {'textureid': tex_id},
                }))
                removed += 1
            except (TypeError, RuntimeError):
                pass
        cached = (tex.get('cachedurl') or '').lstrip('/\\')
        if cached and isinstance(thumbs_dir, str) and not thumbs_dir.startswith('special://'):
            full = os.path.join(thumbs_dir, cached)
            if _within(thumbs_dir, full) and os.path.isfile(full):
                try:
                    os.remove(full)
                except OSError:
                    pass
    return removed


def _ensure_default_backup(icon_path):
    """Respalda el `icon.png` de fábrica antes del primer cambio. Aborta si falla."""
    backup_path = core_settings.get_icon_default_backup_path()
    existing = _read_local_bytes(backup_path)
    if existing and validate_png_bytes(existing)[0]:
        return True, ''
    orig = _read_local_bytes(icon_path)
    if not orig or not validate_png_bytes(orig)[0]:
        return False, 'No se encontró un logo original válido del addon para respaldarlo.'
    if core_settings.is_custom_icon_active():
        custom_bytes = _read_local_bytes(core_settings.get_icon_custom_backup_path())
        if custom_bytes and _sha256_bytes(orig) == _sha256_bytes(custom_bytes):
            return False, 'Falta la copia del logo original de fábrica; reinstala o actualiza el addon antes de cambiar el logo.'
    ok, err = _atomic_write_bytes(backup_path, orig)
    if not ok:
        return False, err
    if not os.path.isfile(backup_path) or os.path.getsize(backup_path) != len(orig):
        return False, 'No se pudo verificar la copia de seguridad del logo original.'
    return True, ''


def sync_after_addon_update():
    """Si una actualización de Kodi pisó `icon.png` mientras había logo custom, resincroniza."""
    if not core_settings.is_custom_icon_active():
        return False
    custom_path = core_settings.get_icon_custom_backup_path()
    icon_path = addon_icon_path()
    custom_bytes = _read_local_bytes(custom_path)
    if not custom_bytes or not validate_png_bytes(custom_bytes)[0]:
        core_settings.set_icon_state(False, '')
        return False
    current_bytes = _read_local_bytes(icon_path)
    if current_bytes is None:
        return False
    custom_sha = _sha256_bytes(custom_bytes)
    expected_sha = core_settings.get_icon_state().get('sha256') or ''
    current_sha = _sha256_bytes(current_bytes)
    if current_sha == custom_sha:
        if expected_sha != custom_sha:
            core_settings.set_icon_state(True, sha256=custom_sha)
        return False

    # Solo actualizamos icon_default.png si el nuevo icon.png de la raíz es un PNG íntegro;
    # así un archivo truncado jamás contamina la copia de fábrica.
    backup_path = core_settings.get_icon_default_backup_path()
    if validate_png_bytes(current_bytes)[0]:
        ok_bk, _ = _atomic_write_bytes(backup_path, current_bytes)
        if not ok_bk:
            return False
    elif not os.path.isfile(backup_path):
        return False

    ok, _ = _atomic_write_bytes(icon_path, custom_bytes)
    if ok:
        if expected_sha != custom_sha:
            core_settings.set_icon_state(True, sha256=custom_sha)
        _invalidate_kodi_icon_texture()
        _log('Logo personalizado reaplicado tras actualización del addon.')
        return True
    return False


def apply_custom_icon(src_path):
    """Valida el PNG, respalda `icon.png` original si no existe copia y aplica el nuevo."""
    png_bytes, err = read_vfs_png_bytes(src_path)
    if not png_bytes:
        return False, err
    ok, err = validate_png_bytes(png_bytes)
    if not ok:
        return False, err

    icon_path = addon_icon_path()
    ok, err = _ensure_default_backup(icon_path)
    if not ok:
        return False, err

    custom_path = core_settings.get_icon_custom_backup_path()
    was_active = core_settings.is_custom_icon_active()
    prev_custom = _read_local_bytes(custom_path) if was_active else None
    prev_icon = _read_local_bytes(icon_path)

    ok, err = _atomic_write_bytes(custom_path, png_bytes)
    if not ok:
        return False, err

    ok, err = _atomic_write_bytes(icon_path, png_bytes)
    if not ok:
        # Revertimos custom_icon.png para no desincronizarlo respecto a icon.png e icon_state.json.
        try:
            if was_active and prev_custom:
                _atomic_write_bytes(custom_path, prev_custom)
            elif not was_active and os.path.isfile(custom_path):
                os.remove(custom_path)
        except OSError:
            pass
        return False, err

    if not core_settings.set_icon_state(True, sha256=_sha256_bytes(png_bytes)):
        if prev_icon is not None:
            _atomic_write_bytes(icon_path, prev_icon)
        if was_active and prev_custom:
            _atomic_write_bytes(custom_path, prev_custom)
        elif not was_active and os.path.isfile(custom_path):
            _cleanup_tmp(custom_path)
        return False, 'No se pudo guardar el estado del logo personalizado.'

    _invalidate_kodi_icon_texture()
    xbmc.executebuiltin('Container.Refresh')
    return True, 'Logo personalizado guardado.'


def restore_default_icon():
    """Restaura `icon.png` original de fábrica byte a byte y limpia el estado custom."""
    backup_path = core_settings.get_icon_default_backup_path()
    orig_bytes = _read_local_bytes(backup_path)
    if not orig_bytes or not validate_png_bytes(orig_bytes)[0]:
        return False, 'No existe una copia válida del logo original para restaurar.'

    icon_path = addon_icon_path()
    prev_icon = _read_local_bytes(icon_path)
    ok, err = _atomic_write_bytes(icon_path, orig_bytes)
    if not ok:
        return False, err

    restored = _read_local_bytes(icon_path)
    if restored != orig_bytes:
        return False, 'La verificación tras restaurar el logo original no coincidió.'

    if not core_settings.set_icon_state(False, ''):
        if prev_icon is not None:
            _atomic_write_bytes(icon_path, prev_icon)
        return False, 'No se pudo actualizar el estado del logo al restaurar.'

    custom_path = core_settings.get_icon_custom_backup_path()
    try:
        if os.path.isfile(custom_path):
            os.remove(custom_path)
    except OSError:
        pass

    _invalidate_kodi_icon_texture()
    xbmc.executebuiltin('Container.Refresh')
    return True, 'Logo original predeterminado restaurado.'


def _pick_and_apply():
    src = xbmcgui.Dialog().browse(
        1,
        'Elegir logo PNG cuadrado (1:1, 256-1024 px)',
        'files',
        '.png',
        False,
        False,
        '',
    )
    # Al cancelar, Dialog().browse() devuelve '' (el valor de defaultt).
    if not src:
        return
    ok, msg = apply_custom_icon(src)
    if ok:
        xbmcgui.Dialog().notification('EspaTV', msg, xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().ok('Logo no aplicado', msg)


def _restore_action():
    ok, msg = restore_default_icon()
    if ok:
        xbmcgui.Dialog().notification('EspaTV', msg, xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().ok('Error al restaurar logo', msg)


def manage_custom_icon():
    """Menú de gestión del logotipo del addon: elegir/cambiar PNG o revertir al original."""
    sync_after_addon_update()
    active = core_settings.is_custom_icon_active()
    labels = ['Cambiar logo personalizado (PNG)' if active else 'Elegir logo personalizado (PNG)']
    actions = [_pick_and_apply]
    if active:
        labels.append('Restaurar logo original predeterminado')
        actions.append(_restore_action)
    opt = xbmcgui.Dialog().select('Logo del Addon', labels)
    if opt < 0:
        return
    actions[opt]()
