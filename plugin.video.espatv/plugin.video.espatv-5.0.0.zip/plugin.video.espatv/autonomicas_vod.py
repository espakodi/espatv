# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Autonómicas a la carta: Canal Sur Más, Telemadrid, AGalega, 3Cat y À Punt.

Cada cadena es un adaptador con la misma interfaz (`root()`, `children(nodo)` y
`playback(nodo)`) y se da de alta en el registro `ADAPTADORES` con `registrar(...)`.

Un nodo es un dict: `id` (texto que viaja en la URL del plugin), `titulo`, `tipo`
("cat" carpeta o "video"), `imagen`, `plot` y `meta`.

Reproducción: los vídeos son items `IsPlayable=true` cuya acción resuelve con
`setResolvedUrl` (nunca `play_raw_url`, que bucleaba), como `rtve_alacarta.py`.

Canal Sur Más y Telemadrid siguen TDT Simple (CanalSurCatalog.kt y TelemadridCatalog.kt);
AGalega, 3Cat y À Punt se apoyan en sus APIs/reproductores públicos verificados.
"""
import hashlib
import html as _html
import json
import os
import re
import sys
import time
import unicodedata
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcgui
import xbmcplugin

import core_settings
from _user_agents import UA_DESKTOP

try:
    import requests
except ImportError:
    requests = None

_LOG_TAG = "[EspaTV-AUTONOMICAS]"
_TIMEOUT = 15
_CACHE_TTL_DEFECTO = 10 * 60   # listados; el usuario puede cambiarlo en los ajustes de caché IPTV
_MAX_PAGINAS_TM = 20


class AutonomicaError(Exception):
    """Fallo de una cadena con un mensaje que se puede enseñar tal cual a la usuaria."""

    def __init__(self, mensaje):
        Exception.__init__(self, mensaje)
        self.mensaje = mensaje


# ---------------------------------------------------------------------------
# Utilidades comunes
# ---------------------------------------------------------------------------

def _log(msg, nivel=None):
    xbmc.log("{0} {1}".format(_LOG_TAG, msg), xbmc.LOGINFO if nivel is None else nivel)


def _handle():
    return int(sys.argv[1])


def _u(**kwargs):
    return "{0}?{1}".format(sys.argv[0], urllib.parse.urlencode(kwargs))


def _s(valor):
    """Texto de un valor JSON simple ('' si no hay)."""
    if valor is None or isinstance(valor, (dict, list)):
        return ""
    return str(valor).strip()


def _limpiar_html(crudo):
    texto = _s(crudo)
    if not texto:
        return ""
    texto = re.sub(r"<br\s*/?>", "\n", texto, flags=re.I)
    texto = re.sub(r"<[^>]+>", "", texto)
    texto = _html.unescape(texto).replace(" ", " ")
    lineas = [l.strip() for l in texto.splitlines()]
    return re.sub(r"\n{3,}", "\n\n", "\n".join(lineas)).strip()


def _msg_http(servicio, estado):
    if estado in (401, 403):
        return ("{0} rechaza la conexión (HTTP {1}). Puede estar limitado a España: "
                "prueba con una VPN.").format(servicio, estado)
    return "{0} respondió con error (HTTP {1}).".format(servicio, estado)


def _peticion(metodo, url, headers=None, datos=None, timeout=_TIMEOUT):
    """(estado HTTP, texto UTF-8). Lanza AutonomicaError si no hay red.

    Es el único punto que toca la red: los tests lo sustituyen."""
    cab = {"User-Agent": UA_DESKTOP, "Accept-Language": "es-ES,es;q=0.9"}
    cab.update(headers or {})
    try:
        if requests:
            r = requests.request(metodo, url, headers=cab, data=datos, timeout=timeout)
            return r.status_code, r.content.decode("utf-8", "replace")
        cuerpo = None
        if datos is not None:
            cuerpo = urllib.parse.urlencode(datos).encode("utf-8")
            cab.setdefault("Content-Type", "application/x-www-form-urlencoded")
        req = urllib.request.Request(url, data=cuerpo, headers=cab, method=metodo)
        try:
            with urllib.request.urlopen(req, timeout=timeout) as resp:
                return resp.status, resp.read().decode("utf-8", "replace")
        except urllib.error.HTTPError as e:
            try:
                texto = e.read().decode("utf-8", "replace")
            except OSError:
                texto = ""
            return e.code, texto
    except (OSError, ValueError) as e:
        _log("sin red al pedir {0}: {1}".format(url.split("?")[0], e), xbmc.LOGWARNING)
        raise AutonomicaError("Sin conexión con el servidor. Comprueba tu red o prueba con una VPN.")


# --- caché de listados (reusa el directorio y el TTL de la caché IPTV del addon) ----------

def _dir_cache():
    return core_settings.get_iptv_cache_dir()


def _ttl():
    return core_settings.get_iptv_cache_ttl(default_ttl=_CACHE_TTL_DEFECTO)


def _ruta_cache(clave):
    return os.path.join(_dir_cache(), "autonomicas_" + hashlib.md5(clave.encode("utf-8")).hexdigest() + ".json")


def _cache_leer(clave):
    ttl = _ttl()
    if ttl <= 0:
        return None
    try:
        with open(_ruta_cache(clave), "r", encoding="utf-8") as f:
            guardado = json.load(f)
        if time.time() - guardado.get("ts", 0) < ttl:
            return guardado.get("content")
    except (OSError, ValueError, AttributeError):
        pass
    return None


def _cache_guardar(clave, contenido):
    if _ttl() <= 0:
        return
    try:
        core_settings.atomic_write_json(_ruta_cache(clave), {"ts": time.time(), "content": contenido})
    except OSError:
        pass


_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")


def _icono_propio(nombre, respaldo="DefaultTVShows.png"):
    """Ruta del PNG propio de resources/media; si falta, el icono genérico de Kodi."""
    ruta = os.path.join(_MEDIA, nombre)
    return ruta if os.path.isfile(ruta) else respaldo


def _nodo(id_, titulo, tipo="cat", imagen="", plot="", meta=""):
    return {"id": id_, "titulo": titulo, "tipo": tipo, "imagen": imagen, "plot": plot, "meta": meta}


def _normalizar_busqueda(texto):
    """Minúsculas sin tildes ni espacios sobrantes para filtrar títulos en local."""
    limpio = unicodedata.normalize("NFD", _s(texto).casefold())
    sin_tildes = "".join(c for c in limpio if unicodedata.category(c) != "Mn")
    return " ".join(sin_tildes.split())


def _filtrar_nodos(nodos, filtro):
    terminos = _normalizar_busqueda(filtro).split()
    if not terminos:
        return list(nodos)
    out = []
    for n in nodos:
        if _s(n.get("id")).startswith(("url|", "more|")):
            continue
        clave = _normalizar_busqueda(" ".join((_s(n.get("titulo")), _s(n.get("meta")), _s(n.get("plot")))))
        if all(t in clave for t in terminos):
            out.append(n)
    return out


# ---------------------------------------------------------------------------
# Interfaz común y registro
# ---------------------------------------------------------------------------

class Adaptador(object):
    """Interfaz que cumple cada cadena. `playback` devuelve
    {"url": str, "headers": dict, "web": str, "motivo": str}; con `url` vacía, `motivo`
    explica por qué no se puede reproducir."""

    id = ""
    nombre = ""
    descripcion = ""
    icono = "DefaultTVShows.png"
    buscable = False

    def root(self):
        raise NotImplementedError

    def children(self, nodo):
        raise NotImplementedError

    def playback(self, nodo):
        raise NotImplementedError


ADAPTADORES = {}   # id -> adaptador, en orden de alta (dict conserva el orden)


def registrar(adaptador):
    ADAPTADORES[adaptador.id] = adaptador
    return adaptador


def _adaptador(id_):
    return ADAPTADORES.get(id_)


# ---------------------------------------------------------------------------
# Plataformas Interactvty (Canal Sur Más y AGalega)
# ---------------------------------------------------------------------------

_CS_API = "https://api-rtva.interactvty.com/api/2.0/contents/"
_CS_TOKEN_URL = "https://www.canalsurmas.es/api/fetch-api/jwt/token"
_CS_ORIGEN = "https://www.canalsurmas.es"
_CS_CAMPOS = ("optional_fields=image,image_medium,alternative_image,alternative_image_medium,"
              "is_title,is_final,type,card,width,height,badges,friendly_url,short_description,"
              "long_description,description,duration,date,content_design,template_category")
_CS_CAMPOS_RES = ("optional_fields=type,videotype,media_url,is_initial,assets,drm_token,test,plain,"
                  "url_app_web,thumbnail_track_url,product,remote_product_id,brightcove_drm_source,has_p2p")
# Categorías de usuario que no son contenido.
_CS_OCULTAS = ("estoy viendo", "mis favoritos", "nos gusta", "contenedor")
_CS_TOKEN_VIDA = 50 * 60          # el token dura ~1 h: se renueva antes
_CS_FICHERO_TOKEN = "autonomicas_canalsur_token.json"

_cs_token = {"valor": "", "ts": 0.0}   # memoria del proceso


def _cs_fichero_token():
    return os.path.join(_dir_cache(), _CS_FICHERO_TOKEN)


class _InteractvtyCliente(object):
    """Cliente compartido para plataformas Interactvty 2.0 (Canal Sur Más, AGalega)."""

    def __init__(self, nombre_error, api, token_url, origen, client, token_cache, fichero_fn):
        self.nombre_error = nombre_error
        self.api = api
        self.token_url = token_url
        self.origen = origen
        self.client = client
        self.token_cache = token_cache
        self.fichero_fn = fichero_fn

    def token_guardado(self):
        ahora = time.time()
        if self.token_cache["valor"] and ahora - self.token_cache["ts"] < _CS_TOKEN_VIDA:
            return self.token_cache["valor"]
        try:
            with open(self.fichero_fn(), "r", encoding="utf-8") as f:
                d = json.load(f)
            valor, ts = _s(d.get("token")), float(d.get("ts", 0))
            if valor and 0 <= ahora - ts < _CS_TOKEN_VIDA:
                self.token_cache.update(valor=valor, ts=ts)
                return valor
        except (OSError, ValueError, AttributeError, TypeError):
            pass
        return ""

    def pedir_token(self):
        estado, texto = _peticion(
            "POST", self.token_url,
            headers={"Origin": self.origen, "Referer": self.origen + "/",
                     "Accept": "application/json, text/plain, */*"},
            datos={"client": self.client})
        if estado != 200:
            _log("token {0}: HTTP {1}".format(self.nombre_error, estado), xbmc.LOGWARNING)
            raise AutonomicaError(_msg_http(self.nombre_error, estado))
        try:
            valor = _s(json.loads(texto).get("access"))
        except (ValueError, AttributeError):
            valor = ""
        if not valor:
            _log("token {0}: la respuesta no trae el campo 'access'".format(self.nombre_error), xbmc.LOGWARNING)
            raise AutonomicaError("{0} no entregó el acceso. Inténtalo más tarde.".format(self.nombre_error))
        self.token_cache.update(valor=valor, ts=time.time())
        try:
            core_settings.atomic_write_json(self.fichero_fn(), {"token": valor, "ts": self.token_cache["ts"]})
        except OSError:
            pass
        return valor

    def obtener_token(self, forzar=False):
        if not forzar:
            guardado = self.token_guardado()
            if guardado:
                return guardado
        return self.pedir_token()

    def json(self, url, cache=True):
        """JSON de la API (dict) o None con 404/400. Con 401/403 renueva el token una vez."""
        if not url.startswith(self.api):
            raise AutonomicaError("Dirección no válida.")
        if cache:
            guardado = _cache_leer(url)
            if isinstance(guardado, dict):
                return guardado
        estado, texto = 0, ""
        for intento in (0, 1):
            token = self.obtener_token(forzar=(intento == 1))
            estado, texto = _peticion("GET", url, headers={
                "authorization": "jwtok " + token, "Origin": self.origen, "Referer": self.origen + "/",
                "Accept": "application/json, text/plain, */*"})
            if estado in (401, 403) and intento == 0:
                _log("API {0}: HTTP {1}, renovando el token".format(self.nombre_error, estado))
                continue
            break
        if estado in (401, 403):
            raise AutonomicaError(_msg_http(self.nombre_error, estado))
        if estado in (400, 404):
            _log("API {0}: HTTP {1} en {2}".format(self.nombre_error, estado, url.split("?")[0]))
            return None
        if estado != 200:
            raise AutonomicaError(_msg_http(self.nombre_error, estado))
        try:
            datos = json.loads(texto)
        except ValueError:
            datos = None
        if not isinstance(datos, dict):
            _log("API {0}: respuesta que no es un objeto JSON en {1}".format(
                self.nombre_error, url.split("?")[0]), xbmc.LOGWARNING)
            raise AutonomicaError("{0} devolvió una respuesta no válida.".format(self.nombre_error))
        if cache:
            _cache_guardar(url, datos)
        return datos


_CS_CLIENTE = _InteractvtyCliente(
    "Canal Sur Más", _CS_API, _CS_TOKEN_URL, _CS_ORIGEN, "canalsur", _cs_token, _cs_fichero_token)


def _cs_json(url, cache=True):
    return _CS_CLIENTE.json(url, cache=cache)


def _cs_es_video(tipo, final):
    if tipo == "VID" or tipo in ("DIR", "AUD"):
        return True
    if final is False:
        return False
    return tipo == "PRO"


def _cs_imagen(it):
    for clave in ("image", "image_medium", "alternative_image", "alternative_image_medium"):
        v = _s(it.get(clave))
        if v.startswith("http"):
            return v
    return ""


def _cs_meta(it):
    partes = []
    try:
        dur = int(float(it.get("duration") or 0))
    except (TypeError, ValueError):
        dur = 0
    if dur > 0:
        minutos = dur // 60000 if dur > 10000 else dur // 60
        if minutos > 0:
            partes.append("{0} min".format(minutos))
    fecha = _s(it.get("date")).split("T")[0]
    if fecha:
        partes.append(fecha)
    return " · ".join(partes)


_CS_ICONOS_TEMA = (
    (("toro", "deporte", "fútbol", "futbol", "baloncesto"), "cat_deportes.png"),
    (("noticia", "actualidad", "informativ"), "cat_noticias.png"),
    (("música", "musica", "musical"), "cat_musica.png"),
    (("cultura", "fiesta", "andaluc"), "cat_cultura.png"),
    (("serie", "ficci"), "cat_series.png"),
    (("cocina", "gastronom"), "cat_cocina.png"),
    (("infantil", "niño", "nino", "juvenil", "menudo"), "cat_infantil.png"),
    (("cine", "película", "pelicula"), "cat_cine.png"),
    (("documental",), "cat_documentales.png"),
    (("entretenimiento", "humor", "programa"), "rtve_entretenimiento.png"),
)


def _cs_icono_tema(nombre):
    clave = _s(nombre).lower()
    for palabras, icono in _CS_ICONOS_TEMA:
        if any(p in clave for p in palabras):
            return icono
    return "cat_tv.png"


def _cs_mapear(items, forzar_categoria=False, ocultas=_CS_OCULTAS, es_video_fn=None):
    """Items Interactvty -> nodos. Usa `_cs_es_video` por defecto salvo regla específica."""
    regla = es_video_fn or _cs_es_video
    out = []
    for it in items or []:
        if not isinstance(it, dict):
            continue
        id_ = _s(it.get("id"))
        if not id_:
            continue
        titulo = _s(it.get("name")) or "Contenido"
        if any(x in titulo.lower() for x in ocultas):
            continue
        tipo = _s(it.get("type")).upper()
        final = it.get("is_final") if isinstance(it.get("is_final"), bool) else None
        es_video = (not forzar_categoria) and regla(tipo, final)
        plot = _limpiar_html(it.get("long_description") or it.get("description")
                             or it.get("short_description"))
        imagen = _cs_imagen(it)
        if not imagen and (forzar_categoria or not es_video):
            imagen = _icono_propio(_cs_icono_tema(titulo), "")
        out.append(_nodo(("prog|" if es_video else "cat|") + id_, titulo,
                         "video" if es_video else "cat", imagen, plot, _cs_meta(it)))
    return out


def _cs_mas(datos):
    siguiente = _s(datos.get("next"))
    return [_nodo("url|" + siguiente, "Ver más", "cat")] if siguiente else []


def _cs_resultados(datos):
    r = datos.get("results") if isinstance(datos, dict) else None
    return r if isinstance(r, list) else []


def _cs_elegir_hls(recursos):
    """Primera media_url https cuyo camino termina en .m3u8 y que no lleva DRM.

    Si no hay ninguna, respaldo: la primera https sin DRM cuyo camino acaba en .mp4
    (las noticias de Canal Sur solo traen mp4 progresivo).
    Las `_1080p...` sin extensión no son HLS aunque cuelguen del mismo directorio."""
    mp4 = ""
    for r in recursos:
        if not isinstance(r, dict) or _s(r.get("drm_token")):
            continue
        url = _s(r.get("media_url"))
        if not url.startswith("https://"):
            continue
        camino = urllib.parse.urlparse(url).path.lower()
        if camino.endswith(".m3u8"):
            return url
        if not mp4 and camino.endswith(".mp4"):
            mp4 = url
    return mp4


class _InteractvtyAdaptador(Adaptador):
    """Base común para cadenas sobre Interactvty 2.0."""

    _cliente = None
    _ocultas = _CS_OCULTAS
    _contents_siempre_video = False
    _sin_categorias_msg = "No hay contenido disponible."

    def _regla_video(self, desde_contents):
        if self._contents_siempre_video:
            if desde_contents:
                return lambda tipo, final: True
            return lambda tipo, final: tipo in ("VID", "DIR", "AUD")
        return _cs_es_video

    def _mapear(self, datos, forzar_categoria=False, desde_contents=False):
        return _cs_mapear(
            _cs_resultados(datos),
            forzar_categoria=forzar_categoria,
            ocultas=self._ocultas,
            es_video_fn=self._regla_video(desde_contents),
        ) + _cs_mas(datos)

    def root(self):
        datos = self._cliente.json(self._cliente.api + "platform_categories/?target=WEB&" + _CS_CAMPOS)
        if datos is None:
            raise AutonomicaError(self._sin_categorias_msg)
        return self._mapear(datos, forzar_categoria=True)

    def children(self, nodo):
        tipo, _, valor = _s(nodo.get("id")).partition("|")
        if not valor:
            return []
        if tipo in ("cat", "folder", "prog"):
            return self._carpeta(valor)
        if tipo == "url":
            datos = self._cliente.json(valor)
            if datos is None:
                return []
            return self._mapear(
                datos,
                forzar_categoria=("platform_categories" in valor),
                desde_contents=("category_contents" in valor),
            )
        return []

    def _carpeta(self, id_):
        if not re.fullmatch(r"\d+", id_):
            _log("id de carpeta no numérico: {0!r}".format(id_), xbmc.LOGWARNING)
            return []
        for prefijo, ep in (
            ("category_contents", "category_contents/{0}/?" + _CS_CAMPOS),
            ("subcategory", "subcategory/{0}/?" + _CS_CAMPOS + "&page_size=200"),
            ("linked_categories", "linked_categories/{0}/?" + _CS_CAMPOS),
        ):
            datos = self._cliente.json(self._cliente.api + ep.format(id_))
            if datos is not None and _cs_resultados(datos):
                return self._mapear(datos, desde_contents=(prefijo == "category_contents"))
        return []

    def playback(self, nodo):
        id_ = _s(nodo.get("id")).partition("|")[2]
        if not re.fullmatch(r"\d+", id_):
            return {"url": "", "headers": {}, "web": "", "motivo": "Contenido no válido."}
        datos = self._cliente.json(
            self._cliente.api + "content_resources/{0}/?{1}".format(id_, _CS_CAMPOS_RES), cache=False)
        recursos = _cs_resultados(datos) if datos else []
        url = _cs_elegir_hls(recursos)
        if url:
            return {"url": url,
                    "headers": {"Origin": self._cliente.origen, "Referer": self._cliente.origen + "/"},
                    "web": "", "motivo": ""}
        if any(isinstance(r, dict) and _s(r.get("drm_token")) for r in recursos):
            motivo = "Este contenido tiene protección DRM y no se puede reproducir aquí."
        elif not any(isinstance(r, dict) and _s(r.get("media_url")) for r in recursos):
            motivo = "Este contenido no tiene vídeo disponible."
        else:
            motivo = "El vídeo no está en un formato compatible (no hay lista HLS https)."
        _log("sin reproducción para el contenido {0}: {1}".format(id_, motivo))
        return {"url": "", "headers": {}, "web": "", "motivo": motivo}


class CanalSurMas(_InteractvtyAdaptador):
    id = "canalsur"
    nombre = "Canal Sur Más"
    descripcion = "Programas y series de Canal Sur Televisión a la carta."
    icono = _icono_propio("tv_canalsur_mas.png")
    buscable = True
    _cliente = _CS_CLIENTE
    _ocultas = _CS_OCULTAS
    _contents_siempre_video = False
    _sin_categorias_msg = "Canal Sur Más no devolvió las categorías."


_AG_API = "https://api-agalega.interactvty.com/api/2.0/contents/"
_AG_TOKEN_URL = "https://www.agalega.gal/api/fetch-api/jwt/token"
_AG_ORIGEN = "https://www.agalega.gal"
_AG_OCULTAS = ("seguir vendo", "a miña lista", "contenedor")
_ag_token = {"valor": "", "ts": 0.0}


def _ag_fichero_token():
    return os.path.join(_dir_cache(), "autonomicas_agalega_token.json")


_AG_CLIENTE = _InteractvtyCliente(
    "AGalega", _AG_API, _AG_TOKEN_URL, _AG_ORIGEN, "agalega", _ag_token, _ag_fichero_token)


class AGalega(_InteractvtyAdaptador):
    id = "agalega"
    nombre = "AGalega (CRTVG)"
    descripcion = "Programas, series, documentais e cine de Televisión de Galicia."
    icono = _icono_propio("tv_agalega.png")
    buscable = True
    _cliente = _AG_CLIENTE
    _ocultas = _AG_OCULTAS
    _contents_siempre_video = True
    _sin_categorias_msg = "AGalega no devolvió las categorías."


# ---------------------------------------------------------------------------
# Telemadrid (últimos vídeos)
# ---------------------------------------------------------------------------

_TM_BASE = "https://www.telemadrid.es"
_TM_PROGRAMAS = _TM_BASE + "/programas/"
# Clave pública de política del reproductor Brightcove de Telemadrid (TelemadridCatalog.kt).
_TM_POLICY_KEY = (
    "BCpkADawqM3NEbF-VfhWkeqZ-VvbtOz3Ck-glPFUGbpuJZKbMZuXqUpB5QUIzHZcSBDRhqMED02XmDcxjSf"
    "h5O6KbAugVjXAZkUr1JvkXRtqnKUcE_x2JA5JhSZC7AFkFSzWcTKiOsiKe6C8E5gvQQIvMXtmuQQbzsaw3g")
_TM_NOMBRES = {
    "120-minutos": "120 Minutos", "deportes-tn": "Deportes TN", "madrid-directo": "Madrid Directo",
    "madrid-trabaja": "Madrid Trabaja", "telenoticias": "Telenoticias", "la-otra": "La Otra",
    "onda-madrid": "Onda Madrid",
}
_TM_MINUSCULAS = ("de", "del", "la", "las", "el", "los", "y", "en", "a")


def _tm_bonito(slug):
    partes = slug.split("-")
    return " ".join(p if (i and p in _TM_MINUSCULAS) else p[:1].upper() + p[1:]
                    for i, p in enumerate(partes))


def _tm_nombre(slug):
    return _TM_NOMBRES.get(slug) or _tm_bonito(slug)


def _tm_buscar_lista(elem):
    """ItemList dentro del JSON-LD, que viene anidado (p. ej. en `@graph`): primero uno con
    `@type == ItemList` y, si no, cualquier objeto con `itemListElement` (como findItemList)."""
    def tipado(e):
        if isinstance(e, dict):
            if e.get("@type") == "ItemList":
                return e
            hijos = e.values()
        elif isinstance(e, list):
            hijos = e
        else:
            return None
        for h in hijos:
            r = tipado(h)
            if r is not None:
                return r
        return None

    def cualquiera(e):
        if isinstance(e, dict):
            if e.get("itemListElement") is not None:
                return e
            hijos = e.values()
        elif isinstance(e, list):
            hijos = e
        else:
            return None
        for h in hijos:
            r = cualquiera(h)
            if r is not None:
                return r
        return None

    return tipado(elem) or cualquiera(elem)


def _tm_extraer(html):
    """(artículos, motivo). Un artículo es {slug, title, url, image}; si la lista sale vacía,
    `motivo` dice qué no se encontró."""
    bloques = re.findall(r'<script[^>]*type="application/ld\+json"[^>]*>(.*?)</script>', html, re.S | re.I)
    if not bloques:
        return [], "la página no tiene ningún bloque JSON-LD"
    hubo_lista = False
    for bloque in bloques:
        try:
            raiz = json.loads(bloque.strip())
        except ValueError:
            continue
        lista = _tm_buscar_lista(raiz)
        elementos = lista.get("itemListElement") if lista else None
        if not isinstance(elementos, list):
            continue
        hubo_lista = True
        out = []
        for e in elementos:
            if not isinstance(e, dict):
                continue
            url = _s(e.get("url")) or _s(e.get("@id"))
            nombre = _s(e.get("name"))
            if not url or not nombre or "/programas/" not in url:
                continue
            resto = url.split("/programas/", 1)[1].split("?")[0].strip("/").split("/")
            # slug/artículo: se descartan /programas/2/ (paginación) y las portadas de programa
            if len(resto) < 2 or not resto[0] or resto[0].isdigit():
                continue
            out.append({"slug": resto[0], "title": nombre, "url": url, "image": ""})
        if out:
            return out, ""
    if hubo_lista:
        return [], "el ItemList del JSON-LD no contiene vídeos de /programas/"
    return [], "ningún JSON-LD contiene un ItemList (¿ha cambiado la web?)"


def _tm_con_imagenes(articulos, html):
    """Empareja cada artículo con su foto por el enlace; si no, por orden (como withImages)."""
    por_url = {}
    for a in re.finditer(r'<a[^>]+href="([^"]*telemadrid\.es/programas/[^"]*)"[^>]*>(.*?)</a>', html, re.S | re.I):
        im = re.search(r'<img[^>]+src="([^"]*static\.telemadrid\.es/clip/[^"]*)"', a.group(2), re.I)
        if im and "_source-aspect-ratio" in im.group(1):
            por_url[a.group(1).split("?")[0].rstrip("/")] = im.group(1)
    en_orden = [m for m in re.findall(r'<img[^>]+src="([^"]*static\.telemadrid\.es/clip/[^"]*)"', html, re.I)
                if "_source-aspect-ratio" in m]
    for i, art in enumerate(articulos):
        exacta = por_url.get(art["url"].split("?")[0].rstrip("/"))
        art["image"] = exacta or (en_orden[i] if i < len(en_orden) else "")
    return articulos


def _tm_ids_brightcove(html):
    """(cuenta, id) del vídeo de un artículo, o ('', '') si no aparecen.

    Primero atributos `bc-account`/`bc-id` de la misma etiqueta; luego sueltos; luego el
    embed `players.brightcove.net/{cuenta}/{player}_default/index.html?videoId={id}`
    (incluso escapado `\\/` en JSON-LD)."""
    limpio = _s(html).replace("\\/", "/")
    for etiqueta in re.findall(r"<[^>]*\bbc-account=\"[^\"]+\"[^>]*>", limpio):
        cuenta = re.search(r'bc-account="([^"]+)"', etiqueta)
        vid = re.search(r'bc-id="([^"]+)"', etiqueta)
        if cuenta and vid:
            return cuenta.group(1), vid.group(1)
    cuenta = re.search(r'bc-account="([^"]+)"', limpio)
    vid = re.search(r'bc-id="([^"]+)"', limpio)
    emb = re.search(r'players\.brightcove\.net/(\d+)/([^/"]+)_default/index\.html\?videoId=(\d+)', limpio)
    return ((cuenta.group(1) if cuenta else (emb.group(1) if emb else "")),
            (vid.group(1) if vid else (emb.group(3) if emb else "")))


def _tm_elegir_hls(datos):
    """Primera fuente HLS https sin DRM de la respuesta de Brightcove."""
    fuentes = datos.get("sources") if isinstance(datos, dict) else None
    for f in fuentes if isinstance(fuentes, list) else []:
        if not isinstance(f, dict) or f.get("key_systems"):
            continue
        src = _s(f.get("src"))
        es_hls = "mpegurl" in _s(f.get("type")).lower() or _s(f.get("container")).upper() == "M3U8"
        if src.startswith("https://") and es_hls:
            return src
    return ""


def _brightcove_hls(servicio, cuenta, vid, policy_key, web_url=""):
    """Resuelve la primera fuente HLS https sin DRM desde la API de Playback de Brightcove."""
    api = "https://edge.api.brightcove.com/playback/v1/accounts/{0}/videos/{1}".format(cuenta, vid)
    estado, texto = _peticion("GET", api, headers={"Accept": "application/json;pk=" + policy_key})
    if estado != 200:
        _log("{0}: Brightcove {1}/{2} respondió HTTP {3}".format(servicio, cuenta, vid, estado),
             xbmc.LOGWARNING)
        return {"url": "", "headers": {}, "web": web_url,
                "motivo": "Brightcove no entrega el vídeo (HTTP {0}).".format(estado)}
    try:
        datos = json.loads(texto)
    except ValueError:
        datos = None
    hls = _tm_elegir_hls(datos)
    if not hls:
        fuentes = datos.get("sources") if isinstance(datos, dict) else None
        tipos = sorted({_s(f.get("type")) or _s(f.get("container"))
                        for f in (fuentes if isinstance(fuentes, list) else [])
                        if isinstance(f, dict)})
        _log("{0}: Brightcove {1}/{2} sin fuente HLS https sin DRM (tipos: {3})".format(
            servicio, cuenta, vid, ", ".join(tipos) or "ninguna fuente"), xbmc.LOGWARNING)
        return {"url": "", "headers": {}, "web": web_url,
                "motivo": "El vídeo no tiene una versión HLS reproducible."}
    return {"url": hls, "headers": {}, "web": web_url, "motivo": ""}


def _og_detail(servicio, url, base_url):
    """Extrae título, descripción, fecha e imagen desde meta OpenGraph tras validar el origen."""
    if not url.startswith(base_url + "/"):
        return {}
    estado, html = _peticion("GET", url)
    if estado != 200:
        raise AutonomicaError(_msg_http(servicio, estado))
    titulo = _limpiar_html(_tm_meta_tag(html, "og:title"))
    desc = _limpiar_html(_tm_meta_tag(html, "og:description") or _tm_meta_tag(html, "description"))
    fecha = _tm_meta_tag(html, "article:published_time").split("T")[0]
    imagen = _tm_meta_tag(html, "og:image")
    return {"titulo": titulo, "descripcion": desc, "fecha": fecha, "imagen": imagen, "url": url}


def _tm_meta_tag(html, clave):
    """Lee el `content` de un `<meta property|name="clave">` sin depender del orden de atributos."""
    patron = r'<meta\b[^>]*(?:property|name)=["\']' + re.escape(clave) + r'["\'][^>]*>'
    for tag in re.findall(patron, html, re.I):
        m = re.search(r'\bcontent=["\']([^"\']*)["\']', tag, re.I)
        if m and m.group(1).strip():
            return m.group(1).strip()
    return ""


class TelemadridVideos(Adaptador):
    id = "telemadrid"
    nombre = "Últimos vídeos de Telemadrid"
    descripcion = "Vídeos recientes de los programas de Telemadrid (no el archivo completo)."
    icono = _icono_propio("tv_telemadrid_videos.png")
    buscable = True

    def _pagina(self, n):
        """Artículos de la página n de /programas/ (caché corta). AutonomicaError si falla."""
        url = _TM_PROGRAMAS if n == 1 else "{0}{1}/".format(_TM_PROGRAMAS, n)
        guardado = _cache_leer(url)
        if isinstance(guardado, list):
            return guardado
        estado, html = _peticion("GET", url)
        if estado != 200:
            _log("Telemadrid {0}: HTTP {1}".format(url, estado), xbmc.LOGWARNING)
            raise AutonomicaError(_msg_http("Telemadrid", estado))
        articulos, motivo = _tm_extraer(html)
        if not articulos:
            _log("Telemadrid {0}: sin vídeos, {1}".format(url, motivo), xbmc.LOGWARNING)
            return []
        articulos = _tm_con_imagenes(articulos, html)
        _cache_guardar(url, articulos)
        return articulos

    def root(self):
        articulos, vistos, fallo = [], set(), None
        for n in (1, 2, 3):
            try:
                pagina = self._pagina(n)
            except AutonomicaError as e:
                if n == 1:
                    raise
                fallo = e
                continue
            for a in pagina:
                if a["url"] not in vistos:
                    vistos.add(a["url"])
                    articulos.append(a)
        if not articulos:
            raise (fallo or AutonomicaError("Telemadrid no devolvió vídeos. Inténtalo más tarde."))
        grupos = {}
        for a in articulos:
            grupos.setdefault(a["slug"], []).append(a)
        nodos = [_nodo("prog|" + slug, _tm_nombre(slug), "cat", lista[0]["image"],
                       "1 vídeo" if len(lista) == 1 else "{0} vídeos".format(len(lista)))
                 for slug, lista in grupos.items()]
        return sorted(nodos, key=lambda x: x["titulo"].casefold())

    def children(self, nodo):
        partes = _s(nodo.get("id")).split("|")
        tipo, slug = partes[0], (partes[1] if len(partes) > 1 else "")
        if not slug:
            return []
        if tipo == "more":
            primera = int(partes[2]) if len(partes) > 2 and partes[2].isdigit() else 4
        else:
            primera = 1
        ultima = primera + 2
        out, vistos = [], set()
        for n in range(primera, ultima + 1):
            try:
                pagina = self._pagina(n)
            except AutonomicaError:
                if not out and n == primera:
                    raise
                break
            if not pagina:
                break
            for a in pagina:
                if a["slug"] == slug and a["url"] not in vistos:
                    vistos.add(a["url"])
                    out.append(_nodo("video|" + a["url"], a["title"], "video", a["image"], _tm_nombre(slug)))
            if len(pagina) < 10:
                break
        if out and ultima < _MAX_PAGINAS_TM:
            out.append(_nodo("more|{0}|{1}".format(slug, ultima + 1), "Ver más", "cat"))
        return out

    def playback(self, nodo):
        url = _s(nodo.get("id")).partition("|")[2]
        if not url.startswith(_TM_BASE + "/"):
            return {"url": "", "headers": {}, "web": "", "motivo": "Contenido no válido."}
        estado, html = _peticion("GET", url)
        if estado != 200:
            _log("Telemadrid: el artículo {0} dio HTTP {1}".format(url, estado), xbmc.LOGWARNING)
            raise AutonomicaError(_msg_http("Telemadrid", estado))
        cuenta, vid = _tm_ids_brightcove(html)
        if not cuenta or not vid:
            _log("Telemadrid {0}: no se encontró bc-account/bc-id ni el embed de Brightcove "
                 "en el HTML del artículo (cuenta={1!r}, id={2!r})".format(url, cuenta, vid),
                 xbmc.LOGWARNING)
            return {"url": "", "headers": {}, "web": url,
                    "motivo": "No se encontró el vídeo en la página del artículo."}
        return _brightcove_hls("Telemadrid", cuenta, vid, _TM_POLICY_KEY, url)

    def detail(self, nodo):
        """Obtiene título, descripción, fecha e imagen desde los meta OpenGraph del artículo/programa."""
        partes = _s(nodo.get("id")).split("|", 1)
        tipo, valor = partes[0], (partes[1] if len(partes) > 1 else "")
        if tipo == "video":
            url = valor
        elif tipo == "prog" and re.fullmatch(r"[a-z0-9-]+", valor):
            url = "{0}{1}/".format(_TM_PROGRAMAS, valor)
        else:
            return {}
        return _og_detail("Telemadrid", url, _TM_BASE)


# ---------------------------------------------------------------------------
# 3Cat (TV3)
# ---------------------------------------------------------------------------

_TC_API = "https://api.3cat.cat/"
_TC_PVIDEO = "https://dinamics.ccma.cat/pvideo/media.jsp"
_TC_QS = "_format=json&version=2.0&https=true&master=yes"
_TC_LETRAS = ("#",) + tuple("ABCDEFGHIJKLMNOPQRSTUVWXYZ")


def _tc_json(url, cache=True):
    if not (url.startswith(_TC_API) or url.startswith(_TC_PVIDEO)):
        raise AutonomicaError("Dirección no válida.")
    if cache:
        guardado = _cache_leer(url)
        if isinstance(guardado, dict):
            return guardado
    estado, texto = _peticion("GET", url, headers={"Accept": "application/json, text/plain, */*"})
    if estado in (400, 404):
        return None
    if estado != 200:
        raise AutonomicaError(_msg_http("3Cat", estado))
    try:
        datos = json.loads(texto)
    except ValueError:
        datos = None
    if not isinstance(datos, dict):
        raise AutonomicaError("3Cat devolvió una respuesta no válida.")
    if cache:
        _cache_guardar(url, datos)
    return datos


def _tc_imagen(imatges):
    if not isinstance(imatges, list):
        return ""
    mejor, por_mida = "", {}
    for img in imatges:
        if not isinstance(img, dict):
            continue
        url = _s(img.get("text"))
        if not url.startswith("https://"):
            continue
        if not mejor:
            mejor = url
        mida = _s(img.get("mida")).upper()
        if mida not in por_mida:
            por_mida[mida] = url
    for pref in ("1014X570", "670X378", "MASTER", "426X240"):
        if pref in por_mida:
            return por_mida[pref]
    return mejor


def _tc_meta(it):
    partes = []
    dur = _s(it.get("durada"))
    if ":" in dur:
        trozos = dur.split(":")
        try:
            hh, mm = int(trozos[0]), int(trozos[1])
            total_min = hh * 60 + mm
            if total_min > 0:
                partes.append("{0} min".format(total_min))
        except (ValueError, IndexError):
            pass
    fecha = _s(it.get("data_emissio")).split(" ")[0]
    if fecha:
        partes.append(fecha)
    return " · ".join(partes)


def _tc_paginar(datos, prefix):
    pag = datos.get("paginacio") if isinstance(datos, dict) else None
    if not isinstance(pag, dict):
        return []
    actual = int(pag.get("pagina_actual") or 0)
    total = int(pag.get("total_pagines") or 0)
    if actual > 0 and actual < total:
        return [_nodo("{0}|{1}".format(prefix, actual + 1), "Ver más", "cat")]
    return []


def _tc_elegir_media(datos):
    """(url, web, motivo) desde la respuesta de `dinamics.ccma.cat/pvideo/media.jsp`."""
    info = datos.get("informacio") if isinstance(datos, dict) else None
    estat = info.get("estat") if isinstance(info, dict) else None
    web = _s(info.get("permalink")) if isinstance(info, dict) else ""
    if isinstance(estat, dict) and estat.get("actiu") is False:
        return "", web, "Este vídeo ya no está disponible en 3Cat."
    media = datos.get("media") if isinstance(datos, dict) else None
    urls = media.get("url") if isinstance(media, dict) else None
    candidatos = [u for u in (urls if isinstance(urls, list) else []) if isinstance(u, dict)]
    activos, resto = [], []
    for u in candidatos:
        file_u = _s(u.get("file"))
        if not file_u.startswith("https://"):
            continue
        camino = urllib.parse.urlparse(file_u).path.lower()
        if camino.endswith(".m3u8"):
            return file_u, web, ""
        (activos if u.get("active") else resto).append(file_u)
    elegida = (activos + resto)[0] if (activos or resto) else ""
    if elegida:
        return elegida, web, ""
    geo = _s(media.get("geo")).upper() if isinstance(media, dict) else ""
    if geo and geo != "TOTS":
        return "", web, "Este vídeo de 3Cat puede estar limitado por zona geográfica (prueba con VPN)."
    return "", web, "3Cat no entrega un vídeo reproducible para este contenido."


class TresCat(Adaptador):
    id = "3cat"
    nombre = "3Cat (TV3)"
    descripcion = "Programes, sèries i documentals de 3Cat / TV3 a la carta."
    icono = _icono_propio("tv_3cat.png")
    buscable = True

    def root(self):
        return [
            _nodo("tot|1", "Novedades TV", "cat", _icono_propio("cat_tv.png"),
                  "Últimos programas y vídeos destacados de 3Cat."),
            _nodo("az|", "Programas (A-Z)", "cat", _icono_propio("cat_series.png"),
                  "Catálogo alfabético de programas de TV3 / 3Cat."),
        ]

    def children(self, nodo):
        partes = _s(nodo.get("id")).split("|")
        tipo = partes[0]
        if tipo == "az":
            ico = _icono_propio("cat_tv.png")
            return [_nodo("letra|{0}|1".format(letra), letra, "cat", ico) for letra in _TC_LETRAS]
        if tipo == "letra" and len(partes) >= 2:
            letra = partes[1]
            pag = int(partes[2]) if len(partes) > 2 and partes[2].isdigit() else 1
            url = "{0}programestv?{1}&lletra={2}&items_pagina=40&pagina={3}".format(
                _TC_API, _TC_QS, urllib.parse.quote(letra), pag)
            datos = _tc_json(url)
            resp = datos.get("resposta", {}) if datos else {}
            lletres = resp.get("items", {}).get("lletra") or []
            out = []
            for grp in lletres:
                for it in grp.get("item") or []:
                    pid = _s(it.get("id"))
                    if pid:
                        out.append(_nodo("prog|" + pid + "|1", _s(it.get("titol")) or "Programa", "cat",
                                         _tc_imagen(it.get("imatges")), _limpiar_html(it.get("entradeta"))))
            return out + _tc_paginar(resp, "letra|" + letra)
        if tipo == "tot":
            pag = int(partes[1]) if len(partes) > 1 and partes[1].isdigit() else 1
            url = "{0}tot?{1}&frontal=trescat-tresplay-novtotweb&items_pagina=25&pagina={2}".format(
                _TC_API, _TC_QS, pag)
            datos = _tc_json(url)
            resp = datos.get("resposta", {}) if datos else {}
            out = []
            for it in resp.get("items", {}).get("item") or []:
                cid = _s(it.get("id"))
                if not cid:
                    continue
                es_vid = bool(it.get("durada") or it.get("tipus_contingut"))
                nid = ("video|" if es_vid else "prog|") + cid + ("" if es_vid else "|1")
                out.append(_nodo(nid, _s(it.get("titol")) or "Contenido", "video" if es_vid else "cat",
                                 _tc_imagen(it.get("imatges")), _limpiar_html(it.get("entradeta")),
                                 _tc_meta(it)))
            return out + _tc_paginar(resp, "tot")
        if tipo == "prog" and len(partes) >= 2:
            pid = partes[1]
            if not re.fullmatch(r"\d+", pid):
                return []
            pag = int(partes[2]) if len(partes) > 2 and partes[2].isdigit() else 1
            url = "{0}videos?{1}&programatv_id={2}&items_pagina=25&pagina={3}".format(
                _TC_API, _TC_QS, pid, pag)
            datos = _tc_json(url)
            resp = datos.get("resposta", {}) if datos else {}
            out = []
            for it in resp.get("items", {}).get("item") or []:
                vid = _s(it.get("id"))
                if vid:
                    out.append(_nodo("video|" + vid, _s(it.get("titol")) or "Capítulo", "video",
                                     _tc_imagen(it.get("imatges")), _limpiar_html(it.get("entradeta")),
                                     _tc_meta(it)))
            return out + _tc_paginar(resp, "prog|" + pid)
        return []

    def playback(self, nodo):
        vid = _s(nodo.get("id")).partition("|")[2]
        if not re.fullmatch(r"\d+", vid):
            return {"url": "", "headers": {}, "web": "", "motivo": "Contenido no válido."}
        datos = _tc_json("{0}?media=video&version=0s&idint={1}".format(_TC_PVIDEO, vid), cache=False)
        if not datos:
            return {"url": "", "headers": {}, "web": "", "motivo": "Este vídeo no está disponible en 3Cat."}
        url, web, motivo = _tc_elegir_media(datos)
        return {"url": url, "headers": {}, "web": web, "motivo": motivo}


# ---------------------------------------------------------------------------
# À Punt
# ---------------------------------------------------------------------------

_AP_BASE = "https://www.apuntmedia.es"
_AP_AZ = _AP_BASE + "/alacarta/programes-az/"
# Clave pública de política del reproductor Brightcove de À Punt.
_AP_POLICY_KEY = (
    "BCpkADawqM2Yrv2qlBGpB2FCRjQ97X2SDg4r2xbdzl5jKZbkiKrGFaQ2mCXaaNZWyEyQPtX4LR7OCKmY"
    "pat8jXceN9PP_qZMOMQSbNqeDf5kln0xC0-cI2KoRkf8ab1FLRVNVCORQA9ME8vg")
_AP_RE_PROGRAMA = re.compile(
    r'<a\b[^>]*href="(https://www\.apuntmedia\.es/programes/[^"?#]+)"[^>]*>(.*?)</a>',
    re.S | re.I)
_AP_RE_VIDEO = re.compile(
    r'<a\b([^>]*href="(https://www\.apuntmedia\.es/[^"?#]+?_\d+_\d+\.html)"[^>]*)>(.*?)</a>',
    re.S | re.I)


def _ap_html(url):
    if not url.startswith(_AP_BASE + "/"):
        raise AutonomicaError("Dirección no válida.")
    guardado = _cache_leer(url)
    if isinstance(guardado, str):
        return guardado
    estado, html = _peticion("GET", url)
    if estado != 200:
        raise AutonomicaError(_msg_http("À Punt", estado))
    _cache_guardar(url, html)
    return html


def _ap_extraer_programas(html):
    out, vistos = [], set()
    for url, cuerpo in _AP_RE_PROGRAMA.findall(html):
        if url in vistos or url.endswith(".html"):
            continue
        vistos.add(url)
        titulo = _limpiar_html(cuerpo).lstrip("• ").strip() or url.rstrip("/").split("/")[-1]
        out.append(_nodo("prog|" + url, titulo, "cat", _icono_propio("cat_tv.png")))
    return out


def _ap_extraer_videos(html):
    out, vistos = [], set()
    for attrs, url, cuerpo in _AP_RE_VIDEO.findall(html):
        if url in vistos or any(x in url for x in ("/directe/", "/sala-de-premsa/", "/noticies/")):
            continue
        vistos.add(url)
        mt = re.search(r'\btitle="([^"]+)"', attrs, re.I)
        ma = re.search(r'\balt="([^"]+)"', cuerpo, re.I)
        titulo = _limpiar_html(mt.group(1) if mt else (ma.group(1) if ma else cuerpo))
        if not titulo:
            titulo = url.rsplit("/", 1)[-1].split("_")[0].replace("-", " ").capitalize()
        mi = re.search(r'<img\b[^>]*src="(https://[^"]+)"', cuerpo, re.I)
        imagen = mi.group(1) if mi else ""
        out.append(_nodo("video|" + url, titulo, "video", imagen))
    return out


class APunt(Adaptador):
    id = "apunt"
    nombre = "À Punt"
    descripcion = "Programes, pel·lícules i documentals d'À Punt a la carta."
    icono = _icono_propio("tv_apunt.png")
    buscable = True

    def root(self):
        return [
            _nodo("cat|" + _AP_BASE + "/pel-licules/", "Películas", "cat", _icono_propio("cat_cine.png")),
            _nodo("cat|" + _AP_BASE + "/documentals/portada/", "Documentales", "cat",
                  _icono_propio("cat_documentales.png")),
            _nodo("az|" + _AP_AZ, "Programas", "cat", _icono_propio("cat_tv.png")),
        ]

    def children(self, nodo):
        tipo, _, url = _s(nodo.get("id")).partition("|")
        if not url.startswith(_AP_BASE + "/"):
            return []
        html = _ap_html(url)
        if tipo == "az":
            return _ap_extraer_programas(html)
        videos = _ap_extraer_videos(html)
        if videos or tipo != "prog":
            return videos
        slug_base = urllib.parse.urlparse(url).path.rstrip("/")
        for rel in re.findall(r'href="((?:https://www\.apuntmedia\.es)?' + re.escape(slug_base)
                              + r'/(?:complets|programes|capitols)/)"', html, re.I):
            sub_url = rel if rel.startswith(_AP_BASE) else (_AP_BASE + rel)
            videos = _ap_extraer_videos(_ap_html(sub_url))
            if videos:
                return videos
        return []

    def playback(self, nodo):
        url = _s(nodo.get("id")).partition("|")[2]
        if not url.startswith(_AP_BASE + "/"):
            return {"url": "", "headers": {}, "web": "", "motivo": "Contenido no válido."}
        estado, html = _peticion("GET", url)
        if estado != 200:
            raise AutonomicaError(_msg_http("À Punt", estado))
        cuenta, vid = _tm_ids_brightcove(html)
        if not cuenta or not vid:
            return {"url": "", "headers": {}, "web": url,
                    "motivo": "No se encontró el vídeo en la página de À Punt."}
        return _brightcove_hls("À Punt", cuenta, vid, _AP_POLICY_KEY, url)

    def detail(self, nodo):
        partes = _s(nodo.get("id")).split("|", 1)
        if len(partes) < 2 or partes[0] not in ("video", "prog"):
            return {}
        return _og_detail("À Punt", partes[1], _AP_BASE)


registrar(CanalSurMas())
registrar(TelemadridVideos())
registrar(AGalega())
registrar(TresCat())
registrar(APunt())


# ---------------------------------------------------------------------------
# Pantallas del plugin
# ---------------------------------------------------------------------------

def _avisar(mensaje, tipo=None):
    try:
        xbmcgui.Dialog().notification(
            "Autonómicas a la carta", mensaje,
            xbmcgui.NOTIFICATION_WARNING if tipo is None else tipo, 5000)
    except Exception as e:  # noqa: BLE001 - un aviso nunca debe romper nada
        _log("no se pudo mostrar el aviso: {0}".format(e), xbmc.LOGWARNING)


def _fin(h, ok=True):
    try:
        xbmcplugin.endOfDirectory(h, succeeded=ok, cacheToDisc=False)
    except Exception as e:  # noqa: BLE001
        _log("endOfDirectory: {0}".format(e), xbmc.LOGWARNING)


def menu():
    """Entrada 'Autonómicas a la carta': una carpeta por cadena registrada."""
    h = _handle()
    for ad in list(ADAPTADORES.values()):
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(ad.nombre))
        li.setArt({"icon": ad.icono, "thumb": ad.icono})
        li.setInfo("video", {"plot": ad.descripcion})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="autonomicas_dir", prov=ad.id, nodo="", titulo=ad.nombre),
                                    listitem=li, isFolder=True)
    _fin(h)


def _etiquetar(li, titulo, plot):
    try:
        etiqueta = li.getVideoInfoTag()
        etiqueta.setMediaType("video")
        etiqueta.setTitle(titulo)
        if plot:
            etiqueta.setPlot(plot)
    except AttributeError:
        li.setInfo("video", {"title": titulo, "plot": plot} if plot else {"title": titulo})


def _cargar_nodos(ad, nodo=""):
    return ad.root() if not nodo else ad.children({"id": nodo})


def listar(prov, nodo="", titulo="", filtro=""):
    """Raíz (nodo vacío) o hijos de un nodo de la cadena `prov`. Si la cadena falla: aviso y
    directorio cerrado sin éxito, sin tocar el resto del menú."""
    h = _handle()
    ad = _adaptador(prov)
    if ad is None:
        _log("adaptador desconocido: {0!r}".format(prov), xbmc.LOGWARNING)
        _avisar("Cadena no disponible.")
        _fin(h, False)
        return
    try:
        nodos = _cargar_nodos(ad, nodo)
    except AutonomicaError as e:
        _log("{0}: {1}".format(prov, e.mensaje), xbmc.LOGWARNING)
        _avisar(e.mensaje)
        _fin(h, False)
        return
    except Exception as e:  # noqa: BLE001 - la cadena puede fallar de cualquier forma
        _log("{0}: error inesperado listando {1!r}: {2!r}".format(prov, nodo, e), xbmc.LOGERROR)
        _avisar("{0} no responde ahora mismo.".format(ad.nombre))
        _fin(h, False)
        return
    if not nodos:
        _avisar("No hay contenido en esta sección.")
        _fin(h, False)
        return
    buscable = bool(getattr(ad, "buscable", False))
    filtro_activo = _s(filtro) if buscable else ""
    if filtro_activo:
        nodos = _filtrar_nodos(nodos, filtro_activo)
        if not nodos:
            _avisar("Sin resultados para '{0}'.".format(filtro_activo))
            _fin(h, False)
            return
    try:
        if titulo:
            xbmcplugin.setPluginCategory(h, titulo)
        # Sin setContent('videos') para que Estuary/Espatuary pinte miniaturas e iconos en el botón y no el punto de visto
        if buscable:
            if filtro_activo:
                li_f = xbmcgui.ListItem(label="[B]Quitar filtro ({0})[/B]".format(filtro_activo))
                ico_b = _icono_propio("rtve_buscar.png", ad.icono)
                li_f.setArt({"icon": ico_b, "thumb": ico_b})
                _etiquetar(li_f, "Quitar filtro", "Volver a mostrar todos los elementos de esta lista.")
                xbmcplugin.addDirectoryItem(
                    handle=h,
                    url=_u(action="autonomicas_dir", prov=ad.id, nodo=nodo, titulo=titulo),
                    listitem=li_f, isFolder=True)
            else:
                li_b = xbmcgui.ListItem(label="[B]Buscar / filtrar...[/B]")
                ico_b = _icono_propio("rtve_buscar.png", ad.icono)
                li_b.setArt({"icon": ico_b, "thumb": ico_b})
                _etiquetar(li_b, "Buscar / filtrar...", "Filtra por texto esta lista de {0}.".format(ad.nombre))
                xbmcplugin.addDirectoryItem(
                    handle=h,
                    url=_u(action="autonomicas_buscar", prov=ad.id, nodo=nodo, titulo=titulo),
                    listitem=li_b, isFolder=False)
        tiene_ficha = hasattr(ad, "detail")
        for n in nodos:
            li = xbmcgui.ListItem(label=n["titulo"])
            icono = n["imagen"] or ad.icono
            li.setArt({"icon": icono, "thumb": icono, "poster": icono} if n["imagen"] else {"icon": icono, "thumb": icono})
            plot = "\n".join(x for x in (n["meta"], n["plot"]) if x)
            _etiquetar(li, n["titulo"], plot)
            if tiene_ficha and _s(n.get("id")).startswith(("video|", "prog|")):
                li.addContextMenuItems([(
                    "Ver ficha",
                    "RunPlugin({0})".format(_u(action="autonomicas_ficha", prov=ad.id, nodo=n["id"], titulo=n["titulo"])),
                )])
            if n["tipo"] == "video":
                li.setProperty("IsPlayable", "true")
                url = _u(action="autonomicas_play", prov=ad.id, nodo=n["id"], titulo=n["titulo"])
                xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=False)
            else:
                url = _u(action="autonomicas_dir", prov=ad.id, nodo=n["id"], titulo=n["titulo"])
                xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=True)
    except Exception as e:  # noqa: BLE001
        _log("{0}: error pintando el listado: {1!r}".format(prov, e), xbmc.LOGERROR)
        _avisar("No se pudo mostrar la lista.")
    _fin(h)


def buscar(prov, nodo="", titulo=""):
    """Pide texto, comprueba coincidencias y actualiza el contenedor con `filtro=` (sin endOfDirectory)."""
    ad = _adaptador(prov)
    if ad is None:
        _avisar("Cadena no disponible.")
        return
    texto = _s(xbmcgui.Dialog().input("Buscar en {0}".format(ad.nombre)))
    if not texto:
        return
    try:
        nodos = _cargar_nodos(ad, nodo)
    except AutonomicaError as e:
        _avisar(e.mensaje)
        return
    except Exception as e:  # noqa: BLE001
        _log("{0}: error buscando en {1!r}: {2!r}".format(prov, nodo, e), xbmc.LOGERROR)
        _avisar("{0} no responde ahora mismo.".format(ad.nombre))
        return
    if not _filtrar_nodos(nodos, texto):
        _avisar("Sin resultados para '{0}'.".format(texto))
        return
    url = _u(action="autonomicas_dir", prov=ad.id, nodo=nodo, titulo=titulo, filtro=texto)
    xbmc.executebuiltin("Container.Update({0})".format(url))


def ver_ficha(prov, nodo, titulo=""):
    """Muestra la ficha detallada bajo demanda en Dialog.textviewer (acción RunPlugin)."""
    ad = _adaptador(prov)
    if ad is None or not hasattr(ad, "detail"):
        _avisar("Ficha no disponible.")
        return
    try:
        info = ad.detail({"id": nodo})
    except AutonomicaError as e:
        _avisar(e.mensaje)
        return
    except Exception as e:  # noqa: BLE001
        _log("{0}: error cargando ficha {1!r}: {2!r}".format(prov, nodo, e), xbmc.LOGERROR)
        _avisar("No se pudo cargar la ficha.")
        return
    if not info:
        _avisar("No se encontró información para este elemento.")
        return
    cabecera = titulo or info.get("titulo") or ad.nombre
    lineas = []
    if info.get("titulo") and info.get("titulo") != cabecera:
        lineas.append(info["titulo"])
    if info.get("fecha"):
        lineas.append("Fecha: {0}".format(info["fecha"]))
    if info.get("descripcion"):
        lineas.append(info["descripcion"])
    if info.get("url"):
        lineas.append("Web: {0}".format(info["url"]))
    cuerpo = "\n\n".join(lineas) or "Sin información adicional."
    xbmcgui.Dialog().textviewer(cabecera, cuerpo)


def reproducir(prov, nodo, titulo=""):
    """Resuelve un vídeo con setResolvedUrl; si falla, False + aviso (nunca play_raw_url)."""
    h = _handle()
    ad = _adaptador(prov)
    motivo = "Cadena no disponible."
    if ad is not None:
        try:
            r = ad.playback({"id": nodo})
            if r.get("url"):
                url_limpia = r["url"].split("|", 1)[0]
                cab = r.get("headers") or {}
                ruta = r["url"]
                if cab and "|" not in r["url"]:
                    ruta = "{0}|{1}".format(r["url"], urllib.parse.urlencode(cab))
                li = xbmcgui.ListItem(path=ruta)
                _etiquetar(li, titulo, "")
                camino = urllib.parse.urlparse(url_limpia).path.lower()
                if camino.endswith(".m3u8"):
                    li.setMimeType("application/vnd.apple.mpegurl")
                    li.setContentLookup(False)
                    ia_ok = xbmc.getCondVisibility("System.HasAddon(inputstream.adaptive)")
                    if ia_ok is True or ia_ok == 1:
                        li.setProperty("inputstream", "inputstream.adaptive")
                        li.setProperty("inputstream.adaptive.manifest_type", "hls")
                        if cab:
                            cab_qs = urllib.parse.urlencode(cab)
                            li.setProperty("inputstream.adaptive.stream_headers", cab_qs)
                            li.setProperty("inputstream.adaptive.manifest_headers", cab_qs)
                elif camino.endswith(".mp4"):
                    li.setMimeType("video/mp4")
                    li.setContentLookup(False)
                xbmcplugin.setResolvedUrl(h, True, li)
                _log("reproduciendo {0}: {1}".format(prov, url_limpia.split("?")[0]))
                return
            motivo = r.get("motivo") or "No se puede reproducir este vídeo."
        except AutonomicaError as e:
            motivo = e.mensaje
        except Exception as e:  # noqa: BLE001
            _log("{0}: error inesperado resolviendo {1!r}: {2!r}".format(prov, nodo, e), xbmc.LOGERROR)
            motivo = "No se pudo reproducir el vídeo."
    xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
    _avisar(motivo, xbmcgui.NOTIFICATION_ERROR)
