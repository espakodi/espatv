# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Estado de la ventana Modo Ajustes: filas, valores, ficha, dependencias y contadores.

Python puro (sin xbmcgui ni xbmc) para poder probarlo sin Kodi. La ventana se limita a pintar
los dicts que devuelve `filas()` y a ejecutar lo que decida `accion_ok()`.
"""
from __future__ import annotations

import os
import unicodedata

import ajustes_registro as R

MODIFICADOS = R.MODIFICADOS
CABECERA_MODIFICADOS = R.CABECERA_MODIFICADOS

_COLOR_TEXTO = 'FFC8D2E0'
_COLOR_VALOR = 'FFC8D2E0'
_COLOR_APAGADO = 'FF5A6678'
_COLOR_DESTRUCTIVO = 'FFEF4444'


def _texto_dependencia(valor):
    if valor is True:
        return 'activado'
    if valor is False:
        return 'desactivado'
    return str(valor)


def normalizar(texto):
    base = unicodedata.normalize('NFKD', texto or '')
    return ''.join(c for c in base if not unicodedata.combining(c)).lower()


class Modelo:
    def __init__(self, categorias, orden, version=''):
        self.categorias = {clave: list(entradas) for clave, entradas in (categorias or {}).items()}
        self.orden = list(orden or [])
        self.version = version
        self.cat_actual = self._primera_categoria()
        self._errores = set()
        self._deshacer = []
        self._por_id = {e.id: e for lista in self.categorias.values() for e in lista}

    # Categorías

    def _primera_categoria(self):
        for categoria in self.orden:
            if self.categorias.get(categoria.clave):
                return categoria.clave
        for clave, entradas in self.categorias.items():
            if entradas:
                return clave
        return self.orden[0].clave if self.orden else ''

    def categoria(self, clave=None):
        return next((c for c in self.orden if c.clave == (clave or self.cat_actual)), None)

    def _entradas(self, cat=None):
        return self.categorias.get(cat or self.cat_actual, [])

    def entradas(self):
        return list(self._por_id.values())

    # Lectura tolerante

    def leer(self, e):
        """Valor actual, o `_SIN_LEER` si el ajuste no se pudo leer (no rompe la categoría)."""
        if e.leer is None:
            return None
        try:
            return e.leer()
        except Exception:
            self._errores.add(e.id)
            return _SIN_LEER

    def _error(self, e):
        return e.id in self._errores

    # Formateo

    def formatear_valor(self, e):
        if e.tipo == 'bool':
            return ''
        if e.tipo == 'action':
            return 'Abrir ›'
        if e.tipo == 'clasico':
            return 'Abrir en ajustes clásicos ›'
        if e.tipo == 'info':
            return ''
        valor = self.leer(e)
        if valor is _SIN_LEER:
            return '—'
        if e.tipo == 'enum':
            return self._etiqueta_enum(e, valor)
        if e.tipo == 'slider':
            return '{0} min'.format(valor)
        if e.tipo == 'number':
            return str(valor)
        if e.tipo == 'folder':
            valor = '' if valor is None else str(valor)
            if not valor:
                return 'Sin configurar'
            return os.path.basename(valor.rstrip('\\/')) or valor
        if e.tipo == 'text':
            valor = '' if valor is None else str(valor)
            if e.secreto:
                return 'Configurado' if valor else 'Sin configurar'
            return valor or 'Sin configurar'
        return '' if valor is None else str(valor)

    def _etiqueta_enum(self, e, valor):
        opciones = tuple(e.opciones or ())
        if e.guarda_indice:
            try:
                indice = int(valor)
            except (TypeError, ValueError):
                return '{0} (desconocido)'.format(valor)
            if 0 <= indice < len(opciones):
                return opciones[indice]
            return '{0} (desconocido)'.format(valor)
        texto = '' if valor is None else str(valor)
        if opciones and texto not in opciones:
            return '{0} (desconocido)'.format(texto)
        return texto

    def _formatear_defecto(self, e):
        defecto = e.defecto
        if defecto is None:
            return '—'
        if e.tipo == 'bool':
            return 'Activado' if defecto else 'Desactivado'
        if e.tipo == 'enum':
            if e.guarda_indice:
                try:
                    indice = int(defecto)
                except (TypeError, ValueError):
                    return str(defecto)
                if 0 <= indice < len(e.opciones or ()):
                    return e.opciones[indice]
                return str(defecto)
            return str(defecto)
        if e.tipo == 'slider':
            return '{0} min'.format(defecto)
        if e.tipo == 'text' and e.secreto:
            return 'Configurado' if defecto else 'Sin configurar'
        if e.tipo == 'folder':
            return os.path.basename(str(defecto).rstrip('\\/')) or 'Sin configurar'
        return str(defecto)

    # Estado

    def habilitada(self, e):
        dependencia = tuple(e.depende_de or ())
        if not dependencia:
            return True
        if len(dependencia) == 2 and dependencia[0] == '__cond__':
            entradas = self._entradas(e.categoria if e.categoria in self.categorias else None)
            indice = next((i for i, otra in enumerate(entradas) if otra is e), -1)
            return R.evaluar_condicion(dependencia[1], entradas, indice, self._leer_id)
        if len(dependencia) != 2:
            return True
        return self._coincide(self._leer_id(dependencia[0]), dependencia[1])

    def _leer_id(self, ident):
        entrada = self._por_id.get(ident)
        if entrada is None:
            return None
        return self.leer(entrada)

    def _coincide(self, actual, esperado):
        if actual is _SIN_LEER or actual is None:
            return False
        if isinstance(actual, bool) or isinstance(esperado, bool):
            return bool(actual) == bool(esperado)
        if isinstance(esperado, int):
            try:
                return int(actual) == esperado
            except (TypeError, ValueError):
                return False
        return str(actual) == str(esperado)

    def modificada(self, e):
        if e.defecto is None or e.tipo not in R.TIPOS_CON_VALOR:
            return False
        # Apagado por su dependencia no está en efecto: contarlo sería ruido (la duración de la
        # caché IPTV sale «Desactivada» mientras la caché está apagada, que es lo de fábrica).
        if not self.habilitada(e):
            return False
        actual = self.leer(e)
        if actual is _SIN_LEER:
            return False
        return not self._coincide(actual, e.defecto)

    # Filas

    def filas(self, cat=None):
        return [self.fila(e) for e in self._entradas(cat)]

    def fila(self, e):
        habilitada = self.habilitada(e)
        modificada = self.modificada(e)
        valor = self.leer(e)
        on = '0'
        pct = '0'
        if e.tipo == 'bool':
            on = '1' if valor is True else '0'
        elif e.tipo in ('slider', 'number') and valor is not _SIN_LEER and valor is not None:
            pct = str(self._pct(e, valor))
        if not habilitada:
            color, color_valor = _COLOR_APAGADO, _COLOR_APAGADO
        elif e.destructivo:
            color, color_valor = _COLOR_DESTRUCTIVO, _COLOR_DESTRUCTIVO
        else:
            color, color_valor = _COLOR_TEXTO, _COLOR_VALOR
        return {
            'entrada': e,
            'rotulo': e.rotulo,
            # Tipos sin soporte visual en la ventana se pintan como acción.
            'tipo': 'action' if e.tipo == 'clasico' else e.tipo,
            'cabecera': e.cabecera or '',
            'valor': self.formatear_valor(e),
            'on': on,
            'pct': pct,
            'modificado': '1' if modificada else '0',
            'deshabilitado': '0' if habilitada else '1',
            'destructivo': '1' if e.destructivo else '0',
            'icono': e.icono or self._icono_categoria(e.categoria),
            'color': color,
            'color_valor': color_valor,
        }

    def _pct(self, e, valor):
        rango = tuple(e.rango or ())
        if len(rango) != 3:
            return 0
        minimo, _paso, maximo = rango
        if maximo <= minimo:
            return 0
        try:
            proporcion = (float(valor) - minimo) / float(maximo - minimo)
        except (TypeError, ValueError):
            return 0
        return max(0, min(20, int(round(proporcion * 20))))

    def _icono_categoria(self, clave):
        categoria = self.categoria(clave)
        return categoria.icono if categoria is not None else ''

    # Edición

    def siguiente_valor(self, e, delta):
        if e.confirmar or not self.habilitada(e) or e.tipo not in R.TIPOS_CON_VALOR:
            return None
        actual = self.leer(e)
        if actual is _SIN_LEER:
            return None
        if e.tipo == 'bool':
            return not bool(actual)
        if e.tipo == 'enum':
            opciones = tuple(e.opciones or ())
            if not opciones:
                return None
            if e.guarda_indice:
                try:
                    indice = int(actual)
                except (TypeError, ValueError):
                    indice = -1 if delta > 0 else len(opciones)
                if not (0 <= indice < len(opciones)):
                    return 0 if delta > 0 else len(opciones) - 1
                return (indice + (1 if delta > 0 else -1)) % len(opciones)
            texto = '' if actual is None else str(actual)
            if texto not in opciones:
                return opciones[0] if delta > 0 else opciones[-1]
            indice = opciones.index(texto)
            return opciones[(indice + (1 if delta > 0 else -1)) % len(opciones)]
        if e.tipo in ('slider', 'number'):
            rango = tuple(e.rango or ())
            if len(rango) != 3:
                return None
            minimo, paso, maximo = rango
            try:
                valor = int(actual)
            except (TypeError, ValueError):
                valor = minimo
            nuevo = valor + (paso or 1) * (1 if delta > 0 else -1)
            return nuevo if minimo <= nuevo <= maximo else None
        return None

    def aplicar(self, e, valor):
        if e.escribir is None:
            return False
        anterior = self.leer(e)
        try:
            e.escribir(valor)
        except Exception:
            return False
        if anterior is not _SIN_LEER:
            self._deshacer.append((e, anterior, valor))
        self._errores.discard(e.id)
        return True

    @property
    def n_deshacer(self):
        return len(self._deshacer)

    def deshacer_ultimo(self):
        while self._deshacer:
            entrada, anterior, _nuevo = self._deshacer.pop()
            if entrada.escribir is None:
                continue
            try:
                entrada.escribir(anterior)
            except Exception:
                continue
            self._errores.discard(entrada.id)
            return entrada
        return None

    def accion_ok(self, e):
        if e.tipo == 'info':
            return 'nada'
        if e.confirmar:
            return 'confirmar'
        return {
            'bool': 'alternar',
            'enum': 'seleccionar',
            'slider': 'numero',
            'number': 'numero',
            'text': 'texto',
            'folder': 'carpeta',
            'action': 'accion',
            'clasico': 'clasico',
        }.get(e.tipo, 'nada')

    # Ficha

    def ficha(self, e):
        ayuda = e.ayuda or 'Sin descripción.'
        if e.clase_accion == 'pantalla' and 'Atrás' not in ayuda:
            ayuda = '{0}\n\nAbre una pantalla aparte; vuelve con Atrás hasta Opciones.'.format(ayuda)
        if self._error(e):
            ayuda = 'No se pudo leer este ajuste. Se puede cambiar desde los ajustes clásicos de Kodi.'
        elif not self.habilitada(e):
            requisito = 'Para cambiar esto, antes hay que dejar «{0}» en {1}.'.format(
                self._rotulo_dependencia(e), self._valor_dependencia(e))
            ayuda = '{0}\n\n{1}'.format(e.ayuda, requisito) if e.ayuda else requisito
        modificada = self.modificada(e)
        # Un botón (acción) no tiene valor ni "de serie": la ficha deja vacío ese bloque y el XML lo oculta.
        sin_valor = e.tipo in ('action', 'clasico', 'info')
        if sin_valor:
            actual = ''
        elif self._error(e):
            actual = '—'
        elif e.tipo == 'bool':
            actual = 'Activado' if self.leer(e) is True else 'Desactivado'
        else:
            actual = self.formatear_valor(e) or '—'
        return {
            'ficha_titulo': e.rotulo,
            'ficha_ayuda': ayuda,
            'ficha_actual': actual,
            'ficha_defecto': '' if sin_valor else self._formatear_defecto(e),
            'ficha_tambien': e.tambien_en or ('Opciones, mantenimiento y anti-errores'
                                              if e.origen == 'opciones' else ''),
            'ficha_estado': '' if sin_valor else ('Modificado' if modificada else 'De serie'),
            'ficha_estado_color': 'FF38BDF8' if modificada else 'FF94A3B8',
            'ficha_icono': e.icono or self._icono_categoria(e.categoria),
            'ficha_atajos': self._atajos(e),
        }

    def _rotulo_dependencia(self, e):
        dependencia = tuple(e.depende_de or ())
        if len(dependencia) == 2 and dependencia[0] != '__cond__':
            entrada = self._por_id.get(dependencia[0])
            if entrada is not None:
                return entrada.rotulo
            return dependencia[0]
        return 'otro ajuste'

    def _valor_dependencia(self, e):
        dependencia = tuple(e.depende_de or ())
        if len(dependencia) == 2 and dependencia[0] != '__cond__':
            return _texto_dependencia(dependencia[1])
        return 'un valor concreto'

    def _atajos(self, e):
        if e.confirmar:
            return 'OK para cambiar · Menú: restaurar de serie'
        if e.tipo in ('bool', 'enum', 'slider', 'number'):
            return 'OK cambiar · ◄► alternar · Menú: restaurar de serie'
        if e.tipo in ('text', 'folder'):
            return 'OK cambiar · Menú: restaurar de serie'
        if e.tipo == 'action':
            return 'OK abrir'
        if e.tipo == 'clasico':
            return 'OK abrir los ajustes clásicos de Kodi'
        return 'Solo informativo'

    # Contadores

    def contadores(self):
        claves = []
        for categoria in self.orden:
            claves.append(categoria.clave)
        for clave in self.categorias:
            if clave not in claves:
                claves.append(clave)
        return {clave: sum(1 for e in self.categorias.get(clave, []) if self.modificada(e))
                for clave in claves}

    def total_modificados(self):
        return sum(self.contadores().values())

    # Búsqueda, modificados y restaurar

    def buscar(self, texto):
        aguja = normalizar(texto)
        if not aguja:
            return []
        filas = []
        for clave in self._claves_ordenadas():
            encontradas = [e for e in self.categorias.get(clave, [])
                           if self._coincide_busqueda(e, clave, aguja)]
            if encontradas:
                filas.extend(self._filas_de(encontradas, self._rotulo_categoria(clave)))
        return filas

    def modificados(self):
        filas = []
        for clave in self._claves_ordenadas():
            encontradas = [e for e in self.categorias.get(clave, [])
                           if not e.protegido and self.modificada(e)]
            if encontradas:
                filas.extend(self._filas_de(encontradas, self._rotulo_categoria(clave)))
        return filas

    def _claves_ordenadas(self):
        claves = [categoria.clave for categoria in self.orden]
        claves.extend(clave for clave in self.categorias if clave not in claves)
        return claves

    def _rotulo_categoria(self, clave):
        categoria = self.categoria(clave)
        return categoria.rotulo if categoria is not None else clave

    def _coincide_busqueda(self, e, clave, aguja):
        campos = (e.rotulo, e.ayuda, e.id, clave, self._rotulo_categoria(clave))
        return any(aguja in normalizar(campo) for campo in campos)

    def _filas_de(self, entradas, cabecera):
        filas = []
        for indice, entrada in enumerate(entradas):
            fila = self.fila(entrada)
            fila['cabecera'] = cabecera if indice == 0 else ''
            filas.append(fila)
        return filas

    def restaurar(self, e):
        if e.protegido or e.defecto is None or e.tipo not in R.TIPOS_CON_VALOR:
            return False
        if not self.modificada(e):
            return False
        return self.aplicar(e, e.defecto)

    def restaurar_categoria(self, cat):
        cambiadas = []
        for entrada in self._entradas(cat):
            if self.restaurar(entrada):
                cambiadas.append(entrada)
        return cambiadas

    def plan_restaurar_todo(self):
        tocan, protegidas = [], []
        for clave in self._claves_ordenadas():
            for entrada in self.categorias.get(clave, []):
                if entrada.tipo not in R.TIPOS_CON_VALOR or entrada.defecto is None:
                    continue
                (protegidas if entrada.protegido else tocan).append(entrada)
        return tocan, protegidas

    def restaurar_todo(self):
        tocan, _protegidas = self.plan_restaurar_todo()
        return sum(1 for entrada in tocan if self.restaurar(entrada))


class _SinLeer(object):
    def __repr__(self):
        return '<sin leer>'


_SIN_LEER = _SinLeer()
SIN_LEER = _SIN_LEER
