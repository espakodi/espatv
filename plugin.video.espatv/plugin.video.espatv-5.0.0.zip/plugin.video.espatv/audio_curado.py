# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Audio curado de Internet Archive para Música Libre.

Dos secciones:
  - "Canciones populares en español (1900-1924)": colección Lummis (Autry National Center),
    listada por búsqueda con caché y filtrada por licencia de dominio público en cada carga.
  - "Paisajes sonoros": lista fija de grabaciones de campo (Radio Aporee y una de Freesound),
    cada una con su licencia anotada.

Se reutilizan la búsqueda con caché y `_best_audio_url` de archive_org.py. La reproducción
resuelve con setResolvedUrl (nunca play_raw_url, que provoca bucles).
"""
import os
import re
import sys
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

import archive_org

_LOG = "[EspaTV-AUDIO]"

TITULO_LUMMIS = "Canciones populares en español (1900-1924)"
TITULO_PAISAJES = "Paisajes sonoros"
ICONO = "DefaultMusicSongs.png"  # respaldo de Kodi si falta el PNG propio
ICONO_LUMMIS = "audio_lummis.png"
ICONO_PAISAJES = "audio_paisajes.png"
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")


def icono_propio(nombre):
    """Ruta del PNG propio de resources/media; si no está, el icono genérico de Kodi."""
    ruta = os.path.join(_MEDIA, nombre)
    return ruta if os.path.isfile(ruta) else ICONO

_LUMMIS_QUERY = "collection:autrynationalcenter AND mediatype:audio AND identifier:WC.*"
_LUMMIS_CAMPOS = ["identifier", "title", "date", "creator", "licenseurl", "rights", "language"]
_LUMMIS_FILAS = 500           # la colección tiene unos 350 items: caben en una sola petición
_LUMMIS_ORDEN = "identifier asc"

_TXT_PDM = "Dominio público (Public Domain Mark 1.0)"
_TXT_BUCLE = "Para repetirlo en bucle, usa Repetir en el reproductor."

# Licencias de los paisajes sonoros: clave -> texto mostrado
_LICENCIAS = {
    "pdm": "Dominio público (PDM 1.0)",
    "cc0": "CC0 1.0 (dominio público)",
    "by-sa": "CC BY-SA 3.0 (atribución y compartir igual)",
}

# (identificador, título, duración en segundos, licencia, autor que se muestra)
# El autor solo se muestra donde la licencia lo exige (CC BY-SA); en el resto,
# el campo `creator` de la fuente suele ser un alias o un correo truncado.
PAISAJES = [
    ("aporee_2057_2974",   "Oleaje del Atlántico: cabo de Finisterre (Galicia)", 135, "by-sa", "udo noll"),
    ("aporee_59829_68684", "Oleaje del Mediterráneo: Puntas de Calnegre",        370, "pdm", ""),
    ("aporee_28211_32503", "Oleaje del Mediterráneo: Benicasim, Voramar (binaural)", 394, "pdm", ""),
    ("aporee_27546_31755", "Oleaje: playa de Sagunto con viento",                554, "pdm", ""),
    ("aporee_35567_40838", "Oleaje: Segura Beach",                               1689, "pdm", ""),
    ("aporee_23718_27569", "Lluvia: Barcelona, por la mañana (binaural)",        969, "pdm", ""),
    ("aporee_5945_7437",   "Lluvia: Ourense",                                    315, "by-sa", "udo noll"),
    ("aporee_47200_53630", "Tormenta y lluvia: Nigrán (Pontevedra)",             2285, "pdm", ""),
    ("aporee_68134_78893", "Bosque: Santa Ana, Cortézubi (Bizkaia)",             67, "pdm", ""),
    ("aporee_13303_15538", "Pájaros al amanecer: Morille (Salamanca)",           415, "pdm", ""),
    ("aporee_39083_44640", "Pájaros de jardín: Badajoz",                         155, "pdm", ""),
    ("aporee_64639_74601", "Cigarras junto al Guadalquivir: Córdoba",            183, "pdm", ""),
    ("aporee_39352_44980", "Ranas de noche: Agaete (Gran Canaria)",              204, "pdm", ""),
    ("FireFavorite",       "Chimenea (fuego)",                                   264, "cc0", ""),
]

_IDS_PAISAJES = {p[0] for p in PAISAJES}
_RE_ID_LUMMIS = re.compile(r"^wc\.[a-z0-9.]+$", re.IGNORECASE)
_RE_INTERPRETE = re.compile(r",\s*(?:sung|performed|played)\s+by\s+(.+?)\s*\.?\s*$", re.IGNORECASE)
_RE_ANIO = re.compile(r"^\s*(\d{4})")


# Utilidades

def _log(msg, nivel=None):
    xbmc.log("{0} {1}".format(_LOG, msg), xbmc.LOGINFO if nivel is None else nivel)


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


def _handle():
    return int(sys.argv[1])


def _avisar(msg, tipo=None):
    try:
        xbmcgui.Dialog().notification("EspaTV", msg, tipo or xbmcgui.NOTIFICATION_INFO, 4000)
    except Exception:  # noqa: BLE001
        pass


def _como_lista(valor):
    if isinstance(valor, (list, tuple)):
        return [str(v).strip() for v in valor if str(v).strip()]
    v = str(valor).strip() if valor is not None else ""
    return [v] if v else []


def _duracion_txt(seg):
    return "{0}:{1:02d}".format(seg // 60, seg % 60)


# Lummis: filtrado y texto (funciones puras, probadas sin red)

def es_dominio_publico(doc):
    """True solo si el campo licenseurl declara dominio público (Public Domain Mark / CC0)."""
    return "publicdomain" in str(doc.get("licenseurl", "")).lower()


def es_espanol(doc):
    langs = [l.lower() for l in _como_lista(doc.get("language"))]
    return any(l in ("spa", "spanish", "es") for l in langs)


def anio_de(doc):
    """Año de 4 cifras de `date`, o '' si falta o es 'XXXX' (WC.A.38). Sin strptime (falla en Kodi)."""
    for d in _como_lista(doc.get("date")):
        m = _RE_ANIO.match(d)
        if m and m.group(1) != "0000":
            return m.group(1)
    return ""


def _nombre_natural(nombre):
    """'Amate, Francisco, singer.' -> 'Francisco Amate'; sin coma se deja igual."""
    n = re.sub(r"[,\s]*\b(singer|performer|vocalist|musician)\b\.?\s*$", "", nombre.strip(), flags=re.IGNORECASE)
    n = n.strip(" ,.")
    if "," in n:
        ap, _, resto = n.partition(",")
        n = "{0} {1}".format(resto.strip(), ap.strip()).strip()
    return n


def _roles_interprete(doc):
    """Nombres del campo `creator` marcados como singer/performer."""
    return [_nombre_natural(c) for c in _como_lista(doc.get("creator"))
            if re.search(r"\b(singer|performer|vocalist)\b", c, re.IGNORECASE)]


def interprete_de(doc):
    """(título sin la cláusula del intérprete, intérprete) o (título, '') si no hay respaldo.

    El intérprete sale de "..., sung by X" / "performed by X" en el título de la fuente. Si el campo
    `creator` marca como intérprete a otra persona (p. ej. WC.B.25: título "sung by Manuela Garcia",
    creator "Uruchurtu, Rosendo, performer"), los metadatos se contradicen y no se muestra ninguno."""
    titulo = str(_como_lista(doc.get("title"))[0] if _como_lista(doc.get("title")) else doc.get("identifier", ""))
    m = _RE_INTERPRETE.search(titulo)
    if not m:
        return titulo, ""
    nombre = m.group(1).strip()
    roles = _roles_interprete(doc)
    if roles:
        apellidos = {r.split()[-1].lower() for r in roles if r.split()}
        if not any(w.lower().strip(".,") in apellidos for w in nombre.split()):
            return titulo, ""
    return titulo[:m.start()].strip(), nombre


def pistas_lummis(docs):
    """Pistas listables a partir de los documentos de la búsqueda: solo dominio público y en español."""
    pistas = []
    vistos = set()
    for d in docs or []:
        if not isinstance(d, dict):
            continue
        ident = str(d.get("identifier", "")).strip()
        if not _RE_ID_LUMMIS.match(ident) or ident.lower() in vistos:
            continue
        if not es_dominio_publico(d) or not es_espanol(d):
            continue
        vistos.add(ident.lower())
        titulo, interprete = interprete_de(d)
        pistas.append({"id": ident, "titulo": titulo or ident, "interprete": interprete, "anio": anio_de(d)})
    pistas.sort(key=lambda p: (p["anio"] or "9999", _clave_natural(p["id"])))
    return pistas


def _clave_natural(ident):
    return [int(t) if t.isdigit() else t.lower() for t in re.split(r"(\d+)", ident)]


def texto_lummis(p):
    lineas = []
    if p["interprete"]:
        lineas.append("Intérprete: {0}".format(p["interprete"]))
    lineas.append("Año: {0}".format(p["anio"]) if p["anio"] else "Año: sin fecha en la fuente")
    lineas.append("Licencia: {0}.".format(_TXT_PDM))
    lineas.append("Colección Lummis, Autry National Center, vía Internet Archive.")
    return "\n".join(lineas)


# Paisajes sonoros: texto

def texto_paisaje(pista):
    ident, titulo, seg, lic, autor = pista
    lineas = []
    if autor:
        lineas.append("Autor: {0}".format(autor))
    lineas.append("Licencia: {0}.".format(_LICENCIAS[lic]))
    lineas.append("Duración: {0}.".format(_duracion_txt(seg)))
    lineas.append("Fuente: Radio Aporee, vía Internet Archive." if ident.startswith("aporee_")
                  else "Fuente: Internet Archive (Freesound).")
    lineas.append(_TXT_BUCLE)
    return "\n".join(lineas)


# Directorios

def _fallo_directorio(h, msg):
    _avisar(msg, xbmcgui.NOTIFICATION_ERROR)
    xbmcplugin.endOfDirectory(h, succeeded=False)


def _anadir_pista(h, ident, titulo, label, info, plot, thumb=True, icono=ICONO_LUMMIS):
    icono = icono_propio(icono)
    li = xbmcgui.ListItem(label=label)
    li.setArt({"icon": icono, "thumb": archive_org._THUMB_URL.format(id=ident) if thumb else icono})
    info = dict(info)
    info["title"] = titulo
    info["comment"] = plot
    li.setInfo("music", info)
    li.setProperty("IsPlayable", "true")
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="audio_curado_play", identifier=ident, titulo=titulo),
        listitem=li, isFolder=False,
    )


def lummis_lista():
    h = _handle()
    xbmcplugin.setPluginCategory(h, TITULO_LUMMIS)
    try:
        docs = archive_org._search(_LUMMIS_QUERY, 1, fields=_LUMMIS_CAMPOS,
                                   rows=_LUMMIS_FILAS, sort=_LUMMIS_ORDEN)
        pistas = pistas_lummis(docs)
    except Exception as e:  # noqa: BLE001
        _log("lummis_lista: {0!r}".format(e), xbmc.LOGERROR)
        pistas = []
    if not pistas:
        _fallo_directorio(h, "No se pudo cargar la lista de Internet Archive. Inténtalo más tarde.")
        return
    xbmcplugin.setContent(h, "songs")
    for p in pistas:
        label = p["titulo"]
        if p["interprete"]:
            label += "  [COLOR grey]{0}[/COLOR]".format(p["interprete"])
        if p["anio"]:
            label += " ({0})".format(p["anio"])
        info = {"artist": p["interprete"], "genre": "Canción popular", "album": TITULO_LUMMIS}
        if p["anio"]:
            info["year"] = int(p["anio"])
        _anadir_pista(h, p["id"], p["titulo"], label, info, texto_lummis(p))
    xbmcplugin.endOfDirectory(h)


def paisajes_lista():
    h = _handle()
    xbmcplugin.setPluginCategory(h, TITULO_PAISAJES)
    xbmcplugin.setContent(h, "songs")
    for pista in PAISAJES:
        ident, titulo, seg, lic, autor = pista
        info = {"artist": autor, "genre": "Paisaje sonoro", "album": TITULO_PAISAJES, "duration": seg}
        _anadir_pista(h, ident, titulo, titulo, info, texto_paisaje(pista), icono=ICONO_PAISAJES)
    xbmcplugin.endOfDirectory(h)


# Reproducción

def _identificador_valido(ident):
    return bool(ident) and (ident in _IDS_PAISAJES or bool(_RE_ID_LUMMIS.match(ident)))


def resolver_url(ident):
    """URL directa de audio del item, o '' si el identificador no es de estas listas o no hay audio."""
    if not _identificador_valido(ident):
        return ""
    try:
        return archive_org._best_audio_url(ident) or ""
    except Exception as e:  # noqa: BLE001
        _log("resolver_url {0}: {1!r}".format(ident, e), xbmc.LOGERROR)
        return ""


def reproducir(identifier, titulo=""):
    """setResolvedUrl(True) con la URL, o setResolvedUrl(False) + aviso. Nunca play_raw_url."""
    h = _handle()
    url = resolver_url(identifier)
    if not url:
        _log("sin audio para {0!r}".format(identifier), xbmc.LOGWARNING)
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        _avisar("No se pudo obtener el audio. Inténtalo más tarde.", xbmcgui.NOTIFICATION_ERROR)
        return
    ext = url.split("?")[0].rsplit(".", 1)[-1].lower()
    mime = {"ogg": "audio/ogg", "flac": "audio/flac", "opus": "audio/ogg"}.get(ext, "audio/mpeg")
    li = xbmcgui.ListItem(label=titulo or identifier, path=url)
    li.setInfo("music", {"title": titulo or identifier})
    li.setMimeType(mime)
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(h, True, li)
    _log("reproduciendo {0}".format(identifier))
