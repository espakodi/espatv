# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Reproductor de podcasts: feeds curados, carátulas, RSS, duración y progreso acotado."""
import hashlib
import json
import os
import sys
import time
import urllib.parse
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings

try:
    import requests
except ImportError:
    xbmc.log("[EspaTV/podcast] requests no disponible", xbmc.LOGERROR)
    raise


_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")


def _icon(name):
    ruta = os.path.join(_MEDIA, name)
    return ruta if os.path.isfile(ruta) else "DefaultMusicSongs.png"


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _err(msg):
    try:
        from default import _log_error
        _log_error(msg)
    except ImportError:
        xbmc.log("[EspaTV ERROR] {0}".format(msg), xbmc.LOGERROR)


_CUSTOM_PODCAST_FILE = "custom_podcasts.json"
_PROGRESS_FILE = "podcast_progress.json"
_MAX_PROGRESS_ENTRIES = 40
_MAX_PROGRESS_AGE_S = 7 * 24 * 3600
_MIN_DURATION_S = 180
_MIN_LISTEN_S = 20
_END_MARGIN_S = 90
_FINISHED_RATIO = 0.95

_BUILT_IN_LOGOS = {
    "https://fapi-top.prisasd.com/podcast/playser/el_larguero/itunestfp/podcast.xml": "https://sdmedia.playser.cadenaser.com/playser/image/20259/09/1757405610429_786.jpeg",
    "https://fapi-top.prisasd.com/podcast/playser/hora_25/itunestfp/podcast.xml": "https://cadenaser.com/estaticos/recursosgraficos/podcast/2026/1788162785804_445.jpeg",
    "https://www.cope.es/api/es/programas/herrera-en-cope/audios/rss.xml": "https://imagenes.cope.es/uploads/2026/08/25/original_6a8d95dcd4446.jpeg",
    "https://fapi-top.prisasd.com/podcast/playser/la_vida_moderna/itunestfp/podcast.xml": "https://editop.prisasd.com/bundles/remarkdesign/assets/images/prisa@2x.png",
    "http://feeds.feedburner.com/todopoderosos": "https://static-1.ivoox.com/canales/2/1/6/1/5661525711612_XXL.jpg",
    "https://thewildproject.libsyn.com/rss": "https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_nologo/46480499/009d03585d784f03.jpg",
    "http://www.spreaker.com/show/2630773/episodes/feed": "https://d3wo5wojvuv7l.cloudfront.net/t_rss_itunes_square_1400/images.spreaker.com/original/ee913b6fc49baeac38be4360311693a1.jpg",
    "https://fapi-top.prisasd.com/podcast/playser/nadie_sabe_nada/itunestfp/podcast.xml": "https://sdmedia.playser.cadenaser.com/playser/image/20244/29/1714384845741_290.jpeg",
    "https://feeds.megaphone.fm/ASCCT6415418901": "https://megaphone.imgix.net/podcasts/e04f258c-e4dd-11f0-b2a7-3be3253cc1fe/image/83539f881d92b3d461b85a3f1c737054.jpg?ixlib=rails-4.3.1&max-w=3000&max-h=3000&fit=crop&auto=format,compress",
    "https://www.cope.es/api/es/programas/el-partidazo-de-cope/audios/rss.xml": "https://imagenes.cope.es/uploads/2024/07/03/original_668565c4a89c2.jpeg",
    "https://www.cope.es/api/es/programas/tiempo-de-juego/audios/rss.xml": "https://imagenes.cope.es/uploads/2026/10/27/original_6ae09f41ade75.jpeg",
    "https://fapi-top.prisasd.com/podcast/playser/a_vivir_que_son_dos_dias/itunestfp/podcast.xml": "https://sdmedia.playser.cadenaser.com/playser/image/20243/21/1711033765914_627.jpeg",
    "https://fapi-top.prisasd.com/podcast/playser/la_ventana/itunestfp/podcast.xml": "https://sdmedia.playser.cadenaser.com/playser/image/20259/09/1757405464433_598.jpeg",
    "https://www.omnycontent.com/d/playlist/2446592a-b80e-4d28-a4fd-ae4c0140ac11/42658bb8-4afa-4449-9c7a-aea9010e5b53/5942eb19-73a6-4772-8093-aea9010e5b61/podcast.rss": "https://www.omnycontent.com/d/playlist/2446592a-b80e-4d28-a4fd-ae4c0140ac11/42658bb8-4afa-4449-9c7a-aea9010e5b53/5942eb19-73a6-4772-8093-aea9010e5b61/image.jpg?t=1729417339&size=Large",
    "https://anchor.fm/s/a4e7fe88/podcast/rss": "https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_nologo/27566674/48704452276992c7.jpeg",
    "https://feeds.ivoox.com/feed_fg_f113302_filtro_1.xml": "https://static-1.ivoox.com/canales/0/f/c/b/0fcbdef26bae437fee8a8c13f7b4537a_XXL.jpg",
    "https://anchor.fm/s/101d1e078/podcast/rss": "https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_nologo/43154990/ff0931e5f596572c.jpg",
    "https://feeds.ivoox.com/feed_fg_f1576365_filtro_1.xml": "https://static-2.ivoox.com/canales/9/c/5/2/9c5238363db5ab3a930a98d53dc600fb_XXL.jpg",
    "https://fapi-top.prisasd.com/podcast/playser/ser_historia/itunestfp/podcast.xml": "https://sdmedia.playser.cadenaser.com/playser/image/20245/09/1715250892125_295.jpeg",
    "https://www.omnycontent.com/d/playlist/2446592a-b80e-4d28-a4fd-ae4c0140ac11/9afe58f0-d402-4e05-a5ce-aead00a0ba96/fd25a142-cbf1-4f2b-9146-aead00a0bab7/podcast.rss": "https://www.omnycontent.com/d/playlist/2446592a-b80e-4d28-a4fd-ae4c0140ac11/9afe58f0-d402-4e05-a5ce-aead00a0ba96/fd25a142-cbf1-4f2b-9146-aead00a0bab7/image.jpg?t=1727868454&size=Large",
    "https://anchor.fm/s/10084e580/podcast/rss": "https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_nologo/42936768/42936768-1741864683895-2a60d36cc63dd.jpg",
    "https://feeds.simplecast.com/8YhIPHu1": "https://image.simplecastcdn.com/images/c5515215-bd80-46e3-9a3c-5b209482b558/fd321964-8c83-4f63-be86-248f1ef82969/3000x3000/cropped_1788213145175.jpg?aid=rss_feed",
    "https://anchor.fm/s/f04e75c8/podcast/rss": "https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_nologo/40216738/40216738-1790854450805-a963076728259.jpg",
    "https://www.omnycontent.com/d/playlist/2446592a-b80e-4d28-a4fd-ae4c0140ac11/172ad2c5-9214-4b21-85fe-aeaa01143b70/58c58f5a-82b3-4be2-aa54-aeaa01143b82/podcast.rss": "https://www.omnycontent.com/d/playlist/2446592a-b80e-4d28-a4fd-ae4c0140ac11/172ad2c5-9214-4b21-85fe-aeaa01143b70/58c58f5a-82b3-4be2-aa54-aeaa01143b82/image.jpg?t=1727877818&size=Large",
    "https://feeds.ivoox.com/feed_fg_f1268956_filtro_1.xml": "https://static-1.ivoox.com/canales/d/1/5/e/d15e14a24feeb70a28488072254566be_XXL.jpg",
    "https://anchor.fm/s/107d78054/podcast/rss": "https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_nologo/44165309/333f127acfb05d9e.jpg",
    "https://dinamics.3cat.cat/public/podcast/catradio/xml/9/5/podprograma1859.xml": "https://img.3cat.cat/multimedia/jpg/5/9/1779889617995.jpg",
    "https://anchor.fm/s/1007af750/podcast/rss": "https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_nologo/42930260/1e42da3b31e4927b.jpg",
    "https://anchor.fm/s/ff4c5068/podcast/rss": "https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_nologo/42731914/42731914-1791890558785-7155b443530d1.jpg",
    "https://feeds.megaphone.fm/HOT7749589265": "https://megaphone.imgix.net/podcasts/897e686c-677b-11ee-b441-dfc22be2e219/image/301298e949164e1b4b8bff9909e8a474.jpg?ixlib=rails-4.3.1&max-w=3000&max-h=3000&fit=crop&auto=format,compress",
    "https://anchor.fm/s/e0c735b8/podcast/rss": "https://d3t3ozftmdmh3i.cloudfront.net/staging/podcast_uploaded_nologo/37611518/37611518-1697550418139-4ad890965087f.jpg",
    "https://feeds.ivoox.com/feed_fg_f1267769_filtro_1.xml": "https://static-1.ivoox.com/canales/c/6/2/2/c6228684821da3f43a7179d3fa6339db_XXL.jpg",
    "https://www.omnycontent.com/d/playlist/2446592a-b80e-4d28-a4fd-ae4c0140ac11/d46d806d-6f59-403c-871f-b04400f4e432/52f42c98-c91e-469f-9579-b04400f56b06/podcast.rss": "https://www.omnycontent.com/d/playlist/2446592a-b80e-4d28-a4fd-ae4c0140ac11/d46d806d-6f59-403c-871f-b04400f4e432/52f42c98-c91e-469f-9579-b04400f56b06/image.jpg?t=1790861044&size=Large",
    "https://feeds.ivoox.com/feed_fg_f11436296_filtro_1.xml": "https://static-1.ivoox.com/canales/a/e/b/d/aebd6cfc034e4ed10a8bbc749c4a6213_XXL.jpg",
}


_PODCAST_FEEDS = [
    {"name": "El Larguero (Cadena SER)", "url": "https://fapi-top.prisasd.com/podcast/playser/el_larguero/itunestfp/podcast.xml", "icon": "podcast_programa.png", "desc": "Manu Carreño con lo mejor del deporte cada noche."},
    {"name": "Hora 25 (Cadena SER)", "url": "https://fapi-top.prisasd.com/podcast/playser/hora_25/itunestfp/podcast.xml", "icon": "podcast_programa.png", "desc": "Àngels Barceló con las noticias del día."},
    {"name": "Herrera en COPE", "url": "https://www.cope.es/api/es/programas/herrera-en-cope/audios/rss.xml", "icon": "podcast_programa.png", "desc": "Carlos Herrera en las mañanas de COPE."},
    {"name": "La Vida Moderna (SER)", "url": "https://fapi-top.prisasd.com/podcast/playser/la_vida_moderna/itunestfp/podcast.xml", "icon": "podcast_programa.png", "desc": "Humor y actualidad."},
    {"name": "Todopoderosos", "url": "http://feeds.feedburner.com/todopoderosos", "icon": "podcast_programa.png", "desc": "Podcast de humor con Berto Romero y más."},
    {"name": "Wild Project", "url": "https://thewildproject.libsyn.com/rss", "icon": "podcast_programa.png", "desc": "Jordi Wild entrevista a personalidades."},
    {"name": "Entiende tu mente", "url": "http://www.spreaker.com/show/2630773/episodes/feed", "icon": "podcast_programa.png", "desc": "Podcast de psicología y desarrollo personal."},
    {"name": "Nadie Sabe Nada (SER)", "url": "https://fapi-top.prisasd.com/podcast/playser/nadie_sabe_nada/itunestfp/podcast.xml", "icon": "podcast_programa.png", "desc": "Buenafuente y Berto Romero improvisando cada sábado."},
    {"name": "Criminopatía", "url": "https://feeds.megaphone.fm/ASCCT6415418901", "icon": "podcast_programa.png", "desc": "True crime en español. Casos reales narrados en detalle."},
    {"name": "El Partidazo de COPE", "url": "https://www.cope.es/api/es/programas/el-partidazo-de-cope/audios/rss.xml", "icon": "podcast_programa.png", "desc": "Juanma Castaño con la mejor actualidad deportiva nocturna."},
    {"name": "Tiempo de Juego (COPE)", "url": "https://www.cope.es/api/es/programas/tiempo-de-juego/audios/rss.xml", "icon": "podcast_programa.png", "desc": "Paco González y el mejor fútbol en directo."},
    {"name": "A Vivir (Cadena SER)", "url": "https://fapi-top.prisasd.com/podcast/playser/a_vivir_que_son_dos_dias/itunestfp/podcast.xml", "icon": "podcast_programa.png", "desc": "Javier del Pino cada fin de semana en la SER."},
    {"name": "La Ventana (Cadena SER)", "url": "https://fapi-top.prisasd.com/podcast/playser/la_ventana/itunestfp/podcast.xml", "icon": "podcast_programa.png", "desc": "Carles Francino cada tarde en Cadena SER."},
    {"name": "Estirando el Chicle", "url": "https://www.omnycontent.com/d/playlist/2446592a-b80e-4d28-a4fd-ae4c0140ac11/42658bb8-4afa-4449-9c7a-aea9010e5b53/5942eb19-73a6-4772-8093-aea9010e5b61/podcast.rss", "icon": "podcast_programa.png", "desc": "Carolina Iglesias y Victoria Martín rajan de todo."},
    {"name": "La Ruina", "url": "https://anchor.fm/s/a4e7fe88/podcast/rss", "icon": "podcast_programa.png", "desc": "Ignasi Taltavull y Tomàs Fuentes y las peores anécdotas."},
    {"name": "La Órbita de Endor (LODE)", "url": "https://feeds.ivoox.com/feed_fg_f113302_filtro_1.xml", "icon": "podcast_programa.png", "desc": "El podcast friki por excelencia. Cine, series y cómics."},
    {"name": "Lo Que Tú Digas con Álex Fidalgo", "url": "https://anchor.fm/s/101d1e078/podcast/rss", "icon": "podcast_programa.png", "desc": "Charlas sin guion, sin filtros y sin censuras."},
    {"name": "Aquí Hay Dragones", "url": "https://feeds.ivoox.com/feed_fg_f1576365_filtro_1.xml", "icon": "podcast_programa.png", "desc": "Historia y humor con Rodrigo Cortés, Cansado, Gómez-Jurado y Arturo."},
    {"name": "SER Historia", "url": "https://fapi-top.prisasd.com/podcast/playser/ser_historia/itunestfp/podcast.xml", "icon": "podcast_programa.png", "desc": "Nacho Ares nos acerca los grandes misterios de la historia."},
    {"name": "La Escóbula de la Brújula", "url": "https://www.omnycontent.com/d/playlist/2446592a-b80e-4d28-a4fd-ae4c0140ac11/9afe58f0-d402-4e05-a5ce-aead00a0ba96/fd25a142-cbf1-4f2b-9146-aead00a0bab7/podcast.rss", "icon": "podcast_programa.png", "desc": "Historia, misterio y leyendas con Jesús Callejo y equipo."},
    {"name": "Misterios y Cubatas", "url": "https://anchor.fm/s/10084e580/podcast/rss", "icon": "podcast_programa.png", "desc": "Podcast de misterio, conspiraciones y muchas risas."},
    {"name": "El Podcast de Marian Rojas Estapé", "url": "https://feeds.simplecast.com/8YhIPHu1", "icon": "podcast_programa.png", "desc": "Salud mental, psicología y bienestar emocional."},
    {"name": "Poco se habla!", "url": "https://anchor.fm/s/f04e75c8/podcast/rss", "icon": "podcast_programa.png", "desc": "Humor y salseo con Ana Brito y Xuso Jones."},
    {"name": "Saldremos mejores", "url": "https://www.omnycontent.com/d/playlist/2446592a-b80e-4d28-a4fd-ae4c0140ac11/172ad2c5-9214-4b21-85fe-aeaa01143b70/58c58f5a-82b3-4be2-aa54-aeaa01143b82/podcast.rss", "icon": "podcast_programa.png", "desc": "Actualidad y análisis social en tono de humor con Inés y Nerea."},
    {"name": "El Descampao", "url": "https://feeds.ivoox.com/feed_fg_f1268956_filtro_1.xml", "icon": "podcast_programa.png", "desc": "Documentales sonoros, cine, música e historia friki."},
    {"name": "Nude Project", "url": "https://anchor.fm/s/107d78054/podcast/rss", "icon": "podcast_programa.png", "desc": "Entrevistas a emprendedores, artistas e ídolos jóvenes."},
    {"name": "Crims (CCMA)", "url": "https://dinamics.3cat.cat/public/podcast/catradio/xml/9/5/podprograma1859.xml", "icon": "podcast_programa.png", "desc": "El mítico true-crime narrado por Carles Porta."},
    {"name": "Tengo un Plan", "url": "https://anchor.fm/s/1007af750/podcast/rss", "icon": "podcast_programa.png", "desc": "Sergio Beguería y Juan Domínguez: éxito y desarrollo personal."},
    {"name": "ROCA PROJECT", "url": "https://anchor.fm/s/ff4c5068/podcast/rss", "icon": "podcast_programa.png", "desc": "Carlos Roca con entrevistas inspiracionales sin filtro."},
    {"name": "WORLDCAST", "url": "https://feeds.megaphone.fm/HOT7749589265", "icon": "podcast_programa.png", "desc": "Pedro Buerbaum conversando con los invitados más virales."},
    {"name": "Black Mango Podcast", "url": "https://anchor.fm/s/e0c735b8/podcast/rss", "icon": "podcast_programa.png", "desc": "Historia, misterios oscuros y casos reales."},
    {"name": "La ContraCrónica", "url": "https://feeds.ivoox.com/feed_fg_f1267769_filtro_1.xml", "icon": "podcast_programa.png", "desc": "Fernando Díaz Villanueva analiza la política, la economía y el mundo."},
    {"name": "A solas con... Vicky Martín Berrocal", "url": "https://www.omnycontent.com/d/playlist/2446592a-b80e-4d28-a4fd-ae4c0140ac11/d46d806d-6f59-403c-871f-b04400f4e432/52f42c98-c91e-469f-9579-b04400f56b06/podcast.rss", "icon": "podcast_programa.png", "desc": "Charlas íntimas e inspiradoras con invitadas mediáticas."},
    {"name": "Crónicas de la Calle Morgue", "url": "https://feeds.ivoox.com/feed_fg_f11436296_filtro_1.xml", "icon": "podcast_programa.png", "desc": "Relatos de crímenes reales llenos de detalle y crudeza."}
]


def _load_custom_podcasts():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    fp = os.path.join(p, _CUSTOM_PODCAST_FILE)
    if not os.path.exists(fp):
        return []
    try:
        with open(fp, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def _save_custom_podcasts(pods):
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    fp = os.path.join(p, _CUSTOM_PODCAST_FILE)
    try:
        core_settings.atomic_write_json(fp, pods)
    except OSError:
        pass


def _podcast_add_custom():
    kb = xbmc.Keyboard('', 'URL del feed RSS del podcast')
    kb.doModal()
    if not kb.isConfirmed():
        return
    url = kb.getText().strip()
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in ('http', 'https') or not parsed.netloc:
        xbmcgui.Dialog().ok('EspaTV', 'Introduce una URL válida (http:// o https://).')
        return
    pods = _load_custom_podcasts()
    existing = [pod['url'] for pod in _PODCAST_FEEDS] + [pod.get('url', '') for pod in pods]
    if url in existing:
        xbmcgui.Dialog().notification('EspaTV', 'Ese podcast ya existe', xbmcgui.NOTIFICATION_WARNING)
        return
    kb2 = xbmc.Keyboard('', 'Nombre para este podcast')
    kb2.doModal()
    name = (kb2.getText().strip() if kb2.isConfirmed() else '').replace('[', '').replace(']', '')
    if not name:
        name = parsed.netloc
    pods.append({'name': name, 'url': url, 'desc': ''})
    _save_custom_podcasts(pods)
    xbmcgui.Dialog().notification('EspaTV', f"Podcast '{name}' añadido", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin('Container.Refresh')


def _profile_dir():
    return xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))


def _progress_key(audio_url):
    return hashlib.md5(audio_url.encode('utf-8')).hexdigest()


def _feed_key(feed_url):
    return hashlib.md5(feed_url.encode('utf-8')).hexdigest()[:8] if feed_url else ""


def _format_time(seconds):
    total = max(0, int(seconds))
    h, rem = divmod(total, 3600)
    m, s = divmod(rem, 60)
    if h:
        return "{0}:{1:02d}:{2:02d}".format(h, m, s)
    return "{0:02d}:{1:02d}".format(m, s)


def _recortar_progreso(entries, max_entries=_MAX_PROGRESS_ENTRIES, now=None, max_age=_MAX_PROGRESS_AGE_S):
    ahora = time.time() if now is None else now
    limite = ahora - max_age
    validas = []
    for e in entries or []:
        if not isinstance(e, dict) or not e.get("h"):
            continue
        try:
            t = float(e.get("t", 0))
            p = int(e.get("p", 0))
        except (TypeError, ValueError):
            continue
        if t >= limite and p >= _MIN_LISTEN_S:
            validas.append({"h": str(e["h"]), "p": p, "t": int(t), "fh": str(e.get("fh") or "")})
    validas.sort(key=lambda x: x["t"], reverse=True)
    return validas[:max_entries]


def _load_progress(now=None):
    fp = os.path.join(_profile_dir(), _PROGRESS_FILE)
    if not os.path.exists(fp):
        return []
    try:
        with open(fp, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if not isinstance(data, list):
            return []
        return _recortar_progreso(data, _MAX_PROGRESS_ENTRIES, now=now)
    except (OSError, ValueError):
        return []


def _save_progress_list(entries):
    p = _profile_dir()
    if not os.path.exists(p):
        os.makedirs(p)
    fp = os.path.join(p, _PROGRESS_FILE)
    try:
        core_settings.atomic_write_json(fp, entries)
    except OSError:
        pass


def get_progress(audio_url, now=None):
    if not audio_url:
        return None
    h = _progress_key(audio_url)
    for e in _load_progress(now=now):
        if e["h"] == h:
            return e["p"]
    return None


def clear_progress(audio_url, now=None):
    if not audio_url:
        return
    h = _progress_key(audio_url)
    actual = _load_progress(now=now)
    if not any(e["h"] == h for e in actual):
        return
    _save_progress_list([e for e in actual if e["h"] != h])


def clear_feed_progress(feed_url, now=None):
    fh = _feed_key(feed_url)
    if not fh:
        return
    actual = _load_progress(now=now)
    if not any(e.get("fh") == fh for e in actual):
        return
    _save_progress_list([e for e in actual if e.get("fh") != fh])


def save_progress(audio_url, feed_key, pos_s, dur_s=0, now=None):
    if not audio_url:
        return
    try:
        pos = int(pos_s)
        dur = int(dur_s or 0)
    except (TypeError, ValueError):
        return
    if pos < _MIN_LISTEN_S:
        clear_progress(audio_url, now=now)
        return
    if dur > 0 and dur < _MIN_DURATION_S:
        clear_progress(audio_url, now=now)
        return
    if dur > 0 and (pos >= int(dur * _FINISHED_RATIO) or (dur - pos) <= _END_MARGIN_S):
        clear_progress(audio_url, now=now)
        return
    ahora = int(time.time() if now is None else now)
    h = _progress_key(audio_url)
    actual = [e for e in _load_progress(now=ahora) if e["h"] != h]
    actual.append({"h": h, "p": pos, "t": ahora, "fh": str(feed_key or "")})
    _save_progress_list(_recortar_progreso(actual, _MAX_PROGRESS_ENTRIES, now=ahora))


def _podcast_forget(url):
    clear_progress(url)
    xbmcgui.Dialog().notification('EspaTV', 'Punto de reanudación olvidado', xbmcgui.NOTIFICATION_INFO, 2500)
    xbmc.executebuiltin('Container.Refresh')


def _parse_duration_s(raw):
    """Convierte '1:02:03', '02:03' o '123' a segundos enteros (0 si no es válido)."""
    texto = (raw or "").strip().split(".", 1)[0].strip()
    if not texto:
        return 0
    partes = []
    for p in texto.split(":"):
        p = p.strip()
        if not p.isdigit():
            return 0
        partes.append(int(p))
    if len(partes) == 1:
        return max(0, partes[0])
    if len(partes) == 2:
        return max(0, partes[0] * 60 + partes[1])
    if len(partes) == 3:
        return max(0, partes[0] * 3600 + partes[1] * 60 + partes[2])
    return 0


def _extract_channel_image(channel):
    """Extrae la carátula del nodo <channel> (<itunes:image href> o <image><url>)."""
    if channel is None:
        return ""
    for el in channel:
        tag = el.tag.lower().rsplit("}", 1)[-1]
        if tag == "image":
            href = (el.get("href") or "").strip()
            if href.startswith(("http://", "https://")):
                return href
            url_el = el.find("url")
            if url_el is not None and url_el.text:
                u = url_el.text.strip()
                if u.startswith(("http://", "https://")):
                    return u
    return ""


def _update_custom_icon(feed_url, image_url):
    if not image_url or not feed_url:
        return
    pods = _load_custom_podcasts()
    changed = False
    for pod in pods:
        if pod.get("url") == feed_url and pod.get("icon") != image_url:
            pod["icon"] = image_url
            changed = True
    if changed:
        _save_custom_podcasts(pods)


def _podcast_delete_custom(url):
    pods = _load_custom_podcasts()
    name = next((pod.get('name', 'Podcast') for pod in pods if pod.get('url') == url), 'Podcast')
    if xbmcgui.Dialog().yesno('EspaTV', f"¿Eliminar el podcast '{name}'?"):
        pods = [pod for pod in pods if pod.get('url') != url]
        _save_custom_podcasts(pods)
        clear_feed_progress(url)
        xbmcgui.Dialog().notification('EspaTV', 'Podcast eliminado', xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin('Container.Refresh')


def _podcast_menu():
    h = int(sys.argv[1])
    base_icon = _icon("podcast_programa.png")
    for pod in _PODCAST_FEEDS:
        icon_path = _icon(pod.get("icon", "podcast_programa.png"))
        cover = _BUILT_IN_LOGOS.get(pod["url"]) or icon_path
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(pod["name"]))
        li.setArt({'icon': icon_path, 'thumb': cover, 'poster': cover})
        li.setInfo('video', {'plot': pod.get("desc", "")})
        fav_params = json.dumps({"url": pod["url"], "title": pod["name"]})
        li.addContextMenuItems([("Añadir a Mis Favoritos", "RunPlugin({0})".format(_u(action='add_favorite', title=pod["name"], fav_url='podcast_{0}'.format(pod["name"]), icon=pod.get("icon", "DefaultMusicSongs.png"), platform='podcast', fav_action='podcast_feed', params=fav_params)))])
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="podcast_feed", url=pod["url"], title=pod["name"]), listitem=li, isFolder=True)

    for pod in _load_custom_podcasts():
        name = pod.get("name", "Podcast")
        url = pod.get("url", "")
        cover = pod.get("icon") or base_icon
        li = xbmcgui.ListItem(label=f"[COLOR aqua][B]{name}[/B][/COLOR]")
        li.setArt({'icon': base_icon, 'thumb': cover, 'poster': cover})
        li.setInfo('video', {'plot': f"Tu podcast\nURL: {url}"})
        li.addContextMenuItems([("Eliminar este podcast", f"RunPlugin({_u(action='podcast_delete_custom', url=url)})")])
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="podcast_feed", url=url, title=name), listitem=li, isFolder=True)

    li_add = xbmcgui.ListItem(label="[B]Añadir podcast RSS...[/B]")
    li_add.setArt({'icon': 'DefaultAddSource.png'})
    li_add.setInfo('video', {'plot': "Añade tu propio feed RSS de podcast al menú."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="podcast_add_custom"), listitem=li_add, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.is_iptv_cache_active())


def _podcast_feed(feed_url, feed_title=""):
    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("Podcast", "Cargando episodios...")
    try:
        dp.update(30, "Descargando feed...")
        content = None
        c_file = ""
        ttl = core_settings.get_iptv_cache_ttl()
        if core_settings.is_iptv_cache_active() and ttl > 0:
            c_dir = core_settings.get_iptv_cache_dir()
            c_key = hashlib.md5(feed_url.encode('utf-8')).hexdigest()
            c_file = os.path.join(c_dir, 'pod_' + c_key + '.xml')
            if os.path.exists(c_file):
                try:
                    with open(c_file, 'r', encoding='utf-8') as f:
                        meta = json.load(f)
                    if (time.time() - meta.get('ts', 0)) < ttl:
                        content = meta.get('data', '').encode('utf-8')
                except (OSError, ValueError):
                    pass

        if not content:
            r = requests.get(feed_url, timeout=15, headers={"User-Agent": "Kodi EspaTV"})
            if r.status_code != 200:
                dp.close()
                xbmcgui.Dialog().ok("Podcast", "Error al descargar el feed: HTTP {0}".format(r.status_code))
                xbmcplugin.endOfDirectory(h, cacheToDisc=False); return
            content = r.content
            if core_settings.is_iptv_cache_active() and c_file:
                try:
                    core_settings.atomic_write_json(c_file, {'ts': time.time(), 'data': content.decode('utf-8', 'ignore')})
                except OSError:
                    pass

        dp.update(70, "Procesando episodios...")
        root = ET.fromstring(content)
        channel = root.find("channel")
        if channel is None:
            dp.close()
            xbmcgui.Dialog().ok("Podcast", "Feed no válido.")
            xbmcplugin.endOfDirectory(h, cacheToDisc=False); return
        channel_img = _extract_channel_image(channel) or _BUILT_IN_LOGOS.get(feed_url, "")
        if channel_img:
            _update_custom_icon(feed_url, channel_img)
        items = channel.findall("item")
        dp.close()
        if not items:
            xbmcgui.Dialog().ok("Podcast", "No se encontraron episodios.")
            xbmcplugin.endOfDirectory(h, cacheToDisc=False); return
        xbmcplugin.setContent(h, 'songs')
        fh = _feed_key(feed_url)
        prog_map = {e["h"]: e["p"] for e in _load_progress()}
        for item in items[:50]:
            title_el = item.find("title")
            title = title_el.text.strip() if title_el is not None and title_el.text else "Episodio"
            desc_el = item.find("description")
            desc = desc_el.text.strip() if desc_el is not None and desc_el.text else ""
            pub_el = item.find("pubDate")
            pub_date = pub_el.text.strip() if pub_el is not None and pub_el.text else ""
            enclosure = item.find("enclosure")
            audio_url = enclosure.get("url", "") if enclosure is not None else ""
            if not audio_url:
                link_el = item.find("link")
                audio_url = link_el.text.strip() if link_el is not None and link_el.text else ""
            if not audio_url:
                continue
            thumb = ""
            dur_s = 0
            for el in item:
                tag_l = el.tag.lower().rsplit("}", 1)[-1]
                if not thumb and "image" in tag_l and el.get("href"):
                    thumb = el.get("href", "").strip()
                if not dur_s and tag_l == "duration" and el.text:
                    dur_s = _parse_duration_s(el.text)
            cover = thumb or channel_img or 'DefaultMusicSongs.png'
            saved_pos = prog_map.get(_progress_key(audio_url))
            label = title
            if pub_date:
                try:
                    short_date = pub_date.split(",")[1].strip()[:12] if "," in pub_date else pub_date[:16]
                    label = "[COLOR gray]{0}[/COLOR] {1}".format(short_date, title)
                except (IndexError, AttributeError):
                    pass
            if saved_pos:
                label = "{0} [COLOR yellow]· lo dejaste en {1}[/COLOR]".format(label, _format_time(saved_pos))
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': cover, 'thumb': cover, 'poster': cover})
            plot = ""
            if feed_title:
                plot += "Podcast: {0}\n".format(feed_title)
            if pub_date:
                plot += "Fecha: {0}\n".format(pub_date)
            if saved_pos:
                plot += "Lo dejaste en {0}\n".format(_format_time(saved_pos))
            if desc:
                plot += "\n{0}".format(desc[:500])
            info_dict = {'title': title, 'plot': plot}
            if dur_s > 0:
                info_dict['duration'] = dur_s
            li.setInfo('video', info_dict)
            if saved_pos:
                li.addContextMenuItems([(
                    "Olvidar punto de reanudación",
                    "RunPlugin({0})".format(_u(action="podcast_forget", url=audio_url)),
                )])
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="play_podcast", url=audio_url, title=title, fh=fh, dur=str(dur_s)),
                listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
    except (requests.RequestException, ValueError, ImportError, ET.ParseError) as e:
        try:
            dp.close()
        except RuntimeError:
            pass
        _err("Podcast feed error: {0}".format(e))
        xbmcgui.Dialog().ok("Podcast", "Error al cargar el feed:\n{0}".format(e))
        try:
            xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        except RuntimeError:
            pass


def _argv_params():
    if len(sys.argv) < 3 or not sys.argv[2]:
        return {}
    return dict(urllib.parse.parse_qsl(sys.argv[2].lstrip("?")))


_TRACK_PROP = "espatv_podcast_track"


def _commit_progress(url, fh, last_pos, last_dur):
    """Guarda o limpia el progreso final de un episodio tras detenerse o terminar."""
    if last_dur > 0 and last_pos >= int(last_dur * _FINISHED_RATIO):
        clear_progress(url)
    elif last_pos >= _MIN_LISTEN_S:
        save_progress(url, fh, last_pos, last_dur)


def start_tracking(url, fh, dur_s=0):
    """Registra en Window(10000) el episodio activo para que service.py lo siga sin bloquear."""
    win = xbmcgui.Window(10000)
    prev_raw = win.getProperty(_TRACK_PROP)
    if isinstance(prev_raw, str) and prev_raw:
        try:
            prev = json.loads(prev_raw)
        except Exception:
            prev = None
        if isinstance(prev, dict) and prev.get("started") and prev.get("url") and prev.get("url") != url:
            _commit_progress(
                prev["url"],
                prev.get("fh", ""),
                int(prev.get("last_pos", 0)),
                int(prev.get("dur", 0)),
            )
    state = {
        "url": url,
        "fh": fh or "",
        "dur": int(dur_s or 0),
        "started": False,
        "kodi_file": "",
        "last_pos": 0,
        "last_save": 0.0,
        "deadline": time.monotonic() + 30.0,
    }
    win.setProperty(_TRACK_PROP, json.dumps(state, ensure_ascii=False))


def service_tick():
    """Tick no bloqueante llamado cada 1 s por service.py mientras hay un podcast activo."""
    win = xbmcgui.Window(10000)
    raw = win.getProperty(_TRACK_PROP)
    if not isinstance(raw, str) or not raw:
        return
    try:
        st = json.loads(raw)
    except Exception:
        win.clearProperty(_TRACK_PROP)
        return
    url = st.get("url", "")
    if not isinstance(st, dict) or not url:
        win.clearProperty(_TRACK_PROP)
        return

    try:
        player = xbmc.Player()
        playing = player.isPlaying()
    except Exception:
        win.clearProperty(_TRACK_PROP)
        return
    if not isinstance(playing, bool):
        win.clearProperty(_TRACK_PROP)
        return

    ahora = time.monotonic()
    if not st.get("started"):
        if not playing:
            if ahora >= float(st.get("deadline", 0)):
                win.clearProperty(_TRACK_PROP)
            return
        st["started"] = True

    if playing:
        try:
            cur_file = player.getPlayingFile()
        except Exception:
            cur_file = ""
        if cur_file:
            if not st.get("kodi_file"):
                st["kodi_file"] = cur_file
            elif cur_file != st["kodi_file"]:
                _commit_progress(url, st.get("fh", ""), int(st.get("last_pos", 0)), int(st.get("dur", 0)))
                win.clearProperty(_TRACK_PROP)
                return
        try:
            pos = player.getTime()
            tot = player.getTotalTime()
        except Exception:
            win.clearProperty(_TRACK_PROP)
            return
        if not isinstance(pos, (int, float)):
            win.clearProperty(_TRACK_PROP)
            return
        if pos > 0:
            st["last_pos"] = int(pos)
        if isinstance(tot, (int, float)) and tot > 0:
            st["dur"] = int(tot)
        if st["last_pos"] >= _MIN_LISTEN_S and (ahora - float(st.get("last_save", 0))) >= 15.0:
            save_progress(url, st.get("fh", ""), st["last_pos"], int(st.get("dur", 0)))
            st["last_save"] = ahora
        win.setProperty(_TRACK_PROP, json.dumps(st, ensure_ascii=False))
        return

    _commit_progress(url, st.get("fh", ""), int(st.get("last_pos", 0)), int(st.get("dur", 0)))
    win.clearProperty(_TRACK_PROP)


def _monitor_playback(url, fh, dur_s=0):
    """Sigue la reproducción de un episodio en Kodi para guardar progreso cada ~15 s."""
    try:
        player = xbmc.Player()
        monitor = xbmc.Monitor()
    except Exception:
        return
    if not isinstance(player.isPlaying(), bool):
        return

    deadline = time.monotonic() + 15.0
    while not player.isPlaying():
        if monitor.abortRequested() or time.monotonic() >= deadline:
            return
        if monitor.waitForAbort(0.5):
            return

    last_pos = 0
    last_dur = int(dur_s or 0)
    last_save = time.monotonic()
    while player.isPlaying() and not monitor.abortRequested():
        try:
            cur_file = player.getPlayingFile()
        except Exception:
            cur_file = ""
        if cur_file and cur_file != url:
            break
        try:
            pos = player.getTime()
            tot = player.getTotalTime()
        except Exception:
            break
        if not isinstance(pos, (int, float)):
            break
        if pos > 0:
            last_pos = int(pos)
        if isinstance(tot, (int, float)) and tot > 0:
            last_dur = int(tot)
        ahora = time.monotonic()
        if last_pos >= _MIN_LISTEN_S and (ahora - last_save) >= 15.0:
            save_progress(url, fh, last_pos, last_dur)
            last_save = ahora
        if monitor.waitForAbort(1.0):
            break

    _commit_progress(url, fh, last_pos, last_dur)


def _play_podcast(url, title="", fh="", dur=0):
    h = int(sys.argv[1])
    if not fh or not dur:
        extra = _argv_params()
        if not fh:
            fh = extra.get("fh", "")
        if not dur:
            try:
                dur = int(extra.get("dur", 0) or 0)
            except ValueError:
                dur = 0
    saved_pos = get_progress(url)
    start_offset = 0
    if saved_pos:
        opcion = xbmcgui.Dialog().contextmenu([
            "Reanudar desde {0}".format(_format_time(saved_pos)),
            "Empezar desde el principio",
        ])
        if opcion == -1:
            if h >= 0:
                xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
            return
        if opcion == 0:
            start_offset = int(saved_pos)
        elif opcion == 1:
            clear_progress(url)
    try:
        ext = url.split('?')[0].rsplit('.', 1)[-1].lower()
        mime = {'ogg': 'audio/ogg', 'flac': 'audio/flac', 'opus': 'audio/ogg', 'm4a': 'audio/mp4'}.get(ext, 'audio/mpeg')
        li = xbmcgui.ListItem(label=title, path=url)
        if start_offset > 0:
            li.setProperty("StartOffset", str(start_offset))
        li.setMimeType(mime)
        li.setContentLookup(False)
        xbmc.log("[EspaTV/podcast] _play_podcast h={0} offset={1} mime={2} url={3}".format(
            h, start_offset, mime, url.split("?", 1)[0]), xbmc.LOGINFO)
        if h < 0:
            xbmc.Player().play(url, li)
        else:
            xbmcplugin.setResolvedUrl(h, True, li)
    except RuntimeError as e:
        _err("Podcast play error: {0}".format(e))
        if h >= 0:
            xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return
    start_tracking(url, fh, dur)
