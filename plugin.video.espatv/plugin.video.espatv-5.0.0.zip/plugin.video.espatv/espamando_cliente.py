# -*- coding: utf-8 -*-
# EspaMando - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""«Control remoto completo»: lo que el addon anfitrión hace con el mini-addon compartido
service.espamando.

El mando (servidor, vinculación, página del móvil) vive en service.espamando, que EspaTV, EspaDaily
y AtresDaily llevan como plantilla en resources/espamando y lo instalan la primera vez que el
usuario usa el modo, como el puente de YouTube. Así, con varios de estos addons instalados, hay un
solo servidor, un puerto y una vinculación. Quien no usa el modo no tiene nada instalado.

Este fichero es igual en los tres addons. No importa código del módulo: le habla por HTTP en
127.0.0.1 con la clave que el servidor publica en una propiedad de Kodi.
"""
import errno
import http.client
import json
import os
import re
import shutil
import time

import xbmc
import xbmcgui
import xbmcvfs

MODULO = 'service.espamando'
_TITULO = 'Control remoto completo'
_P_PUERTO = 'espamando.puerto'
_P_ADMIN = 'espamando.admin'
_P_LATIDO = 'espamando.latido'
_P_DUENO = 'espamando.dueno'
_CERROJO_CADUCA = 120
_PLANTILLA = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'espamando')

_MSG_ESPACIO = ("No hay espacio libre suficiente para instalar el control remoto. Libera espacio "
                "(por ejemplo, borrando la caché de Kodi) e inténtalo de nuevo.")
_MSG_PERMISOS = ("Tu dispositivo no deja crear el complemento del control remoto en la carpeta de "
                 "Kodi. Puedes seguir escribiendo desde el móvil o con el teclado.")


def _log(msg, nivel=xbmc.LOGINFO):
    xbmc.log('[EspaMando/cliente] {0}'.format(msg), nivel)


def _cond(cond):
    return xbmc.getCondVisibility('{0}({1})'.format(cond, MODULO))


def _rpc(metodo, params):
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(
            {'jsonrpc': '2.0', 'id': 1, 'method': metodo, 'params': params})))
    except (ValueError, TypeError, RuntimeError):
        return {}


def _esperar(comprobar, segundos=4.0):
    fin = time.time() + segundos
    monitor = xbmc.Monitor()
    while time.time() < fin:
        if comprobar():
            return True
        if monitor.waitForAbort(0.1):
            return False
    return comprobar()


def _rutas():
    addons = xbmcvfs.translatePath('special://home/addons')
    return {
        'addons': addons,
        'destino': os.path.join(addons, MODULO),
        # Sin addon.xml en su raíz: Kodi no carga lo que haya dentro
        'trabajo': os.path.join(addons, MODULO + '.trabajo'),
        'cerrojo': os.path.join(addons, '.' + MODULO + '.lock'),
        'perfil': xbmcvfs.translatePath('special://profile/addon_data/{0}/'.format(MODULO)),
    }


def _version(addon_xml):
    try:
        with open(addon_xml, 'r', encoding='utf-8') as f:
            cabecera = f.read(2048)
    except OSError:
        return ()
    m = re.search(r'<addon\b[^>]*\bversion="([0-9.]+)"', cabecera)
    return tuple(int(x) for x in m.group(1).split('.') if x.isdigit()) if m else ()


def instalado():
    return os.path.isfile(os.path.join(_rutas()['destino'], 'addon.xml'))


def _hace_falta_instalar():
    rutas = _rutas()
    mia = _version(os.path.join(_PLANTILLA, 'addon.xml'))
    puesta = _version(os.path.join(rutas['destino'], 'addon.xml'))
    # Solo se sube de versión: si otro addon instaló una más nueva, se respeta
    return bool(mia) and mia > puesta


# --- cerrojo entre addons (EspaTV y EspaDaily pueden instalar a la vez) ---

def _coger_cerrojo(ruta):
    for _ in range(50):
        try:
            fd = os.open(ruta, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
            os.write(fd, str(time.time()).encode('ascii'))
            os.close(fd)
            return True
        except FileExistsError:
            try:
                if time.time() - os.path.getmtime(ruta) > _CERROJO_CADUCA:
                    os.remove(ruta)
                    continue
            except OSError:
                pass
            xbmc.sleep(100)
        except OSError:
            return False
    return False


def _soltar_cerrojo(ruta):
    try:
        os.remove(ruta)
    except OSError:
        pass


def _borrar_trabajo(trabajo, addons):
    # Solo se borra la carpeta de trabajo propia, comprobada dentro de addons
    if os.path.basename(trabajo) == MODULO + '.trabajo' and os.path.dirname(trabajo) == addons:
        shutil.rmtree(trabajo, ignore_errors=True)


def _activar(si):
    _rpc('Addons.SetAddonEnabled', {'addonid': MODULO, 'enabled': bool(si)})
    return _esperar(lambda: bool(_cond('System.AddonIsEnabled')) == bool(si), 3)


# --- servidor ---

def _admin(metodo, ruta, datos=None, timeout=4):
    ventana = xbmcgui.Window(10000)
    puerto, clave = ventana.getProperty(_P_PUERTO), ventana.getProperty(_P_ADMIN)
    if not puerto.isdigit() or not clave:
        return None
    conexion = http.client.HTTPConnection('127.0.0.1', int(puerto), timeout=timeout)
    try:
        cuerpo = json.dumps(datos or {}) if metodo == 'POST' else None
        cabeceras = {'X-Admin': clave}
        if cuerpo is not None:
            cabeceras['Content-Type'] = 'application/json'
        conexion.request(metodo, ruta, body=cuerpo, headers=cabeceras)
        respuesta = conexion.getresponse()
        if respuesta.status != 200:
            return None
        datos = json.loads(respuesta.read().decode('utf-8') or '{}')
        return datos if isinstance(datos, dict) else None
    except (OSError, ValueError, http.client.HTTPException):
        return None
    finally:
        conexion.close()


def _vivo():
    return _admin('GET', '/admin/ping', timeout=2)


def _parar():
    if _admin('POST', '/admin/parar') is not None:
        _esperar(lambda: not xbmcgui.Window(10000).getProperty(_P_LATIDO), 3)


def _arrancar():
    """Lanza el servidor si no está vivo. Devuelve lo que contesta /admin/ping, o None."""
    estado = _vivo()
    if estado is not None:
        return estado
    # Un latido sin servidor que conteste es de un proceso que murió de golpe: se limpia para que
    # el nuevo no crea que ya hay otro
    ventana = xbmcgui.Window(10000)
    for prop in (_P_PUERTO, _P_ADMIN, _P_LATIDO, _P_DUENO):
        ventana.clearProperty(prop)
    script = os.path.join(_rutas()['destino'], 'servidor.py')
    # Entre comillas: una ruta con comas partiría los parámetros del builtin
    xbmc.executebuiltin('RunScript("{0}")'.format(script))
    estado = [None]

    def listo():
        estado[0] = _vivo()
        return estado[0] is not None
    _esperar(listo, 6)
    return estado[0]


# --- instalar, actualizar, quitar ---

def _instalar(activar_al_final):
    """Copia la plantilla a addons/ (con vuelta atrás si algo falla). (ok, mensaje_error)."""
    rutas = _rutas()
    if not os.path.isfile(os.path.join(_PLANTILLA, 'addon.xml')):
        return False, 'No se encuentra la plantilla del control remoto.'
    if not _coger_cerrojo(rutas['cerrojo']):
        return False, 'Hay otra instalación en curso. Inténtalo en unos segundos.'
    try:
        if not _hace_falta_instalar():
            return True, ''
        # Se para el servidor y se cambian los ficheros sin desactivar el módulo: desactivar un
        # servicio en marcha hace que Kodi lo mate a los 5 s y no lo vuelve a arrancar
        _parar()
        _borrar_trabajo(rutas['trabajo'], rutas['addons'])
        preparado = os.path.join(rutas['trabajo'], 'nuevo', MODULO)
        shutil.copytree(_PLANTILLA, preparado, ignore=shutil.ignore_patterns('__pycache__', '*.pyc'))
        viejo = os.path.join(rutas['trabajo'], 'viejo')
        movido = False
        try:
            if os.path.isdir(rutas['destino']):
                shutil.move(rutas['destino'], viejo)
                movido = True
            shutil.move(preparado, rutas['destino'])
        except OSError:
            if movido and not os.path.isdir(rutas['destino']):
                shutil.move(viejo, rutas['destino'])
            raise
        _borrar_trabajo(rutas['trabajo'], rutas['addons'])
        xbmc.executebuiltin('UpdateLocalAddons()')
        _esperar(lambda: _cond('System.HasAddon'))
        if activar_al_final and not _cond('System.AddonIsEnabled') and not _activar(True):
            return False, 'Kodi no ha activado el control remoto. Actívalo en Mis addons > Servicios.'
        return True, ''
    except OSError as e:
        _borrar_trabajo(rutas['trabajo'], rutas['addons'])
        _log('No se pudo instalar {0}: {1}'.format(MODULO, e), xbmc.LOGERROR)
        if getattr(e, 'errno', None) == errno.ENOSPC:
            return False, _MSG_ESPACIO
        if isinstance(e, PermissionError) or getattr(e, 'errno', None) in (errno.EACCES, errno.EPERM):
            return False, _MSG_PERMISOS
        return False, 'No se pudo instalar el control remoto: {0}'.format(e)
    finally:
        _soltar_cerrojo(rutas['cerrojo'])


def _asegurar():
    """Deja el módulo instalado, activo y con el servidor en marcha. Lo que contesta el servidor
    (moviles, url...) o None, tras avisar al usuario."""
    ok, msg = _instalar(activar_al_final=True)
    if ok and not _cond('System.AddonIsEnabled') and not _activar(True):
        ok, msg = False, 'Kodi no ha activado el control remoto. Actívalo en Mis addons > Servicios.'
    if not ok:
        xbmcgui.Dialog().ok(_TITULO, msg)
        return None
    estado = _arrancar()
    if estado is None:
        xbmcgui.Dialog().notification(_TITULO, 'No se pudo arrancar el control remoto',
                                      xbmcgui.NOTIFICATION_WARNING, 4000)
    return estado


# --- ventana de vinculación ---

class _Ventana(xbmcgui.WindowDialog):
    _CERRAR = (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK, xbmcgui.ACTION_STOP)

    def __init__(self, datos):
        super().__init__()
        self.cerrada = False
        blanco, gris, azul, amarillo = '0xFFFFFFFF', '0xFFB0B8C0', '0xFF58A6FF', '0xFFFFD700'
        # Una ControlImage sin textura no se pinta en todas las skins: se tiñe una blanca de 4x4
        fondo = os.path.join(_rutas()['destino'], 'fondo.png')
        self.addControl(xbmcgui.ControlImage(0, 0, 1280, 720, fondo, colorDiffuse='0xF20D1117'))
        x = 60

        def texto(y, cadena, color=blanco, fuente='font14', alto=34):
            self.addControl(xbmcgui.ControlLabel(x, y, 680, alto, cadena, font=fuente,
                                                 textColor=color))
        texto(40, 'Vincular un móvil', fuente='font20', alto=40)
        texto(100, 'Maneja Kodi y escribe desde el navegador del móvil.', gris)
        texto(165, '1   Escanea el QR con la cámara del móvil,')
        texto(200, '     o entra en  [B]{0}[/B]'.format(datos.get('url', '')), azul)
        otras = datos.get('otras') or []
        y = 235
        if otras:
            texto(y, '     Si no carga, prueba  {0}'.format('  o  '.join(otras)), gris)
            y += 35
        texto(y + 30, '2   O escribe este PIN en esa página:')
        texto(y + 68, '     [B]{0}[/B]'.format('  '.join(datos.get('pin', ''))), amarillo, 'font20', 44)
        texto(y + 140, '3   Esta pantalla se cierra sola al vincular.')
        texto(y + 175, '     Pulsa Atrás para cancelar.', gris)
        texto(640, 'Solo una vez por móvil. El móvil tiene que estar en la misma wifi.', gris)
        qr = datos.get('qr') or ''
        if qr and os.path.isfile(qr):
            self.addControl(xbmcgui.ControlImage(780, 150, 420, 420, qr))
        else:
            self.addControl(xbmcgui.ControlLabel(780, 340, 420, 40, 'QR no disponible: usa la dirección',
                                                 font='font14', textColor=gris, alignment=0x00000002))

    def onAction(self, accion):
        if accion.getId() in self._CERRAR:
            self.cerrada = True
            self.close()


def _vincular():
    """Enseña la ventana hasta que se vincula un móvil, se cancela o caduca. True si se vinculó."""
    datos = _admin('POST', '/admin/vincular')
    if not datos or datos.get('error') == 'sin_red':
        xbmcgui.Dialog().ok(_TITULO, 'La tele no está conectada a una red local. '
                                     'Conéctala a la wifi o por cable e inténtalo de nuevo.')
        return False
    antes = int(datos.get('moviles') or 0)
    ventana = _Ventana(datos)
    vinculado = False
    monitor = xbmc.Monitor()
    try:
        ventana.show()
        while not ventana.cerrada and not monitor.waitForAbort(0.4):
            ahora = _admin('GET', '/admin/estado', timeout=2)
            if ahora is None:
                break
            if int(ahora.get('moviles') or 0) > antes:
                vinculado = True
                break
            if not ahora.get('vinculando'):
                break
    finally:
        ventana.close()
        if not vinculado:
            _admin('POST', '/admin/cancelar')
        qr = datos.get('qr') or ''
        if qr:
            try:
                os.remove(qr)
            except OSError:
                pass
        del ventana
    if vinculado:
        xbmcgui.Dialog().notification(_TITULO, 'Móvil vinculado', xbmcgui.NOTIFICATION_INFO, 3000)
    return vinculado


# --- lo que llama el addon anfitrión ---

def pedir_texto(titulo, default=''):
    """Teclado de Kodi que el móvil vinculado puede rellenar. Siempre devuelve un str ('' si se
    cancela). Si el mando falla, el teclado de Kodi sigue sirviendo con el mando de la tele."""
    estado = None
    try:
        estado = _asegurar()
        if estado is not None and not int(estado.get('moviles') or 0):
            _vincular()
    except Exception as e:  # el modo nunca puede dejar al usuario sin poder escribir
        _log('Fallo del control remoto: {0}'.format(e), xbmc.LOGERROR)
        estado = None
    cabecera = titulo
    if estado is not None:
        cabecera = '{0} (o escríbelo en el móvil)'.format(titulo)
        aviso = 'Escribe en el móvil'
        if estado.get('url'):
            aviso += ': ' + estado['url']
        xbmcgui.Dialog().notification(_TITULO, aviso, xbmcgui.NOTIFICATION_INFO, 4000)
    teclado = xbmc.Keyboard(default or '', cabecera)
    teclado.doModal()
    return teclado.getText().strip() if teclado.isConfirmed() else ''


def vincular():
    """Entrada de menú «Vincular un móvil»."""
    try:
        if _asegurar() is not None:
            _vincular()
    except Exception as e:
        _log('Fallo al vincular: {0}'.format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification(_TITULO, 'No se pudo vincular', xbmcgui.NOTIFICATION_ERROR)


def _moviles_guardados():
    try:
        with open(os.path.join(_rutas()['perfil'], 'moviles.json'), 'r', encoding='utf-8') as f:
            moviles = json.load(f).get('moviles')
        return len(moviles) if isinstance(moviles, list) else 0
    except (OSError, ValueError, AttributeError):
        return 0


def estado_texto():
    if not instalado():
        return 'sin usar'
    n = _moviles_guardados()
    if not n:
        return 'sin móviles vinculados'
    return '1 móvil vinculado' if n == 1 else '{0} móviles vinculados'.format(n)


def olvidar():
    """Desvincula todos los móviles. Sin ninguno, para el servidor y desactiva el módulo: deja de
    arrancar con Kodi hasta que se vuelva a usar el modo."""
    if not instalado():
        xbmcgui.Dialog().notification(_TITULO, 'No hay móviles vinculados', xbmcgui.NOTIFICATION_INFO)
        return
    if not xbmcgui.Dialog().yesno(_TITULO, 'Ningún móvil podrá usar el mando hasta que lo vuelvas '
                                          'a vincular. ¿Olvidar todos los móviles?'):
        return
    if _admin('POST', '/admin/olvidar') is None:
        try:
            os.remove(os.path.join(_rutas()['perfil'], 'moviles.json'))
        except FileNotFoundError:
            pass
        except OSError as e:
            _log('No se pudo borrar la lista de móviles: {0}'.format(e), xbmc.LOGERROR)
            xbmcgui.Dialog().notification(_TITULO, 'No se pudo olvidar', xbmcgui.NOTIFICATION_ERROR)
            return
    _parar()
    _activar(False)
    xbmcgui.Dialog().notification(_TITULO, 'Móviles olvidados', xbmcgui.NOTIFICATION_INFO)


def quitar():
    """Desinstala el módulo y borra sus datos. No quita nada de los addons anfitriones."""
    if not instalado():
        xbmcgui.Dialog().notification(_TITULO, 'No está instalado', xbmcgui.NOTIFICATION_INFO)
        return
    if not xbmcgui.Dialog().yesno(_TITULO, 'Se quitará el control remoto completo y se olvidarán los '
                                          'móviles. Podrás volver a instalarlo eligiéndolo como forma de '
                                          'escribir. '
                                          '¿Quitarlo?'):
        return
    rutas = _rutas()
    if not _coger_cerrojo(rutas['cerrojo']):
        xbmcgui.Dialog().notification(_TITULO, 'Hay otro cambio en curso', xbmcgui.NOTIFICATION_WARNING)
        return
    try:
        _parar()
        _activar(False)
        _borrar_trabajo(rutas['trabajo'], rutas['addons'])
        os.makedirs(rutas['trabajo'], exist_ok=True)
        shutil.move(rutas['destino'], os.path.join(rutas['trabajo'], 'quitado'))
        _borrar_trabajo(rutas['trabajo'], rutas['addons'])
        perfil = rutas['perfil'].rstrip('/\\')
        if os.path.basename(perfil) == MODULO:
            shutil.rmtree(perfil, ignore_errors=True)
        xbmc.executebuiltin('UpdateLocalAddons()')
        xbmcgui.Dialog().notification(_TITULO, 'Control remoto quitado', xbmcgui.NOTIFICATION_INFO)
    except OSError as e:
        _log('No se pudo quitar {0}: {1}'.format(MODULO, e), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(_TITULO, 'No se pudo quitar: {0}'.format(e))
    finally:
        _soltar_cerrojo(rutas['cerrojo'])


def cambiar_puerto():
    """Puerto de inicio del mando (se prueban los 9 siguientes si está ocupado)."""
    rutas = _rutas()
    ruta = os.path.join(rutas['perfil'], 'config.json')
    try:
        with open(ruta, 'r', encoding='utf-8') as f:
            actual = int(json.load(f).get('puerto') or 8110)
    except (OSError, ValueError, AttributeError, TypeError):
        actual = 8110
    nuevo = xbmcgui.Dialog().numeric(0, 'Puerto del control remoto (1024-65525)', str(actual))
    if not nuevo:
        return
    try:
        puerto = int(nuevo)
    except ValueError:
        return
    if not 1024 <= puerto <= 65525:
        xbmcgui.Dialog().notification(_TITULO, 'Puerto no válido', xbmcgui.NOTIFICATION_WARNING)
        return
    try:
        os.makedirs(rutas['perfil'], exist_ok=True)
        with open(ruta + '.tmp', 'w', encoding='utf-8') as f:
            json.dump({'puerto': puerto}, f)
        os.replace(ruta + '.tmp', ruta)
    except OSError as e:
        xbmcgui.Dialog().ok(_TITULO, 'No se pudo guardar el puerto: {0}'.format(e))
        return
    if _vivo() is not None:
        _parar()
        _arrancar()
    xbmcgui.Dialog().notification(_TITULO, 'Puerto guardado: {0}'.format(puerto),
                                  xbmcgui.NOTIFICATION_INFO)
