# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Festivos Nacionales y Autonómicos de España, calculados para cualquier año."""
import datetime
import sys
import urllib.parse
import os

import xbmcgui
import xbmcplugin

_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

# (mes, dia, nombre): festivos nacionales de fecha fija
_NACIONALES_FIJOS = [
    (1,  1,  "Año Nuevo"),
    (1,  6,  "Epifanía del Señor — Reyes Magos"),
    (5,  1,  "Día del Trabajo"),
    (8,  15, "Asunción de la Virgen"),
    (10, 12, "Fiesta Nacional de España"),
    (11, 1,  "Todos los Santos"),
    (12, 6,  "Día de la Constitución Española"),
    (12, 8,  "Inmaculada Concepción"),
    (12, 25, "Natividad del Señor — Navidad"),
]

# (código, nombre, [(mes, dia, nombre), ...])
_CCAA_INFO = [
    ("AN", "Andalucía",             [(2, 28, "Día de Andalucía")]),
    ("AR", "Aragón",                [(4, 23, "Día de Aragón"), (10, 12, "Fiesta Nacional de España")]),
    ("AS", "Asturias",              [(9, 8,  "Día de Asturias")]),
    ("IB", "Islas Baleares",        [(3, 1,  "Día de las Islas Baleares")]),
    ("CN", "Canarias",              [(5, 30, "Día de Canarias")]),
    ("CB", "Cantabria",             [(8, 15, "Nuestra Señora La Virgen Grande")]),
    ("CM", "Castilla-La Mancha",    [(5, 31, "Día de Castilla-La Mancha")]),
    ("CL", "Castilla y León",       [(4, 23, "Día de Castilla y León")]),
    ("CT", "Cataluña",              [(9, 11, "Diada de Catalunya"), (6, 24, "Sant Joan")]),
    ("CE", "Ceuta",                 [(3, 5,  "Día de Ceuta")]),
    ("VC", "Comunitat Valenciana",  [(10, 9, "Día de la Comunitat Valenciana"), (3, 19, "San José / Las Fallas")]),
    ("EX", "Extremadura",           [(9, 8,  "Día de Extremadura")]),
    ("GA", "Galicia",               [(7, 25, "Día de Galicia"), (5, 17, "Día das Letras Galegas")]),
    ("RI", "La Rioja",              [(6, 9,  "Día de La Rioja")]),
    ("MD", "Comunidad de Madrid",   [(5, 2,  "Día de la Comunidad de Madrid"), (5, 15, "San Isidro")]),
    ("ML", "Melilla",               [(9, 17, "Día de Melilla")]),
    ("MU", "Región de Murcia",      [(6, 9,  "Día de la Región de Murcia")]),
    ("NC", "Navarra",               [(9, 27, "Día de Navarra"), (7, 7,  "San Fermín")]),
    ("PV", "País Vasco",            [(10, 25, "Día del País Vasco"), (7, 31, "San Ignacio de Loyola")]),
]

# ---------------------------------------------------------------------------
# Calendario escolar 2026-2027 (tabla estatica, revisada el 2026-11-11)
#
# Cada fecha lleva año, mes y dia explicitos: (año, mes, dia). Nunca se deduce el año
# del mes en que se consulta (el borrador anterior colocaba septiembre en 2027 al
# consultar en febrero). Las fechas son tuplas, no datetime.date, para que una errata
# no rompa la importacion del modulo: _d() devuelve None y esa fila se omite.
#
# Solo entran las comunidades cuya fuente oficial (boletin autonomico o web de la
# consejeria) se ha podido leer. Fuera: Andalucia (resoluciones por provincia en
# juntadeandalucia.es, cuyo servidor no responde desde la maquina de pruebas) y Ceuta
# (el calendario oficial es un PDF grafico sin texto). Los festivos locales no se
# incluyen: varian por municipio.
#
# Estructura de cada comunidad:
#   fuente      organismo que publica el calendario (se muestra como "Fuente: ...")
#   norma       disposicion o pagina oficial concreta
#   url         direccion de la fuente (comentada aqui y visible en la ficha)
#   revision    fecha en que se contrasto con la fuente
#   etapas      (etiqueta, inicio, fin, nota)   inicio/fin de clases por etapa
#   vacaciones  (etiqueta, desde, hasta, nota)
#   no_lectivos (motivo, desde, hasta o None)   dias sin clase fijados por la fuente
#   notas       avisos de la fuente (p. ej. cada centro fija su calendario)
# ---------------------------------------------------------------------------
_CURSO_ESCOLAR = "2026-2027"
_CURSO_ESCOLAR_FIN = (2027, 6, 30)   # pasada esta fecha se avisa de que puede haber uno nuevo
_REVISION_ESCOLAR = (2026, 11, 11)

_CALENDARIO_ESCOLAR = {
    # https://www.comunidad.madrid/docs/2026-06/bocm-131-04-06-2026_orden-2034-calendario-escolar-curso-2026-27.pdf
    "MD": {
        "fuente": "Consejería de Educación, Ciencia y Universidades de la Comunidad de Madrid",
        "norma": "Orden 2034/2026, de 25 de mayo (BOCM nº 131, de 4 de junio de 2026)",
        "url": "https://www.comunidad.madrid/docs/2026-06/bocm-131-04-06-2026_orden-2034-calendario-escolar-curso-2026-27.pdf",
        "revision": _REVISION_ESCOLAR,
        "etapas": [
            ("Infantil (2º ciclo), Primaria y Especial", (2026, 9, 7), (2027, 6, 18), ""),
            ("ESO, Bachillerato y FP", (2026, 9, 8), (2027, 6, 18),
             "2º de Bachillerato termina según las fechas de la prueba de acceso a la universidad."),
        ],
        "vacaciones": [
            ("Navidad", (2026, 12, 23), (2027, 1, 6), ""),
            ("Semana Santa", (2027, 3, 20), (2027, 3, 28), ""),
        ],
        "no_lectivos": [
            ("Fiesta nacional", (2026, 10, 12), None),
            ("Lunes siguiente a Todos los Santos", (2026, 11, 2), None),
            ("Constitución e Inmaculada", (2026, 12, 7), (2026, 12, 8)),
            ("Día no lectivo", (2027, 1, 7), (2027, 1, 8)),
            ("Día no lectivo", (2027, 2, 12), None),
            ("Día no lectivo", (2027, 2, 15), None),
            ("Día no lectivo", (2027, 3, 19), None),
            ("Día no lectivo", (2027, 3, 29), None),
        ],
        "notas": ["Los festivos locales de cada municipio se suman a estos días."],
    },
    # https://www.edubcn.cat/ca/centres_serveis_educatius/centres_educatius/gestio_centres/calendari_escolar/2026_2027
    "CT": {
        "fuente": "Departament d'Educació i Formació Professional de la Generalitat de Catalunya",
        "norma": "Ordre EDF/66/2026, de 22 d'abril (DOGC nº 9653, de 27 d'abril de 2026)",
        "url": "https://www.edubcn.cat/ca/centres_serveis_educatius/centres_educatius/gestio_centres/calendari_escolar/2026_2027",
        "revision": _REVISION_ESCOLAR,
        "etapas": [
            ("Infantil (2º ciclo), Primaria y ESO", (2026, 9, 8), (2027, 6, 21), ""),
            ("Bachillerato", (2026, 9, 8), (2027, 6, 17), ""),
        ],
        "vacaciones": [
            ("Navidad", (2026, 12, 22), (2027, 1, 7), ""),
            ("Semana Santa", (2027, 3, 20), (2027, 3, 29), ""),
        ],
        "no_lectivos": [],
        "notas": ["Cada centro puede fijar hasta cuatro días de libre disposición, repartidos entre los tres trimestres.",
                  "Los festivos los fija el Departament d'Empresa i Treball, más dos locales por municipio."],
    },
    # https://portal.edu.gva.es/consellescolar/wp-content/uploads/sites/238/2026/06/Calendario-Escolar-2026-2027-Val.pdf
    "VC": {
        "fuente": "Conselleria d'Educació, Cultura i Universitats de la Generalitat Valenciana",
        "norma": "Resolución de 15 de junio de 2026 de la Dirección General de Centros Docentes (DOGV nº 10387, de 18 de junio de 2026)",
        "url": "https://portal.edu.gva.es/consellescolar/wp-content/uploads/sites/238/2026/06/Calendario-Escolar-2026-2027-Val.pdf",
        "revision": _REVISION_ESCOLAR,
        "etapas": [
            ("Infantil, Primaria, ESO, Bachillerato y FP", (2026, 9, 9), (2027, 6, 18), ""),
        ],
        "vacaciones": [
            ("Navidad", (2026, 12, 22), (2027, 1, 6), ""),
            ("Pascua", (2027, 3, 25), (2027, 4, 5), ""),
        ],
        "no_lectivos": [
            ("Día de la Comunitat Valenciana", (2026, 10, 9), None),
            ("Fiesta Nacional de España", (2026, 10, 12), None),
            ("Inmaculada Concepción", (2026, 12, 8), None),
            ("San José", (2027, 3, 19), None),
        ],
        "notas": ["Los ayuntamientos pueden proponer hasta tres días no lectivos locales."],
    },
    # https://www.xunta.gal/dog/Publicados/2026/20260615/AnuncioG0761-050626-0001_es.html
    "GA": {
        "fuente": "Consellería de Educación, Ciencia, Universidades e Formación Profesional de la Xunta de Galicia",
        "norma": "Orde do 4 de xuño de 2026 (DOG nº 110, de 15 de junio de 2026)",
        "url": "https://www.xunta.gal/dog/Publicados/2026/20260615/AnuncioG0761-050626-0001_es.html",
        "revision": _REVISION_ESCOLAR,
        "etapas": [
            ("Infantil, Primaria, ESO, Bachillerato y 1º de FP", (2026, 9, 9), (2027, 6, 21),
             "2º de Bachillerato termina según las fechas de la PAU."),
            ("2º curso de FP", (2026, 9, 9), (2027, 6, 15), ""),
        ],
        "vacaciones": [
            ("Navidad", (2026, 12, 22), (2027, 1, 7), ""),
            ("Entroido", (2027, 2, 8), (2027, 2, 10), ""),
            ("Semana Santa", (2027, 3, 22), (2027, 3, 29), ""),
        ],
        "no_lectivos": [
            ("Día de la Enseñanza", (2026, 12, 7), None),
        ],
        "notas": [],
    },
    # https://miprincipado.asturias.es/bopa/2026/06/01/2026-04361.pdf
    "AS": {
        "fuente": "Consejería de Educación del Principado de Asturias",
        "norma": "Resolución de 13 de mayo de 2026 (BOPA nº 103, de 1 de junio de 2026)",
        "url": "https://miprincipado.asturias.es/bopa/2026/06/01/2026-04361.pdf",
        "revision": _REVISION_ESCOLAR,
        "etapas": [
            ("Infantil (3 a 6 años), Primaria, Especial, ESO y Bachillerato", (2026, 9, 9), (2027, 6, 23), ""),
            ("Formación Profesional", (2026, 9, 14), (2027, 5, 28), ""),
        ],
        "vacaciones": [
            ("Navidad", (2026, 12, 23), (2027, 1, 10), ""),
            ("Semana Santa", (2027, 3, 22), (2027, 3, 28), ""),
        ],
        "no_lectivos": [
            ("Día no lectivo", (2026, 10, 30), None),
            ("Día no lectivo", (2026, 11, 3), (2026, 11, 4)),
            ("Día no lectivo", (2027, 2, 8), (2027, 2, 9)),
            ("Día no lectivo", (2027, 4, 30), None),
            ("Día no lectivo", (2027, 5, 3), None),
        ],
        "notas": ["Se suman las fiestas nacionales y autonómicas y los dos festivos locales de cada municipio."],
    },
    # https://boc.cantabria.es/boces/verAnuncioAction.do?idAnuBlob=434226
    "CB": {
        "fuente": "Consejería de Educación, Formación Profesional y Universidades de Cantabria",
        "norma": "Orden EDU/10/2026, de 24 de marzo (BOC nº 75, de 21 de abril de 2026)",
        "url": "https://boc.cantabria.es/boces/verAnuncioAction.do?idAnuBlob=434226",
        "revision": _REVISION_ESCOLAR,
        "etapas": [
            ("Infantil, Primaria y Especial", (2026, 9, 8), (2027, 6, 23), ""),
            ("ESO, Bachillerato y FP", (2026, 9, 9), (2027, 6, 24), ""),
        ],
        "vacaciones": [
            ("Navidad", (2026, 12, 23), (2027, 1, 8), "Las clases se retoman el lunes 11 de enero de 2027."),
            ("Carnaval", (2027, 2, 10), (2027, 2, 12), ""),
            ("Semana Santa", (2027, 3, 22), (2027, 3, 26), "Las clases se retoman el lunes 29 de marzo de 2027."),
        ],
        "no_lectivos": [
            ("Descanso de noviembre", (2026, 11, 2), (2026, 11, 6)),
            ("Descanso de mayo", (2027, 5, 3), (2027, 5, 4)),
        ],
        "notas": [],
    },
    # https://educa.aragon.es/calendario-escolar
    "AR": {
        "fuente": "Departamento de Educación, Cultura y Deporte del Gobierno de Aragón",
        "norma": "Resolución de 29 de abril de 2025 de la Dirección General de Planificación, Centros y FP (BOA nº 88, de 12 de mayo de 2025)",
        "url": "https://educa.aragon.es/calendario-escolar",
        "revision": _REVISION_ESCOLAR,
        "etapas": [
            ("Infantil (2º ciclo), Primaria, Especial y ESO", (2026, 9, 8), (2027, 6, 18), ""),
            ("Bachillerato", (2026, 9, 9), (2027, 6, 18), ""),
            ("Formación Profesional presencial", (2026, 9, 10), (2027, 6, 18), ""),
        ],
        "vacaciones": [
            ("Navidad", (2026, 12, 22), (2027, 1, 6), "Desde el final de las clases de la mañana del 22 de diciembre."),
            ("Semana Santa", (2027, 3, 25), (2027, 4, 2), ""),
        ],
        "no_lectivos": [
            ("Fiesta nacional", (2026, 10, 12), None),
            ("Lunes siguiente a Todos los Santos", (2026, 11, 2), None),
            ("Lunes siguiente a la Constitución", (2026, 12, 7), None),
            ("Inmaculada Concepción", (2026, 12, 8), None),
            ("Día de Aragón", (2027, 4, 23), None),
            ("Huesca", (2027, 2, 18), (2027, 2, 19)),
            ("Huesca", (2027, 5, 3), None),
            ("Teruel", (2027, 2, 18), (2027, 2, 19)),
            ("Teruel", (2027, 4, 26), None),
            ("Zaragoza", (2026, 10, 13), (2026, 10, 14)),
            ("Zaragoza", (2027, 5, 3), None),
        ],
        "notas": ["Los días no lectivos que llevan nombre de provincia solo valen para esa provincia."],
    },
    # https://www.caib.es/eboibfront/pdf/es/2026/41/1216209
    "IB": {
        "fuente": "Conselleria d'Educació i Universitats del Govern de les Illes Balears",
        "norma": "Resolución del consejero de 27 de marzo de 2026 (BOIB nº 41, de 31 de marzo de 2026; modificada en el BOIB nº 82, de 30 de junio de 2026, sin cambiar fechas)",
        "url": "https://www.caib.es/eboibfront/pdf/es/2026/41/1216209",
        "revision": _REVISION_ESCOLAR,
        "etapas": [
            ("Infantil, Primaria, Especial, ESO y Bachillerato", (2026, 9, 10), (2027, 6, 18),
             "El alumnado de 2º de Bachillerato que titule acaba las clases el 20 de mayo de 2027."),
        ],
        "vacaciones": [
            ("Navidad", (2026, 12, 23), (2027, 1, 6), ""),
            ("Pascua", (2027, 3, 25), (2027, 4, 4), ""),
        ],
        "no_lectivos": [
            ("Fiesta Nacional de España", (2026, 10, 12), None),
            ("Inmaculada Concepción", (2026, 12, 8), None),
            ("Fiesta escolar unificada", (2027, 2, 26), None),
            ("Día de las Illes Balears", (2027, 3, 1), None),
        ],
        "notas": [],
    },
    # https://www.gobiernodecanarias.org/boc/2026/061/1025.html
    "CN": {
        "fuente": "Consejería de Educación, FP, Actividad Física y Deportes del Gobierno de Canarias",
        "norma": "Resolución de 17 de marzo de 2026 (BOC nº 61, de 30 de marzo de 2026)",
        "url": "https://www.gobiernodecanarias.org/boc/2026/061/1025.html",
        "revision": _REVISION_ESCOLAR,
        "etapas": [
            ("Infantil y Primaria", (2026, 9, 9), (2027, 6, 22), ""),
            ("ESO", (2026, 9, 10), (2027, 6, 22), ""),
            # BOC nº 61, pág. 12190-12191: 2º de Bachillerato acaba el 14 de mayo de 2027
            # (la tabla y el anexo I, "entrega de calificaciones finales", coinciden).
            # 1º de Bachillerato queda sin fecha: la tabla dice 18 de junio y el anexo I
            # dice 22 de junio para "finalización de actividades"; el texto se contradice.
            ("1.º de Bachillerato (inicio)", (2026, 9, 11), None,
             "La resolución da dos fechas de fin distintas (18 y 22 de junio de 2027); consulta el BOC nº 61."),
            ("2.º de Bachillerato", (2026, 9, 11), (2027, 5, 14),
             "Evaluación final ordinaria el 14 de mayo; la extraordinaria, el 11 de junio."),
        ],
        "vacaciones": [
            ("Navidad", (2026, 12, 22), (2027, 1, 7), ""),
            ("Semana Santa", (2027, 3, 22), (2027, 3, 26), ""),
        ],
        "no_lectivos": [
            ("Todos los Santos (trasladado)", (2026, 11, 2), None),
            ("Día del Enseñante y del Estudiante", (2026, 12, 7), None),
            ("Inmaculada Concepción", (2026, 12, 8), None),
        ],
        "notas": ["Cada centro puede fijar hasta cuatro días no lectivos de libre disposición.",
                  "Las fiestas insulares y locales se suman a estos días."],
    },
    # https://docm.jccm.es/portaldocm/descargarArchivo.do?ruta=2026%2F06%2F03%2Fpdf%2F2026_4106.pdf&tipo=rutaDocm
    "CM": {
        "fuente": "Consejería de Educación, Cultura y Deportes de Castilla-La Mancha",
        "norma": "Orden 79/2026, de 26 de mayo (DOCM nº 104, de 3 de junio de 2026)",
        "url": "https://docm.jccm.es/portaldocm/descargarArchivo.do?ruta=2026%2F06%2F03%2Fpdf%2F2026_4106.pdf&tipo=rutaDocm",
        "revision": _REVISION_ESCOLAR,
        "etapas": [
            ("Infantil (2º ciclo), Primaria, Especial, ESO, Bachillerato y FP básica", (2026, 9, 8), (2027, 6, 22),
             "2º de Bachillerato termina según las fechas de la prueba de acceso a la universidad."),
        ],
        "vacaciones": [
            ("Navidad", (2026, 12, 23), (2027, 1, 8), ""),
            ("Semana Santa", (2027, 3, 22), (2027, 3, 29), ""),
        ],
        "no_lectivos": [
            ("Día de la Enseñanza", (2026, 11, 20), None),
            ("Día no lectivo", (2026, 12, 7), None),
            ("Libre disposición", (2027, 2, 8), (2027, 2, 9)),
            ("Día no lectivo", (2027, 5, 28), None),
        ],
        "notas": ["Las Delegaciones Provinciales concretan el calendario de su provincia."],
    },
    # https://www.educa.jcyl.es/es/informacion/calendario-escolar-2026-2027
    "CL": {
        "fuente": "Consejería de Educación de la Junta de Castilla y León",
        "norma": "Orden EDU/478/2026, de 25 de mayo (BOCYL nº 101, de 28 de mayo de 2026)",
        "url": "https://www.educa.jcyl.es/es/informacion/calendario-escolar-2026-2027",
        "revision": _REVISION_ESCOLAR,
        "etapas": [
            ("Infantil (2º ciclo), Primaria y Especial", (2026, 9, 9), (2027, 6, 24), ""),
            ("ESO", (2026, 9, 15), (2027, 6, 24), ""),
            ("1º de Bachillerato y FP presencial", (2026, 9, 15), (2027, 6, 17), ""),
            ("2º de Bachillerato", (2026, 9, 15), (2027, 5, 21), ""),
        ],
        "vacaciones": [
            ("Navidad", (2026, 12, 23), (2027, 1, 10), ""),
            ("Carnaval", (2027, 2, 8), (2027, 2, 9), ""),
            ("Semana Santa", (2027, 3, 20), (2027, 3, 30), ""),
        ],
        "no_lectivos": [
            ("Fiesta Nacional de España", (2026, 10, 12), None),
            ("Día del Docente", (2026, 10, 30), None),
            ("Todos los Santos (trasladado)", (2026, 11, 2), None),
            ("Constitución (trasladado)", (2026, 12, 7), None),
            ("Inmaculada Concepción", (2026, 12, 8), None),
            ("Día de Castilla y León", (2027, 4, 23), None),
        ],
        "notas": [],
    },
    # https://doe.juntaex.es/pdfs/doe/2026/1160o/26061567.pdf
    "EX": {
        "fuente": "Secretaría General de Educación de la Junta de Extremadura",
        "norma": "Resolución de 15 de junio de 2026 (DOE nº 116, de 18 de junio de 2026)",
        "url": "https://doe.juntaex.es/pdfs/doe/2026/1160o/26061567.pdf",
        "revision": _REVISION_ESCOLAR,
        "etapas": [
            ("Infantil (2º ciclo), Primaria, Especial y ESO", (2026, 9, 10), (2027, 6, 18), ""),
            ("1º de Bachillerato", (2026, 9, 11), (2027, 6, 17), ""),
            ("2º de Bachillerato", (2026, 9, 11), (2027, 5, 7), ""),
        ],
        "vacaciones": [
            ("Navidad", (2026, 12, 23), (2027, 1, 7), ""),
            ("Carnaval", (2027, 2, 8), (2027, 2, 9), ""),
            ("Semana Santa", (2027, 3, 22), (2027, 3, 29), ""),
        ],
        "no_lectivos": [
            ("Día de Extremadura", (2026, 9, 8), None),
            ("Fiesta Nacional de España", (2026, 10, 12), None),
            ("Lunes siguiente a Todos los Santos", (2026, 11, 2), None),
            ("Lunes siguiente a la Constitución", (2026, 12, 7), None),
            ("Inmaculada Concepción", (2026, 12, 8), None),
            ("Día del Docente", (2027, 1, 29), None),
        ],
        "notas": [],
    },
    # https://actualidad.larioja.org/noticia?n=not-el-proximo-curso-escolar-2026-2027-comenzara-en-la-rioja-el-9-de-septiembre-y-finalizara-el-22
    "RI": {
        "fuente": "Consejería de Educación y Empleo del Gobierno de La Rioja",
        "norma": "Resolución publicada en el BOR el 16 de abril de 2026 (nota oficial del Gobierno de La Rioja)",
        "url": "https://actualidad.larioja.org/noticia?n=not-el-proximo-curso-escolar-2026-2027-comenzara-en-la-rioja-el-9-de-septiembre-y-finalizara-el-22",
        "revision": _REVISION_ESCOLAR,
        "etapas": [
            ("Infantil, Primaria, ESO y Bachillerato (con carácter general)", (2026, 9, 9), (2027, 6, 22), ""),
        ],
        "vacaciones": [
            ("Navidad", (2026, 12, 23), (2027, 1, 6), ""),
            ("Semana Santa", (2027, 3, 25), (2027, 4, 4), ""),
        ],
        "no_lectivos": [
            ("Fiesta Nacional de España", (2026, 10, 12), None),
            ("Lunes siguiente a la Constitución", (2026, 12, 7), None),
            ("Inmaculada Concepción", (2026, 12, 8), None),
            ("Día de la Comunidad Educativa", (2027, 2, 26), None),
            ("Día de La Rioja", (2027, 6, 9), None),
        ],
        "notas": ["Los municipios pueden proponer hasta siete días no lectivos de carácter local."],
    },
    # https://www.borm.es/services/anuncio/ano/2026/numero/2748/pdf?id=843430
    "MU": {
        "fuente": "Dirección General de Centros Educativos e Infraestructuras de la Región de Murcia",
        "norma": "Resolución de 8 de junio de 2026 (BORM nº 132, de 11 de junio de 2026)",
        "url": "https://www.borm.es/services/anuncio/ano/2026/numero/2748/pdf?id=843430",
        "revision": _REVISION_ESCOLAR,
        "etapas": [
            ("Infantil, Primaria y Especial", (2026, 9, 8), (2027, 6, 22), ""),
            ("ESO y FP básica", (2026, 9, 10), (2027, 6, 21), ""),
            ("Bachillerato", (2026, 9, 10), (2027, 6, 21), ""),
        ],
        "vacaciones": [
            ("Navidad", (2026, 12, 24), (2027, 1, 6), ""),
            ("Semana Santa", (2027, 3, 22), (2027, 3, 29), ""),
        ],
        "no_lectivos": [
            ("Patrón de Infantil, Primaria y Especial", (2026, 11, 27), None),
            ("Día no lectivo", (2026, 12, 23), None),
            ("Patrón de ESO y Bachillerato", (2027, 1, 29), None),
        ],
        "notas": ["Los consejos escolares municipales proponen además tres días no lectivos."],
    },
    # https://www.educacion.navarra.es/en/web/dpto/calendario-escolar
    "NC": {
        "fuente": "Departamento de Educación del Gobierno de Navarra",
        "norma": "Resolución 143/2026, de 31 de marzo, y cuadro resumen del Departamento",
        "url": "https://www.educacion.navarra.es/en/web/dpto/calendario-escolar",
        "revision": _REVISION_ESCOLAR,
        "etapas": [
            ("Infantil (2º ciclo), Primaria y Especial", (2026, 9, 4), (2027, 6, 22),
             "Cada centro elige el inicio entre el 4 y el 8 de septiembre, y el fin entre el 18 y el 22 de junio."),
            ("ESO y 1º de Bachillerato", (2026, 9, 4), (2027, 6, 21), ""),
        ],
        "vacaciones": [
            ("Navidad", (2026, 12, 23), (2027, 1, 10), ""),
            ("Semana Santa", (2027, 3, 25), (2027, 4, 4), ""),
        ],
        "no_lectivos": [],
        "notas": ["Cada centro aprueba su propio calendario dentro de estos límites; puede haber variaciones de uno a otro."],
    },
    # https://www.euskadi.eus/estructura-y-organizacion-de-los-centros-calendario-escolar-centros-publicos-y-privados/web01-a2hikast/es/
    "PV": {
        "fuente": "Departamento de Educación del Gobierno Vasco",
        "norma": "Resoluciones de la Viceconsejería de Políticas Educativas (Infantil/Primaria y ESO/Bachillerato/FP), 2026",
        "url": "https://www.euskadi.eus/estructura-y-organizacion-de-los-centros-calendario-escolar-centros-publicos-y-privados/web01-a2hikast/es/",
        "revision": _REVISION_ESCOLAR,
        "etapas": [
            ("Infantil, Primaria, ESO y Bachillerato (límites oficiales)", (2026, 9, 7), (2027, 6, 18),
             "Las clases no pueden empezar antes del 7 de septiembre ni acabar después del 18 de junio."),
            ("1º de Bachillerato (fin de clases)", (2026, 9, 7), (2027, 5, 28),
             "Del 31 de mayo al 18 de junio se hacen las pruebas finales."),
        ],
        "vacaciones": [
            ("Navidad (mínimo)", (2026, 12, 24), (2027, 1, 6), "Cada centro puede ampliarla."),
            ("Semana Santa (mínimo)", (2027, 3, 25), (2027, 3, 29), "Cada centro puede ampliarla."),
        ],
        "no_lectivos": [],
        "notas": ["Cada centro aprueba su calendario en su consejo escolar dentro de estos límites."],
    },
    # https://www.educacionfpydeportes.gob.es/dam/jcr:97a96fff-bae7-4388-a5ec-bb6b7e564abc/resolucion-calendario-escolar-26-27.pdf
    "ML": {
        "fuente": "Ministerio de Educación, Formación Profesional y Deportes (Dirección General de Planificación y Gestión Educativa)",
        "norma": "Resolución de 10 de junio de 2026 por la que se establece el calendario escolar de Melilla",
        "url": "https://www.educacionfpydeportes.gob.es/dam/jcr:97a96fff-bae7-4388-a5ec-bb6b7e564abc/resolucion-calendario-escolar-26-27.pdf",
        "revision": _REVISION_ESCOLAR,
        "etapas": [
            ("Especial, Infantil, Primaria, ESO, FP básica y Bachillerato", (2026, 9, 9), (2027, 6, 23),
             "En 2º de Bachillerato el calendario se adapta a la prueba de acceso a la universidad."),
        ],
        "vacaciones": [
            ("Navidad", (2026, 12, 23), (2027, 1, 7), ""),
            ("Semana Santa", (2027, 3, 22), (2027, 3, 26), ""),
        ],
        "no_lectivos": [
            ("Virgen de la Victoria", (2026, 9, 8), None),
            ("Día de Melilla", (2026, 9, 17), None),
            ("Libre disposición", (2026, 9, 21), None),
            ("Fiesta Nacional de España", (2026, 10, 12), None),
            ("Libre disposición", (2026, 11, 2), None),
            ("Lunes siguiente a la Constitución", (2026, 12, 7), None),
            ("Inmaculada Concepción", (2026, 12, 8), None),
            ("Libre disposición", (2027, 1, 8), None),
            ("Final del Ramadán", (2027, 3, 9), None),
            ("Libre disposición", (2027, 3, 29), (2027, 4, 2)),
            ("Fiesta del Sacrificio (Eid al-Adha)", (2027, 5, 17), None),
        ],
        "notas": [],
    },
}

_DIAS_ES   = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
_MESES_ES  = ["", "enero", "febrero", "marzo", "abril", "mayo", "junio",
              "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _fecha_str(fecha):
    return f"{_DIAS_ES[fecha.weekday()]} {fecha.day} de {_MESES_ES[fecha.month]} de {fecha.year}"


def _pascua(year):
    """Domingo de Pascua gregoriano (algoritmo gregoriano anónimo, Butcher-Meeus)."""
    a = year % 19
    b, c = divmod(year, 100)
    d, e = divmod(b, 4)
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = divmod(c, 4)
    L = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * L) // 451
    month, day = divmod(h + L - 7 * m + 114, 31)
    return datetime.date(year, month, day + 1)


def _nota_domingo(fecha):
    # El Art. 37.2 ET traslada al lunes el descanso, pero quien mueve el festivo en el
    # calendario es cada CCAA, no el Estado: por eso se avisa en vez de cambiar la fecha.
    if fecha.weekday() != 6:
        return ""
    lunes = fecha + datetime.timedelta(days=1)
    return ("Cae en domingo; tu comunidad autónoma puede trasladarlo al "
            f"lunes {lunes.day} de {_MESES_ES[lunes.month]}.")


def _nacionales(year):
    """Festivos nacionales del año: los de fecha fija más el Viernes Santo."""
    fechas = [(datetime.date(year, mes, dia), nombre) for mes, dia, nombre in _NACIONALES_FIJOS]
    fechas.append((_pascua(year) - datetime.timedelta(days=2), "Viernes Santo"))
    return sorted(fechas)


def _item(fecha, nombre, tipo):
    return {
        "nombre":    nombre,
        "fecha_str": _fecha_str(fecha),
        "days_left": (fecha - datetime.date.today()).days,
        "tipo":      tipo,
        "date":      fecha,
        "nota":      _nota_domingo(fecha),
    }


def _fundir_misma_fecha(items):
    """Un dia festivo, una fila.

    Hay comunidades cuyo festivo propio cae sobre uno nacional. Aragon repite el 12 de
    octubre con el mismo nombre, y Cantabria celebra la Virgen Grande el 15 de agosto,
    que ya es la Asuncion. Sin esto salen dos filas para un solo dia de fiesta.
    """
    por_fecha = {}
    for it in items:
        previo = por_fecha.get(it["date"])
        if previo is None:
            por_fecha[it["date"]] = it
            continue
        if it["nombre"] not in previo["nombre"]:
            previo["nombre"] += " / " + it["nombre"]
        # Que sea festivo en toda Espana manda sobre el matiz autonomico.
        if it["tipo"] == "nacional":
            previo["tipo"] = "nacional"
    return list(por_fecha.values())


def _build_items_zona(year, zona_code):
    items = [_item(fecha, nombre, "nacional") for fecha, nombre in _nacionales(year)]
    if zona_code != "ES":
        ccaa_extra = next((extras for code, _, extras in _CCAA_INFO if code == zona_code), [])
        items += [_item(datetime.date(year, mes, dia), nombre, "autonomico")
                  for mes, dia, nombre in ccaa_extra]
    items = _fundir_misma_fecha(items)
    items.sort(key=lambda x: x["date"])
    return items


def _d(t):
    """(año, mes, dia) -> date, o None si la tupla no es una fecha valida (nunca lanza)."""
    try:
        return datetime.date(t[0], t[1], t[2])
    except (TypeError, ValueError, IndexError):
        return None


def _fecha_corta(fecha):
    return f"{_DIAS_ES[fecha.weekday()][:3].lower()} {fecha.day} {_MESES_ES[fecha.month][:3]} {fecha.year}"


def _rango_txt(desde, hasta):
    if desde is None:
        return ""
    if hasta is None or hasta == desde:
        return _fecha_corta(desde)
    return f"{_fecha_corta(desde)} al {_fecha_corta(hasta)}"


def escolar_disponible(zona_code):
    """True si hay calendario escolar verificado para esa comunidad."""
    return zona_code in _CALENDARIO_ESCOLAR


def _escolar_filas(zona_code):
    """Filas del calendario escolar de una comunidad: no depende de la fecha de hoy.

    Cada fila: {"tipo", "etiqueta", "desde", "hasta", "nota"} con fechas ya convertidas.
    Las filas con una fecha invalida se omiten (el listado nunca se rompe por una errata).
    """
    datos = _CALENDARIO_ESCOLAR.get(zona_code)
    if not datos:
        return []
    filas = []
    for etiqueta, ini, fin, nota in datos["etapas"]:
        desde = _d(ini)
        if desde is None:
            continue
        filas.append({"tipo": "curso", "etiqueta": etiqueta, "desde": desde,
                      "hasta": _d(fin) if fin else None, "nota": nota})
    for etiqueta, ini, fin, nota in datos["vacaciones"]:
        desde = _d(ini)
        if desde is None:
            continue
        filas.append({"tipo": "vacaciones", "etiqueta": etiqueta, "desde": desde,
                      "hasta": _d(fin) if fin else None, "nota": nota})
    for etiqueta, ini, fin in datos["no_lectivos"]:
        desde = _d(ini)
        if desde is None:
            continue
        filas.append({"tipo": "no_lectivo", "etiqueta": etiqueta, "desde": desde,
                      "hasta": _d(fin) if fin else None, "nota": ""})
    return filas


def _escolar_fuera_de_curso():
    """True cuando hoy es posterior al curso cubierto por la tabla."""
    fin = _d(_CURSO_ESCOLAR_FIN)
    return fin is not None and datetime.date.today() > fin


def festivos_escolar(zona_code):
    h = int(sys.argv[1])
    icon = _icon("festivos_escolar.png")
    datos = _CALENDARIO_ESCOLAR.get(zona_code)
    nombre = next((n for code, n, _ in _CCAA_INFO if code == zona_code), zona_code)
    xbmcplugin.setPluginCategory(h, f"Calendario escolar {_CURSO_ESCOLAR} — {nombre}")

    def _fila(label, plot="", titulo=""):
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon})
        li.setInfo("video", {"title": titulo or label, "plot": plot})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)

    if not datos:
        _fila("[COLOR grey]Esta comunidad aún no tiene calendario escolar verificado.[/COLOR]")
        xbmcplugin.endOfDirectory(h)
        return

    if _escolar_fuera_de_curso():
        _fila(f"[COLOR tomato]Calendario del curso {_CURSO_ESCOLAR}; puede haber uno más reciente[/COLOR]",
              f"Estos datos son del curso {_CURSO_ESCOLAR}. Consulta la fuente oficial por si ya hay otro.")

    titulos = (("curso", "Inicio y fin de las clases"),
               ("vacaciones", "Vacaciones"),
               ("no_lectivo", "Días no lectivos"))
    filas = _escolar_filas(zona_code)
    for tipo, titulo in titulos:
        grupo = [f for f in filas if f["tipo"] == tipo]
        if not grupo:
            continue
        _fila(f"[COLOR gold]── {titulo} ──[/COLOR]")
        for f in grupo:
            if tipo == "curso":
                rango = (f"{_fecha_corta(f['desde'])} → {_fecha_corta(f['hasta'])}" if f["hasta"]
                         else f"desde {_fecha_corta(f['desde'])}")
            else:
                rango = _rango_txt(f["desde"], f["hasta"])
            label = f"[B]{f['etiqueta']}[/B]   [COLOR grey]{rango}[/COLOR]"
            plot = f"{f['etiqueta']}\n{rango}"
            if f["nota"]:
                plot += f"\n\n{f['nota']}"
            _fila(label, plot, f["etiqueta"])

    for nota in datos["notas"]:
        _fila(f"[COLOR grey]{nota}[/COLOR]", nota)

    rev = _d(datos["revision"])
    detalle = (f"Fuente: {datos['fuente']}\n{datos['norma']}\n{datos['url']}\n"
               f"Revisado el {_fecha_str(rev) if rev else ''}.")
    _fila(f"[COLOR deepskyblue]Fuente: {datos['fuente']}[/COLOR]", detalle, "Fuente")
    xbmcplugin.endOfDirectory(h)


def festivos_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_festivos.png")

    li_nac = xbmcgui.ListItem(label="[B]Festivos Nacionales (toda España)[/B]")
    li_nac.setArt({"icon": icon})
    li_nac.setInfo("video", {"plot": "Festivos nacionales comunes a todo el territorio español."})
    li_nac.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="festivos_zona", zona="ES"),
                                listitem=li_nac, isFolder=True)

    for code, nombre, _ in _CCAA_INFO:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(nombre))
        li.setArt({"icon": icon})
        li.setInfo("video", {"plot": "Festivos nacionales mas los festivos propios de {0}.".format(nombre)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="festivos_zona", zona=code),
                                    listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def festivos_zona(zona_code):
    h = int(sys.argv[1])
    icon = _icon("cat_festivos.png")
    if zona_code == "ES":
        titulo = "Festivos Nacionales"
    else:
        titulo = next((nombre for code, nombre, _ in _CCAA_INFO if code == zona_code), zona_code)

    xbmcplugin.setPluginCategory(h, titulo)
    today = datetime.date.today()

    if escolar_disponible(zona_code):
        li_esc = xbmcgui.ListItem(label=f"[B][COLOR lightgreen]Calendario escolar {_CURSO_ESCOLAR}[/COLOR][/B]")
        li_esc.setArt({"icon": _icon("festivos_escolar.png")})
        li_esc.setInfo("video", {"plot": f"Inicio y fin de curso, vacaciones y días no lectivos de {titulo}.\n"
                                         f"Fuente: {_CALENDARIO_ESCOLAR[zona_code]['fuente']}"})
        li_esc.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="festivos_escolar", zona=zona_code),
                                    listitem=li_esc, isFolder=True)

    for year in (today.year, today.year + 1):
        sep = xbmcgui.ListItem(label=f"[COLOR gold]── Festivos {year} — {titulo} ──[/COLOR]")
        sep.setArt({"icon": icon})
        sep.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=sep, isFolder=False)

        for it in _build_items_zona(year, zona_code):
            days_left = it["days_left"]
            if days_left < 0:
                color = "grey"
                resta = "ya paso"
            elif days_left == 0:
                color = "tomato"
                resta = "HOY"
            else:
                resta = f"en {days_left} dia{'s' if days_left != 1 else ''}"
                if days_left <= 7:
                    color = "gold"
                elif days_left <= 30:
                    color = "khaki"
                else:
                    color = "white"

            tipo_str = ("[COLOR deepskyblue][nacional][/COLOR]" if it["tipo"] == "nacional"
                        else "[COLOR plum][autonomico][/COLOR]")
            marca = "   [COLOR grey](en domingo)[/COLOR]" if it["nota"] else ""
            label = (f"[B][COLOR {color}]{it['nombre']}[/COLOR][/B]   "
                     f"[COLOR grey]{it['fecha_str']}[/COLOR]   {tipo_str}{marca}")
            plot = f"{it['nombre']}\n{it['fecha_str']}\n{resta}\nFestivo {it['tipo']}"
            if it["nota"]:
                plot += f"\n\n{it['nota']}"
            li = xbmcgui.ListItem(label=label)
            li.setArt({"icon": icon})
            li.setInfo("video", {"title": it["nombre"], "plot": plot})
            li.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)
