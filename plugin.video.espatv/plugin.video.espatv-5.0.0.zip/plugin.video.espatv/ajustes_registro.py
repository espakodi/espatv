# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Registro de ajustes del Modo Ajustes: qué ajustes existen, de dónde se leen y dónde se escriben.

Los nativos salen de resources/settings.xml (etiqueta, cabecera plegada y ayuda, como los enseña
Kodi). Las acciones del menú Opciones, que no están en ese XML, se declaran aquí para que la ventana
no dependa del despachador de default.py.
"""
from __future__ import annotations

import copy
import os
import re
import xml.etree.ElementTree as ET
from dataclasses import dataclass
from typing import Callable, Optional

# Tipos que la ventana sabe representar. 'clasico' es la salida para lo que no entendemos: se
# muestra como una fila que abre los ajustes nativos de Kodi, nunca se salta la categoría entera.
TIPOS = ('bool', 'enum', 'slider', 'number', 'text', 'folder', 'action', 'info', 'clasico')
TIPOS_CON_VALOR = ('bool', 'enum', 'slider', 'number', 'text', 'folder')

MODIFICADOS = 'modificados'
CABECERA_MODIFICADOS = 'Modificados'

_RUTA_XML = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'settings.xml')


@dataclass
class Entrada:
    id: str
    categoria: str
    rotulo: str
    tipo: str
    cabecera: str = ''
    ayuda: str = ''
    opciones: tuple = ()
    guarda_indice: bool = False
    rango: tuple = ()
    defecto: object = None
    leer: Optional[Callable] = None
    escribir: Optional[Callable] = None
    depende_de: tuple = ()
    secreto: bool = False
    destructivo: bool = False
    protegido: bool = False
    confirmar: bool = False
    accion: object = None
    clase_accion: str = ''
    tambien_en: str = ''
    icono: str = ''
    origen: str = 'nativo'
    # Nombres de los ganchos de default.py para las filas cuyo valor no vive en un ajuste nativo
    # sino en core_settings o en default.py (Accesibilidad). construir() los resuelve a callables.
    leer_gancho: str = ''
    escribir_gancho: str = ''


@dataclass
class Categoria:
    clave: str
    rotulo: str
    subtitulo: str
    icono: str


CATEGORIAS = [
    Categoria('inicio', 'Inicio', 'Lo primero que ves al abrir EspaTV', 'ajustes_inicio.png'),
    Categoria('apariencia', 'Apariencia', 'Fondos, menús y efecto Fantasía', 'ajustes_apariencia.png'),
    Categoria('accesibilidad', 'Accesibilidad', 'Colores, negrita y símbolos', 'ajustes_accesibilidad.png'),
    Categoria('cine', 'Modo Cine', 'Películas y series: filas, vista y tráiler', 'ajustes_cine.png'),
    Categoria('tv', 'TV e IPTV', 'TV en directo: motor TDT, caché y HyperXStream', 'ajustes_tv.png'),
    Categoria('grabacion', 'Grabación TDT', 'Carpeta, programación y grabación en curso', 'ajustes_grabacion.png'),
    Categoria('busqueda', 'Búsqueda', 'Cómo buscar y dónde buscar', 'ajustes_busqueda.png'),
    Categoria('dm_yt', 'Vídeo online', 'Dailymotion y YouTube: listas, filtros y reproductor', 'ajustes_dm_yt.png'),
    Categoria('descargas', 'Descargas', 'Carpeta y modo de descarga', 'ajustes_descargas.png'),
    Categoria('mando', 'Mando Web', 'Conexión remota: puerto, seguridad y EspaMando', 'ajustes_mando.png'),
    Categoria('debrid', 'Debrid y claves', 'Cuenta Debrid, comportamiento y claves API', 'ajustes_debrid.png'),
    Categoria('rendimiento', 'Rendimiento', 'Listas, memoria, posición y cachés', 'ajustes_rendimiento.png'),
    Categoria('juegos', 'Juegos y tests', 'Minijuegos y Tests DGT', 'ajustes_juegos.png'),
    Categoria('copias', 'Copias', 'Copias de seguridad del addon y de favoritos', 'ajustes_copias.png'),
    Categoria('mantenimiento', 'Mantenimiento', 'Diagnóstico: debug, log, novedades y restaurar', 'ajustes_mantenimiento.png'),
]

# Todos los ids visibles de settings.xml, en el orden en que se pintan dentro de su categoría.
# Lo que no esté aquí conserva su categoría nativa (y entonces el test de cobertura lo delata).
MAPA_NATIVO = {
    'inicio_destino': 'inicio',
    'cinema_mode_auto': 'inicio',
    'autostart_1_enabled': 'inicio',
    'autostart_1_delay': 'inicio',
    'autostart_2_enabled': 'inicio',
    'autostart_2_delay': 'inicio',
    'autostart_3_enabled': 'inicio',
    'autostart_3_delay': 'inicio',
    'autofav_1_enabled': 'inicio',
    'autofav_1_delay': 'inicio',
    'autofav_2_enabled': 'inicio',
    'autofav_2_delay': 'inicio',
    'autofav_3_enabled': 'inicio',
    'autofav_3_delay': 'inicio',
    'menu_colors_enabled': 'apariencia',
    'menu_customize_btn': 'apariencia',
    'menu_hidden_btn': 'apariencia',
    'menu_reset_btn': 'apariencia',
    'espakodi_lista_clasica': 'apariencia',
    'fantasia_nivel': 'apariencia',
    'fantasia_sonidos': 'apariencia',
    'fantasia_fps': 'apariencia',
    'crt_enabled': 'apariencia',
    'crt_scanlines': 'apariencia',
    'crt_vignette': 'apariencia',
    'crt_bezel': 'apariencia',
    'crt_sepia': 'apariencia',
    'crt_grain': 'apariencia',
    'crt_rollbar': 'apariencia',
    'crt_flicker': 'apariencia',
    'pelis_grid_mode': 'cine',
    'flix_rows_cfg': 'cine',
    'flix_trailer_cfg': 'cine',
    'use_inputstream': 'tv',
    'acestream_ui_mode': 'tv',
    'fuentes_formato': 'tv',
    'fuentes_mosaicos': 'tv',
    'fuentes_espanol_primero': 'tv',
    'fuentes_solo_espanol': 'tv',
    'fuentes_ua': 'tv',
    'fuentes_cache_ttl': 'tv',
    'fuentes_remoto_activo': 'tv',
    'record_path': 'grabacion',
    'record_delay': 'grabacion',
    'record_timer': 'grabacion',
    'record_quality': 'grabacion',
    'record_format': 'grabacion',
    'stop_record': 'grabacion',
    'search_input_default': 'busqueda',
    'dm_filtrar_retirados': 'dm_yt',
    'dm_ocultar_privados': 'dm_yt',
    'dm_ocultar_directos_apagados': 'dm_yt',
    'dm_rellenar_listas': 'dm_yt',
    'dm_exigir_numero': 'dm_yt',
    'dm_exigir_palabras': 'dm_yt',
    'dm_min_duracion': 'dm_yt',
    'dm_max_quality': 'dm_yt',
    'yt_player_mode': 'dm_yt',
    'remote_port': 'mando',
    'remote_secure': 'mando',
    'webremote_mode': 'mando',
    'webremote_confirm': 'mando',
    'webremote_server': 'mando',
    'webremote_topic': 'mando',
    'espamando_vincular': 'mando',
    'espamando_puerto': 'mando',
    'espamando_olvidar': 'mando',
    'espamando_quitar': 'mando',
    'modo_ligero_sin_lag': 'rendimiento',
    'remember_list_position': 'rendimiento',
    'juegos_separadores': 'juegos',
    'juegos_dificultad': 'juegos',
    'juegos_mostrar_rendimiento': 'juegos',
    'juegos_mandos_tactiles': 'juegos',
    'juegos_sensibilidad_tactil': 'juegos',
    'juegos_mandos_grandes': 'juegos',
    'juegos_disparo_automatico': 'juegos',
    'juegos_borrar_record': 'juegos',
    'dgt_modo': 'juegos',
    'dgt_imagenes': 'juegos',
}

# Acción de advanced_menu que ya queda representada por una entrada del registro. Se usa en el
# test de cobertura: ninguna acción del menú Opciones puede quedarse sin sitio en el Modo Ajustes.
EQUIVALENCIAS_CORE = {
    'toggle_force_white_text': ('acc_color_mode',),
    'toggle_advanced_search': ('busqueda_avanzada',),
    'toggle_espadaily_integration': ('espadaily',),
    'toggle_topzilla_integration': ('topzilla',),
    'toggle_tmdbhelper_player': ('tmdbhelper_player',),
    'set_search_input_method': ('search_input_default',),
    'toggle_iptv_anti_errors': ('iptv_anti_errors',),
    'toggle_debug': ('debug_mode',),
    'toggle_dev_mode': ('dev_mode',),
    'toggle_prioritize_match': ('priorizar_coincidencias',),
    'toggle_recent': ('mostrar_recientes',),
    'toggle_cinema_auto': ('cinema_mode_auto',),
    'toggle_flix_lazy_load': ('flix_lazy',),
    'toggle_flix_remember_pos': ('flix_remember_pos',),
    'set_pelis_grid_mode': ('pelis_grid_mode',),
    'set_acestream_ui_mode': ('acestream_ui_mode',),
    'set_min_duration': ('dm_min_duracion',),
    'set_download_path': ('carpeta_descargas',),
    'set_dm_safe_level': ('dm_safe_level',),
    'toggle_dm_ajuste': ('dm_exigir_numero', 'dm_exigir_palabras'),
    'set_dm_max_quality': ('dm_max_quality',),
    'set_dl_mode': ('modo_descarga',),
    'toggle_iptv_cache': ('iptv_cache_enabled',),
    'set_iptv_cache_ttl': ('iptv_cache_ttl',),
    'reset_iptv_cache': ('reset_iptv_cache',),
    'toggle_remember_position': ('remember_list_position',),
    'toggle_modo_ligero': ('modo_ligero_sin_lag',),
    'toggle_espakodi_lista_clasica': ('espakodi_lista_clasica',),
    'toggle_inputstream': ('use_inputstream',),
    'set_yt_player_mode': ('yt_player_mode',),
    'toggle_remote_secure': ('remote_secure',),
}

# Filas que solo se cambian con OK porque el cambio abre un diálogo, instala algo o borra ficheros.
# Con flechas no se tocan (una pasada accidental por la lista no rompe nada).
_CONFIRMAR_NATIVOS = ('use_inputstream', 'stop_record', 'crt_enabled')
_PROTEGIDOS_NATIVOS = ('menu_customize_btn', 'menu_hidden_btn', 'menu_reset_btn',
                       'flix_rows_cfg', 'flix_trailer_cfg')

# Acción del menú Opciones que ejecuta la fila con OK cuando la entrada lleva confirmar=True.
_HOOK_AL_CONFIRMAR = {
    'use_inputstream': 'toggle_inputstream',
    'iptv_cache_enabled': 'toggle_iptv_cache',
    'reset_iptv_cache': 'reset_iptv_cache',
    'debug_mode': 'toggle_debug',
    'clear_cache': 'clear_cache',
}

# Ganchos que no salen de ninguna entrada concreta (se construyen sobre la marcha).
_HOOKS_FIJOS = ('acc_leer', 'acc_escribir', 'storage_tamanos', 'storage_borrar',
                'ejecutar_accion')

_DIALOGOS = frozenset({
    'configure_cinema_rows', 'trailer_config', 'customize_menu_screen', 'ytdlp_menu',
    'debrid_authorize_pin', 'debrid_authorize_key', 'debrid_account', 'debrid_set_provider',
    'debrid_toggle_enabled', 'set_download_path', 'set_dl_mode', 'set_dm_safe_level',
    'config_remote_port', 'manage_custom_fanart', 'manage_custom_icon', 'inicio_elegir', 'autostart_config_slot',
    'autofav_config_slot', 'create_backup_full', 'import_backup', 'fav_export', 'fav_import',
    'kodi_maintenance_menu', 'kodi_config_backup', 'menu_hidden_items',
    'crt_toggle', 'crt_install_assets', 'crt_uninstall_assets',
})
_PANTALLAS = frozenset({
    'log_menu', 'search_shortcuts_menu', 'espamando_menu', 'minijuegos_menu', 'fantasia',
    'open_pvr', 'novedades', 'check_repo_status', 'open_settings', 'list_backups',
    'crt_config_menu',
})


def _run(accion):
    return 'RunPlugin(plugin://plugin.video.espatv/?action={0})'.format(accion)


def _carpeta(accion):
    # Una carpeta de plugin lanzada con RunPlugin no se dibuja: hay que abrir la lista de vídeos.
    return 'ActivateWindow(Videos,plugin://plugin.video.espatv/?action={0},return)'.format(accion)


def _core_leer(nombre):
    def _leer():
        import core_settings
        return getattr(core_settings, nombre)()
    return _leer


def _core_escribir(nombre):
    def _escribir(valor):
        import core_settings
        getattr(core_settings, nombre)(valor)
    return _escribir


def _leer_ttl():
    """La duración de la caché IPTV como etiqueta, que es lo que enseña la fila."""
    import core_settings
    ttl = core_settings.get_iptv_cache_ttl()
    for segundos, nombre in core_settings._IPTV_CACHE_TTL_OPTIONS:
        if segundos == ttl:
            return nombre
    return 'Desactivada'


def _escribir_ttl(nombre):
    import core_settings
    for segundos, etiqueta in core_settings._IPTV_CACHE_TTL_OPTIONS:
        if etiqueta == nombre:
            core_settings.set_iptv_cache_ttl(segundos)
            return


def _escribir_tmdbhelper_player(valor):
    import core_settings
    import tmdbhelper_player
    core_settings.set_tmdbhelper_player_enabled(bool(valor))
    tmdbhelper_player.sync(bool(valor))


# Lo mismo que default._toggle_dev_mode: el modo desarrollador es un fichero .dev_mode en la
# carpeta del addon. Las lambdas de la entrada lo buscan aquí en cada llamada (los tests lo cambian).
_DEV_FLAG = os.path.join(os.path.dirname(os.path.abspath(__file__)), '.dev_mode')


def _leer_dev_mode():
    return os.path.exists(_DEV_FLAG)


def _escribir_dev_mode(valor):
    if valor:
        with open(_DEV_FLAG, 'w') as f:
            f.write('dev')
    elif os.path.exists(_DEV_FLAG):
        os.remove(_DEV_FLAG)


def _entrada(ident, categoria, rotulo, tipo, **kw):
    return Entrada(ident, categoria, rotulo, tipo, origen='opciones', **kw)


ENTRADAS_OPCIONES = [
    # Inicio
    _entrada('autostart_config_slot_1', 'inicio', 'Elegir addon 1…', 'action',
             accion=('autostart_config_slot', 1), clase_accion='dialogo',
             ayuda='Elige qué addon de Kodi se abre solo al arrancar.'),
    _entrada('autostart_config_slot_2', 'inicio', 'Elegir addon 2…', 'action',
             accion=('autostart_config_slot', 2), clase_accion='dialogo'),
    _entrada('autostart_config_slot_3', 'inicio', 'Elegir addon 3…', 'action',
             accion=('autostart_config_slot', 3), clase_accion='dialogo'),
    _entrada('autofav_config_slot_1', 'inicio', 'Elegir favorito 1…', 'action',
             accion=('autofav_config_slot', 1), clase_accion='dialogo',
             ayuda='Elige un favorito de Kodi para abrirlo solo al arrancar.'),
    _entrada('autofav_config_slot_2', 'inicio', 'Elegir favorito 2…', 'action',
             accion=('autofav_config_slot', 2), clase_accion='dialogo'),
    _entrada('autofav_config_slot_3', 'inicio', 'Elegir favorito 3…', 'action',
             accion=('autofav_config_slot', 3), clase_accion='dialogo'),

    # Apariencia
    _entrada('manage_custom_fanart', 'apariencia', 'Fanart de fondo personalizado…', 'action',
             accion=_run('manage_custom_fanart'), clase_accion='dialogo', protegido=True,
             ayuda='Elige tu propia imagen de fondo, vuelve a la predeterminada u oculta el fondo.'),
    _entrada('manage_custom_icon', 'apariencia', 'Logo del Addon personalizado…', 'action',
             accion=_run('manage_custom_icon'), clase_accion='dialogo', protegido=True,
             ayuda='Cambia el icono del addon por un PNG cuadrado (256-1024 px, 8 bits) o restaura el original.'),
    _entrada('crt_config_menu', 'apariencia', 'Filtro CRT Vintage (capas y texturas)…', 'action',
             accion=_carpeta('crt_config_menu'), clase_accion='pantalla',
             ayuda='Abre el menú para activar el modo TV de tubo, instalar sus texturas (~850 KB) y elegir sus 7 capas.'),
    _entrada('crt_install_assets', 'apariencia', 'Instalar texturas del Filtro CRT…', 'action',
             accion=_run('crt_install_assets'), clase_accion='dialogo', protegido=True,
             ayuda='Descarga e instala en tu perfil las texturas (~850 KB) del Filtro CRT Vintage.'),
    _entrada('crt_uninstall_assets', 'apariencia', 'Desinstalar texturas del Filtro CRT…', 'action',
             accion=_run('crt_uninstall_assets'), clase_accion='dialogo',
             destructivo=True, confirmar=True, protegido=True,
             ayuda='Elimina las texturas CRT descargadas de tu carpeta de perfil para liberar espacio y apaga el filtro.'),
    _entrada('fantasia', 'apariencia', 'Probar el Modo Fantasía', 'action',
             accion=_run('fantasia'), clase_accion='pantalla',
             ayuda='Abre el Modo Fantasía para ver los efectos en marcha. Se sale con Atrás.'),

    # Accesibilidad
    _entrada('acc_color_mode', 'accesibilidad', 'Modo de color', 'enum',
             opciones=('Sin modificar (colores originales)',
                       'Texto blanco (todos los colores → blanco)',
                       'Daltónico rojo-verde (deuteranopia/protanopia)',
                       'Daltónico azul-amarillo (tritanopia)',
                       'Alto contraste, fondo oscuro (amarillo)',
                       'Alto contraste, fondo claro (negro)'),
             defecto='Sin modificar (colores originales)',
             leer_gancho='acc_leer', escribir_gancho='acc_escribir',
             ayuda='Modos de color para daltonismo y baja visión. El acento cielo mantiene el '
                   'contraste en los tres modos.'),
    _entrada('acc_force_bold', 'accesibilidad', 'Texto en negrita', 'bool', defecto=True,
             leer_gancho='acc_leer', escribir_gancho='acc_escribir',
             ayuda='Pone en negrita los rótulos del addon para leerlos mejor a distancia.'),
    _entrada('acc_strip_symbols', 'accesibilidad', 'Sustituir símbolos por texto', 'bool',
             defecto=False, leer_gancho='acc_leer', escribir_gancho='acc_escribir',
             ayuda='Cambia ‹ › y ● por texto, para cuando los símbolos no se distinguen bien.'),

    # Búsqueda
    _entrada('busqueda_avanzada', 'busqueda', 'Búsqueda avanzada', 'bool', defecto=True,
             leer=_core_leer('is_advanced_search_active'),
             escribir=_core_escribir('set_advanced_search_active'),
             ayuda='Al pulsar «Buscar manualmente» abre un menú intermedio con opciones de '
                   'búsqueda especializada (Cine, Exacta, etc.) en vez del teclado directo.'),
    _entrada('search_shortcuts_menu', 'busqueda', 'Atajos de «¿Dónde buscar?»', 'action',
             accion=_carpeta('search_shortcuts_menu'), clase_accion='pantalla',
             ayuda='Añade atajos y reordena u oculta las opciones del menú «¿Dónde quieres '
                   'buscar?». Abre una pantalla aparte; vuelve con Atrás hasta Opciones.'),
    _entrada('espadaily', 'busqueda', 'Buscar también en EspaDaily', 'bool', defecto=False,
             cabecera='Integraciones', protegido=True,
             leer=_core_leer('is_espadaily_integration_enabled'),
             escribir=_core_escribir('set_espadaily_integration_enabled'),
             ayuda='Añade «Buscar en EspaDaily» al menú de búsqueda. EspaDaily y EspaTV '
                   'comparten origen: si uno falla, el otro puede funcionar.'),
    _entrada('topzilla', 'busqueda', 'Buscar también en Topzilla', 'bool', defecto=False,
             cabecera='Integraciones', protegido=True,
             leer=_core_leer('is_topzilla_integration_enabled'),
             escribir=_core_escribir('set_topzilla_integration_enabled'),
             ayuda='Añade «Buscar en TopZilla» al menú de búsqueda: buscar, filtrar y consultar '
                   'fichas de películas y series.'),
    _entrada('tmdbhelper_player', 'busqueda', 'Buscar en EspaTV desde TMDB Helper', 'bool', defecto=True,
             cabecera='Integraciones', protegido=True,
             leer=_core_leer('is_tmdbhelper_player_enabled'),
             escribir=_escribir_tmdbhelper_player,
             ayuda='Registra «Buscar en EspaTV» como reproductor en TMDB Helper para abrir el diálogo '
                   'de búsqueda (incluida la búsqueda en Debrid) desde sus fichas.'),

    # TV en directo e IPTV
    _entrada('iptv_anti_errors', 'tv', 'Anti-errores IPTV', 'bool', defecto=False,
             ayuda='Si un canal da «Playback failed», este modo lo reintenta de otra forma.'),
    _entrada('iptv_cache_enabled', 'tv', 'Activar la caché IPTV', 'bool', defecto=False,
             cabecera='Caché IPTV', confirmar=True,
             leer=_core_leer('is_iptv_cache_active'),
             escribir=_core_escribir('set_iptv_cache_active'),
             ayuda='Guarda en disco los canales (M3U, TDT) para que al volver con Atrás carguen '
                   'al instante. Desactivarla borra los ficheros guardados.'),
    _entrada('iptv_cache_ttl', 'tv', 'Cuánto se guarda', 'enum', cabecera='Caché IPTV',
             opciones=('Desactivada', '1 hora', '12 horas', '1 día', '1 semana'),
             defecto='12 horas', depende_de=('iptv_cache_enabled', True),
             leer=_leer_ttl, escribir=_escribir_ttl,
             ayuda='Tiempo que se mantienen guardados los canales antes de volver a descargarlos.'),
    _entrada('reset_iptv_cache', 'tv', 'Restaurar caché por defecto', 'action',
             cabecera='Caché IPTV', destructivo=True, confirmar=True,
             accion=_run('reset_iptv_cache'), clase_accion='builtin',
             ayuda='Desactiva la caché IPTV y borra todos los ficheros guardados.'),
    _entrada('open_pvr', 'tv', 'Abrir guía de TV de Kodi', 'action', cabecera='Guía nativa (PVR)',
             accion=_run('open_pvr'), clase_accion='pantalla',
             ayuda='Abre la sección TV de Kodi para consultar la programación.'),
    _entrada('setup_pvr', 'tv', 'Auto-configurar IPTV Simple Client', 'action',
             cabecera='Guía nativa (PVR)', accion=_run('setup_pvr'), clase_accion='builtin',
             ayuda='Vincula la programación TDT con la sección TV de Kodi sin alterar otras listas.'),

    # Dailymotion y YouTube
    _entrada('dm_safe_level', 'dm_yt', 'Nivel de contenido seguro', 'action',
             accion=_run('set_dm_safe_level'), clase_accion='dialogo',
             ayuda='Ajusta cómo se conecta el addon con Dailymotion: normal, móvil, extremo o yt-dlp.'),
    _entrada('flix_lazy', 'cine', 'Carga perezosa de carátulas', 'bool', defecto=False,
             leer=_core_leer('is_flix_lazy_enabled'),
             escribir=_core_escribir('set_flix_lazy_enabled'),
             ayuda='El Modo Cine carga las primeras filas y el resto al hacer scroll. Útil con '
                   'dispositivos lentos o muchas filas activas.'),
    _entrada('flix_remember_pos', 'cine', 'Recordar posición en el Modo Cine', 'bool', defecto=True,
             leer=_core_leer('is_flix_remember_pos_enabled'),
             escribir=_core_escribir('set_flix_remember_pos_enabled'),
             ayuda='Al reabrir el Modo Cine vuelves al modo, la fila y la película donde estabas.'),
    _entrada('priorizar_coincidencias', 'cine', 'Priorizar coincidencias exactas', 'bool',
             defecto=False,
             leer=_core_leer('is_prioritize_match_active'),
             escribir=_core_escribir('set_prioritize_match'),
             ayuda='Ordena los resultados por parecido con lo buscado en vez de por duración.'),
    _entrada('mostrar_recientes', 'cine', 'Mostrar «Recientes»', 'bool', defecto=False,
             leer=_core_leer('is_recent_active'), escribir=_core_escribir('set_recent_active'),
             ayuda='Ordena los vídeos por fecha de subida, para informativos y programas diarios.'),

    # Descargas
    _entrada('carpeta_descargas', 'descargas', 'Carpeta de descargas', 'action',
             accion=_run('set_download_path'), clase_accion='dialogo',
             ayuda='Carpeta donde se guardan los vídeos descargados.'),
    _entrada('modo_descarga', 'descargas', 'Modo de descarga', 'action',
             accion=_run('set_dl_mode'), clase_accion='dialogo',
             ayuda='Directo, Safe Mode, por segmentos HLS o con yt-dlp.'),
    _entrada('ytdlp_menu', 'descargas', 'yt-dlp en el PC: instrucciones y diagnóstico', 'action',
             accion=_run('ytdlp_menu'), clase_accion='dialogo',
             ayuda='Instrucciones para instalar yt-dlp en el ordenador y comprobar si funciona.'),

    # Mando Web y conexión remota
    _entrada('reset_webremote_topic', 'mando', 'Regenerar canal del relay', 'action',
             accion=_run('reset_webremote_topic'), clase_accion='builtin',
             depende_de=('webremote_mode', 'Internet'),
             ayuda='Genera un canal nuevo para el relay de Internet. Los móviles vinculados '
                   'tendrán que volver a escanear el QR.'),
    _entrada('espamando_menu', 'mando', 'Abrir EspaMando', 'action',
             accion=_carpeta('espamando_menu'), clase_accion='pantalla',
             ayuda='Control remoto completo desde el móvil. Abre una pantalla aparte; vuelve con '
                   'Atrás hasta Opciones.'),

    # Debrid y claves API
    # Interruptor con OK obligatorio: al activarlo la primera vez sale el aviso de uso responsable
    # de _debrid_toggle_enabled, así que el cambio pasa por esa acción y no por setSetting.
    _entrada('debrid_enabled', 'debrid', 'Resolver Debrid activado', 'bool', defecto=False,
             confirmar=True, protegido=True,
             accion=_run('debrid_toggle_enabled'), clase_accion='dialogo',
             ayuda='Activa el Resolver Debrid, que convierte los enlaces en descargas directas.'),
    _entrada('debrid_set_provider', 'debrid', 'Proveedor', 'action',
             accion=_run('debrid_set_provider'), clase_accion='dialogo',
             ayuda='AllDebrid, Real-Debrid, TorBox, Premiumize u Offcloud.'),
    _entrada('debrid_authorize_pin', 'debrid', 'Autorizar con PIN', 'action',
             cabecera='Cuenta', accion=_run('debrid_authorize_pin'), clase_accion='dialogo',
             ayuda='Vincula la cuenta mostrando un PIN en la web del proveedor.'),
    _entrada('debrid_authorize_key', 'debrid', 'Autorizar con clave', 'action',
             cabecera='Cuenta', accion=_run('debrid_authorize_key'), clase_accion='dialogo',
             ayuda='Vincula la cuenta pegando la clave de la API del proveedor.'),
    _entrada('debrid_account', 'debrid', 'Ver cuenta', 'action',
             cabecera='Cuenta', accion=_run('debrid_account'), clase_accion='dialogo',
             ayuda='Estado de la cuenta y días de suscripción que quedan.'),
    _entrada('debrid_deauthorize', 'debrid', 'Desvincular la cuenta', 'action',
             cabecera='Cuenta', accion=_run('debrid_deauthorize'), clase_accion='dialogo',
             destructivo=True, confirmar=True, protegido=True,
             ayuda='Desvincula la cuenta Debrid de este dispositivo. Volver a usarla exige '
                   'autorizarla otra vez.'),
    # Interruptores normales: el id es el del ajuste oculto de settings.xml, que es lo que
    # alternan debrid_toggle_cached/cleanup/quality en el menú Debrid.
    _entrada('debrid_cached_only', 'debrid', 'Solo enlaces en caché', 'bool', defecto=False,
             cabecera='Comportamiento',
             ayuda='Solo ofrece enlaces que ya están listos en el proveedor.'),
    _entrada('debrid_auto_cleanup', 'debrid', 'Limpieza automática', 'bool', defecto=True,
             cabecera='Comportamiento',
             ayuda='Borra del proveedor las descargas de las últimas horas.'),
    _entrada('debrid_auto_quality', 'debrid', 'Calidad automática', 'bool', defecto=True,
             cabecera='Comportamiento',
             ayuda='Elige la mejor calidad disponible sin preguntar.'),
    _entrada('debrid_torrentio_enabled', 'debrid', 'Torrentio', 'bool', defecto=False,
             cabecera='Comportamiento',
             ayuda='Añade resultados de Torrentio al Resolver Debrid.'),
    _entrada('tmdb_user_key', 'debrid', 'Clave TMDB propia', 'text', secreto=True, protegido=True,
             cabecera='Claves API', defecto='',
             leer=_core_leer('get_tmdb_user_key'), escribir=_core_escribir('set_tmdb_user_key'),
             ayuda='Tu clave personal de TMDB tiene prioridad sobre las claves incluidas en el addon.'),
    _entrada('mdblist_api_key', 'debrid', 'Clave MDbList propia', 'text', secreto=True,
             protegido=True, cabecera='Claves API', defecto='',
             leer=_core_leer('get_mdblist_api_key'), escribir=_core_escribir('set_mdblist_api_key'),
             ayuda='Tu clave personal de MDbList para las listas y valoraciones.'),

    # Rendimiento y listas
    _entrada('clear_cache', 'rendimiento', 'Borrar toda la caché', 'action',
             destructivo=True, confirmar=True, accion=_run('clear_cache'),
             clase_accion='builtin',
             ayuda='Elimina datos temporales de canales, historial de red y caché IPTV. No borra '
                   'tus listas ni tu configuración.'),

    # Juegos y tests
    _entrada('minijuegos_menu', 'juegos', 'Ir a Minijuegos', 'action',
             accion=_carpeta('minijuegos_menu'), clase_accion='pantalla',
             ayuda='Ajustes de los catorce minijuegos. Abre una pantalla aparte; vuelve con Atrás.'),

    # Copias de seguridad
    _entrada('backup_crear', 'copias', 'Crear copia…', 'action',
             accion=_run('create_backup_full'), clase_accion='dialogo', protegido=True,
             ayuda='Crea un ZIP con los datos del addon: historial, favoritos, configuración y más.'),
    _entrada('backup_restaurar', 'copias', 'Restaurar copia…', 'action',
             accion=_carpeta('list_backups'), clase_accion='pantalla', protegido=True,
             ayuda='Lista las copias creadas y permite restaurar solo lo que elijas.'),
    _entrada('backup_importar', 'copias', 'Importar copia…', 'action',
             accion=_run('import_backup'), clase_accion='dialogo', protegido=True,
             ayuda='Importa un ZIP de otra instalación, eligiendo qué datos restaurar.'),
    _entrada('fav_export', 'copias', 'Exportar favoritos…', 'action',
             accion=_run('fav_export'), clase_accion='dialogo', protegido=True,
             ayuda='Guarda tus favoritos en un fichero para llevarlos a otro dispositivo.'),
    _entrada('fav_import', 'copias', 'Importar favoritos…', 'action',
             accion=_run('fav_import'), clase_accion='dialogo', protegido=True,
             ayuda='Recupera los favoritos de un fichero exportado.'),
    _entrada('kodi_config_backup', 'copias', 'Copia de configuración de Kodi…', 'action',
             accion=_run('kodi_config_backup'), clase_accion='dialogo', protegido=True,
             ayuda='Guarda y restaura la configuración global de Kodi (guisettings, fuentes y favoritos de Kodi, sin contraseñas). Crea copia automática previa antes de restaurar.'),

    # Mantenimiento y diagnóstico
    _entrada('debug_mode', 'mantenimiento', 'Modo Debug', 'bool', defecto=False, confirmar=True,
             leer=_core_leer('is_debug_active'), escribir=_core_escribir('set_debug_active'),
             ayuda='Registro detallado de errores. Puede ralentizar el addon.'),
    _entrada('dev_mode', 'mantenimiento', 'Modo desarrollador', 'bool', defecto=False,
             leer=lambda: _leer_dev_mode(), escribir=lambda valor: _escribir_dev_mode(valor),
             ayuda='Protege los módulos internos: el addon no se actualiza desde internet.'),
    _entrada('log_menu', 'mantenimiento', 'Log y diagnóstico', 'action',
             accion=_carpeta('log_menu'), clase_accion='pantalla',
             ayuda='Ver y analizar el log de Kodi y del addon. Abre una pantalla aparte.'),
    _entrada('open_settings', 'mantenimiento', 'Ajustes clásicos de Kodi', 'action',
             accion=_run('open_settings'), clase_accion='pantalla',
             ayuda='Abre el diálogo de ajustes nativo del addon.'),
    _entrada('novedades', 'mantenimiento', 'Acerca de EspaTV: novedades', 'action',
             accion=_run('novedades'), clase_accion='pantalla',
             ayuda='Qué trae la versión instalada y qué se ha cambiado.'),
    _entrada('check_repo_status', 'mantenimiento', 'Estado del repositorio', 'action',
             accion=_run('check_repo_status'), clase_accion='pantalla',
             ayuda='Comprueba que el repositorio del addon responde.'),
    _entrada('kodi_maintenance_menu', 'mantenimiento', 'Mantenimiento del sistema Kodi…', 'action',
             accion=_run('kodi_maintenance_menu'), clase_accion='dialogo', protegido=True,
             ayuda='Limpia paquetes .zip, temporales de addons, registros de fallos (sin tocar kodi.log), caché de ResolveURL y miniaturas en desuso; revisa y compacta las bases de datos y respalda la configuración de Kodi.'),
    _entrada('restaurar_todo', 'mantenimiento', 'Restaurar todos los ajustes de serie', 'action',
             destructivo=True, confirmar=True, protegido=False,
             ayuda='Devuelve a su valor de fábrica los ajustes simples. No toca favoritos, '
                   'historial, copias, claves, tokens ni la personalización de menús.'),
]

# Textos que settings.xml no trae, copiados de los submenús de Opciones, de la ficha de cada botón
# o del diálogo que abre el propio ajuste. Lo que no tiene texto en el addon se queda sin ayuda.
AYUDAS = {
    # Ajustes sin texto previo en el addon (pvr_recorder_manager.py y relay).
    'record_delay': 'Cuánto espera EspaTV antes de empezar a grabar después de pulsar «Grabar». '
                    'Con «Ahora» empieza en el momento.',
    'record_timer': 'La grabación se detiene sola al llegar a este tiempo. Con «Sin límite» sigue '
                    'hasta que la detengas.',
    'record_quality': 'Si el canal emite en varias calidades, se graba la mejor que no pase de esta. '
                      'Menos calidad ocupa menos disco.',
    'stop_record': 'Termina todas las grabaciones de TDT que están en marcha en segundo plano. '
                   'Antes pide confirmación.',
    'webremote_topic': 'Canal del relay por el que el mando web manda las URL a este Kodi. Si lo '
                       'dejas vacío, EspaTV crea uno la primera vez. Quien conozca el canal puede '
                       'mandar URL a tu Kodi, así que no lo compartas.',
    # Inicio automático
    'cinema_mode_auto': 'Al abrir una categoría de YouTube se abre directamente el Modo Cine '
                        'en vez de mostrar el menú habitual.',
    'autostart_1_enabled': 'Un addon que se abrirá automáticamente al arrancar Kodi.',
    'autostart_1_delay': 'Retardo antes de lanzar.',
    'autostart_2_enabled': 'Un addon que se abrirá automáticamente al arrancar Kodi.',
    'autostart_2_delay': 'Retardo antes de lanzar.',
    'autostart_3_enabled': 'Un addon que se abrirá automáticamente al arrancar Kodi.',
    'autostart_3_delay': 'Retardo antes de lanzar.',
    'autostart_config_slot_2': 'Elige qué addon de Kodi se abre solo al arrancar.',
    'autostart_config_slot_3': 'Elige qué addon de Kodi se abre solo al arrancar.',
    'autofav_1_enabled': 'Un favorito de Kodi que se abrirá automáticamente al arrancar.',
    'autofav_1_delay': 'Retardo antes de lanzar.',
    'autofav_2_enabled': 'Un favorito de Kodi que se abrirá automáticamente al arrancar.',
    'autofav_2_delay': 'Retardo antes de lanzar.',
    'autofav_3_enabled': 'Un favorito de Kodi que se abrirá automáticamente al arrancar.',
    'autofav_3_delay': 'Retardo antes de lanzar.',
    'autofav_config_slot_2': 'Elige un favorito de Kodi para abrirlo solo al arrancar.',
    'autofav_config_slot_3': 'Elige un favorito de Kodi para abrirlo solo al arrancar.',
    # Apariencia
    'menu_hidden_btn': 'Consulta y vuelve a activar los elementos que has ocultado del menú '
                       'principal o de «Más».',
    'menu_reset_btn': 'Devuelve el menú principal y el catálogo a su estado original '
                      '(orden y visibilidad).',
    'espakodi_lista_clasica': 'Convierte las secciones de EspaKodi con ventana propia en carpetas '
                              'estándar de Kodi. Recomendado si usas un skin de terceros donde '
                              'las ventanas emergentes no se adaptan bien a tu pantalla.',
    'fantasia_nivel': 'Intensidad de los efectos visuales, rotaciones 3D, halos y reflejos del '
                      'Modo Fantasía.\n\nSuave: menos efectos, pensado para dispositivos modestos.\n'
                      'Normal: efectos equilibrados.\nMáximo: todas las partículas y animaciones.',
    'fantasia_sonidos': 'Sonidos al navegar y seleccionar elementos en el Modo Fantasía.',
    'fantasia_fps': 'Muestra el contador de fotogramas por segundo en pantalla durante el Modo '
                    'Fantasía para verificar el rendimiento.',
    'crt_enabled': 'Activa el filtro de televisión de tubo (CRT) sobre los vídeos en '
                   'reproducción. Si faltan las texturas (~850 KB), ofrece '
                   'descargarlas y respeta el Modo ligero / Sin lag.',
    'crt_scanlines': 'Líneas horizontales finas, típicas de una tele de tubo.',
    'crt_vignette': 'Oscurece las esquinas para imitar el brillo desigual del tubo.',
    'crt_bezel': 'Marco oscuro con esquinas redondeadas que simula la curvatura de la pantalla.',
    'crt_sepia': 'Da un tono ámbar cálido a la imagen, como el fósforo de las pantallas viejas.',
    'crt_grain': 'Ruido animado superpuesto, como la nieve de una señal débil de antena. '
                 'Se desactiva por defecto en Modo ligero / Sin lag.',
    'crt_rollbar': 'Banda de luz tenue que recorre la pantalla de arriba abajo.',
    'crt_flicker': 'Leve parpadeo del brillo, como el barrido inestable de un tubo antiguo. '
                   'Se desactiva por defecto en Modo ligero / Sin lag.',
    # TV e IPTV
    'use_inputstream': 'Usa el motor InputStream de Kodi para M3U8: mejora la reconexión de red '
                       'y permite pausar el directo (TimeShift).',
    'fuentes_formato': 'Formato para emitir canales en directo (HLS m3u8 o TS nativo).\n\n'
                       'Automático: usa lo que recomiende el servidor.\n'
                       'HLS (m3u8): recomendado si los streams TS sufren cortes o '
                       'desincronización de audio en Android TV.\n'
                       'TS nativo: contenedor directo sin transcodificar.',
    'fuentes_mosaicos': 'Muestra carátulas e iconos en los listados de canales de tus '
                        'proveedores.\n\nDesactívalo en conexiones lentas o con miles de canales '
                        'para navegar mucho más rápido.',
    'fuentes_espanol_primero': 'Ordena los canales poniendo los identificados en español al '
                               'principio de cada categoría.',
    'fuentes_solo_espanol': 'Oculta automáticamente cualquier canal que no parezca en español en '
                            'las listas de tus servidores.',
    'fuentes_ua': 'Identidad (User-Agent) que envía el addon para conectar con tus proveedores. '
                  'Simula navegadores habituales o reproductores multimedia para evitar bloqueos '
                  'del servidor.',
    'fuentes_cache_ttl': 'Cuánto tiempo se reutiliza lo ya descargado de cada servidor (se guarda '
                         'en el perfil del addon) antes de volver a pedirlo.',
    'fuentes_remoto_activo': 'Permite o bloquea la importación y sincronización de servidores '
                             'desde una URL remota.\n\nApagado por seguridad para evitar que una '
                             'URL descargue credenciales sin tu consentimiento.',
    # Grabación
    'record_path': 'Configura la carpeta de destino para las grabaciones PVR de IPTV y TDT.',
    'record_format': '¿Grabar en MP4 comprimido?\n\nArchivo un 50-70% más pequeño, compatible con '
                     'cualquier reproductor.',
    # Búsqueda
    'search_input_default': 'Elige cómo introducir el texto al buscar.\n\n'
                            'Teclado: usa el teclado de Kodi.\n'
                            'Desde móvil/PC: escribe desde el mando web.\n'
                            'Control remoto completo: escribe y maneja Kodi desde el móvil (hay '
                            'que vincularlo una vez con un QR).\n'
                            'Preguntar siempre: te pregunta cada vez.',
    # Dailymotion
    'dm_filtrar_retirados': 'El buscador de Dailymotion sigue devolviendo vídeos que ya han sido '
                            'retirados: aparecen en la lista y al pulsarlos no reproducen. Con '
                            'esta opción no se muestran.',
    'dm_ocultar_privados': 'Algunos vídeos salen en las búsquedas aunque su autor los ha hecho '
                           'privados, y no se pueden ver de ninguna forma. Distinguirlos cuesta '
                           'una consulta por cada uno, y suelen ser menos de 1 de cada 100 '
                           'resultados.',
    'dm_ocultar_directos_apagados': 'Un canal en directo que ahora mismo no emite no se puede '
                                    'reproducir. Desactívala si prefieres encontrar esos canales '
                                    'en las búsquedas aunque estén apagados.',
    'dm_rellenar_listas': 'Al ocultar vídeos, algunas búsquedas se quedan en 4 o 5 resultados. '
                          'Con esta opción se piden más a Dailymotion para que la lista salga '
                          'completa, en la misma consulta.',
    'dm_exigir_numero': 'Si la búsqueda lleva un número (por ejemplo «serie 5»), solo se muestran '
                        'los resultados que lo llevan en el título. Evita que el capítulo 3 tape '
                        'al 5.',
    'dm_exigir_palabras': 'Solo se muestran los resultados que llevan en el título todas las '
                          'palabras que identifican la búsqueda (se ignoran las vacías y las de '
                          'episodio).',
    'dm_min_duracion': 'Oculta automáticamente cualquier vídeo por debajo de esta duración. '
                       'Útil para quitar tráilers, clips y avances de los resultados de '
                       'búsqueda.',
    'dm_max_quality': 'Tope de calidad al reproducir vídeos de Dailymotion.\n\nEn los vídeos '
                      'verticales la calidad real la marca el lado menor. Bajarla ayuda en '
                      'conexiones lentas o aparatos que se atascan con 1080p.',
    # Mando Web y conexión remota
    'remote_port': 'Puerto inicial del servidor HTTP local para enviar URLs o texto desde el '
                   'móvil o PC.\nSi el puerto está ocupado, se prueban los 10 siguientes.',
    'remote_secure': 'Activa o desactiva la protección del mando web.\n\n'
                     'Desactivada (por defecto): cualquier dispositivo en tu red WiFi '
                     'puede acceder al mando. Pensado para casa con red de confianza.\n\n'
                     'Activada: la URL incluye un código único generado al arrancar el '
                     'mando. Sin ese código nadie puede acceder aunque esté en tu red. '
                     'Recomendado en redes públicas, hoteles o WiFi compartida.',
    'webremote_mode': 'Cómo escucha el receptor de URLs.\n\n'
                      'Red local: accesible solo en tu WiFi. Rápido y sin dependencias.\n\n'
                      'Internet (relay ntfy): usa el servidor ntfy para recibir URLs desde fuera '
                      'de casa.',
    'webremote_confirm': 'Si está activo, Kodi pregunta antes de reproducir cada URL recibida '
                         'desde el móvil o PC. Evita reproducciones accidentales.',
    'webremote_server': 'URL del servidor ntfy para el relay de Internet.\n\nPuedes usar el '
                        'público ntfy.sh o alojar el tuyo.',
    'espamando_vincular': 'Enseña un código QR en la tele. Escanéalo con la cámara del móvil, '
                          'conectado a la misma wifi, para vincularlo.\n\nSolo hace falta hacerlo '
                          'una vez por móvil.',
    'espamando_puerto': 'Cambia el puerto por el que el móvil se conecta a Kodi (normalmente '
                        '8110).\n\nSolo hace falta si otro programa de tu red ya usa ese puerto.',
    'espamando_olvidar': 'Desvincula todos los móviles y apaga el control remoto hasta que lo '
                         'vuelvas a usar.\n\nPara usarlo de nuevo tendrás que vincular otra vez '
                         'el móvil.',
    'espamando_quitar': 'Quita el control remoto completo de Kodi y olvida los móviles.\n\n'
                        'Podrás volver a instalarlo eligiéndolo al buscar.',
    # Rendimiento
    'remember_list_position': 'Algunas secciones (agenda, catálogos, clasificaciones...) no se '
                              'guardan en disco, así que al volver con ATRÁS o al cerrar un vídeo '
                              'Kodi las reconstruye desde cero y pierde el punto donde estabas.\n\n'
                              'Con esta opción activa, esas listas se guardan en disco y al volver '
                              'se restauran al instante conservando tu posición.\n\n'
                              'A cambio, el contenido puede quedar algo desactualizado hasta que '
                              'refresques (pulsa ATRÁS y vuelve a entrar).',
    # Minijuegos
    'juegos_separadores': 'Los separadores de los menús esconden un easter egg. Al pulsar uno se '
                          'ofrece uno de los catorce minijuegos al azar. Apágalo si los pulsas '
                          'sin querer.',
    'juegos_dificultad': 'Solo Normal deja los juegos exactamente como han sido siempre. Los '
                         'niveles duros aceleran, dan menos vidas o dejan menos hueco, cada juego '
                         'a su manera; 2048, Memoria y Solitario no cambian. Cada nivel guarda su '
                         'propio récord, así que una marca de Experto no compite con una de '
                         'Normal.',
    'juegos_mandos_tactiles': 'Dibuja una cruceta y un botón de acción sobre el juego para poder '
                              'jugar con los dedos. En automático salen en móviles y tabletas; '
                              'en un ordenador con pantalla táctil salen la primera vez que '
                              'deslizas el dedo.',
    'juegos_sensibilidad_tactil': 'A qué velocidad se repite una flecha mantenida en los mandos en '
                                  'pantalla. No cambia el teclado ni el mando, que repiten por su '
                                  'cuenta.',
    'juegos_mandos_grandes': 'Agranda la cruceta y el botón de acción, para pantallas pequeñas o '
                             'si te cuesta acertar. Crecen hacia el centro y se quedan anclados en '
                             'su esquina. También se cambia desde la rueda dentada sin salir de la '
                             'partida.',
    'juegos_disparo_automatico': 'En Invaders y Galaga. Kodi no dice dónde está el segundo dedo, '
                                 'así que pulsar la cruceta y el botón a la vez no se puede '
                                 'detectar, y sin esto habría que elegir entre moverse o disparar. '
                                 'Con teclado y mando no cambia nada.',
    'juegos_mostrar_rendimiento': 'Enseña cuatro números arriba a la izquierda mientras juegas: '
                                  'los pasos por segundo que da el juego y los que pedía, lo que '
                                  'tarda un paso, los fotogramas por segundo de Kodi y cuántas '
                                  'veces ha recogido basura Python. También se apuntan en '
                                  'rendimiento.log, en la carpeta minijuegos de los datos del '
                                  'addon, y ese fichero se borra en la primera partida con el '
                                  'contador apagado.',
    'juegos_borrar_record': 'Abre la lista de juegos con marca guardada, para borrar el que elijas '
                            'o todos.',
}


def _addon_por_defecto():
    import xbmcaddon
    return xbmcaddon.Addon()


def _valor_condicion(texto):
    texto = (texto or '').strip()
    if texto == 'true':
        return True
    if texto == 'false':
        return False
    try:
        return int(texto)
    except ValueError:
        return texto


def _limpiar_rotulo(texto):
    """Separa el rótulo del aviso de color: [COLOR red]Detener[/COLOR] -> ('Detener', True)."""
    rojo = re.compile(r'\[COLOR\s+(red|orange)\](.*?)\[/COLOR\]', re.IGNORECASE)
    destructivo = bool(rojo.search(texto or ''))
    return rojo.sub(r'\2', texto or ''), destructivo


def _tipo_nativo(tipo_xml, nodo):
    valores = tuple((nodo.get('values') or '').split('|')) if nodo.get('values') else ()
    rango = tuple(int(x) for x in (nodo.get('range') or '').split(',') if x.strip().isdigit())
    if tipo_xml == 'bool':
        return 'bool', False, (), ()
    if tipo_xml == 'enum':
        return 'enum', True, valores, ()
    if tipo_xml == 'labelenum':
        return 'enum', False, valores, ()
    if tipo_xml == 'slider':
        return 'slider', False, (), rango
    if tipo_xml == 'number':
        return 'number', False, (), rango
    if tipo_xml in ('text', 'folder'):
        return tipo_xml, False, (), ()
    if tipo_xml == 'action':
        return 'action', False, (), ()
    return 'clasico', False, (), ()


def _defecto_nativo(tipo, guarda_indice, crudo):
    crudo = crudo if crudo is not None else ''
    if tipo == 'bool':
        return crudo == 'true'
    if tipo == 'enum':
        if guarda_indice:
            return _valor_condicion(crudo) if crudo else 0
        return crudo
    if tipo in ('slider', 'number'):
        return int(crudo) if str(crudo).strip().isdigit() else 0
    if tipo in ('text', 'folder'):
        return crudo
    return None


def _clase_accion(accion):
    encontrado = re.search(r'action=([a-z_]+)', accion or '')
    nombre = encontrado.group(1) if encontrado else ''
    if nombre in _DIALOGOS:
        return 'dialogo'
    if nombre in _PANTALLAS:
        return 'pantalla'
    return 'builtin'


def _absolutiza(condicion, con_id, indice):
    """Cambia eq(-1,true) por el id real: los índices relativos dejan de valer al remapear categorías."""

    def _sustituye(encontrado):
        salto = int(encontrado.group(1))
        posicion = indice + salto
        if 0 <= posicion < len(con_id):
            return 'eq({0},'.format(con_id[posicion])
        return encontrado.group(0)

    return re.sub(r'eq\((-?\d+),', _sustituye, condicion)


_EQ_SIMPLE = re.compile(r'eq\(([^,)]+),(.+)\)$')


def _depende_de(condicion, con_id, indice):
    condicion = (condicion or '').strip()
    if not condicion:
        return ()
    absoluta = _absolutiza(condicion, con_id, indice)
    if any(marca in absoluta for marca in ('!', '|', '+')):
        return ('__cond__', absoluta)
    encontrado = _EQ_SIMPLE.match(absoluta)
    if encontrado:
        return (encontrado.group(1), _valor_condicion(encontrado.group(2)))
    return ('__cond__', absoluta)


def evaluar_condicion(cond, entradas_categoria, indice, leer):
    """Evalúa una condición `enable=` de Kodi ya absolutizada, con | (o), + (y) y ! (no)."""
    cond = (cond or '').strip()
    if not cond:
        return True
    if '|' in cond:
        return any(evaluar_condicion(parte, entradas_categoria, indice, leer)
                   for parte in cond.split('|'))
    if '+' in cond:
        return all(evaluar_condicion(parte, entradas_categoria, indice, leer)
                   for parte in cond.split('+'))
    negar = cond.startswith('!')
    if negar:
        cond = cond[1:].strip()
    encontrado = _EQ_SIMPLE.match(cond)
    if not encontrado:
        return True  # condición que no entendemos: mejor dejar el ajuste usable que esconderlo
    referencia = encontrado.group(1).strip()
    esperado = _valor_condicion(encontrado.group(2))
    if referencia.startswith('-'):
        posicion = indice + int(referencia)
        referencia = (entradas_categoria[posicion].id
                      if 0 <= posicion < len(entradas_categoria) else '')
    actual = leer(referencia)
    if isinstance(actual, bool) or isinstance(esperado, bool):
        correcto = bool(actual) == bool(esperado)
    else:
        correcto = str(actual) == str(esperado)
    return not correcto if negar else correcto


def _leer_valor(addon, entrada):
    crudo = addon.getSetting(entrada.id)
    if entrada.tipo == 'bool':
        return crudo == 'true'
    if entrada.tipo == 'enum':
        if entrada.guarda_indice:
            try:
                return int(crudo)
            except (TypeError, ValueError):
                return entrada.defecto
        return crudo
    if entrada.tipo in ('slider', 'number'):
        try:
            return int(crudo)
        except (TypeError, ValueError):
            return entrada.defecto
    return crudo


def _escribir_valor(addon, entrada, valor):
    if entrada.tipo == 'bool':
        addon.setSetting(entrada.id, 'true' if valor else 'false')
    elif entrada.tipo == 'enum' and entrada.guarda_indice:
        addon.setSetting(entrada.id, str(int(valor)))
    elif entrada.tipo in ('slider', 'number'):
        addon.setSetting(entrada.id, str(int(valor)))
    else:
        addon.setSetting(entrada.id, '' if valor is None else str(valor))


def _lector(addon, entrada):
    def _leer():
        return _leer_valor(addon, entrada)
    return _leer


def _escritor(addon, entrada):
    def _escribir(valor):
        _escribir_valor(addon, entrada, valor)
    return _escribir


def cargar_nativos(ruta_xml=None, addon=None):
    """Convierte settings.xml en Entradas: lsep -> cabecera, label -> ayuda, lo raro -> clasico."""
    addon = addon if addon is not None else _addon_por_defecto()
    raiz = ET.parse(ruta_xml or _RUTA_XML).getroot()
    salida = []
    for categoria in raiz.findall('category'):
        etiqueta = categoria.get('label', '')
        cabecera = ''
        ultima = None
        con_id = []
        for nodo in categoria:
            tipo_xml = (nodo.get('type') or '').strip()
            if tipo_xml == 'lsep':
                # "(también en Opciones > ...)" sobra aquí: la ficha ya dice dónde más se cambia.
                cabecera = re.sub(r'\s*\(también en [^)]*\)', '', nodo.get('label') or '',
                                  flags=re.IGNORECASE).strip()
                ultima = None
                continue
            if tipo_xml == 'sep':
                continue
            if tipo_xml == 'label':
                if ultima is not None and not ultima.ayuda:
                    ultima.ayuda = (nodo.get('label') or '').strip()
                continue
            if nodo.get('visible') == 'false':
                continue
            ident = nodo.get('id')
            if not ident:
                continue
            tipo, guarda_indice, opciones, rango = _tipo_nativo(tipo_xml, nodo)
            rotulo, destructivo = _limpiar_rotulo(nodo.get('label') or ident)
            accion = nodo.get('action') or ''
            entrada = Entrada(
                id=ident,
                categoria=etiqueta,
                rotulo=rotulo,
                tipo=tipo,
                cabecera=cabecera,
                opciones=opciones,
                guarda_indice=guarda_indice,
                rango=rango,
                defecto=_defecto_nativo(tipo, guarda_indice, nodo.get('default')),
                destructivo=destructivo,
                accion=accion or None,
                clase_accion=_clase_accion(accion) if accion else '',
                origen='nativo',
            )
            con_id.append(ident)
            if tipo in TIPOS_CON_VALOR:
                entrada.leer = _lector(addon, entrada)
                entrada.escribir = _escritor(addon, entrada)
            entrada.depende_de = _depende_de(nodo.get('enable'), con_id, len(con_id) - 1)
            salida.append(entrada)
            ultima = entrada
            cabecera = ''
    return salida


def _tamano_legible(bytes_):
    for unidad, tamano in (('GB', 1024 ** 3), ('MB', 1024 ** 2), ('KB', 1024)):
        if bytes_ >= tamano:
            return '{0:.1f} {1}'.format(bytes_ / tamano, unidad)
    return '{0} B'.format(bytes_)


def _filas_almacenamiento(ganchos):
    """Una fila informativa por caché y otra para borrarla, como el submenú Almacenamiento."""
    tamanos = ganchos.get('storage_tamanos')
    borrar = ganchos.get('storage_borrar')
    if not callable(tamanos):
        return []
    try:
        datos = tamanos() or []
    except Exception as e:
        # Leer los tamaños recorre el perfil en disco; si falla, la categoría sigue pintándose.
        import xbmc
        xbmc.log('[ModoAjustes] no se pudieron leer los tamaños de caché: {0}'.format(e),
                 xbmc.LOGWARNING)
        return []
    filas = []
    for nombre, bytes_, clave in datos:
        filas.append(Entrada(
            id='storage_info_{0}'.format(clave), categoria='rendimiento',
            rotulo='{0} · {1}'.format(nombre, _tamano_legible(bytes_)), tipo='info',
            origen='opciones', icono='adv_almacenamiento.png'))
        if callable(borrar):
            filas.append(Entrada(
                id='storage_borrar_{0}'.format(clave), categoria='rendimiento',
                rotulo='Borrar {0}'.format(nombre), tipo='action', origen='opciones',
                destructivo=True, confirmar=True, icono='adv_borrar.png',
                ayuda='Borra esta caché. Los datos se vuelven a descargar la próxima vez que '
                      'abras la sección.',
                accion=lambda clave=clave, borrar=borrar: borrar(clave)))
    return filas


def construir(ganchos, ruta_xml=None, addon=None):
    """Devuelve {clave de categoría: entradas en orden}, con los ganchos ya resueltos."""
    addon = addon if addon is not None else _addon_por_defecto()
    categorias = {c.clave: [] for c in CATEGORIAS}
    por_id = {}
    for entrada in cargar_nativos(ruta_xml, addon):
        etiqueta_nativa = entrada.categoria
        entrada.categoria = MAPA_NATIVO.get(entrada.id, etiqueta_nativa)
        entrada.tambien_en = 'Ajustes clásicos de Kodi › {0}'.format(etiqueta_nativa)
        if entrada.id == 'menu_colors_enabled':
            # El mismo ajuste también se cambia desde el submenú Accesibilidad.
            entrada.tambien_en = ('Accesibilidad, dentro del addon · ' + entrada.tambien_en)
        if entrada.id in _CONFIRMAR_NATIVOS:
            entrada.confirmar = True
        if entrada.id in _PROTEGIDOS_NATIVOS:
            entrada.protegido = True
        if entrada.id == 'crt_enabled':
            entrada.accion = _run('crt_toggle&key=crt_enabled')
            entrada.clase_accion = 'dialogo'
        por_id[entrada.id] = entrada

    for ident in MAPA_NATIVO:
        entrada = por_id.get(ident)
        if entrada is not None:
            categorias.setdefault(entrada.categoria, []).append(entrada)

    for plantilla in ENTRADAS_OPCIONES:
        entrada = copy.copy(plantilla)
        if isinstance(entrada.accion, tuple):
            nombre, argumento = entrada.accion
            funcion = ganchos.get(nombre)
            if callable(funcion):
                entrada.accion = lambda argumento=argumento, funcion=funcion: funcion(argumento)
            else:
                entrada.accion = None
        elif (isinstance(entrada.accion, str)
              and not entrada.accion.startswith(('RunPlugin(', 'ActivateWindow('))):
            entrada.accion = ganchos.get(entrada.accion)
        if entrada.leer_gancho:
            funcion = ganchos.get(entrada.leer_gancho)
            if callable(funcion):
                entrada.leer = lambda funcion=funcion, ident=entrada.id: funcion(ident)
        if entrada.escribir_gancho:
            funcion = ganchos.get(entrada.escribir_gancho)
            if callable(funcion):
                entrada.escribir = (lambda valor, funcion=funcion, ident=entrada.id:
                                    funcion(ident, valor))
        if entrada.leer is None and entrada.tipo in TIPOS_CON_VALOR:
            entrada.leer = _lector(addon, entrada)
            entrada.escribir = entrada.escribir or _escritor(addon, entrada)
        categorias.setdefault(entrada.categoria, []).append(entrada)

    todas = {e.id: e for lista in categorias.values() for e in lista}
    for ident, nombre in _HOOK_AL_CONFIRMAR.items():
        funcion = ganchos.get(nombre)
        if ident in todas and callable(funcion):
            todas[ident].accion = funcion

    categorias['rendimiento'].extend(_filas_almacenamiento(ganchos))
    for entrada in (e for lista in categorias.values() for e in lista):
        if not entrada.ayuda and entrada.id in AYUDAS:
            entrada.ayuda = AYUDAS[entrada.id]
    return categorias


def ids_acciones_opciones():
    """Nombres de gancho que el registro necesita de default._ganchos_modo_ajustes()."""
    nombres = set(_HOOKS_FIJOS) | set(_HOOK_AL_CONFIRMAR.values())
    for entrada in ENTRADAS_OPCIONES:
        if isinstance(entrada.accion, tuple) and entrada.accion:
            nombres.add(entrada.accion[0])
        elif (isinstance(entrada.accion, str)
              and not entrada.accion.startswith(('RunPlugin(', 'ActivateWindow('))):
            nombres.add(entrada.accion)
        for campo in ('leer_gancho', 'escribir_gancho'):
            if getattr(entrada, campo):
                nombres.add(getattr(entrada, campo))
    return nombres
