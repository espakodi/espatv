# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Más webcams: cámaras de YouTube de todo el mundo, por país y por categoría.

Las listas no viajan en el zip: se bajan de un JSON público al abrir la carpeta, se guardan en
caché y se normalizan a `{"nombre", "yt_id", "pais"}`. La reproducción la hace la acción
`play_youtube_live` de siempre. Estructura de carpetas:

    Más webcams (webcams_mas)
      ├─ Por país (webcams_paises)           → País (webcams_pais) → cámaras
      └─ Por categoría (webcams_categorias)  → Categoría (webcams_categoria) → País → cámaras
"""
import os
import re
import sys
import time
import unicodedata

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings

URL_BASE = "https://raw.githubusercontent.com/famelack/famelack-data/main/webcams/categories/"
URL_TODAS = URL_BASE + "all.json"
TTL_SEGUNDOS = 24 * 3600
ARCHIVO_CACHE = "webcams_remotas_cache.json"
VERSION_CACHE = 2
_TIMEOUT = (5, 15)  # (conexión, lectura): con la red caída no se espera en cada carpeta
REINTENTO_SEGUNDOS = 30 * 60  # tras un fallo con caché vieja, no se vuelve a la red hasta pasado este tiempo

# (código del dataset, nombre en español)
CATEGORIAS = (
    ("airport", "Aeropuertos"), ("animals", "Animales"), ("beach", "Playas"), ("city", "Ciudades"),
    ("construction", "Obras"), ("harbor", "Puertos"), ("lake", "Lagos"), ("landmark", "Monumentos"),
    ("mountain", "Montañas"), ("nature", "Naturaleza"), ("park", "Parques"), ("river", "Ríos"),
    ("ski", "Esquí"), ("space", "Espacio"), ("sports", "Deportes"), ("traffic", "Tráfico"),
    ("train", "Trenes"), ("underwater", "Bajo el agua"), ("volcano", "Volcanes"),
)

PAISES_ES = {
    "ae": "Emiratos Árabes Unidos", "ai": "Anguila", "ar": "Argentina", "at": "Austria",
    "au": "Australia", "aw": "Aruba", "ba": "Bosnia y Herzegovina", "bb": "Barbados",
    "be": "Bélgica", "bg": "Bulgaria", "bl": "San Bartolomé", "bq": "Caribe Neerlandés",
    "br": "Brasil", "bw": "Botsuana", "by": "Bielorrusia", "ca": "Canadá",
    "cd": "R. D. del Congo", "ch": "Suiza", "cl": "Chile", "cn": "China", "cr": "Costa Rica",
    "cw": "Curazao", "cz": "Chequia", "de": "Alemania", "dk": "Dinamarca",
    "do": "República Dominicana", "ec": "Ecuador", "ee": "Estonia", "es": "España",
    "fi": "Finlandia", "fr": "Francia", "ge": "Georgia", "gr": "Grecia", "gt": "Guatemala",
    "hn": "Honduras", "hr": "Croacia", "hu": "Hungría", "id": "Indonesia", "ie": "Irlanda",
    "il": "Israel", "in": "India", "iq": "Irak", "is": "Islandia", "it": "Italia",
    "jm": "Jamaica", "jp": "Japón", "ke": "Kenia", "kg": "Kirguistán", "kr": "Corea del Sur",
    "kz": "Kazajistán", "li": "Liechtenstein", "lv": "Letonia", "mk": "Macedonia del Norte",
    "mt": "Malta", "mu": "Mauricio", "mv": "Maldivas", "mx": "México", "na": "Namibia",
    "nl": "Países Bajos", "no": "Noruega", "np": "Nepal", "nz": "Nueva Zelanda", "om": "Omán",
    "pa": "Panamá", "pe": "Perú", "ph": "Filipinas", "pl": "Polonia", "pt": "Portugal",
    "py": "Paraguay", "ro": "Rumanía", "rs": "Serbia", "ru": "Rusia", "sa": "Arabia Saudí",
    "se": "Suecia", "sg": "Singapur", "si": "Eslovenia", "sk": "Eslovaquia",
    "sv": "El Salvador", "sx": "Sint Maarten", "tc": "Islas Turcas y Caicos", "th": "Tailandia",
    "tr": "Turquía", "tw": "Taiwán", "tz": "Tanzania", "ua": "Ucrania", "uk": "Reino Unido",
    "us": "Estados Unidos", "uz": "Uzbekistán", "va": "Ciudad del Vaticano",
    "vg": "Islas Vírgenes Británicas", "vi": "Islas Vírgenes de EE. UU.", "vn": "Vietnam",
    "za": "Sudáfrica", "zw": "Zimbabue",
}

_RE_EMBED = re.compile(
    r"^https?://(?:www\.)?youtube(?:-nocookie)?\.com/embed/([A-Za-z0-9_-]{11})(?:[/?#].*)?$")


# ---------------------------------------------------------------- datos puros

def extraer_yt_id(url):
    """El id de 11 caracteres de un embed de YouTube, o "" si la URL no lo es."""
    if not isinstance(url, str):
        return ""
    m = _RE_EMBED.match(url.strip())
    return m.group(1) if m else ""


def _clave_orden(nombre):
    """Orden alfabético sin tildes ni mayúsculas: Albir, Ávila, Zamora."""
    s = unicodedata.normalize("NFD", nombre)
    return "".join(c for c in s if not unicodedata.combining(c)).casefold()


def normalizar(entradas, excluir_ids=frozenset()):
    """Convierte las entradas del JSON en `[{"nombre", "yt_id", "pais"}]` ordenadas por nombre.

    Se descartan las que no son de YouTube, las geobloqueadas, las sin nombre, las repetidas
    y las que ya están en `excluir_ids`. Cualquier forma inesperada del feed da lista vacía
    en vez de excepción.
    """
    if not isinstance(entradas, list):
        return []
    vistos = set(excluir_ids)
    res = []
    for e in entradas:
        if not isinstance(e, dict) or e.get("isGeoBlocked"):
            continue
        nombre = e.get("name")
        nombre = nombre.strip() if isinstance(nombre, str) else ""
        fuentes = e.get("sources")
        urls = fuentes.get("youtube") if isinstance(fuentes, dict) else None
        if not nombre or not isinstance(urls, list):
            continue
        yt_id = next((i for i in (extraer_yt_id(u) for u in urls) if i), "")
        if not yt_id or yt_id in vistos:
            continue
        vistos.add(yt_id)
        pais = e.get("country")
        res.append({"nombre": nombre, "yt_id": yt_id,
                    "pais": pais.strip().lower() if isinstance(pais, str) else ""})
    res.sort(key=lambda r: _clave_orden(r["nombre"]))
    return res


def nombre_pais(cc):
    """Nombre del país en español; si no se conoce, el código en mayúsculas."""
    return PAISES_ES.get(str(cc).lower(), str(cc).upper())


def paises(camaras):
    """`[(código, nº de cámaras)]`: España primero y el resto por nombre sin tildes."""
    cuenta = {}
    for c in camaras:
        if c.get("pais"):
            cuenta[c["pais"]] = cuenta.get(c["pais"], 0) + 1
    orden = sorted(cuenta, key=lambda cc: (cc != "es", _clave_orden(nombre_pais(cc))))
    return [(cc, cuenta[cc]) for cc in orden]


def de_pais(camaras, cc):
    """Las cámaras de un país, en el orden en que vienen (ya por nombre)."""
    return [c for c in camaras if c.get("pais") == cc]


def categorias():
    """`[(código, nombre)]` de las 19 categorías, por nombre sin tildes."""
    return sorted(CATEGORIAS, key=lambda c: _clave_orden(c[1]))


# ---------------------------------------------------------------- descarga y caché

def _perfil():
    return xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))


def _ruta_cache():
    return os.path.join(_perfil(), ARCHIVO_CACHE)


def _ruta_cache_cat(cat):
    return os.path.join(_perfil(), "webcams_cat_{0}.json".format(cat))


def _ids_existentes():
    """Los ids de YouTube que ya están en las webcams fijas del addon (para no repetirlas)."""
    try:
        from youtube_data import WEBCAMS_ES
    except Exception:
        return frozenset()
    ids = set()

    def _recorre(nodo):
        if isinstance(nodo, dict):
            if nodo.get("yt_id"):
                ids.add(nodo["yt_id"])
            for v in nodo.values():
                _recorre(v)
        elif isinstance(nodo, list):
            for v in nodo:
                _recorre(v)

    _recorre(WEBCAMS_ES)
    return frozenset(ids)


def _leer_cache(ruta, clave):
    """`{"ts": float, clave: list}` o None si no hay caché, está rota o es de otra versión."""
    datos = core_settings._load_json(ruta, None)
    if not isinstance(datos, dict) or datos.get("version") != VERSION_CACHE:
        return None
    if not isinstance(datos.get("ts"), (int, float)) or not isinstance(datos.get(clave), list):
        return None
    intento = datos.get("intento")
    return {"ts": float(datos["ts"]), clave: datos[clave],
            "intento": float(intento) if isinstance(intento, (int, float)) else None}


def _fresca(cache, ahora):
    """Caché dentro de su plazo, o con un intento de renovarla fallido hace poco."""
    if not cache:
        return False
    if 0 <= ahora - cache["ts"] < TTL_SEGUNDOS:
        return True
    intento = cache.get("intento")
    return intento is not None and 0 <= ahora - intento < REINTENTO_SEGUNDOS


def _anotar_fallo(ruta, cache, clave, ahora):
    """Apunta cuándo falló la renovación para no volver a esperar a la red en cada carpeta."""
    if not cache:
        return
    try:
        core_settings.atomic_write_json(
            ruta, {"version": VERSION_CACHE, "ts": cache["ts"], clave: cache[clave], "intento": ahora})
    except Exception:
        pass


def _sin_repetidas(entradas):
    existentes = _ids_existentes()
    return [e for e in entradas if e["yt_id"] not in existentes]


def _entradas_validas(entradas):
    return [{"nombre": e["nombre"], "yt_id": e["yt_id"], "pais": e.get("pais") or ""}
            for e in entradas if isinstance(e, dict)
            and isinstance(e.get("nombre"), str) and isinstance(e.get("yt_id"), str)]


def _bajar_json(url):
    resp = requests.get(url, timeout=_TIMEOUT)
    resp.raise_for_status()
    return resp.json()


def cargar(ahora=None):
    """Todas las webcams del dataset como lista (vacía si no hay nada que mostrar).

    Caché fresca (24 h) sin red. Caducada: se intenta bajar de nuevo y, si falla o la respuesta
    no tiene la forma esperada, se sigue sirviendo la vieja. Nunca lanza.
    """
    ahora = time.time() if ahora is None else ahora
    cache = _leer_cache(_ruta_cache(), "entradas")
    if _fresca(cache, ahora):
        return _sin_repetidas(_entradas_validas(cache["entradas"]))
    try:
        lista = normalizar(_bajar_json(URL_TODAS))
        if lista:
            core_settings.atomic_write_json(
                _ruta_cache(), {"version": VERSION_CACHE, "ts": ahora, "entradas": lista})
            return _sin_repetidas(lista)
        xbmc.log("[EspaTV] Webcams remotas: la respuesta no trae cámaras", xbmc.LOGWARNING)
    except Exception as e:
        xbmc.log("[EspaTV] Webcams remotas: no se pudo actualizar ({0})".format(type(e).__name__),
                 xbmc.LOGWARNING)
    _anotar_fallo(_ruta_cache(), cache, "entradas", ahora)
    return _sin_repetidas(_entradas_validas(cache["entradas"])) if cache else []


def ids_categoria(cat, ahora=None):
    """Los ids de YouTube de una categoría, como frozenset (vacío si no se puede saber).

    Se baja solo al abrir esa categoría y se guarda en caché 24 h. Un código que no sea una de
    las 19 categorías no toca la red.
    """
    if cat not in dict(CATEGORIAS):
        return frozenset()
    ahora = time.time() if ahora is None else ahora
    ruta = _ruta_cache_cat(cat)
    cache = _leer_cache(ruta, "ids")
    if _fresca(cache, ahora):
        return frozenset(i for i in cache["ids"] if isinstance(i, str))
    try:
        ids = sorted({c["yt_id"] for c in normalizar(_bajar_json(URL_BASE + cat + ".json"))})
        if ids:
            core_settings.atomic_write_json(ruta, {"version": VERSION_CACHE, "ts": ahora, "ids": ids})
            return frozenset(ids)
    except Exception as e:
        xbmc.log("[EspaTV] Webcams remotas ({0}): no se pudo actualizar ({1})".format(
            cat, type(e).__name__), xbmc.LOGWARNING)
    _anotar_fallo(ruta, cache, "ids", ahora)
    return frozenset(i for i in cache["ids"] if isinstance(i, str)) if cache else frozenset()


# ---------------------------------------------------------------- carpetas de Kodi

def _carpeta(h, etiqueta, url, icono, plot=""):
    li = xbmcgui.ListItem(label=etiqueta)
    li.setArt({'icon': icono, 'thumb': icono})
    if plot:
        li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=True)


def _sin_datos(h, texto):
    import webcams
    webcams._notify_warn(texto)
    xbmcplugin.endOfDirectory(h)


def menu_raiz():
    """«Más webcams»: las dos formas de buscar una cámara. No hace red."""
    import webcams
    h = int(sys.argv[1])
    _carpeta(h, "[B]Por país[/B]", webcams._u(action="webcams_paises"),
             webcams._icono_media("webcams_paises.png"),
             "Las cámaras de cada país, con España la primera.")
    _carpeta(h, "[B]Por categoría[/B]", webcams._u(action="webcams_categorias"),
             webcams._icono_media("webcams_categorias.png"),
             "Playas, ciudades, montañas, puertos y más.")
    xbmcplugin.endOfDirectory(h)


def menu_paises():
    import webcams
    h = int(sys.argv[1])
    camaras = cargar()
    if not camaras:
        return _sin_datos(h, "No se pudieron cargar las webcams. Inténtalo más tarde.")
    icon = webcams._cam_icon()
    for cc, n in paises(camaras):
        _carpeta(h, "[B]{0}[/B] [COLOR limegreen]({1})[/COLOR]".format(nombre_pais(cc), n),
                 webcams._u(action="webcams_pais", cc=cc), icon)
    xbmcplugin.endOfDirectory(h)


def menu_categorias():
    """Las 19 categorías. No hace red: los datos se bajan al abrir cada una."""
    import webcams
    h = int(sys.argv[1])
    icon = webcams._cam_icon()
    for cat, nombre in categorias():
        _carpeta(h, "[B]{0}[/B]".format(nombre), webcams._u(action="webcams_categoria", cat=cat), icon)
    xbmcplugin.endOfDirectory(h)


def menu_categoria(cat):
    """Los países que tienen cámaras de esa categoría."""
    import webcams
    h = int(sys.argv[1])
    ids = ids_categoria(cat)
    camaras = [c for c in cargar() if c["yt_id"] in ids]
    if not camaras:
        return _sin_datos(h, "No hay cámaras de esta categoría ahora mismo.")
    icon = webcams._cam_icon()
    for cc, n in paises(camaras):
        _carpeta(h, "[B]{0}[/B] [COLOR limegreen]({1})[/COLOR]".format(nombre_pais(cc), n),
                 webcams._u(action="webcams_pais", cc=cc, cat=cat), icon)
    xbmcplugin.endOfDirectory(h)


def lista(cc, cat=""):
    """Las cámaras de un país (y de una categoría, si se indica): una fila reproducible cada una."""
    import webcams
    h = int(sys.argv[1])
    camaras = de_pais(cargar(), cc)
    if cat:
        ids = ids_categoria(cat)
        camaras = [c for c in camaras if c["yt_id"] in ids]
    if not camaras:
        return _sin_datos(h, "No hay cámaras para mostrar ahora mismo.")
    icon = webcams._cam_icon()
    for cam in camaras:
        nombre = cam["nombre"]
        li = xbmcgui.ListItem(label="[B][COLOR red]●[/COLOR] {0}[/B]".format(nombre))
        li.setArt({'icon': icon, 'thumb': icon})
        li.setInfo('video', {'title': nombre, 'plot': "{0}\nPulsa para ver en directo.".format(nombre)})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(
            handle=h, url=webcams._u(action="play_youtube_live", yt_id=cam["yt_id"], title=nombre),
            listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)
