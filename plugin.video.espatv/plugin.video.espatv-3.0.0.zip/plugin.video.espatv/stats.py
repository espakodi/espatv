# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""
Telemetria anonima para EspaTV

Datos de interes: Sistema operativo, version del addon y version de Kodi.
No se recopilan datos personales, IPs, habitos de uso ni contenido reproducido.

Proposito: Mejorar el software y planificar su desarrollo.

"""
import os
import json
import time
import uuid
import threading
import xbmc
import xbmcaddon
import xbmcvfs

import core_settings

_API_URL = "https://gpcbfvgxwesvlezaning.supabase.co"
_API_KEY = "eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6ImdwY2Jmdmd4d2VzdmxlemFuaW5nIiwicm9sZSI6ImFub24iLCJpYXQiOjE3NzM0ODQ1MjYsImV4cCI6MjA4OTA2MDUyNn0.ipnXlrez3yA6CWriqwJU4OzVRYn2nNicpOQSuzpBy-w"
_TABLE = "installs"
_PING_INTERVAL_HOURS = 24
_DATA_FILE = 'stats.json'


def _get_profile():
    return xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))


def _data_path():
    return os.path.join(_get_profile(), _DATA_FILE)


def _load_data():
    path = _data_path()
    if not os.path.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_data(data):
    profile = _get_profile()
    if not os.path.exists(profile):
        os.makedirs(profile, exist_ok=True)
    if not core_settings.atomic_write_json(os.path.join(profile, _DATA_FILE), data,
                                           ensure_ascii=False):
        xbmc.log("[EspaTV] Stats: no se pudo guardar {0}".format(_DATA_FILE), xbmc.LOGWARNING)


def _marcador_path():
    return os.path.join(_get_profile(), 'stats_activado')


def _activada():
    """True si la telemetría ya se activó alguna vez. Distingue 'primera vez' de
    'el usuario borró stats.json': en el segundo caso no se vuelve a crear ni se envía."""
    return os.path.exists(_marcador_path())


def _marcar_activada():
    try:
        with open(_marcador_path(), 'w', encoding='utf-8') as f:
            f.write('1')
    except OSError as e:
        xbmc.log("[EspaTV] Stats: no se pudo crear el marcador: {0}".format(e), xbmc.LOGWARNING)


def activar():
    """Primera activación (o tras restaurar el perfil): crea stats.json con un UUID.
    Sin uuid no se envía nada, según promete el punto h del AVISO_LEGAL."""
    data = _load_data()
    if not data.get('uuid'):
        if _activada():
            return False
        data['uuid'] = str(uuid.uuid4())
        _save_data(data)
    _marcar_activada()
    return True


def _get_platform():
    if xbmc.getCondVisibility("System.Platform.Android"):
        return "Android"
    elif xbmc.getCondVisibility("System.Platform.Windows"):
        return "Windows"
    elif xbmc.getCondVisibility("System.Platform.Linux"):
        return "Linux"
    elif xbmc.getCondVisibility("System.Platform.OSX"):
        return "macOS"
    elif xbmc.getCondVisibility("System.Platform.IOS"):
        return "iOS"
    return "Unknown"


def _should_ping():
    data = _load_data()
    if not data.get('uuid'):
        return False
    try:
        last_ping = float(data.get('last_ping', 0))
    except (ValueError, TypeError):
        # stats.json corrupto (last_ping con texto): se trata como si nunca se hubiera
        # enviado; sin esto el TypeError tumbaba el arranque.
        last_ping = 0.0
    hours_passed = (time.time() - last_ping) / 3600
    return hours_passed >= _PING_INTERVAL_HOURS


def _do_ping():
    try:
        import requests

        uid = _load_data().get('uuid')
        if not uid:
            return
        platform = _get_platform()
        addon = xbmcaddon.Addon()
        addon_version = addon.getAddonInfo('version')
        addon_id = addon.getAddonInfo('id')
        kodi_version = xbmc.getInfoLabel("System.BuildVersion").split(' ')[0]

        headers = {
            "apikey": _API_KEY,
            "Authorization": "Bearer {0}".format(_API_KEY),
            "Content-Type": "application/json",
        }

        now = time.strftime('%Y-%m-%dT%H:%M:%SZ', time.gmtime())

        payload = {
            "uuid": uid,
            "addon_name": addon_id,
            "platform": platform,
            "addon_version": addon_version,
            "kodi_version": kodi_version,
            "last_seen": now
        }

        resp = requests.post(
            "{0}/rest/v1/{1}".format(_API_URL, _TABLE),
            headers=headers,
            json=payload,
            timeout=10
        )

        if resp.status_code == 409:
            update = {
                "platform": platform,
                "addon_version": addon_version,
                "kodi_version": kodi_version,
                "last_seen": now
            }
            resp = requests.patch(
                "{0}/rest/v1/{1}?uuid=eq.{2}".format(_API_URL, _TABLE, uid),
                headers=headers,
                json=update,
                timeout=10
            )

        if resp.status_code in (200, 201, 204):
            xbmc.log("[EspaTV] Stats ping OK", xbmc.LOGINFO)
            data = _load_data()
            data['last_ping'] = time.time()
            _save_data(data)
        else:
            xbmc.log("[EspaTV] Stats ping failed: {0}".format(resp.status_code), xbmc.LOGWARNING)

    except (ImportError, OSError, ValueError, RuntimeError) as e:
        # OSError también cubre requests.RequestException (subclase de OSError)
        xbmc.log("[EspaTV] Stats error: {0}".format(e), xbmc.LOGWARNING)


def ping():
    try:
        data = _load_data()
        if data.get('uuid'):
            # Ya enviaba antes: asegurar el marcador para que borrar stats.json desactive.
            if not _activada():
                _marcar_activada()
        elif _activada():
            return  # el usuario borró stats.json: no se recrea ni se envía
        else:
            activar()

        if not _should_ping():
            return

        t = threading.Thread(target=_do_ping, daemon=True)
        t.start()
    except (OSError, ValueError, TypeError, RuntimeError) as e:
        xbmc.log("[EspaTV] Stats: {0}".format(e), xbmc.LOGWARNING)