# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Utilidades de interfaz compartidas por los módulos que se portan de AtresDaily/EspaDaily.

EspaTV no tenía este módulo. Se trae solo lo que usan los módulos portados y se apoya en
core_settings para lo que ya existe ahí (escritura atómica). Abajo están también los helpers
de las listas de Dailymotion (filtro de borrados, relleno y puntuación).
"""
import difflib
import json
import os
import re
import sys
import unicodedata
import urllib.parse
from concurrent.futures import ThreadPoolExecutor

import requests

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings
from _user_agents import UA_DESKTOP

ADDON = xbmcaddon.Addon()
ICON_MAIN = os.path.join(ADDON.getAddonInfo('path'), 'icon.png')
_MEDIA_DIR = os.path.join(ADDON.getAddonInfo('path'), 'resources', 'media')

PUNTO_NUEVO = "[COLOR lime]●[/COLOR] "
# Lo nuevo que ya se ha abierto: un archivo vacío por clave. No va en los ajustes porque cada
# xbmcaddon.Addon() tiene su copia y setSetting reescribe el settings.xml entero.
_VISTOS = os.path.join(xbmcvfs.translatePath(ADDON.getAddonInfo('profile')), 'vistos')

# El código portado solo usa la User-Agent de aquí (para pedir listas). Se toma la de
# _user_agents, sin el Origin de atresplayer que llevaba la de AtresDaily.
HEADERS = {"User-Agent": UA_DESKTOP}

# Elección recordada de "cómo quieres escribir" (teclado o móvil) mientras dura la llamada.
_ask_choice = None


def media_icon(filename):
    """Ruta del icono en resources/media, o '' si no existe."""
    p = os.path.join(_MEDIA_DIR, filename)
    return p if os.path.exists(p) else ''


def punto(clave):
    """El punto verde de lo nuevo mientras no se haya abierto (ver visto)."""
    return "" if os.path.exists(os.path.join(_VISTOS, clave)) else PUNTO_NUEVO


def visto(clave):
    """Apaga el punto verde. Devuelve True si lo ha apagado ahora; con dos llamadas a la vez,
    solo una, porque el archivo se crea en exclusiva."""
    try:
        os.makedirs(_VISTOS, exist_ok=True)
        with open(os.path.join(_VISTOS, clave), 'x'):
            pass
    except FileExistsError:
        return False
    except OSError as e:
        xbmc.log("[EspaTV] No se puede guardar como visto '{0}': {1}".format(clave, e), xbmc.LOGWARNING)
        return False
    return True


def get_params():
    p = {}
    if len(sys.argv) >= 3 and sys.argv[2]:
        p = dict(urllib.parse.parse_qsl(sys.argv[2][1:]))
    return p


def _fanart():
    # Mismo criterio que el menú de EspaTV: respeta el desactivado y el fanart propio.
    if core_settings.is_fanart_disabled():
        return ''
    return core_settings.get_custom_fanart() or ADDON.getAddonInfo('fanart')


def add_item(action, title, url="", thumbnail="", fanart="", extra="", folder=True,
             isPlayable=False, plot="", context=None, nuevo="", li=None, **kwargs):
    # nuevo: clave del punto verde (ver punto). Va solo en la etiqueta; no en la URL, para no
    # cambiar la dirección del botón al apagarse.
    #
    # li: un `ListItem` ya hecho, para cuando quien llama necesita `setInfo` con campos que aquí no
    # existen (año, nota, reparto...). Se le pone el contexto y se añade tal cual. Es opcional y
    # aditivo: sin él, esta función se comporta exactamente como antes, lo que hace que tocar
    # este fichero compartido sea seguro.
    if li is None:
        li = xbmcgui.ListItem(punto(nuevo) + title if nuevo else title)

        art = {}
        if thumbnail:
            art['icon'] = thumbnail
            art['thumb'] = thumbnail
        if not fanart:
            fanart = _fanart()
        if fanart:
            art['fanart'] = fanart
        li.setArt(art)

        info = {'title': title}
        if plot:
            info['plot'] = plot
        li.setInfo('video', info)

        if isPlayable:
            li.setProperty('IsPlayable', 'true')
            folder = False
    elif isPlayable:
        li.setProperty('IsPlayable', 'true')
        folder = False

    if context:
        li.addContextMenuItems(menu_contextual(context))

    u = "{0}?action={1}&title={2}&url={3}&extra={4}".format(
        sys.argv[0], action, urllib.parse.quote(title),
        urllib.parse.quote(url), urllib.parse.quote(extra))
    for key, value in kwargs.items():
        u += "&{0}={1}".format(key, urllib.parse.quote(str(value)))

    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=u, listitem=li, isFolder=folder)


def close_item_list():
    xbmcplugin.endOfDirectory(int(sys.argv[1]))


def menu_contextual(entradas):
    """Las entradas de un menú contextual. Con el Modo Fantasía abierto pasan por su puente.

    default.py solo importa fantasia con el modo abierto, así que con el modo cerrado esto no
    importa ni cambia nada."""
    fantasia = sys.modules.get('fantasia')
    return list(entradas) if fantasia is None else fantasia.menu_contextual(entradas)


def play_resolved(url):
    li = xbmcgui.ListItem(path=url)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)


def get_path(filename):
    p = xbmcvfs.translatePath(ADDON.getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p, exist_ok=True)
    return os.path.join(p, filename)


def load_json(name, default=None):
    """JSON del perfil. Si no existe: `default` si se da; si no, dict para ajustes y lista
    para el resto (misma heurística que AtresDaily)."""
    try:
        with open(get_path(name), 'r', encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        if default is not None:
            return default
        if 'settings' in name or 'config' in name or 'last_adv' in name:
            return {}
        return []


def save_json(name, data):
    # Atómico con el helper común (tmp + os.replace): un corte o dos guardados solapados no
    # dejan el archivo a medias. Devuelve el resultado de la escritura, que
    # `core_settings.atomic_write_json` ya calculaba y aquí se descartaba: sin él, un disco
    # lleno o un perfil sin permisos llegaba a quien llama como un "guardado" silencioso, y
    # quien prometía "guardado" no tenía forma de saber que estaba mintiendo.
    return core_settings.atomic_write_json(get_path(name), data)


def _activar(addon_id):
    """Enciende un addon instalado. True si queda encendido.

    Con JSON-RPC y no con el builtin EnableAddon, que pregunta sí/no cada vez. SetAddonEnabled
    contesta OK tanto si lo enciende como si no, así que se pide una vez y se mira el estado."""
    xbmc.executeJSONRPC(json.dumps({"jsonrpc": "2.0", "id": 1,
                                    "method": "Addons.SetAddonEnabled",
                                    "params": {"addonid": addon_id, "enabled": True}}))
    monitor = xbmc.Monitor()
    for _ in range(30):
        if xbmc.getCondVisibility("System.AddonIsEnabled({0})".format(addon_id)):
            return True
        if monitor.waitForAbort(0.1):
            break
    return bool(xbmc.getCondVisibility("System.AddonIsEnabled({0})".format(addon_id)))


def addon_listo(addon_id, nombre, aviso_si_falta=None):
    """True si el addon está instalado y activado. Si está desactivado, ofrece activarlo; si no
    está instalado, enseña aviso_si_falta (si lo hay) y devuelve False.

    Desde Kodi 19 System.HasAddon es cierto también con el addon desactivado, y uno desactivado
    no abre ni reproduce nada. InstallAddon tampoco hace nada con él."""
    if xbmc.getCondVisibility("System.AddonIsEnabled({0})".format(addon_id)):
        return True
    if not xbmc.getCondVisibility("System.HasAddon({0})".format(addon_id)):
        if aviso_si_falta:
            xbmcgui.Dialog().ok("EspaTV", aviso_si_falta)
        return False
    if not xbmcgui.Dialog().yesno(
            "EspaTV", "{0} está instalado pero desactivado.\n\n¿Activarlo ahora?".format(nombre),
            nolabel="Cerrar", yeslabel="Activar"):
        return False
    if _activar(addon_id):
        xbmcgui.Dialog().notification("EspaTV", "{0} activado".format(nombre),
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        return True
    xbmcgui.Dialog().ok("EspaTV",
                        "Kodi no ha podido activar {0}. Actívalo en Addons > Mis addons.".format(nombre))
    return False


def get_text(title, default=''):
    """Pide un texto: teclado de Kodi o, si el usuario lo eligió, desde el móvil/PC."""
    global _ask_choice
    cfg = load_json('settings.json')
    mode = cfg.get('web_input_mode', 'keyboard') if isinstance(cfg, dict) else 'keyboard'
    use_web = mode == 'web'
    try:
        if mode == 'ask':
            if _ask_choice is None:
                sel = xbmcgui.Dialog().select('¿Cómo quieres escribir?',
                                              ['Teclado de Kodi', 'Escribir desde el móvil/PC'])
                if sel < 0:
                    return ''
                _ask_choice = sel
            use_web = _ask_choice == 1
        if use_web:
            try:
                import web_input
                r = web_input.receive_text(title, default)
                if r is not None:
                    return r
            except Exception as e:
                xbmc.log('[EspaTV] web_input no disponible, uso el teclado: {0}'.format(e),
                         xbmc.LOGWARNING)
        kb = xbmc.Keyboard(default, title)
        kb.doModal()
        return kb.getText() if kb.isConfirmed() else ''
    finally:
        # Se olvida la elección para que la siguiente búsqueda de la sesión vuelva a
        # preguntar (antes reutilizaba la primera sin preguntar).
        _ask_choice = None


# ===== Listas de Dailymotion =================================================
# Portado de AtresDaily (ui_utils.py: dm_limite_lista, dm_api_videos, filtrar_dm_borrados)
# y de su conector (_puntuar, _norm, _VACIAS, _GENERICAS). EspaTV no tiene conector, así que
# vive aquí. El filtro quita DM005 y también DM002 (borrado por el autor), como EspaDaily.

_DM_OCULTAR = ('dm_filtrar_retirados', 'dm_ocultar_privados', 'dm_ocultar_directos_apagados')


def ajuste_dm(clave):
    """Interruptor de las listas de Dailymotion. Es un ajuste nativo, así que la pestaña
    Dailymotion de los ajustes del addon y el submenú de Opciones cambian lo mismo."""
    return xbmcaddon.Addon().getSetting(clave) != 'false'


def dm_limite_lista(n):
    """Cuántos resultados pedir a la API para poder enseñar n después del filtro.

    En algunas búsquedas 16 de cada 20 resultados están retirados. Con "Rellenar las listas"
    se piden hasta cinco veces más (la API da 100 como mucho) y filtrar_dm_borrados recorta a
    n, así que la lista sale llena sin consultas de más.
    """
    if any(ajuste_dm(c) for c in _DM_OCULTAR) and ajuste_dm('dm_rellenar_listas'):
        return max(n, min(100, n * 5))
    return n


# access_error de un vídeo que ya no existe: DM005 si Dailymotion lo retiró y DM002 si lo borró
# su autor. Los dos siguen saliendo en búsquedas y tendencias; los vivos nunca lo llevan.
_DM_RETIRADOS = {"DM002", "DM005"}
# Tope de privados que se comprueban por lista. Un canal que restringe sus vídeos los tiene
# todos así, y sin tope su playlist tardaría decenas de segundos.
_DM_MAX_PRIVADOS = 20


def dm_api_videos(url, params, timeout=10):
    """GET a la API de vídeos de DM pidiendo también access_error, para que
    filtrar_dm_borrados sepa qué no se puede ver sin hacer otra consulta (unos 0,3 s menos
    por lista). Si la API rechazara el campo, se repite sin él."""
    cabeceras = {"User-Agent": HEADERS["User-Agent"]}
    con_error = dict(params, fields="{0},access_error".format(params.get('fields', 'id')))
    r = requests.get(url, params=con_error, headers=cabeceras, timeout=timeout)
    if r.status_code == 400:
        r = requests.get(url, params=params, headers=cabeceras, timeout=timeout)
    return r


def _dm_codigo(v):
    ae = v.get("access_error")
    return ae.get("code") if isinstance(ae, dict) else None


def _dm_privado(vid):
    """True si el vídeo no se puede ver ni pidiéndolo como la web de DM.

    La API marca con DM016 tanto los que su autor solo deja ver en dailymotion.com, que el
    addon sí reproduce, como los privados, y solo la metadata pedida así los distingue. Ante
    un fallo de red se deja el vídeo a la vista.
    """
    try:
        r = requests.get("https://www.dailymotion.com/player/metadata/video/{0}".format(vid),
                         params={"app": "com.dailymotion.neon"},
                         headers={"User-Agent": HEADERS["User-Agent"],
                                  "Referer": "https://www.dailymotion.com/"}, timeout=4)
        return bool(r.json().get("error"))
    except (requests.RequestException, ValueError) as e:
        xbmc.log("[EspaTV] filtro DM, comprobando {0}: {1}".format(vid, e), xbmc.LOGINFO)
        return False


def _dm_privados(vids):
    """Los de `vids` (todos DM016) que son privados, comprobados a la vez."""
    if not vids:
        return set()
    with ThreadPoolExecutor(max_workers=min(8, len(vids))) as ex:
        return {vid for vid, es in zip(vids, ex.map(_dm_privado, vids)) if es}


def _dm_codigos_por_lote(ids):
    """{id: código de access_error} de los vídeos que siguen existiendo, o None si la API
    falla. Es el camino de las listas pedidas sin dm_api_videos."""
    codigos = {}
    for inicio in range(0, len(ids), 100):
        lote = ",".join(ids[inicio:inicio + 100])
        try:
            for campos in ("id,access_error", "id"):
                r = requests.get("https://api.dailymotion.com/videos",
                                 params={"ids": lote, "fields": campos, "limit": 100},
                                 headers={"User-Agent": HEADERS["User-Agent"]}, timeout=8)
                if r.status_code != 400:
                    break
            if r.status_code != 200:
                return None
            for v in r.json().get("list", []):
                codigos[str(v.get("id"))] = _dm_codigo(v)
        except (requests.RequestException, ValueError) as e:
            # Un filtro no puede romper la lista: cualquier fallo, sin filtrar.
            xbmc.log("[EspaTV] filtro DM: {0}".format(e), xbmc.LOGWARNING)
            return None
    return codigos


def filtrar_dm_borrados(videos, id_key="id", cuantos=None):
    """Quita de una lista de resultados de Dailymotion lo que no se puede ver.

    Según los ajustes: retirados, privados y directos que no están emitiendo. Con `cuantos`
    devuelve como mucho esos, para las listas pedidas de más con dm_limite_lista.

    El índice de búsqueda de DM sigue devolviendo vídeos borrados. Su campo access_error dice
    qué error daría cada uno: DM005 y DM002 retirado, DM003 directo sin emisión y DM016
    posible privado. Si la lista se pidió con dm_api_videos ya lo trae y no hace falta
    consultar nada; si no, se piden los ids por lote, que omite los retirados. Los DM016 se
    comprueban a la vez, hasta _DM_MAX_PRIVADOS.

    Ante cualquier fallo devuelve la lista intacta: mostrar algún vídeo muerto es mucho menos
    grave que vaciar los resultados del usuario.
    """
    # Una respuesta corrupta no debe colar entradas que no son diccionario a quien pinta la lista,
    # ni con los filtros apagados ni por los caminos que devuelven la lista intacta.
    videos = [v for v in videos if isinstance(v, dict)] if videos else []
    intacta = videos if cuantos is None else videos[:cuantos]
    retirados = ajuste_dm('dm_filtrar_retirados')
    privados = ajuste_dm('dm_ocultar_privados')
    apagados = ajuste_dm('dm_ocultar_directos_apagados')
    if not (retirados or privados or apagados) or not videos:
        return intacta

    if all(isinstance(v, dict) and "access_error" in v for v in videos):
        codigos = {str(v.get(id_key)): _dm_codigo(v) for v in videos}
    else:
        # Se ignoran las entradas que no son diccionario (respuesta corrupta).
        ids = [str(v.get(id_key)) for v in videos if isinstance(v, dict) and v.get(id_key)]
        # `_dm_codigos_por_lote` devuelve None si la API falla (sin filtrar) y un dict, que
        # puede estar vacío, si responde: vacío significa que ninguno de los ids existe, o
        # sea, retirados. Antes se exigían 2 ids y el vacío se tomaba por un fallo, así que
        # una lista de un solo vídeo muerto nunca se filtraba.
        codigos = _dm_codigos_por_lote(ids) if ids else None
        if codigos is None:
            return intacta

    dudosos = ([str(v.get(id_key)) for v in videos
                if isinstance(v, dict) and codigos.get(str(v.get(id_key))) == "DM016"]
               if privados else [])
    son_privados = _dm_privados(dudosos[:_DM_MAX_PRIVADOS])

    visibles = []
    n_retirados = n_privados = n_apagados = 0
    for v in videos:
        if not isinstance(v, dict):
            continue
        if cuantos is not None and len(visibles) >= cuantos:
            break
        vid = str(v.get(id_key))
        codigo = codigos.get(vid, "DM005")  # por lote, el que falta es retirado
        if codigo in _DM_RETIRADOS:
            if retirados:
                n_retirados += 1
                continue
        elif codigo == "DM003" and apagados:
            n_apagados += 1
            continue
        elif vid in son_privados:
            n_privados += 1
            continue
        visibles.append(v)

    if n_retirados or n_privados or n_apagados:
        xbmc.log("[EspaTV] filtro DM: ocultos {0} retirados, {1} privados y {2} directos sin "
                 "emisión".format(n_retirados, n_privados, n_apagados), xbmc.LOGINFO)
    return visibles


# Palabras que no identifican lo buscado. Que falten en un título no indica que sea otro
# vídeo ("Hombres de Paco" es "Los hombres de Paco").
_VACIAS = {"el", "la", "los", "las", "lo", "de", "del", "y", "e", "o", "u", "a", "al", "en",
           "con", "por", "para", "un", "una", "uno", "unos", "unas", "su", "sus", "que", "se"}
# Las de episodio tampoco, porque los títulos ponen "Cap.", "Ep" o "1x05" en vez de "Capítulo".
_GENERICAS = {"capitulo", "cap", "episodio", "ep", "temporada", "temp", "programa",
              "completo", "completa", "parte"}


def norm(t):
    """Minúsculas y sin tildes, porque los títulos de DM ponen tanto "Capítulo" como "Capitulo"."""
    t = unicodedata.normalize("NFKD", t.lower())
    return "".join(c for c in t if not unicodedata.combining(c))


def _duracion(v):
    try:
        return int(float(v.get("duration", 0) or 0))
    except (ValueError, TypeError):
        return 0


def puntuar(q, rs, largos_primero=False):
    """Resultados ordenados por parecido con la búsqueda: [(puntos, %, vídeo)], donde % es qué
    parte de lo buscado aparece en el título (nunca pasa de 100).

    Cuenta sobre todo que estén, enteras y sin mirar tildes, las palabras que identifican lo
    buscado y sus números; la duración desempata. `largos_primero` sube los de 30 minutos o más
    sin pasar por delante de un título que coincide mejor.

    Es la puntuación de AtresDaily, una sola para todas las listas. El ajuste de prioridad es
    el de siempre (core_settings); "solo con el número de capítulo" y "todas las palabras" son
    nativos (dm_exigir_numero, dm_exigir_palabras).
    """
    qn = norm(q)
    numeros = [int(x) for x in re.findall(r"\d+", qn)]
    q_nums = set(numeros)
    # El número de capítulo es el último: el episodio va al final de la búsqueda.
    capitulo = numeros[-1] if numeros else None
    claves = [w for w in re.findall(r"[^\W\d_]+", qn) if w not in _VACIAS and w not in _GENERICAS]
    frase = re.sub(r"\b(capitulo|episodio|cap|temporada)\b.*$", "", qn).strip()
    partes = len(claves) + (1 if q_nums else 0)
    por_duracion = not core_settings.is_prioritize_match_active()
    exigir_numero = ajuste_dm('dm_exigir_numero')
    exigir_palabras = ajuste_dm('dm_exigir_palabras')

    sc = []
    for r in rs:
        if not isinstance(r, dict):
            continue
        t = norm(str(r.get("title") or "").strip())
        if not t:
            continue
        palabras = set(re.findall(r"[^\W\d_]+", t))
        faltan = sum(1 for w in claves if w not in palabras)
        t_nums = {int(x) for x in re.findall(r"\d+", t)}
        numero_ok = capitulo in t_nums
        if (exigir_palabras and faltan) or (exigir_numero and q_nums and not numero_ok):
            continue

        parecido = difflib.SequenceMatcher(None, qn, t).ratio()
        s = parecido * 0.5
        if claves:
            s += (len(claves) - faltan) / len(claves) - faltan
        if frase and frase in t:
            s += 0.5
        if q_nums and t_nums:
            comunes = len(q_nums & t_nums)
            s += 2.0 * comunes / len(q_nums) if comunes else -1.0
        du = _duracion(r)
        if por_duracion:
            if du > 600:
                s += 0.3
            elif du > 300:
                s += 0.1
        if largos_primero and du >= 1800:
            s += 0.6
        # Menos de un minuto casi nunca es lo buscado (anuncios, resúmenes), y en una búsqueda
        # de capítulo tampoco menos de tres.
        if du < 60:
            s -= 0.5
        elif du < 180 and q_nums:
            s -= 0.3

        pct = (round(100 * (len(claves) - faltan + numero_ok) / partes) if partes
               else round(100 * parecido))
        sc.append((s, min(pct, 100), r))

    sc.sort(key=lambda x: x[0], reverse=True)
    return sc
