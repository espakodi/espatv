# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Guía de programación (EPG) desde tdtchannels.com: lo que se emite ahora.

El sello de la fuente ('20250501200000 +0200') va en hora española; se pasa a UTC real al
leerlo (_to_utc14, de epg_texto) y format_time lo lleva a la hora local. El XML se lee por
partes (iterparse) porque la guía completa ronda los 50 MB.
"""
import gzip
import hashlib
import io
import json
import os
import time
import xml.etree.ElementTree as ET
from datetime import datetime, timedelta, timezone

import xbmc
import core_settings

# _to_utc14 y _parse_epg_dt son los mismos que los de la guía en texto: un solo sitio donde se
# entiende el sello XMLTV (con su +0200) y donde se parsea sin strptime (bug #7980).
from epg_texto import _parse_epg_dt, _to_utc14

try:
    import requests
except ImportError:
    requests = None

_EPG_URL = "https://www.tdtchannels.com/epg/TV.xml.gz"
# Versión de la caché: al pasar start/stop de hora local-como-si-fuera-UTC a UTC real hay que
# invalidar las viejas.
_CACHE_VERSION = 2
_MAX_XML = 200 * 1024 * 1024
_epg_cache = {"data": None, "ts": 0, "v": _CACHE_VERSION}


class _LectorConTope:
    """Fichero que da ValueError al pasar de `tope` bytes leídos."""

    def __init__(self, f, tope):
        self._f = f
        self._quedan = tope

    def read(self, n=-1):
        datos = self._f.read(n)
        self._quedan -= len(datos)
        if self._quedan < 0:
            raise ValueError("la guía descomprimida pasa del tope")
        return datos


def _parse_ahora(xml_data):
    """{canal: {title, desc, start, stop}} de lo que se emite ahora, con start/stop en UTC real."""
    programmes = {}
    ahora = datetime.now(timezone.utc).replace(tzinfo=None).strftime("%Y%m%d%H%M%S")
    crudo = io.BytesIO(xml_data)
    with (gzip.GzipFile(fileobj=crudo) if xml_data[:2] == b"\x1f\x8b" else crudo) as fz:
        eventos = ET.iterparse(_LectorConTope(fz, _MAX_XML), events=("start", "end"))
        _, raiz = next(eventos)
        for evento, el in eventos:
            if evento != "end":
                continue
            if el.tag == "programme":
                ch_id = el.get("channel", "")
                start_s = _to_utc14(el.get("start", ""))
                stop_s = _to_utc14(el.get("stop", ""))
                if ch_id and start_s and stop_s and start_s <= ahora < stop_s:
                    title_el = el.find("title")
                    desc_el = el.find("desc")
                    programmes[ch_id] = {
                        "title": (title_el.text if title_el is not None and title_el.text else ""),
                        "desc": (desc_el.text if desc_el is not None and desc_el.text else ""),
                        "start": start_s, "stop": stop_s,
                    }
            raiz.clear()
    return programmes


def fetch():
    now = time.time()
    if (_epg_cache["data"] is not None and _epg_cache["v"] == _CACHE_VERSION
            and (now - _epg_cache["ts"]) < 7200):
        return _epg_cache["data"]
    try:
        ttl = core_settings.get_iptv_cache_ttl()
        if ttl <= 0:
            ttl = 7200

        c_file = ""
        programmes = None
        if core_settings.is_iptv_cache_active():
            c_dir = core_settings.get_iptv_cache_dir()
            c_key = hashlib.md5(_EPG_URL.encode('utf-8')).hexdigest()
            c_file = os.path.join(c_dir, 'epg_' + c_key + '.json')
            if os.path.exists(c_file):
                try:
                    with open(c_file, 'r', encoding='utf-8') as f:
                        meta = json.load(f)
                    if meta.get('v') == _CACHE_VERSION and (now - meta.get('ts', 0)) < ttl:
                        programmes = meta.get('data', {})
                except (OSError, ValueError):
                    pass

        if not programmes:
            if requests is None:
                return {}
            r = requests.get(_EPG_URL, timeout=20)
            if r.status_code != 200:
                return {}
            programmes = _parse_ahora(r.content)
            if core_settings.is_iptv_cache_active() and c_file:
                core_settings.atomic_write_json(c_file,
                                                {'v': _CACHE_VERSION, 'ts': now,
                                                 'data': programmes})

        _epg_cache["data"] = programmes
        _epg_cache["ts"] = now
        _epg_cache["v"] = _CACHE_VERSION
        return programmes
    except Exception as e:
        xbmc.log("[EspaTV] EPG fetch error: {0}".format(e), xbmc.LOGERROR)
        return {}


def format_time(t):
    if len(t) >= 12:
        utc_dt = _parse_epg_dt(t)
        if utc_dt is None:
            return "{0}:{1}".format(t[8:10], t[10:12])
        local_offset = -time.timezone if not time.daylight else -time.altzone
        local_dt = utc_dt + timedelta(seconds=local_offset)
        return "{0:02d}:{1:02d}".format(local_dt.hour, local_dt.minute)
    return ""
