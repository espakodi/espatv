# EspaTV, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
#
# Resolución de Dailymotion. Entrega la URL de una VARIANTE HLS
# (vod*.cf.dmcdn.net), no el master: cdndirector.dailymotion.com, el host del
# master, filtra por huella TLS y exige las cookies que deja la petición de
# metadata. Los clientes de reproducción de Kodi no pasan ese filtro; las
# variantes no lo tienen.
#
# Receta portada de AtresDaily (dm_resolver.py + las funciones _dm_* de su
# conector), adaptada a EspaTV: metadata y master por el mismo urllib con
# CookieJar (solo biblioteca estándar), vías 'cookies'/'requests'/'resolveurl'/
# 'sistema', motivo de fallo por código y liberación del decodificador en Android.
import http.cookiejar
import json
import re
import subprocess
import sys
import urllib.parse
import urllib.request

import xbmc


_UA_DM = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36"
)
HEADERS_DM = {
    "User-Agent": _UA_DM,
    "Origin": "https://www.dailymotion.com",
    "Referer": "https://www.dailymotion.com/",
}

# Script para subprocess. Usa el urllib3 del Python del sistema, que esquiva el
# fingerprint TLS que bloquea a Kodi. Imprime la URL de la variante en stdout.
_DM_SYSPY = r'''
import sys, json, re, urllib.parse
try:
    import requests
    _GET = lambda u, h: requests.get(u, headers=h, timeout=15).text
except ImportError:
    import urllib.request
    def _GET(u, h):
        return urllib.request.urlopen(urllib.request.Request(u, headers=h), timeout=15).read().decode()
vid, max_cal = sys.argv[1], int(sys.argv[2])
hdr = {"User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/138.0.0.0 Safari/537.36",
       "Origin": "https://www.dailymotion.com", "Referer": "https://www.dailymotion.com/"}
data = json.loads(_GET("https://www.dailymotion.com/player/metadata/video/" + vid, hdr))
if data.get("error"):
    sys.exit(2)
hls = ""
for it in data.get("qualities", {}).get("auto", []):
    if it.get("type") == "application/x-mpegURL":
        hls = it.get("url", ""); break
if not hls:
    sys.exit(3)
master = _GET(hls, hdr)
lineas = master.splitlines(); cands = []
for i, l in enumerate(lineas):
    if not l.startswith("#EXT-X-STREAM-INF:"):
        continue
    bw = re.search(r"BANDWIDTH=(\d+)", l); res = re.search(r"RESOLUTION=(\d+)x(\d+)", l)
    for nxt in lineas[i + 1:]:
        nxt = nxt.strip()
        if nxt and not nxt.startswith("#"):
            cal = min(int(res.group(1)), int(res.group(2))) if res else 0
            cands.append((cal, int(bw.group(1)) if bw else 0, nxt.split("#")[0])); break
if not cands:
    sys.exit(4)
us = [c for c in cands if c[0] <= max_cal] or cands
print(json.dumps({"url": urllib.parse.urljoin(hls, max(us, key=lambda c: (c[0], c[1]))[2])}))
'''

# Códigos de error de la metadata de DM que no significan "retirado". DM007 es el
# geobloqueo, según el extractor de yt-dlp.
_DM_MOTIVOS = {
    "DM002": "Su autor lo ha retirado",
    "DM005": "Su autor lo ha retirado",
    "DM003": "Este directo no está emitiendo ahora",
    "DM007": "Su autor lo bloquea en tu país. Con una VPN de otro país puede funcionar",
    "DM016": "Su autor solo deja verlo en la web de Dailymotion",
    "DM020": "Su autor lo ha hecho privado",
}

_PREF_FILE = 'dm_via.json'


def _log(msg, level='info'):
    try:
        import xbmc
        lvl = {'info': xbmc.LOGINFO, 'warning': xbmc.LOGWARNING,
               'error': xbmc.LOGERROR}.get(level, xbmc.LOGINFO)
        xbmc.log("[dm_resolver] {0}".format(msg), lvl)
    except (ImportError, AttributeError):
        pass


def _abridor():
    """Opener de urllib con tarro de cookies, para metadata y master a la vez:
    cdndirector solo entrega el master si trae las cookies de la metadata."""
    return urllib.request.build_opener(
        urllib.request.HTTPCookieProcessor(http.cookiejar.CookieJar()))


def _get(abridor, url, timeout=15):
    with abridor.open(urllib.request.Request(url, headers=HEADERS_DM), timeout=timeout) as r:
        return r.read().decode('utf-8', 'replace')


def elegir_variante(master_url, texto, max_altura):
    """URL absoluta de la variante elegida del master, o None si no trae ninguna.

    El lado menor es la calidad real: en vertical (480x848) el límite lo marca el ancho.
    Se ordena por (calidad, BANDWIDTH)."""
    lineas = texto.splitlines()
    candidatas = []
    for i, linea in enumerate(lineas):
        if not linea.startswith('#EXT-X-STREAM-INF:'):
            continue
        bw = re.search(r'BANDWIDTH=(\d+)', linea)
        res = re.search(r'RESOLUTION=(\d+)x(\d+)', linea)
        for siguiente in lineas[i + 1:]:
            siguiente = siguiente.strip()
            if siguiente and not siguiente.startswith('#'):
                calidad = min(int(res.group(1)), int(res.group(2))) if res else 0
                candidatas.append((calidad, int(bw.group(1)) if bw else 0,
                                   siguiente.split('#')[0]))
                break
    if not candidatas:
        return None
    usables = [c for c in candidatas if c[0] <= max_altura] or candidatas
    mejor = max(usables, key=lambda c: (c[0], c[1]))
    return urllib.parse.urljoin(master_url, mejor[2])


def _master(vid, abridor):
    """(url del master HLS, error de DM, subtítulos). La url sale de la API de metadata o, si no
    la trae, del raspado de /embed/. '' si no hay forma de obtenerla; error es el dict
    que DM devuelve cuando el vídeo no se puede ver (retirado, restringido). Los subtítulos
    vienen de la misma metadata (la vía Gujal ya los traía; la normal los perdía)."""
    url_meta = "https://www.dailymotion.com/player/metadata/video/{0}".format(
        urllib.parse.quote(vid))
    js = json.loads(_get(abridor, url_meta))
    # DM016: el autor solo deja verlo en dailymotion.com. Pedida como la web de DM
    # (igual que hace yt-dlp), la metadata suele salir; si no, el vídeo es privado y
    # la respuesta pasa a ser DM020.
    if (js.get("error") or {}).get("code") == "DM016":
        js = json.loads(_get(abridor, url_meta + "?app=com.dailymotion.neon"))
    if js.get("error"):
        return "", js["error"], []
    subs = []
    subtitulos = js.get("subtitles")
    if isinstance(subtitulos, dict):
        for lista in subtitulos.values():
            if isinstance(lista, list):
                for s in lista:
                    if isinstance(s, dict) and s.get("url"):
                        subs.append(s["url"])
    m3u8 = next((s.get("url") for s in js.get("qualities", {}).get("auto", [])
                 if s.get("type") == "application/x-mpegURL"), "")

    if not m3u8:
        html = _get(abridor, "https://www.dailymotion.com/embed/video/{0}".format(vid))
        if 'application/x-mpegURL":"' in html:
            m3u8 = html.split('application/x-mpegURL":"')[1].split('"')[0].replace("\\/", "/")

    return m3u8, None, subs


_PYTHONS = ("python", "python3", "py")


def _python_run(argumentos, timeout, texto=False):
    """Ejecuta el Python del sistema probando los lanzadores conocidos (en Windows puede
    haber solo `py`). Devuelve el CompletedProcess del primero que arranque, o None."""
    extra = {'creationflags': 0x08000000} if sys.platform.startswith('win') else {}
    for exe in _PYTHONS:
        try:
            return subprocess.run([exe] + argumentos, capture_output=True, text=texto,
                                  timeout=timeout, **extra)
        except FileNotFoundError:
            continue
        except (OSError, subprocess.SubprocessError) as e:
            _log("python del sistema ({0}): {1}".format(exe, e))
            continue
    return None


def via_sistema(vid, max_altura):
    """Resuelve con el Python del sistema, en un subproceso.

    Su pila TLS no la negocia Kodi, así que pasa el filtro de cdndirector donde el
    intérprete del addon recibe 403; es el caso de Windows. Donde no hay ningún Python
    en el PATH (Android) no arranca ninguno y no cuesta nada."""
    p = _python_run(['-c', _DM_SYSPY, vid, str(max_altura)], timeout=25, texto=True)
    if p is None:
        return None
    if p.returncode == 0 and p.stdout.strip():
        try:
            return json.loads(p.stdout).get('url') or None
        except ValueError:
            return None
    _log("python del sistema rc={0} vid={1}".format(p.returncode, vid))
    return None


def via_ytdlp(vid):
    """Resuelve con el yt-dlp del addon (nivel 3), si está instalado. URL o None."""
    try:
        import ytdlp_resolver
        info = ytdlp_resolver.resolve_full("https://www.dailymotion.com/video/{0}".format(vid))
        if info and info.get('url'):
            return info['url']
    except (ImportError, OSError, ValueError, RuntimeError) as e:
        _log("yt-dlp: {0}".format(e))
    return None


def via_resolveurl(vid):
    """Delega en ResolveURL, si está instalado. Devuelve URL o None.

    Pide metadata y master con urllib y su propio tarro de cookies, la misma receta que
    la vía 'cookies' con código de otros. Sirve si DM cambia algo y ResolveURL se
    actualiza antes que este módulo."""
    try:
        import resolveurl
    except ImportError:
        return None
    try:
        media = resolveurl.HostedMediaFile(url="https://www.dailymotion.com/video/{0}".format(vid))
        if not media.valid_url():
            return None
        return media.resolve() or None
    except (OSError, ValueError, RuntimeError) as e:
        _log("ResolveURL no pudo: {0}".format(e))
        return None


def motivo_fallo(vid, error=None):
    """Texto para el usuario cuando no se ha podido reproducir.

    Si la metadata ya dijo por qué (retirado, privado...) se usa eso; si no, se consulta
    ahora, que solo cuesta en el caso de fallo."""
    if not error:
        try:
            import requests
            r = requests.get(
                "https://www.dailymotion.com/player/metadata/video/{0}".format(vid),
                headers=HEADERS_DM, timeout=8)
            if r.status_code != 200:
                return "Dailymotion no responde (HTTP {0})".format(r.status_code)
            error = r.json().get('error')
        except (ImportError, OSError, ValueError) as e:
            _log("diagnostico {0}: {1}".format(vid, e), 'warning')
            return "Sin conexión con Dailymotion"
        if not error:
            return "Dailymotion no ha dado un stream reproducible"
    _log("vid={0} no reproducible: {1}".format(vid, error))
    codigo = error.get("code") if isinstance(error, dict) else None
    return _DM_MOTIVOS.get(codigo, "Este vídeo ya no está disponible en Dailymotion")


def liberar_decodificador():
    """Para el vídeo que siga sonando antes de resolver el nuevo.

    En Android el decodificador por hardware admite una sola instancia y Kodi la suelta
    con retraso: si alguien ve uno, pulsa Atrás (sigue de fondo) y elige otro, el nuevo
    abre solo el audio ('InstanceGuard locked'). Parándolo al empezar, la resolución
    tarda lo bastante para que se libere."""
    try:
        player = xbmc.Player()
        if player.isPlayingVideo():
            player.stop()
    except (RuntimeError, AttributeError) as e:
        _log("no se pudo parar el vídeo anterior: {0}".format(e))


def _pref_via():
    try:
        import ui_utils
        return ui_utils.load_json(_PREF_FILE, {}).get('via')
    except (ImportError, AttributeError, OSError, ValueError):
        return None


def _guardar_pref_via(nombre):
    try:
        import ui_utils
        ui_utils.save_json(_PREF_FILE, {'via': nombre})
    except (ImportError, AttributeError, OSError, ValueError):
        pass


def _niveles_gujal(vid, dm_level, max_altura):
    """Modos de Gujal. Devuelve {'url','mime','subs'} o None. No corta la cadena si
    fallan, y no acepta el master de cdndirector (lo que entregan cuando no consiguen
    la variante): Kodi lo rechazaría y las vías de abajo lo hacen mejor."""
    try:
        import dm_gujal
    except ImportError:
        return None
    try:
        if dm_level == 2:
            url, subs, mime = dm_gujal.play_dm_extreme(vid, max_quality=max_altura)
            if url and 'cdndirector' not in url:
                return {'url': url, 'mime': mime or 'application/x-mpegURL', 'subs': subs or []}
        elif dm_level == 1:
            url, mime = dm_gujal.play_dm_basic(vid)
            if url and 'cdndirector' not in url:
                return {'url': url, 'mime': mime or 'application/x-mpegURL', 'subs': []}
    except (OSError, ValueError, RuntimeError, AttributeError) as e:
        _log("dm_gujal nivel {0}: {1}".format(dm_level, e), 'warning')
    return None


def resolver_url(vid, max_altura=1080, dm_level=0):
    """Resuelve la URL de una variante HLS (o MP4 directo si lo hay) de un vídeo de DM.

    Devuelve {'url','mime','subs','headers'} o None. TODAS las vías devuelven la URL de
    una variante o None; el master NO se devuelve aquí (solo `resolver()` lo entrega
    como último recurso, cuando nadie más va a intentarlo)."""
    if not isinstance(vid, str) or not vid.strip():
        return None
    vid = vid.strip()

    if dm_level == 3:
        # yt-dlp del sistema, si el usuario lo eligió y lo tiene; si no, se sigue por la
        # vía normal (cada nivel hace algo distinto).
        url = via_ytdlp(vid)
        if url:
            return {'url': url, 'mime': '', 'subs': [], 'headers': {}}
        _log("nivel 3: yt-dlp no disponible, uso la vía normal vid={0}".format(vid))
        dm_level = 0

    if dm_level in (1, 2):
        res = _niveles_gujal(vid, dm_level, max_altura)
        if res:
            return {'url': res['url'], 'mime': res['mime'], 'subs': res['subs'], 'headers': {}}
        _log("nivel {0} sin URL, sigo por la vía normal vid={1}".format(dm_level, vid))

    abridor = _abridor()
    try:
        master, error_dm, subs = _master(vid, abridor)
    except (OSError, ValueError, RuntimeError) as e:
        _log("metadata vid={0}: {1}".format(vid, e), 'warning')
        master, error_dm, subs = "", None, []

    if error_dm:
        # Retirado o restringido: ninguna vía lo va a resolver.
        return None

    max_q = max_altura
    vias = [
        ('cookies', lambda: elegir_variante(master, _get(abridor, master), max_q) if master else None),
        ('requests', lambda: _via_requests(master, max_q)),
        ('resolveurl', lambda: via_resolveurl(vid)),
        ('sistema', lambda: via_sistema(vid, max_q)),
    ]
    preferida = _pref_via()
    if preferida:
        vias.sort(key=lambda v: v[0] != preferida)
    for nombre, obtener in vias:
        try:
            url = obtener()
        except (OSError, ValueError, RuntimeError, TypeError) as e:
            _log("via '{0}': {1}".format(nombre, e))
            url = None
        if url:
            if nombre != preferida:
                _log("vid={0}: resuelto por via '{1}'".format(vid, nombre))
                _guardar_pref_via(nombre)
            return {'url': url, 'mime': 'application/x-mpegURL', 'subs': subs, 'headers': {}}

    return None


def _via_requests(master, max_altura):
    """Variante del master con requests. Pasa en Android, no en el Python de Kodi de Windows."""
    if not master:
        return None
    try:
        import requests
        r = requests.get(master, headers=HEADERS_DM, timeout=10)
        if r.status_code != 200:
            return None
        return elegir_variante(master, r.text, max_altura)
    except (ImportError, OSError, ValueError) as e:
        _log("requests: {0}".format(e))
        return None


def _reproducir(url, mime=''):
    """Manda al reproductor una URL ya resuelta y devuelve True.

    `mime` es el tipo que anuncia la vía que la resolvió (un MP4 directo de Gujal no es
    HLS); si no se da, se adivina por la extensión."""
    import xbmcgui
    import xbmcplugin
    li = xbmcgui.ListItem(path=url)
    if mime:
        li.setMimeType(mime)
    elif '.m3u8' in url.split('|')[0]:
        li.setMimeType('application/x-mpegURL')
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(int(sys.argv[1]), True, listitem=li)
    return True


def resolver(vid, cfg=None, cerrar_si_falla=True):
    """Resuelve un vídeo de DM y lo manda al reproductor. Devuelve True si lo logró.

    `cerrar_si_falla=False` lo deja sin resolver y sin avisar, para que quien llama pueda
    seguir probando otros métodos: Kodi solo admite un setResolvedUrl por reproducción y
    cerrarlo aquí dejaría fuera al resto."""
    cfg = cfg or {}
    max_altura = cfg.get('dm_max_quality', 1080)
    dm_level = cfg.get('dm_safe_level', 0)
    # Deja libre el decodificador del vídeo anterior (Android) antes de resolver.
    liberar_decodificador()

    import xbmcgui
    import xbmcplugin

    error_dm = None
    try:
        res = resolver_url(vid, max_altura, dm_level)
        if res and res.get('url'):
            return _reproducir(res['url'], res.get('mime', ''))

        # Último recurso, y solo si nadie más va a intentarlo después: el master tal cual.
        # Kodi lo rechaza a menudo, pero cuando DM no aprieta el filtro reproduce.
        if cerrar_si_falla:
            abridor = _abridor()
            try:
                master, error_dm, _ = _master(vid, abridor)
            except (OSError, ValueError, RuntimeError):
                master = ""
            if master:
                _log("vid={0}: sin variante por ninguna via, entrego el master".format(vid), 'warning')
                return _reproducir(master)
    except (OSError, ValueError, RuntimeError) as e:
        _log("resolver {0}: {1}".format(vid, e), 'warning')

    if cerrar_si_falla:
        xbmcplugin.setResolvedUrl(int(sys.argv[1]), False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification("EspaTV", motivo_fallo(vid, error_dm),
                                      xbmcgui.NOTIFICATION_ERROR, 5000)
    return False


# --- Compatibilidad: parser de variantes que usaba default.py/download_manager ---------------

def _fetch_master_direct(url, timeout=15):
    try:
        import requests
        r = requests.get(url, headers=HEADERS_DM, timeout=timeout)
        if r.status_code == 200 and r.text:
            return r.text
        _log("direct status={0}".format(r.status_code), 'warning')
    except (OSError, ValueError) as exc:
        _log("direct exception: {0}".format(exc), 'warning')
    return None


def _fetch_master_warmup(url, timeout=15):
    try:
        import requests
        s = requests.Session()
        s.get("https://www.dailymotion.com/", headers=HEADERS_DM, timeout=timeout)
        r = s.get(url, headers=HEADERS_DM, timeout=timeout)
        if r.status_code == 200 and r.text:
            return r.text
        _log("warmup status={0}".format(r.status_code), 'warning')
    except (OSError, ValueError) as exc:
        _log("warmup exception: {0}".format(exc), 'warning')
    return None


def _fetch_master_subprocess(url, timeout=20):
    # Vale en cualquier plataforma con python en el PATH: es la única vía cuyo TLS no
    # lo negocia el intérprete de Kodi. En Android no arranca ningún lanzador.
    script = (
        "import sys,urllib.request\n"
        "u=sys.argv[1]\n"
        "h={'User-Agent':'Mozilla/5.0','Referer':'https://www.dailymotion.com/'}\n"
        "r=urllib.request.urlopen(urllib.request.Request(u,headers=h),timeout=15)\n"
        "sys.stdout.buffer.write(r.read())\n"
    )
    p = _python_run(['-c', script, url], timeout=timeout)
    if p and p.returncode == 0 and p.stdout:
        text = p.stdout.decode('utf-8', errors='replace')
        if text:
            return text
    return None


def _fetch_master(master_url, abridor=None):
    """Un master válido debe contener #EXT-X-STREAM-INF. Con `abridor` se prueba primero
    urllib con las cookies de la metadata (pasa en Windows y Android)."""
    estrategias = [_fetch_master_direct, _fetch_master_warmup, _fetch_master_subprocess]
    if abridor is not None:
        estrategias.insert(0, lambda u: _get(abridor, u))
    for strategy in estrategias:
        try:
            text = strategy(master_url)
        except (OSError, ValueError):
            text = None
        if text and '#EXT-X-STREAM-INF' in text:
            return text
    return None


def fetch_hls_variants(master_url, headers=None, abridor=None):
    """Variantes del master ordenadas por bitrate (de mayor a menor).

    `headers` se ignora (se usan HEADERS_DM); se mantiene por compatibilidad. `abridor`
    es el opener con el que se pidió la metadata, si se tiene."""
    text = _fetch_master(master_url, abridor)
    if not text:
        return []

    variants = []
    current_bw = 0
    current_res = ''
    expecting = False
    for line in text.splitlines():
        line = line.strip()
        if not line:
            continue
        if line.startswith('#EXT-X-STREAM-INF'):
            bw_m = re.search(r'BANDWIDTH=(\d+)', line)
            res_m = re.search(r'RESOLUTION=(\d+x\d+)', line)
            current_bw = int(bw_m.group(1)) if bw_m else 0
            current_res = res_m.group(1) if res_m else ''
            expecting = True
        elif expecting and not line.startswith('#'):
            url = line if line.startswith('http') else urllib.parse.urljoin(master_url, line)
            url = url.split('#')[0]
            variants.append({'label': current_res, 'url': url, 'bandwidth': current_bw,
                             'resolution': current_res})
            expecting = False
    variants.sort(key=lambda x: x['bandwidth'], reverse=True)
    return variants
