# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Sección X (+18): Eporner, RedTube y Pornhub dentro de EspaTV.

UI y almacenamiento. La red está en `xxx_api.py`, que no importa nada de Kodi.

Decisiones que no son obvias y están razonadas en docs/15_seccion_x.md:

- **Almacenamiento propio** (`xxx_settings.json`, `xxx_favs.json`, `xxx_hist.json`) en vez de
  `core_settings.get_favorites()` o `watch_history.py`: aquellos son de secciones y de
  Dailymotion respectivamente, y un favorito de vídeo saldría sin carátula y se abriría como
  carpeta. Aquí además los títulos no se cuelan en las búsquedas de torrents que el contexto de
  favoritos de EspaTV hace con cualquier favorito.
- **PIN antes que +18**: al revés que el addon de origen. No tiene sentido exigir la
  confirmación de edad a quien aún no ha entrado.
- **El PIN es una puerta al canal de Telegram, no seguridad.** 4 dígitos publicados en un canal
  son 10.000 combinaciones que conoce cualquiera que se apunte. Se pone límite de intentos, pero
  el texto no vende una protección que no hay.
- **Menús sin `setContent`**: con contenido vacío el skin pinta `ListItem.Icon` en la fila; con
  contenido, no. Solo los listados de vídeos lo fijan. Y `SetViewMode` solo por `AlarmClock`.
"""
import datetime
import hashlib
import hmac
import json
import os
import re
import secrets
import sys
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

import ui_utils
import xxx_api as api
from _user_agents import ua_desktop_pipe_encoded

NOMBRE = "Sección X"
URL_CANAL = "https://t.me/espadaily"
PIN_INICIAL = "9126"
MAX_FALLOS = 3

FICH_AJUSTES = "xxx_settings.json"
FICH_FAVS = "xxx_favs.json"
FICH_HIST = "xxx_hist.json"
MAX_HIST = 100

# El PIN de la sesión y los intentos fallidos viven en propiedades de la ventana, NO en disco.
# En disco el bloqueo era acumulativo entre sesiones y, como el único reset estaba detrás de
# la propia puerta, tres fallos dejaban la sección inservible para siempre con un diálogo que
# prometía lo contrario. En una propiedad, "hasta reiniciar Kodi" es literalmente verdad.
PROP_UNLOCK = "espatv.xxx_unlock"
PROP_FALLOS = "espatv.xxx_fallos"

# Versión del formato de `xxx_settings.json`. Se graba con cada guardado. Sirve para la
# migración del `pin_on` que se explica en `_cfg()`: un fichero SIN este número es anterior,
# y su `pin_on` (que era "entrar" por defecto entonces) se descarta.
VER_AJUSTES = 2

_AJUSTES = {
    "per_page": 20,
    "thumbsize": "big",
    "order": "latest",
    "gay": 0,
    "quality": "max",
    "timeout": 15,
    "adult_confirm": True,
    "adult_ok": False,
    # Por defecto, una vez por sesión de Kodi (en Ajustes: "al entrar" o "nunca").
    "pin_on": "sesion",
    # Se graba con cada guardado; ver la migración del `pin_on` en `_cfg()`. No es un ajuste
    # que se pueda cambiar desde un botón, por eso no está en OPCIONES.
    "v_ajustes": VER_AJUSTES,
    "vista": "wide",
    # Callar el log de la sección. Por defecto ESTÁ PUESTO: lo que se
    # arregla con el log es que no había ninguno, y sin él un 403 por
    # rate-limit, un 404 de vídeo despublicado y un timeout son lo mismo.
    # Quien lo apaga lo hace a propósito: para eso está el botón.
    "log_on": True,
    "pin_hash": "",
    "pin_salt": "",
    # True SOLO si el usuario ha puesto su propio PIN con `cambiar_pin()`. Mientras sea False
    # el PIN que se pide es el de Telegram, que es PUBLICO, y por eso `menu()` le recuerda al
    # entrar que hay que cambiarlo.
    #
    # Hace falta el marca porque `pin_hash` no lo dice: antes `pin_gate()` sembraba la huella
    # del codigo de Telegram en la primera entrada, asi que despues no habia forma de saber si
    # lo que habia ahi era el codigo publico o uno que el usuario habia elegido a proposito
    # (que puede querer, por ejemplo). Con este campo la pregunta tiene respuesta.
    #
    # No está en OPCIONES porque no se cambia con un botón: lo pone `cambiar_pin()` al terminar,
    # y a False no se vuelve (cambiar el PIN no es volver al público).
    "pin_propio": False,
}

# Los 9 iconos de dentro de la sección (buscar, categorías, favoritos, historial, ajustes,
# siguiente, y uno por plataforma). Sus nombres tienen que aparecer aquí literal:
# tools/generar_web_iconos.py --check cuenta como "sin usar" los iconos que solo se citan en
# tools/, y falla si pasan del 10 %.
ICO_BUSCAR = "xxx_buscar.png"
ICO_CATEGORIAS = "xxx_categorias.png"
ICO_FAVORITOS = "xxx_favoritos.png"
ICO_HISTORIAL = "xxx_historial.png"
ICO_AJUSTES = "xxx_ajustes.png"
ICO_SIGUIENTE = "xxx_siguiente.png"
ICO_EPORNER = "xxx_eporner.png"
ICO_REDTUBE = "xxx_redtube.png"
ICO_PORNHUB = "xxx_pornhub.png"

# Son búsquedas: la API no tiene endpoint de categorías. Copiadas de plugin.video.epornerxxx
# (main.py:66 `CATEGORIES`), en su orden.
CAT_EPORNER = (
    "Amateur", "Anal", "Asian", "BBW", "BDSM", "Big Tits", "Blonde", "Blowjob",
    "Brunette", "Compilation", "Creampie", "Cumshot", "Ebony", "Fetish", "Gangbang",
    "Hardcore", "Hentai", "Interracial", "Japanese", "Latina", "Lesbian", "Milf",
    "Orgy", "POV", "Public", "Teen", "Threesome", "Vintage",
)

# En Pornhub no hay endpoint de categorías: estos botones son búsquedas predefinidas.
BUSQUEDAS_PH = (
    ("Español", "spanish"),
    ("Latina", "latina"),
    ("Amateur", "amateur"),
    ("Joven", "teen"),
    ("Madre de familia", "milf"),
    ("Anal", "anal"),
    ("Tetas grandes", "big tits"),
    ("Masturbación", "blowjob"),
    ("Lesbian", "lesbian"),
    ("Threesome", "threesome"),
    ("Hentai", "hentai"),
    ("Japonés", "japanese"),
    ("Moreno", "ebony"),
    ("Maduro", "mature"),
    ("Creampie", "creampie"),
    ("POV", "pov"),
)

# Copiadas de plugin.video.epornerxxx (main.py:53 `RT_CATEGORIES`). La API devuelve 111,
# disponibles en `api.cats_redtube()`.
CATS_RT = (
    "Amateur", "Anal", "Asian", "Big Ass", "Big Dick", "Big Tits", "Blonde", "Blowjob",
    "Brunette", "Compilation", "Creampie", "Cumshot", "Ebony", "Fetish", "Gangbang",
    "Group", "Hardcore", "Hentai", "Interracial", "Japanese", "Latina", "Lesbian",
    "Mature", "MILF", "Orgy", "POV", "Redhead", "Teens", "Threesome", "Vintage",
)

# Mapeo de ordenación de RedTube hacia los parámetros de su API.
# La API de RedTube aplica ordenación y periodos cuando la consulta incluye
# un término de búsqueda; se envían para mantener consistencia en la navegación.
ORDENES_RT = (("latest", "Últimos", "newest", None),
              ("most-popular", "Más vistos", "mostviewed", None),
              ("top-weekly", "Top semanal", "mostviewed", "weekly"),
              ("top-monthly", "Top mensual", "mostviewed", "monthly"))

# Categorías de RedTube con temática homosexual en su catálogo.
# El parámetro de contenido gay de ajustes aplica a Eporner; en RedTube se muestra
# un aviso informativo al acceder.
CATS_GAY_RT = ("Bisexual Male", "Bisexual", "Transgender", "Shemale",
               "Solo Male", "Muscle")

ORDENES = (("latest", "Últimos"),
           ("top-weekly", "Top semanal"),
           ("top-monthly", "Top mensual"),
           ("most-popular", "Más vistos"))

# El addon de origen los tiene como `slider` con `range="10,30"` y `range="5,30"`, o sea 21 y
# 26 valores (settings.xml:30010 y 30015). Aquí eran cinco escalones cada uno: más manejable con
# el botón, pero más estrecho. Se recuperan los rangos enteros del origen.
PAGINAS = tuple(range(10, 31))
MINIATURAS = (("small", "Pequeñas"), ("medium", "Medianas"), ("big", "Grandes"))
CALIDADES = (("max", "Máxima"), ("ahorro", "Ahorro de datos"))
TIEMPOS = tuple(range(5, 31))
MODOS_PIN = (("entrar", "Al entrar en la sección"),
             ("sesion", "Una vez por sesión (empieza aquí)"),
             ("nunca", "Nunca"))
# Opciones del filtro: en Eporner gay=0 excluye contenido gay y gay=2 selecciona exclusivamente
# contenido gay. En Pornhub el filtrado se realiza por el campo segment de cada vídeo.
GAY_OPCIONES = ((0, "No (ocultar el contenido gay)"), (2, "Sí, solo contenido gay"))
# Vista de los menús de la sección (los de carpetas). El addon de origen forzaba la 55
# (WideList) sin dar opción: ahí las filas se veían con su icono y su descripción. Aquí es un
# ajuste, que es mejor que forzar y encima sin opción.
VISTAS = (("wide", "WideList (icono grande)"), ("skin", "La que trae el skin"))
# La 55 de los skins de Kodi por defecto (Estuary y compañía): la de lista ancha, con icono a
# la izquierda y el texto a la derecha. Si el skin del usuario no la tiene, Kodi cae en la suya
# sin romperse.
VIEW_WIDE = 55
ALARMA_VISTA = "espatv_xxx_vista"


def _log(msg, level=None):
    # Ni títulos ni URLs firmadas en el log: solo el motivo de un fallo.
    #
    # Respeta el ajuste 'Avisos en el log de Kodi' (log_on) mediante api._log_puesto()
    # para sincronizar el filtrado de trazas con la capa de API.
    if not api._log_puesto():
        return
    xbmc.log("[EspaTV-XXX] {0}".format(msg), xbmc.LOGDEBUG if level is None else level)


def _notifica(msg, heading=NOMBRE):
    try:
        xbmcgui.Dialog().notification(heading, msg, xbmcgui.NOTIFICATION_INFO, 4000)
    except Exception:
        pass


def _h():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1


def _u(**kw):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kw)


def _ico(nombre):
    return ui_utils.media_icon(nombre) or nombre


def _cierra(handle, succeeded=True):
    """`endOfDirectory` SOLO si hay un handle de verdad.

    Estas acciones llegan de dos maneras: desde un listado (handle >= 0, y entonces cerrar el
    directorio es lo correcto) y desde el menú contextual, que las lanza con `RunPlugin` y por
    tanto con handle -1. Ahí `endOfDirectory(-1)` no hace nada útil y deja un error en el log de
    Kodi.
    """
    try:
        h = int(handle)
    except (TypeError, ValueError):
        return
    if h < 0:
        return
    try:
        xbmcplugin.endOfDirectory(h, succeeded=succeeded)
    except Exception:
        pass


def _no_resuelto(handle):
    """Indica a Kodi que la reproducción no ha salido, tal como lo espera.

    Una fila de esta sección es `IsPlayable`, así que Kodi la abre para reproducir con un
    handle válido. Lo que espera cuando la resolución falla es
    `setResolvedUrl(h, False, ListItem())`: con eso sabe que no hay nada que reproducir y
    vuelve a la lista.

    Antes se cerraba el directorio con `endOfDirectory(succeeded=False)`, adecuado
    para carpetas pero no para elementos reproducibles, dejando la selección sin
    respuesta visible ni resolución en Kodi.

    Con handle -1 (la acción escrita a mano en la URL, o llegada de un `RunPlugin`)
    `setResolvedUrl` rechaza el handle («Invalid handle -1»), así que ahí no se hace nada:
    no hay a quién decírselo. Es el mismo criterio que `_cierra()`.
    """
    try:
        h = int(handle)
    except (TypeError, ValueError):
        return
    if h < 0:
        return
    try:
        xbmcplugin.setResolvedUrl(h, False, listitem=xbmcgui.ListItem())
    except Exception:
        pass


# ------------------------------------------------------------- almacenamiento
def _cfg():
    """Ajustes con los valores por defecto rellenados. Tolerante a JSON roto o no-dict.

    MIGRACIÓN DE `pin_on` (2026-10-04). El ajuste se guardaba en cuanto se entraba una vez, así
    que en toda instalación existente hay un `"pin_on": "entrar"` escrito en disco que sigue
    mandando sobre el valor por defecto del código: cambiar el `_AJUSTES` no arregla nada por
    sí solo. Aquí se distingue "guardado por alguien" de "grabado por el valor de entonces":

    · `_v_ajustes` es un número que se graba con cada guardado. Si el fichero guardado NO lo
      tiene, es un fichero anterior a esta migración, y su `pin_on` se descarta: se usa el
      valor por defecto actual ("sesion", una vez por sesión).
    · Un `pin_on` que alguien haya cambiado DESPUÉS de esta migración se respeta siempre,
      porque su fichero ya lleva `_v_ajustes`.

    Es una migración de una sola vez: al guardar cualquier vez, el fichero queda versionado y
    a partir de ahí manda lo que el usuario elija.
    """
    datos = ui_utils.load_json(FICH_AJUSTES, {})
    if not isinstance(datos, dict):
        datos = {}
    out = dict(_AJUSTES)
    for k, v in _AJUSTES.items():
        if k in datos:
            out[k] = datos[k]

    # `pin_hash` y `pin_salt` SI se sanean, y no por precaución sino porque sin esto la
    # seccion se queda COLGADA. Es lo unico que `_cfg()` no puede dejar pasar:
    #
    # · `hmac.compare_digest()` exige dos `str`. Con un `pin_hash` entero salta
    #   `TypeError: unsupported operand types`, y con uno no-ASCII,
    #   `comparing strings with non-ASCII characters is not supported`.
    # · La comparacion de versiones de la migracion de mas abajo usa `<`, y con un `pin_hash`
    #   entero salta `TypeError: '<' not supported between instances of 'str' and 'int'`, que es
    # Sanea las claves del PIN para evitar excepciones de tipo si el archivo fue modificado.
    for _k in ("pin_hash", "pin_salt"):
        _v = out.get(_k)
        if not (isinstance(_v, str) and _v.isascii()):
            out[_k] = ""
    # `v_ajustes` también se sanea para evitar que valores no enteros fuercen la migración
    # en cada lectura. Al sanearlo a la versión actual tras migrar, los siguientes guardados
    # persisten la versión correcta y respetan la configuración elegida.
    _va = datos.get("v_ajustes")
    _va_entero = isinstance(_va, int) and not isinstance(_va, bool) and _va >= 0
    if not _va_entero:
        out["v_ajustes"] = VER_AJUSTES
    # Migración del `pin_on`: un fichero ANTERIOR a esta migración (sin `v_ajustes`, o con una
    # versión más vieja) tenía un "entrar" grabado que se descartaba; a partir del primer
    # guardado, el fichero lleva versión y manda lo que elija el usuario.
    #
    # OJO: la comparación es `<` y no `!=` a propósito. Con `!=`, cuando esta migración pase a
    # VER_AJUSTES = 3, un fichero que el usuario guardó CON la 2 (y su `pin_on` elegido a
    # propósito) se leería como "no es el de ahora" y su `pin_on` se descartaría otra vez, sin
    # avisar: justo lo que arregla esta migración volvería a romperse en silencio. Con `<`, solo
    # se toca lo que es de verdad más viejo.
    if (not _va_entero or _va < VER_AJUSTES) and "pin_on" in datos:
        out["pin_on"] = _AJUSTES["pin_on"]
    # Valores imposibles: cada botón tiene su lista, y aquí se recorta a lo que existe.
    if out["per_page"] not in PAGINAS:
        out["per_page"] = _AJUSTES["per_page"]
    if out["thumbsize"] not in [k for k, _ in MINIATURAS]:
        out["thumbsize"] = _AJUSTES["thumbsize"]
    if out["order"] not in [k for k, _ in ORDENES]:
        out["order"] = _AJUSTES["order"]
    if out["gay"] not in [k for k, _ in GAY_OPCIONES]:
        out["gay"] = _AJUSTES["gay"]
    if out["quality"] not in [k for k, _ in CALIDADES]:
        out["quality"] = _AJUSTES["quality"]
    if out["timeout"] not in TIEMPOS:
        out["timeout"] = _AJUSTES["timeout"]
    if out["pin_on"] not in [k for k, _ in MODOS_PIN]:
        out["pin_on"] = _AJUSTES["pin_on"]
    if out["vista"] not in [k for k, _ in VISTAS]:
        out["vista"] = _AJUSTES["vista"]
    out["per_page"] = int(out["per_page"])
    out["timeout"] = int(out["timeout"])
    out["gay"] = int(out["gay"])
    return out


def _fallos():
    """Intentos fallidos en ESTA sesión. Cero si la propiedad no está o está corrupta."""
    try:
        return int(xbmcgui.Window(10000).getProperty(PROP_FALLOS) or 0)
    except Exception:
        return 0


def _suma_fallo():
    n = _fallos() + 1
    try:
        xbmcgui.Window(10000).setProperty(PROP_FALLOS, str(n))
    except Exception:
        pass
    return n


def _limpia_fallos():
    try:
        xbmcgui.Window(10000).setProperty(PROP_FALLOS, "0")
    except Exception:
        pass


def _guardar_cfg(cfg):
    """Guarda los ajustes y DICE si se escribieron.

    Devuelve el resultado de la escritura para que `cambiar_pin()`, que tiene algo que
    prometer, no lo prometa en falso. Antes se descartaba: un fallo de disco (perfil sin
    permisos, disco lleno) dejaba el PIN viejo en vigor con un "PIN cambiado" en pantalla."""
    return ui_utils.save_json(FICH_AJUSTES, cfg)


def _ruta_lista(fich):
    """La ruta absoluta de un fichero de la sección, o "" si no se puede sacar."""
    try:
        ruta = ui_utils.get_path(fich)
        return ruta if isinstance(ruta, str) else ""
    except Exception:
        return ""


def _carga_lista(fich):
    """El JSON del fichero, o `[]`. Si está roto se aparta, no se pisa.

    `ui_utils.load_json()` devuelve el valor por defecto cuando el JSON no parsea, así que con
    el fichero roto `_leer_lista()` devolvía `[]` y el siguiente guardado escribía la lista
    vacía encima: **todos los favoritos o el historial entero, perdidos sin aviso**. Se aparta
    como `<fichero>.corrupt-<hora>`, que es lo que hace `fuentes_store._lee()` con el almacén
    de servidores, y así queda para que se pueda mirar qué había dentro.

    Un `OSError` **no** es corrupión, y esta es la parte fina: en Windows es lo normal cuando
    otro proceso está reemplazando el fichero en ese instante, y también lo que hace un antivirus
    que lo abre. Apostar por «está roto» renombraba el fichero BUENO y hacía que el guardado
    siguiente escribiera la lista vacía encima. Es la misma distinción que hace
    `fuentes_store._lee()`, y allí está explicada con más detalle.
    """
    ruta = _ruta_lista(fich)
    if not ruta:
        return ui_utils.load_json(fich, [])
    try:
        with open(ruta, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return []
    except ValueError as e:
        _log("{0} ilegible ({1}), se aparta".format(fich, e), xbmc.LOGWARNING)
        try:
            os.replace(ruta, "{0}.corrupt-{1}".format(ruta, int(time.time())))
        except OSError:
            pass
        _notifica("El fichero {0} estaba dañado: se ha apartado y se empieza de "
                  "cero.".format(fich))
        return []
    except OSError:
        return ui_utils.load_json(fich, [])


def _leer_lista(fich, tope=0):
    """Lee favoritos o historial y deja solo dicts con id, con los tipos que espera el resto.

    Los dos ficheros son MERGEABLES: entran importando un .zip de otra máquina o de otra
    versión del addon, y ahí los tipos pueden ser lo que quiera. Con `title` entero,
    `"\n".join` reventaba con TypeError, y como `favoritos()` e `historial()` pintan las filas
    sin `try`, el directorio se quedaba sin cerrar: pantalla colgada. Con `views` a `inf` (JSON
    lo parsea) reventaba el `_numero`/`formatea_vistas`. Aquí se normaliza una vez.

    Si el JSON está roto, el fichero se aparta en vez de pisarse. Ver
    `_carga_lista()`.
    """
    datos = _carga_lista(fich)
    if not isinstance(datos, list):
        return []
    salida = []
    for d in datos:
        if not isinstance(d, dict) or not d.get("id"):
            continue
        d = dict(d)
        d["id"] = str(d.get("id") or "")
        d["src"] = str(d.get("src") or "")
        d["title"] = str(d.get("title") or d["id"])
        d["thumb"] = api.fix_thumb(d.get("thumb"))
        # `length` y `added` solo se guardan si son cadenas. Con `str(...)` a secas, un dict en
        # `length` salia como "Duracion: {'a': 1}" en la etiqueta de la fila.
        d["length"] = d.get("length") if isinstance(d.get("length"), str) else ""
        d["added"] = d.get("added") if isinstance(d.get("added"), str) else ""
        # `page` viaja en las filas para "Abrir en la web": si un JSON importado trae una lista
        # o un número, `_u()` lo urlencodearía raro. Se sanea aquí, como `length` y `added`.
        d["page"] = d.get("page") if isinstance(d.get("page"), str) else ""
        d["views"] = _numero(d.get("views"))
        d["rate"] = _numero(d.get("rate"))
        d["length_sec"] = _numero(d.get("length_sec"))
        if d.get("keywords") and not isinstance(d.get("keywords"), list):
            d["keywords"] = []
        salida.append(d)
    return salida[:tope] if tope else salida


def _guardar_lista(fich, items):
    """Como `_guardar_cfg`: guarda y devuelve si de verdad se escribió, para que quien avise
    ("Guardado en favoritos.") pueda enterarse de un fallo de disco en vez de prometerlo."""
    return ui_utils.save_json(fich, items)


def _clave(src, vid):
    return "{0}:{1}".format(src, vid)


def _claves_favoritos():
    """Claves (src:id) guardadas. Se lee UNA vez por pantalla y se pasa a _fila_video: antes
    se abría y parseaba xxx_favs.json por cada fila, que con 200 favoritos son 200 lecturas."""
    return set(_clave(f.get("src", ""), f.get("id", ""))
               for f in _leer_lista(FICH_FAVS) if f.get("id"))


def _pagina(valor):
    """Page de la URL a entero, sin reventar si viene algo raro: si no, el directorio se
    queda sin cerrar y la pantalla queda colgada."""
    try:
        return max(1, int(valor))
    except (TypeError, ValueError):
        return 1


# --------------------------------------------------------------------- PIN
def _hash(pin, salt):
    return hashlib.sha256((str(pin) + str(salt)).encode("utf-8")).hexdigest()


def _es_pin_publico(cfg):
    """True si el PIN que hay ahora mismo sigue siendo el del canal de Telegram."""
    return not bool(cfg.get("pin_propio"))


def _pin_correcto(cfg, tecleado):
    """Comprueba el PIN tecleado contra el que toca.

    El flag manda, no el hash. Mientras `pin_propio` sea False se compara con `PIN_INICIAL` en
    claro, aunque haya un `pin_hash` guardado: ese hash lo sembró `pin_gate()` con el codigo
    publico, así que compararlo contra su propia huella sería lo mismo y mucho más difícil de
    leer. Con `pin_propio` a True, la comparación es contra el hash, como siempre.
    """
    tecleado = str(tecleado).strip()
    # `hmac.compare_digest()` con dos `str` lanza TypeError si alguno contiene caracteres
    # no-ASCII. Se rechaza directamente cualquier valor con caracteres no-ASCII para evitar fallos.
    if not tecleado.isascii():
        return False
    if _es_pin_publico(cfg):
        return hmac.compare_digest(tecleado, PIN_INICIAL)
    if not cfg.get("pin_hash"):
        # `pin_propio` a True pero sin hash es un fichero manipulado. Se cae al de Telegram:
        # mejor una puerta que funciona que una sección cerrada.
        return hmac.compare_digest(tecleado, PIN_INICIAL)
    return hmac.compare_digest(_hash(tecleado, cfg.get("pin_salt", "")),
                               cfg.get("pin_hash", ""))


def _pin_aceptable(pin):
    """True si `pin` está compuesto exactamente por 4 dígitos ASCII (0-9).

    Descarta dígitos Unicode de ancho completo u otros alfabetos numéricos
    para asegurar coherencia con la verificación del hash en `_pin_correcto()`.
    """
    return isinstance(pin, str) and len(pin) == 4 and pin.isascii() and pin.isdigit()


def _aviso_pin_publico(cfg):
    """El texto del recordatorio, o "" si el PIN ya es del usuario."""
    if not _es_pin_publico(cfg):
        return ""
    return ("El PIN de esta sección sigue siendo el público del canal de Telegram "
            "[B]t.me/espadaily[/B]. Para cambiarlo por uno propio, ve a "
            "[B]Ajustes · PIN de la sección[/B].")




def _pedir_pin(cfg):
    """Diálogo del PIN. True = puede entrar.

    La explicación se enseña en `_explica_el_pin()`, una vez por sesión, porque
    `Dialog.select()` no admite texto explicativo.

    Los intentos van en el título del `select` y se recalculan en cada vuelta: es el diálogo
    que se queda en pantalla para decidir si seguir intentando.

    Sin etiquetas de color en el título a propósito: `Dialog::select()` pinta la cabecera
    como etiqueta de control y no está claro que interprete el `[COLOR]`. Un «último
    intento» en texto plano se lee seguro; uno con la etiqueta mal puesta, no.
    """
    _explica_el_pin()
    opciones = ["Escribir el PIN", "No lo sé, abrir el canal", "Salir"]
    while True:
        intentos = max(0, MAX_FALLOS - _fallos())
        if intentos > 1:
            titulo = '{0}: {1} intentos'.format(NOMBRE, intentos)
        elif intentos == 1:
            titulo = '{0}: último intento'.format(NOMBRE)
        else:
            titulo = '{0}: sin intentos'.format(NOMBRE)
        sel = xbmcgui.Dialog().select(titulo, opciones)
        if sel < 0 or sel == 2:
            return False
        if sel == 1:
            abrir_canal()
            continue
        # numeric() y no input(INPUT_NUMERIC): en Dialog.cpp esa rama llama a
        # ShowAndGetNumber() e ignora `option` (y 1 es PASSWORD_VERIFY, no ocultar), así que
        # los dígitos se ven. numeric(0..., bHiddenInput=True) sí los enmascara.
        tecleado = xbmcgui.Dialog().numeric(0, NOMBRE + " | PIN", '', True)
        if not tecleado:
            continue
        if _pin_correcto(cfg, tecleado):
            return True
        restantes = MAX_FALLOS - _suma_fallo()
        if restantes <= 0:
            xbmcgui.Dialog().ok(
                NOMBRE,
                "PIN incorrecto. Has agotado los {0} intentos de esta sesión.\n\n"
                "El resto de EspaTV sigue funcionando. Si crees que el PIN es correcto, "
                "compruébalo en el canal de Telegram (t.me/espadaily): en cuanto salgas de la "
                "sección te dejará volver a intentarlo.".format(MAX_FALLOS))
            return False
        xbmcgui.Dialog().ok(
            NOMBRE,
            "PIN incorrecto. " + ("Te queda 1 intento." if restantes == 1
                                  else "Te quedan {0} intentos.".format(restantes)))


def pin_gate(raiz=False):
    """Puerta del PIN. False = no se entra en la sección.

    `raiz=True` solo la llama menu(), y es lo que hace que el modo "al entrar" vuelva a
    preguntar cada vez que se abre la sección. El resto de pantallas (plataforma, listado,
    buscador, ajustes) pasan con el desbloqueo de la sesión: si no lo hay, es que se ha entrado
    por un atajo y se pregunta.
    """
    cfg = _cfg()
    if cfg["pin_on"] == "nunca":
        return True
    desbloqueado = False
    try:
        desbloqueado = xbmcgui.Window(10000).getProperty(PROP_UNLOCK) == "1"
    except Exception:
        pass
    if desbloqueado and not (raiz and cfg["pin_on"] == "entrar"):
        return True
    if _fallos() >= MAX_FALLOS:
        # Nadie se queda fuera para siempre por tres erratas. Antes esto solo se levantaba
        # reiniciando Kodi... y como el reinicio no lo levantaba, era un cierre sin salida.
        # Ahora se ofrece reintentar, que borra el contador de la sesión y vuelve a preguntar.
        if not xbmcgui.Dialog().yesno(
                NOMBRE,
                "Has usado los {0} intentos del PIN en esta sesión.\n\n"
                "El PIN está en el canal de Telegram (t.me/espadaily).\n\n"
                "El resto de EspaTV sigue funcionando. ¿Quieres volver a intentarlo?".format(
                    MAX_FALLOS),
                nolabel="Salir", yeslabel="Volver a intentarlo"):
            return False
        _limpia_fallos()
    if not _pedir_pin(cfg):
        return False
    _limpia_fallos()
    # Aquí antes se sembraba `pin_hash` con la huella del código de Telegram, para no tener que
    # guardarlo en claro. Con `pin_propio` ya no hace falta: mientras el PIN sea el público se
    # compara contra `PIN_INICIAL` directamente (ver `_pin_correcto`), y la huella solo existe si
    # el usuario ha puesto un PIN suyo. Sembrarla convertía "el PIN público" en un hash
    # indistinguible del de un PIN elegido a propósito.
    try:
        xbmcgui.Window(10000).setProperty(PROP_UNLOCK, "1")
    except Exception:
        pass
    return True


def cambiar_pin():
    """Fija el PIN que elija el usuario. Nunca se guarda en claro, solo su hash con sal.

    No se pide el PIN actual: para llegar aquí ya se ha pasado el de la sección.

    Es a propósito y no un olvido: es la única de las 22 acciones del addon de referencia que
    aquí NO lleva `pin_gate()` (él las lleva todas, `main.py:1168-1171`).
    """
    # numeric() por lo mismo que en _pedir_pin().
    tecleado = xbmcgui.Dialog().numeric(0, NOMBRE + " | PIN nuevo (4 dígitos)", '', True)
    if not tecleado:
        return
    pin = str(tecleado).strip()
    if not _pin_aceptable(pin):
        # OJO: `isdigit()` a secas admitía dígitos no ASCII (de ancho completo, de otras
        # alfabetos) que `_pin_correcto()` rechaza siempre. Aceptarlos guardaba un PIN
        # imposible de teclear y apagaba el de Telegram: la sección quedaba cerrada. Ver
        # `_pin_aceptable()`, y la nota de por qué no se "normalizan" los caracteres raros.
        xbmcgui.Dialog().ok(NOMBRE, "El PIN tiene que tener 4 dígitos normales, del 0 al 9. "
                                    "Los de ancho completo y los de otras escrituras no valen.")
        return
    otra = xbmcgui.Dialog().numeric(0, NOMBRE + " | Repite el PIN", '', True)
    if str(otra or "").strip() != pin:
        xbmcgui.Dialog().ok(NOMBRE, "El PIN repetido no coincide. No se ha cambiado nada.")
        return
    cfg = _cfg()
    cfg["pin_salt"] = secrets.token_hex(12)
    cfg["pin_hash"] = _hash(pin, cfg["pin_salt"])
    # A partir de aquí el PIN es del usuario: deja de estar en uso el de Telegram y el
    # recordatorio de "cambíalo" desaparece solo.
    cfg["pin_propio"] = True
    if not _guardar_cfg(cfg):
        # Si falla la escritura en disco, se notifica explícitamente para no
        # asumir erróneamente que el PIN nuevo quedó registrado.
        xbmcgui.Dialog().ok(NOMBRE, "No se ha podido guardar el PIN nuevo, así que sigue "
                                    "valiendo el anterior. Comprueba que el disco no esté "
                                    "lleno ni el perfil sin permisos, y vuelve a intentarlo.")
        return
    _limpia_fallos()
    try:
        xbmcgui.Window(10000).setProperty(PROP_UNLOCK, "1")
    except Exception:
        pass
    xbmcgui.Dialog().notification(NOMBRE, "PIN cambiado", xbmcgui.NOTIFICATION_INFO, 3000)


# -------------------------------------------------------------------- +18
def adult_gate():
    cfg = _cfg()
    if not cfg["adult_confirm"] or cfg["adult_ok"]:
        return True
    ret = xbmcgui.Dialog().yesno(
        NOMBRE + " | +18",
        "Contenido sexual explícito. SOLO para adultos (+18).\n\n"
        "Cada vídeo se reproduce desde lo que la propia web pone a disposición de cualquier "
        "visitante: su API pública o su propio reproductor web. No hay re-subidas ni copias.\n\n"
        "El contenido pertenece a cada plataforma y a sus usuarios; DMCA de Eporner en "
        "eporner.com/dmca.\n\n"
        "Confirma que tienes +18 y quieres entrar.")
    if not ret:
        xbmcgui.Dialog().notification(NOMBRE, "Hay que confirmar que eres mayor de edad (+18) para entrar.",
                                      xbmcgui.NOTIFICATION_WARNING, 3000)
        return False
    cfg["adult_ok"] = True
    _guardar_cfg(cfg)
    return True


def abrir_canal():
    """Abre el canal de Telegram. Reutiliza el helper del instalador, que ya pregunta y
    cubre el caso de Android."""
    try:
        import espakodi_installer
        espakodi_installer.abrir_url(
            URL_CANAL, NOMBRE,
            "El PIN de esta sección está en el canal de Telegram de EspaKodi.", "Abriendo el canal...")
        return
    except Exception as e:
        _log("no se pudo abrir el canal: {0}".format(e), xbmc.LOGWARNING)
    try:
        import webbrowser
        webbrowser.open(URL_CANAL)
    except Exception:
        xbmcgui.Dialog().ok(NOMBRE, "Abre el canal a mano: {0}".format(URL_CANAL))


# ------------------------------------------------------------------- filas
def _fin(titulo):
    try:
        xbmcplugin.setPluginCategory(_h(), titulo)
    except Exception:
        pass


def _fila_dir(label, params, icono, plot, is_folder=True, contexto=None):
    params = {k: v for k, v in params.items() if v is not None}
    li = xbmcgui.ListItem(label=label)
    art = {"icon": _ico(icono), "thumb": _ico(icono)}
    li.setArt(art)
    try:
        li.setInfo("video", {"plot": plot})
    except Exception:
        pass
    if contexto:
        try:
            li.addContextMenuItems(contexto)
        except Exception:
            pass
    xbmcplugin.addDirectoryItem(_h(), _u(**params), li, is_folder)


_RE_BBCODE = re.compile(r"[\[\]]")


def _bbcode(texto):
    """Escapa los corchetes para que el texto de la red no se interprete como BBCode.

    Los titulos de estas plataformas traen corchetes, y un `[COLOR]`, un `[/COLOR]` o un `[B]`
    se renderiza de verdad: una fila puede pintarse con una falsa nota, una falsa linea de
    "Descargas:" o un cierre de color que rompe el de la fila entera. En Kodi los escapes son
    `[[]` y `[]]`.

    El orden NO vale: `]` primero y `[` despues tampoco, porque los propios escapes contienen los
    dos caracteres (`[]]` se convierte en `[[]]]`). Se hace en una sola pasada con regex.

    No toca los textos del propio addon, que si quiere BBCode: el boton de la seccion pinta
    `[B][COLOR crimson]Sección X[/COLOR][/B]`.
    """
    return _RE_BBCODE.sub(lambda m: "[[]" if m.group(0) == "[" else "[]]", str(texto or ""))


def _plot_de(v):
    lineas = [_bbcode(v.get("title"))]
    datos = []
    if v.get("length"):
        datos.append("Duración: {0}".format(_bbcode(v.get("length"))))
    vistas = api.formatea_vistas(v.get("views"))
    if vistas:
        datos.append("{0} vistas".format(vistas))
    if v.get("rate"):
        datos.append("Nota: {0}/10".format(_bbcode(v.get("rate"))))
    if v.get("added"):
        datos.append("Subido: {0}".format(_bbcode(v.get("added"))))
    if v.get("src") in ("rt", "ph"):
        datos.append(api.NOMBRES[v["src"]])
    if datos:
        lineas.append(" · ".join(datos))
    if v.get("keywords"):
        etiquetas = [_bbcode(k) for k in list(v.get("keywords"))[:6] if k]
        if etiquetas:
            lineas.append("Etiquetas: " + ", ".join(etiquetas))
    return "\n".join(lineas)


def _etiqueta_de(v):
    """Rótulo de la fila: plataforma, título, duración, nota y vistas.

    Las vistas y la nota se veían de un vistazo en el addon de origen y aquí se habían
    perdido (solo estaban en el plot, que hay que abrir). Son justo los datos con los que
    uno elige vídeo, así que vuelven a la etiqueta, en gris y en pequeño.
    """
    pre = api.PREFIJOS.get(v.get("src"), "")
    bits = [pre + _bbcode(v.get("title", "Sin título"))]
    if v.get("length"):
        bits.append("[COLOR grey]{0}[/COLOR]".format(_bbcode(v.get("length"))))
    cola = []
    if v.get("rate"):
        cola.append("★{0}".format(_numero(v.get("rate"), 0)))
    vistas = api.formatea_vistas(v.get("views"))
    if vistas:
        cola.append("{0} vistas".format(vistas))
    if cola:
        bits.append("[COLOR grey]{0}[/COLOR]".format(_bbcode(" · ".join(cola))))
    return " ".join(bits)


def _url_play(v):
    """La URL de reproducción, con TODO lo que necesita el historial.

    Antes solo llevaba src/vid/titulo, así que el historial se guardaba siempre sin carátula ni
    duración. También evita que un título con comas rompa algo: urlencode lo escapa.

    `added` es la fecha de subida, y va porque sin ella el historial y los favoritos no tenían
    `premiered` y ordenar por fecha en esas dos pantallas no separaba nada: era un método de
    ordenación que no hacía nada. El addon de origen sí la guarda (`main.py:1078`).
    """
    return _u(action="xxx_play", src=v.get("src", ""), vid=v.get("id", ""),
              titulo=v.get("title", ""), thumb=v.get("thumb", ""),
              length=v.get("length", ""), views=str(_numero(v.get("views")) or 0),
              rate=str(_numero(v.get("rate")) or 0),
              added=_fecha_de(v), pagina=v.get("page", ""))


def _numero(valor, defecto=0):
    """Número tolerante: un 'N/A', una lista o un '1.234' no pueden tumbar la sección.

    Ojo con el separador de millares: "1.234" son mil doscientos treinta y cuatro, pero "8.0"
    son ocho coma cero. Solo se quita el punto cuando detrás hay exactamente tres dígitos.
    Devuelve entero cuando el valor lo es, para que las URLs no lleven 'views=1200.0'.

    `nan`, `inf` y `1e999` los acepta `float()` sin quejarse y reventan en el `int()` de abajo
    (ValueError y OverflowError, ninguno de los dos en el except). llegan por la URL del plugin
    sin pasar por ninguna puerta (`?action=xxx_play&views=nan`) y como el fallo está antes del
    `endOfDirectory`, la pantalla se quedaba colgada. Ahora se devuelven como `defecto`.

    Y el `float(valor)` de la rama de int/float va también dentro de un try: `json.loads` de un
    número de 310+ cifras devuelve un **int** de Python, y `float()` de ese int lanza
    OverflowError. Los dos JSON son mergeables, asi que ese dato llega de un .zip importado y
    `_leer_lista` lo pasa aqui desde `favoritos()` y `historial()`, que se quedaban sin cerrar
    el directorio. El try de las dos ramas juntas, para no dejar un agujero al lado del otro.
    """
    if isinstance(valor, bool):
        return defecto
    try:
        if isinstance(valor, (int, float)):
            v = float(valor)
        else:
            s = str(valor or "").strip().replace(" ", "").replace(",", "")
            if "." in s:
                cabeza, _, cola = s.rpartition(".")
                if len(cola) == 3 and cola.isdigit():
                    s = cabeza + cola
            v = float(s)
    except (TypeError, ValueError, OverflowError):
        return defecto
    if v != v or v in (float("inf"), float("-inf")):
        return defecto
    try:
        return int(v) if v == int(v) else v
    except (ValueError, OverflowError):
        return defecto


def _fecha_de(v):
    """La fecha del vídeo en AAAA-MM-DD, o "" si no la hay o no es una fecha de verdad.

    Cada API la da en un formato distinto y a veces no la da: Eporner devuelve una fecha con
    hora, RedTube y Pornhub `YYYYMMDDHHMMSS` sin separadores. Se normaliza a lo que espera
    Kodi en `premiered`, que es AAAA-MM-DD, y si no encaja se devuelve "" en vez de un texto
    suelto: un string raro en `premiered` hace que el skin pinte la fila con la fecha en
    blanco.

    La comprobación es de fecha REAL, no de forma. Antes `_FECHA_OK` solo miraba la forma
    (`AAAA-MM-DD`) y aceptaba `2026-13-45`, que es un mes 13 y un día 45: Kodi lo pinta como
    fecha inválida o directamente no lo enseña, que es justo lo que este recorte quiere evitar.
    """
    bruto = str((v or {}).get("added") or "").strip()
    if not bruto:
        return ""
    candidatos = [bruto[:10]]
    # "20260131T120233" o "2026/03/04": los ocho primeros dígitos, por si la fecha viene con
    # separadores raros o pegada a la hora. SOLO si el texto EMPIEZA por dígitos: si no, el
    # recorte encuentra 8 dígitos en medio de una frase cualquiera ("Subido: texto con
    # 20260304 dentro") y fabrica una fecha que no está ahí.
    if bruto[0].isdigit():
        digitos = ""
        for ch in bruto:
            if ch.isdigit():
                digitos += ch
            if len(digitos) == 8:
                break
        if len(digitos) == 8:
            candidatos.append("{0}-{1}-{2}".format(digitos[0:4], digitos[4:6], digitos[6:8]))
    for candidato in candidatos:
        if _fecha_valida(candidato):
            return candidato
    return ""


def _fecha_valida(texto):
    """True si `texto` es AAAA-MM-DD y además existe en el calendario."""
    if not _FECHA_OK.match(texto or ""):
        return False
    try:
        datetime.date(int(texto[0:4]), int(texto[5:7]), int(texto[8:10]))
    except (ValueError, TypeError):
        return False
    return True


_FECHA_OK = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def _fanart_permitido():
    """Si el usuario ha dejado los fondos de imagen prendidos en EspaTV.

    `core_settings.is_fanart_disabled()` devuelve True cuando estan apagados, asi que el
    nombre engaña: se devuelve True cuando SI se puede poner fanart.

    Si `core_settings` falla se devuelve **False**, y antes se devolvia True. La razon: si no se
    puede leer la preferencia no se sabe si el usuario la tiene apagada, y devolver True
    ENCIENDE el fondo de imagen que quiza apagó. Un fallo al leer una preferencia no puede
    cambiarla al revés. Era lo mas grave de los 33 `except` anchos de este modulo, porque no
    degrada: cambia una decision del usuario, en silencio y una vez por fila.
    """
    try:
        import core_settings
        return not bool(core_settings.is_fanart_disabled())
    except Exception:
        return False


def _fanart_del_addon():
    """El fanart de este addon, para ponerlo de fondo cuando la fila no tiene caratula."""
    try:
        return xbmcaddon.Addon().getAddonInfo("fanart") or ""
    except Exception:
        return ""


# ------------------------------------------------------------------ miniaturas de RedTube
# Las miniaturas de RedTube se resuelven y descargan en paralelo por pantalla
# para almacenarlas localmente, ya que su CDN requiere Referer y la API no entrega rutas completas.
#
# Esto es una caché más y va con las demás: `cache_clear()` también la vacía.
_DIR_THUMBS_RT = None
_THUMBS_RT = {}

# El logo de cada plataforma, para cuando no hay carátula. Sin esto la fila sale con el icono
# genérico de Kodi. Va como `icon`, NUNCA como `fanart`: de fondo está `_fanart_del_addon()`.
_ICO_POR_PLATAFORMA = {"ep": ICO_EPORNER, "rt": ICO_REDTUBE, "ph": ICO_PORNHUB}


def _dir_thumbs_rt():
    """Carpeta del addon donde se guardan las miniaturas de RedTube. "" si no se puede.

    `xbmcvfs` se importa AQUÍ y no arriba a propósito, y además se exige que la ruta sea ABSOLUTA.
    Bajo los tests `xbmcvfs` es un `MagicMock`, y `MagicMock` implementa `__fspath__`, así que
    `os.path.join` NO falla: devuelve una ruta RELATIVA y `os.makedirs` crea de verdad un árbol de
    carpetas `MagicMock/...` en la raíz del repo. Está en `.gitignore`, pero ensucia y fue lo que
    hizo que esta suite tardase 16 s en vez de 4. Con `isabs` esto devuelve "" y las pantallas de
    test no se descargan ni una imagen ni crean una carpeta.

    Y no es solo cosa de tests: si `translatePath` devolviera algo que no es una ruta real,
    `os.makedirs` escribiría en el directorio de trabajo de Kodi, que es justo donde no hay que
    escribir. Es la misma razón por la que `fix_thumb()` limita el esquema a http(s).
    """
    global _DIR_THUMBS_RT
    if _DIR_THUMBS_RT is None:
        _DIR_THUMBS_RT = ""
        try:
            import xbmcvfs

            base = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
            if not isinstance(base, str) or not os.path.isabs(base):
                return ""
            carpeta = os.path.join(base, "thumbs_rt")
            if not os.path.isdir(carpeta):
                os.makedirs(carpeta)
            _DIR_THUMBS_RT = carpeta
        except Exception:
            _DIR_THUMBS_RT = ""
    return _DIR_THUMBS_RT


def _thumbs_listados(videos):
    """Las miniaturas reparadas de RedTube de una pantalla entera: ``{id: ruta o ""}``.

    UNA vez por vídeo y por sesión, y no por pantalla. Se resuelve la pantalla entera de una vez
    porque `thumbs_redtube()` ya va en paralelo; si se pidiera fila a fila serían 20 x 1,6 s en
    serie y se notaría como la pantalla tarda.

    Lo que FALLA se apunta como "" a propósito. Sin esto, un vídeo que no se pudo bajar (la red
    cayó, RedTube cambió la página) se volvería a intentar en cada visita a la pantalla, y en el
    peor caso son 20 x 1,6 s colgados cada vez que se abre el menú de RedTube. Es peor un
    recargado que una miniatura que falta.

    Ese apunte va en disco, no en memoria. `_THUMBS_RT` es un diccionario del módulo,
    y en Kodi cada pulsación es un intérprete nuevo (`addon.xml` no lleva
    `reuselanguageinvoker`): **no dura una sesión**, diga lo que diga el párrafo de arriba. Con
    él solo, un vídeo roto se reintentaba en cada visita. El marcador lo escribe
    `api.apunta_fallo_thumb_rt()` en `rt_<id>.fallo` y caduca a las 24 h
    (`api.thumb_rt_fallada()`).
    """
    nuevos = [v for v in (videos or [])
              if isinstance(v, dict) and v.get("src") == "rt"
              and str(v.get("id") or "") not in _THUMBS_RT]
    if not nuevos:
        return _THUMBS_RT
    carpeta = _dir_thumbs_rt()
    if not carpeta:
        return _THUMBS_RT

    # Las miniaturas que fallaron recientemente se saltan y se marcan como vacías
    # para evitar reintentos continuos en la misma pantalla.
    por_intentar = []
    for v in nuevos:
        if api.thumb_rt_fallada(v, carpeta):
            _THUMBS_RT[str(v.get("id") or "")] = ""
            continue
        por_intentar.append(v)
    if not por_intentar:
        return _THUMBS_RT

    try:
        bajadas = api.thumbs_redtube(por_intentar, carpeta)
    except Exception:
        return _THUMBS_RT
    for v in por_intentar:
        ident = str(v.get("id") or "")
        ruta = bajadas.get(ident, "")
        _THUMBS_RT[ident] = ruta
        if not ruta:
            api.apunta_fallo_thumb_rt(v, carpeta)
    return _THUMBS_RT


def _vaciar_thumbs_rt():
    """Borra las miniaturas de RedTube guardadas. Lo llama `cache_clear()`."""
    global _DIR_THUMBS_RT
    carpeta = _dir_thumbs_rt()
    _THUMBS_RT.clear()
    if not carpeta:
        return 0
    borrados = 0
    try:
        for nombre in os.listdir(carpeta):
            if not nombre.startswith("rt_"):
                continue
            try:
                os.remove(os.path.join(carpeta, nombre))
                borrados += 1
            except OSError:
                pass
    except OSError:
        pass
    _DIR_THUMBS_RT = None
    return borrados


def _fila_video(v, contexto_extra=None, en_favoritos=None, fanart=None, thumbs=None):
    src, vid = v.get("src", ""), v.get("id", "")
    li = xbmcgui.ListItem(label=_etiqueta_de(v))
    # `fanart` es la caratula: los skins con fondo de imagen la usan como fondo de la fila y, al
    # reproducir, como cartel del video. El addon de origen la ponia (`thumb or
    # ADDON.getAddonInfo('fanart')`, main.py:653) y aqui se habia perdido. `mediatype` y `studio`
    # los leen algunos skins para distinguir la fila.
    # Se añade fanart de fondo si la preferencia global core_settings.is_fanart_disabled() lo permite.
    caratula = v.get("thumb", "")
    # La miniatura de RedTube que se baja a disco TIENE prioridad sobre la de la API: no es que sea
    # "mejor", es que la de la API no existe (429/410). Ver `_thumbs_listados()`. La usan las cuatro
    # pantallas que pintan vídeos, y por eso el diccionario va por parámetro y no se lee aquí.
    if thumbs:
        local = thumbs.get(str(vid))
        if local:
            caratula = local
    # Sin carátula se usa el icono de la plataforma para evitar el recuadro gris de Kodi.
    # El logo no va de fondo: de eso se encarga `_fanart_del_addon()`.
    icono = caratula
    if not icono:
        nombre_icono = _ICO_POR_PLATAFORMA.get(src, "")
        if nombre_icono:
            icono = _ico(nombre_icono)
    art = {"icon": icono, "thumb": icono, "poster": icono}
    # `fanart` lo lee la pantalla UNA vez y lo pasa a cada fila. Sin él (un sitio que no lo pase)
    # se lee aquí, como antes. Antes se leía por fila, y eso son 30 lecturas del mismo JSON para
    # pintar 30 filas, porque dentro hay un `is_fanart_disabled()` que abre y lee un fichero.
    if _fanart_permitido() if fanart is None else fanart:
        art["fanart"] = caratula or _fanart_del_addon()
    li.setArt(art)
    info = {"title": v.get("title", ""), "plot": _plot_de(v), "mediatype": "video"}
    if src in ("rt", "ph"):
        info["studio"] = api.NOMBRES.get(src, src)
    if v.get("length_sec"):
        info["duration"] = int(_numero(v.get("length_sec")) or 0)
    # `rating` y `premiered`: los skins los usan para las estrellas y para la fecha, y el addon de
    # origen los ponía (main.py:675). `rate` ya viene en 0-10 desde `api.norm_rate()`, que es
    # justo la escala que espera Kodi. `premiered` solo se pasa si parece una fecha: un string
    # raro ahí hace que algunos skins muestren la fila con la fecha en blanco.
    nota = _numero(v.get("rate"), 0)
    if nota:
        info["rating"] = float(nota)
    alta = _fecha_de(v)
    if alta:
        info["premiered"] = alta
    try:
        li.setInfo("video", info)
    except Exception:
        pass
    li.setProperty("IsPlayable", "true")
    if en_favoritos is None:
        en_favoritos = _clave(src, vid) in _claves_favoritos()
    # El menú contextual va SIEMPRE en tuplas (rótulo, orden). Una cadena suelta la interpreta
    # Kodi como el nombre de un builtin, así que el botón se pintaba y no hacía nada: Favoritos
    # se quedaba siempre vacío y tres acciones del router no las emitía nadie.
    # "Reproducir" va con PlayMedia, NO con RunPlugin. Con RunPlugin, Kodi invoca el addon con
    # handle -1, y `xbmcplugin.setResolvedUrl(-1...)` lo rechaza ("Invalid handle -1"): el
    # diálogo de progreso se abría y se cerraba, y no sonaba nada. PlayMedia es lo que usa el
    # resto del addon para esto (default.py, pelis_flix.py, fantasia.py, iptv_lists.py...). El
    # resto de entradas del contextual (favoritos, historial, abrir en la web) si son RunPlugin,
    # porque no resuelven nada.
    acciones = [("Reproducir", "PlayMedia({0})".format(_url_play(v)))]
    if en_favoritos:
        acciones.append(("Quitar de favoritos",
                          "RunPlugin({0})".format(_u(action="xxx_fav_del", vid=vid, src=src))))
    else:
        acciones.append(("Añadir a favoritos",
                         "RunPlugin({0})".format(_u(
                             action="xxx_fav_add", src=src, vid=vid,
                             titulo=v.get("title", ""), thumb=v.get("thumb", ""),
                             length=v.get("length", ""),
                             views=str(_numero(v.get("views")) or 0),
                             rate=str(_numero(v.get("rate")) or 0),
                             added=_fecha_de(v), pagina=v.get("page", "")))))
    # "Abrir en la web": se lleva la `page` que vino de la API. Los favoritos y el historial la
    # guardan desde que se enhebró (antes no se pasaba aquí y `fav_add()`/`play()` no la
    # guardaban, así que "Abrir en la web" desde esas dos pantallas caía SIEMPRE al embed, que
    # se ve peor). Solo una entrada guardada antes de ese arreglo no la trae, y entonces
    # abrir_web() cae al embed, que también se ve.
    acciones.append(("Abrir en la web",
                     "RunPlugin({0})".format(_u(action="xxx_web", src=src, vid=vid,
                                                pagina=v.get("page", "") or ""))))
    if contexto_extra:
        acciones.extend(contexto_extra)
    try:
        li.addContextMenuItems(acciones, replaceItems=False)
    except Exception:
        pass
    xbmcplugin.addDirectoryItem(_h(), _url_play(v), li, False)


def _boton_accion(label, accion, icono, plot, params_extra=None, is_folder=False):
    """Genera un botón de acción en el listado.

    Con `is_folder=False` y sin declararla reproducible, Kodi la ejecuta sin
    abrir una nueva carpeta de navegación (para acciones directas como borrar favoritos,
    aviso legal o cambiar PIN). Las acciones que muestran listados posteriores
    deben especificar `is_folder=True`.
    """
    p = {"action": accion}
    if params_extra:
        p.update(params_extra)
    _fila_dir(label, p, icono, plot, is_folder=is_folder)


PROP_AVISO_PIN = "espatv_xxx_aviso_pin"

#: Indica si la explicación del PIN se ha enseñado ya en esta sesión de Kodi.
PROP_EXPLICA_PIN = "espatv_xxx_explica_pin"


def _explica_el_pin():
    """Enseña de dónde sale el PIN, una vez por sesión de Kodi.

    Dialog::select() no admite texto descriptivo; este diálogo previo informa
    de la procedencia del PIN en Telegram antes de solicitar la clave numérica.

    **Una vez por sesión**, con `PROP_EXPLICA_PIN` en `Window(10000)`, igual que
    `_recuerda_cambiar_el_pin()` con `PROP_AVISO_PIN`: una puerta que explica lo mismo cada
    vez que se abre es una puerta que se aprende a ignorar. Y en Kodi cada pulsación es un
    intérprete nuevo (`addon.xml` no lleva `reuselanguageinvoker`), así que "una variable"
    no sirve: tiene que ser una propiedad de ventana.

    Si la ventana no se puede tolear se enseña igual: es el texto quien tiene que salir, y
    quedarse sin explicación por un fallo de propiedades es el fallo que se está arreglando.
    """
    try:
        ventana = xbmcgui.Window(10000)
        if ventana.getProperty(PROP_EXPLICA_PIN) == "1":
            return
        ventana.setProperty(PROP_EXPLICA_PIN, "1")
    except Exception:
        pass
    xbmcgui.Dialog().ok(
        NOMBRE,
        "Esta sección pide un PIN de 4 dígitos.\n\n"
        "Se publica en el canal de Telegram de EspaKodi: [B]t.me/espadaily[/B]\n"
        "Puedes buscar en el canal «Sección X», «+18» o «XXX».\n\n"
        "Te quedan [B]{0}[/B] intentos en esta sesión.".format(
            max(0, MAX_FALLOS - _fallos())))


def _recuerda_cambiar_el_pin():
    """Recuerda, AL ENTRAR, que el PIN sigue siendo el público del canal de Telegram.

    Sin PIN propio se sigue aceptando el de Telegram; como es público, se recuerda cambiarlo.

    UNA VEZ POR SESIÓN de Kodi, y eso es lo que hace, aunque antes este texto prometiese que salía
    cada vez que se abría la sección. No puede ser así sin detectar la salida de la sección, y el
    resultado sería un aviso cada vez que se vuelve atrás, que es ruido. Se corrige el texto para
    que diga lo que pasa, que es justo lo que faltaba.

    Si el ajuste `pin_on` está en "nunca" no se dice nada: si no se pide el PIN, recordar que
    lo cambies no viene a cuento.
    """
    cfg = _cfg()
    texto = _aviso_pin_publico(cfg)
    if not texto or cfg["pin_on"] == "nunca":
        return
    try:
        ventana = xbmcgui.Window(10000)
        if ventana.getProperty(PROP_AVISO_PIN) == "1":
            return
        ventana.setProperty(PROP_AVISO_PIN, "1")
    except Exception:
        pass
    _notifica(texto, heading=NOMBRE + " · aviso")


PROP_AVISO_GAY = "espatv_xxx_aviso_gay"


def _filtra_ph(lista, gay):
    """Aplica el ajuste de contenido sobre una página de Pornhub.

    Devuelve `(lista filtrada, cuántas había antes)`. El segundo número permite
    distinguir una búsqueda sin resultados de una donde el filtro descartó el total.

    `gay=0` descarta elementos con `segment == 'gay'`. `gay=2` mantiene solo esos.
    Si el elemento no incluye el campo `segment`, se conserva para evitar filtrados espurios.
    """
    traidas = len(lista)
    if gay == 0:
        return [v for v in lista if (v.get('segment') or '') != 'gay'], traidas
    if gay == 2:
        return [v for v in lista if (v.get('segment') or '') == 'gay'], traidas
    return lista, traidas


def _avisa_contenido_gay():
    pass


# ------------------------------------------------------------------- menú
def menu():
    """Menú de la sección. Las puertas van antes: PIN y luego +18."""
    if not pin_gate(raiz=True):
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    if not adult_gate():
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    # El punto verde de lo nuevo se apaga al entrar de verdad, no al pulsar la entrada:
    # quien cancela el PIN o el aviso de mayoría de edad no ha visto la sección (ver
    # ui_utils.punto/visto y default._NUEVO_PORT).
    ui_utils.visto('seccion_x')
    _fin(NOMBRE)
    # Sin setContent: con contenido vacío el skin pinta el icono en la fila.
    #
    # El recordatorio del PIN va aquí y no dentro de `pin_gate()` a propósito: `pin_gate()` se
    # llama en 21 acciones y solo en la RAÍZ tiene sentido recordar algo. Además, si está
    # dentro, el aviso saldría también al cambiar el PIN desde el contextual.
    _recuerda_cambiar_el_pin()
    #
    # El orden del menú principal sigue el de referencia: Eporner, RedTube,
    # Pornhub, Buscar por plataforma, Favoritos, Historial y Ajustes.
    _fila_dir("Eporner", {"action": "xxx_menu_plat", "src": "ep"}, ICO_EPORNER,
              "Eporner: los más recientes, los tops y las categorías.")
    _fila_dir("RedTube", {"action": "xxx_menu_plat", "src": "rt"}, ICO_REDTUBE,
              "RedTube: los más recientes, las categorías y el buscador.")
    _fila_dir("Pornhub", {"action": "xxx_menu_plat", "src": "ph"}, ICO_PORNHUB,
              "Pornhub: búsquedas por tema y el buscador. No tiene categorías oficiales.")
    _fila_dir("Buscar por plataforma", {"action": "xxx_search_menu"}, ICO_BUSCAR,
              "Elige en qué plataforma buscar, sin entrar antes en ella.")
    _fila_dir("Favoritos", {"action": "xxx_favs"}, ICO_FAVORITOS,
              "Los vídeos que has guardado desde esta sección.")
    _fila_dir("Historial", {"action": "xxx_hist"}, ICO_HISTORIAL,
              "Lo que has reprodujido en esta sección, hasta 100 entradas.")
    _fila_dir("Ajustes", {"action": "xxx_ajustes"}, ICO_AJUSTES,
              "Ajustes de la sección: resultados por página, calidad, PIN y control parental.")
    _forzar_vista_wide()
    xbmcplugin.endOfDirectory(_h())


def _forzar_vista_wide():
    """Fuerza la vista 55 en las pantallas de CARPETAS de la sección (menú raíz, menús de
    plataforma, buscar y categorías). Los listados de vídeos no: ahí manda el skin.

    Va con `AlarmClock` y no con el comando directo porque durante el listado el contenedor
    todavía no existe y `Container.SetViewMode` a pelo no pega; con un segundo de margen, el
    builtin ya corre con la lista puesta. El `CancelAlarm` previo evita que se acumulen
    alarmas si se entra varias veces seguidas. El addon de origen lo hacía igual, pero sin
    opción para desactivarlo.
    """
    try:
        if _cfg()["vista"] != "wide":
            return
        xbmc.executebuiltin("CancelAlarm({0},True)".format(ALARMA_VISTA))
        xbmc.executebuiltin("AlarmClock({0},Container.SetViewMode({1}),1,silent)".format(
            ALARMA_VISTA, VIEW_WIDE))
    except Exception as e:
        _log("no se pudo forzar la vista: {0}".format(e), xbmc.LOGWARNING)


def search_menu():
    """Elegir plataforma y buscar, sin entrar antes en la plataforma.

    El addon de origen tenía esta pantalla en la raíz. Aquí se había fusionado con el
    buscador de cada plataforma, lo que costaba un paso de más a quien ya sabe dónde lo
    tiene.
    """
    if not _puertas():
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    _fin("{0} · Buscar".format(NOMBRE))
    for src, icono in (("ep", ICO_EPORNER), ("rt", ICO_REDTUBE), ("ph", ICO_PORNHUB)):
        nombre = api.NOMBRES.get(src, src)
        _fila_dir("Buscar en {0}...".format(nombre), {"action": "xxx_buscar", "src": src},
                  icono, "Escribe lo que quieras ver en {0}.".format(nombre))
    _fila_dir("<< Volver al menú de la sección", {"action": "xxx_menu"}, ICO_BUSCAR,
              "Atrás: vuelve al menú con las tres plataformas.")
    _forzar_vista_wide()
    xbmcplugin.endOfDirectory(_h())


def _plot_orden_rt(texto):
    """Lo que hay que saber antes de entrar en una de las cuatro secciones de orden de RedTube.

    La API de RedTube solo aplica ordenación si la petición incluye término de búsqueda.
    """
    return ("RedTube ordenado por {0}.\n\n".format(texto.lower()) +
            "Aviso: en estas listas sin término de búsqueda, RedTube no hace caso del orden y "
            "salen los mismos vídeos que en «Últimos». "
            "En cuanto escribes algo en el buscador, el orden sí funciona.")


def menu_plataforma(src):
    if not _puertas():
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    nombre = api.NOMBRES.get(src, src)
    _fin("{0} · {1}".format(NOMBRE, nombre))
    if src == "rt":
        # "Avisar al entrar, no filtrar": el aviso de contenido gay de RedTube. Antes dependía de
        # una categoría de la lista de paridad que no existe, así que no se decía NADA al entrar.
        _avisa_contenido_gay()
    # Mismas filas y orden que plugin.video.epornerxxx (action_ep_menu/_rt_menu/_ph_menu).
    if src == "ep":
        _boton_accion("Buscar...", "xxx_buscar", ICO_BUSCAR,
                      "Escribe lo que quieras ver en Eporner.", {"src": "ep"},
                      is_folder=True)
        for clave, texto in ORDENES:
            _fila_dir("Eporner: {0}".format(texto),
                      {"action": "xxx_list", "src": "ep", "q": "", "page": 1, "order": clave},
                      ICO_EPORNER, "Listado de Eporner ordenado por {0}.".format(texto.lower()))
        _fila_dir("Eporner: Categorías", {"action": "xxx_cats", "src": "ep"}, ICO_CATEGORIAS,
                  "Categorías de Eporner. Son búsquedas por etiqueta.")
    elif src == "rt":
        for clave, texto, _ordering, _period in ORDENES_RT:
            _fila_dir("RedTube: {0}".format(texto),
                      {"action": "xxx_list", "src": "rt", "q": "", "page": 1, "order": clave},
                      ICO_REDTUBE, _plot_orden_rt(texto))
        _fila_dir("RedTube: Categorías", {"action": "xxx_cats", "src": "rt"}, ICO_CATEGORIAS,
                  "Las {0} categorías de RedTube.".format(len(CATS_RT)))
        _boton_accion("Buscar...", "xxx_buscar", ICO_BUSCAR,
                      "Escribe lo que quieras ver en RedTube.", {"src": "rt"},
                      is_folder=True)
    else:
        _fila_dir("Pornhub: Español", {"action": "xxx_list", "src": "ph", "q": "spanish",
                                       "page": 1},
                  ICO_PORNHUB, "Videos de Pornhub etiquetados en español.")
        _fila_dir("Pornhub: Categorías", {"action": "xxx_cats", "src": "ph"}, ICO_CATEGORIAS,
                  "Pornhub no publica categorías: estas son búsquedas por término.\n\n"
                  "De su API solo funcionan el buscador y la página.")
        _boton_accion("Buscar...", "xxx_buscar", ICO_BUSCAR,
                      "Escribe lo que quieras ver en Pornhub.", {"src": "ph"},
                      is_folder=True)
    _forzar_vista_wide()
    xbmcplugin.endOfDirectory(_h())


# -------------------------------------------------------------- listados
def listado(src, q="", page=1, order=None, upd=""):
    if not _puertas():
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    cfg = _cfg()
    page = _pagina(page)
    if src == "rt":
        # También aquí: desde el buscador, que es la entrada habitual, se llega al listado
        # sin pasar por el menú.
        _avisa_contenido_gay()
    traidos_ph = 0
    if src == "ph":
        # Pornhub sin término no tiene sentido: no tiene categorías y su API solo filtra por
        # `search`. El origen cae a "spanish" (`main.py:961-962`), así que aquí igual.
        lista, err = api.buscar("ph", query=q or "spanish", page=page, timeout=cfg["timeout"])

        # El ajuste «Contenido gay» en Pornhub. Su API no lo acepta (`segment`, es
        # decir filtrar por segmento, es de pago segun `_buscar_ph`), pero cada video trae
        # el suyo en la respuesta, asi que se filtra aqui y no en la peticion.
        #
        # La paginacion se decide con lo que devolvio la API **antes** de filtrar (el `tope`
        # de abajo), no con lo que queda: si no, quitar dos videos haria desaparecer la
        # pagina siguiente cuando la API si tiene mas.
        lista, traidos_ph = _filtra_ph(lista, cfg["gay"])
        tope = api.PAGE_SIZE_PH
    elif src == "rt":
        # Se transmite el orden seleccionado a la API de RedTube.
        lista, err = api.buscar("rt", query=q, page=page, order=order or "latest",
                                timeout=cfg["timeout"])
        tope = api.PAGE_SIZE_RT
    else:
        lista, err = api.buscar("ep", query=q, page=page,
                               order=order or cfg["order"],
                               per_page=cfg["per_page"], thumbsize=cfg["thumbsize"],
                               gay=cfg["gay"], timeout=cfg["timeout"])
        tope = cfg["per_page"]
    nombre = api.NOMBRES.get(src, src)
    # Con pagina y orden, como el origen: su etiqueta es '%s | %s p.%s' (main.py:770). En un
    # listado paginado, saber en qué página estás y por qué orden es justo lo que no se ve.
    titulo = "{0} · {1} · p.{2}".format(NOMBRE, q or nombre, page)
    if order:
        titulo += " · " + str(order)
    _fin(titulo)
    if not lista:
        # Si ha habido error de red, la fila NO dice "no hay resultados" (que es otra cosa):
        # dice "reintentar" y lleva el motivo en el plot. Antes el mensaje era el mismo
        #quiera hubiera pasado, asi que un fallo de red se leia como "esta busqueda no
        #devuelve nada".
        #
        # upd=1 evita duplicar entradas en el historial de navegación si falla la carga
        # y el usuario regresa a la página anterior.
        if page > 1:
            _fila_dir("<< Anterior (página {0})".format(page - 1),
                      {"action": "xxx_list", "src": src, "q": q, "page": page - 1,
                       "order": order, "upd": 1},
                      ICO_SIGUIENTE, "Vuelve a la página anterior.")
        if err:
            # Aviso Y fila: el aviso se ve al momento y la fila lo deja escrito, que es lo que
            # sobrevive cuando el usuario vuelve atras y vuelve a entrar.
            #
            # A partir de la página 500 el catálogo de RedTube suele terminar, devolviendo
            # respuestas vacías que no deben notificarse como error de conexión.
            motivo = err
            if src == "rt" and page > 500:
                motivo = ("El catálogo de RedTube se acaba hacia la página {0}: esta no ha "
                          "devuelto nada.\n\nSi sales con la página {1}, es el final de la "
                          "lista y no un fallo.".format(page, page - 1))
            _notifica(motivo)
            # Y el reintento, a la misma página: volver a la 1 pierde lo que el usuario lleva
            # mirando. El addon de origen conservaba la página (`main.py:926-927`).
            #
            # `upd=1` también aquí: "Reintentar" es la MISMA página, y sin esto cada pulsación
            # añade una entrada al historial y ".." hay que pulsarlo tantas veces como se ha
            # reintentado.
            _fila_dir("Reintentar", {"action": "xxx_list", "src": src, "q": q,
                                     "page": page, "order": order, "upd": 1},
                      ICO_BUSCAR, motivo)
        else:
            _fila_dir("Sin resultados. Probar otra vez",
                      {"action": "xxx_list", "src": src, "q": q, "page": 1,
                       "order": order, "upd": 1},
                      ICO_BUSCAR, "No ha salido ningún vídeo con esa búsqueda.")
            # Si la búsqueda devolvió resultados pero el filtro los descartó todos,
            # se muestra una fila explicativa con el motivo.
            if (src == "ph" and cfg["gay"] in (0, 2) and traidos_ph > len(lista)):
                _fila_dir("Vídeos ocultados por el filtro de contenido",
                          {"action": "xxx_set", "clave": "gay"}, ICO_BUSCAR,
                          "La búsqueda ha devuelto {0} vídeos que están ocultos por el ajuste «Contenido gay». "
                          "Pulsa para abrir Ajustes.".format(traidos_ph))
        # Salida SIEMPRE: antes solo Eporner tenía "Buscar otra cosa", y en RedTube y
        # Pornhub un fallo de red dejaba al usuario en un callejon sin salida: la unica
        # accion era repetir la busqueda que acababa de fallar.
        _boton_accion("Buscar otra cosa", "xxx_buscar", ICO_BUSCAR,
                      "Escribe otra búsqueda.", {"src": src}, is_folder=True)
        _boton_accion("Volver al menú de la sección", "xxx_menu", ICO_BUSCAR,
                      "Atrás: vuelve al menú con las tres plataformas.",
                      is_folder=True)
        _cierra_listado(upd)
        return
    if err:
        _notifica(err)
    # Los listados de vídeos sí fijan contenido; los menús no (ver cabecera del módulo).
    try:
        xbmcplugin.setContent(_h(), "videos")
    except Exception:
        pass
    fanart = _fanart_permitido()
    favs = _claves_favoritos()
    # Las miniaturas de RedTube se resuelven de la pantalla ENTERA y una sola vez (ver
    # `_thumbs_listados`): fila a fila serían 20 descargas en serie y se notaría como que la
    # pantalla tarda.
    thumbs = _thumbs_listados(lista)
    for v in lista:
        _fila_video(v, en_favoritos=_clave(v.get("src"), v.get("id")) in favs,
                    fanart=fanart, thumbs=thumbs)
    # updateListing=True evita bucles en el historial de navegación de Kodi al paginar,
    # reemplazando la entrada actual para que la acción Atrás regrese directamente al menú superior.
    if page > 1:
        _fila_dir("<< Anterior (página {0})".format(page - 1),
                  {"action": "xxx_list", "src": src, "q": q, "page": page - 1,
                   "order": order, "upd": 1},
                  ICO_SIGUIENTE, "Vuelve a la página anterior.")
    # Solo len(lista) >= tope es fiable: total_count de Eporner es un tope de catálogo (100000)
    # y total_pages daría "página 3334 de 3334" con diez vídeos.
    if len(lista) >= tope:
        _fila_dir("Siguiente >> (página {0})".format(page + 1),
                  {"action": "xxx_list", "src": src, "q": q, "page": page + 1,
                   "order": order, "upd": 1},
                  ICO_SIGUIENTE, "Página siguiente.")
    try:
        xbmcplugin.addSortMethod(_h(), xbmcplugin.SORT_METHOD_LABEL)
        xbmcplugin.addSortMethod(_h(), xbmcplugin.SORT_METHOD_DURATION)
        # Por fecha, que es lo que sí ponía el addon de origen (main.py:812). Funciona porque
        # las filas llevan `premiered`.
        xbmcplugin.addSortMethod(_h(), xbmcplugin.SORT_METHOD_DATE)
    except Exception:
        pass
    _cierra_listado(upd)


def _cierra_listado(upd):
    """Cierra el directorio de un listado de vídeos, respetando `upd`.

    `upd` lo ponen las dos filas de paginación ("Siguiente >>" y "<< Anterior"). Sin él, esas
    filas son carpetas y Kodi mete cada página en el historial, así que "..", los dos puntos de
    arriba, que es lo que sale al pulsar Atrás, deshace un paso dentro del propio listado y se
    queda en un bucle entre páginas en vez de volver al menú de la plataforma.

    Con `updateListing=True` la página REEMPLAZA la anterior en el historial: ".." sale al
    menú, que es lo que espera quien ya sabe de dónde vino. El origen no lo hace (main.py:803
    y 926) y por eso a él sí le pasa el bucle.

    `cacheToDisc=False` porque un listado con páginas no tiene nada que ganar cacheado: Kodi
    guarda el JSON en disco y una entrada vieja reaparece al volver atrás.
    """
    kw = {}
    if str(upd or "").strip() not in ("", "0", "None", "False"):
        kw["updateListing"] = True
    try:
        xbmcplugin.endOfDirectory(_h(), succeeded=True, cacheToDisc=False, **kw)
    except TypeError:
        # Un Kodi muy viejo sin alguno de estos parámetros: se cierra como se pueda antes que
        # dejar la pantalla colgada.
        try:
            xbmcplugin.endOfDirectory(_h(), succeeded=True)
        except Exception:
            pass
    except Exception:
        pass


def categorias(src, upd=""):
    if not _puertas():
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    _fin("{0} · Categorías".format(NOMBRE))
    if src == "ep":
        for cat in CAT_EPORNER:
            _fila_dir(cat, {"action": "xxx_list", "src": "ep", "q": cat, "page": 1},
                      ICO_CATEGORIAS, "Vídeos de Eporner con la etiqueta «{0}».".format(cat))
    elif src == "rt":
        # Las 30 del addon de referencia, en su orden. NO se piden a la API: son una constante
        # copiada de su main.py:53, que es lo que hacía el origen. Antes aquí se pedían las 111
        # de `api.cats_redtube()` y salían 105, setenta y cinco más que las del origen.
        cats = list(CATS_RT)
        _avisa_contenido_gay()
        # Las categorías de CATS_RT son temáticas generales. El aviso de contenido
        # se gestiona a nivel de sección mediante `_avisa_contenido_gay()`.
        for cat in cats:
            _fila_dir(cat, {"action": "xxx_list_rt_cat", "cat": cat, "page": 1},
                      ICO_CATEGORIAS,
                      "Vídeos de RedTube de la categoría «{0}».".format(cat))
    else:
        _fila_dir("Buscar en Pornhub...",
                  {"action": "xxx_buscar", "src": "ph"}, ICO_CATEGORIAS,
                  "Pornhub solo permite filtrar por el buscador.", is_folder=True)
        for etiqueta, termino in BUSQUEDAS_PH:
            _fila_dir(etiqueta, {"action": "xxx_list", "src": "ph", "q": termino, "page": 1},
                      ICO_CATEGORIAS, "Buscar «{0}» en Pornhub.".format(termino))
    _forzar_vista_wide()
    # Cierra respetando el parámetro upd cuando la fila previa lo indica.
    _cierra_listado(upd)


def listado_rt_cat(cat, page=1, upd=""):
    if not _puertas():
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    cfg = _cfg()
    page = _pagina(page)
    lista, err = api.buscar("rt", query="", page=page, category=cat, timeout=cfg["timeout"])
    _fin("{0} · RedTube · {1}".format(NOMBRE, _bbcode(cat)))
    if err:
        # Mismo matiz que `listado()`, y por el mismo motivo: el catálogo de RedTube se acaba
        # hacia la página 505, así que en una categoría alta la API deja de devolver lista. Sin
        # esto el toast decía "Revisa la conexión" a quien solo se había pasado de página.
        if page > 500:
            _notifica("El catálogo de RedTube se acaba hacia la página 500: esta no ha devuelto "
                      "nada.\n\nSi sales a una página anterior, es el final de la lista y no un "
                      "fallo.")
        else:
            _notifica(err)
    if not lista:
        # El `upd=1` de la fila de aquí estaba puesto pero NO ERA NADA: el cierre de abajo era
        # `endOfDirectory(_h())` a secas, sin `updateListing`, así que el `upd` viajaba en la URL
        # y no hacía nada. Era el bucle de navegación, otra vez, en la pantalla de categorías.
        if page > 1:
            _fila_dir("<< Anterior (página {0})".format(page - 1),
                      {"action": "xxx_list_rt_cat", "cat": cat, "page": page - 1, "upd": 1},
                      ICO_SIGUIENTE, "Vuelve a la página anterior.")
        _fila_dir("No ha salido nada de «{0}»".format(_bbcode(cat)),
                  {"action": "xxx_cats", "src": "rt", "upd": 1}, ICO_BUSCAR,
                  err or "Prueba con otra categoría.")
        _cierra_listado(upd)
        return
    try:
        xbmcplugin.setContent(_h(), "videos")
    except Exception:
        pass
    fanart = _fanart_permitido()
    favs = _claves_favoritos()
    # Las miniaturas de RedTube se resuelven de la pantalla ENTERA y una sola vez (ver
    # `_thumbs_listados`): fila a fila serían 20 descargas en serie y se notaría como que la
    # pantalla tarda.
    thumbs = _thumbs_listados(lista)
    for v in lista:
        _fila_video(v, en_favoritos=_clave(v.get("src"), v.get("id")) in favs,
                    fanart=fanart, thumbs=thumbs)
    if page > 1:
        _fila_dir("<< Anterior (página {0})".format(page - 1),
                  {"action": "xxx_list_rt_cat", "cat": cat, "page": page - 1, "upd": 1},
                  ICO_SIGUIENTE, "Vuelve a la página anterior.")
    if len(lista) >= api.PAGE_SIZE_RT:
        _fila_dir("Siguiente >> (página {0})".format(page + 1),
                  {"action": "xxx_list_rt_cat", "cat": cat, "page": page + 1, "upd": 1},
                  ICO_SIGUIENTE, "Página siguiente.")
    try:
        xbmcplugin.addSortMethod(_h(), xbmcplugin.SORT_METHOD_LABEL)
        xbmcplugin.addSortMethod(_h(), xbmcplugin.SORT_METHOD_DURATION)
        # Por fecha, que es lo que sí ponía el addon de origen (main.py:950). Funciona porque
        # las filas llevan `premiered`.
        xbmcplugin.addSortMethod(_h(), xbmcplugin.SORT_METHOD_DATE)
    except Exception:
        pass
    _cierra_listado(upd)


def buscar(src):
    if not pin_gate():
        _cierra(_h(), succeeded=False)
        return
    texto = ui_utils.get_text("Buscar en {0}".format(api.NOMBRES.get(src, src)))
    if not texto or not texto.strip():
        _cierra(_h(), succeeded=False)
        return
    _nav_listado(src, texto.strip(), 1)


def _nav_listado(src, q, page):
    """Navega al listado. Se hace con Container.Update para que Atrás vuelva aquí y no a la
    raíz de la sección."""
    # SIN replace: con replace, "Atras" se lleva al menu de la seccion en lugar de volver al
    # teclado. Es lo que hace iptv_lists.search_prompt, con el comentario al reves.
    xbmc.executebuiltin('Container.Update("{0}")'.format(
        _u(action="xxx_list", src=src, q=q, page=page)))


def _puertas(con_edad=True):
    """Las dos puertas de la sección, en orden: primero el PIN, luego la edad.

    El addon de origen las ejecuta en TODAS sus acciones, dentro del `router()`
    (`main.py:1168-1171`). Aquí solo estaban en `menu()`, `search_menu()`, `play()` y
    `abrir_web()`, y por la interfaz normal no se nota porque se pasa por `menu()`: pero
    `?action=xxx_menu_plat&src=ep` escrita a mano abría la sección sin confirmar la edad, y
    el propio autor lo había razonado ya para `play()`.

    `con_edad=False` es para las pantallas que NO muestran contenido adulto por sí mismas
    (el aviso legal, vaciar caché): en esas la puerta del PIN basta y preguntar dos veces es
    molesto.
    """
    if not pin_gate():
        return False
    if con_edad and not adult_gate():
        return False
    return True


# -------------------------------------------------------------- favoritos
def _ordenes_de_ordenacion():
    """Métodos de ordenación de las pantallas de la sección.

    El addon de origen los tenía en Favoritos y en Historial, y aquí se habían perdido: con
    200 favoritos, ordenar por fecha o por nombre era la única forma de encontrar algo. Se
    Krasnan por comparación de atributos que no existen, así que se prueban todos y se
    descartan los que el skin no soporta.
    """
    for metodo in ("SORT_METHOD_LABEL", "SORT_METHOD_UNSORTED", "SORT_METHOD_DATE",
                   "SORT_METHOD_VIDEO_YEAR", "SORT_METHOD_DURATION", "SORT_METHOD_TITLE",
                   "SORT_METHOD_TITLE_IGNORE_THE", "SORT_METHOD_FILE"):
        valor = getattr(xbmcplugin, metodo, None)
        if valor is None:
            continue
        try:
            xbmcplugin.addSortMethod(_h(), valor)
        except Exception:
            pass


def favoritos():
    if not _puertas():
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    _fin("{0} · Favoritos".format(NOMBRE))
    items = _leer_lista(FICH_FAVS)
    if not items:
        # `setContent('videos')` va DESPUES de esta rama, no antes: en un contenedor de videos
        # la fila de aviso se pinta con el arte generico del skin (o en blanco en WideList) y
        # se pierde el icono propio. Es lo que ya hace `listado()`.
        _fila_dir("Todavía no has guardado ningún vídeo aquí.", {"action": "xxx_menu_plat",
                                                                 "src": "ep"},
                  ICO_BUSCAR,
                  "Abre una plataforma y usa el menú contextual de cualquier vídeo.\n\n"
                  "Esta lista es propia de la sección y no comparte nada con los "
                  "favoritos de EspaTV.")
        _boton_accion("Volver al menú de la sección", "xxx_menu", ICO_BUSCAR,
                      "Atrás: vuelve al menú con las tres plataformas.",
                      is_folder=True)
    else:
        try:
            xbmcplugin.setContent(_h(), "videos")
        except Exception:
            pass
    fanart = _fanart_permitido()
    # Igual que en los listados: una sola llamada por pantalla. Aqui se nota mas, porque el
    # historial llega a 100 filas y todas pueden ser de RedTube.
    thumbs = _thumbs_listados(items)
    for v in items:
        # "Quitar de favoritos" NO se pasa aqui: _fila_video ya lo pone cuando
        # `en_favoritos=True`, y con las dos cosas salia duplicado en el menu.
        _fila_video(v, en_favoritos=True, contexto_extra=[
            ("Borrar todos los favoritos",
             "RunPlugin({0})".format(_u(action="xxx_favs_clear")))], fanart=fanart, thumbs=thumbs)
    if items:
        _boton_accion("Borrar todos los favoritos", "xxx_favs_clear", ICO_FAVORITOS,
                      "Borra la lista de favoritos de esta sección.")
        _ordenes_de_ordenacion()
    xbmcplugin.endOfDirectory(_h())


def _transforma_lista(fich, transforma):
    """Lee, transforma y guarda una lista de la sección **bajo cerrojo**. Devuelve si se escribió.

    Las acciones que escriben favoritos o historial requieren cerrojo para evitar
    condiciones de carrera si se producen pulsaciones rápidas o accesos concurrentes.
    Sigue el mismo patrón que `fuentes_store._escribe_favoritos()`.

    **Un solo sitio para las cuatro**, que es lo que evita que la siguiente se quede sin
    cerrojo: con cuatro `with` repetidos, el que añagan mañana se les olvidará.

    Con el cerrojo ocupado no se escribe. Si no se puede crear (perfil raro, disco lleno) se
    sigue sin él, para no quedarse sin poder guardar favoritos.
    """
    import contextlib
    import iptv_store

    try:
        # `or "."` dos veces: sin ruta, o con un `get_path` que no da directorio, el perfil
        # sería "" y `os.makedirs("")` no crea nada.
        carpeta = os.path.dirname(_ruta_lista(fich) or ".") or "."
        cerrojo = iptv_store.Store(carpeta).lock(fich + ".lock")
    except Exception as e:
        _log("sin cerrojo para {0}: {1}".format(fich, e), xbmc.LOGWARNING)
        cerrojo = None

    if cerrojo is None:
        return transforma()

    # El cerrojo se toma con un `ExitStack` y no con un `with` a secas porque `lock()` es un
    # generador: con el `with`, el `os.makedirs` que hace dentro corre en el `__enter__`, y un
    # fallo ahí se escapaba del `try` de arriba. Con la pila se ve si se pudo entrar y, si no,
    # se sigue sin cerrojo en vez de perder el guardado.
    #
    # Un `LockBusy` que llegue al salir no se captura a propósito: si algo raro pasa ahí, que
    # salga al router y se vea como «este botón no ha funcionado», que es la verdad.
    with contextlib.ExitStack() as pila:
        try:
            pila.enter_context(cerrojo)
        except iptv_store.LockBusy:
            # Ocupado: otra pulsación en este instante. No se escribe, y eso es a
            # propósito: escribir sin el cerrojo es justo el fallo que se arregla.
            _log("otra escritura tiene el cerrojo de {0}".format(fich), xbmc.LOGWARNING)
            return False
        except Exception as e:
            # Sin cerrojo posible se guarda igual (ver docstring).
            _log("sin cerrojo para {0} ({1}), se sigue sin él".format(fich, e),
                 xbmc.LOGWARNING)
        return transforma()


def _guardar_fav(v):
    """Guarda un favorito y dice si de verdad se escribió.

    El aviso "Guardado en favoritos." ya no se lanza a ciegas: solo si la escritura ha ido
    bien. Con el perfil de solo lectura antes se prometía el guardado y no quedaba nada.

    Lectura y escritura van bajo el mismo cerrojo. Ver `_transforma_lista()`.
    """
    vid = v.get("id", "")
    if not vid:
        return False

    def _haz():
        items = _leer_lista(FICH_FAVS)
        k = _clave(v.get("src", ""), vid)
        items = [f for f in items if _clave(f.get("src", ""), f.get("id", "")) != k]
        items.insert(0, v)
        # Sin tope, como el addon de origen: con uno, el favorito más antiguo se borraba sin avisar.
        return _guardar_lista(FICH_FAVS, items)

    if not _transforma_lista(FICH_FAVS, _haz):
        return False
    _notifica("Guardado en favoritos.")
    return True


def _quitar_fav(vid, src=""):
    """Bajo cerrojo, igual que `_guardar_fav()`. Ver `_transforma_lista()`."""

    def _haz():
        items = _leer_lista(FICH_FAVS)
        k = _clave(src, vid)
        # Sin plataforma (una URL a mano, por ejemplo) se busca por id solo: el peor caso es
        # borrar de las dos plataformas el id repetido, que es lo que se pedía al pulsar.
        quedan = [f for f in items if _clave(f.get("src", ""), f.get("id", "")) != k
                  and not (not src and f.get("id") == vid)]
        return _guardar_lista(FICH_FAVS, quedan)

    if not _transforma_lista(FICH_FAVS, _haz):
        return False
    xbmc.executebuiltin("Container.Refresh")
    return True


def fav_add(src, vid, titulo="", thumb="", length="", views="", rate="", added="", pagina=""):
    # Puerta. El origen la pone en las 22 acciones (`main.py:1168-1171`); aquí faltaba en las
    # que escriben en disco. Sin ella, una URL escrita a mano metía carátulas y títulos en el
    # JSON de favoritos sin pasar por ningún PIN.
    #
    # El esquema de la miniatura se filtra igual en `api.fix_thumb()`, que es donde está el
    # filtro de verdad: aquí no se repite.
    if not pin_gate():
        return
    v = {"src": src, "id": vid, "title": titulo or vid, "thumb": api.fix_thumb(thumb),
         "length": length, "length_sec": api.dur_to_sec(length),
         "views": _numero(views), "rate": _numero(rate),
         # La página real, para que "Abrir en la web" desde Favoritos abra la del vídeo y no el
         # embed. Antes no se guardaba y caía siempre al embed.
         "page": pagina if isinstance(pagina, str) else ""}
    fecha = _fecha_de({"added": added})
    if fecha:
        v["added"] = fecha
    if not _guardar_fav(v):
        # Notificar si la persistencia en disco falla para evitar asumir un guardado inexistente.
        xbmcgui.Dialog().ok(NOMBRE, "No se ha podido guardar en favoritos. Comprueba que el "
                                    "disco no esté lleno ni el perfil sin permisos.")
        return
    xbmc.executebuiltin("Container.Refresh")


def fav_del(vid, src=""):
    if not pin_gate():
        return
    # `_quitar_fav()` hace el `Container.Refresh` solo si se ha escrito; aquí no se repite.
    if not _quitar_fav(vid, src):
        _aviso_escritura("los favoritos")


def favs_clear():
    # Ni `endOfDirectory` cuando no hay un handle real. Estas dos acciones también salen como
    # RunPlugin desde el contextual, y ahí el handle es -1: cerrarlo ahí solo mete ruido en el
    # log de Kodi. Es la clase de bug que ya se arregló para `play()` y que se había vuelto a
    # colar aquí.
    if not pin_gate():
        _cierra(_h(), succeeded=False)
        return
    if not xbmcgui.Dialog().yesno(NOMBRE, "¿Borrar todos los favoritos de esta sección?",
                                  nolabel="Cancelar", yeslabel="Borrar"):
        _cierra(_h(), succeeded=False)
        return
    if not _guardar_lista(FICH_FAVS, []):
        _aviso_escritura("los favoritos")
        return
    xbmc.executebuiltin("Container.Refresh")


# --------------------------------------------------------------- historial
def historial():
    if not _puertas():
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    _fin("{0} · Historial".format(NOMBRE))
    items = _leer_lista(FICH_HIST, tope=MAX_HIST)
    if not items:
        # Igual que en favoritos(): `setContent` despues de la rama vacia, para que la fila de
        # aviso conserve su icono en vez del arte generico del skin.
        _fila_dir("Todavía no has visto nada aquí.", {"action": "xxx_menu_plat", "src": "ep"},
                  ICO_BUSCAR,
                  "Abre una plataforma y reproduce algo.\n\n"
                  "El historial es propio de la sección.")
        _boton_accion("Volver al menú de la sección", "xxx_menu", ICO_BUSCAR,
                      "Atrás: vuelve al menú con las tres plataformas.",
                      is_folder=True)
    else:
        try:
            xbmcplugin.setContent(_h(), "videos")
        except Exception:
            pass
    # Las claves de favoritos se leen UNA vez: _fila_video sin `en_favoritos` las va a buscar
    # él, y con el historial lleno (100 filas) eran 100 lecturas y parseos del mismo JSON.
    fanart = _fanart_permitido()
    favs = _claves_favoritos()
    # Una sola vez para las 100 filas del historial, no una por fila (ver `_thumbs_listados`).
    thumbs = _thumbs_listados(items)
    for v in items:
        _fila_video(v, en_favoritos=_clave(v.get("src"), v.get("id")) in favs,
                    contexto_extra=[
                        ("Quitar del historial", "RunPlugin({0})".format(
                            _u(action="xxx_hist_del", vid=v.get("id", ""),
                               src=v.get("src", "")))),
                        ("Borrar todo el historial",
                         "RunPlugin({0})".format(_u(action="xxx_hist_clear")))],
                    fanart=fanart, thumbs=thumbs)
    if items:
        _boton_accion("Borrar todo el historial", "xxx_hist_clear", ICO_HISTORIAL,
                      "Borra el historial de esta sección.")
        _ordenes_de_ordenacion()
    xbmcplugin.endOfDirectory(_h())


def _apuntar_hist(v):
    """Bajo cerrojo, igual que `_guardar_fav()`.

    Este es el que más se solapa: se llama en **cada reproducción**, así que es el que más
    veces coincide con un «Borrar del historial» pulsado un instante antes.
    """

    def _haz():
        vid = v.get("id", "")
        if not vid:
            # Nada que apuntar, y no es un fallo: no hay que escribir.
            return True
        items = _leer_lista(FICH_HIST)
        # Por src:id y no solo por id: Eporner y RedTube usan ids numericos, asi que reproducir un
        # video de RedTube no puede borrar del historial el de Eporner con el mismo id.
        k = _clave(v.get("src", ""), vid)
        items = [f for f in items if _clave(f.get("src", ""), f.get("id", "")) != k]
        items.insert(0, v)
        return _guardar_lista(FICH_HIST, items[:MAX_HIST])

    _transforma_lista(FICH_HIST, _haz)


def _aviso_escritura(que):
    """El aviso único de las acciones que escriben y no pueden comprobarlo.

    Existe para no repetir cinco veces el mismo texto, y porque el texto ES el arreglo: estas
    cinco (`fav_del`, `favs_clear`, `hist_del`, `hist_clear`, `ajuste_set`) anunciaban el cambio
    con un `Container.Refresh` o un `Container.Update` sin mirar si se había escrito. Con el
    perfil de solo lectura o el disco lleno, la lista se repinta entera como si se hubiera
    borrado o el ajuste hubiera cambiado, y no hay nada.
    """
    xbmcgui.Dialog().ok(NOMBRE, "No se ha podido guardar {0}. Comprueba que el disco no esté "
                                "lleno ni el perfil sin permisos.".format(que))


def hist_del(vid, src=""):
    """Bajo cerrojo, igual que `_guardar_fav()`."""
    if not pin_gate():
        return

    def _haz():
        items = _leer_lista(FICH_HIST)
        k = _clave(src, vid)
        quedan = [f for f in items if _clave(f.get("src", ""), f.get("id", "")) != k
                  and not (not src and f.get("id") == vid)]
        return _guardar_lista(FICH_HIST, quedan)

    if not _transforma_lista(FICH_HIST, _haz):
        _aviso_escritura("el historial")
        return
    xbmc.executebuiltin("Container.Refresh")


def hist_clear():
    if not pin_gate():
        _cierra(_h(), succeeded=False)
        return
    # Y aqui tambien `_cierra()`, no `endOfDirectory` a secas. Esta es la rama que MAS duele
    # porque es la NORMAL: se abre Favoritos o Historial, se pulsa el contexto, "Borrar todo", y
    # se dice que no. Ahi llega por `RunPlugin`, con handle -1, y el `endOfDirectory(-1)` solo
    # deja un "Invalid handle -1" en el log de Kodi. `favs_clear()` ya lo tenia; este se quedo.
    if not xbmcgui.Dialog().yesno(NOMBRE, "¿Borrar todo el historial de esta sección?",
                                  nolabel="Cancelar", yeslabel="Borrar"):
        _cierra(_h(), succeeded=False)
        return
    if not _guardar_lista(FICH_HIST, []):
        _aviso_escritura("el historial")
        return
    xbmc.executebuiltin("Container.Refresh")


# --------------------------------------------------------------- ajustes
# El texto del botón del log va en una constante, para que se lea aquí y no dentro de la tupla,
# donde quedaba en una línea de más de 500 caracteres que era ilegible. Se pega con `+` porque
# una tupla no admite un texto de varias líneas sin liar de paréntesis.
_PLOT_LOG_ON = (
    "Escribe en el log de Kodi cuando algo falla de verdad: una conexión que se cae, un vídeo "
    "que ya no está, o un límite de peticiones de la plataforma.\n\n"
    "Con «Sí», que es lo de ahora, se puede distinguir un 403 por límite de peticiones de un "
    "404 de vídeo despublicado: antes se veían igual y solo decía «no ha contestado».\n\n"
    "Con «No» se calla y el log queda limpio. Afecta SOLO a los avisos de esta sección; el "
    "resto del addon no lo mira, así que se puede apagar sin miedo."
)

OPCIONES = (
    # (clave, etiqueta, valores, es_booleano, plot)
    ("per_page", "Resultados por página", PAGINAS, False,
     "Cuántos vídeos trae Eporner en cada página.\n\n"
     "Solo afecta a Eporner: RedTube siempre trae 20 y Pornhub 30."),
    ("thumbsize", "Tamaño de las miniaturas", MINIATURAS, False,
     "Pequeñas (190 px), medianas o grandes (640 px). Solo Eporner."),
    ("order", "Orden por defecto", ORDENES, False,
     "El orden con el que salen las categorías y las búsquedas de Eporner.\n\n"
     "NO cambia los cuatro botones del menú de Eporner (Últimos, Top semanal, Top mensual, "
     "Más vistos): cada uno lleva su propio orden. Tampoco afecta a RedTube ni a Pornhub."),
    ("gay", "Contenido gay (Eporner y Pornhub)", GAY_OPCIONES, False,
      "Si Eporner y Pornhub dejan entrar el contenido gay en sus listados. «No» lo oculta, "
      "que es lo que la API de Eporner hace por su cuenta; «Sí, solo gay» enseña únicamente "
      "eso y «Sí» lo mezcla.\n\n"
      "Funciona en Eporner y Pornhub. Solo RedTube queda fuera porque su API no admite el filtro.\n\n"
      "La opción «Sí, solo gay» deja un listado con contenido gay y casi nada más: el "
      "91-99% de los títulos llevan temática gay y no comparte NI UNO de 100 vídeos con la "
      "opción «No».\n\n"
      "Las 30 categorías de RedTube que se muestran son todas «straight»."),

    ("quality", "Calidad del vídeo", CALIDADES, False,
     "Máxima se lleva la mejor fuente disponible; ahorro de datos elige la más pequeña.\n\n"
     "Afecta a las tres plataformas."),
    ("timeout", "Tiempo de espera de la red", TIEMPOS, False,
     "Segundos que se espera a cada plataforma antes de rendirse."),
    ("vista", "Tipo de vista de los menús", VISTAS, False,
     "WideList es la lista ancha de los skins de Kodi: el icono grande a la izquierda y el "
     "texto a la derecha, que es como se ven bien los iconos de esta sección. Con «La que trae el skin» se respeta la que tenga configurada.\n\n"
     "Solo afecta a los menús de carpetas (la raíz, las plataformas, buscar y categorías), no a los listados de vídeos."),
    ("adult_confirm", "Aviso +18 al entrar", ((True, "Sí"), (False, "No")), True,
     "Si está activado, la primera vez que entras te pide confirmar que eres mayor de edad.\n\n"
     "Apagarlo no cambia nada más: el contenido sigue siendo +18."),
    ("pin_on", "Cuándo pedir el PIN", MODOS_PIN, False,
     "«Al entrar» pide el PIN cada vez que abres la sección.\n\n"
     "«Una vez por sesión» solo la primera, hasta que reinicies Kodi.\n\n"
     "«Nunca» no lo pide."),
    ("pin_hash", "PIN de la sección", None, False,
     "Son 4 dígitos. Por defecto se usa el publicado en el canal de "
     "Telegram de EspaKodi (t.me/espadaily), donde puedes buscar «Sección X», «+18» o «XXX».\n\n"
     "Al pulsar esta fila tecleas el PIN nuevo, se te pide repetirlo para confirmar, y a partir "
     "de entonces se usa el tuyo: no vuelve a preguntar el de Telegram y este aviso desaparece.\n\n"
     "Del tuyo solo se guarda la huella, nunca el PIN en claro."),
    ("adult_ok", None, None, False, None),
    ("log_on", "Avisos en el log de Kodi", ((True, "Sí"), (False, "No")), True,
     _PLOT_LOG_ON),
    # Al FINAL a propósito: `xxx_set` va por URL con `?action=xxx_set&i=N` y el N es
    # posicional. Si este se metiera delante, `adult_confirm` (7) y `pin_on` (8) se
    # desplazarían y una URL escrita a mano apagaría una puerta distinta de la que su
    # autor cree. Hay un test que mira que esos dos índices no cambien, y este tiene que
    # quedar después de ellos.
)


def _texto_de(indice, valor):
    """El valor de un ajuste, en palabras."""
    clave, etiqueta, valores, es_bool, _plot = OPCIONES[indice]
    if clave == "pin_hash":
        cfg = _cfg()
        if _es_pin_publico(cfg):
            return "el de Telegram (público) - cambiar"
        return "el tuyo" if valor else "sin configurar"
    if clave in ("per_page", "timeout"):
        return "{0} s".format(valor) if clave == "timeout" else str(valor)
    for v, nombre in (valores or ()):
        if v == valor:
            return nombre
    return str(valor)


def _boton_de_ajuste(cfg, indice):
    """Un botón por ajuste: la etiqueta lleva el valor actual y el plot explica."""
    clave, etiqueta, _valores, _es_bool, plot = OPCIONES[indice]
    if etiqueta is None:
        return
    actual = _texto_de(indice, cfg.get(clave))
    if clave == "pin_hash":
        _boton_accion("{0}: [COLOR green]{1}[/COLOR]".format(etiqueta, actual),
                      "xxx_pin_cambiar", ICO_AJUSTES, plot)
        return
    color = "green" if clave in ("quality", "order") else "grey"
    _fila_dir("{0}: [COLOR {1}]{2}[/COLOR]".format(etiqueta, color, actual),
              {"action": "xxx_set", "i": indice}, ICO_AJUSTES, plot, is_folder=False)


def ajustes():
    """Ajustes de la sección, en botones. Mismo estilo que la sección de Opciones de EspaTV:
    el valor actual va en la etiqueta y el plot explica qué hace."""
    if not _puertas():
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    cfg = _cfg()
    _fin("{0} · Ajustes".format(NOMBRE))
    # También aquí: quien entra en Ajustes a cambiar el PIN se encuentra el aviso justo antes de
    # hacerlo, y quien ya lo ha cambiado no ve nada.
    _recuerda_cambiar_el_pin()
    for i in range(len(OPCIONES)):
        _boton_de_ajuste(cfg, i)
    _boton_accion("Vaciar caché de la sección", "xxx_cache_clear", ICO_AJUSTES,
                  "Olvida las listas que ya se han pedido, para que vuelvan a descargarse.")
    _boton_accion("Aviso legal y DMCA", "xxx_legal", ICO_AJUSTES,
                  "De quién es el contenido y dónde está el aviso de cada plataforma.")
    # Le faltaba, y es la última pantalla de carpetas de la sección sin ella: con la vista del
    # skin, 12 filas con el mismo icono y sin texto al lado.
    _forzar_vista_wide()
    xbmcplugin.endOfDirectory(_h())


def _claves_de(valores):
    """La lista de valores reales de un ajuste.

    Los ajustes con texto llevan pares (clave, rótulo) y los de número llevan el número solo.
    Recorrer los valores tal cual guardaba la tupla entera ("ahorro", "Ahorro de datos") en vez
    de la clave, y `_cfg()` lo tiraba en el siguiente volcado: el botón no hacía nada.
    """
    if not valores:
        return []
    primero = valores[0]
    if isinstance(primero, (list, tuple)):
        return [v[0] for v in valores]
    return list(valores)


def _avanzar(valor, claves, es_bool):
    if es_bool:
        return not valor
    if not claves:
        return valor
    actual = claves.index(valor) if valor in claves else 0
    return claves[(actual + 1) % len(claves)]


def ajuste_set(clave, i):
    """Un ajuste por action: la fila es un botón que va saltando de valor en valor.

    El segundo parámetro se llama `i` porque es el nombre de la clave en la URL, igual que
    `play()` y sus demas. El dispatcher los pasa posicionalmente.

    Pide el PIN, y no por casualidad: `xxx_set` es la acción que escribe en disco los dos
    ajustes que gobiernan las puertas (`pin_on` y `adult_confirm`). Sin puerta, unas pocas
    URLs escritas a mano (`?action=xxx_set&i=7` y `&i=8`) apagaban las dos puertas sin
    preguntar nada, y el estado sobrevive a reiniciar Kodi.

    Los índices son 7 y 8 porque `_AVISOS` cuenta también `adult_ok`, que no sale en pantalla.
    Con la tupla de `OPCIONES` de hoy son: 0 per_page, 1 thumbsize, 2 order, 3 gay, 4 quality,
    5 timeout, 6 vista, 7 adult_confirm, 8 pin_on, 9 pin_hash, 10 adult_ok. Si se añade o quita
    un ajuste delante, este comentario hay que rehacerlo: hay un test que mira que el índice de
    `pin_on` sea el que dice.
    """
    if not pin_gate():
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    cfg = _cfg()
    try:
        real, etiqueta, valores, es_bool, _plot = OPCIONES[int(i)]
    except (TypeError, ValueError, IndexError):
        # `i=abc`, `i=` o `i=99999` desde una URL a mano: el directorio se cierra y no
        # aparece el dialogo de error generico de EspaTV con la pantalla colgada.
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    if int(i) < 0 or etiqueta is None:
        # Los negativos viven en la tupla (Python cuenta hacia atras) y `adult_ok` no se
        # cambia desde aqui: se cambia confirmando el aviso de +18.
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    cfg[real] = _avanzar(cfg.get(real), _claves_de(valores), es_bool)
    if not _guardar_cfg(cfg):
        # Si falla el guardado, se avisa para no repintar la interfaz con un valor no persistido.
        _aviso_escritura("el ajuste")
        return
    # Update en vez de Refresh: el submenú se redibuja y no se queda con la lista anterior.
    xbmc.executebuiltin("Container.Update({0},replace)".format(_u(action="xxx_ajustes")))


def cache_clear():
    # Puerta del PIN, pero no la de la edad: esto no enseña contenido, y pedir las dos sería
    # preguntar dos veces por vaciar una papelera.
    if not _puertas(con_edad=False):
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    api.limpiar_cache()
    # Las miniaturas de RedTube en disco también forman parte de la caché local.
    _vaciar_thumbs_rt()
    _notifica("Caché de la sección vaciada.")
    # Cierra el directorio para evitar bloqueos de resolución en Kodi.
    _cierra(_h())


def legal():
    # Puerta del PIN y no la de la edad: un aviso legal no es contenido adulto.
    if not _puertas(con_edad=False):
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    xbmcgui.Dialog().ok(
        NOMBRE,
        "Contenido +18. Solo para adultos.\n\n"
        "Todo el contenido pertenece a cada plataforma y a sus usuarios. Cada vídeo se "
        "reproduce desde lo que la propia web pone a disposición de cualquier visitante: "
        "su API pública o su reproductor web. No hay re-subidas ni copias.\n\n"
        "DMCA y contacto:\n"
        "· Eporner: https://www.eporner.com/dmca/\n"
        "· RedTube y Pornhub: en sus propias webs.\n\n"
        "El PIN de acceso se publica en el canal de Telegram de EspaKodi (t.me/espadaily).")
    # Cerrar el directorio, por lo mismo que `cache_clear()`: es un botón y no pinta nada, así
    # que sin esto Kodi se queda sin resolución.
    _cierra(_h())


def abrir_web(src, vid, pagina=""):
    """'Abrir en la web' del menú contextual: la página del vídeo en el navegador del sistema.

    Reutiliza `abrir_url()` de espakodi_installer, que es la vía del proyecto: pregunta antes,
    avisa de "Abriendo la web..." en Android y, si el navegador no abre, muestra la URL para
    copiarla. Si ese módulo no está (no debería), se cae a `webbrowser` y luego al diálogo con
    la URL, que es lo que nunca debe faltar: el usuario tiene que poder llegar al vídeo.

    Pide el PIN y el aviso +18 como el resto de la sección. Con la sesión ya desbloqueada y el
    aviso ya confirmado, ninguna de las dos vuelve a preguntar.
    """
    if not pin_gate():
        return
    if not adult_gate():
        return
    url = api.url_web(src, vid, pagina)
    if not url:
        xbmcgui.Dialog().notification(NOMBRE, "No sé qué vídeo es ese.",
                                      xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    pregunta = ("Se va a abrir en el navegador del sistema: {0}.\n\n"
                "La web enseña su propio reproductor y su publicidad, y ya puede tener la edad "
                "que tenga. Aquí dentro no.".format(api.NOMBRES.get(src, NOMBRE)))
    # El try se limita al import: un fallo de abrir_url (que solicita confirmación al usuario)
    # no debe derivar en aperturas de URL no autorizadas.
    try:
        import espakodi_installer
    except Exception as e:
        _log("espakodi_installer no disponible: {0}".format(e), xbmc.LOGWARNING)
    else:
        espakodi_installer.abrir_url(url, NOMBRE, pregunta, "Abriendo la web...")
        return
    try:
        import webbrowser
        if webbrowser.open(url):
            return
    except Exception as e:
        _log("webbrowser no pudo abrir: {0}".format(e), xbmc.LOGWARNING)
    xbmcgui.Dialog().ok(NOMBRE, "No se pudo abrir el navegador.\n\nAbre a mano:\n{0}".format(url))


# ------------------------------------------------------------- reproducción
def play(src, vid, titulo="", length="", views="", rate="", thumb="", added="", pagina=""):
    """Resuelve y reproduce. La URL firmada se pide en el momento y no se cachea.

    Los nombres de los parametros son LOS MISMOS que las claves de la URL (`length`, `views`,
    `rate`, `thumb`), a proposito: el dispatcher los pasa posicionalmente y antes se llamaban
    `dur` y `vistas`, asi que una reordenacion de la firma no se notaba.
    """
    if not pin_gate():
        _no_resuelto(_h())
        return
    # La puerta +18 también aquí, no solo en menu(). `?action=xxx_play&src=ep&vid=<id>`
    # escrita a mano entraba directo a reproducir, y el PIN de 4 dígitos publicado en un canal
    # abierto no pretende ser seguridad: es la única puerta que quedaba.
    if not adult_gate():
        _no_resuelto(_h())
        return
    cfg = _cfg()
    if not vid:
        xbmcgui.Dialog().notification(NOMBRE, "No sé qué vídeo es ese.",
                                      xbmcgui.NOTIFICATION_ERROR, 3000)
        _no_resuelto(_h())
        return
    # `fix_thumb()` antes de guardar, como hace `fav_add()`. Sin esto, un `file:///...` escrito
    # a mano en la URL queda en el JSON del historial. No llega al `setArt` porque `_leer_lista()`
    # filtra al leer, pero el fichero en disco sí lo guarda, y `backups.py` mete ese fichero en el
    # .zip que la gente comparte.
    entrada_hist = {"src": src, "id": vid, "title": titulo or vid,
                    "thumb": api.fix_thumb(thumb),
                    "length": length, "length_sec": api.dur_to_sec(length),
                    "views": _numero(views), "rate": _numero(rate),
                    # La página real, para que "Abrir en la web" desde el Historial abra la del
                    # vídeo y no el embed (ver `fav_add`).
                    "page": pagina if isinstance(pagina, str) else ""}
    fecha = _fecha_de({"added": added})
    if fecha:
        entrada_hist["added"] = fecha
    url, motivo = "", ""
    try:
        dlg = xbmcgui.DialogProgress()
        dlg.create(NOMBRE, "Buscando el vídeo...")
        try:
            url, motivo = api.resolver(src, vid, quality=cfg["quality"],
                                       timeout=cfg["timeout"])
        except Exception as e:
            _log("resolve {0}: {1}".format(src, e), xbmc.LOGWARNING)
            url, motivo = "", "No se ha podido buscar el vídeo."
        # El botón de cancelar se mira de verdad. Antes se enseñaba y no hacía nada, que es peor
        # que no enseñarlo. El resolver no se puede interrumpir a medias (las peticiones van
        # dentro de `api`), así que el aviso sale al terminar el intento en curso.
        if url:
            try:
                if dlg.iscanceled():
                    url, motivo = "", "Has cancelado."
            except Exception:
                pass
    except Exception as e:
        _log("diálogo de progreso: {0}".format(e), xbmc.LOGWARNING)
        url, motivo = "", ""
    finally:
        try:
            dlg.close()
        except Exception:
            pass

    if not url:
        # Modal y no toast. El toast de 5 s se iba solo mientras el usuario miraba el fallo, y el
        # fallo más frecuente (vídeo no disponible) es justo el que más lo necesita. El addon de
        # origen abría un `Dialog().ok` con las causas (main.py:1039-1042).
        xbmcgui.Dialog().ok(
            NOMBRE,
            (motivo or "No se ha podido reproducir.") +
            "\n\nPuede ser que no tengas conexión, que el vídeo se haya retirado de la web "
            "o que tenga un límite temporal de descargas. Prueba otra vez o elige otro vídeo.")
        _no_resuelto(_h())
        return

    # El historial se apunta AHORA, con la URL ya resuelta. Antes se apuntaba antes de resolver,
    # y `api.resolver()` reintenta una vez, así que un vídeo retirado, un corte de red o uno con
    # la URL caducada entraban en el historial sin haberse reproducido nada. Y el historial dice
    # "Lo que has reproducido en esta sección", así que eso era mentira. El addon de origen
    # apunta solo si hay stream (main.py:1045-1050), y ahora también este.
    try:
        _apuntar_hist(entrada_hist)
    except Exception as e:
        _log("historial {0}: {1}".format(src, e), xbmc.LOGWARNING)

    # El Referer va con quote_plus y el UA con ua_desktop_pipe_encoded: parse_url_with_headers
    # no hace unquote, y el UA de Chrome lleva espacios y paréntesis.
    ref = urllib.parse.quote_plus(api.referer_de(src))
    destino = "{0}|User-Agent={1}&Referer={2}".format(url, ua_desktop_pipe_encoded(), ref)
    li = xbmcgui.ListItem(path=destino)
    li.setInfo("video", {"title": titulo or vid})
    xbmcplugin.setResolvedUrl(_h(), True, listitem=li)