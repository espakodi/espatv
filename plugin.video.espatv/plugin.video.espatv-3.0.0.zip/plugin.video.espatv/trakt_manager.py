# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
import os
import sys
import json
import time
import threading
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import requests

import core_settings


_TRAKT_API_BASE = "https://api.trakt.tv"
_TMDB_API_BASE = "https://api.themoviedb.org/3"
_TMDB_IMG_BASE = "https://image.tmdb.org/t/p/w342"


def _trakt_headers(api_key):
    return {
        'Content-Type': 'application/json',
        'trakt-api-version': '2',
        'trakt-api-key': api_key,
    }


_MSG_NO_KEY = (
    "No hay ninguna Client ID de Trakt configurada.\n"
    "Configúrala en Opciones > Configurar API Key."
)

_MSG_TOPZILLA = (
    "La versión completa de Trakt (tu cuenta, watchlist, listas personales y "
    "sincronización) está en TopZilla."
)

_MSG_FORBIDDEN = (
    "Trakt ha rechazado la petición (403).\n"
    "Casi siempre significa que la Client ID configurada ya no es válida: revisa que la copiaste "
    "entera, que la app sigue existiendo en developer.trakt.tv y que no ha sido "
    "borrada por 30 días sin uso.\n"
    "En listas concretas también ocurre si el perfil del dueño de la lista es privado.\n\n"
    + _MSG_TOPZILLA
)


_PAGINA = 250          # máximo que acepta Trakt; por defecto pagina de 100 en 100
_LISTA_TTL_S = 86400
_TMDBHELPER_ID = "plugin.video.themoviedb.helper"


def _tmdbhelper_list_url(list_id, user):
    """URL para abrir la colección en TMDb Helper, o None si no está instalado.

    TMDb Helper lleva su propia clave de Trakt, así que sirve de salida cuando la
    nuestra falla. Su ruta pide el slug de la lista, pero Trakt acepta ahí el id
    numérico, así que no hay que guardar slugs aparte.
    """
    # AddonIsEnabled y no HasAddon: con TMDb Helper desactivado, su plugin:// no abre.
    if not user or not xbmc.getCondVisibility("System.AddonIsEnabled({0})".format(_TMDBHELPER_ID)):
        return None
    params = urllib.parse.urlencode({
        'info': 'trakt_userlist', 'list_slug': list_id, 'user_slug': user})
    return "plugin://{0}/?{1}".format(_TMDBHELPER_ID, params)


def _get_items_cache_path(list_id):
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    return os.path.join(p, "trakt_items_{0}.json".format(list_id))


def _clear_items_cache(list_id):
    try:
        path = _get_items_cache_path(list_id)
        if os.path.exists(path):
            os.remove(path)
    except OSError as e:
        xbmc.log("[EspaTV-TM] no se pudo borrar cache de {0}: {1}".format(list_id, e), xbmc.LOGWARNING)


def _fetch_list_items(list_id, key):
    """Todas las páginas de una lista, con caché de un día. Devuelve (items, error).

    Se pide sin extended=full: Trakt manda 1738 bytes por ítem con él y 312 sin él,
    y lo único que se pierde (overview, tagline) lo sobrescribe metadata_enricher
    con TMDB en español.
    """
    path = _get_items_cache_path(list_id)
    try:
        with open(path, 'r', encoding='utf-8') as f:
            guardado = json.load(f)
        if time.time() - guardado['ts'] < _LISTA_TTL_S:
            return guardado['items'], None
    except (OSError, ValueError, KeyError, TypeError):
        pass

    headers = _trakt_headers(key)
    url = "{0}/lists/{1}/items".format(_TRAKT_API_BASE, list_id)
    items = []
    pagina = 1
    while True:
        try:
            r = requests.get(url, params={'limit': _PAGINA, 'page': pagina}, headers=headers, timeout=20)
        except requests.RequestException as e:
            xbmc.log("[EspaTV-TM] lista {0} pag {1}: {2}".format(list_id, pagina, e), xbmc.LOGWARNING)
            return None, "No se pudo conectar con Trakt"

        err = _trakt_error_msg(r)
        if err:
            return None, err
        try:
            lote = r.json()
        except ValueError:
            return None, "Respuesta no válida"
        if not isinstance(lote, list):
            return None, "Respuesta no válida"

        items.extend(lote)
        try:
            total_paginas = int(r.headers.get('X-Pagination-Page-Count', 1))
        except (TypeError, ValueError):
            total_paginas = 1
        if not lote or pagina >= total_paginas:
            break
        pagina += 1

    try:
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as f:
            json.dump({'ts': int(time.time()), 'items': items}, f, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError as e:
        xbmc.log("[EspaTV-TM] no se pudo guardar cache de {0}: {1}".format(list_id, e), xbmc.LOGWARNING)
    return items, None


def _trakt_error_msg(r):
    """None si la respuesta vale; si no, el texto que se muestra al usuario."""
    if r.status_code == 200:
        return None
    if r.status_code == 403:
        return _MSG_FORBIDDEN
    # Trakt responde 204 (no 404) cuando la colección ya no existe.
    if r.status_code in (204, 404):
        return "Esa colección ya no existe o dejó de ser pública."
    if r.status_code == 401:
        return "Esta colección requiere autorización de usuario (OAuth), que el addon no soporta."
    return "Trakt respondió con código {0}. Inténtalo más tarde.\n\n{1}".format(r.status_code, _MSG_TOPZILLA)


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def _handle():
    return int(sys.argv[1])

def _get_thumb_cache_path(list_id):
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    return os.path.join(p, "trakt_thumbs_{0}.json".format(list_id))

def _load_thumb_cache(list_id):
    path = _get_thumb_cache_path(list_id)
    if not os.path.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}

def _get_tmdb_data(tmdb_id, fallback, media_type='movie'):
    if not tmdb_id:
        return fallback, [], ''
    endpoint = 'tv' if media_type == 'show' else 'movie'
    try:
        r = requests.get(
            "{0}/{1}/{2}".format(_TMDB_API_BASE, endpoint, tmdb_id),
            params={
                "api_key": core_settings.get_tmdb_api_key(),
                "append_to_response": "credits",
                "language": "es-ES",
            },
            timeout=8,
        )
        if r.status_code == 200:
            d = r.json()
            poster_path = d.get("poster_path")
            thumb = "{0}{1}".format(_TMDB_IMG_BASE, poster_path) if poster_path else fallback
            credits = d.get('credits') or {}
            cast = [
                {
                    'name': a.get('name', ''),
                    'role': a.get('character', ''),
                    'thumbnail': "https://image.tmdb.org/t/p/w185{0}".format(a['profile_path']) if a.get('profile_path') else '',
                }
                for a in (credits.get('cast') or [])[:10]
            ]
            if media_type == 'show':
                creators = d.get('created_by') or []
                director = ', '.join(c.get('name', '') for c in creators if c.get('name')) or next(
                    (p.get('name', '') for p in (credits.get('crew') or []) if p.get('job') == 'Director'),
                    '',
                )
            else:
                director = next(
                    (p.get('name', '') for p in (credits.get('crew') or []) if p.get('job') == 'Director'),
                    '',
                )
            return thumb, cast, director
    except (requests.RequestException, ValueError):
        pass
    return fallback, [], ''

def menu_collections():
    li = xbmcgui.ListItem(label="Listas de Trakt.tv")
    li.setArt({'icon': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_root"), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(_handle())

def menu_trakt_root():
    core_settings.seed_default_trakt_lists(core_settings.get_trakt_api_key())

    if not core_settings.get_trakt_api_key():
        li = xbmcgui.ListItem(label="[COLOR orange]Trakt: falta configurar la Client ID[/COLOR]")
        li.setArt({'icon': 'DefaultIconError.png'})
        li.setInfo('video', {'plot': _MSG_NO_KEY})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_options"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Actualizar nombres y datos")
    li.setArt({'icon': _tm_media_icon('adv_refrescar.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Obtiene el nombre real y el número de ítems de todas las listas desde Trakt."})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_refresh_defaults"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR cyan]Descubrir listas de Trakt[/COLOR]")
    li.setArt({'icon': 'DefaultVideoPlaylists.png'})
    li.setInfo('video', {'plot': "Explora las listas curadas más populares y trending de Trakt.tv."})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_discover_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[COLOR blue]Opciones / Importar Lista[/COLOR]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_options"), listitem=li, isFolder=True)

    lists = core_settings.get_trakt_lists()
    for l in lists:
        # Las listas por defecto nacen con item_count=0: el número solo se enseña
        # cuando se sabe (al abrir la lista o con «Actualizar nombres y datos»).
        count = l.get('item_count') or 0
        label = l['name']
        plot = f"ID: {l['id']}\nUsuario: {l['user']}"
        if count:
            label += f" [COLOR gray]({count} ítems)[/COLOR]"
            plot += f"\nTotal: {count} elementos."
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _tm_media_icon('top_trakt_listas.png', 'DefaultFolder.png')})
        li.setInfo('video', {'plot': plot})

        cm = [("Eliminar lista", "RunPlugin({0})".format(_u(action='trakt_delete_list', list_id=l['id'])))]
        destino = _tmdbhelper_list_url(l['id'], l.get('user'))
        if destino:
            cm.append(("Abrir en TMDb Helper", "Container.Update({0})".format(destino)))
        li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_view_list", list_id=l['id']), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[COLOR gold]¿Quieres Trakt completo? Está en TopZilla[/COLOR]")
    li.setArt({'icon': _tm_media_icon('topzilla.png', 'DefaultAddonVideo.png')})
    li.setInfo('video', {'plot': "Esto es una muestra de las colecciones de Trakt.\n\n"
                                 + _MSG_TOPZILLA
                                 + "\n\nPulsa para abrirlo; si no lo tienes, te ofrece instalarlo."})
    xbmcplugin.addDirectoryItem(handle=_handle(),
                                url=_u(action="ek_launch", addon_id="plugin.video.topzilla"),
                                listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(_handle())

def refresh_all_lists():
    api_key = core_settings.get_trakt_api_key()
    if not api_key:
        xbmcgui.Dialog().ok("EspaTV", _MSG_NO_KEY)
        return
    lists = core_settings.get_trakt_lists()
    if not lists:
        xbmcgui.Dialog().notification("Trakt", "No hay listas para actualizar", xbmcgui.NOTIFICATION_INFO)
        return
    headers = _trakt_headers(api_key)
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaTV", "Actualizando listas de Trakt...")
    total = len(lists)
    ok = 0
    first_err = None
    cancelado = False
    for i, l in enumerate(lists):
        if pDialog.iscanceled():
            cancelado = True
            break
        pDialog.update(int((i / total) * 100), "({0}/{1}) {2}".format(i + 1, total, l['name']))
        # "Actualizar" tiene que traer datos frescos, no los de la cache de ayer.
        _clear_items_cache(l['id'])
        try:
            r = requests.get(
                "{0}/lists/{1}".format(_TRAKT_API_BASE, l['id']),
                headers=headers, timeout=5,
            )
            err = _trakt_error_msg(r)
            if err:
                first_err = first_err or err
                continue
            data = r.json()
            l['name'] = data.get('name', l['name'])
            user_data = data.get('user')
            if isinstance(user_data, dict):
                l['user'] = user_data.get('username', l.get('user', 'official'))
            else:
                l['user'] = l.get('user', 'official')
            l['item_count'] = data.get('item_count', l.get('item_count', 0))
            ok += 1
        except (requests.RequestException, ValueError):
            pass
    pDialog.close()
    if not ok:
        if not cancelado:
            xbmcgui.Dialog().ok("EspaTV", first_err or "No se pudo actualizar ninguna lista.")
        return
    settings = core_settings.get_trakt_settings()
    existing = {l['id']: l for l in settings.get('lists', [])}
    for l in lists:
        if l['id'] in existing:
            existing[l['id']].update(l)
    settings['lists'] = list(existing.values())
    core_settings.save_trakt_settings(settings)
    msg = "Listas actualizadas correctamente" if ok == total else "Listas actualizadas: {0}/{1}".format(ok, total)
    xbmcgui.Dialog().notification("EspaTV", msg, xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def menu_options():
    li = xbmcgui.ListItem(label="[COLOR yellow][B]Guía: Cómo obtener tu API Key (Paso a Paso)[/B][/COLOR]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    li.setInfo('video', {'plot': "Instrucciones detalladas de cómo registrarte en Trakt.tv para obtener tu propia llave Client ID."})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_help_guide"), listitem=li, isFolder=False)

    key = core_settings.get_trakt_api_key()
    status = "[COLOR green]CONFIGURADA[/COLOR]" if key else "[COLOR red]NO CONFIGURADA[/COLOR]"

    li = xbmcgui.ListItem(label="Configurar API Key {0}".format(status))
    li.setArt({'icon': 'DefaultAddonService.png'})
    key_plot = ("Pulsa aquí para introducir tu Client ID una vez lo tengas." if key else
                "El addon trae su propia clave y funciona sin configurar nada. "
                "Si prefieres usar la tuya, pulsa para introducirla.")
    li.setInfo('video', {'plot': key_plot})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_set_key"), listitem=li, isFolder=False)

    if key:
        li = xbmcgui.ListItem(label="Importar Lista por ID")
        li.setArt({'icon': 'DefaultAddonService.png'})
        li.setInfo('video', {'plot': "Introduce el ID numérico de la lista pública (ej: 21583416)"})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_import"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(_handle())

def help_guide():
    heading = "[COLOR yellow]GUÍA: CONFIGURAR TRAKT.TV[/COLOR]"
    text = (
        "[B]PASO 1: CUENTA DE TRAKT[/B]\n"
        "Regístrate gratis en [COLOR cyan]trakt.tv[/COLOR] si no tienes cuenta.\n\n"

        "[B]PASO 2: CUENTA DE GITHUB[/B]\n"
        "Trakt exige vincular una cuenta de GitHub verificada para crear apps.\n"
        "Si no tienes, créala en [COLOR cyan]github.com[/COLOR].\n\n"

        "[B]PASO 3: PORTAL DE DESARROLLADORES[/B]\n"
        "Entra en [COLOR cyan]developer.trakt.tv[/COLOR], pulsa [B]My Apps[/B] y luego\n"
        "[B]Connect GitHub[/B]. Solo hace falta una vez.\n\n"

        "[B]PASO 4: CREAR LA APP[/B]\n"
        "Pulsa [B]Create app[/B] y rellena:\n"
        " • [B]Name:[/B] EspaTV\n"
        " • [B]Description:[/B] Addon de Kodi\n"
        " • [B]Redirect uri:[/B] urn:ietf:wg:oauth:2.0:oob\n"
        " • [B]Javascript (cors) origins:[/B] (Vacío)\n"
        " • [B]Permissions:[/B] No marques nada.\n\n"

        "[B]PASO 5: OBTENER EL CÓDIGO[/B]\n"
        "Tras guardar, busca el campo [B]Client ID[/B] y cópialo entero.\n"
        "Copia ese código y pégalo en el menú 'Configurar API Key' de este addon.\n\n"
        "--------------------------------------------------\n"
        "[I]* La Client ID es personal y gratuita. Solo sirve para que el addon pueda leer las listas públicas de Trakt.tv.[/I]\n"
        "[I]* Trakt borra las apps que pasan 30 días seguidos sin uso.[/I]"
    )
    xbmcgui.Dialog().textviewer(heading, text)

def set_api_key():
    k = xbmc.Keyboard(core_settings.get_trakt_api_key(), 'Introduce Trakt Client ID (API Key)')
    k.doModal()
    if not k.isConfirmed():
        return
    new_key = k.getText().strip()
    if not new_key:
        xbmcgui.Dialog().notification("EspaTV", "No se introdujo ninguna clave", xbmcgui.NOTIFICATION_WARNING)
        return

    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaTV", "Validando API Key...")
    try:
        # Endpoint público y sin dueño: un 403 aquí solo puede ser la clave.
        r = requests.get("{0}/movies/popular?limit=1".format(_TRAKT_API_BASE),
                         headers=_trakt_headers(new_key), timeout=10)
        pDialog.close()
        if r.status_code == 200:
            core_settings.set_trakt_api_key(new_key)
            xbmcgui.Dialog().notification("EspaTV", "API Key Guardada", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        elif r.status_code == 403:
            xbmcgui.Dialog().ok("Client ID no reconocida", "Trakt no reconoce esta Client ID.\nRevisa que la copiaste entera, que la app existe en developer.trakt.tv y que no ha sido borrada por 30 días sin uso.")
        else:
            xbmcgui.Dialog().ok("EspaTV", "Trakt respondió con código {0}. Inténtalo más tarde.".format(r.status_code))
    except requests.RequestException as e:
        pDialog.close()
        xbmcgui.Dialog().ok("Error de red", "No se pudo conectar con Trakt.tv:\n{0}".format(e))

def import_list():
    key = core_settings.get_trakt_api_key()
    if not key:
        xbmcgui.Dialog().ok("EspaTV", _MSG_NO_KEY)
        return

    k = xbmc.Keyboard('', 'Introduce ID numérico de la lista')
    k.doModal()
    if not k.isConfirmed():
        return
    list_id = k.getText().strip()
    if not list_id:
        return

    headers = _trakt_headers(key)
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaTV", "Importando lista de Trakt...")
    try:
        r = requests.get(
            "{0}/lists/{1}".format(_TRAKT_API_BASE, list_id),
            headers=headers, timeout=15,
        )
        err = _trakt_error_msg(r)
        if err:
            xbmcgui.Dialog().ok("EspaTV", err)
            return
        data = r.json()
        name = data.get('name', 'Lista {0}'.format(list_id))
        user_data = data.get('user', {})
        user = user_data.get('username', 'Unknown') if isinstance(user_data, dict) else 'Unknown'
        item_count = data.get('item_count', 0)
        core_settings.add_trakt_list(list_id, name, user, item_count)
    except (requests.RequestException, ValueError) as e:
        xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)
        return
    finally:
        pDialog.close()

    if xbmcgui.Dialog().yesno("EspaTV", "Lista '{0}' importada con éxito.\n\n¿Quieres abrirla ahora mismo?".format(name)):
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='trakt_view_list', list_id=list_id)))
    else:
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='trakt_root')))

def _trigger_bg_enrich_trakt(items):
    import metadata_enricher as me
    def _fetch():
        try:
            results = me.batch_enrich(items, max_workers=2)
            if any(results):
                xbmc.executebuiltin("Container.Refresh")
        except Exception:
            pass
    threading.Thread(target=_fetch, daemon=True).start()


def _recordar_item_count(list_id, total):
    """Deja en trakt_settings.json cuantos titulos tiene una lista.

    Lo usa el rotulo de la pantalla de listas. Solo se escribe si el numero ha
    cambiado de verdad, para no tocar el fichero en cada apertura.
    """
    for l in core_settings.get_trakt_lists():
        if str(l.get('id')) != str(list_id):
            continue
        if l.get('item_count') == total:
            return
        core_settings.add_trakt_list(
            str(list_id), l.get('name') or '', l.get('user') or '', total)
        return


def view_list(list_id, show_covers=False):
    try:
        key = core_settings.get_trakt_api_key()
        if not key:
            xbmcgui.Dialog().ok("EspaTV", _MSG_NO_KEY)
            xbmcplugin.endOfDirectory(_handle())
            return

        items, err = _fetch_list_items(list_id, key)
        if err:
            user = next((l.get('user') for l in core_settings.get_trakt_lists()
                         if str(l.get('id')) == str(list_id)), '')
            destino = _tmdbhelper_list_url(list_id, user)
            if destino:
                abrir = xbmcgui.Dialog().yesno(
                    "EspaTV", "{0}\n\n¿Abrir esta colección en TMDb Helper?".format(err),
                    nolabel="Cerrar", yeslabel="Abrir")
            else:
                abrir = False
                xbmcgui.Dialog().ok("EspaTV", err)
            xbmcplugin.endOfDirectory(_handle())
            if abrir:
                xbmc.executebuiltin("Container.Update({0})".format(destino))
            return

        import metadata_enricher as me
        addon = xbmcaddon.Addon()
        ai = addon.getAddonInfo('icon')
        af = addon.getAddonInfo('fanart')

        # Respuesta vacía de Trakt: muestra un ítem informativo en vez de una carpeta vacía.
        if not items:
            li = xbmcgui.ListItem(
                label="[COLOR grey][I]Esta colección está vacía o ya no existe[/I][/COLOR]")
            li.setArt({'icon': ai})
            li.setInfo('video', {'plot': "Trakt ha contestado, pero esta colección no tiene títulos.\n"
                                         "Puede que su autor la haya vaciado o la haya borrado."})
            xbmcplugin.addDirectoryItem(handle=_handle(), url="", listitem=li, isFolder=False)
            xbmcplugin.endOfDirectory(_handle())
            return

        if isinstance(items, list):
            _recordar_item_count(list_id, len(items))

        # trakt_thumbs cache: compatibilidad hacia atrás para usuarios que ya tenían carátulas guardadas
        cache = _load_thumb_cache(list_id)

        missing_meta = []

        for item in items:
            if not isinstance(item, dict):
                continue
            t = item.get('type')
            data = item.get(t)
            if not data:
                continue

            title = data.get('title')
            year = data.get('year')
            overview = data.get('overview') or ''
            tagline = data.get('tagline') or ''
            genres = data.get('genres') or []
            rating = data.get('rating') or 0
            runtime = data.get('runtime') or 0
            certification = data.get('certification') or ''
            ids = data.get('ids') or {}
            tmdb_id = ids.get('tmdb')
            imdb_id = ids.get('imdb') or ''

            item_key = "{0}_{1}".format(title, year)
            label = "{0} ({1})".format(title, year) if year else title
            li = xbmcgui.ListItem(label=label)

            meta = me.enrich(
                tmdb_id=tmdb_id, imdb_id=imdb_id,
                title=title, year=year,
                media_type=t, use_cache_only=True,
            )

            if meta:
                me.apply_to_listitem(li, meta, addon_fanart=af)
                thumb = meta.get('poster') or ai
            else:
                cached = cache.get(item_key)
                if isinstance(cached, dict):
                    thumb = cached.get('thumb') or ai
                    cast = cached.get('cast') or []
                    director = cached.get('director') or ''
                elif cached:
                    thumb = cached or ai
                    cast, director = [], ''
                else:
                    thumb = ai
                    cast, director = [], ''
                    missing_meta.append({
                        'tmdb_id': tmdb_id,
                        'imdb_id': imdb_id,
                        'title': title,
                        'year': year,
                        'media_type': t,
                    })

                li.setArt({'icon': 'DefaultVideo.png', 'thumb': thumb, 'poster': thumb, 'fanart': af})
                li.setInfo('video', {
                    'title': title,
                    'year': year,
                    'plot': "[B]{0}[/B]\n\n{1}".format(tagline, overview) if tagline else overview,
                    'mediatype': 'movie' if t == 'movie' else 'tvshow',
                    'genre': ' / '.join(genres),
                    'rating': rating,
                    'mpaa': certification,
                    'duration': runtime * 60 if runtime else 0,
                    'director': director,
                })
                if cast:
                    li.setCast(cast)

            params_json = json.dumps({'q': title})
            fav_url = _u(action='add_favorite', title=title, fav_url=title, icon=thumb, platform='Trakt', fav_action='lfr', params=params_json)
            li.addContextMenuItems([("Añadir a Mis Favoritos", "RunPlugin({0})".format(fav_url))])

            li.setProperty('IsPlayable', 'false')
            play_url = _u(action='search_alt_prompt', q=title, ot=thumb,
                          mode=('movie' if t == 'movie' else 'show'), tmdb_id=(tmdb_id or ''))
            xbmcplugin.addDirectoryItem(handle=_handle(), url=play_url, listitem=li, isFolder=False)

        if missing_meta:
            _trigger_bg_enrich_trakt(missing_meta)

        xbmcplugin.endOfDirectory(_handle())
    except (requests.RequestException, ValueError, RuntimeError, OSError) as e:
        xbmcgui.Dialog().ok("Error Trakt", "Ocurrió un error al ver la lista:\n{0}".format(e))

def cache_covers(list_id):
    if not xbmcgui.Dialog().yesno(
        "EspaTV",
        "[B]AVISO DE CARGA:[/B]\n\n"
        "Al guardar las carátulas, el addon mostrará las fotos siempre que entres.\n\n"
        "Esto hará que la lista [COLOR yellow]tarde más en cargar[/COLOR] cada vez.\n\n"
        "¿Quieres continuar con la descarga?",
    ):
        return

    key = core_settings.get_trakt_api_key()
    if not key:
        xbmcgui.Dialog().ok("EspaTV", _MSG_NO_KEY)
        return
    items, err = _fetch_list_items(list_id, key)
    if err:
        xbmcgui.Dialog().ok("EspaTV", err)
        return

    if not isinstance(items, list):
        msg = items.get('message', 'Error desconocido') if isinstance(items, dict) else "Respuesta no válida"
        xbmcgui.Dialog().ok("Error Trakt", "No se pudo obtener la lista para cachear:\n{0}".format(msg))
        return

    total = len(items)
    if total == 0:
        xbmcgui.Dialog().notification("Trakt", "La lista está vacía", xbmcgui.NOTIFICATION_INFO)
        return

    # Se guarda el numero real. Las listas por defecto se crean con item_count=0
    # y nadie lo actualizaba, asi que el rotulo nunca ensenaba cuantos titulos
    # tiene una lista aunque se hayan cargado mil. Con esto, la segunda vez que
    # se entra ya lo dice.
    _recordar_item_count(list_id, total)

    cache = {}
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaTV", "Descargando carátulas...")
    try:
        for i, item in enumerate(items):
            if pDialog.iscanceled():
                break
            if not isinstance(item, dict):
                continue
            t = item.get('type')
            data = item.get(t)
            if not data:
                continue
            title = data.get('title')
            year = data.get('year')
            tmdb_id = data.get('ids', {}).get('tmdb')
            item_key = "{0}_{1}".format(title, year)
            percent = int((float(i) / total) * 100)
            pDialog.update(percent, "Procesando ({0}/{1}): {2}".format(i, total, title))
            thumb, cast, director = _get_tmdb_data(tmdb_id, None, t)
            if thumb:
                cache[item_key] = {'thumb': thumb, 'cast': cast, 'director': director}
    finally:
        pDialog.close()

    if not cache:
        return

    try:
        core_settings.atomic_write_json(_get_thumb_cache_path(list_id), cache)
    except OSError as e:
        xbmcgui.Dialog().ok("Error Cache", "No se pudo escribir el archivo:\n{0}".format(e))
        return

    xbmcgui.Dialog().notification("EspaTV", "Carátulas guardadas correctamente", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def clear_cache(list_id):
    path = _get_thumb_cache_path(list_id)
    if not os.path.exists(path):
        return
    try:
        os.remove(path)
    except OSError as e:
        xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification("EspaTV", "Cache eliminada: Volvemos a carga rápida", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def delete_list(list_id):
    if xbmcgui.Dialog().yesno("Eliminar Lista", "¿Seguro que quieres borrar esta lista de tu colección?"):
        core_settings.remove_trakt_list(list_id)
        _clear_items_cache(list_id)
        xbmc.executebuiltin("Container.Refresh")


# Descubrimiento de listas curadas de Trakt

def _discovery_cache_path():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(p, 'espatv_trakt_discovery_cache.json')

def _load_discovery_cache():
    try:
        path = _discovery_cache_path()
        if not os.path.exists(path):
            return {}
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}

def _save_discovery_cache(data):
    try:
        path = _discovery_cache_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError:
        pass

_DISCOVERY_TTL = 6 * 3600

def _fetch_list_index(path, page=1):
    cache = _load_discovery_cache()
    cache_key = "{0}|{1}".format(path, page)
    entry = cache.get(cache_key, {})
    now = time.time()
    if entry and (now - entry.get('ts', 0)) < _DISCOVERY_TTL:
        return entry['lists'], entry.get('total_pages', 1)

    api_key = core_settings.get_trakt_api_key()
    if not api_key:
        stale = entry.get('lists')
        return (stale, entry.get('total_pages', 1)) if stale else ([], 1)
    headers = _trakt_headers(api_key)
    url = "{0}/{1}".format(_TRAKT_API_BASE, path)
    try:
        r = requests.get(url, params={'limit': 20, 'page': page}, headers=headers, timeout=12)
        if r.status_code != 200:
            stale = entry.get('lists')
            return (stale, entry.get('total_pages', 1)) if stale else ([], 1)
        raw = r.json()
        total_pages = int(r.headers.get('X-Pagination-Page-Count', 1))
    except (requests.RequestException, ValueError):
        stale = entry.get('lists')
        return (stale, entry.get('total_pages', 1)) if stale else ([], 1)

    lists = []
    for item in (raw if isinstance(raw, list) else []):
        lst = item.get('list') or item  # trending wraps in {"like_count": N, "list": {...}}
        lid  = (lst.get('ids') or {}).get('trakt')
        name = (lst.get('name') or '').strip()
        if not lid or not name:
            continue
        user = (lst.get('user') or {}).get('username') or ''
        lists.append({
            'id':         lid,
            'name':       name,
            'desc':       (lst.get('description') or '').strip(),
            'user':       user,
            'item_count': lst.get('item_count') or 0,
            'likes':      item.get('like_count') or lst.get('likes') or 0,
        })

    cache[cache_key] = {'ts': now, 'lists': lists, 'total_pages': total_pages}
    _save_discovery_cache(cache)
    return lists, total_pages


def _tm_media_icon(name, fallback='DefaultVideoPlaylists.png'):
    p = os.path.join(
        xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path')),
        'resources', 'media', name,
    )
    return p if os.path.exists(p) else fallback


def menu_discover_lists():
    h = _handle()
    entries = [
        ("Listas trending ahora", "trakt_browse_list_index", "lists/trending",
         "Las listas curadas más populares en este momento en Trakt.tv.",
         'top_lists_trending.png'),
        ("Listas más populares",  "trakt_browse_list_index", "lists/popular",
         "Las listas con más seguidores de toda la historia de Trakt.tv.",
         'top_lists_popular.png'),
        ("Buscar listas...",      "trakt_search_lists",      "",
         "Busca listas de Trakt por nombre o temática.",
         'adv_busqueda.png'),
    ]
    for label, action, path, plot, icon_file in entries:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _tm_media_icon(icon_file)})
        li.setInfo('video', {'plot': plot})
        kwargs = {'action': action}
        if path:
            kwargs['path'] = path
        xbmcplugin.addDirectoryItem(handle=h, url=_u(**kwargs), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def browse_list_index(path, page=1):
    h = _handle()
    page = int(page)
    lists, total_pages = _fetch_list_index(path, page)
    if not lists:
        if core_settings.get_trakt_api_key():
            xbmcgui.Dialog().notification("EspaTV", "No se encontraron listas", xbmcgui.NOTIFICATION_INFO)
        else:
            xbmcgui.Dialog().ok("EspaTV", _MSG_NO_KEY)
        xbmcplugin.endOfDirectory(h)
        return
    for lst in lists:
        count = lst['item_count']
        likes = lst['likes']
        parts = []
        if lst['user']:
            parts.append("por {0}".format(lst['user']))
        if count:
            parts.append("{0} ítems".format(count))
        if likes:
            parts.append("{0} likes".format(likes))
        subtitle = "  ·  ".join(parts)
        label = "{0}  [COLOR gray]{1}[/COLOR]".format(lst['name'], subtitle) if subtitle else lst['name']
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _tm_media_icon('top_trakt_listas.png')})
        lines = [lst['desc']] if lst['desc'] else []
        if subtitle:
            lines.append(subtitle)
        li.setInfo('video', {'plot': '\n'.join(lines)})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='trakt_view_list', list_id=lst['id']),
            listitem=li,
            isFolder=True,
        )
    if page < total_pages:
        li = xbmcgui.ListItem(
            label="[COLOR limegreen]Página siguiente ({0}/{1})[/COLOR]".format(page + 1, total_pages))
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='trakt_browse_list_index', path=path, page=page + 1),
            listitem=li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


def search_trakt_lists():
    kb = xbmc.Keyboard('', 'Buscar listas en Trakt.tv')
    kb.doModal()
    if not kb.isConfirmed():
        xbmcplugin.endOfDirectory(_handle())
        return
    query = kb.getText().strip()
    if not query:
        xbmcplugin.endOfDirectory(_handle())
        return

    api_key = core_settings.get_trakt_api_key()
    if not api_key:
        xbmcgui.Dialog().ok("EspaTV", _MSG_NO_KEY)
        xbmcplugin.endOfDirectory(_handle())
        return

    headers = _trakt_headers(api_key)
    url = "{0}/search".format(_TRAKT_API_BASE)
    try:
        r = requests.get(url, params={'type': 'list', 'query': query, 'limit': 20},
                         headers=headers, timeout=12)
        err = _trakt_error_msg(r)
        if err:
            xbmcgui.Dialog().ok("EspaTV", err)
            xbmcplugin.endOfDirectory(_handle())
            return
        raw = r.json()
    except (requests.RequestException, ValueError):
        raw = []

    h = _handle()
    lists = []
    for item in (raw if isinstance(raw, list) else []):
        lst = item.get('list') or {}
        lid  = (lst.get('ids') or {}).get('trakt')
        name = (lst.get('name') or '').strip()
        if not lid or not name:
            continue
        user = (lst.get('user') or {}).get('username') or ''
        lists.append({
            'id': lid, 'name': name,
            'desc': (lst.get('description') or '').strip(),
            'user': user, 'item_count': lst.get('item_count') or 0, 'likes': 0,
        })

    if not lists:
        xbmcgui.Dialog().notification("EspaTV", "Sin resultados para: {0}".format(query),
                                      xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(h)
        return

    for lst in lists:
        parts = ["por {0}".format(lst['user'])] if lst['user'] else []
        if lst['item_count']:
            parts.append("{0} ítems".format(lst['item_count']))
        subtitle = "  ·  ".join(parts)
        label = "{0}  [COLOR gray]{1}[/COLOR]".format(lst['name'], subtitle) if subtitle else lst['name']
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _tm_media_icon('top_trakt_listas.png')})
        li.setInfo('video', {'plot': lst['desc'] or subtitle})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action='trakt_view_list', list_id=lst['id']),
            listitem=li, isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)
