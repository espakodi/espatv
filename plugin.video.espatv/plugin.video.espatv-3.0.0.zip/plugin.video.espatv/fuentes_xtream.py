# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Hablar con un servidor Xtream. Un solo sitio donde se hace.

Existe por una razón concreta: a partir de la fase F2 **todas** las vistas leen del servidor.
Si cada vista hablara con `player_api.php` por su cuenta, habría cinco sitios que podrían
olvidar el `lan_ok=True`, cinco que podrían tratar mal un panel apagado, y cinco que podrían
filtrar el usuario o la clave en el log.

Lo que este módulo envuelve, y no reimplementa:

- `iptv_lists._xtream_api()` ya sabe descargar con tope de tamaño, con
  cancelación desde el `DialogProgress`, reintentando un 403 como VLC, yDeadline que corta a
  un servidor que manda la lista gota a gota.
- `iptv_parse.xtream_categories()` ya normaliza las categorías.
- `iptv_parse.xtream_channels()` ya monta las URLs y los `new_channel`.
  **No se reutiliza**, y es deliberado: mete el usuario y la clave en la URL de cada canal, que
  es justo lo que no puede salir de aquí. Se reusan `clean_name()` y el reparto de extensiones.
- `fuentes_store.cache_leer/escribir()` ya dan la caché con TTL y sin reventar nunca.

Lo que añade, que es lo propio de la sección:

- `cuenta()`, `categorias()` y `listado()` con **paginación**, que `iptv_lists._xtream_fetch`
  no tiene: ese pide `get_live_streams` entero, y un servidor con 18 000 canales son 18 000
  entradas de golpe. Aquí van de 100 en 100.
- La caché con TTL de la propia sección, para que "Atrás" sea instantáneo y no cueste red.

Cuatro reglas que no hay que romper aquí:

- **Ninguna URL con credenciales sale de este módulo hacia un `plugin://`.** `url_de()`
  devuelve la URL, que lleva usuario y clave en el camino, y solo se usa al reproducir. En la
  fila, el favorito y la grabación va un `fid` y un `sid`.
- **`lan_ok=True` siempre.** El servidor puede estar en la red local.
- **User-Agent del proyecto y configurable** (`fuentes_ua`, vacío por defecto). Lo usan pedir
  datos (`pedir()`) y reproducir. Si el panel responde 403 se reintenta como VLC.
- **Añadir o listar no escribe en disco** salvo la caché, y en caché van **las filas ya
  normalizadas**, nunca la respuesta cruda: los paneles Xtream Codes meten `username` y
  `password` dentro de cada stream, y cachear lo crudo dejaría la clave en un JSON en claro.

Excepciones: las del borde se envuelven en dos que la pantalla sabe pintar, `ErrorRed` (no se
pudo contactar) y `ErrorCuenta` (se contactó, pero el panel no es un Xtream o la clave no vale).
Quien llama no necesita saber de `iptv_lists`.
"""
import datetime
import re
import urllib.parse

import xbmc


_LOG = '[EspaTV/FUENTES]'

#: Cuánto vive una respuesta en la caché **si no se ha elegido otra cosa** en
#: `fuentes_cache_ttl` (ver `ttl_de()`). Seis horas, el mismo que usa `iptv_lists` para
#: `kind='xtream'`, para que el "Atrás" de esta sección no vaya más despacio que el de las otras.
TTL_S = 6 * 3600

#: «Hasta que lo refresque yo»: no caduca nunca. Es lo que significa el 0 = manual del addon de
#: referencia, y **no** «no guardar nada». Lo que lo renueva es «Refrescar esta lista» o
#: «Borrar lo que tengo guardado».
SIN_CADUCAR = float('inf')

#: Las opciones de `fuentes_cache_ttl`, en orden, con sus segundos. El ajuste es un `labelenum`
#: y Kodi guarda la etiqueta, como en `_FORMATO_A_EXT`, por lo que deben coincidir con `settings.xml`.
TTL_ELEGIBLES = (
    ('6 horas', 6 * 3600),
    ('12 horas', 12 * 3600),
    ('24 horas', 24 * 3600),
    ('3 días', 3 * 24 * 3600),
    ('7 días', 7 * 24 * 3600),
    ('Hasta que lo refresque yo', SIN_CADUCAR),
)
_TTL_POR_ETIQUETA = {e.lower(): s for e, s in TTL_ELEGIBLES}

#: El más largo que caduca. `fuentes_store.VIEJO_S` tiene que pasar de este.
TTL_MAX = max(s for _, s in TTL_ELEGIBLES if s != SIN_CADUCAR)


def ttl_de(valor=None):
    """Los segundos que vive la caché según el ajuste (o según `valor`, si se pasa).

    Una etiqueta que no está en la tabla vale `TTL_S`: nunca lanza ni devuelve 0, que en
    `fuentes_store.cache_leer()` sería «no leer nunca».
    """
    if valor is None:
        valor = _ajuste('fuentes_cache_ttl')
    return _TTL_POR_ETIQUETA.get(str(valor or '').strip().lower(), TTL_S)

#: Cuántos canales se piden a la vez. 100 es lo que usa el propio addon para las listas que
#: paginan, y es un número en el que la respuesta sigue cabiendo en un ZIP manejable: con 18 000
#: canales son 180 peticiones, y con `limit` mayor serían menos pero cada una de varios MB.
LIMITE = 100

#: El número de página que representa la lista completa en paneles sin paginación real.
#: No es un entero y evita colisiones con páginas numéricas estándar.
_TODAS = 'todas'


def _corta(filas, pagina, limite):
    """El trozo de una lista entera que toca en esta página.

    Devuelve `(trozo, hay_mas)`, y `hay_mas` se calcula sobre la longitud **total**: si queda
    algo mas alla de esta pagina, hay mas. Es lo que permite que el rotulo diga el rango sin
    que el panel tenga que colaborar.
    """
    desde = pagina * limite
    trozo = filas[desde:desde + limite]
    return trozo, len(filas) > desde + limite

#: Las tres secciones del servidor y las cuatro cosas que **no** se pueden deducir una de
#: otra. Están juntas a propósito, en una sola tabla, porque en tablas separadas es cuestión de
#: tiempo que se desincronicen y una sección acabe con la accion de otra:
#:
#:   * `cats`:    la acción de categorías (`get_live_categories`, `get_vod_categories`,
#:               `get_series_categories`).
#:   * `streams`: la acción de canales. Las series usan `get_series`, **no** `get_vod_streams`.
#:   * `camino`:  el camino de la URL. Lo que va a `/live/` son los canales en directo, las
#:               películas van a `/movie/` y los capítulos de serie a `/series/`.
#:   * `k`:       la letra que `iptv_parse.xtream_categories` mete en cada categoría. **No es la
#:               primera letra de la sección**: `vod` es `m` (de *movie*), no `v`, porque es lo
#:               que ya usa el resto del addon (`iptv_lists._xtream_fetch()`) y las dos cosas tienen que
#:               decir lo mismo.
SECCIONES = {
    'live': {'cats': 'get_live_categories', 'streams': 'get_live_streams',
             'camino': 'live', 'k': 'l'},
    'vod': {'cats': 'get_vod_categories', 'streams': 'get_vod_streams',
            'camino': 'movie', 'k': 'm'},
    'series': {'cats': 'get_series_categories', 'streams': 'get_series',
               'camino': 'series', 'k': 's'},
}

#: Una extensión de fichero válida: de 1 a 5 letras o digitos. Lo mismo que acepta
#: `iptv_parse` (`iptv_parse.py:66`), y por la misma razón: `container_extension` viene del
#: servidor y se mete en una URL, así que no puede ser cualquier cosa.
_EXT_OK = re.compile(r'[A-Za-z0-9]{1,5}')


#: Estados de cuenta que delatan que el usuario o la clave no valen. Se mira ademas del
#: auth, porque hay paneles que dejan auth a 1 y aun asi no dejan entrar.
_CUENTA_INVALIDA = ('expired', 'disabled', 'banned', 'inactive', 'suspended')


class ErrorRed(Exception):
    """No se ha podido contactar con el servidor. Puede que este apagado."""


class ErrorCuenta(Exception):
    """Se ha contactado, pero el panel no es un Xtream o las credenciales no valen."""


class ErrorCertificado(ErrorCuenta):
    """El certificado HTTPS del servidor no es válido (caducado, autofirmado...).

    Hereda de `ErrorCuenta` para que quien ya la trata siga igual; «Comprobar» y «Analizar»
    la distinguen para ofrecer conectar sin verificarlo.
    """


def _log(texto, nivel=xbmc.LOGDEBUG):
    xbmc.log('{0} {1}'.format(_LOG, texto), nivel)


def _ajuste(clave, defecto=''):
    """Un ajuste de `settings.xml`, leido sin escribir nada.

    Leer un ajuste y no encontrarlo no es un error: es el estado por defecto,
    cuando todavía no hay nada configurado.
    """
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting(clave) or defecto
    except Exception as e:                              # pragma: no cover
        _log('no se ha podido leer el ajuste {0}: {1}'.format(clave, e))
        return defecto


def _user_agent():
    """El User-Agent que se identifica ante el servidor.

    Vacío si no se ha puesto nada, y entonces `_download()` manda el de navegador del
    proyecto (`ui_utils.HEADERS`, Chrome), nunca uno que diga EspaTV ni el del addon de origen.

    Ojo: tras un 403, `_download()` reintenta como `VLC/3.0.20`, así que no se puede decir
    «nunca uno falsificado». Se deja porque sin él dejan de funcionar algunos paneles.

    El primero que se manda es el de `fuentes_ua` si está puesto, y el del proyecto si no; el
    de VLC solo se prueba detrás, tras un 403.
    """
    return _ajuste('fuentes_ua')


#: Las marcas con las que un panel dice «esto es en español». Sale del nombre del canal, que es
#: lo unico que hay por item: `get_live_streams` **no** trae idioma por canal.
#: Las marcas van **sin enye** a proposito, porque _n_de_ene() la cambia antes de partir.
#: Ver esa funcion: sin ese cambio ESPANA y ESPANOL son entradas **muertas**, y
#: [ESPANOL] es de las formas que mas se ven en un nombre de canal.
#: Marcas habituales en nombres de canal:
#: 'ES', 'ESP', 'ESPANA', 'ESPANOL', 'SPAIN', 'CASTELLANO', 'LATINO', 'LATAM', 'LAT'.
_ES_MARCAS = ('ES', 'ESP', 'ESPANA', 'ESPANOL', 
              'SPAIN', 'CASTELLANO', 'LATINO', 'LATAM', 'LAT')

#: Todo lo que no es letra ni digito se vuelve un espacio, para que `[ES]`, `(ES)`, `-ES-` y
#: ` ES ` cuenten igual. Y se buscan las marcas **delimitadas por espacios**, porque si no, «ES»
#: aparece dentro de «Deportivo» o «Casa» y medio catálogo sale como español.
_NO_ALFANUM = re.compile(r'[^A-Z0-9]+')


def lang_es(nombre):
    """True si el **nombre** del canal huele a español (6.1).

    Heurística de nombre, no un dato del panel: `get_live_streams` devuelve `stream_id`, `name`,
    `stream_icon`, `epg_channel_id`, `added`, `category_id`, `tv_archive` y `direct_source`, y
    **no hay idioma por canal**. Lo unico por item es el nombre, y ahi es donde estan las marcas.

    Por eso se separan los dos sitio de donde se saca el idioma, que se parecen y no son lo mismo:

    - `_IDIOMAS_ES` de `fuentes_servidores.py` es lo que el servidor **declara** en su
      `user_info.langs`. Es fiable y es a nivel de servidor.
    - esto es lo que el **nombre** parece. Es una suposicion, y hay canales en español sin marca
      y canales en ingles con `[ES]` de la serie original.

    **Por eso `solo_espanol` es un ajuste de verdad y no el criterio de una lista**: si lo que
    se quiere es «solo español de verdad», el filtro del servidor (que mira lo declarado) es el
    que vale. Este es para limpiar la lista, no para decidir qué fuentes usar.
    """
    texto = ' ' + _NO_ALFANUM.sub(' ', _n_de_ene(str(nombre or '')).upper()) + ' '
    return any(' {0} '.format(m) in texto for m in _ES_MARCAS)


def _n_de_ene(texto):
    """`ESPAÑA` → `ESPANA`, `Español` → `ESPANOL`. Para que las marcas con ñ existan.

    Al normalizar con `[^A-Z0-9]+`, la `Ñ` no está en `A-Z0-9`, así que `ESPAÑA` se convertiría
    en `ESPA A` y la marca `ESPANA` no coincidiría.

    Aquí la `Ñ` se cambia a `N` **antes** de partir. `PEÑA` pasa a `PENA`, y lo que se
    busca son las palabras delimitadas enteras.
    """
    return str(texto).replace(chr(209), 'N').replace(chr(241), 'n')


def _xt(fuente):
    """El dict que espera `iptv_lists._xtream_api()`.

    `{'server', 'user', 'pass'}` y nada mas: `_xtream_api` pone el `username` y el `password`
    en la query desde aqui. Pasarlos otra vez es redundante.
    """
    return {'server': fuente['servidor'], 'user': fuente['usuario'], 'pass': fuente['clave']}


def _sin_credenciales(texto):
    """Un texto de error o de log **sin usuario ni clave**.

    Se aplica a **lo que se cuenta**, no a lo que se construye. La fila y el favorito ya llevan
    `fid` y `sid` porque `_fila_de()` nunca ve la credencial; pero el **mensaje de una
    excepcion** si la lleva, y ahi no hay ninguna proteccion:

        iptv_lists._download  ->  P.ListError('No se ha podido descargar: {e}')
        y el mensaje de `requests` **incluye la URL**
        y la URL de `player_api.php` lleva `username` y `password` en la query

    Así que la clave acaba en `kodi.log` o en el diálogo de error si no se sanea.
    Aquí se sanea de forma centralizada en `pedir()`, por donde pasan todas las llamadas.

    Se tapa con `***` y no se quita, para que el mensaje siga siendo legible y se vea que habia
    algo ahi. Se tapan tres formas porque los paneles usan las tres:

    - el query: `?username=U&password=P`
    - el userinfo: `https://U:P@host/...`
    - el camino: `/live/U/P/401.ts`
    """
    import re
    import urllib.parse
    t = str(texto or '')
    if not t:
        return t

    # 1. El userinfo de la URL, antes de mirar el query: es el unico sitio donde la credencial
    #    esta en la parte de "servidor" y no en la de parametros.
    def _host(m):
        """El `https://host:puerto` sin el userinfo, para sustituirlo entero."""
        try:
            partes = urllib.parse.urlsplit(m.group(0))
        except ValueError:
            return m.group(0)
        host = partes.hostname or ''
        if partes.port:
            host += ':' + str(partes.port)
        return (partes.scheme + '://' + host) if partes.scheme else host

    #    Hasta la ÚLTIMA `@` antes de `/`, `?` o `#`, que es donde corta `urllib3` el servidor
    #    (`authority.rpartition("@")`). Cortando en la primera, una clave `p@ss` sin codificar
    #    funcionaba al conectar y dejaba ver `ss` en el mensaje.
    t = re.sub(r'\b[a-zA-Z][a-zA-Z0-9+.-]*://[^/?#\s:]+:[^/?#\s]+@', _host, t)

    # 2. Los parametros de la query. Se tapAN uno a uno, porque el texto puede traer varios.
    t = re.sub(r"((?:pass(?:word|wd)?|user(?:name)?|auth|token|api_key|apikey)=)"
               r"[^&\s'\"\\]+", r'\1***', t, flags=re.I)

    # 3. El camino de Xtream: `/live/USUARIO/CLAVE/401.ts`. Se comprueba que el primer segmento
    #    sea uno de los tres, que es lo que ancla la forma. Sin esa comprobacion, un texto con
    #    dos barras cualesquiera se descifra y se tapa informacion que no es credencial.
    def _camino(m):
        # m.group(0) contiene únicamente el prefijo: /live/USUARIO/CLAVE. El resto de la ruta
        # (/401.ts) queda excluido por la aserción lookahead para no reinsertar la clave.
        partes = m.group(0).split('/')
        if len(partes) == 4 and partes[1] in ('live', 'movie', 'series'):
            return '/' + '/'.join([partes[1], '***', '***'])
        return m.group(0)

    t = re.sub(r"/(?:live|movie|series)/[^/\s]+/[^/\s]+(?=[/\s'\"\\.,;)]|$)", _camino, t)
    return t


def pedir(fuente, accion='', dp=None, insecure=False, **params):
    """Llama a `player_api.php` y devuelve lo que responde, sin tocar.

    `accion` vacía es legal y es la llamada más barata que hay: sin acción el panel devuelve
    `user_info` y `server_info` y **ni un canal**. Es la que usa el propio `iptv_lists` para lo
    mismo (`iptv_lists._xtream_api()`).

    Envuelve las excepciones del borde en `ErrorRed` y `ErrorCuenta`, de modo que quien llama
    no necesita saber de `iptv_lists`. Lo demás se deja pasar, incluida `_Cancelled`, que no es
    un fallo sino "se ha pulsado cancelar" y la tiene que ver quien la puso.

    **La respuesta cruda, sin tocar.** Cada panel Xtream devuelve su propia forma y es cada
    llamada la que sabe interpretarla; un `dict` común aquí solo serviría para imponer una
    forma que luego habría que deshacer en los tres casos.
    """
    import iptv_lists
    try:
        # `ua` con el valor de `fuentes_ua`, o `None` para usar el de EspaTV. Tiene que llegar
        # también aquí y no solo al reproducir: si no, un panel que rechaza el de EspaTV no se
        # arregla cambiando el ajuste.
        datos = iptv_lists._xtream_api(_xt(fuente), insecure or fuente.get('inseguro'), dp, lan_ok=True,
                                       ua=_user_agent() or None,
                                       action=accion, **params)
    except iptv_lists._XtreamSinRespuesta as e:
        # Antes que `_NoXtreamApi`, de la que hereda: un servidor caído, que no contesta a
        # tiempo o da un 502 no es una clave mala, y en «Comprobar» va en naranja, no en rojo.
        raise ErrorRed(_sin_credenciales(str(e))
                       or 'No se ha podido contactar con el servidor.') from e
    except iptv_lists._NoXtreamApi as e:
        raise ErrorCuenta(_sin_credenciales(str(e))) from e
    except iptv_lists._NeedsInsecure as e:
        # La conexión sí va cifrada: lo que falla es el certificado.
        raise ErrorCertificado(
            'El certificado HTTPS de este servidor no es válido. Usa «Comprobar» en su menú '
            'para conectar igualmente sin verificarlo.') from e
    except iptv_lists._Cancelled:
        raise
    except Exception as e:
        raise ErrorRed(_sin_credenciales(str(e))
                        or 'No se ha podido contactar con el servidor.') from e
    return datos


def cuenta(fuente, dp=None):
    """Pregunta al servidor qué dice de sí misma la cuenta, e interpreta lo que conteste.

    Es `pedir()` sin acción más `lee_cuenta()`, en dos pasos a propósito: la pantalla de
    comprobar **ya tiene** la respuesta en la mano (`pedir()` sin acción) y no tiene sentido
    volver a pedirla solo para interpretarla. Las dos Interpretaciones pasan por
    `lee_cuenta()`, que es donde vive.
    """
    return lee_cuenta(pedir(fuente, '', dp))


def _segundos_de(valor):
    """Convierte exp_date de panel a segundos Unix, o 0 si no es válido.

    Los paneles pueden enviar marcas temporales en segundos Unix estándar o en formato
    de 14 dígitos (YYYYMMDDhhmmss). Este último se interpreta explícitamente para evitar
    excepciones de rango en time.localtime(). Cualquier otro valor anómalo devuelve 0.
    """
    try:
        n = int(valor or 0)
    except (TypeError, ValueError):
        return 0
    if n <= 0:
        return 0
    if len(str(n)) == 14:
        # Parseo a mano y no con time.strptime: strptime falla de forma intermitente
        # en el interprete de Kodi (importacion perezosa de _strptime) y devuelve
        # basura para fechas validas, lo que vaciaba el calendario. Lo explica
        # `calendario_series._parse_date()`, que es el mismo problema.
        #
        # datetime y no time.mktime con la tupla desarmada: mktime NORMALIZA las
        # fechas imposibles en vez de rechazarlas (30 de febrero -> 1 de marzo, mes
        # 13 -> año siguiente), asi que un "20240230120000" pasaria a tener hora en
        # vez de ser 0. datetime las rechaza con ValueError.
        s = str(n)
        try:
            return int(datetime.datetime(int(s[0:4]), int(s[4:6]), int(s[6:8]),
                                         int(s[8:10]), int(s[10:12]),
                                         int(s[12:14])).timestamp())
        except (ValueError, OverflowError, OSError):
            return 0
    import time
    try:
        time.localtime(n)
    except (OverflowError, OSError, ValueError):
        return 0
    return n


def lee_cuenta(datos):
    """Interpreta una respuesta de `player_api.php` y saca la cuenta. No va a la red.

    Lo que sale: `estado`, `caduca`, `conexiones`, `actual` y `fmt`.

    - **`conexiones` en `None` significa "el panel no lo dice"**, que no es lo mismo que decir
      cero, y para el filtro de hueco libre lo desconocido no bloquea.
    - **`actual` en `None` es lo mismo**: el tope sin el uso no dice si queda hueco, y un filtro
      que bloquea por no saber tira fuentes que funcionan.
    - `caduca` en `0` significa "no lo dice" o "no es una fecha". Un panel que manda
      `"no soy un numero"` no tumba nada: se queda en cero y se sigue.
    - `fmt` es `m3u8` o `ts`, y lo decide la cuenta en `allowed_output_formats`, no el servidor
      en la URL. Es lo que permite que un canal se vea en un móvil y en otro no.

    **`int()` con proteccion, siempre.** La respuesta puede venir de un panel viejo, un clon con el JSON a medio hacer, o algo que devuelve `"3"`
    donde se espera `3`. Un `int()` a pelo revienta la comprobación entera por un campo que
    solo es informativo.
    """
    user = datos.get('user_info') if isinstance(datos, dict) else None
    if not isinstance(user, dict):
        raise ErrorCuenta('El servidor no ha enviado los datos de la cuenta.')
    # **El `auth` es lo que dice si la credencial vale**, y no se miraba. Un panel que
    # responde `{'user_info': {'auth': 0, 'status': 'Expired'}}` se pintaba como
    # "OK". Es indispensable exigirlo para validar la cuenta.
    #
    # Se miran los DOS, y no solo `auth`: hay paneles que dejan `auth` a 1 con
    # `status` en `Expired`, y mirar uno solo deja escapar al otro. Un panel raro
    # que mande solo `status: 'Disabled'` también se avisa.
    auth = str(user.get('auth', '1')).strip()
    estado_bruto = str(user.get('status', '') or '').strip()
    if auth not in ('1', 'true', 'True') or estado_bruto.lower() in _CUENTA_INVALIDA:
        raise ErrorCuenta(
            'El servidor ha rechazado el usuario o la contraseña. '
            'Revísalos en Editar.')
    caducidad = _segundos_de(user.get('exp_date'))
    conexiones = user.get('max_connections')
    if conexiones is not None:
        try:
            conexiones = int(conexiones)
        except (TypeError, ValueError):
            conexiones = None
    # Las conexiones **en uso**, que no es lo mismo que el tope. Sin esto no se puede saber si
    # queda hueco, y "queda hueco" es una de las cosas por las que se analizan los servidores.
    #
    # Cada panel lo llama distinto (`active_cons`, `active_connections`, `cur_connections`), así
    # que se prueban los tres. `None` en todos significa "no lo dice", que es la tercera
    # respuesta posible y la más honesta: no es que no haya hueco, es que no se sabe.
    actual = None
    for clave in ('active_cons', 'active_connections', 'cur_connections'):
        if user.get(clave) is not None:
            try:
                actual = int(user[clave])
            except (TypeError, ValueError):
                actual = None
            break
    activo = user.get('status', '')
    formatos = [str(f).lower() for f in user.get('allowed_output_formats') or []]
    # **La ausencia del campo no significa "solo MPEG-TS".** No lo manda todo el
    # mundo, y con la regla de antes todos los directos de esos paneles caian a
    # `.ts`. Cuando el panel no lo dice se usa HLS, que funciona en todas partes:
    # el original fuerza `.m3u8` siempre, con el motivo escrito
    # en su cliente. Es la misma regla que ya se aplica a `caduca`
    # en cero y `conexiones` en `None`: lo que el panel no dice, no bloquea.
    return {
        'estado': 'activo' if activo in ('Active', 'active', 1, '1') else str(activo or ''),
        'caduca': caducidad,
        'conexiones': conexiones,
        'actual': actual,
        'fmt': 'm3u8' if (not formatos or 'm3u8' in formatos) else 'ts',
    }


# --- la cache ---------------------------------------------------------------
#
# Vive aquí y no en las vistas porque las tres secciones comparten el mismo criterio y no
# quiero tres copias del mismo `if`. El TTL sale del ajuste (`ttl_de()`); las vistas
# solo deciden cuándo saltárselo (`forzar`, el botón de refrescar).

#: Version del formato de la cache de listas. Sube cuando cambia la forma, para que lo viejo
#: se lea como un fallo y se vuelva a pedir en vez de devolver una lista cruda como si fueran
#: filas ya normalizadas.
_LISTAS_V = 2


def _lee_lista(fid, clave, forzar=False):
    """La cache de una pagina de listado, o `None` si no hay.

    Devuelve `{'filas', 'mas'}` ya validado. Lo que se comprueba es **la version**, no la
    forma: un fichero de la version 1 es una lista de dicts **crudos del panel**, con usuario
    y contraseña dentro, y normalizarlo otra vez no es posible porque `_fila_de()` busca
    `stream_id` y en un dict ya normalizado no esta. O se pide de nuevo, o se devuelve algo
    equivocado; se pide de nuevo.
    """
    guardado = _lee_cache(fid, clave, forzar=forzar)
    if not isinstance(guardado, dict) or guardado.get('v') != _LISTAS_V:
        return None
    filas = guardado.get('filas')
    if not isinstance(filas, list):
        return None
    return {'filas': [f for f in filas if isinstance(f, dict)],
            'mas': bool(guardado.get('mas'))}


def _guarda_lista(fid, clave, filas, mas):
    """Guarda una pagina de listado **ya normalizada**.

    Las filas se normalizan antes de guardarlas: los paneles Xtream Codes meten `username` y
    `password` dentro de cada stream, y la respuesta cruda dejaría la clave en claro en el JSON.

    Lo que se guarda son las filas de 8 campos de `_fila_de()`. No se pierde nada de lo que se
    leia: la fila normalizada lleva el nombre ya limpio por `clean_name()` y el grupo
    resuelto, que es lo que se usa despues.
    """
    _guarda_cache(fid, clave, {'v': _LISTAS_V, 'filas': list(filas), 'mas': bool(mas)})


def _huella_de(fuente):
    """La **identidad** de la fuente, para las claves de cache (B10).

    Sin esto, editar el host o el usuario de un servidor **no invalida nada**: la clave era
    `fid|cat|pagina|limite` y el `fid` no cambia al editar, con lo que se seguia viendo la
    lista del servidor anterior. Es el bug B10.

    Se usa `fuentes_store.huella()`, que es `sha1(tipo|servidor|usuario)` recortado a 12:
    **deliberadamente sin la clave dentro**, de modo que la huella no es una credencial que
    se acabe de escribir en el nombre de un fichero.

    No cambia al cambiar la clave, y eso tambien es a proposito: identifica **a quien** es
    la fuente, no **que clave** tiene. La lista de canales es la misma con una clave distinta.

    Va **al final** de la clave y no al principio, porque el visor (`fuentes_vistas.
    _cache_de_visor`) localiza por el prefijo `list_<seccion>_`. Ponerla delante habria
    vaciado 'Mas usados', 'Historial' y la busqueda: arreglando B10 se habria roto C4 otra vez.

    Una M3U **no trae huella**: no tiene servidor ni usuario, y la huella seria identica para
    todas, con lo que unas se pisarian a otras.
    """
    if fuente.get('tipo') == 'm3u':
        return ''
    import fuentes_store
    return fuentes_store.huella(fuente.get('tipo'), fuente.get('servidor'),
                                fuente.get('usuario'))

#: Cuanto de la clave se queda **legible** en el nombre del fichero. Lo que va despues es un
#: hash, asi que esto es solo para que al abrir la carpeta de caché a mano se vea qué es.
_CLAVE_LEGIBLE = 24

#: Caracteres del hash que se anaden. 12 en hexadecimal son 48 bits: con unas cuantas claves de
#: cache por fuente, la probabilidad de que dos den el mismo es de lo mas improbable que se
#: pueda encontrar, y truncar sin hash no da **ninguna** garantia.
#:
#: Los dos numeros estan aqui para que se puedan cambiar sin tocar el codigo, y para que se vea
#: que la suma tiene que caber en _CLAVE_RE de fuentes_store (48).
_CLAVE_HASH = 12


def _clave_cache(*partes):
    """Una clave de caché que sea nombre de fichero, **acotada** y **sin colisiones**.

    `fuentes_store.cache_escribir` acepta solo claves que se puedan poner en un nombre de
    fichero, y **se traga el `ValueError`** en vez de reventar. Eso está bien para una caché,
    pero aquí significa que una clave con acentos o con `/` se perdería en silencio: se
    escribiría nada y se leería `None` siempre, y la caché parecerá no funcionar sin decir por
    qué. Por eso se sanea aquí y se avisa si hubo que tocar algo.
    """
    crudo = '_'.join(str(p) for p in partes)
    # `isascii()` además de `isalnum()`: `'ñ'.isalnum()` es True y `_CLAVE_RE` no la admite.
    limpio = ''.join(c if ((c.isascii() and c.isalnum()) or c in '-_') else '-' for c in crudo)
    if limpio != crudo:
        _log('la clave de cach' + chr(233) + ' {0!r} se ha saneado a {1!r}'.format(crudo, limpio),
             xbmc.LOGWARNING)

    # **Con un hash, y acotada (5.6).**
    #
    # `_CLAVE_RE` es [A-Za-z0-9_-]{1,40}. Con un category_id de los largos que mandan
    # algunos paneles (son ids compuestos, tipo 123|456|789) la clave pasaba de 40 y
    # cache_escribir **se tragaba el ValueError**. Y el resultado es el peor de los dos: la
    # caché **no falla**, se comporta como si no existiera. Cada visita vuelve a
    # bajarlo todo, y no hay aviso, porque el que hay dice «clave no válida» y va al
    # log, donde nadie lo lee.
    #
    # Y truncar a secas tampoco era solucion: dos category_id largos que compartieran los
    # primeros 120 caracteres darían **la misma clave**, y se serviría la lista de
    # la categoría equivocada. Un recorte es many-to-one.
    #
    # Así que el final de la clave es un **hash de la clave entera sin recortar**: dos
    # entradas distintas dan dos claves distintas, siempre. Y la parte legible se queda para
    # que el nombre del fichero diga qué es, porque al mirar una carpeta de caché a
    # mano, ver list_live_7_0_100_a1b2c3d4 dice mucho más que a1b2c3d4.
    #
    # **Cambia todas las claves**, así que la caché del perfil no se encuentra y se
    # vuelve a pedir todo una vez. No es una perdida: dura lo que el TTL.
    import hashlib
    resumen = hashlib.sha1(crudo.encode('utf-8')).hexdigest()[:_CLAVE_HASH]
    return '{0}-{1}'.format(limpio[:_CLAVE_LEGIBLE] or 'x', resumen)


def _lee_cache(fid, clave, ttl=None, forzar=False):
    if forzar:
        return None
    import fuentes_store
    return fuentes_store.cache_leer(fid, clave, ttl_de() if ttl is None else ttl)


def _guarda_cache(fid, clave, datos):
    """Escribe en la caché. No devuelve nada, y no necesita devolver nada.

    `forzar` **no** aparece aquí a propósito: obliga a leer del servidor, no a dejar de
    guardar. Una versión anterior lo tenía al revés (si `forzar`, no escribir) y eso
    convertía "refrescar" en "leer del servidor y no actualizar el caché", o sea un botón de
    refrescar que no refresca. Lo que sale de aquí lo usa quien llama desde su propia variable,
    así que la caché es una optimización y nunca un requisito: si el disco está lleno, la
    pantalla sigue funcionando, solo que la próxima vez volverá a preguntar.
    """
    import fuentes_store
    fuentes_store.cache_escribir(fid, clave, datos)


def guia_de(fuente):
    """La dirección de la guía de esta fuente, o cadena vacía si no tiene.

    **Solo se construye; no se descarga nada.** Nada más en toda la sección llama a la red
    por su cuenta, y una guía son decenas de megabytes.

    - **Xtream**: `xmltv.php` del panel, con usuario y clave. Es la guía **de esos
      canales**, y es la única que va a emparejar: la general es de canales españoles y con
      un panel extranjero no casa ni uno.
    - **M3U**: el `url-tvg` de la cabecera, si la lista lo trae. Sin él, cadena vacía:
      inventar una dirección sería peor que no tener guía.

    El patrón es el de `url_de()`: **esta función y ninguna otra** construyen direcciones con
    credenciales. Y `epg_texto` no escribe la dirección en el disco (la hashea para el
    nombre) ni en el log (la sanea), que ya se hizo pensando en este caso.
    """
    if fuente.get('tipo') == 'm3u':
        return str(fuente.get('epg') or '').strip()
    servidor = str(fuente.get('servidor') or '').rstrip('/')
    usuario = urllib.parse.quote(fuente.get('usuario') or '', safe='')
    clave = urllib.parse.quote(fuente.get('clave') or '', safe='')
    if not servidor or not usuario:
        return ''
    return '{0}/xmltv.php?username={1}&password={2}'.format(servidor, usuario, clave)

def cuenta_cacheada(fuente, dp=None, forzar=False):
    """La cuenta, de caché si la hay. El caché es de la cuenta, no de la pantalla.

    El motivo de cachearla y no leerla en cada reproducción: `url_de()` necesita el formato
    (`m3u8` o `ts`) para cada canal, y pedir la cuenta cada vez sería una petición extra por
    reproducción. El TTL es el de la sección.
    """
    fid, clave = fuente['id'], _clave_cache('cuenta', _huella_de(fuente))
    guardado = _lee_cache(fid, clave, forzar=forzar)
    if isinstance(guardado, dict) and 'fmt' in guardado:
        return guardado
    datos = cuenta(fuente, dp)
    _guarda_cache(fid, clave, datos)
    return datos


# --- categorias y listado ---------------------------------------------------

def categorias(fuente, seccion, dp=None, forzar=False):
    """Las categorías del servidor, de caché si la hay.

    Se cachean porque **cambian muy poco**: un servidor tiene las mismas categorías durante
    semanas. Es la caché que más ahorra, y la que hace que entrar en "TV y radio en directo" por
    segunda vez sea inmediato.

    Se normalizan con `iptv_parse.xtream_categories`, que ya limpia los nombres. La respuesta
    cruda del panel no se guarda: se guarda ya normalizada, porque normalizar es gratis pero
    volver a interpretar un `dict` con la forma de otro panel es trabajo de cada vez.
    """
    if seccion not in SECCIONES:
        raise ValueError('sección desconocida: {0!r}'.format(seccion))
    import iptv_parse as P

    fid, clave = fuente['id'], _clave_cache('cats', seccion, _huella_de(fuente))
    guardado = _lee_cache(fid, clave, forzar=forzar)
    if isinstance(guardado, list):
        return guardado

    accion = SECCIONES[seccion]['cats']
    filas = pedir(fuente, accion, dp)
    if not isinstance(filas, list):
        return []
    datos = P.xtream_categories(filas, SECCIONES[seccion]['k'])
    _guarda_cache(fid, clave, datos)
    return datos


def categorias_cacheadas(fuente, seccion):
    """Devuelve las categorías que ya están en caché local, o `[]` si no hay.

    A diferencia de `categorias()`, nunca hace peticiones de red ni lanza errores si el
    servidor está caído. Se usa para búsquedas instantáneas en memoria.
    """
    if seccion not in SECCIONES or not fuente:
        return []
    fid, clave = fuente.get('id', ''), _clave_cache('cats', seccion, _huella_de(fuente))
    guardado = _lee_cache(fid, clave)
    return guardado if isinstance(guardado, list) else []


def listado(fuente, seccion, categoria='', pagina=0, dp=None, limite=LIMITE, forzar=False,
            nombre_categoria=''):
    """Una página de canales. Devuelve `(filas, hay_mas)`.

    **Lo que devuelve no lleva ni el usuario ni la clave.** Cada fila es
    `{'sid', 'nombre', 'logo', 'grupo', 'num', 'epg', 'radio', 'ext'}` y nada más. Eso no es
    una precaución, es la forma de que la **vista no pueda filtrar las credenciales ni por
    error**: no las recibe, así que no las puede poner en un `plugin://` aunque alguien lo
    intente.

    Es la diferencia con `iptv_parse.xtream_channels()`, que sí devuelve la URL con las
    credenciales dentro del camino. Aquí se reutiliza de este lo que sí
    conviene (`clean_name`, que limpia los nombres que traen los paneles) y **no** lo que
    monta la URL, porque montar la URL es exactamente lo que no queremos que salga de aquí.
    Las 10 líneas que se dejan de reusar se recuperan haciendo la URL una vez, en `url_de()`,
    en el momento de reproducir.

    **Paginado de verdad.** `get_live_streams` acepta `category_id`, `start` y `limit`, y sin
    ellos se bajan los 18 000 canales de golpe: eso tarda, y en un móvil se come la memoria.
    `iptv_lists._xtream_fetch` los pide enteros; aquí van de `LIMITE` en
    `LIMITE`.

    `hay_mas` se decide por lo que **ha vuelto**, no por un total que el panel no garantiza:
    si la página viene llena, hay más; si viene menos de lo pedido, no. Un panel que no
    implementa `limit` devuelve todo siempre, y entonces `hay_mas` se queda en `True`. Por eso
    quien pinta pone siempre la fila de "página siguiente", con tope de páginas, para que el
    bucle se pare solo.

    Se cachean las filas **ya normalizadas** por `_fila_de()`, no las crudas: es lo que quita
    las credenciales, porque un panel Xtream Codes mete `username` y `password` dentro de cada
    stream. `_fila_de()` devuelve solo `sid`, `nombre`, `logo`, `grupo`, `num`, `epg`, `radio` y
    `ext`.

    **Este texto decia lo contrario** («las filas crudas y nada construido») y por eso era
    especialmente peligroso: la conclusión («no hay usuario ni clave») era correcta y el motivo
    estaba equivocado. Quien lo leyera pensaria que la seguridad venía de no construir nada, y
    si algún dia `_fila_de()` se hiciera un `dict(crudo)` «para no perder campos», este texto
    seguiria diciendo que no se construye nada mientras la clave se iba a la caché.
    """
    if seccion not in SECCIONES:
        raise ValueError('sección desconocida: {0!r}'.format(seccion))

    pagina = max(int(pagina or 0), 0)
    limite = max(int(limite or LIMITE), 1)

    fid = fuente['id']
    clave = _clave_cache('list', seccion, categoria, pagina, limite,
                         _huella_de(fuente))
    guardado = _lee_lista(fid, clave, forzar=forzar)
    if guardado is not None:
        return guardado['filas'], guardado['mas']

    # Si el panel no pagina, la lista completa ya está guardada: se corta el tramo
    # correspondiente sin volver a realizar petición de red.
    entera = _lee_lista(fid, _clave_cache('list', seccion, categoria, _TODAS, limite,
                                          _huella_de(fuente)), forzar=forzar)
    if entera is not None:
        return _corta(entera['filas'], pagina, limite)

    accion = SECCIONES[seccion]['streams']
    params = {'start': pagina * limite, 'limit': limite}
    if categoria:
        params['category_id'] = categoria
    respuesta = pedir(fuente, accion, dp, **params)
    crudos = [f for f in respuesta if isinstance(f, dict)] \
        if isinstance(respuesta, list) else []
    filas = [f for f in (_fila_de(crudo, seccion, nombre_categoria) for crudo in crudos) if f]

    if len(crudos) > limite:
        # El panel ha ignorado start/limit: se guarda la lista completa y se corta la página.
        _guarda_lista(fid, _clave_cache('list', seccion, categoria, _TODAS, limite,
                                        _huella_de(fuente)),
                      filas, len(filas) > limite)
        return _corta(filas, pagina, limite)

    _guarda_lista(fid, clave, filas, len(crudos) >= limite)
    return filas, len(crudos) >= limite


#: Extensiones que son audio. Una entrada de Xtream con una de estas es una emisora de radio,
#: no un canal de television, y en pantalla es otra cosa. Es la senal que usa el plan, y la que
#: viene en `container_extension`, que es lo unico fiable: hay canales de TV que se llaman
#: "Radio X" y emisoras que se llaman "Canal 24".
_AUDIO = ('aac', 'mp3', 'ogg', 'opus', 'm4a', 'flac', 'wma')


def _fila_de(fila, seccion, nombre_categoria=''):
    """Una fila de canal, sin credenciales, o `None` si no es un canal.

    Se descartan las que no tienen `stream_id` convertible a entero: sin él no hay forma de
    reproducirla ni de hacer un `plugin://` que la distinga de otra. Un panel que meta
    garbage se queda sin esas filas en vez de reventar la página entera, que es lo que hace un
    `int()` a pelo.
    """
    import iptv_parse as P
    sid = _entero(fila.get('stream_id'))
    if sid is None:
        return None
    ext = str(fila.get('container_extension') or '').strip().lstrip('.').lower()
    if not _EXT_OK.fullmatch(ext):
        ext = ''
    return {
        'sid': str(sid),
        'nombre': P.clean_name(fila.get('name')) or str(sid),
        'logo': str(fila.get('stream_icon') or ''),
        'grupo': nombre_categoria or P.clean_name(fila.get('category_name')) or '',
        'num': str(fila.get('num') or ''),
        'epg': str(fila.get('epg_channel_id') or ''),
        # **Lo que el panel ya manda y aqui se tiraba.** No es TMDB ni red: es informacion
        # gratuita que viene en la misma respuesta de `get_vod_streams`. Sin esto, una pagina
        # de cine muestra titulo, icono generico y nada mas.
        'year': _anio_de(fila.get('year'), fila.get('release_date'), fila.get('plot')),
        'plot': P.clean_name(str(fila.get('plot') or '')),
        'rating': _nota_de(fila.get('rating')),
        'duracion': _duracion_de(fila.get('duration')),
        'generos': [str(g).strip() for g in (fila.get('genre') or []) if str(g).strip()]
                 if isinstance(fila.get('genre'), list) else [],
        # `movie_image` es la caratula que manda el panel, y en VOD `stream_icon` suele venir
        # vacio: es la unica imagen que hay sin pedirle nada a nadie.
        'poster': str(fila.get('movie_image') or ''),
        'radio': ext in _AUDIO,
        'ext': ext,
    }


def _anio_de(*valores):
    """El a"no de una pelicula, del campo que venga.

    Lo manda el panel en `year`, en `release_date` o dentro del propio `plot` como "(1994)", y cada
    panel usa uno. Se prueban en ese orden y se devuelve `''` si ninguno tiene un numero de cuatro
    cifras. Es texto, no una busqueda en TMDB: se saca lo que hay.
    """
    import re
    for v in valores:
        if v in (None, ''):
            continue
        m = re.search(r'(19|20)\d{2}', str(v))
        if m:
            return m.group(0)
    return ''


def _nota_de(valor):
    """La nota, como texto, o vacio.

    Los paneles la mandan en `rating` y va de 0 a 10 con decimales, pero algunos la mandan como
    `"7.5/10"` o como entero. Se coge el primer numero y se recorta a una decimal: en una lista
    apretada, `"7.53"` no cabe y `"7.5"` si.
    """
    import re
    if valor in (None, ''):
        return ''
    m = re.search(r'\d+(?:[.,]\d+)?', str(valor))
    if not m:
        return ''
    try:
        n = float(m.group(0).replace(',', '.'))
    except ValueError:
        return ''
    if n <= 0:
        return ''
    return ('{0:.1f}'.format(n)).rstrip('0').rstrip('.')


def _duracion_de(valor):
    """La duracion en minutos, como texto, o vacio.

    Xtream la manda en segundos, pero hay clones que la mandan ya en minutos o como `"01:35:12"`,
    asi que se distinguen los tres casos por su forma y no por su magnitud: un numero de cuatro
    cifras en segundos son ~28 minutos y en minutos son 7 dias.
    """
    if valor in (None, ''):
        return ''
    s = str(valor).strip()
    if ':' in s:
        partes = s.split(':')
        try:
            nums = [int(p) for p in partes]
        except ValueError:
            return ''
        if len(nums) == 3:
            total = nums[0] * 60 + nums[1]
        elif len(nums) == 2:
            total = nums[0]
        else:
            return ''
        return str(total) if total > 0 else ''
    try:
        n = int(float(s))
    except (TypeError, ValueError):
        return ''
    if n <= 0:
        return ''
    return str(n // 60 if n >= 1000 else n)   # >= 1000 son segundos


def _entero(valor):
    """El entero que sea, o `None`. Para `stream_id`, que llega como texto en unos paneles y
    como número en otros; un `int('abc')` a media línea es un `ValueError` que tumba la
    página entera."""
    try:
        return int(str(valor).strip())
    except (TypeError, ValueError, AttributeError):
        return None


# --- series ----------------------------------------------------------------
#
# Las tres van en el mismo sitio y con las mismas reglas que `listado()`, por el mismo motivo:
# `iptv_parse.xtream_episodes()` devuelve canales con la URL montada y la credencial dentro, y
# lo que sale de aquí no puede llevarla. Se reusa `clean_name()` y el reparto de extensiones.

def series(fuente, categoria='', pagina=0, dp=None, limite=LIMITE, forzar=False):
    """Una página de series. Devuelve `(filas, hay_mas)`, como `listado()`.

    Filas de `{'id', 'nombre', 'logo', 'plot'}`. El `id` es un `series_id`, y es lo único que
    hace falta para pedir las temporadas: la fila lleva ese id y nada más.
    """
    if 'series' not in SECCIONES:
        raise ValueError('sección desconocida: {0!r}'.format('series'))

    pagina = max(int(pagina or 0), 0)
    limite = max(int(limite or LIMITE), 1)

    fid = fuente['id']
    clave = _clave_cache('list', 'series', categoria, pagina, limite,
                         _huella_de(fuente))
    guardado = _lee_lista(fid, clave, forzar=forzar)
    if guardado is not None:
        return guardado['filas'], guardado['mas']

    # Si el panel no pagina, la lista completa ya está guardada y se corta el tramo.
    entera = _lee_lista(fid, _clave_cache('list', 'series', categoria, _TODAS, limite,
                                          _huella_de(fuente)), forzar=forzar)
    if entera is not None:
        return _corta(entera['filas'], pagina, limite)

    params = {'start': pagina * limite, 'limit': limite}
    if categoria:
        params['category_id'] = categoria
    respuesta = pedir(fuente, 'get_series', dp, **params)
    crudos = [f for f in respuesta if isinstance(f, dict)] \
        if isinstance(respuesta, list) else []
    filas = [f for f in (_serie_de(s) for s in crudos) if f]

    if len(crudos) > limite:
        # El panel ha ignorado start/limit: se guarda completa y se corta.
        _guarda_lista(fid, _clave_cache('list', 'series', categoria, _TODAS, limite,
                                        _huella_de(fuente)),
                      filas, len(filas) > limite)
        return _corta(filas, pagina, limite)

    _guarda_lista(fid, clave, filas, len(crudos) >= limite)
    return filas, len(crudos) >= limite


def _serie_de(s):
    """Una fila de serie, `{'id', 'nombre', 'logo', 'plot'}`, o `None` sin `series_id`.

    Aparte porque la escriben `series()` y `lista_entera()`, y el buscador lee las dos con el
    mismo prefijo: si una fila cambiara de forma en un solo sitio, la otra saldría rota.
    """
    import iptv_parse as P
    sid = _entero(s.get('series_id'))
    if sid is None:
        return None
    return {'id': str(sid), 'nombre': P.clean_name(s.get('name')) or str(sid),
            'logo': str(s.get('cover') or ''), 'plot': str(s.get('plot') or '')}


def lista_entera(fuente, seccion, categoria, nombre_categoria='', dp=None):
    """Una categoría entera, guardada donde `listado()` y `series()` la buscan. Devuelve cuántas.

    Es lo que hace «Indexar». El buscador no va a la red: lee `list_<sec>_*` de la caché, y con
    un panel que respeta `start`/`limit` ahí solo hay las páginas que se han abierto. Aquí se pide
    la categoría sin `start` ni `limit`, que en Xtream es «todo», y se guarda con la clave
    `_TODAS`, propia de paneles que no paginan. Así sirve a la vez para buscar y para
    navegar: `listado()` corta las páginas de aquí sin pedir nada, y también las que pasan de
    `MAX_PAGINAS`.

    La clave lleva `LIMITE` porque es la que buscan `listado()` y `series()` con su límite por
    defecto, que es el único que usan las vistas.
    """
    if seccion not in SECCIONES:
        raise ValueError(f'sección desconocida: {seccion!r}')
    params = {'category_id': categoria} if categoria else {}
    respuesta = pedir(fuente, SECCIONES[seccion]['streams'], dp, **params)
    crudos = [f for f in respuesta if isinstance(f, dict)] if isinstance(respuesta, list) else []
    if seccion == 'series':
        filas = [f for f in (_serie_de(s) for s in crudos) if f]
    else:
        filas = [f for f in (_fila_de(c, seccion, nombre_categoria) for c in crudos) if f]
    _guarda_lista(fuente['id'], _clave_cache('list', seccion, categoria, _TODAS, LIMITE,
                                             _huella_de(fuente)),
                  filas, len(filas) > LIMITE)
    return len(filas)


def info_serie(fuente, serie_id, dp=None, forzar=False):
    """Lo que el servidor dice de una serie, **sin los capitulos**.

    `get_series_info` devuelve las temporadas Y todos los capitulos de golpe, y no hay una
    llamada más ligera: es la forma de la API. Aquí se quita el `episodes` de la respuesta y se
    cachea lo que queda, que son unos pocos campos. Así el `plot` de una serie se puede pintar
    sinuju enorme en memoria cada vez que se abre, y los capitulos se piden aparte.

    Se cachea **la respuesta sin capitulos**, no la entera: cachear 800 capítulos de una serie
    larga para no volver a pedirlos es justo lo que hace que la cache del modulo crezca sin
    control, y el TTL ya se encarga de lo que cambia.
    """
    sid = _entero(serie_id)
    if sid is None:
        raise ValueError('no es un identificador de serie: {0!r}'.format(serie_id))

    fid = fuente['id']
    clave = _clave_cache('serie', sid, _huella_de(fuente))
    guardado = _lee_cache(fid, clave, forzar=forzar)
    if isinstance(guardado, dict):
        return guardado

    info = pedir(fuente, 'get_series_info', dp, series_id=sid)
    if not isinstance(info, dict):
        return {}
    # `seasons` es una lista de diccionarios con `season_number` y `episode_count`. Es la
    # fuente de "cuántos capítulos hay", que es lo que hace falta para pintar "Temporada 1 (24)".
    temporadas = []
    for s in info.get('seasons') if isinstance(info.get('seasons'), list) else []:
        if not isinstance(s, dict):
            continue
        num = _entero(s.get('season_number'))
        if num is None:
            # Sin numero de temporada este saison no se puede ni mostrar ni pedir.
            continue
        temporadas.append({'numero': num,
                           'nombre': str(s.get('name') or '').strip(),
                           'capitulos': _entero(s.get('episode_count'))})
    datos = {'nombre': str(info.get('name') or '').strip(),
             'logo': str(info.get('cover') or ''),
             'plot': str(info.get('plot') or ''),
             'temporadas': temporadas}
    _guarda_cache(fid, clave, datos)
    return datos


def capitulos(fuente, serie_id, temporada=None, dp=None, forzar=False):
    """Los capitulos de una temporada. Filas de `{'sid', 'nombre', 'logo', 'num'}`.

    Con `temporada=None` salen **todas**, que es lo que quiere la pantalla de capitulos cuando
    se entra por la serie y no por una temporada concreta.

    De `iptv_parse.xtream_episodes()` se reusa solo lo importante: que se aceptan las dos
    formas que mandan los paneles (`episodes` como diccionario de temporada -> lista, o como
    lista de listas). Eso es lo que hay que acertar y es lo que se rompe con cada clon distinto.
    Lo que **no** se reusa es el `new_channel` con la URL dentro, que es justo lo que aquí no
    puede pasar.
    """
    import iptv_parse as P

    sid = _entero(serie_id)
    if sid is None:
        raise ValueError('no es un identificador de serie: {0!r}'.format(serie_id))
    num = None if temporada is None else _entero(temporada)

    fid = fuente['id']
    clave = _clave_cache('caps', sid, 'todas' if num is None else num,
                         _huella_de(fuente))
    guardado = _lee_cache(fid, clave, forzar=forzar)
    if isinstance(guardado, list):
        return guardado

    info = pedir(fuente, 'get_series_info', dp, series_id=sid)
    episodes = info.get('episodes') if isinstance(info, dict) else None
    if isinstance(episodes, dict):
        grupos = list(episodes.items())
    elif isinstance(episodes, list):
        grupos = [('', g) for g in episodes]
    else:
        grupos = []

    filas = []
    sin_temporada = 0
    for clave_temporada, rows in grupos:
        if not isinstance(rows, list):
            continue
        temporada_del_grupo = _entero(clave_temporada)
        for e in rows:
            if not isinstance(e, dict):
                continue
            eid = _entero(e.get('id'))
            if eid is None:
                continue
            # La temporada sale de la clave del grupo cuando `episodes` es un dict
            # (`{"1": [...]}`), y del campo `season` del capítulo cuando es una lista (ahí la
            # clave es `''` y `_entero('')` da None). Hay que mirar los dos o pedir la temporada 2
            # devuelve todas. Mismo respaldo que `iptv_parse.xtream_episodes`.
            temporada_de_esta = temporada_del_grupo
            if temporada_de_esta is None:
                temporada_de_esta = _entero(e.get('season'))

            if num is not None:
                if temporada_de_esta is None:
                    # Se pidio una temporada concreta y este capitulo **no dice cual es**. No se
                    # incluye: pasarlo seria enseñar como de la temporada pedida un capitulo que
                    # puede ser de otra. Se cuentan para poder decirlo en el log, porque si esto
                    # pasa mucho el problema es del panel y hay que verlo.
                    sin_temporada += 1
                    continue
                if temporada_de_esta != num:
                    continue
            numero = _entero(e.get('episode_num'))
            extra = e.get('info') if isinstance(e.get('info'), dict) else {}
            nombre = P.clean_name(e.get('title')) or 'Capítulo {0}'.format(
                numero if numero is not None else eid)
            filas.append({'sid': str(eid), 'nombre': nombre, 'num': numero,
                          'logo': str(extra.get('movie_image') or e.get('movie_image') or ''),
                          'ext': _extension(e.get('container_extension')),
                          'temporada': temporada_de_esta})
    # El fallback del numero es el **id, y como entero**. Con `f['sid']`, que es texto, un
    # capitulo con `episode_num` y otro sin el llegan a compararse `int` contra `str` y sale
    # un `TypeError` que deja la pantalla en blanco. El tercer elemento desempata y es texto
    # en las dos ramas, que es lo que evita que vuelva a pasar.
    # Es el mismo criterio que `iptv_parse.xtream_episodes:1656`.
    filas.sort(key=lambda f: (f['temporada'] if f['temporada'] is not None else 0,
                              f['num'] if f['num'] is not None else (_entero(f['sid']) or 0),
                              str(f['sid'])))
    _guarda_cache(fid, clave, filas)
    if sin_temporada:
        # Solo cuando se pidio una temporada concreta: es el caso en el que un capitulo sin
        # `season` **no se puede incluir** y se pierde. Con `temporada=None` no hay nada que
        # perder, asi que no se dice nada.
        #
        # Va al log y no a un aviso porque no hay nada que hacer: es el panel, que no manda la
        # temporada. Lo que se evita es que se diagnose como
        # «no hay capitulos» cuando en realidad hay algunos y no se sabe de que son.
        _log('de la serie {0} se han dejado fuera {1} capitulo(s) sin `season` al pedir la '
             'temporada {2}'.format(serie_id, sin_temporada, num), xbmc.LOGWARNING)
    return filas


def _extension(valor):
    """La extensión, limpia, o `mp4`. Lo mismo que hace `iptv_parse._file_ext`, que es
    privado, y en cuatro líneas: quitar los puntos, y si no son de 1 a 5 letras y digitos, no
    vale y se deja el que funciona en todas partes."""
    ext = str(valor or '').strip().lstrip('.')
    return ext if _EXT_OK.fullmatch(ext) else 'mp4'


#: Traducción de `fuentes_formato` a una extensión, en un solo sitio.
#:
#: El ajuste es un `labelenum` y Kodi guarda la etiqueta visible ("HLS (m3u8)"), no un valor.
#: Sin traducirla, la extensión llevaría espacios y paréntesis y la URL saldría rota. Si cambia
#: el texto en `settings.xml`, hay que cambiarlo aquí.
_FORMATO_A_EXT = {
    'automatico': '',
    'hls (m3u8)': 'm3u8',
    'ts nativo': 'ts',
    'm3u8': 'm3u8',
    'ts': 'ts',
}


def _extension_elegida(valor):
    """La extension que dice el ajuste, o cadena vacia para que decida la cuenta.

    **Nunca lanza y nunca devuelve algo raro.** Una etiqueta que no este en el mapa (porque el
    `settings.xml` cambio, o porque alguien metio una mano) se queda en cadena vacia, que es
    exactamente "no has elegido": lo decide la cuenta. Devolver la etiqueta tal cual seria justo el
    bug que se arregla aqui.
    """
    return _FORMATO_A_EXT.get(str(valor or '').strip().lower(), '')


def url_de(fuente, seccion, stream_id, extension=None, dp=None):
    """La URL de un canal, **con el usuario y la clave dentro del camino**.

    Y aquí está lo importante: **esta URL no puede ir en un `plugin://`**. Acabaría en el
    historial de Kodi, en el favorito y en la grabación, con la contraseña a la vista
    (`iptv_lists._channel_item()` lo hace así, y por eso aquí no se reutiliza).

    Lo que va en la fila es un `fid` y un `sid`, y esta función se llama en el momento de
    reproducir, una vez y solo una. Por eso está aquí y no en la vista: es la función que
    **no** se puede guardar en ninguna parte.

    `extension` solo hace falta en `vod` y en capítulos de serie, donde cada entrada trae la
    suya (`container_extension`). En directo decide la cuenta, y por eso se lee de la caché y
    no se elige aquí.
    """
    if seccion not in SECCIONES:
        raise ValueError('sección desconocida: {0!r}'.format(seccion))
    sid = _entero(stream_id)
    if sid is None:
        raise ValueError('no es un identificador de canal: {0!r}'.format(stream_id))

    camino = SECCIONES[seccion]['camino']
    if seccion == 'live':
        # Orden: el ajuste `fuentes_formato` y, si no hay, lo que dice la cuenta. El ajuste
        # es un `labelenum` y guarda la etiqueta ("TS nativo"), que hay que traducir para no
        # meter espacios en la extensión. Se lee el ajuste y no el `formato` copiado al dar de
        # alta; ese solo se respeta si es una extensión válida (`ts`, `m3u8`), como en los
        # importados antiguos.
        elegido = _extension_elegida(_ajuste('fuentes_formato'))
        if not elegido and fuente.get('formato'):
            elegido = _extension_elegida(fuente.get('formato')) or \
                str(fuente.get('formato') or '').strip().lstrip('.')
        if elegido:
            ext = elegido
        else:
            # La cuenta decide, pero **no puede tumbar la reproduccion**.
            # `url_de()` se llama en el momento de darle al play: si el
            # panel no contesta ahi, el canal no se ve y no hay plan B.
            # Con el almacen escribiendo cadena vacia en vez de `m3u8`
            # forzado, este camino se abre tambien para las fuentes que no
            # traen el campo (importadas de un texto, p.ej.), asi que hace
            # falta la salida.
            try:
                ext = cuenta_cacheada(fuente, dp).get('fmt') or 'm3u8'
            except Exception:
                ext = 'm3u8'
        ext = str(ext).lstrip('.')
    else:
        ext = _extension(extension)
    usuario = urllib.parse.quote(fuente['usuario'], safe='')
    clave = urllib.parse.quote(fuente['clave'], safe='')
    return '{0}/{1}/{2}/{3}/{4}.{5}'.format(fuente['servidor'], camino, usuario, clave,
                                            sid, ext)