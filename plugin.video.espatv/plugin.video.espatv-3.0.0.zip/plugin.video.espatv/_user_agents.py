# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
import urllib.parse

UA_DESKTOP = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/138.0.0.0 Safari/537.36"
)

UA_DAILYMOTION_LEGACY = (
    "Mozilla/5.0 (Linux; Android 7.1.1; Pixel Build/NMF26O) "
    "AppleWebKit/537.36 (KHTML, like Gecko) "
    "Chrome/55.0.2883.91 Mobile Safari/537.36"
)

UA_KODI = "Kodi/EspaTV"


def ua_addon(que="", version=""):
    """User-Agent del addon, con datos de contacto.

    Lo pide Wikimedia de forma explícita: un User-Agent sin información de
    contacto "may be blocked without notice", y copiar el de un navegador se toma
    como malicioso. Los dos módulos que consultan sus APIs (efemerides.py y
    nombres.py) usan este. Los que hablan con otras APIs pueden seguir con su
    cadena propia: allí no hay tal exigencia.
    """
    try:
        if not version:
            import xbmcaddon
            version = xbmcaddon.Addon().getAddonInfo("version") or ""
    except Exception:
        version = version or ""
    return ("EspaTV/{0} (Kodi addon;{1} https://github.com/espakodi; "
            "t.me/rubensdfa1laberot)").format(
        version or "?", (" " + que) if que else "")

_SEC_CH_UA = (
    '"Chromium";v="138", "Google Chrome";v="138", "Not A Brand";v="24"'
)

ACCEPT_LANG_ES = "es-ES,es;q=0.9,en;q=0.8"
ACCEPT_HTML = "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8"
ACCEPT_JSON = "application/json,text/plain,*/*;q=0.8"


def desktop_headers(accept=None, referer=None, origin=None):
    """Devuelve headers de Chrome 138 desktop con Client Hints y Accept-Language."""
    h = {
        "User-Agent": UA_DESKTOP,
        "Accept-Language": ACCEPT_LANG_ES,
        "sec-ch-ua": _SEC_CH_UA,
        "sec-ch-ua-mobile": "?0",
        "sec-ch-ua-platform": '"Windows"',
    }
    if accept:
        h["Accept"] = accept
    if referer:
        h["Referer"] = referer
    if origin:
        h["Origin"] = origin
    return h


def ua_desktop_pipe_encoded():
    """UA_DESKTOP codificado en quote_plus para el formato pipe de Kodi (|header=value&...)."""
    return urllib.parse.quote_plus(UA_DESKTOP)
