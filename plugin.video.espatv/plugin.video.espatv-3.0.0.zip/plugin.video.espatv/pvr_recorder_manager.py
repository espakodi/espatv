# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
# Coordinador de Interfaz y Background para el PVR HLS

import os
import re
import time
import xbmc
import xbmcgui
import xbmcaddon
from datetime import datetime

from hls_recorder import HLSRecorder, ffmpeg_available

_KODI_WINDOW = xbmcgui.Window(10000)
_ACTIVAS = "espatv_active_recordings"
_ESPERA_AL_PARAR = 45


def _sumar_activas(n):
    """Cuántas grabaciones hay en marcha, contando todas las llamadas al plugin.

    Era un sí/no: con dos grabaciones, la primera en acabar lo borraba y la otra quedaba
    fuera de «Detener todas»."""
    try:
        activas = int(_KODI_WINDOW.getProperty(_ACTIVAS) or 0)
    except ValueError:
        activas = 0
    activas = max(0, activas + n)
    if activas:
        _KODI_WINDOW.setProperty(_ACTIVAS, str(activas))
    else:
        _KODI_WINDOW.clearProperty(_ACTIVAS)


def _get_setting(setting_id):
    return xbmcaddon.Addon().getSetting(setting_id)


def archivo_grabado_ok(path):
    """Una grabación solo se da por buena si el archivo existe y tiene tamaño: si el
    hilo no llegó a renombrar el parcial, o quedó a 0 bytes, no hay grabación."""
    try:
        return os.path.isfile(path) and os.path.getsize(path) > 0
    except OSError:
        return False


def get_record_path():
    path = _get_setting("record_path")
    if not path:
        if not xbmcgui.Dialog().yesno(
            "Carpeta no configurada",
            "No has configurado dónde guardar las grabaciones.\n\n¿Quieres elegir la carpeta ahora?"
        ):
            return ""
        path = xbmcgui.Dialog().browse(3, "Elige dónde guardar las grabaciones de TDT", "files")
        if path:
            xbmcaddon.Addon().setSetting("record_path", path)
    return path


def _parse_time_label(label):
    """Convierte '1 hora', '1h 30min', '30 min', '45' a minutos. Devuelve 0 si no aplica."""
    if not label:
        return 0
    label = label.strip().lower()
    if label in ("ahora", "sin límite", "sin limite", "infinito", ""):
        return 0

    m = re.match(r'^(\d+)\s*h\s*(\d+)\s*min', label)
    if m:
        return int(m.group(1)) * 60 + int(m.group(2))

    m = re.match(r'^(\d+)\s*hora', label)
    if m:
        return int(m.group(1)) * 60

    m = re.match(r'^(\d+)\s*min', label)
    if m:
        return int(m.group(1))

    try:
        return int(label)
    except ValueError:
        return 0


def get_timer_mins():
    return _parse_time_label(_get_setting("record_timer"))


def get_delay_mins():
    return _parse_time_label(_get_setting("record_delay"))


def get_max_bandwidth():
    val = _get_setting("record_quality")
    if not val:
        return 0
    val_lower = val.strip().lower()
    if "1080" in val_lower or "máxima" in val_lower or "maxima" in val_lower:
        return 0
    if "720" in val_lower or "alta" in val_lower:
        return 3_000_000
    if "480" in val_lower or "media" in val_lower:
        return 1_500_000
    if "360" in val_lower or "baja" in val_lower:
        return 800_000
    return 0


def get_record_format():
    """Devuelve 'ask' | 'ts' | 'mp4' según el ajuste de formato."""
    val = (_get_setting("record_format") or "").lower()
    if "mp4" in val:
        return "mp4"
    if "ts" in val:
        return "ts"
    return "ask"


def _sanitize_filename(raw_name):
    safe = "".join(c for c in raw_name if c.isalnum() or c in (' ', '-', '_')).strip()
    if not safe:
        safe = "Grabacion_TDT"
    # Margen suficiente bajo PATH_MAX (260) tras concatenar carpeta + timestamp + extensión.
    return safe[:80]


def _get_pvr_subfolder(base_path):
    pvr_dir = os.path.join(base_path, "Grabaciones_PVR")
    if not os.path.exists(pvr_dir):
        os.makedirs(pvr_dir, exist_ok=True)
    return pvr_dir


def start_recording_ui(url, canonical_name):
    dest_path = get_record_path()
    if not dest_path:
        return

    # falla si la ruta no existe (USB no montado, red caída)
    if not os.path.isdir(dest_path):
        xbmcgui.Dialog().ok(
            "Error de grabación",
            "La carpeta de grabaciones no existe o no es accesible:\n\n{0}\n\nComprueba que el disco o USB está conectado.".format(dest_path)
        )
        return

    mins = get_timer_mins()
    delay_mins = get_delay_mins()
    pvr_dir = _get_pvr_subfolder(dest_path)

    fmt = get_record_format()
    has_ffmpeg = ffmpeg_available()
    if fmt == "mp4":
        compress = has_ffmpeg
        if not has_ffmpeg:
            xbmcgui.Dialog().notification(
                "EspaTV", "FFmpeg no disponible. Se graba en TS nativo.",
                xbmcgui.NOTIFICATION_WARNING, 5000
            )
    elif fmt == "ts":
        compress = False
    else:  # "ask"
        compress = has_ffmpeg and bool(xbmcgui.Dialog().yesno(
            "Formato de grabación",
            "¿Grabar en MP4 comprimido?\n\nArchivo un 50-70% más pequeño, compatible con cualquier reproductor.",
            nolabel="TS nativo",
            yeslabel="MP4 comprimido",
        ))

    if delay_mins > 0:
        dp_delay = xbmcgui.DialogProgress()
        dp_delay.create(
            "Grabación programada: {0}".format(canonical_name),
            "La grabación comenzará en {0} minutos...\nPulsa cancelar para abortar.".format(delay_mins)
        )
        total_secs = delay_mins * 60
        elapsed = 0
        monitor = xbmc.Monitor()
        while elapsed < total_secs:
            if dp_delay.iscanceled():
                dp_delay.close()
                xbmcgui.Dialog().notification("EspaTV", "Grabación programada cancelada.", xbmcgui.NOTIFICATION_INFO)
                return
            remaining = total_secs - elapsed
            rm = remaining // 60
            rs = remaining % 60
            pct = int((elapsed / float(total_secs)) * 100)
            dp_delay.update(pct, "Faltan {0}m {1}s para empezar a grabar...".format(rm, rs))
            if monitor.waitForAbort(1):
                dp_delay.close()
                return
            elapsed += 1
        dp_delay.close()

    safe_name = _sanitize_filename(canonical_name)
    date_str = datetime.now().strftime("%Y-%m-%d_%H-%M-%S")
    ext = 'mp4' if compress else 'ts'
    filename = f"{safe_name} - {date_str}.{ext}"

    fmt_label = ext.upper()
    out_file = os.path.join(pvr_dir, filename)
    max_bw = get_max_bandwidth()
    xbmc.log(f"[EspaTV-PVR] Grabacion iniciada. Destino: {out_file} | Calidad max: {max_bw if max_bw else 'Sin limite'} bps | Formato: {ext}", xbmc.LOGINFO)

    _sumar_activas(1)

    recorder = HLSRecorder(url, out_file, name=canonical_name, max_duration_mins=mins, max_bandwidth=max_bw, compress=compress)
    recorder.start()

    dp = xbmcgui.DialogProgress()
    dp.create("Grabando ({0}): {1}".format(fmt_label, canonical_name), "Conectando al stream en directo...")

    in_background = False
    bg_dp = None

    recorder.playlist_resolved.wait(timeout=10)
    start_time = time.time()  # Empieza a contar después de resolver la playlist, no antes
    if max_bw > 0 and recorder.quality_status != "matched":
        if recorder.quality_status == "forced_lowest":
            xbmcgui.Dialog().notification(
                "EspaTV", "No hay calidad tan baja. Se graba en la más baja disponible.",
                xbmcgui.NOTIFICATION_WARNING, 5000
            )
        elif recorder.quality_status in ("single", "error"):
            xbmcgui.Dialog().notification(
                "EspaTV", "Este canal solo ofrece una calidad. Se graba en la disponible.",
                xbmcgui.NOTIFICATION_INFO, 4000
            )

    while recorder.is_alive():
        if not in_background and dp.iscanceled():
            ans = xbmcgui.Dialog().yesno(
                "Grabar en Segundo Plano",
                "Has pulsado cancelar en la ventana principal.\n¿Quieres detener la grabación o dejarla funcionando de fondo?",
                nolabel="Detener y Guardar",
                yeslabel="Seguir de fondo"
            )

            if not ans:  # 0 -> Detener
                dp.update(100, "Cerrando archivo...")
                recorder.stop()
                # El hilo es daemon y renombra el .partial al acabar: si esta llamada vuelve
                # antes, Kodi lo mata a medias. Puede estar en una descarga de 15 s y luego
                # esperando otros 15 a que ffmpeg cierre.
                recorder.join(timeout=_ESPERA_AL_PARAR)
                break
            else:  # 1 -> Segundo plano
                dp.close()
                in_background = True
                bg_dp = xbmcgui.DialogProgressBG()
                bg_dp.create("EspaTV: Grabando", canonical_name)

        run_mins = recorder.get_run_time_mins()
        run_secs = int(time.time() - start_time)

        if mins > 0:
            pct = min(int((run_mins / float(mins)) * 100), 100)
        else:
            pct = run_secs % 100  # Sin límite: barra de actividad cíclica (indica "vivo")

        sin_datos = (recorder.downloaded_bytes == 0 and run_secs > 10)
        estado_red = "[COLOR orange]Reconectando...[/COLOR]" if sin_datos else "Conexión estable"

        if in_background:
            if bg_dp and not bg_dp.isFinished():
                bg_msg = "Datos: {0} | {1}".format(recorder.format_bytes(recorder.downloaded_bytes), estado_red)
                bg_dp.update(pct, heading="Grabando ({0}): {1}".format(fmt_label, canonical_name), message=bg_msg)
        else:
            line1 = "Duración actual: {0} min / {1}  [{2}]".format(
                run_mins, "{0} min".format(mins) if mins > 0 else "Infinito", fmt_label
            )
            line2 = "Descargado: {0}".format(recorder.format_bytes(recorder.downloaded_bytes))
            line3 = "Estado de red: {0}".format(estado_red)
            dp.update(pct, line1 + "\n" + line2 + "\n" + line3)

        time.sleep(0.5)

    if in_background and bg_dp:
        bg_dp.close()
    elif not in_background:
        dp.close()

    if recorder.error_msg:
        xbmcgui.Dialog().ok("Error en grabación", recorder.error_msg)
    elif recorder.downloaded_bytes == 0:
        xbmcgui.Dialog().notification(
            "Grabación fallida",
            "No se pudo descargar ningún dato del canal.",
            xbmcgui.NOTIFICATION_WARNING
        )
    elif not archivo_grabado_ok(out_file):
        # Llegaron datos, pero el archivo final no está o quedó vacío (fallo al renombrar
        # el parcial, disco lleno...): no se da por buena la grabación.
        xbmcgui.Dialog().notification(
            "Grabación incompleta",
            "Se recibieron datos, pero el archivo no se guardó correctamente.",
            xbmcgui.NOTIFICATION_WARNING, 5000
        )
    else:
        xbmcgui.Dialog().notification(
            "Grabación Completada",
            "{0} ({1})".format(canonical_name, recorder.format_bytes(recorder.downloaded_bytes)),
            xbmcgui.NOTIFICATION_INFO, 5000
        )

    _sumar_activas(-1)


def stop_all_recordings():
    c = _KODI_WINDOW.getProperty(_ACTIVAS)
    if not c:
        xbmcgui.Dialog().notification("EspaTV", "No hay grabaciones activas.", xbmcgui.NOTIFICATION_INFO)
        return

    if xbmcgui.Dialog().yesno(
        "Detener Grabaciones",
        "¿Estás seguro de que quieres finalizar todas las grabaciones de TDT en segundo plano?"
    ):
        # La hora de la orden y no un "1" que se borraba a los 3 s: el hilo de grabación solo
        # la lee entre descarga y descarga, y si estaba en una de 15 s la perdía para siempre
        # (ver HLSRecorder._parada_pedida). Las activas las descuenta cada grabación al acabar.
        _KODI_WINDOW.setProperty("espatv_force_stop", str(time.time()))
        xbmcgui.Dialog().notification(
            "EspaTV", "Señal de cierre enviada. Tardará unos segundos.",
            xbmcgui.NOTIFICATION_INFO
        )