# -*- coding: utf-8 -*-
# EspaTV, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Gestor del cliente PVR IPTV Simple de Kodi.

Desde Kodi 20, IPTV Simple admite varias listas, cada una en su instancia
(instance-settings-<N>.xml). EspaTV usa una propia, llamada "EspaTV", y no toca las demás: las
del usuario ni las de otros addons (AtresDaily, EKHorus...). En Kodi 19 solo hay una lista, la
de settings.xml, y es la que se configura.
"""
import json
import os
import re
import time
import uuid
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcvfs

from _user_agents import UA_DESKTOP

_PVR_ADDON_ID = "pvr.iptvsimple"

_CHROME_UA = UA_DESKTOP

_NOMBRE_INSTANCIA = "EspaTV"
# Nombre que Kodi pone a la instancia a la que pasa la lista única de Kodi 19. Las versiones
# anteriores de EspaTV dejaban ahí su lista, y esa instancia se reconoce como suya.
_NOMBRE_MIGRADA = "Migrated Add-on Config"
_RE_INSTANCIA = re.compile(r"instance-settings-(\d+)\.xml\Z")
# Una instancia sin nombre, la única a la que IPTV Simple pasa la lista de Kodi 19.
_INSTANCIA_VACIA = '<settings version="2">\n</settings>\n'
# IPTV Simple para en menos de un segundo; esto es el margen para un aparato lento.
_PARADA_MAX = 15


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"[EspaTV] PVR: {msg}", level)


def is_pvr_installed():
    # getCondVisibility y no xbmcaddon.Addon(id): cada llamada al segundo deja un
    # ERROR en kodi.log cuando IPTV Simple no esta puesto, y esto se consulta cada
    # vez que se abre la TV.
    return xbmc.getCondVisibility('System.HasAddon({0})'.format(_PVR_ADDON_ID))


def supports_instances():
    """True si IPTV Simple admite varias listas (Kodi 20 o posterior)."""
    try:
        return int(xbmc.getInfoLabel("System.BuildVersion").split(".")[0]) >= 20
    except ValueError:
        return True


def _execute_rpc(method, params=None):
    payload = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params:
        payload["params"] = params
    raw = xbmc.executeJSONRPC(json.dumps(payload))
    try:
        return json.loads(raw)
    except (ValueError, TypeError):
        return {}


def enable_pvr():
    resp = _execute_rpc(
        "Addons.SetAddonEnabled",
        {"addonid": _PVR_ADDON_ID, "enabled": True},
    )
    return resp.get("result") == "OK"


def _disable_pvr():
    _execute_rpc(
        "Addons.SetAddonEnabled",
        {"addonid": _PVR_ADDON_ID, "enabled": False},
    )


def trigger_pvr_reload():
    resp = _execute_rpc("PVR.Reload")
    return resp.get("result") == "OK"


def _build_settings_map(m3u_url, epg_url):
    return {
        "m3uPathType":      "1",
        "m3uUrl":           m3u_url,
        "m3uCache":         "false",
        "epgPathType":      "1",
        "epgUrl":           epg_url,
        "epgCache":         "false",
        "catchupEnabled":   "false",
        "logoPathType":     "0",
        "defaultUserAgent": _CHROME_UA,
    }


def _carpeta():
    return os.path.normpath(
        xbmcvfs.translatePath("special://userdata/addon_data/" + _PVR_ADDON_ID)
    )


def _escribir(ruta, texto):
    """Escritura atómica. En Windows os.replace falla si otro proceso tiene el fichero abierto
    en ese momento, así que se reintenta un poco."""
    tmp = f"{ruta}.{os.getpid()}.{uuid.uuid4().hex[:8]}.tmp"
    try:
        with open(tmp, "w", encoding="utf-8", newline="\n") as f:
            f.write(texto)
        for intento in range(5):
            try:
                os.replace(tmp, ruta)
                return True
            except PermissionError:
                time.sleep(0.1 * (intento + 1))
        _log(f"{ruta} sigue ocupado, no se ha podido escribir", xbmc.LOGERROR)
    except OSError as exc:
        _log(f"no se ha podido escribir {ruta}: {exc}", xbmc.LOGERROR)
    try:
        os.remove(tmp)
    except OSError:
        pass
    return False


def _ajustes(ruta):
    """{id: valor} de un fichero de ajustes, o None si no se puede leer."""
    try:
        raiz = ET.parse(ruta).getroot()
    except (OSError, ET.ParseError) as exc:
        _log(f"no se puede leer {ruta}: {exc}", xbmc.LOGWARNING)
        return None
    return {s.get("id"): (s.text or "").strip() for s in raiz.iter("setting")}


def _instancias(carpeta):
    try:
        nombres = os.listdir(carpeta)
    except OSError:
        return {}
    return {int(m.group(1)): os.path.join(carpeta, m.group(0))
            for m in map(_RE_INSTANCIA.match, nombres) if m}


def _nuestra(instancias, m3u_url):
    """Número de la instancia de EspaTV: la que se llama así o, si no hay, una sin nombre propio
    que ya tenga la lista de EspaTV (la que dejaban las versiones anteriores). Nunca una con
    otro nombre, que es de otro addon o del usuario."""
    heredada = None
    for numero, ruta in sorted(instancias.items()):
        ajustes = _ajustes(ruta) or {}
        nombre = ajustes.get("kodi_addon_instance_name", "")
        if nombre == _NOMBRE_INSTANCIA:
            return numero
        if (heredada is None and nombre in ("", _NOMBRE_MIGRADA)
                and ajustes.get("m3uPathType") == "1" and ajustes.get("m3uUrl") == m3u_url):
            heredada = numero
    return heredada


def _numero_nuevo(instancias, carpeta, m3u_url):
    """(número, hace falta una 1 vacía). Sin ninguna instancia, la 1; salvo que en settings.xml
    espere a migrar la lista de Kodi 19 de otro, que solo va a una instancia sin nombre, así que
    se deja la 1 vacía para ella y la de EspaTV es la 2."""
    if instancias:
        return max(instancias) + 1, False
    ruta = os.path.join(carpeta, "settings.xml")
    viejo = _ajustes(ruta) if os.path.isfile(ruta) else None
    if viejo and (viejo.get("m3uPath") or viejo.get("m3uUrl")) and viejo.get("m3uUrl") != m3u_url:
        return 2, True
    return 1, False


def _xml_instancia(valores):
    # Ningún default="true": Kodi tomaría el valor por no tocado y lo ignoraría.
    raiz = ET.Element("settings", version="2")
    for clave, valor in valores.items():
        ET.SubElement(raiz, "setting", id=clave).text = valor
    return ET.tostring(raiz, encoding="unicode") + "\n"


def _aplicar_instancia(m3u_url, epg_url):
    """Escribe la instancia de EspaTV. Devuelve (exito, hubo_cambios)."""
    carpeta = _carpeta()
    try:
        os.makedirs(carpeta, exist_ok=True)
    except OSError as exc:
        _log(f"no se puede crear {carpeta}: {exc}", xbmc.LOGERROR)
        return False, False
    valores = {"kodi_addon_instance_name": _NOMBRE_INSTANCIA,
               "kodi_addon_instance_enabled": "true"}
    valores.update(_build_settings_map(m3u_url, epg_url))

    instancias = _instancias(carpeta)
    numero = _nuestra(instancias, m3u_url)
    if numero is None:
        numero, con_vacia = _numero_nuevo(instancias, carpeta, m3u_url)
        if con_vacia and not _escribir(os.path.join(carpeta, "instance-settings-1.xml"), _INSTANCIA_VACIA):
            return False, False
        ok = _escribir(os.path.join(carpeta, f"instance-settings-{numero}.xml"), _xml_instancia(valores))
        _log(f"instancia {numero} creada" if ok else f"no se ha podido crear la instancia {numero}")
        return ok, ok

    ruta = instancias[numero]
    try:
        arbol = ET.parse(ruta)
    except (OSError, ET.ParseError) as exc:
        _log(f"no se puede leer {ruta}: {exc}", xbmc.LOGERROR)
        return False, False
    raiz = arbol.getroot()
    cambiada = False
    for clave, valor in valores.items():
        nodo = next((s for s in raiz.iter("setting") if s.get("id") == clave), None)
        if nodo is None:
            nodo = ET.SubElement(raiz, "setting", id=clave)
        if (nodo.text or "").strip() != valor or "default" in nodo.attrib:
            nodo.text = valor
            nodo.attrib.pop("default", None)
            cambiada = True
    if not cambiada:
        return True, False
    ok = _escribir(ruta, ET.tostring(raiz, encoding="unicode") + "\n")
    return ok, ok


def _apply_via_addon_api(m3u_url, epg_url):
    try:
        addon = xbmcaddon.Addon(_PVR_ADDON_ID)
    except RuntimeError:
        return False

    cambios = False
    for key, val in _build_settings_map(m3u_url, epg_url).items():
        if addon.getSetting(key) != val:
            addon.setSetting(key, val)
            cambios = True
    return cambios


def _apply_via_xml(m3u_url, epg_url):
    """Kodi 19: la lista única de IPTV Simple, en su settings.xml."""
    ruta = os.path.join(_carpeta(), "settings.xml")
    if not os.path.isfile(ruta):
        return False

    tree = ET.parse(ruta)
    root = tree.getroot()
    mapping = _build_settings_map(m3u_url, epg_url)
    existing_ids = set()
    changed = False

    for node in root.findall("setting"):
        sid = node.get("id")
        existing_ids.add(sid)
        if sid in mapping and (node.text or "") != mapping[sid]:
            node.text = mapping[sid]
            node.attrib.pop("default", None)
            changed = True

    for sid, val in mapping.items():
        if sid not in existing_ids:
            ET.SubElement(root, "setting", id=sid).text = val
            changed = True

    if changed and not _escribir(ruta, ET.tostring(root, encoding="unicode") + "\n"):
        raise OSError(f"no se ha podido escribir {ruta}")
    return changed


def configure_pvr_settings(m3u_url, epg_url):
    """Aplica la configuración de EspaTV. Devuelve (exito, hubo_cambios)."""
    if supports_instances():
        return _aplicar_instancia(m3u_url, epg_url)

    _apply_via_addon_api(m3u_url, epg_url)
    try:
        cambios = _apply_via_xml(m3u_url, epg_url)
    except (OSError, ET.ParseError) as exc:
        _log(f"error configurando: {exc}", xbmc.LOGERROR)
        return False, False
    return True, bool(cambios)


def _parado():
    """IPTV Simple ha parado del todo: apagado, sin clientes y con la TV de Kodi quieta."""
    if xbmc.getCondVisibility(f"System.AddonIsEnabled({_PVR_ADDON_ID})"):
        return False
    clientes = _execute_rpc("PVR.GetClients").get("result", {}).get("clients") or []
    if any(c.get("addonid") == _PVR_ADDON_ID for c in clientes):
        return False
    return xbmc.getInfoLabel("PVR.BackendHost") == "" or bool(clientes)


def _esperar_parada():
    monitor = xbmc.Monitor()
    limite = time.time() + _PARADA_MAX
    while not _parado() and time.time() < limite:
        if monitor.waitForAbort(0.25):
            return


def check_and_setup_pvr(m3u_url, epg_url):
    """Instala IPTV Simple si falta, escribe la lista de EspaTV y lo recarga.

    Se escribe con IPTV Simple apagado, y se espera a que pare del todo antes: encenderlo
    antes de tiempo deja instancias sin cargar."""
    if not is_pvr_installed():
        xbmcgui.Dialog().ok(
            "EspaTV",
            "Para ver la parrilla de TV necesitas el modulo PVR IPTV Simple.\n"
            "Pulsa instalar en la siguiente pantalla.",
        )
        xbmc.executebuiltin(f"InstallAddon({_PVR_ADDON_ID})")
        return False

    _disable_pvr()
    _esperar_parada()
    time.sleep(0.5)

    success, _cambios = configure_pvr_settings(m3u_url, epg_url)
    enable_pvr()
    return success
