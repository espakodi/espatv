# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""
Reproductor de URLs Externas para EspaTV

Permite al usuario pegar una URL de vídeo y reproducirla en Kodi.
--
Inicia un mini servidor en la red local que sirve una pagina web
donde el usuario puede pegar una URL. 
Al enviar, Kodi lo recibe y actua.

Incluye controles de reproduccion y estado en tiempo real
mediante JSON-RPC de Kodi.

Idea original de RubenSDFA1labernt:
La implementación de un servidor HTTP local efímero que se levanta bajo demanda
para enviar URLs o texto a Kodi y se cierra automáticamente al terminar, sin dejar puertos abiertos ni obligar
al usuario a activar el control HTTP en los ajustes del sistema Kodi.

Si decides utilizar este código en tus propios desarrollos o te inspiras en esta idea original, 
es de agradecer que menciones este proyecto.

Detección inteligente:
  - Dailymotion (dailymotion.com / dai.ly)   -> dm_gujal
  - YouTube     (youtube.com / youtu.be)      -> plugin.video.youtube
  - Streams     (.m3u8 / .mp4 / .mpd / etc.)  -> reproducción directa
  - Torrents    (magnet: / .torrent)           -> plugin.video.elementum
  - AceStream   (acestream://)                -> horus / motor local (HTTP)
  - Otras webs                                -> SendToKodi / yt-dlp

Escaneo de enlaces (no reproducción directa):
  - Webs         (cualquier URL)               -> html_scanner o yt-dlp
  - Telegram     (@canal, t.me/canal)          -> telegram_scanner, paginando
                                                  hacia atrás a demanda
"""
# noinspection PyUnresolvedReferences
import sys
import os
import hashlib
import json
import socket
import time
import re
import urllib.parse
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs
import ytdlp_resolver
import core_settings

_ADDON_ID = "plugin.video.espatv"
_profile_path = None
MAX_HISTORY = 20
MAX_BOOKMARKS = 50

_STREAM_EXTENSIONS = {
    ".m3u8", ".mp4", ".mkv", ".avi", ".ts", ".flv",
    ".mov", ".wmv", ".webm", ".mpd", ".m3u",
}

_ACESTREAM_RE = re.compile(r"^acestream://[0-9a-fA-F]{40}$")


def _ace_engine_alive(timeout=1):
    """True si el motor AceStream responde en 127.0.0.1:6878. Si nada escucha, falla por refused o por timeout corto (depende del firewall)."""
    try:
        with socket.create_connection(("127.0.0.1", 6878), timeout=timeout):
            return True
    except OSError:
        return False


def _get_profile():
    global _profile_path
    if _profile_path is None:
        _profile_path = xbmcvfs.translatePath(
            xbmcaddon.Addon().getAddonInfo("profile")
        )
        if not os.path.exists(_profile_path):
            os.makedirs(_profile_path)
    return _profile_path


def _history_path():
    return os.path.join(_get_profile(), "url_history.json")


def _bookmarks_path():
    return os.path.join(_get_profile(), "url_bookmarks.json")


def _load_json(path):
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (json.JSONDecodeError, IOError):
        return []


def _save_json(path, data):
    try:
        core_settings.atomic_write_json(path, data)
    except IOError:
        pass


_DEBRID_CACHE_TTL = 600   # 10 min: los enlaces Debrid caducan, TTL conservador
_DEBRID_CACHE_MAX = 20


def _debrid_cache_path():
    return os.path.join(_get_profile(), "debrid_resolve_cache.json")


def _debrid_cache_key(provider, url):
    return hashlib.sha1("{0}|{1}".format(provider, url).encode("utf-8")).hexdigest()


def _debrid_cache_get(provider, url):
    data = _load_json(_debrid_cache_path())
    if not isinstance(data, dict):
        return None
    entry = data.get(_debrid_cache_key(provider, url))
    if entry and (time.time() - entry.get("ts", 0)) < _DEBRID_CACHE_TTL:
        return entry.get("stream")
    return None


def _debrid_cache_put(provider, url, stream):
    data = _load_json(_debrid_cache_path())
    if not isinstance(data, dict):
        data = {}
    data[_debrid_cache_key(provider, url)] = {"stream": stream, "ts": int(time.time())}
    if len(data) > _DEBRID_CACHE_MAX:
        recientes = sorted(data.items(), key=lambda kv: kv[1].get("ts", 0), reverse=True)[:_DEBRID_CACHE_MAX]
        data = dict(recientes)
    _save_json(_debrid_cache_path(), data)


def parse_url_with_headers(raw_url):
    """Separa URL y headers en formato pipe.

    Entrada: "http://example.com/video.m3u8|User-Agent=xxx&Referer=yyy"
    Salida:  ("http://example.com/video.m3u8", {"User-Agent": "xxx", ...})
    """
    if not raw_url:
        return "", {}
    raw_url = raw_url.strip()
    if "|" not in raw_url:
        return raw_url, {}

    parts = raw_url.split("|", 1)
    url = parts[0].strip()
    headers_str = parts[1].strip()
    if not headers_str:
        return url, {}

    headers = {}
    for pair in headers_str.split("&"):
        if "=" in pair:
            key, value = pair.split("=", 1)
            key = key.strip()
            value = value.strip()
            if len(value) >= 2 and value[0] in ('"', "'") and value[-1] == value[0]:
                value = value[1:-1]
            if key:
                headers[key] = value
    return url, headers


def is_direct_stream(url):
    try:
        parsed = urllib.parse.urlparse(url)
    except ValueError:
        return False
    _, ext = os.path.splitext(parsed.path.lower())
    return ext in _STREAM_EXTENSIONS


def build_kodi_url(url, headers=None):
    if not headers:
        return url
    parts = ["{0}={1}".format(k, v) for k, v in headers.items()]
    return url + "|" + "&".join(parts)


def detect_dailymotion_id(url):
    if not url:
        return None
    try:
        parsed = urllib.parse.urlparse(url)
    except ValueError:
        return None
    host = (parsed.hostname or "").lower()
    if host.startswith("www."):
        host = host[4:]

    if host.endswith("dailymotion.com"):
        match = re.match(r"/video/([a-zA-Z0-9]+)", parsed.path)
        if match:
            return match.group(1)
        match = re.match(r"/embed/video/([a-zA-Z0-9]+)", parsed.path)
        if match:
            return match.group(1)
    elif host == "dai.ly":
        vid = parsed.path.strip("/")
        if vid:
            return vid.split("_")[0].split("?")[0]
    return None


def detect_youtube_id(url):
    if not url:
        return None
    try:
        parsed = urllib.parse.urlparse(url)
    except ValueError:
        return None
    host = (parsed.hostname or "").lower()
    if host.startswith("www."):
        host = host[4:]

    if host in ("youtube.com", "m.youtube.com"):
        if "/watch" in parsed.path:
            params = urllib.parse.parse_qs(parsed.query)
            vid_list = params.get("v", [])
            if vid_list:
                return vid_list[0]
        elif "/shorts/" in parsed.path:
            match = re.match(r"/shorts/([a-zA-Z0-9_-]+)", parsed.path)
            if match:
                return match.group(1)
        elif "/live/" in parsed.path:
            match = re.match(r"/live/([a-zA-Z0-9_-]+)", parsed.path)
            if match:
                return match.group(1)
    elif host == "youtu.be":
        vid = parsed.path.strip("/")
        if vid:
            return vid
    return None


def detect_url_type(raw_url):
    """Devuelve (tipo, id_o_url) ∈ {dailymotion, youtube, rtve, atresplayer, torrent, acestream, direct_stream, web_page}."""
    url, _ = parse_url_with_headers(raw_url)

    if url.startswith("magnet:"):
        return "torrent", url
    try:
        parsed_path = urllib.parse.urlparse(url).path.lower()
    except ValueError:
        parsed_path = ""
    if parsed_path.endswith(".torrent"):
        return "torrent", url

    # AceStream
    if _ACESTREAM_RE.match(url):
        return "acestream", url

    dm_id = detect_dailymotion_id(url)
    if dm_id:
        return "dailymotion", dm_id

    yt_id = detect_youtube_id(url)
    if yt_id:
        return "youtube", yt_id

    # RTVE Play
    rtve_match = re.match(
        r"https?://(?:www\.)?rtve\.es/(?:play/videos/.+?/|v/)(\d+)/?", url)
    if rtve_match:
        return "rtve", rtve_match.group(1)

    # A3pl._ayer
    if re.match(r"https?://(?:www\.)?atresplayer\.com/.+", url):
        return "atresplayer", url

    if is_direct_stream(url):
        return "direct_stream", raw_url

    return "web_page", url

_YT_RE = re.compile(
    r"(?:youtube\.com/watch\?.*?v=|youtu\.be/|youtube\.com/shorts/)"
    r"([A-Za-z0-9_-]{11})"
)
_DM_RE = re.compile(
    r"(?:dailymotion\.com/video/|dai\.ly/)([A-Za-z0-9]+)"
)
_VIMEO_RE = re.compile(r"vimeo\.com/(\d+)")
_OG_RE = re.compile(
    r'<meta[^>]+(?:property=["\']og:image["\'][^>]+content=["\']([^"\']+)["\']'
    r'|content=["\']([^"\']+)["\'][^>]+property=["\']og:image["\'])',
    re.IGNORECASE,
)
_THUMB_TIMEOUT = 3


def _auto_thumb(url):
    """Miniatura de la URL: YT/DM sin HTTP, Vimeo via oEmbed, otras vía og:image. '' si no hay."""
    if not url:
        return ""
    # YouTube: sin peticion HTTP
    m = _YT_RE.search(url)
    if m:
        return "https://img.youtube.com/vi/{0}/hqdefault.jpg".format(m.group(1))
    # Dailymotion: sin peticion HTTP
    m = _DM_RE.search(url)
    if m:
        return "https://www.dailymotion.com/thumbnail/video/{0}".format(m.group(1))
    # Vimeo: oEmbed API (sin autenticacion)
    m = _VIMEO_RE.search(url)
    if m:
        return _vimeo_thumb(url)
    # Webs genericas: intentar og:image
    if url.startswith("http"):
        return _og_thumb(url)
    return ""


def _vimeo_thumb(url):
    try:
        import requests
        r = requests.get(
            "https://vimeo.com/api/oembed.json",
            params={"url": url, "width": 480},
            timeout=_THUMB_TIMEOUT,
        )
        if r.status_code == 200:
            return r.json().get("thumbnail_url", "")
    except (ImportError, ValueError, OSError):
        pass
    return ""


def _og_thumb(url):
    try:
        import requests
        r = requests.get(
            url,
            timeout=_THUMB_TIMEOUT,
            headers={"User-Agent": "Mozilla/5.0"},
            stream=True,
        )
        try:
            if r.status_code != 200:
                return ""
            chunk = r.raw.read(8192).decode("utf-8", errors="ignore")
            m = _OG_RE.search(chunk)
            if m:
                return m.group(1) or m.group(2) or ""
        finally:
            r.close()
    except (ImportError, OSError):
        pass
    return ""


def _auto_label(url):
    """Título via oEmbed para YT/DM/Vimeo; nombre del path para el resto."""
    if not url:
        return ""
    try:
        import requests
        # YouTube
        m = _YT_RE.search(url)
        if m:
            r = requests.get(
                "https://www.youtube.com/oembed",
                params={"url": url, "format": "json"},
                timeout=3,
            )
            if r.status_code == 200:
                return r.json().get("title", "")
        # Dailymotion
        m = _DM_RE.search(url)
        if m:
            r = requests.get(
                "https://www.dailymotion.com/services/oembed",
                params={"url": url, "format": "json"},
                timeout=3,
            )
            if r.status_code == 200:
                return r.json().get("title", "")
        # Vimeo
        m = _VIMEO_RE.search(url)
        if m:
            r = requests.get(
                "https://vimeo.com/api/oembed.json",
                params={"url": url},
                timeout=3,
            )
            if r.status_code == 200:
                return r.json().get("title", "")
    except Exception:
        pass
    # Fallback: limpiar path de la URL
    try:
        from urllib.parse import urlparse
        path = urlparse(url).path.rstrip("/").rsplit("/", 1)[-1]
        if "." in path:
            path = path.rsplit(".", 1)[0]
        name = path.replace("-", " ").replace("_", " ")
        return name[:80] if name else ""
    except (ImportError, ValueError, OSError):
        return ""


def _add_to_history(raw_url, label=None, thumb=None):
    history = _load_json(_history_path())
    # Reutilizar thumb y label de la entrada existente
    if not thumb or not label:
        for h in history:
            if h.get("url") == raw_url:
                if not thumb and h.get("thumb"):
                    thumb = h["thumb"]
                if not label and h.get("label") and h["label"] != raw_url:
                    label = h["label"]
                break
    history = [h for h in history if h.get("url") != raw_url]
    if not thumb:
        thumb = _auto_thumb(raw_url)
    if not label or label == raw_url:
        fetched = _auto_label(raw_url)
        label = fetched or raw_url
    entry = {
        "url": raw_url,
        "label": label,
        "date": time.strftime("%d/%m/%Y %H:%M"),
        "timestamp": int(time.time()),
    }
    if thumb:
        entry["thumb"] = thumb
    history.insert(0, entry)
    history = history[:MAX_HISTORY]
    _save_json(_history_path(), history)


def _get_history():
    return _load_json(_history_path())


def _clear_history():
    _save_json(_history_path(), [])


def _remove_from_history(url):
    history = _get_history()
    history = [h for h in history if h.get("url") != url]
    _save_json(_history_path(), history)


def _get_bookmarks():
    return _load_json(_bookmarks_path())


def _add_bookmark(name, url):
    bookmarks = _get_bookmarks()
    if any(b.get("url") == url for b in bookmarks):
        return False
    thumb = _auto_thumb(url)
    entry = {
        "name": name,
        "url": url,
        "date": time.strftime("%d/%m/%Y %H:%M"),
    }
    if thumb:
        entry["thumb"] = thumb
    bookmarks.append(entry)
    bookmarks = bookmarks[:MAX_BOOKMARKS]
    _save_json(_bookmarks_path(), bookmarks)
    return True


def _remove_bookmark(url):
    bookmarks = _get_bookmarks()
    new_bookmarks = [b for b in bookmarks if b.get("url") != url]
    _save_json(_bookmarks_path(), new_bookmarks)
    return len(bookmarks) != len(new_bookmarks)


def _rename_bookmark(url, new_name):
    bookmarks = _get_bookmarks()
    changed = False
    for b in bookmarks:
        if b.get("url") == url:
            b["name"] = new_name
            changed = True
            break
    if changed:
        _save_json(_bookmarks_path(), bookmarks)
    return changed


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


def open_url_dialog():
    h = int(sys.argv[1])
    # Punto verde de lo nuevo (ver ui_utils.punto/visto): lo que se estrenó desde la
    # v2.9.0, la última publicada en GitHub, lo lleva hasta que se abre.
    import ui_utils
    _mp_url = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")
    def _ico_url(name, fallback):
        p = os.path.join(_mp_url, name)
        return p if os.path.isfile(p) else fallback

    li = xbmcgui.ListItem(
        label="[COLOR limegreen][B]Pegar URL de vídeo[/B][/COLOR]"
    )
    li.setArt({"icon": _ico_url("url_pegar.png", "DefaultAddSource.png")})
    li.setInfo("video", {
        "plot": (
            "Reproduce un enlace de vídeo o de una emisión.\n\n"
            "YouTube y Dailymotion: el enlace del vídeo.\n"
            "Torrent y magnet: .torrent o magnet:?\n"
            "AceStream: acestream:// o solo el ID de 40 caracteres.\n"
            "Streams directos: .m3u8, .mp4, .mkv o .mpd.\n"
            "Con cabeceras: URL|User-Agent=xxx&Referer=yyy\n"
            "Otras webs: se intenta sacar el vídeo de la página."
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="url_input"), listitem=li, isFolder=False
    )

    try:
        clipboard_url = xbmcgui.Window(10000).getProperty("espatv.clipboard.url").strip()
    except (AttributeError, RuntimeError):
        clipboard_url = ""
    if clipboard_url:
        url_display = clipboard_url[:70] + "..." if len(clipboard_url) > 70 else clipboard_url
        li = xbmcgui.ListItem(
            label="[COLOR cyan][B]Reproducir URL copiada[/B][/COLOR]"
        )
        li.setArt({"icon": "DefaultAddonsUpdates.png"})
        li.setInfo("video", {
            "plot": (
                "URL en memoria:\n{0}\n\n"
                "Reproduce el enlace detectado en el portapapeles."
            ).format(url_display),
        })
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="url_play_clipboard"),
            listitem=li, isFolder=False
        )

    li = xbmcgui.ListItem(
        label="[COLOR lightsalmon][B]Enviar URL desde móvil/PC[/B][/COLOR]"
    )
    li.setArt({"icon": _ico_url("url_movil.png", "DefaultNetwork.png")})
    li.setInfo("video", {
        "plot": (
            "Abre una página temporal en la red local para pegar el enlace desde el navegador "
            "del móvil o del PC, sin escribirlo con el mando.\n\n"
            "El addon loiolink, en EspaKodi, hace esto y más: mando a distancia, enviar texto y "
            "copiar y pegar."
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="url_remote"), listitem=li, isFolder=False
    )

    li = xbmcgui.ListItem(
        label="[COLOR mediumpurple][B]Escanear web o Telegram[/B][/COLOR]"
    )
    li.setArt({"icon": _ico_url("url_escanear.png", "DefaultAddonsSearch.png")})
    li.setInfo("video", {
        "plot": (
            "Pega la URL de cualquier web o canal público de Telegram y "
            "el addon detectará todos los vídeos y enlaces disponibles.\n\n"
            "Muestra título, duración y tamaño de cada uno.\n\n"
            "En PC usa yt-dlp (más completo).\n"
            "En Android usa análisis HTML."
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="url_scan"), listitem=li, isFolder=False
    )

    li = xbmcgui.ListItem(
        label=ui_utils.punto('url_scan_telegram') + "[COLOR mediumpurple][B]Escanear canal de Telegram[/B][/COLOR]"
    )
    li.setArt({"icon": _ico_url("url_telegram.png", "DefaultAddonsSearch.png")})
    li.setInfo("video", {
        "plot": (
            "Atajo para buscar directamente en un canal público de Telegram.\n\n"
            "Escribe el canal como @canal, t.me/canal o el nombre solo.\n\n"
            "Empieza por las últimas entradas y con 'Cargar más antiguas' "
            "seguir hacia atrás por el canal. Muestra el texto del mensaje "
            "de cada enlace para saber de qué va."
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="url_scan_telegram"), listitem=li, isFolder=False
    )

    li = xbmcgui.ListItem(
        label="[COLOR lightblue][B]Abrir o instalar StreamNinja[/B][/COLOR]"
    )
    li.setArt({"icon": _ico_url("url_streamninja.png", "DefaultAddonVideo.png")})
    li.setInfo("video", {
        "plot": (
            "StreamNinja resuelve los enlaces de AceStream de esta sección.\n\n"
            "Si ya está instalado, lo abre. Si no, te ofrece el instalador "
            "automático o las instrucciones para hacerlo a mano.\n\n"
            "Solo hace falta si los canales de AceStream no reproducen."
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="url_player_ensure_sn"), listitem=li, isFolder=False
    )

    li = xbmcgui.ListItem(label="[COLOR thistle][B]Configuración[/B][/COLOR]")
    li.setArt({"icon": "DefaultAddonService.png"})
    li.setInfo("video", {
        "plot": (
            "Ajustes del receptor de URLs (móvil/PC): modo de conexión, puerto del servidor, "
            "seguridad, confirmación antes de reproducir y opciones del relay de Internet."
        ),
    })
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="url_player_config"), listitem=li, isFolder=True
    )

    if _debrid_active():
        provider = xbmcaddon.Addon().getSetting("debrid_provider") or "AllDebrid"
        li = xbmcgui.ListItem(label="[COLOR gold]Mi nube {0}[/COLOR]".format(provider))
        li.setArt({"icon": "DefaultPlaylist.png"})
        li.setInfo("video", {"plot": (
            "Vídeos que tienes en tu cuenta {0}.\n\n"
            "Reproduce o borra el contenido de tu nube."
        ).format(provider)})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="debrid_library"), listitem=li, isFolder=True
        )

    history = _get_history()
    if history:
        li = xbmcgui.ListItem(
            label="[COLOR cyan]Historial de URLs ({0})[/COLOR]".format(len(history))
        )
        li.setArt({"icon": _ico_url("url_historial.png", "DefaultRecentlyAddedMovies.png")})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="url_history"), listitem=li, isFolder=True
        )

    bookmarks = _get_bookmarks()
    if bookmarks:
        li = xbmcgui.ListItem(
            label="[COLOR khaki]Marcadores ({0})[/COLOR]".format(len(bookmarks))
        )
        li.setArt({"icon": _ico_url("url_marcadores.png", "DefaultSets.png")})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="url_bookmarks"), listitem=li, isFolder=True
        )

    xbmcplugin.endOfDirectory(h)


def _play_resolved_stream(stream_url, headers=None, protocol=""):
    li = xbmcgui.ListItem(path=stream_url)

    clean_path = urllib.parse.urlparse(stream_url).path.lower()

    _GENERIC_HEADERS = {
        "user-agent", "accept", "accept-language", "accept-encoding",
        "sec-fetch-dest", "sec-fetch-mode", "sec-fetch-site",
        "sec-ch-ua", "sec-ch-ua-mobile", "sec-ch-ua-platform",
    }
    meaningful_headers = {}
    if headers:
        meaningful_headers = {
            k: v for k, v in headers.items()
            if k.lower() not in _GENERIC_HEADERS
        }

    header_str = ""
    if meaningful_headers:
        header_str = "&".join(
            "{0}={1}".format(k, urllib.parse.quote(str(v)))
            for k, v in meaningful_headers.items()
        )

    is_mpd = clean_path.endswith(".mpd") or "mpd" in protocol
    is_m3u8 = clean_path.endswith(".m3u8") or "m3u8" in protocol

    if is_mpd:
        li.setProperty("inputstream", "inputstream.adaptive")
        li.setProperty("inputstream.adaptive.manifest_type", "mpd")
        li.setMimeType("application/dash+xml")
        if header_str:
            li.setProperty("inputstream.adaptive.manifest_headers", header_str)
            li.setProperty("inputstream.adaptive.stream_headers", header_str)
    elif is_m3u8:
        li.setMimeType("application/x-mpegURL")
        if header_str:
            li.setProperty("inputstream", "inputstream.adaptive")
            li.setProperty("inputstream.adaptive.manifest_headers", header_str)
            li.setProperty("inputstream.adaptive.stream_headers", header_str)
    elif header_str:
        # Para mp4/otros formatos directos, usar pipe (aun soportado)
        stream_url = "{0}|{1}".format(stream_url, header_str)
        li = xbmcgui.ListItem(path=stream_url)

    li.setProperty("IsPlayable", "true")
    li.setContentLookup(False)
    xbmc.Player().play(stream_url, li)
    

def _debrid_active():
    """True si hay un proveedor Debrid activado y con cuenta vinculada."""
    try:
        if xbmcaddon.Addon().getSetting("debrid_enabled") != "true":
            return False
        return _get_debrid() is not None and _get_debrid().is_authorized()
    except Exception:
        return False


def _get_debrid():
    """Instancia del resolver Debrid. Import defensivo: si el módulo fallara,
    el addon sigue funcionando como si Debrid no existiera."""
    try:
        import debrid_resolver
        return debrid_resolver.get_resolver()
    except Exception as e:
        xbmc.log("[EspaTV] Debrid no disponible: {0}".format(e), xbmc.LOGWARNING)
        return None


def _resolve_and_play(raw_url):
    url_type, value = detect_url_type(raw_url)

    # Resolver Debrid: solo intercepta magnets y páginas/hosters desconocidos.
    # Los tipos que el addon resuelve nativamente (dailymotion, youtube, rtve...)
    # nunca pasan por aquí, para no robarlos a sus resolvers específicos.
    if url_type in ("torrent", "web_page") and _debrid_active():
        provider = xbmcaddon.Addon().getSetting("debrid_provider") or "AllDebrid"
        stream = _debrid_cache_get(provider, value)
        if not stream:
            try:
                stream = _get_debrid().resolve(value)
            except Exception as e:
                xbmc.log("[EspaTV/Debrid] {0}".format(e), xbmc.LOGWARNING)
                stream = None
            if stream:
                _debrid_cache_put(provider, value, stream)
        if stream:
            _play_resolved_stream(stream)
            return

    if url_type == "dailymotion":
        xbmcgui.Dialog().notification(
            "EspaTV", "Dailymotion: " + value,
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        played = False

        # Método 1: yt-dlp (mejor compatibilidad CDN en PC)
        if ytdlp_resolver.is_available():
            dm_url = "https://www.dailymotion.com/video/" + value
            info = ytdlp_resolver.resolve_full(dm_url)
            if info and info.get("url"):
                _play_resolved_stream(
                    info["url"],
                    headers=info.get("headers"),
                    protocol=info.get("protocol", ""),
                )
                played = True

        # Método 2: resolver interno del addon (misma receta que _pv() en default.py:
        # gujal según el nivel y, si no, metadata+master con cookies).
        if not played:
            try:
                import default as _d
                cfg = {}
                try:
                    cfg = _d._load_dm_settings()
                except (OSError, ValueError, RuntimeError):
                    cfg = {}
                result = _d._dm_play(value, dm_level=cfg.get('dm_safe_level', 0),
                                     max_quality=cfg.get('dm_max_quality', 1080))
                if result and result.get('url'):
                    stream_url = result['url']
                    
                    headers_dict = result.get('headers')
                    header_str = ""
                    if headers_dict:
                        header_str = "&".join(
                            "{0}={1}".format(k, urllib.parse.quote(str(v)))
                            for k, v in headers_dict.items()
                        )
                        
                    mime_type = result.get('mime', '')
                    is_hls = 'mpegURL' in mime_type
                    
                    if not is_hls and header_str:
                        stream_url = "{0}|{1}".format(stream_url, header_str)

                    li = xbmcgui.ListItem(path=stream_url)
                    if mime_type:
                        li.setMimeType(mime_type)
                        
                    if is_hls and header_str:
                        li.setProperty("inputstream", "inputstream.adaptive")
                        li.setProperty("inputstream.adaptive.manifest_headers", header_str)
                        li.setProperty("inputstream.adaptive.stream_headers", header_str)
                        
                    li.setContentLookup(False)
                    subs = result.get('subs')
                    if subs and isinstance(subs, list):
                        li.setSubtitles(subs)
                    li.setProperty("IsPlayable", "true")
                    xbmc.Player().play(stream_url, li)
                    played = True
            except Exception as e:
                xbmc.log(
                    "[EspaTV/url_player] _dm_play error: " + str(e),
                    xbmc.LOGWARNING,
                )

        # Método 3: navegador como último recurso
        if not played:
            dm_web = "https://www.dailymotion.com/video/" + value
            is_android = xbmc.getCondVisibility("System.Platform.Android")
            if is_android:
                opts = ["Abrir en el navegador", "Abrir en app externa"]
                sel = xbmcgui.Dialog().select("No se pudo resolver", opts)
                if sel < 0: return
                if sel == 0:
                    xbmc.executebuiltin(
                        'StartAndroidActivity("",'
                        '"android.intent.action.VIEW","",'
                        '"{0}")'.format(dm_web))
                else:
                    xbmc.executebuiltin(
                        'StartAndroidActivity("",'
                        '"android.intent.action.VIEW","",'
                        '"{0}")'.format(dm_web))
            else:
                if xbmcgui.Dialog().yesno(
                    "EspaTV",
                    "No se pudo resolver el vídeo de Dailymotion.\n\n"
                    "¿Abrir en el navegador?"):
                    import webbrowser
                    webbrowser.open(dm_web)

    elif url_type == "youtube":
        yt_web = "https://www.youtube.com/watch?v=" + value
        is_android = xbmc.getCondVisibility("System.Platform.Android")

        # Construir menú de opciones estilo Felicidad
        opts = []
        actions = []

        # Addon YouTube (no pide API key para reproducir)
        if xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.youtube)"):
            opts.append("Reproducir aquí")
            actions.append("addon")
        # yt-dlp (PC)
        if ytdlp_resolver.is_available():
            opts.append("Reproducir con yt-dlp")
            actions.append("ytdlp")
        # App YouTube nativa (solo Android)
        if is_android:
            opts.append("Abrir en la app YouTube")
            actions.append("yt_app")
        # Navegador (siempre)
        opts.append("Abrir en el navegador")
        actions.append("browser")

        if len(opts) == 1:
            sel = 0
        else:
            sel = xbmcgui.Dialog().select("YouTube", opts)
        if sel < 0:
            return

        act = actions[sel]
        if act == "ytdlp":
            xbmcgui.Dialog().notification(
                "EspaTV", "Resolviendo con yt-dlp...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            info = ytdlp_resolver.resolve_full(yt_web)
            if info and info.get("url"):
                _play_resolved_stream(
                    info["url"],
                    headers=info.get("headers"),
                    protocol=info.get("protocol", ""),
                )
            else:
                xbmcgui.Dialog().ok("EspaTV", "yt-dlp no pudo resolver el vídeo.")
        elif act == "addon":
            xbmc.executebuiltin(
                'PlayMedia("plugin://plugin.video.youtube/play/?video_id={0}")'.format(value))
        elif act == "yt_app":
            xbmc.executebuiltin(
                'StartAndroidActivity(com.google.android.youtube,'
                '"android.intent.action.VIEW","",'
                '"{0}")'.format(yt_web))
        elif act == "browser":
            import webbrowser
            webbrowser.open(yt_web)


    elif url_type == "direct_stream":
        url, headers = parse_url_with_headers(raw_url)
        kodi_url = build_kodi_url(url, headers)
        li = xbmcgui.ListItem(path=kodi_url)
        if ".mpd" in url.lower():
            li.setProperty("inputstream", "inputstream.adaptive")
            li.setProperty("inputstream.adaptive.manifest_type", "mpd")
        elif ".m3u8" in url.lower():
            li.setMimeType("application/x-mpegURL")
        if headers:
            header_str = "&".join("{0}={1}".format(k, v) for k, v in headers.items())
            li.setProperty("inputstream.adaptive.stream_headers", header_str)
        xbmc.Player().play(kodi_url, li)

    elif url_type == "torrent":
        # AddonIsEnabled y no HasAddon: desde Kodi 19 HasAddon es cierto con el addon
        # desactivado, y uno desactivado se quedaba el enlace sin abrir nada.
        if xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.elementum)"):
            xbmcgui.Dialog().notification(
                "EspaTV", "Abriendo torrent en Elementum...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            elem_url = (
                "plugin://plugin.video.elementum/play?"
                + urllib.parse.urlencode({"uri": value})
            )
            xbmc.executebuiltin('PlayMedia("{0}")'.format(elem_url))
        else:
            # Sin Elementum: EKHorus abre magnets y .torrent con el motor AceStream (del
            # magnet saca él el infohash). Se ofrece instalarlo o activarlo.
            accion = "Activar" if xbmc.getCondVisibility(
                "System.HasAddon(script.module.horus)") else "Instalar"
            if not xbmcgui.Dialog().yesno(
                    "EspaTV",
                    "Para reproducir torrents necesitas Elementum, o EKHorus, que los abre "
                    "con el motor AceStream.\n\n¿{0} EKHorus ahora?".format(accion),
                    nolabel="Cerrar", yeslabel="{0} EKHorus".format(accion)):
                return
            import espakodi_installer
            if not espakodi_installer.instalar_si_falta("script.module.horus"):
                return
            xbmcgui.Dialog().notification(
                "EspaTV", "Abriendo torrent en EKHorus...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            ek_url = "plugin://script.module.horus/?" + urllib.parse.urlencode(
                {"action": "play", "url": value})
            xbmc.executebuiltin('PlayMedia("{0}")'.format(ek_url))
            return

    elif url_type == "acestream":
        ace_hash = value.replace("acestream://", "").lower()

        # StreamNinja primero (arreglo 6). AddonIsEnabled: un addon desactivado no abre nada.
        if xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.streamninja)"):
            xbmcgui.Dialog().notification(
                "EspaTV", "Abriendo AceStream con StreamNinja...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            # Con RunPlugin: StreamNinja reproduce él y sigue en marcha mientras se ve, así que
            # con PlayMedia Kodi se quedaría esperando la respuesta y dejaría la rueda encima.
            target = (
                "plugin://plugin.video.streamninja/?"
                + urllib.parse.urlencode({"action": "acestream", "id": ace_hash})
            )
            xbmc.executebuiltin('RunPlugin("{0}")'.format(target))
        elif xbmc.getCondVisibility("System.AddonIsEnabled(script.module.horus)"):
            xbmcgui.Dialog().notification(
                "EspaTV", "Abriendo AceStream con EKHorus...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            target = (
                "plugin://script.module.horus/?"
                + urllib.parse.urlencode({"action": "play", "id": ace_hash})
            )
            xbmc.executebuiltin('PlayMedia("{0}")'.format(target))
        elif not _ace_engine_alive():
            # Sin player y sin motor escuchando: avisamos en vez de colgar a Kodi 30s en el timeout del curl.
            xbmcgui.Dialog().ok(
                "AceStream",
                "No se detectó el motor AceStream en este equipo "
                "(127.0.0.1:6878).\n\n"
                "Arranca el motor AceStream, o instala EKHorus "
                "(script.module.horus) o StreamNinja.",
            )
        else:
            target = "http://127.0.0.1:6878/ace/getstream?id={0}".format(ace_hash)
            li = xbmcgui.ListItem(path=target)
            li.setContentLookup(False)  # stream MPEG-TS directo: evita el probe HEAD de Kodi
            xbmc.Player().play(target, li)

    elif url_type == "rtve":
        xbmcgui.Dialog().notification(
            "EspaTV", "Reproduciendo vídeo...",
            xbmcgui.NOTIFICATION_INFO, 2000,
        )
        try:
            import rtve_alacarta
            stream_url = "https://ztnr.rtve.es/ztnr/{0}.mpd".format(value)
            # Token Widevine opcional; si falla, el MPD puede reproducirse igualmente en abierto
            license_url = ""
            try:
                token_data = rtve_alacarta._fetch_json(
                    "{0}/token/{1}".format(rtve_alacarta._API_BASE, value))
                license_url = token_data.get("widevineURL", "")
            except (OSError, ValueError, AttributeError, RuntimeError):
                pass

            headers = {
                "User-Agent": rtve_alacarta._HEADERS["User-Agent"],
                "Referer": "https://www.rtve.es/",
                "Origin": "https://www.rtve.es",
            }
            headers_string = "&".join(
                ["{0}={1}".format(k, urllib.parse.quote(v)) for k, v in headers.items()])

            li = xbmcgui.ListItem(path=stream_url)
            li.setProperty("inputstream", "inputstream.adaptive")
            li.setProperty("inputstream.adaptive.manifest_type", "mpd")
            li.setProperty("inputstream.adaptive.manifest_headers", headers_string)
            li.setProperty("inputstream.adaptive.stream_headers", headers_string)
            if license_url:
                li.setProperty("inputstream.adaptive.license_type",
                               "com.widevine.alpha")
                li.setProperty("inputstream.adaptive.license_key", license_url)
            li.setMimeType("application/dash+xml")
            li.setContentLookup(False)
            xbmc.Player().play(stream_url, li)
        except (ImportError, OSError, ValueError, AttributeError, RuntimeError) as e:
            xbmc.log(
                "[EspaTV/url_player] RTVE error: " + str(e),
                xbmc.LOGWARNING,
            )
            xbmcgui.Dialog().ok(
                "EspaTV",
                "Error al reproducir:\n{0}".format(str(e)),
            )

    elif url_type == "atresplayer":
        if ytdlp_resolver.is_available():
            xbmcgui.Dialog().notification(
                "EspaTV", "Resolviendo con yt-dlp...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            info = ytdlp_resolver.resolve_full(value)
            if info and info.get("url"):
                _play_resolved_stream(
                    info["url"],
                    headers=info.get("headers"),
                    protocol=info.get("protocol", ""),
                )
                return

        # Fallback: navegador/app
        is_android = xbmc.getCondVisibility("System.Platform.Android")
        if is_android:
            opts = ["Abrir en el navegador", "Abrir en app externa"]
            sel = xbmcgui.Dialog().select(
                "No se pudo reproducir (puede requerir login)", opts)
            if sel < 0: return
            if sel == 1:
                xbmc.executebuiltin(
                    'StartAndroidActivity("",'
                    '"android.intent.action.VIEW","",'
                    '"{0}")'.format(value))
            else:
                import webbrowser
                webbrowser.open(value)
        else:
            msg = ("No se pudo reproducir este contenido.\n\n"
                   "Es posible que requiera login o sea premium.\n\n"
                   "¿Abrir en el navegador?")
            if not ytdlp_resolver.is_available():
                msg = ("Se necesita yt-dlp para este contenido.\n\n"
                       "Instala con: pip install yt-dlp\n\n"
                       "¿Abrir en el navegador?")
            if xbmcgui.Dialog().yesno("EspaTV", msg):
                import webbrowser
                webbrowser.open(value)

    elif url_type == "web_page":
        # yt-dlp (soporta cientos de webs de forma nativa)
        if ytdlp_resolver.is_available():
            xbmcgui.Dialog().notification(
                "EspaTV", "Resolviendo con yt-dlp...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            info = ytdlp_resolver.resolve_full(value)
            if info and info.get("url"):
                _play_resolved_stream(
                    info["url"],
                    headers=info.get("headers"),
                    protocol=info.get("protocol", ""),
                )
                return

        # Fallback a SendToKodi
        has_stk = xbmc.getCondVisibility(
            "System.AddonIsEnabled(plugin.video.sendtokodi)"
        )
        if has_stk:
            xbmcgui.Dialog().notification(
                "EspaTV", "Resolviendo con SendToKodi...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            stk_url = (
                "plugin://plugin.video.sendtokodi/?"
                + urllib.parse.urlencode({"url": value})
            )
            xbmc.executebuiltin('PlayMedia("{0}")'.format(stk_url))
            return

        # YouTube addon (último recurso)
        has_yt = xbmc.getCondVisibility(
            "System.AddonIsEnabled(plugin.video.youtube)"
        )
        if has_yt:
            xbmcgui.Dialog().notification(
                "EspaTV", "Intentando resolver...",
                xbmcgui.NOTIFICATION_INFO, 2000,
            )
            yt_url = (
                "plugin://plugin.video.youtube/uri2addon/?uri="
                + urllib.parse.quote(value)
            )
            xbmc.executebuiltin('PlayMedia("{0}")'.format(yt_url))
        else:
            # Abrir en navegador / app nativa
            is_android = xbmc.getCondVisibility("System.Platform.Android")
            if is_android:
                opts = ["Abrir en el navegador", "Abrir en app externa"]
                sel = xbmcgui.Dialog().select("No se puede resolver aquí", opts)
                if sel < 0:
                    return
                if sel == 1:
                    xbmc.executebuiltin(
                        'StartAndroidActivity("",'
                        '"android.intent.action.VIEW","",'
                        '"{0}")'.format(value))
                else:
                    import webbrowser
                    webbrowser.open(value)
            else:
                if xbmcgui.Dialog().yesno(
                    "EspaTV",
                    "No se pudo resolver esta URL.\n\n"
                    "¿Abrir en el navegador?"):
                    import webbrowser
                    webbrowser.open(value)



def play_clipboard():
    try:
        raw = xbmcgui.Window(10000).getProperty("espatv.clipboard.url").strip()
    except (AttributeError, RuntimeError):
        raw = ""

    if not raw:
        xbmcgui.Dialog().notification(
            "EspaTV", "No hay URL copiada en memoria",
            xbmcgui.NOTIFICATION_WARNING, 2000
        )
        return

    _add_to_history(raw)
    _resolve_and_play(raw)


def _get_download_dest(title, ext=".mp4"):
    """Pide carpeta destino y devuelve la ruta final, '' si el usuario cancela."""
    import default
    import download_manager
    cfg = default._load_dm_settings()
    dest_dir = download_manager.carpeta_destino(cfg.get("download_path", ""))
    if not dest_dir:
        return ""

    safe_title = "".join(c for c in title if c.isalnum() or c in " -_").strip()
    if not safe_title:
        safe_title = "espatv_download_{0}".format(int(time.time()))
    if len(safe_title) > 120:
        safe_title = safe_title[:120].rstrip()

    return os.path.join(dest_dir, "{0}{1}".format(safe_title, ext))


def _motivo_sin_ruta(url, exc):
    """(servidor, motivo) de un fallo de descarga, sin la ruta del enlace.

    Un enlace de debrid sirve para descargar sin cuenta y requests la repite en sus errores; el
    log de Kodi se comparte, así que del enlace solo queda el servidor."""
    partes = urllib.parse.urlsplit(url)
    motivo = str(exc)
    for secreto in (url, partes.path + ("?{0}".format(partes.query) if partes.query else ""),
                    partes.path):
        if len(secreto) > 1:
            motivo = motivo.replace(secreto, "/...")
    # requests la escribe tras "url: ", a veces recodificada, y entonces no coincide.
    motivo = re.sub(r'(url: )\S+', r'\1/...', motivo)
    return partes.netloc, motivo


def _download_direct_url(url, dest, title, headers=None):
    import requests
    dp = xbmcgui.DialogProgress()
    dp.create("Descargando", "Conectando: {0}".format(title))
    tmp = dest + ".tmp"
    try:
        req_headers = headers or {
            "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                          "AppleWebKit/537.36 (KHTML, like Gecko) "
                          "Chrome/120.0.0.0 Safari/537.36",
        }
        r = requests.get(url, headers=req_headers, stream=True, timeout=30)
        if r.status_code >= 400:
            raise RuntimeError(
                "El servidor respondio con codigo {0}".format(r.status_code))
        total = int(r.headers.get("content-length", 0))
        done = 0
        with open(tmp, "wb") as f:
            for chunk in r.iter_content(chunk_size=256 * 1024):
                if dp.iscanceled():
                    break
                f.write(chunk)
                done += len(chunk)
                if total > 0:
                    pct = int(done * 100 / total)
                    mb_done = done / (1024 * 1024)
                    mb_total = total / (1024 * 1024)
                    dp.update(pct, "{0:.1f} MB / {1:.1f} MB".format(
                        mb_done, mb_total))

        cancelled = dp.iscanceled()
        dp.close()
        if not cancelled:
            os.replace(tmp, dest)
            xbmcgui.Dialog().ok(
                "EspaTV", "Descarga completada:\n{0}".format(dest))
        elif os.path.exists(tmp):
            os.remove(tmp)
    except (OSError, RuntimeError) as exc:
        try:
            dp.close()
        except RuntimeError:
            pass
        try:
            if os.path.exists(tmp):
                os.remove(tmp)
        except OSError:
            pass
        # La ruta de un enlace de debrid sirve para descargar sin cuenta, y requests la repite en
        # sus errores; el log de Kodi se comparte, así que solo queda el servidor y el motivo.
        netloc, motivo = _motivo_sin_ruta(url, exc)
        xbmc.log("[EspaTV/url_player] Descarga directa desde {0}: {1}".format(
            netloc, motivo), xbmc.LOGWARNING)
        xbmcgui.Dialog().ok("EspaTV", "No se ha podido descargar:\n{0}\n\n{1}".format(
            title, motivo[:200]))


def _download_hls_stream(playlist_url, dest, title, headers=None):
    """Concatena los .ts de un m3u8 a disco. Acepta headers arbitrarios."""
    import requests
    dp = xbmcgui.DialogProgress()
    dp.create("Descargando HLS", "Obteniendo segmentos...")
    req_headers = headers or {
        "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
                      "AppleWebKit/537.36 (KHTML, like Gecko) "
                      "Chrome/120.0.0.0 Safari/537.36",
    }
    clean_url = playlist_url.split("|")[0] if "|" in playlist_url else playlist_url
    tmp = dest + ".tmp"
    try:
        if "?" in clean_url:
            params = "?" + clean_url.split("?")[1]
        else:
            params = ""

        m3u8_text = requests.get(
            clean_url, headers=req_headers, timeout=15).text
        segments = [
            ln for ln in m3u8_text.splitlines()
            if ln and not ln.startswith("#")
        ]
        if not segments:
            dp.close()
            xbmcgui.Dialog().ok(
                "EspaTV", "La lista de reproduccion esta vacia.")
            return

        with open(tmp, "wb") as f_out:
            for idx, seg_name in enumerate(segments):
                if dp.iscanceled():
                    break

                if seg_name.startswith("http"):
                    seg_url = seg_name
                else:
                    import urllib.parse
                    # urljoin resuelve correctamente paths relativos o absolutos (con /)
                    seg_url = urllib.parse.urljoin(clean_url, seg_name)
                    if params and "?" not in seg_url:
                        seg_url += params

                success = False
                for _attempt in range(3):
                    try:
                        seg_data = requests.get(
                            seg_url, headers=req_headers, timeout=12).content
                        f_out.write(seg_data)
                        success = True
                        break
                    except (requests.RequestException, OSError):
                        continue

                if not success:
                    raise RuntimeError(
                        "Fallo en segmento {0}/{1}".format(idx + 1, len(segments)))

                pct = int((idx + 1) * 100 / len(segments))
                dp.update(pct, "Segmento {0}/{1} - {2}".format(
                    idx + 1, len(segments), title))

        cancelled = dp.iscanceled()
        dp.close()
        if not cancelled:
            os.replace(tmp, dest)
            xbmcgui.Dialog().ok(
                "EspaTV", "Descarga HLS completada:\n{0}".format(dest))
        elif os.path.exists(tmp):
            os.remove(tmp)
    except (OSError, RuntimeError, requests.RequestException) as exc:
        try:
            dp.close()
        except RuntimeError:
            pass
        if os.path.exists(tmp):
            os.remove(tmp)
        # Sin la ruta, como _download_direct_url: en un m3u8 de debrid el token va en ella.
        netloc, motivo = _motivo_sin_ruta(playlist_url, exc)
        xbmc.log(f"[EspaTV/url_player] Error HLS download desde {netloc}: {motivo}",
                 xbmc.LOGWARNING)
        xbmcgui.Dialog().ok(
            "EspaTV", "Error en descarga HLS:\n{0}".format(motivo[:200]))


def _download_via_ytdlp(url, dest, title):
    """Descarga vía yt-dlp en un subproceso (Python externo, no el de Kodi). Sólo escritorio."""
    # download_manager y no default: _find_system_python, _get_ytdlp_pkg_path y
    # _ensure_ytdlp viven en download_manager. Llamarlas a traves de default daba
    # «module 'default' has no attribute ...» y la descarga fallaba siempre.
    import subprocess

    import download_manager

    if xbmc.getCondVisibility("System.Platform.Android"):
        xbmcgui.Dialog().ok(
            "EspaTV",
            "Las descargas con yt-dlp no estan\n"
            "disponibles en dispositivos Android.\n\n"
            "Usa un PC con Python 3.10+ instalado.")
        return

    dp = xbmcgui.DialogProgress()
    dp.create("Descarga con yt-dlp", "Preparando...")

    try:
        dp.update(2, "Buscando Python del sistema...")
        py_cmd = download_manager._find_system_python()
        if not py_cmd:
            dp.close()
            xbmcgui.Dialog().ok(
                "EspaTV",
                "Se necesita Python 3.10+ instalado.\n\n"
                "Descargalo de python.org e instalalo\n"
                "marcando 'Add to PATH'.\n\n"
                "Despues reinicia Kodi.")
            return

        pkg_path = download_manager._get_ytdlp_pkg_path()
        ytdlp_dir = os.path.join(pkg_path, "yt_dlp")
        if not os.path.isdir(ytdlp_dir):
            dp.update(5, "Descargando yt-dlp (~3 MB)...")
            if not download_manager._ensure_ytdlp():
                dp.close()
                xbmcgui.Dialog().ok(
                    "EspaTV",
                    "Error al descargar yt-dlp.\n"
                    "Comprueba tu conexion a internet.")
                return

        if not dest.endswith(".mp4"):
            dest = os.path.splitext(dest)[0] + ".mp4"

        import json as _json
        progress_file = os.path.join(pkg_path, "_dl_progress.json")
        if os.path.exists(progress_file):
            os.remove(progress_file)

        helper_path = os.path.join(pkg_path, "_dl_helper.py")
        script = (
            "import sys, os, json\n"
            "sys.path.insert(0, {pkg!r})\n"
            "import yt_dlp\n"
            "\n"
            "progress_file = {pf!r}\n"
            "\n"
            "def hook(d):\n"
            "    info = {{\"status\": d.get(\"status\", \"\"), "
            "\"percent\": 0, \"text\": \"\"}}\n"
            "    if d[\"status\"] == \"downloading\":\n"
            "        total = d.get(\"total_bytes\") or "
            "d.get(\"total_bytes_estimate\") or 0\n"
            "        done = d.get(\"downloaded_bytes\", 0)\n"
            "        speed = d.get(\"speed\") or 0\n"
            "        if total > 0:\n"
            "            info[\"percent\"] = int(done * 100 / total)\n"
            "            mb_d = done / (1024*1024)\n"
            "            mb_t = total / (1024*1024)\n"
            "            sp = speed / (1024*1024) if speed else 0\n"
            "            info[\"text\"] = "
            "f\"{{mb_d:.1f}}MB / {{mb_t:.1f}}MB ({{sp:.1f}} MB/s)\"\n"
            "        elif done > 0:\n"
            "            info[\"percent\"] = 50\n"
            "            info[\"text\"] = "
            "f\"Descargando: {{done/(1024*1024):.1f}}MB\"\n"
            "    elif d[\"status\"] == \"finished\":\n"
            "        info[\"percent\"] = 95\n"
            "        info[\"text\"] = \"Finalizando...\"\n"
            "    with open(progress_file, \"w\") as f:\n"
            "        json.dump(info, f)\n"
            "\n"
            "opts = {{\n"
            "    \"format\": \"best[ext=mp4]/best\",\n"
            "    \"outtmpl\": {dest!r},\n"
            "    \"quiet\": True,\n"
            "    \"no_warnings\": True,\n"
            "    \"progress_hooks\": [hook],\n"
            "    \"noprogress\": True,\n"
            "}}\n"
            "try:\n"
            "    ydl = yt_dlp.YoutubeDL(opts)\n"
            "    ydl.download([{url!r}])\n"
            "    with open(progress_file, \"w\") as f:\n"
            "        json.dump({{\"status\": \"done\", \"percent\": 100, "
            "\"text\": \"Completado\"}}, f)\n"
            "except Exception as e:\n"
            "    with open(progress_file, \"w\") as f:\n"
            "        json.dump({{\"status\": \"error\", \"percent\": 0, "
            "\"text\": str(e)[:300]}}, f)\n"
        ).format(pkg=pkg_path, pf=progress_file, dest=dest, url=url)

        with open(helper_path, "w", encoding="utf-8") as f:
            f.write(script)

        dp.update(10, "Iniciando descarga...")
        no_win = getattr(subprocess, "CREATE_NO_WINDOW", 0)
        proc = subprocess.Popen(
            [py_cmd, helper_path],
            stdout=subprocess.PIPE, stderr=subprocess.PIPE,
            creationflags=no_win,
        )

        cancelled = False
        while proc.poll() is None:
            if dp.iscanceled():
                cancelled = True
                proc.kill()
                break
            if os.path.exists(progress_file):
                try:
                    with open(progress_file, "r") as f:
                        info = _json.loads(f.read())
                    dp.update(
                        info.get("percent", 0),
                        info.get("text", "Descargando..."))
                except Exception:
                    pass
            time.sleep(0.5)

        dp.close()

        for tmp in [helper_path, progress_file]:
            if os.path.exists(tmp):
                try:
                    os.remove(tmp)
                except OSError:
                    pass

        if cancelled:
            for ext in ["", ".part"]:
                p = dest + ext
                if os.path.exists(p):
                    try:
                        os.remove(p)
                    except OSError:
                        pass
            return

        if proc.returncode == 0 and os.path.exists(dest):
            xbmcgui.Dialog().ok(
                "EspaTV", "Descarga completada:\n{0}".format(dest))
        else:
            stderr = ""
            try:
                stderr = proc.stderr.read().decode(
                    "utf-8", errors="replace")[:200]
            except Exception:
                pass
            xbmcgui.Dialog().ok(
                "EspaTV",
                "Error en la descarga:\n{0}".format(stderr or "Desconocido"))

    except Exception as exc:
        try:
            dp.close()
        except Exception:
            pass
        xbmc.log("[EspaTV/url_player] Error yt-dlp download: {0}".format(
            exc), xbmc.LOGWARNING)
        xbmcgui.Dialog().ok(
            "EspaTV", "Error al preparar la descarga:\n{0}".format(
                str(exc)[:200]))


def _resolve_and_download(raw_url):
    url_type, value = detect_url_type(raw_url)

    if url_type == "dailymotion":
        import default
        label = _auto_label(raw_url) or value
        default._download_video(value, label)

    elif url_type in ("youtube", "web_page"):
        if not ytdlp_resolver.is_available():
            xbmcgui.Dialog().ok(
                "EspaTV",
                "La descarga de este contenido requiere yt-dlp.\n\n"
                "Solo esta disponible en PC (Windows/Linux/Mac)\n"
                "con Python 3.10+ instalado.")
            return
        label = _auto_label(raw_url) or "video"
        dest = _get_download_dest(label)
        if not dest:
            return
        _download_via_ytdlp(raw_url, dest, label)

    elif url_type == "direct_stream":
        url, headers = parse_url_with_headers(raw_url)
        label = _auto_label(raw_url) or "stream"

        clean_path = urllib.parse.urlparse(url).path.lower()
        if clean_path.endswith(".m3u8"):
            dest = _get_download_dest(label, ext=".ts")
            if not dest:
                return
            if not xbmcgui.Dialog().yesno(
                    "Descarga HLS",
                    "Este stream se descargara por segmentos.\n"
                    "El proceso puede ser lento. Continuar?"):
                return
            _download_hls_stream(url, dest, label, headers=headers or None)
        else:
            ext = os.path.splitext(clean_path)[1] or ".mp4"
            dest = _get_download_dest(label, ext=ext)
            if not dest:
                return
            h = headers if headers else None
            _download_direct_url(url, dest, label, headers=h)

    elif url_type == "rtve":
        if not ytdlp_resolver.is_available():
            xbmcgui.Dialog().ok(
                "EspaTV",
                "La descarga de RTVE requiere yt-dlp.\n\n"
                "Solo esta disponible en PC.")
            return
        label = _auto_label(raw_url) or "rtve"
        dest = _get_download_dest(label)
        if not dest:
            return
        _download_via_ytdlp(raw_url, dest, label)

    else:
        xbmcgui.Dialog().ok(
            "EspaTV",
            "Este tipo de contenido no se puede descargar.\n\n"
            "Tipos descargables: Dailymotion, YouTube,\n"
            "streams directos (.m3u8, .mp4) y paginas web.")


def url_input():
    """Teclado para pegar una URL y reproducirla."""
    kb = xbmc.Keyboard("", "Pegar URL (Dailymotion, YouTube, stream...)")
    kb.doModal()
    if not kb.isConfirmed():
        return

    raw = kb.getText().strip()
    if not raw:
        return

    # Hash desnudo de AceStream (40 hex): normalizar a acestream:// (igual que el mando web)
    if re.fullmatch(r'[0-9a-fA-F]{40}', raw):
        raw = 'acestream://' + raw.lower()

    valid_schemes = ("http://", "https://", "rtmp://", "rtsp://",
                     "magnet:?", "acestream://")
    if not raw.startswith(valid_schemes):
        xbmcgui.Dialog().ok(
            "EspaTV",
            "La URL no parece válida.\n\n"
            "Esquemas soportados: http, https, rtmp, rtsp, magnet, acestream",
        )
        return

    _add_to_history(raw)

    url_type, _ = detect_url_type(raw)
    type_labels = {
        "dailymotion": "Dailymotion",
        "youtube": "YouTube",
        "rtve": "Vídeo web",
        "atresplayer": "Vídeo web",
        "torrent": "Torrent",
        "acestream": "AceStream",
        "direct_stream": "Stream directo",
        "web_page": "Página web",
    }
    detected = type_labels.get(url_type, "Desconocido")
    url_display = raw[:50] + "..." if len(raw) > 50 else raw

    opts = [
        "Reproducir ahora ({0})".format(detected),
        "Guardar como marcador y reproducir",
        "Solo guardar como marcador",
    ]
    _DOWNLOADABLE = {"dailymotion", "youtube", "direct_stream", "web_page", "rtve"}
    if url_type in _DOWNLOADABLE:
        opts.append("Descargar ({0})".format(detected))

    sel = xbmcgui.Dialog().select(url_display, opts)

    if sel == 0:
        _resolve_and_play(raw)
    elif sel == 1:
        name_kb = xbmc.Keyboard("", "Nombre para el marcador")
        name_kb.doModal()
        if name_kb.isConfirmed() and name_kb.getText().strip():
            _add_bookmark(name_kb.getText().strip(), raw)
        _resolve_and_play(raw)
    elif sel == 2:
        name_kb = xbmc.Keyboard("", "Nombre para el marcador")
        name_kb.doModal()
        if name_kb.isConfirmed() and name_kb.getText().strip():
            if _add_bookmark(name_kb.getText().strip(), raw):
                xbmcgui.Dialog().notification(
                    "EspaTV", "Marcador guardado",
                    xbmcgui.NOTIFICATION_INFO,
                )
                xbmc.executebuiltin("Container.Refresh")
            else:
                xbmcgui.Dialog().notification(
                    "EspaTV", "Ya existe este marcador",
                    xbmcgui.NOTIFICATION_INFO,
                )
    elif sel == 3:
        _resolve_and_download(raw)


def url_history_menu():
    """Historial de URLs reproducidas."""
    h = int(sys.argv[1])
    history = _get_history()
    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _ico(name, fallback):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    if not history:
        li = xbmcgui.ListItem(
            label="[COLOR gray]No hay URLs en el historial[/COLOR]"
        )
        li.setArt({"icon": _ico('info.png', "DefaultIconInfo.png")})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    li = xbmcgui.ListItem(
        label="[COLOR red][B]Borrar todo el historial de URLs[/B][/COLOR]"
    )
    li.setArt({"icon": _ico('adv_borrar.png', "DefaultIconError.png")})
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="url_history_clear"), listitem=li, isFolder=False
    )

    for entry in history:
        raw_url = entry.get("url", "")
        label = entry.get("label", raw_url)
        date = entry.get("date", "")

        display = label[:80] + "..." if len(label) > 80 else label
        thumb = entry.get("thumb", "")
        li = xbmcgui.ListItem(label=display)
        li.setArt({
            "icon": thumb or _ico('url_historial.png', "DefaultVideo.png"),
            "thumb": thumb or "",
        })
        li.setInfo("video", {"plot": "URL: {0}\n\nFecha: {1}".format(raw_url, date)})

        cm = [
            (
                "Guardar como marcador",
                "RunPlugin({0})".format(
                    _u(action="url_bookmark_save_from_history", url=raw_url)
                ),
            ),
            (
                "Eliminar del historial",
                "RunPlugin({0})".format(
                    _u(action="url_history_remove", url=raw_url)
                ),
            ),
        ]
        li.addContextMenuItems(cm)

        play_url = _u(action="url_play", url=raw_url)
        xbmcplugin.addDirectoryItem(
            handle=h, url=play_url, listitem=li, isFolder=False
        )

    xbmcplugin.endOfDirectory(h)


def url_bookmarks_menu():
    """Marcadores de URLs guardados."""
    h = int(sys.argv[1])
    bookmarks = _get_bookmarks()
    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _ico(name, fallback):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    if not bookmarks:
        li = xbmcgui.ListItem(
            label="[COLOR gray]No hay marcadores guardados[/COLOR]"
        )
        li.setArt({"icon": _ico('info.png', "DefaultIconInfo.png")})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for bm in bookmarks:
        url = bm.get("url", "")
        name = bm.get("name", url)
        date = bm.get("date", "")

        li = xbmcgui.ListItem(label=name)
        thumb = bm.get("thumb", "")
        li.setArt({
            "icon": thumb or _ico('url_marcadores.png', "DefaultVideo.png"),
            "thumb": thumb or "",
        })
        li.setInfo("video", {"plot": "URL: {0}\n\nGuardado: {1}".format(url, date)})

        cm = [
            (
                "Renombrar",
                "RunPlugin({0})".format(_u(action="url_bookmark_rename", url=url)),
            ),
            (
                "Eliminar marcador",
                "RunPlugin({0})".format(_u(action="url_bookmark_delete", url=url)),
            ),
        ]
        li.addContextMenuItems(cm)

        play_url = _u(action="url_play", url=url)
        xbmcplugin.addDirectoryItem(
            handle=h, url=play_url, listitem=li, isFolder=False
        )

    xbmcplugin.endOfDirectory(h)


def bookmark_save_from_history(url):
    if not url:
        return
    kb = xbmc.Keyboard("", "Nombre para el marcador")
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        if _add_bookmark(kb.getText().strip(), url):
            xbmcgui.Dialog().notification(
                "EspaTV", "Marcador guardado", xbmcgui.NOTIFICATION_INFO
            )
            xbmc.executebuiltin("Container.Refresh")
        else:
            xbmcgui.Dialog().notification(
                "EspaTV", "Ya existe este marcador", xbmcgui.NOTIFICATION_INFO
            )


def bookmark_rename(url):
    if not url:
        return
    bookmarks = _get_bookmarks()
    current_name = ""
    for b in bookmarks:
        if b.get("url") == url:
            current_name = b.get("name", "")
            break

    kb = xbmc.Keyboard(current_name, "Nuevo nombre")
    kb.doModal()
    if kb.isConfirmed() and kb.getText().strip():
        if _rename_bookmark(url, kb.getText().strip()):
            xbmc.executebuiltin("Container.Refresh")


def bookmark_delete(url):
    if not url:
        return
    if _remove_bookmark(url):
        xbmcgui.Dialog().notification(
            "EspaTV", "Marcador eliminado", xbmcgui.NOTIFICATION_INFO
        )
        xbmc.executebuiltin("Container.Refresh")


def history_remove(url):
    if not url:
        return
    _remove_from_history(url)
    xbmc.executebuiltin("Container.Refresh")


def history_clear():
    if xbmcgui.Dialog().yesno("EspaTV", "¿Borrar todo el historial de URLs?"):
        _clear_history()
        xbmc.executebuiltin("Container.Refresh")


def _clip_via_cmd(cmd):
    import subprocess
    try:
        out = subprocess.run(cmd, capture_output=True, encoding='utf-8', errors='replace', timeout=2)
        return out.stdout.strip() if out.returncode == 0 else ""
    except (OSError, ValueError):
        return ""


def _get_system_clipboard_text():
    """Lee el portapapeles del sistema operativo, o '' si no se puede (otra plataforma, sin
    xclip/xsel, portapapeles bloqueado). En ese caso el botón que lo usa no aparece, sin error."""
    if sys.platform.startswith('win'):
        try:
            import ctypes
            import ctypes.wintypes
            CF_UNICODETEXT = 13
            user32 = ctypes.windll.user32
            kernel32 = ctypes.windll.kernel32
            user32.GetClipboardData.restype = ctypes.c_void_p
            user32.GetClipboardData.argtypes = [ctypes.wintypes.UINT]
            kernel32.GlobalLock.restype = ctypes.c_void_p
            kernel32.GlobalLock.argtypes = [ctypes.c_void_p]
            kernel32.GlobalUnlock.argtypes = [ctypes.c_void_p]
            if not user32.OpenClipboard(None):
                return ""
            try:
                handle = user32.GetClipboardData(CF_UNICODETEXT)
                if not handle:
                    return ""
                ptr = kernel32.GlobalLock(handle)
                if not ptr:
                    return ""
                try:
                    return ctypes.wstring_at(ptr).strip()
                finally:
                    kernel32.GlobalUnlock(handle)
            finally:
                user32.CloseClipboard()
        except (AttributeError, OSError):
            return ""
    if sys.platform == 'darwin':
        return _clip_via_cmd(['pbpaste'])
    # Linux/Unix. En Android no hay xclip/xsel ni subprocess fiable, así que cortamos antes.
    if xbmc.getCondVisibility('System.Platform.Android'):
        return ""
    return (_clip_via_cmd(['xclip', '-selection', 'clipboard', '-o'])
            or _clip_via_cmd(['xsel', '-b', '-o']))


def play_url_action(raw_url):
    """Reproduce una URL registrándola en el historial."""
    if not raw_url:
        return
    import threading
    threading.Thread(target=_add_to_history, args=(raw_url,), daemon=True).start()
    _resolve_and_play(raw_url)


def play_without_history(raw_url):
    """Como play_url_action pero sin anotarla en el historial de URLs, porque los canales de las
    listas de canales no son URLs que el usuario haya escrito. AceStream sigue la cadena de
    siempre (StreamNinja, EKHorus/Horus o el motor local)."""
    if raw_url:
        _resolve_and_play(raw_url)


def debrid_library_menu():
    """Lista el contenido de la nube del Debrid configurado."""
    h = int(sys.argv[1])
    resolver = _get_debrid()
    if resolver is None:
        xbmcplugin.endOfDirectory(h)
        return

    try:
        items = resolver.list_library()
    except Exception as e:
        xbmc.log("[EspaTV/Debrid] biblioteca: {0}".format(e), xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("Debrid", "No se pudo cargar tu nube", xbmcgui.NOTIFICATION_WARNING, 3000)
        xbmcplugin.endOfDirectory(h)
        return

    if not items:
        li = xbmcgui.ListItem(label="[COLOR grey]Tu nube está vacía[/COLOR]")
        li.setArt({"icon": "DefaultPlaylist.png"})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for it in items:
        size_gb = (it.get("size", 0) or 0) / 1e9
        ready = it.get("ready")
        label = "{0}  [COLOR grey]({1:.2f} GB)[/COLOR]".format(it.get("filename", "?"), size_gb)
        if not ready:
            label = "[COLOR grey]{0} ({1})[/COLOR]".format(it.get("filename", "?"), it.get("status", "procesando"))
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": "DefaultVideo.png"})
        item_id = it.get("id")
        if ready:
            li.setProperty("IsPlayable", "false")
            li.addContextMenuItems([
                ("Ver archivos", "Container.Update({0})".format(_u(action="debrid_library_files", id=item_id))),
                ("Descargar a disco", "RunPlugin({0})".format(_u(action="debrid_download", id=item_id, title=it.get("filename", "")))),
                ("Borrar de la nube", "RunPlugin({0})".format(_u(action="debrid_library_delete", id=item_id))),
            ])
            url = _u(action="debrid_library_play", id=item_id)
            folder = False
        else:
            url = ""
            folder = False
        xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=folder)

    xbmcplugin.endOfDirectory(h)


def debrid_library_files(item_id):
    """Lista los archivos de vídeo de un item concreto de la nube."""
    h = int(sys.argv[1])
    resolver = _get_debrid()
    if resolver is None or not item_id:
        xbmcplugin.endOfDirectory(h)
        return
    try:
        files = resolver.library_files(item_id)
    except Exception as e:
        xbmc.log("[EspaTV/Debrid] archivos: {0}".format(e), xbmc.LOGWARNING)
        files = []
    for idx, f in enumerate(files):
        size_gb = (f.get("size", 0) or 0) / 1e9
        li = xbmcgui.ListItem(label="{0}  [COLOR grey]({1:.2f} GB)[/COLOR]".format(f.get("name", "?"), size_gb))
        li.setArt({"icon": "DefaultVideo.png"})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="debrid_library_play", id=item_id, file=idx),
            listitem=li, isFolder=False,
        )
    xbmcplugin.endOfDirectory(h)


def debrid_library_play(item_id, file_index=None):
    """Reproduce un item de la nube (vídeo principal o archivo concreto)."""
    resolver = _get_debrid()
    if resolver is None or not item_id:
        return
    try:
        if file_index is None:
            stream = resolver.resolve_library_item(item_id)
        else:
            stream = resolver.resolve_library_file(item_id, int(file_index))
    except Exception as e:
        xbmc.log("[EspaTV/Debrid] reproducir nube: {0}".format(e), xbmc.LOGWARNING)
        stream = None
    if stream:
        _play_resolved_stream(stream)
    else:
        xbmcgui.Dialog().notification("Debrid", "No se pudo reproducir", xbmcgui.NOTIFICATION_WARNING, 3000)


def debrid_library_delete(item_id):
    if not item_id:
        return
    if not xbmcgui.Dialog().yesno("Debrid", "¿Borrar este elemento de tu nube?"):
        return
    resolver = _get_debrid()
    if resolver is None:
        return
    try:
        resolver.delete_library_item(item_id)
    except Exception as e:
        xbmc.log("[EspaTV/Debrid] borrar nube: {0}".format(e), xbmc.LOGWARNING)
    xbmc.executebuiltin("Container.Refresh")


def debrid_download(item_id, title=""):
    """Descarga a disco un elemento de la nube Debrid (link directo HTTPS)."""
    resolver = _get_debrid()
    if resolver is None or not item_id:
        return
    try:
        stream = resolver.resolve_library_item(item_id)
    except Exception as e:
        xbmc.log("[EspaTV/Debrid] descargar nube: {0}".format(e), xbmc.LOGWARNING)
        stream = None
    if not stream:
        xbmcgui.Dialog().notification("Debrid", "No se pudo resolver para descargar", xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    title = title or "video"
    ext = os.path.splitext(urllib.parse.urlparse(stream).path)[1].lower()
    if ext not in _STREAM_EXTENSIONS:
        ext = ".mp4"
    dest = _get_download_dest(title, ext)
    if not dest:
        return
    _download_direct_url(stream, dest, title)


def url_player_ensure_streamninja():
    """Abre StreamNinja o, si no está, ofrece instalarlo.

    La instalación la lleva espakodi_installer (ya tiene el repo, el instalador
    automático y las instrucciones manuales). Es la entrada de la acción
    ``url_player_ensure_sn``, que fantasia.py esconde en su Modo Fantasía.

    Sin punto verde de novedad a propósito: abrir o instalar StreamNinja ya se
    podía hacer desde «Addons EspaKodi» desde siempre; esta fila es un atajo a
    eso, no una función nueva (la rama del router llevaba muerta desde la
    v2.5.0, apuntando a esta función, que no existió hasta el 2026-10-04).
    """
    import espakodi_installer
    espakodi_installer.launch_by_id("plugin.video.streamninja")


def scan_videos_dialog():
    """Escanea una web o un canal público de Telegram y permite reproducir."""
    import telegram_scanner

    kb = xbmc.Keyboard('', 'URL de web, o canal de Telegram (@canal, t.me/canal)')
    kb.doModal()
    if not kb.isConfirmed():
        return

    url = kb.getText().strip()
    if not url:
        return

    # Canales de Telegram: flujo propio (acepta @canal, t.me/canal o nombre desnudo)
    if telegram_scanner.is_telegram(url):
        _scan_telegram_flow(url)
        return

    if not url.startswith(("http://", "https://")):
        xbmcgui.Dialog().ok(
            "EspaTV",
            "Introduce una URL (http:// o https://) o un canal de Telegram "
            "(@canal, t.me/canal).",
        )
        return

    pdp = xbmcgui.DialogProgress()
    pdp.create("Escaneando vídeos", "Analizando {0}...".format(url[:60]))

    try:
        videos = _scan_with_best_engine(url)
    except Exception as exc:
        xbmc.log(
            "[EspaTV] Error escaneando {0}: {1}".format(url[:60], exc),
            xbmc.LOGWARNING,
        )
        videos = []
    finally:
        pdp.close()

    if not videos:
        xbmcgui.Dialog().ok(
            "EspaTV",
            "No se encontraron vídeos en esta página.\n\n"
            "Prueba con otra URL o pega directamente \n"
            "la URL del vídeo.",
        )
        return

    import html_scanner

    labels = []
    for v in videos:
        parts = [v.get("title") or v.get("url", "")[:60]]
        dur = v.get("duration")
        if dur:
            parts.append(html_scanner.format_duration(dur))
        size = v.get("filesize")
        if size:
            parts.append(html_scanner.format_size(size))
        ext = v.get("ext", "")
        if ext:
            parts.append(ext.upper())
        labels.append(" · ".join(parts))

    sel = xbmcgui.Dialog().select(
        "Vídeos encontrados ({0})".format(len(videos)), labels
    )
    # Misma guarda que el flujo de Telegram: un índice fuera de rango no debe
    # reventar con IndexError por la vía del router.
    if sel < 0 or sel >= len(videos):
        return

    chosen = videos[sel]
    chosen_url = chosen.get("url", "")
    if chosen_url:
        _add_to_history(chosen_url, label=chosen.get("title"))
        _resolve_and_play(chosen_url)


def _scan_with_best_engine(url):
    """Elige el motor adecuado según la plataforma y escanea."""
    # En PC, usar yt-dlp si está disponible
    if ytdlp_resolver.is_available():
        results = ytdlp_resolver.scan_videos(url)
        if results:
            return results

    # Fallback universal: escáner HTML
    import html_scanner
    return html_scanner.scan_page(url)


def scan_telegram_dialog():
    """Pide solo un canal de Telegram (no acepta webs) y lo escanea.

    Es la entrada de la acción ``url_scan_telegram``: para quien ya sabe que va
    a canal y no quiere escribir una URL de web. Acepta @canal, t.me/canal o el
    nombre desnudo; si se pega otra cosa, avisa y no escanea.
    """
    # Lo nuevo deja de serlo en cuanto se abre (ver ui_utils.punto/visto).
    import ui_utils
    ui_utils.visto('url_scan_telegram')
    import telegram_scanner

    kb = xbmc.Keyboard("", "Canal de Telegram (@canal, t.me/canal)")
    kb.doModal()
    if not kb.isConfirmed():
        return

    channel = kb.getText().strip()
    if not channel:
        return

    if not telegram_scanner.is_telegram(channel):
        xbmcgui.Dialog().ok(
            "EspaTV",
            "Eso no parece un canal de Telegram.\n\n"
            "Escribe @canal, t.me/canal o el nombre del canal.",
        )
        return

    _scan_telegram_flow(channel)


# Rondas seguidas sin ningún enlace nuevo antes de dejar de ofrecer "Cargar más".
# Un canal real tiene mensajes de solo texto, así que una ronda vacía no quiere
# decir que se acabó; dos seguidas sí, y seguir sería una cinta sin fin.
_TG_MAX_RONDAS_VACIAS = 2


def _scan_telegram_flow(channel):
    """Escanea un canal público de Telegram con paginación incremental.

    Empieza por las últimas entradas y permite cargar más antiguas a demanda.
    El label de cada enlace es el texto del mensaje (contexto, no solo la URL).
    """
    import telegram_scanner
    import html_scanner

    if telegram_scanner.is_private_invite(channel):
        xbmcgui.Dialog().ok(
            "EspaTV",
            "Es un enlace de invitación a un canal o grupo PRIVADO de "
            "Telegram.\n\n"
            "Solo se pueden escanear canales públicos (t.me/nombre).",
        )
        return

    videos = []
    seen = set()
    cursor = None
    first = True
    rondas_vacias = 0

    while True:
        pdp = xbmcgui.DialogProgress()
        pdp.create(
            "Escaneando Telegram",
            "Leyendo las últimas entradas..." if first else "Cargando más antiguas...",
        )
        fallo = None
        try:
            batch, cursor = telegram_scanner.scan_channel_paged(channel, before_id=cursor)
        except Exception as exc:
            xbmc.log(
                "[EspaTV] Error escaneando Telegram {0}: {1}".format(channel[:40], exc),
                xbmc.LOGWARNING,
            )
            batch, cursor = [], None
            fallo = exc
        finally:
            # iscanceled se lee ANTES de cerrar: una vez cerrado, el diálogo ya
            # no garantiza nada. Es el orden que usa el resto del addon.
            cancelado = pdp.iscanceled()
            pdp.close()
        if cancelado and first:
            # Cancelado en la primera ronda: no hay nada que enseñar y no hay
            # motivo para abrir un diálogo sobre un diálogo.
            return

        added = 0
        for v in batch:
            u = v.get("url", "")
            if u and u not in seen:
                seen.add(u)
                videos.append(v)
                added += 1

        if not videos:
            # Cubre canal inexistente/vacío y también fallo de red.
            xbmcgui.Dialog().ok(
                "EspaTV",
                "No se pudieron obtener enlaces de vídeo del canal.\n\n"
                "Verifica que el nombre es correcto y el canal es público "
                "(t.me/nombre), que comparte vídeos y que tienes conexión.",
            )
            return

        if not first:
            # `fallo` solo se activa si revienta el propio escáner: los errores de
            # red los traga _fetch_page y llegan aquí como página vacía.
            if fallo is not None:
                xbmcgui.Dialog().notification(
                    "Telegram",
                    "No se pudo leer el canal: {0}".format(str(fallo)[:80]),
                    xbmcgui.NOTIFICATION_WARNING, 3000,
                )
            elif added == 0:
                rondas_vacias += 1
                # O el canal se acabó, o la lectura falló: _fetch_page se traga el
                # error de red y devuelve "", así que aquí no se puede distinguir.
                xbmcgui.Dialog().notification(
                    "Telegram",
                    "No se encontraron más enlaces en las entradas anteriores",
                    xbmcgui.NOTIFICATION_INFO, 2500,
                )
            else:
                rondas_vacias = 0
        first = False

        options = []
        for v in videos:
            parts = [v.get("title") or v.get("url", "")[:60]]
            dur = v.get("duration")
            if dur:
                parts.append(html_scanner.format_duration(dur))
            size = v.get("filesize")
            if size:
                parts.append(html_scanner.format_size(size))
            ext = v.get("ext", "")
            if ext:
                parts.append(ext.upper())
            options.append(" · ".join(parts))

        more_idx = -1
        if cursor and rondas_vacias < _TG_MAX_RONDAS_VACIAS:
            more_idx = len(options)
            options.append("[COLOR cyan]⬇ Cargar más antiguas[/COLOR]")
        elif cursor:
            xbmcgui.Dialog().notification(
                "Telegram",
                "El canal ya no da más enlaces. Se terminan las entradas antiguas.",
                xbmcgui.NOTIFICATION_INFO, 2500,
            )

        sel = xbmcgui.Dialog().select(
            "Telegram: {0} enlaces".format(len(videos)), options
        )
        # El orden importa: Dialog.select() devuelve -1 al cancelar, que es el
        # mismo centinela de more_idx. Sin el "more_idx >= 0", pulsar Atrás sin
        # botón "Cargar más" haría sel == more_idx y volvería a escanear en bucle.
        if sel >= 0 and sel == more_idx:
            continue  # paginar hacia atrás y reabrir la lista acumulada
        if sel < 0 or sel >= len(videos):
            # Cancelado, o índice inválido (no debería pasar): no se reproduce nada.
            return

        chosen = videos[sel]
        chosen_url = chosen.get("url", "")
        if chosen_url:
            _add_to_history(chosen_url, label=chosen.get("title"))
            _resolve_and_play(chosen_url)
        return