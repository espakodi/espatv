# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Diccionario de nombres: significado, origen, variantes y personas famosas.

Todo se consulta en vivo, sin base de datos propia. Fuentes:

  · es.wikipedia / en.wikipedia   (CC BY-SA 4.0) -> significado y personas
  · es.wiktionary / en.wiktionary (CC BY-SA 4.0) -> etimologia y variantes

Behind the Name NO se consulta: su robots.txt lo permite, pero su pagina de
derechos de autor prohibe expresamente raspar su contenido. Solo se enlaza.

El grueso del trabajo esta en no confundirse con otro articulo. El articulo del
nombre y el del toponimo comparten titulo: "Sofia" es la capital de Bulgaria y
"Almudena" una alcazaba. Por eso se pide 'prop=extracts|categories' en la misma
llamada y solo se acepta la pagina si su categoria empieza por "Categoria:Nombres"
o si su texto dice "es un nombre propio". Ver _acepta().

Límites de Wikimedia: 10 peticiones por minuto y por IP, con cubo compartido entre
wikipedia.org y wiktionary.org. Se ejecutan en serie, con separación mínima entre
llamadas y respetando el Retry-After. Ver _api().

El texto remoto se sanea antes de pintarlo: se le quitan las etiquetas BBCode que
Kodi interpreta, los caracteres invisibles y los de control.
"""
import hashlib
import json
import os
import re
import sys
import threading
import time
import unicodedata
import urllib.parse

import requests

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings
from _user_agents import ua_addon

_LOG = "[EspaTV-NOMBRES]"
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")


def _err(e):
    """El tipo de error, y el codigo HTTP si lo hay, para el log.

    No se usa str(e) a proposito. El mensaje de requests lleva la URL completa, y en
    las busquedas de Wikipedia la URL lleva titles=<nombre buscado>: registrarlo
    sacaria a kodi.log el nombre buscado, que es justo lo que
    AVISO_LEGAL.txt promete no transmitir. El tipo y el codigo bastan para
    diagnosticar y no dicen a quien se buscaba.
    """
    respuesta = getattr(e, "response", None)
    codigo = getattr(respuesta, "status_code", None)
    if isinstance(e, requests.exceptions.HTTPError) and codigo:
        return "HTTPError {0}".format(codigo)
    return type(e).__name__

_TIMEOUT = 20
# Separacion minima entre peticiones.
# Pausa prudencial entre peticiones a Wikimedia para no saturar la Action API
# ni provocar 429. Si la API responde 429 con Retry-After, _api() lo respeta.
_ESPERA_MIN = 1.0

# Techo global de una ficha. Una ficha son 7-10 peticiones (hasta 15), y con _TIMEOUT=20
# y 3 intentos, una conexión colgada (acepta pero no contesta) la deja unos 4 minutos con
# el DialogProgress abierto; cancelar no corta el hilo. 90 s sobra para el caso normal
# (7-10 s), y lo que no dé tiempo a mirar se queda fuera: la ficha sale con lo que haya.
_PLAZO_FICHA = 90.0
# Cuando se agota el plazo. Es una lista de un elemento para que las pruebas puedan
# ponerla y dejar el estado como estaba, sin ensuciar el resto del modulo (igual que
# _FALLO_RED).
_PLAZO = [None]


def _plazo_empieza():
    """Arranca el reloj de una ficha. Lo llama _con_progreso() al empezar."""
    _PLAZO[0] = time.monotonic() + _PLAZO_FICHA


def _plazo_agotado():
    """True si ya no queda tiempo para esta ficha.

    Se comprueba antes de cada petición, no durante: una petición iniciada no se
    cancela a mitad. Con _TIMEOUT=20 s, el peor caso sin respuesta queda acotado a
    90 + 20 = 110 s.
    """
    if _PLAZO[0] is None:
        return False
    return time.monotonic() >= _PLAZO[0]


def _queda_plazo(segundos):
    """True si sigue habiendo plazo para una peticion de 'segundos' segundos.

    Evita iniciar una petición que superaría el plazo global de la ficha.
    """
    if _PLAZO[0] is None:
        return True
    return time.monotonic() + segundos <= _PLAZO[0]
# La etimologia de un nombre no cambia: 90 dias. Esta cache es la que hace que la
# segunda consulta del mismo nombre no gaste red.
_TTL_DATO = 90 * 24 * 3600
# "No hay articulo de nombre para X" se reintenta pronto: 15 minutos. Un nombre
# puede aparecer en la wiki cualquier dia, y 90 dias era demasiado castigo.
_TTL_AUSENCIA = 15 * 60
# Tope de candidatos cuando el nombre escrito no resuelve.
_MAX_CANDIDATOS = 12

try:
    _VERSION = xbmcaddon.Addon().getAddonInfo("version") or "3.0.0"
except Exception:
    _VERSION = "3.0.0"

# User-Agent con contacto, el compartido del addon: Wikimedia dice que bloquea sin
# aviso a quien no lo da, y que copiar el de un navegador se toma como malicioso.
_UA = ua_addon("diccionario de nombres", _VERSION)

_WIKI_ES = "es.wikipedia.org"
_WIKI_EN = "en.wikipedia.org"
_WIKT_ES = "es.wiktionary.org"
_WIKT_EN = "en.wiktionary.org"

# Aviso que acompana a todo texto de Wikipedia/Wiktionary (CC BY-SA 4.0).
_CC = "CC BY-SA 4.0 - https://creativecommons.org/licenses/by-sa/4.0/"

# Desambiguación

# Las cuatro formulas reales de una pagina de desambiguacion en espanol. Se midio
# que ninguna sobra: hay titulos que usan una y otros otra.
_DESAMB_ES = re.compile(
    # Fórmulas de desambiguación habituales en Wikipedia (con y sin pronombre).
    r"(puede\s+referirse\s+a:"
    r"|puede\s+hacer\s+(?:se\s+)?referencia\s+a:"
    r"|puede\s+referirse\s+a\s+lo\s+siguiente"
    r"|hace\s+referencia\s+a\s+varios\s+art[ií]culos"
    r"|generalmente\s+se\s+refiere\s+a:)", re.I)
# En ingles es una sola formula, con prefijo variable ("X or Y may refer to:").
_DESAMB_EN = re.compile(r"\bmay\s+refer\s+to\s*:", re.I)

# La categoría discrimina frente a topónimos y otros usos homónimos.
# En inglés incluye variantes como "Male given names" o "Given names".
_CAT_NOMBRES = re.compile(
    r"^(Categor[ií]a:Nombres\b"
    r"|Categor(?:y|ies):(?:\w+\s+)?given\s+names\b)", re.I)
# Y el texto, para cuando no hay categoría (artículos nuevos sin categorizar).
# "first name" hace falta: en.wikipedia dice de Reuben "a Biblical male first
# name", no "given name", y sin esto Rubén no resolvía.
_TEXTO_NOMBRE = re.compile(
    r"(es\s+un\s+nombre(\s+de\s+pila)?\s+propio"
    r"|nombre\s+(de\s+pila\s+)?(femenino|masculino)"
    r"|(male|female)\s+(given|first)\s+name"
    r"|\bis\s+a\s+(masculine|feminine)\s+given\s+name)", re.I)
# En inglés el patrón es más abierto: el lead de un artículo de nombre de pila siempre dice
# "given name" o "first name" ("Laura is a traditionally feminine given name" no casaba con
# el estricto), y la desambiguación ya la descarta _DESAMB_EN. En español no se abre porque
# un artículo de APELLIDO también dice "nombre propio", que es lo que evita _acepta().
_TEXTO_NOMBRE_EN = re.compile(r"\b(given|first)\s+names?\b", re.I)

# Etimologia de mentira: en es.wiktionary la plantilla {{etimologia}} se renderiza
# como este texto y no dice absolutely nada del nombre.
_PLACEHOLDER = re.compile(
    r"^\s*\(?\s*(si\s+puedes,?\s+incorp[oó]rala|please\s+add\s+an\s+etymology"
    r"|add\s+an\s+etymology|this\s+term\s+needs|this\s+etymology\s+is\s+missing"
    r"|this\s+etymology\s+is\s+incomplete)", re.I)
# Una etimologia real nunca es tan corta como un placeholder.
_MIN_ETIM = 25
# Longitud mínima de definición (menor que la etimología para aceptar definiciones breves).
_MIN_DEF = 15
# Términos que identifican una definición de antropónimo o hipocorístico.
_PERSONA_DEF = re.compile(
    r"(nombre\s+de\s+pila|antrop[oó]nim|given\s+name|hipocor[íi]stic|"
    r"apodo|diminutivo)", re.I)

_PERSONA = re.compile(r"(nombre\s+de\s+pila|antropónimo|given\s+name)", re.I)

# Palabras que Wiktionary pone en "Hipocoristicos" o "Masculino/Femenino" y que
# no son nombres.
_GENERICOS = {"no", "n/d", "nd", "sin", "desconocido", "ninguno", "ninguna", "n/a"}

# Saneado del texto remoto

# Kodi interpreta BBCode en el plot y en el textviewer. Un texto remoto con
# [COLOR] dejaria la interfaz en un color arbitrario, y con [IMG] (Kodi 20+)
# descargaria una imagen desde el movil del usuario. Se quitan todas.
_KODI_TAG_RE = re.compile(
    r"\[/?(?:B|I|U|S|LIGHT|CR|LF|CRLF|TABS?|CENTER|LEFT|RIGHT|MONO|CREDIT|HR"
    r"|COLOR\b[^\]]*|FONT\b[^\]]*|CHAR\b[^\]]*|REF\b[^\]]*|IMG\b[^\]]*"
    r"|UPPERCASE|LOWERCASE|CAPITALIZE)\]", re.I)
# U+200B y compañía: vienen en casi todos los articulos de nombres y se ven como
# un hueco en pantalla.
_INVISIBLE = dict.fromkeys(map(ord, "\u200b\u200c\u200d\u200e\u200f\u00ad\u2060\ufeff"), None)
_CTRL = re.compile(r"[\x00-\x08\x0b\x0c\x0e-\x1f\x7f]")


def _sane(texto):
    """Texto remoto listo para un ListItem o un textviewer de Kodi."""
    if not texto:
        return ""
    t = _KODI_TAG_RE.sub("", str(texto))
    # Quita las etiquetas de mantenimiento de Wikipedia ("[cita requerida]"...):
    # _KODI_TAG_RE solo quita BBCode de Kodi y estas pasaban tal cual a la tele.
    t = re.sub(r"\[\s*(?:cita\s+requerida|cita requerida|needs?\s+citation)"
               r"(?:\s*[^\]]*)?\]", "", t, flags=re.I)
    t = t.translate(_INVISIBLE)
    # El \r se queda fuera de _CTRL a proposito (no es de control para Python), pero
    # un "\r\n" del remoto dentro de un plot sale como un salto raro: se normaliza.
    t = t.replace("\r\n", "\n").replace("\r", "\n")
    t = _CTRL.sub("", t)
    t = re.sub(r"[ \t]{2,}", " ", t)
    t = re.sub(r"\n{3,}", "\n\n", t)
    return t.strip()


def _norm(texto):
    """Minusculas, sin tildes y sin espacios de sobra, para comparar.

    El usuario escribe "sofia", "SOFÍA" o " sofia " y son el mismo nombre: si el
    _norm no colapsara los espacios, cada variante gastaria tres peticiones enteras
    en lugar de leer la caché.

    Un aviso: esto hace que "Rubén" y "Rúben" compartan clave. Es lo correcto aquí,
    porque para un diccionario es el mismo nombre escrito de dos maneras, y lo
    contrario obligaría a guardar tildes en un md5 pensando en el Registro Civil,
    que es un dato que este addon no maneja ni pretende manejar.
    """
    t = unicodedata.normalize("NFKD", str(texto or "").lower())
    t = "".join(c for c in t if not unicodedata.combining(c))
    return " ".join(t.split())


def _sin_tilde(texto):
    return "".join(c for c in unicodedata.normalize("NFKD", str(texto or ""))
                   if not unicodedata.combining(c))


def _clave(prefijo, nombre):
    """Clave de caché de un nombre.

    Se construye SIEMPRE sobre el nombre ya limpio, no sobre lo tecleado: si no, "sofia " y "SOFÍA" serían dos entradas distintas.
    """
    return prefijo + _norm(_bonito(nombre))


def _bonito(nombre):
    """Como lo escribiría una persona: sin espacios raros ni comillas sueltas.

    Elimina caracteres de control y separadores que puedan alterar consultas a la API.
    """
    n = " ".join(_sane(nombre).split())
    # Se quitan caracteres sueltos en los extremos preservando paréntesis de desambiguación.
    n = n.replace("|", " ").strip(" .,;:-'\"")
    return n.strip(" []")


# Patrón para identificar líneas que contienen solo el lema y género gramatical en Wiktionary.
_LEMA = re.compile(
    r"(?m)^[ \t]*\S[^\n]{0,80}?[ \t]+(?:f|m|n|c|anim|adj)(?:[ \t]+\([^)\n]{0,40}\))?"
    r"[ \t]*$")

# Inicio típico de una definición de antropónimo o término en inglés en Wiktionary.
_DEFINICION_EN = re.compile(
    r"^\(?(?:christianity|italian|spanish|english|literary|archaic|obsolete)?\)?\s*"
    r"(?:a|an|the|is|obsolete|short|pet|form|hypocor\w+|diminutive|petform)\b", re.I)


def _sin_lema(texto):
    """Quita la línea del lema cuando la definición viene en la siguiente línea."""
    limpio = _LEMA.sub(" ", texto or "")
    lineas = limpio.split("\n")
    for i, linea in enumerate(lineas):
        if not re.fullmatch(r"[\w'’\-]+(?: [\w'’\-]+)?", linea.strip()):
            continue
        siguiente = ""
        for j in range(i + 1, len(lineas)):
            if lineas[j].strip():
                siguiente = lineas[j].strip()
                break
        if siguiente and _DEFINICION_EN.match(siguiente):
            lineas[i] = " "
    return "\n".join(lineas)


def _cabeza(texto, n=240):
    """Primera frase útil de un texto largo, para usarlo de etiqueta.

    Conserva el punto final y marca el corte con puntos suspensivos para evitar
    descartar oraciones que contienen la definición esencial tras el primer punto.
    """
    t = _sane(_sin_lema(_sane(texto)))
    for corte in (". ", "\n"):
        i = t.find(corte)
        if 0 < i <= n:
            if len(t) - i <= _MIN_SEGUNDO_FRAGMENTO:
                break
            return t[:i].strip() + "..."
    if len(t) <= n:
        return t.strip()
    return t[:n].strip() + "..."


# Margen para no truncar la segunda frase si es corta y aporta contexto.
_MIN_SEGUNDO_FRAGMENTO = 160

# Línea corta que finaliza en dos puntos indicando inicio de lista o subsección.
_ENCABEZADO_DE_LISTA = re.compile(r"^[^:]{0,70}:\s*$")

# Longitud máxima aconsejable para el texto del significado en pantalla.
_MAX_SIGNIFICADO = 700


def _significado_legible(texto, n=_MAX_SIGNIFICADO):
    """El significado en español, recortado para que se lea en la tele.

    `_cabeza()` tiene que recortar también el texto en español, no solo el inglés:

        teresa      2149 car, de los que solo ~600 hablan del nombre
        guadalupe   1928 car, y el segundo parrafo habla del RIO
        juan         962 car

    Corta en dos sitios y en este orden, porque importa: primero en el encabezado de
    una lista, que es donde empieza lo que NO es el nombre, y luego en la longitud.
    Al revés, un nombre cuyo encabezado de lista está al final saldría entero.
    """
    t = _sane(texto)
    lineas = t.split("\n")
    for i, linea in enumerate(lineas):
        # i == 0 se salta: una definición puede empezar con dos puntos.
        if i and _ENCABEZADO_DE_LISTA.match(linea.strip()):
            t = "\n".join(lineas[:i]).strip()
            break
    if len(t) <= n:
        return t
    troceado = t[:n]
    punto = troceado.rfind(". ")
    if punto > n // 3:
        return troceado[:punto].strip() + "..."
    return troceado.strip() + "..."


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _h():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1


def _fila(h, label, url, plot, folder=True, art=None, contexto=None):
    if h < 0:
        return
    li = xbmcgui.ListItem(label=label)
    li.setArt({"icon": art or _icon("cat_nombres.png")})
    li.setInfo("video", {"title": _sane(label), "plot": _sane(plot)})
    li.setProperty("IsPlayable", "false")
    # El menú contextual solo se añade en filas navegables.
    if contexto:
        li.addContextMenuItems(contexto)
    xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=folder)


def _vacio(h, texto):
    if h < 0:
        return
    li = xbmcgui.ListItem(label="[COLOR grey]{0}[/COLOR]".format(_sane(texto)))
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)


def _categoria(h, texto):
    """Establece la categoría del plugin si el handle es válido."""
    if h < 0:
        return
    xbmcplugin.setPluginCategory(h, texto)


# Caché en disco

# El directorio se calcula al usarlo y no al importar: en los tests
# xbmcvfs.translatePath devuelve un MagicMock y os.path.join(MagicMock, ...)
# revienta con TypeError en el import.
def _cache_dir():
    try:
        perfil = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
        return os.path.join(str(perfil), "nombres_cache")
    except Exception as e:
        xbmc.log("{0} Sin perfil para la caché: {1}".format(_LOG, e), xbmc.LOGDEBUG)
        return os.path.join(os.getcwd(), "nombres_cache")


def _cache_path(clave):
    return os.path.join(_cache_dir(),
                        hashlib.md5(clave.encode("utf-8")).hexdigest() + ".json")


def _cache_get(clave, ttl=None):
    """Lo cacheado para esta clave, o None si no hay o esta caducado.

    El ttl lo pone quien guarda, en el propio fichero, y solo quien lee con un ttl
    propio lo manda: asi un acierto con vida corta (el título de una entrada de la
    que la API no trajo el texto, que se vuelve a preguntar a los quince minutos) no
    se queda congelado los 90 días de los datos buenos. Antes este campo se escribía
    siempre y no lo leía nadie, o sea que era datos muertos.
    """
    try:
        with open(_cache_path(clave), "r", encoding="utf-8") as f:
            obj = json.load(f)
        limite = ttl if ttl is not None else (obj.get("ttl") or _TTL_DATO)
        if time.time() - obj.get("ts", 0) < limite:
            return obj.get("data")
    except (OSError, ValueError, TypeError, AttributeError):
        pass
    return None


def _cache_put(clave, datos, ttl=None):
    """Guarda. La clave va hasheada a proposito: un nombre de pila puede ser el de
    alguien real y no queremos dejar el texto buscado escrito en el disco.

    Un 'datos' que es None o una lista vacia NO se guarda. Antes se guardaba, y eso
    convertia un fallo de red (sin conexion, un 403, un 5xx) en un "no existe" que
    duraba 90 dias: con la red ya de vuelta, buscar el mismo nombre no gastaba una
    sola peticion y seguia sin salir nada. El aviso de "intentalo mas tarde" era
    mentira.
    """
    if datos is None or (isinstance(datos, (list, dict, str, tuple)) and not datos):
        return
    try:
        os.makedirs(_cache_dir(), exist_ok=True)
        if not core_settings.atomic_write_json(
                _cache_path(clave),
                {"ts": time.time(), "ttl": (_TTL_DATO if ttl is None else ttl),
                 "data": datos}):
            xbmc.log("{0} atomic_write_json no pudo escribir {1}".format(_LOG, clave),
                     xbmc.LOGWARNING)
    except (OSError, AttributeError, ValueError, TypeError) as e:
        xbmc.log("{0} No se pudo guardar la caché: {1}".format(_LOG, e), xbmc.LOGWARNING)


# Red

# Un solo hilo y separacion minima: es lo que pide la API Etiquette de Wikimedia
# para la Action API sin autenticar (concurrencia 1).
_SEMAFORO = threading.Semaphore(1)
_ULTIMA_LLAMADA = [0.0]


def _esperar_turno():
    with _SEMAFORO:
        desde = time.time() - _ULTIMA_LLAMADA[0]
        if desde < _ESPERA_MIN:
            time.sleep(_ESPERA_MIN - desde)
        _ULTIMA_LLAMADA[0] = time.time()


class _RateLimit(Exception):
    """Wikimedia nos ha pedido que frenemos y no lo hemos conseguido."""


def _api(host, params, intentos=3):
    # El testigo se pone a False al empezar cada petición: importa si falló la ÚLTIMA.
    # _api() devuelve None tanto si la página no existe como con un 429, 403 o 5xx, y sin
    # esto no hay forma de distinguir «no hay artículo» de «no se pudo mirar».
    _FALLO_RED[0] = False
    """Una consulta a la Action API. Devuelve el dict, o None.

    Lo importante de esta funcion es que comprueba el codigo de estado ANTES de
    pedir el JSON: el 429 de Wikimedia viene en text/plain, y response.json()
    lanzaria antes de que pudiéramos mirar el estado.
    """
    url = "https://{0}/w/api.php".format(host)
    consulta = dict(params, format="json", formatversion="1", redirects="1")
    for intento in range(max(1, intentos)):
        # Techo de la ficha (_PLAZO_FICHA). Se mira antes de CADA intento: con 3 intentos, una
        # sola petición puede gastar 60 s. Al cortar se marca como fallo de red, para que no se
        # lea como «este nombre no tiene artículo».
        if _plazo_agotado():
            _FALLO_RED[0] = True
            xbmc.log("{0} Se agota el plazo de la ficha; dejo de preguntar a {1}".format(
                _LOG, host), xbmc.LOGINFO)
            return None
        _esperar_turno()
        try:
            r = requests.get(url, params=consulta, timeout=_TIMEOUT,
                             headers={"User-Agent": _UA, "Accept": "application/json"})
        except (OSError, ValueError) as e:
            # OSError y no requests.RequestException a propósito: RequestException
            # hereda de OSError, y así se sigue capturando aunque haya otra copia de
            # 'requests' cargada (pasa en el PC de desarrollo, con dos instalaciones
            # en el path) y la excepción no sea instancia de la clase que tenemos aquí.
            xbmc.log("{0} Error de red en {1}: {2}".format(_LOG, host, _err(e)), xbmc.LOGWARNING)
            _FALLO_RED[0] = True
            return None
        if r.status_code == 200:
            try:
                datos = r.json()
            except ValueError as e:
                xbmc.log("{0} Respuesta ilegible de {1}: {2}".format(_LOG, host, e),
                         xbmc.LOGWARNING)
                _FALLO_RED[0] = True
                return None
            if not isinstance(datos, dict):
                _FALLO_RED[0] = True
                return None
            # Wikimedia devuelve sus errores de servidor (maxlag...) con estado 200 y
            # {"error": {...}} en el cuerpo. Se marca _FALLO_RED y se devuelve el dict tal cual,
            # para que el llamante pueda leer 'error'; devolver None haría perder el
            # 'continue' en los bucles de paginación.
            if datos.get("error"):
                err = datos["error"]
                codigo = err.get("code") if isinstance(err, dict) else err
                xbmc.log("{0} {1} respondio un error en el cuerpo: {2}".format(
                    _LOG, host, codigo), xbmc.LOGWARNING)
                _FALLO_RED[0] = True
            return datos
        if r.status_code == 429:
            # Retry-After en segundos es la unica cabecera que mandan.
            try:
                espera = int(r.headers.get("Retry-After") or 0)
            except (TypeError, ValueError):
                espera = 0
            # Se acota el tiempo de espera entre 5 y 60 segundos respetando Retry-After.
            espera = max(min(espera, 60), 5)
            xbmc.log("{0} Limite de peticiones de {1}; espero {2}s".format(_LOG, host, espera),
                     xbmc.LOGINFO)
            if intento + 1 >= intentos:
                # Tambien se marca: un 429 es un fallo NUESTRO de ritmo, no que el
                # nombre no exista.
                _FALLO_RED[0] = True
                raise _RateLimit(host)
            time.sleep(espera)
            continue
        # Cualquier otro codigo (404, 403, 5xx) no se reintenta: no va a mejorar.
        xbmc.log("{0} {1} respondio {2}".format(_LOG, host, r.status_code), xbmc.LOGINFO)
        _FALLO_RED[0] = True
        return None
    return None


# Si la última llamada falló por la red. _api() devuelve None tanto si la página no
# existe como con un 429, 403 o 5xx; esto lo distingue.
#
# Es una lista de un elemento y no una bandera de módulo para que los tests puedan ponerla
# y restaurarla sin ensuciar el resto del módulo.
_FALLO_RED = [False]


def _api_va_a_mirar():
    """Limpia el testigo de fallo antes de empezar a buscar un nombre."""
    _FALLO_RED[0] = False


def _hay_fallo_de_red():
    return _FALLO_RED[0]


def _paginas(datos):
    """Las paginas de una respuesta de query, como lista de dicts válidos.

    El guardia de 'missing' importa: con formatversion=1 la API lo devuelve como
    CADENA VACÍA ("missing": "") para las páginas que no existen, y not "" es True,
    así que un `not p.get("missing")` no filtraría nada. Hay que mirar que sea None.
    """
    if not isinstance(datos, dict):
        return []
    crudos = ((datos.get("query") or {}).get("pages") or {})
    if isinstance(crudos, dict):
        crudos = list(crudos.values())
    if not isinstance(crudos, list):
        return []
    return [p for p in crudos
            if isinstance(p, dict) and p.get("missing") is None and "invalid" not in p]


def _lista_de(datos, clave):
    """(datos or {}).get('query').get(clave) como lista, siempre.

    Blindado porque 'query' puede no ser un dict si la respuesta llega rara, y un
    .get() sobre un str revienta con AttributeError que sube hasta la pantalla.

    OJO: esto es para las listas de la RESPUESTA ('redirects', 'categorymembers'),
    que cuelgan de 'query'. NO vale para los campos de UNA PAGINA ('categories'),
    que cuelgan de la pagina directamente: ver _categorias_de().
    """
    q = (datos or {}).get("query")
    v = q.get(clave) if isinstance(q, dict) else None
    return v if isinstance(v, list) else []


def _categorias_de(pagina):
    """Las categorías de una página en 'query.pages', como lista de títulos."""
    crudas = (pagina or {}).get("categories")
    if isinstance(crudas, dict):
        crudas = list(crudas.values())
    if not isinstance(crudas, list):
        return []
    return [c.get("title", "") for c in crudas
            if isinstance(c, dict) and c.get("title")]


# Resolución del nombre

def _habla_de_otro_nombre(extracto, nombre, espanol):
    """Si el artículo habla de un nombre DISTINTO al que se busca.

    Detecta si el texto describe un nombre masculino distinto al buscado (por ejemplo,
    cuando un artículo de nombre femenino remite al masculino). Requiere ambas condiciones
    para no descartar entradas legítimas que mencionan variantes de ambos géneros.
    """
    n = _norm(nombre)
    if not n:
        return False
    m = re.search(r"\b([\w\u00C0-\u024F' -]{2,30})\s+es\s+un\s+nombre\s+"
                  r"(?:de\s+pila\s+)?masculin", extracto, re.I)
    if not m:
        return False
    return _norm(m.group(1)) != n


def _acepta(extracto, categorias, espanol, nombre=None):
    """True si esta pagina es la del nombre de pila y no la del toponimo.

    Se usa el regex de desambiguacion y, si no dice nada, la categoria. La
    categoria sola bastaba en las pruebas, pero un articulo recien creado puede
    no estar categorizado, asi que tambien se mira el texto.

    `nombre` es el nombre tecleado, cuando se sabe. Sirve para descartar textos que hablan
    de OTRO nombre: el artículo de Antonio dice "cuya versión femenina es Antonia", y sin
    esto buscar Antonia enseñaba Antonio.
    """
    if not extracto:
        return False
    if nombre and _habla_de_otro_nombre(extracto, nombre, espanol):
        return False
    if (_DESAMB_ES if espanol else _DESAMB_EN).search(extracto):
        return False
    if any(_CAT_NOMBRES.match(c) for c in categorias):
        return True
    return bool((_TEXTO_NOMBRE_EN if not espanol else _TEXTO_NOMBRE).search(extracto))


def _pagina(host, titulo, espanol, nombre=None):
    """La pagina pedida, o None si no existe o no es la del nombre.

    `nombre` es el nombre tecleado y hay que pasárselo a `_acepta()`: sin el cuarto
    argumento, el filtro de otro nombre no actúa. Con el texto real de la página de Antonio:

        _habla_de_otro_nombre(texto, "Antonia", True)  -> True
        _acepta(texto, [], True)                       -> True    (como se llamaba)
        _acepta(texto, [], True, "Antonia")            -> False   (como debe)
        _resuelve("Antonia")                           -> 'Antonio'

    Es decir: buscando "Antonia" se enseñaba la ficha de "Antonio", que es el mismo
    tipo de fallo que el que hacía que "Sofía" saliera con el significado de Bulgaria.
    """
    datos = _api(host, {"action": "query", "prop": "extracts|categories",
                        "exintro": "1", "explaintext": "1", "cllimit": "max",
                        "titles": titulo})
    for pagina in _paginas(datos):
        extracto = _sane(pagina.get("extract") or "")
        cats = _categorias_de(pagina)
        if _acepta(extracto, cats, espanol, nombre):
            return {"titulo": pagina.get("title", titulo), "extracto": extracto, "host": host}
    return None


def _por_busqueda(nombre):
    """Quinto intento: buscar páginas de antropónimos en Wikipedia en español."""
    n = _bonito(nombre)
    if not n:
        return None
    try:
        datos = _api(_WIKI_ES, {
            "action": "query", "generator": "search", "gsrsearch": n,
            "gsrlimit": "10", "gsrnamespace": 0,
            "prop": "extracts|categories", "exintro": "1", "explaintext": "1",
            "cllimit": "max", "exlimit": "max",
        })
    except _RateLimit:
        return None
    # El propio nombre fuera, y el primero que _acepta() da por bueno.
    objetivo = _norm(n)
    for pagina in _paginas(datos):
        titulo = pagina.get("title") or ""
        if not titulo or _norm(titulo) == objetivo:
            continue
        extracto = (pagina.get("extract") or "").strip()
        categorias = [c.get("title", "") for c in (pagina.get("categories") or [])]
        if _acepta(extracto, categorias, True, n):
            return {"titulo": titulo, "extracto": extracto, "host": _WIKI_ES}
    return None


def _resuelve(nombre):
    """Resuelve la página del nombre en español (es.wikipedia o es.wiktionary)."""
    _api_va_a_mirar()
    clave = _clave("resuelve_", nombre)
    # La clave de resolución usa el TTL normal de dato (90 días): el significado
    # de un nombre es estático y no requiere reconsultas frecuentes.
    cacheado = _cache_get(clave)
    # El isinstance hace falta: con un `data` de texto en esta clave sale "string indices
    # must be integers". Quien llama hace pagina["extracto"], así que tiene que ser un dict.
    if isinstance(cacheado, dict):
        return cacheado or None

    n = _bonito(nombre)
    if not n:
        return None
    for titulo in (n, "{0} (nombre)".format(n)):
        try:
            pagina = _pagina(_WIKI_ES, titulo, True, n)
        except _RateLimit:
            # Un 429 NO significa que el nombre no exista: no se cachea nada.
            return None
        if pagina:
            _cache_put(clave, pagina)
            return pagina
    try:
        hallada = _por_busqueda(n)
    except _RateLimit:
        return None
    if not hallada:
        # Último intento en español: es.wiktionary (para nombres sin artículo propio en Wikipedia).
        # Se devuelve con host de Wiktionary para atribuir correctamente el enlace al pie.
        definicion = _definicion_wikt(n)
        if definicion:
            hallada = {"titulo": _titulo_wikt(n), "extracto": definicion,
                       "host": _WIKT_ES}
    if hallada:
        _cache_put(clave, hallada)
    return hallada


# Wiktionary

def _secciones(texto, nivel):
    """[(titulo, cuerpo)] de los encabezados de markdown de ESE nivel, y solo de ese.

    El (?!=) en los dos extremos es lo importante: sin él, el patrón de nivel 2
    también casaba con "=== Etimología ===" (el grupo se comía el signo '='), y
    _bloque_idioma no encontraba ningún idioma.
    """
    eq = "=" * nivel
    patron = re.compile(r"^{0}(?!=)\s*(.+?)\s*{0}(?!=)\s*$".format(eq), re.M)
    marcas = [(m.group(1).strip(), m.start(), m.end()) for m in patron.finditer(texto or "")]
    salida = []
    for i, (_titulo, _ini, fin) in enumerate(marcas):
        fin_cuerpo = marcas[i + 1][1] if i + 1 < len(marcas) else len(texto or "")
        salida.append((_titulo, (texto or "")[fin:fin_cuerpo].strip()))
    return salida


def _sin_subsecciones(cuerpo):
    """Corta en el siguiente encabezado de cualquier nivel.

    Sin esto la etimologia de "Guadalupe" se traga las catorce definiciones de
    "Sustantivo propio", que en Wiktionary van un nivel mas abajo.
    """
    m = re.search(r"^={2,6}\s*\S", cuerpo or "", re.M)
    return (cuerpo[:m.start()] if m else cuerpo or "").strip()


def _seccion(texto, nivel, patrones):
    """El cuerpo del primer encabezado de ese nivel cuyo titulo case con un patron."""
    for titulo, cuerpo in _secciones(texto, nivel):
        # Las cabeceras de Wiktionary vienen numeradas ("Etimologia 1").
        limpio = re.sub(r"\s*\d+\s*$", "", titulo).strip()
        if any(re.fullmatch(p, limpio, re.I) for p in patrones):
            cuerpo = _sin_subsecciones(cuerpo)
            if cuerpo:
                return cuerpo
    return ""


def _cualquier_apartado_de_nombre(extracto):
    """El primer apartado (nivel 3 o 4) que hable de un nombre de pila, o "".

    Complemento de _cuerpo_nombre_de_pila(): no depende de una lista fija de
    encabezados para admitir entradas bajo 'Antropónimo' o definiciones de
    nombre de pila incluidas dentro de otras secciones.
    """
    for nivel in (3, 4):
        for titulo, cuerpo in _secciones(extracto, nivel):
            limpio_titulo = re.sub(r"\s*\d+\s*$", "", titulo).strip()
            # Descarta apartados auxiliares (etimología en español e inglés, pronunciación,
            # traducciones...) que no constituyen la definición principal.
            if re.fullmatch(
                    r"Eti(?:molog|ymolog)[ií]a?(?:\s*\d+)?|Pronunciation|Pronunciaci[oó]n"
                    r"|Translations|Traducciones|References|Referencias|Synonyms"
                    r"|Sin[oó]nimos|Derived\s+terms|Descendientes|Descendants"
                    r"|Usage\s+notes|Notas?\s+de?\s+uso|Descendencia"
                    r"|Etimolog[ií]a|Etymology", limpio_titulo, re.I):
                continue
            limpio = _sin_subsecciones(cuerpo)
            if limpio and _PERSONA_DEF.search(limpio):
                return limpio
    return ""


def _cuerpo_nombre_de_pila(extracto, espanol):
    """Cuerpo del apartado que define el nombre de pila en Wiktionary, o cadena vacía."""
    for nivel in (3, 4):
        for titulo, cuerpo in _secciones(extracto, nivel):
            limpio = re.sub(r"\s*\d+\s*$", "", titulo).strip()
            if _es_apartado_de_nombre(limpio, espanol):
                limpio_cuerpo = _sin_subsecciones(cuerpo)
                if limpio_cuerpo and _PERSONA_DEF.search(limpio_cuerpo):
                    return limpio_cuerpo
    return ""


def _es_apartado_de_nombre(titulo, espanol):
    """True si el encabezado del apartado es el que define un nombre de pila."""
    patrones = ((r"Sustantivo\s+propio", r"Antrop[oó]nim[oa]", r"Nombre\s+propio",
                  r"Nombres?\s+propios?") if espanol
                else (r"Proper\s+noun", r"Given\s+name"))
    return any(re.fullmatch(p, titulo or "", re.I) for p in patrones)


def _acepciones(cuerpo):
    """Separa las acepciones de Wiktionary por puntos preservando años y fechas."""
    acepciones, actual = [], []

    def cerrar():
        if actual:
            texto = " ".join(actual).strip(" .;:,")
            if texto:
                acepciones.append(texto)
            del actual[:]

    for linea in (cuerpo or "").split("\n"):
        s = linea.strip()
        if not s:
            continue
        if re.fullmatch(r"\d{1,2}", s):
            cerrar()                          # la línea ES un número
            continue
        m = re.match(r"^(\d{1,2})\s*[.)]?\s+(\S.*)$", s)
        if m:
            cerrar()
            actual.append(m.group(2))         # "2 Nombre de pila" / "2. Nombre"
            continue
        m = re.match(r"^(.*\S)\s+\d{1,2}$", s)
        if m:
            actual.append(m.group(1))         # "Nombre de pila 3"
            cerrar()
            continue
        actual.append(s)
    cerrar()

    salida, vistas = [], set()
    for a in acepciones:
        a = a.strip(" .;:,")
        # La deduplicacion compara SIN el punto final. Con el punto, dos acepciones
        # iguales ("Nombre de pila de mujer." / "Nombre de pila de mujer") no se
        # detectan porque una tiene punto y la otra no todavia.
        clave = a.lower()
        if a and clave not in vistas:
            vistas.add(clave)
            salida.append(a + ".")
    return " ".join(salida)


def _significado_en(nombre):
    """El significado en INGLÉS, o "" si no hay.

    Lo que da cada fuente, y por qué este orden:
    - en.wikipedia "X (given name)": la mejor (Lola, Laura, Greta, Pau).
    - en.wikipedia "X" a secas: cubre a los que no tienen "(given name)", como Rubén
      ("Reuben") o Sofía.
    - en.wiktionary: cuando no hay artículo en la wikipedia inglesa.

    Se pide sin tildes porque los articulos ingleses van sin ellas.
    """
    clave = _clave("sigen_", nombre)
    cacheado = _cache_get(clave)
    if isinstance(cacheado, dict):
        return cacheado or None

    n = _sin_tilde(_bonito(nombre))
    if not n:
        return None
    hallada = None
    for titulo in ("{0} (given name)".format(n), n):
        try:
            pagina = _pagina(_WIKI_EN, titulo, False, n)
        except _RateLimit:
            return None
        if pagina:
            hallada = {"titulo": pagina["titulo"], "host": pagina["host"],
                       "extracto": _cabeza(pagina["extracto"], 420)}
            break
    if not hallada:
        # en.wiktionary, con el mismo resolvedor de titulo que para el espanol.
        texto = _extracto_wikt(n, _WIKT_EN)
        cuerpo = _cuerpo_nombre_de_pila(texto, False) if texto else ""
        if cuerpo:
            hallada = {"titulo": n, "host": _WIKT_EN,
                       "extracto": _cabeza(cuerpo, 420)}
    if hallada:
        _cache_put(clave, hallada)
    return hallada


def _clave_wikt(nombre, host=None):
    """Clave de caché para la entrada de Wiktionary (versión 3)."""
    return "wix3_{0}_{1}".format((host or _WIKT_ES).split(".")[0], _norm(nombre))


def _es_el_nombre(objetivo, titulo):
    """Comprueba si el título de Wiktionary corresponde exactamente al antropónimo buscado."""
    _GUIONES = "".join(chr(c) for c in range(0x2010, 0x2016))

    def _llave(texto):
        t = _norm(re.sub(r"\s*\([^)]*\)\s*$", "", texto or ""))
        for g in _GUIONES:
            t = t.replace(g, " ")
        t = t.replace("-", " ")
        return re.sub(r"\s+", " ", t).strip()

    t, n = _llave(titulo), _llave(objetivo)
    return bool(t) and t == n


def _pagina_wikt(nombre, host=None):
    """Devuelve {'titulo': ..., 'extracto': ...} de Wiktionary, o None."""
    host = host or _WIKT_ES
    clave = _clave_wikt(nombre, host)
    cacheado = _cache_get(clave)
    if isinstance(cacheado, dict):
        return {"titulo": cacheado.get("titulo") or "",
                "extracto": cacheado.get("extracto") or ""}

    n = _bonito(nombre)
    if not n:
        return None
    try:
        datos = _api(host, {
            "action": "query", "generator": "search", "gsrsearch": n,
            "gsrlimit": "8", "gsrnamespace": 0, "prop": "extracts",
            "exlimit": "max",
            "explaintext": "1", "redirects": "1",
        })
    except _RateLimit:
        return None

    redir = {r.get("from", ""): r.get("to", "")
             for r in _lista_de(datos, "redirects") if isinstance(r, dict)}
    objetivo = _norm(n)
    mejor_titulo, mejor_texto = "", ""
    for pagina in _paginas(datos):
        titulo = pagina.get("title") or ""
        texto = (pagina.get("extract") or "").strip()
        desde = next((f for f, t in redir.items() if t == titulo), titulo)
        if not _es_el_nombre(objetivo, titulo) and not _es_el_nombre(objetivo, desde):
            continue
        if not mejor_titulo or len(titulo) < len(mejor_titulo):
            mejor_titulo = titulo
        if len(texto) > len(mejor_texto):
            mejor_texto = texto
    if not mejor_titulo:
        return None
    if not mejor_texto:
        # Si el generador no trajo extracto para el título encontrado, se pide directamente.
        mejor_texto = _texto_por_titulo(host, mejor_titulo)
    salida = {"titulo": mejor_titulo, "extracto": mejor_texto}
    _cache_put(clave, salida, ttl=(None if mejor_texto else _TTL_AUSENCIA))
    return salida


def _texto_por_titulo(host, titulo):
    """Extrae el texto de una página por su título en Wiktionary (sin exintro)."""
    try:
        datos = _api(host, {"action": "query", "prop": "extracts",
                            "explaintext": "1", "redirects": "1",
                            "titles": titulo})
    except _RateLimit:
        return ""
    for pagina in _paginas(datos):
        return _sane(pagina.get("extract") or "")
    return ""


def _titulo_wikt(nombre):
    """El titulo REAL de la entrada de es.wiktionary, o el nombre tal cual.

    SOLO LEE LA CACHE y no pide nada a proposito. Antes llamaba a _pagina_wikt(), y
    como _url_wikt() la usa para construir el enlace, la pantalla de "no hay
    articulo" acababa haciendo una peticion de red entero solo para escribir una URL.

    Si el nombre ya se resolvio antes, el titulo esta en la cache y el enlace es el
    bueno ("/wiki/Rubén"). Si no, se cae al nombre tal cual, que es lo unico que se
    sabe sin pedir.
    """
    cacheado = _cache_get(_clave_wikt(nombre))
    if isinstance(cacheado, dict) and cacheado.get("titulo"):
        return cacheado["titulo"]
    return _bonito(nombre)


def _extracto_wikt(nombre, host=None):
    """Solo el texto de _pagina_wikt(), para quien no necesita el titulo."""
    pagina = _pagina_wikt(nombre, host)
    return pagina["extracto"] if pagina else ""


_PLANTILLA = re.compile(
    r"Si puedes,?\s*incorp[oó]rala(?:[^.\n]{0,40})?\.?|ver c[oó]mo\s*$|"
    r"\{\{\s*etimolog[ií]a\s*\}\}", re.I)


def _definicion_wikt(nombre):
    """Obtiene la definición del nombre en español desde es.wiktionary, o cadena vacía."""
    clave = _clave("wiktdef_", nombre)
    cacheado = _cache_get(clave)
    # Guarda de tipo: el llamador realiza operaciones de texto (.strip, regex),
    # por lo que el valor recuperado de caché debe ser una cadena.
    if isinstance(cacheado, str):
        return cacheado

    n = _bonito(nombre)
    if not n:
        return ""
    extracto = _extracto_wikt(n)
    if not extracto.strip():
        return ""
    cuerpo = _cuerpo_nombre_de_pila(extracto, True)
    if not cuerpo:
        cuerpo = _cualquier_apartado_de_nombre(extracto)
    if not cuerpo and not _secciones(extracto, 3) and not _secciones(extracto, 4):
        # Entrada plana, sin apartados: el texto entero es la definición.
        cuerpo = _bloque_idioma(extracto, True) or extracto
    cuerpo = _PLANTILLA.sub("", cuerpo)
    # Quita el lema con género en línea aislada si precede a la definición.
    cuerpo = re.sub(r"(?m)^[ \t]*\S[^\n]{0,80}?[ \t]+(?:f|m|n|c|anim|adj|"
                    r"proper noun)(?:[ \t]+\([^)\n]{0,40}\))?[ \t]*$", " ", cuerpo)
    # Elimina etiquetas de acepción de Wiktionary (Ciudades, Apellido, Regiones...)
    # que aparecen en líneas aisladas y distorsionan la definición del nombre.
    cuerpo = re.sub(r"(?m)^[ \t]*(?:Ciudades?|Paises?|Regiones?|Apellidos?|"
                    r"Sustantivos?|Nombres?|Verbos?|Adjetivos?|Adverbios?|"
                    r"Locuciones?|Onomatopeas?|Antrop[oó]nimos?)[ \t]*$",
                    " ", cuerpo)
    # Cabeceras eliminadas antes de aplanar líneas.
    cuerpo = re.sub(r"(?m)^={2,6}.*?={2,6}\s*", " ", cuerpo)
    cuerpo = _acepciones(cuerpo)
    # Filtra acepciones para conservar las relativas a antropónimos.
    if _PERSONA_DEF.search(cuerpo):
        quedan = [a for a in cuerpo.split(". ") if _PERSONA_DEF.search(a)]
        cuerpo = ". ".join(quedan) if quedan else cuerpo
        if cuerpo and not cuerpo.endswith("."):
            cuerpo += "."

    cuerpo = _sane(cuerpo)
    if len(cuerpo) < _MIN_DEF or not _PERSONA_DEF.search(cuerpo):
        return ""
    _cache_put(clave, cuerpo)
    return cuerpo


def _tiene_nombre_de_pila(extracto, espanol):
    """True si el artículo define el término como nombre de pila y no solo como topónimo."""
    for nivel in (3, 4):
        for titulo, cuerpo in _secciones(extracto, nivel):
            limpio = re.sub(r"\s*\d+\s*$", "", titulo).strip()
            if _es_apartado_de_nombre(limpio, espanol) and _PERSONA.search(cuerpo):
                return True
    return False


def _tiene_etimologia(cuerpo):
    """True si el bloque trae una etimologia de verdad, no un hueco de wiki.

    Se usa para no quedarse con el bloque del idioma pedido cuando ese bloque no
    dice de donde viene el nombre y otro idioma si que lo dice. Se aceptan las dos
    cabeceras (espanola e inglesa) porque un bloque "Italian" en en.wiktionary
    puede traer la suya en ingles.
    """
    for patrones in ((r"Etimolog[ií]a(?:\s*\d+)?",), (r"Etymology(?:\s*\d+)?",)):
        etim = _sane(_seccion(cuerpo, 3, patrones))
        if etim and not _PLACEHOLDER.match(etim) and \
                (len(etim) >= _MIN_ETIM or _ETIM_CLARA.match(etim)):
            return True
    return False


def _bloque_idioma(extracto, espanol):
    """El cuerpo del idioma que interesa.

    En en.wiktionary el bloque "English" de "Sofía" describe la capital bulgara y
    el "Spanish" el nombre. Por eso se busca el espanol primero aunque la ficha se
    pida a la wiki inglesa.

    Cada idioma se busca con sus dos nombres porque las cabeceras estan en el
    idioma de la wiki: en.wiktionary pone "Spanish" y es.wiktionary "Español", y
    aquí se pregunta a las dos por el mismo nombre.
    """
    orden = ((r"Español", r"Spanish"), (r"English", r"Inglés")) if espanol else \
            ((r"English", r"Inglés"), (r"Español", r"Spanish"))
    bloques = _secciones(extracto, 2)
    for nombres in orden:
        for titulo, cuerpo in bloques:
            if any(re.fullmatch(p, titulo.strip(), re.I) for p in nombres) and cuerpo.strip():
                return cuerpo
    return ""


def _bloque_etimologia(extracto, espanol):
    """Como _bloque_idioma(), pero exigiendo que el bloque traiga etimologia.

    Prioriza bloques de idioma que incluyan sección de etimología. Si el idioma
    solicitado carece de ella, recurre a otros bloques disponibles antes de descartar
    el origen.

    Es una funcion aparte y no un cambio en _bloque_idioma() porque esa tambien
    elige el cuerpo de la DEFINICION, y ahi si importa el idioma: devolverle el
    bloque hawaiano de "Manuela" enseñaría la definición hawaiana.

    Devuelve "" si no hay ningun bloque con etimologia, para que _etimologia()
    conserve su recurso al bloque entero.
    """
    orden = ((r"Español", r"Spanish"), (r"English", r"Inglés")) if espanol else \
            ((r"English", r"Inglés"), (r"Español", r"Spanish"))
    bloques = _secciones(extracto, 2)

    def es_del(idiomas, cuerpo):
        return any(any(re.fullmatch(p, t.strip(), re.I) for p in idiomas)
                   for t, c in bloques if c is cuerpo) and cuerpo.strip()

    for idiomas in orden:
        for titulo, cuerpo in bloques:
            if es_del(idiomas, cuerpo) and _tiene_etimologia(cuerpo):
                return cuerpo
    for titulo, cuerpo in bloques:
        if cuerpo.strip() and _tiene_etimologia(cuerpo):
            return cuerpo
    return ""


# Categorías que agrupan los nombres de pila de la Wikipedia en español.
# Sustituyen a prop=links y a list=prefixsearch, cuya ordenación por relevancia
# relega los artículos de antropónimos.
_CATS_DICCIONARIO = ("Categoría:Nombres masculinos", "Categoría:Nombres femeninos")


def _diccionario():
    """Los nombres de pila de la Wikipedia en español, sin repetir.

    Acepta las dos convenciones, con el sufijo " (nombre)" y sin él, que es como
    están la mayoría (Lucía, Javier, Pablo). Deduplica por el nombre limpio: "Lucas"
    y "Lucas (nombre)" son el mismo nombre y no pueden salir dos veces en la lista.
    Cacheado, así que solo se paginan una vez. Si la red falla se devuelve lo que
    hubiera, nunca un error.
    """
    clave = "diccionario_"
    cacheado = _cache_get(clave)
    # Guardia de tipo: asegura que la caché devuelva una lista de nombres.
    if isinstance(cacheado, list):
        return cacheado
    salida = set()
    completo = True
    for cat in _CATS_DICCIONARIO:
        cont = None
        while True:
            params = {"action": "query", "list": "categorymembers", "cmtitle": cat,
                      "cmtype": "page", "cmlimit": "500"}
            if cont:
                params.update(cont)
            try:
                datos = _api(_WIKI_ES, params)
            except _RateLimit:
                completo = False
                break
            if datos is None:
                completo = False
                break
            for m in _lista_de(datos, "categorymembers"):
                if isinstance(m, dict) and m.get("title"):
                    salida.add(m["title"])
            cont = (datos.get("continue") or {})
            if not cont:
                break
    # Fuera las subcategorías, y un nombre por artículo aunque tenga las dos formas.
    limpios, vistos = [], set()
    for t in sorted(salida, key=_norm):
        # El filtro de espacio de nombres descarta títulos con dos puntos (que es lo
        # que separa "Categoría:", "Ayuda:", "Usuario discusión:", "Wikipedia:",
        # "Plantilla:", "Anexo:"...), para evitar páginas ajenas a nombres de pila.
        if ":" in t:
            continue
        # Se exige que la coletilla entre paréntesis contenga "nombre", para
        # aceptar "(nombre propio)" o "(nombre de pila)" y descartar desambiguaciones
        # u otras entidades homónimas sin perder entradas válidas.
        if "(" in t and "nombre" not in _norm(t[t.rfind("("):]):
            continue
        nombre = _sin_sufijo(t)
        k = _norm(nombre)
        if k and k not in vistos:
            vistos.add(k)
            limpios.append(nombre)
    # Solo se cachea si se han leído todas las páginas: si la red falla a mitad,
    # no se debe guardar una lista incompleta durante el tiempo de vida de la caché.
    if completo:
        _cache_put(clave, limpios)
    return limpios


def _sin_sufijo(titulo):
    """'Sofía (nombre)' -> 'Sofía'. También retira '(nombre propio)'.

    Evita que títulos como 'Arturo (nombre propio)' muestren la coletilla
    innecesariamente en el listado.
    """
    t = titulo.strip()
    if not t.endswith(")") or "(" not in t:
        return t
    dentro = t[t.rfind("(") + 1:-1]
    if "nombre" in _norm(dentro):
        return t[:t.rfind("(")].strip()
    return t


def _extracto(host, titulo):
    """El extracto de una página, o ''. Sin exintro para Wiktionary.

    Cacheado por host y título exacto (respetando mayúsculas y minúsculas porque
    en Wiktionary corresponden a páginas distintas con diferente contenido).
    """
    clave = "ext2_{0}_{1}".format(host, (titulo or "").strip())
    cacheado = _cache_get(clave)
    # Quien llama hace .strip() y búsqueda con expresiones regulares: debe ser texto.
    if isinstance(cacheado, str):
        return cacheado
    datos = _api(host, {"action": "query", "prop": "extracts", "explaintext": "1",
                        "titles": titulo})
    salida = ""
    for pagina in _paginas(datos):
        salida = pagina.get("extract") or ""
        break
    # El extracto vacio NO se cachea: si no, un fallo de red se confundiria con
    # "esta pagina no existe".
    if salida:
        _cache_put(clave, salida)
    return salida


def _etimologia(nombre, detalle=None):
    """La cadena etimologica, o "" si no la hay.

    `detalle` es un diccionario opcional donde se deja de dónde salió el texto
    ({"host":..., "titulo":...}). Lo necesita el pie de la ficha: sin eso decía
    "Origen: Wiktionary" sin enlace y sin decir cuál de las dos, y con eso faltan
    dos de los cuatro requisitos de CC BY-SA 4.0 en ese campo.

    Lo que sale en caché es el par (texto, host, título), no solo el texto: sin el host
    el pie de la ficha no puede decir de qué wiktionary salió el texto y acaba firmando
    el inglés como español.

    El español va primero, con el título resuelto por búsqueda: pidiendo "ruben" tal cual a es.wiktionary salía un extracto vacío (la
    página se titula "Rubén"), así que se pensaba que es.wiktionary estaba vacío y
    se iba al inglés. Resuelto el título, la etimología en español aparece para
    Lucía ("Del latín Lucia, masculino Lucius"), Laura, Greta y otros, y solo se
    recurre a en.wiktionary cuando la española no da nada.
    """
    clave = _clave("etim2_", nombre)
    cacheado = _cache_get(clave)
    # El prefijo pasa a etim2_ porque el FORMATO cambia: lo que se guarda ahora es el
    # par (texto, host, titulo) y no solo la cadena. Los ficheros de la etim_ old
    # guardan una cadena suelta, y cacheado["texto"] sobre una cadena reventaria con
    # TypeError. El isinstance de abajo es la red por si vuelve a haber un cambio.
    # Se rellena el detalle con el host y título originales para que la ficha mantenga
    # la atribución de origen y enlace correctos al recuperar de caché.
    if isinstance(cacheado, dict):
        if detalle is not None:
            detalle["origen_host"] = cacheado.get("host") or ""
            detalle["origen_titulo"] = cacheado.get("titulo") or ""
        return cacheado.get("texto") or ""

    n = _bonito(nombre)
    encontrada = ""
    # En caché se guarda el texto junto al host de procedencia para mantener el detalle.
    origen_guardado = {}
    # En en.wiktionary la página en minúscula puede ser distinta de la de mayúscula
    # ("manuela" trae solo español y sin etimología; "Manuela", la entrada completa). Pedir
    # siempre en mayúscula empeora otros casos (greta, marta, alba), así que la mayúscula es
    # un segundo intento, solo si la minúscula no ha dado nada. El orden de la tupla es la
    # regla: el bucle hace break en cuanto acierta.
    for espanol, titulo in ((True, n), (False, n),
                            (False, n[:1].upper() + n[1:])):
        host = _WIKT_ES if espanol else _WIKT_EN
        try:
            extracto = _extracto_wikt(titulo) if espanol else _extracto(host, titulo)
        except _RateLimit:
            break
        if not extracto.strip() or not _tiene_nombre_de_pila(extracto, espanol):
            continue
        # _bloque_etimologia() y no _bloque_idioma(): el bloque del idioma pedido puede
        # no traer apartado de etimologia (en "Manuela" el inglés y el español no lo
        # traen y el hawaiano si), y con el otro se acababa sin origen.
        cuerpo = _bloque_etimologia(extracto, espanol)
        if not cuerpo:
            # Hay entradas sin bloque Español cuya etimología está en español (Greta bajo
            # "== Sueco ==", Pau bajo "== Catalán =="): en wiktionary el encabezado dice de dónde
            # viene el nombre, no en qué idioma está escrito. Solo se usa la entrada entera
            # cuando no hay bloque de idioma.
            cuerpo = extracto
        patrones = ((r"Etymology(?:\s*\d+)?",) if not espanol
                    else (r"Etimolog[ií]a(?:\s*\d+)?",))
        etim = _sane(_seccion(cuerpo, 3, patrones))
        # Si hay más de un párrafo o acepción de etimología en Wiktionary, se toma el
        # primero: el primer sentido corresponde al nombre de pila y evita mezclarlo
        # con etimologías de topónimos homónimos numerados sucesivamente.
        if "\n" in etim:
            primero = next((p for p in etim.split("\n") if p.strip()), "")
            if primero.strip():
                etim = primero.strip()
        # El mínimo de longitud descarta fragmentos espurios, pero se admiten
        # etimologías cortas si comienzan con fórmulas típicas de origen (_ETIM_CLARA).
        if _PLACEHOLDER.match(etim):
            continue
        if len(etim) < _MIN_ETIM and not _ETIM_CLARA.match(etim):
            continue
        encontrada = etim
        # Se firma el título que se ha PREGUNTADO, no el tecleado: si la etimología salió del
        # segundo intento (con mayúscula), el enlace a "manuela" apuntaría a otra página. CC
        # BY-SA pide que el enlace y el nombre sean los de la fuente real.
        firmado = _titulo_wikt(n) if espanol else titulo
        origen_guardado = {"texto": etim, "host": host, "titulo": firmado}
        if detalle is not None:
            # Claves PROPIAS y no "host"/"titulo": el diccionario que se le pasa es la
            # ficha, y esas dos ya tienen el dato de la wikipedia con el que se resolvió
            # el significado. Escribiendo ahí, una etimología hallada machacaba el
            # "Significado: Wikipedia - ..." del pie y ponía "Wiktionary".
            detalle["origen_host"] = host
            detalle["origen_titulo"] = firmado
        break

    # Se guarda el diccionario completo (texto, host, título) para conservar la atribución
    # de origen en la ficha al recuperar desde caché.
    _cache_put(clave, origen_guardado)
    return encontrada


# Wiktionary lista también apodos poco comunes. Van bajo "VARIANTES Y
# DIMINUTIVOS" en la ficha, y alguno (Maruja, Carlangas, Anchoño) es cariñoso pero
# despectivo. Se filtran: la fuente es lo que hay, no necesariamente lo que hay que
# enseñar.
# Fórmulas de inicio habituales en apartados etimológicos de Wiktionary (español e inglés),
# válidas incluso si la cadena no alcanza _MIN_ETIM.
_ETIM_CLARA = re.compile(
    r"^\s*(?:del|de|procede|procedencia|origen|derivad|antrop[oó]nim|"
    r"hipocor|diminut|variante|forma\s|originalmente|top[oó]nim|ep[oó]nim|"
    r"cultismo|culta|prestad|adopta|adapt[oó]rese|"
    r"from|of\s|derived\s)",
    re.I)


# La lista se normaliza al definirse para que case con las cadenas pasadas por _norm,
# que elimina diacríticos (incluida la virgulilla de la eñe).
_APODOS_A_FILTRAR = frozenset(_norm(a) for a in (
    "maruja", "mariquita", "carlangas", "carlanga", "anchoño", "anchoña", "anchuco",
    "toñeque", "toñín", "toñito", "toñuco", "antuco", "choño", "marica", "mari",
))


def _formas_de_la_entrada(nombre):
    """(diminutivos, formas del otro genero), tal y como las da Wiktionary.

    Separa diminutivos reales de las formas del otro género (masculino/femenino),
    presentando cada categoría bajo su propio rótulo.

    Con el título resuelto sale de la caché que _etimologia() ya rellenó, así
    que no cuesta una petición más.
    """
    extracto = _extracto(_WIKT_ES, _titulo_wikt(nombre))
    propio = {_norm(_bonito(nombre))}
    diminutivos, otro, vistos = [], [], set()
    for patron, destino in ((r"Hipocorísticos:\s*([^\n]+)", diminutivos),
                            (r"(?:Masculino|Femenino):\s*([^\n]+)", otro)):
        for m in re.finditer(patron, extracto, re.I):
            for parte in re.split(r"[,;]", _sane(m.group(1))):
                parte = parte.strip(" .")
                if not (2 < len(parte) <= 28):
                    continue
                k = _norm(parte)
                if k in _GENERICOS or k in _APODOS_A_FILTRAR or not k:
                    continue
                # El diminutivo que se busca se descarta a sí mismo; en el otro
                # género no, porque "Petra" -> "Pedro" es justo lo que se quiere
                # enseñar.
                if destino is diminutivos and k in propio:
                    continue
                if k not in vistos:
                    vistos.add(k)
                    destino.append(parte)
    return diminutivos[:12], otro[:12]


def _variantes(nombre):
    """Diminutivos y formas cortas, tal y como las da Wiktionary."""
    clave = _clave("var_", nombre)
    cacheado = _cache_get(clave)
    if isinstance(cacheado, list):
        return cacheado
    diminutivos, _otro = _formas_de_la_entrada(nombre)
    _cache_put(clave, diminutivos)
    return diminutivos


def _otro_genero(nombre):
    """La forma del otro genero: "Cándido" para Cándida, "Pedro" para Petra.

    Tiene su propio apartado diferenciado de las variantes y diminutivos.
    """
    clave = _clave("gen_", nombre)
    cacheado = _cache_get(clave)
    if isinstance(cacheado, list):
        return cacheado
    _diminutivos, otro = _formas_de_la_entrada(nombre)
    _cache_put(clave, otro)
    return otro


# Personas famosas

# Encabezados comunes para listas de personas notables en Wikipedia en inglés.
# Se evalúan permitiendo coletillas posteriores con el nombre del artículo.
_CABECERAS_FAMOSOS = (
    r"(?:List\s+of\s+)?(?:Notable\s+)?[Pp]eople\s+with\s+the\s+(?:given\s+)?names?",
    r"[Pp]eople\s+with\s+this\s+(?:name|given\s+name)",
    r"Notable\s+people",
    r"People\s+named\s+\S+",
    r"Personas\s+con\s+este\s+nombre",
)


def _es_encabezado_de_gente(limpio):
    """Si ese encabezado de nivel 3 es el de la lista de personas de un nombre.

    Compara por el prefijo conocido y admite una terminación posterior siempre
    que corresponda al nombre o variantes del artículo.
    """
    t = (limpio or "").strip("= ").strip()
    for patron in _CABECERAS_FAMOSOS:
        if re.match(patron + r"\s*$", t, re.I):
            return True
        m = re.match(patron + r"\s+(?=\S)", t, re.I)
        if m and _norm(t[m.end():]) != "":
            return True
    return False


# Secciones temáticas en artículos de Wikipedia en inglés donde se listan portadores
# notables cuando no existe una sección única de 'Notable people'.
_CAMPOS_FAMOSOS = (
    "Arts and entertainment", "Arts and entertainments", "Arts and culture",
    "Politics", "Politics and journalism", "Sports", "Science", "Royalty",
    "Other fields", "Others", "Military", "Business", "Academia", "Medicine",
    "Law", "Technology", "Given name", "Female", "Male", "People",
    "Notable male bearers", "Notable female bearers", "Bearers",
)

# Lo que no es una persona que lleva el nombre (desambiguaciones, santos, listas genéricas).
_RUIDO_FAMOSOS = re.compile(
    r"(disambiguation|\bmay refer to\b|see also\b|^saints?\b|^santas?\b|"
    r"^list of\b|^\d+\s*\)|^main article\b|^[\"'(])", re.I)

# Identifica menciones de desambiguación en el encabezado introductorio.
_DESAMBIG = re.compile(r"\b(disambig\w*|may\s+refer\s+to)\b", re.I)


def _lead(extracto):
    """Texto previo al primer encabezado de nivel 2 para identificar el tema principal."""
    corte = re.search(r"\n==[^=]", extracto or "")
    return (extracto or "")[:corte.start()] if corte else (extracto or "")[:600]


def _es_articulo_de_nombre(titulo, extracto):
    """Verifica si el artículo trata sobre el antropónimo y no una desambiguación general."""
    if _DESAMBIG.search(_lead(extracto)):
        return False
    if "(given name)" in (titulo or ""):
        return True
    return bool(_TEXTO_NOMBRE_EN.search(_lead(extracto)))


def _gente_por_campos(extracto):
    """Extrae personas cuando Wikipedia en inglés las distribuye por secciones temáticas.

    Solo se consulta si el artículo trata sobre el nombre y no se localizó
    un encabezado único de 'Notable people'.
    """
    salida = []
    for titulo, cuerpo in _secciones(extracto, 2):
        if re.sub(r"\s*\d+\s*$", "", titulo).strip() not in _CAMPOS_FAMOSOS:
            continue
        for linea in _sane(cuerpo).split("\n"):
            linea = linea.strip(" ;,\t")
            # Descarta subencabezados que terminan en dos puntos.
            if (3 < len(linea) < 160 and not linea.startswith("=")
                    and not linea.endswith(":")
                    and not _RUIDO_FAMOSOS.search(linea)):
                salida.append(linea)
    return salida


def _famosos(nombre):
    """Personas que llevan ese nombre, o [] si no hay lista.

    La lista se extrae de Wikipedia en inglés buscando en el resumen introductorio,
    en secciones dedicadas ('People with the given name') o en apartados temáticos.
    """
    clave = _clave("fam_", nombre)
    cacheado = _cache_get(clave)
    if isinstance(cacheado, list):
        return cacheado

    n = _sin_tilde(_bonito(nombre))
    # Si la API devuelve _RateLimit, se captura para no interrumpir el resto de la ficha.
    try:
        return _famosos_mirando(nombre, n, clave)
    except _RateLimit:
        xbmc.log("{0} Límite de peticiones en la lista de personas".format(_LOG),
                 xbmc.LOGWARNING)
        return []


def _famosos_mirando(nombre, n, clave):
    """Consulta Wikipedia en inglés buscando el artículo por '{nombre} (given name)' o '{nombre}'."""
    datos = None
    salida = []
    for titulo in ("{0} (given name)".format(n), n):
        datos = _api(_WIKI_EN, {"action": "query", "prop": "extracts",
                                "explaintext": "1", "titles": titulo})
        if any((p.get("extract") or "").strip() for p in _paginas(datos)):
            break
    for pagina in _paginas(datos or {}):
        extracto = pagina.get("extract") or ""
        # En el lead la lista viene aplanada y sin viñetas, y no siempre empieza en línea nueva.
        en_linea = re.compile(r"(?:^|[\n.])\s*(?:{0}).{{0,80}}?:\s*".format(
            "|".join(_CABECERAS_FAMOSOS)), re.I)
        m = en_linea.search(extracto)
        if m:
            trozo = extracto[m.end():]
        else:
            # En artículos con subapartados no se corta prematuramente por nivel de encabezado.
            trozo = ""
            for titulo, cuerpo in _secciones(extracto, 2):
                limpio = re.sub(r"\s*\d+\s*$", "", titulo).strip()
                if _es_encabezado_de_gente(limpio):
                    trozo = cuerpo
                    break
        if not trozo.strip():
            # Si no hay encabezado dedicado, busca en secciones temáticas (ver _gente_por_campos).
            trozo = "\n".join(_gente_por_campos(extracto)) if \
                _es_articulo_de_nombre(pagina.get("title", ""), extracto) else ""
        for linea in _sane(trozo).split("\n"):
            linea = linea.strip(" ;,\t")
            # Descarta ruido y entradas que no corresponden a personas reales.
            if (3 < len(linea) < 160 and not linea.startswith("=")
                    and not linea.endswith(":")
                    and not _RUIDO_FAMOSOS.search(linea)):
                salida.append(linea)
        break

    # Si la lista está vacía se cachea con TTL corto (_TTL_AUSENCIA) para evitar
    # peticiones repetidas en consultas consecutivas del mismo nombre.
    _cache_put(clave, salida[:10],
               ttl=(None if salida else _TTL_AUSENCIA))
    return salida[:10]


# Ficha

def _con_progreso(accion, titulo="Diccionario de nombres", cancelable=True):
    """Ejecuta accion(progreso) en un hilo y mantiene vivo el DialogProgress.

    _api() duerme entre peticiones para respetar el límite de Wikimedia. En el
    hilo principal bloquearía la interfaz de Kodi; en un hilo separado, la UI
    continúa respondiendo y DialogProgress permite cancelar la operación.

    El progreso lo pinta el hilo PRINCIPAL: los skins de Kodi no admiten que se
    toquen sus controles desde otro hilo.
    """
    caja = {"error": None, "datos": None, "hecho": False}
    progreso = _Progreso()

    def _trabajo():
        # El techo de la ficha arranca aquí y no en ficha(): es el único sitio por el que
        # pasan todas las consultas, y así el reloj cubre el trabajo entero.
        _plazo_empieza()
        try:
            caja["datos"] = accion(progreso)
        except Exception as e:            # noqa: BLE001 - aquí se atrapa todo a posta
            caja["error"] = e
            # _err(e) y no e: el mensaje de un error de requests lleva la URL completa,
            # y la URL de Wikipedia lleva titles=<nombre buscado>.
            xbmc.log("{0} {1}".format(_LOG, _err(e)), xbmc.LOGERROR)
        except BaseException as e:         # noqa: BLE001
            # Se registra en caja["error"] para no perder excepciones como SystemExit
            # o KeyboardInterrupt en el log de Kodi.
            caja["error"] = e
            xbmc.log("{0} el hilo terminó con {1}".format(_LOG, _err(e)), xbmc.LOGERROR)
        finally:
            # En el finally y no después del except a propósito: si el worker
            # lanzara un BaseException (SystemExit, KeyboardInterrupt), 'hecho'
            # nunca se pondría True y el hilo principal se quedaría dando vueltas
            # con el diálogo modal puesto, sin salida. Con esto siempre termina.
            caja["hecho"] = True

    hilo = threading.Thread(target=_trabajo)
    hilo.daemon = True
    hilo.start()

    pdp = xbmcgui.DialogProgress()
    try:
        # Dentro del try para asegurar que el finally cierra el diálogo si create() falla.
        pdp.create(titulo, "Buscando...")
        while not caja["hecho"]:
            if cancelable:
                try:
                    if pdp.iscanceled():
                        progreso.cancelar()
                        break
                except Exception:
                    pass
            try:
                pct, texto = progreso.estado()
                pdp.update(pct, texto)
            except Exception:
                pass
            time.sleep(0.15)
    finally:
        try:
            pdp.close()
        except Exception:
            pass
        # El diálogo ya se ha cerrado; se concede un breve margen (0.3 s) al worker
        # daemon para finalizar limpiamente sin congelar la interfaz de Kodi.
        hilo.join(timeout=0.3)
    return caja["datos"], caja["error"]


class _Progreso:
    """El estado que va leyendo el hilo principal para pintar el diálogo."""

    def __init__(self):
        self._lock = threading.Lock()
        self._pct = 0
        self._texto = "Buscando..."
        self._cancelado = False

    def advance(self, pct, texto):
        with self._lock:
            self._pct, self._texto = pct, texto

    def estado(self):
        with self._lock:
            return self._pct, self._texto

    def cancelar(self):
        with self._lock:
            self._cancelado = True

    @property
    def cancelado(self):
        with self._lock:
            return self._cancelado


def ficha(nombre, progreso=None):
    """Todo lo que se sabe de un nombre. Si algo falta, el campo va vacio.

    El progreso son los pasos que se pintan: van con un porcentaje, que es lo que
    espera xbmcgui.DialogProgress.update(percent, message). Un MagicMock en los
    tests acepta update("texto") sin quejarse, asi que aqui no se nota: en el Kodi
    de verdad es TypeError y la pantalla se queda en blanco.
    """
    d = {"nombre": _bonito(nombre), "encontrado": False, "cancelado": False,
         "significado": "", "titulo": "", "host": _WIKI_ES, "origen": "",
         "variantes": [], "famosos": [],
         # La versión en inglés va DESPUÉS de la española, como complemento: se enseñan las
         # dos. "Candido" para Candida o "Pedro" para Petra no son variantes sino la forma del
         # otro género, y no tienen que ver con el diminutivo (de Candida es "Candi").
         "otro_genero": [],
         "significado_en": "", "titulo_en": "", "host_en": _WIKI_EN,
         # De qué wiktionary salió la etimología, para el pie con su enlace.
         "origen_host": "", "origen_titulo": "", "origen_url": ""}
    if not d["nombre"]:
        return d

    def _corta(f):
        """Marca la ficha como cancelada y la devuelve.

        Importante que ponga tambien encontrado=False: una ficha a medias no se
        puede enseñar como si estuviera completa, y si no, quien la mire ve
        encontrado=True y cancelado=True a la vez, que no significa nada. Con
        encontrado=False, quien llama vuelve al menu sin decir que el nombre no
        existe, que es lo que había pasado al cancelar.
        """
        f["cancelado"] = True
        f["encontrado"] = False
        paso(100, "Cancelado")
        return f

    def paso(porcentaje, texto):
        """Pinta un paso. True si se ha pulsado cancelar."""
        cancelar = getattr(progreso, "cancelar", None)
        if progreso is None or cancelar is not None:
            if progreso is not None:
                progreso.advance(porcentaje, texto)
            return bool(progreso.cancelado) if progreso is not None else False
        try:
            progreso.update(int(porcentaje), texto)
        except TypeError:
            # Si alguien pluginea un progreso con otra firma, no que se caiga la ficha.
            xbmc.log("{0} update() de progreso con otra firma".format(_LOG), xbmc.LOGDEBUG)
        try:
            return bool(progreso.iscanceled())
        except Exception:
            return False

    if paso(10, "Buscando en Wikipedia..."):
        return _corta(d)
    pagina = _resuelve(d["nombre"])
    if not pagina:
        paso(100, "Sin resultados")
        return d
    # El recorte se aplica aquí antes de cachear para guardar únicamente la porción
    # legible del significado en memoria y disco.
    d.update({"encontrado": True,
              "significado": _significado_legible(pagina["extracto"]),
              "titulo": pagina["titulo"], "host": pagina["host"]})
    try:
        if paso(35, "Buscando la etimología..."):
            return _corta(d)
        d["origen"] = _etimologia(d["nombre"], d)
        if paso(55, "Buscando el significado en inglés..."):
            return _corta(d)
        # El inglés va después del español y no lo sustituye. Antes esto no se
        # pedía para nada, y con la Wikipedia inglesa fuera de la cadena la ficha se
        # quedaba coja: para "Rubén" el texto español es "Nombre de pila de varón",
        # que dice que es un nombre pero no qué significa.
        inglesa = _significado_en(d["nombre"])
        if inglesa:
            d["significado_en"] = inglesa["extracto"]
            d["titulo_en"] = inglesa["titulo"]
            d["host_en"] = inglesa["host"]
        if paso(70, "Buscando las variantes..."):
            return _corta(d)
        d["variantes"] = _variantes(d["nombre"])
        d["otro_genero"] = _otro_genero(d["nombre"])
        if paso(88, "Buscando personas con ese nombre..."):
            return _corta(d)
        d["famosos"] = _famosos(d["nombre"])
    except _RateLimit:
        # Con el limite justo se queda sin etimologia, pero el significado -lo
        # principal- ya esta. Se enseña igual.
        xbmc.log("{0} Límite alcanzado en la ficha".format(_LOG),
                 xbmc.LOGINFO)
    paso(100, "Listo")
    return d


def _url_wiki(d):
    return "https://{0}/wiki/{1}".format(d.get("host") or _WIKI_ES,
                                         urllib.parse.quote(d.get("titulo") or "", safe=""))


def _url_wikt(nombre):
    # El titulo resuelto, no el crudo: con "ruben" el enlace iba a /wiki/ruben, que
    # no existe, mientras que el pie de la ficha si iba a /wiki/Rubén. Incoherente
    # consigo mismo. _titulo_wikt() sale de la cache, asi que no cuesta nada.
    return "https://{0}/wiki/{1}".format(
        _WIKT_ES, urllib.parse.quote(_titulo_wikt(nombre), safe=""))


def _url_btn(nombre):
    return "https://www.behindthename.com/name/{0}".format(
        urllib.parse.quote(_sin_tilde(_bonito(nombre)).lower(), safe=""))


_URL_INE = "https://www.ine.es/uc/zrarulAb"


def _texto_ficha(d):
    """El textviewer de la ficha, con el aviso de licencia al final."""
    l = ["[B][COLOR orchid]{0}[/COLOR][/B]".format(_sane(d["nombre"])), ""]
    if d.get("significado"):
        l += ["[B][COLOR khaki]SIGNIFICADO[/COLOR][/B]", _sane(d["significado"]), ""]
    if d.get("significado_en"):
        # El inglés va DEBAJO y con su propio rótulo, como complemento del español.
        l += ["[B][COLOR khaki]SIGNIFICADO, EN INGLÉS[/COLOR][/B]",
              _sane(d["significado_en"]), ""]
    if d.get("origen"):
        l += ["[B][COLOR khaki]ORIGEN[/COLOR][/B]", _sane(d["origen"]), ""]
    if d.get("origen_host"):
        d["origen_url"] = "https://{0}/wiki/{1}".format(
            d["origen_host"],
            urllib.parse.quote(d.get("origen_titulo") or _bonito(d["nombre"]), safe=""))
    elif d.get("origen"):
        # No se sabe de qué wiktionary salió, pero el texto se enseña y hay que
        # enlazarlo igualmente: sin enlace faltan dos requisitos de CC BY-SA.
        d["origen_url"] = _url_wikt(d["nombre"])
    if d.get("variantes"):
        l += ["[B][COLOR khaki]VARIANTES Y DIMINUTIVOS[/COLOR][/B]",
              ", ".join(d["variantes"]), ""]
    if d.get("otro_genero"):
        # Apartado propio y rótulo diferenciado de variantes y diminutivos.
        l += ["[B][COLOR khaki]FORMA DEL OTRO GÉNERO[/COLOR][/B]",
              ", ".join(d["otro_genero"]), ""]
    if d.get("famosos"):
        l += ["[B][COLOR khaki]PERSONAS QUE LO LLEVAN[/COLOR][/B]",
              "\n".join("[COLOR white]·[/COLOR] " + _sane(p) for p in d["famosos"]), ""]
    if not d.get("significado") and not d.get("origen"):
        l += ["[COLOR grey]No se ha encontrado información de este nombre.[/COLOR]", ""]
    l += ["[COLOR grey]" + "-" * 40 + "[/COLOR]",
          # La fuente hay que nombrarla bien: si el significado vino de
          # es.wiktionary porque es.wikipedia no tenia el articulo, decir
          # "Wikipedia" esta mal y el enlace lleva a otra pagina.
          "[COLOR grey]Significado: {0} - {1}[/COLOR]".format(
              "Wiktionary" if "wiktionary" in (d.get("host") or "") else "Wikipedia",
              _url_wiki(d))]
    if d.get("variantes") or d.get("otro_genero"):
        # Atribución y enlace requeridos por CC BY-SA 4.0 cuando el significado no está presente.
        l.append("[COLOR grey]Variantes: Wiktionary - {0}[/COLOR]".format(
            _url_wikt(d["nombre"])))
    if d.get("famosos"):
        l.append("[COLOR grey]Personas: Wikipedia en inglés - {0}[/COLOR]".format(
            _url_wiki({"host": _WIKI_EN,
                       "titulo": "{0} (given name)".format(
                           _sin_tilde(_bonito(d["nombre"])))})))
    if d.get("significado_en"):
        l.append("[COLOR grey]Significado en inglés: {0} - {1}[/COLOR]".format(
            "Wiktionary" if "wiktionary" in (d.get("host_en") or "") else "Wikipedia",
            _url_wiki({"host": d.get("host_en") or _WIKI_EN,
                       "titulo": d.get("titulo_en") or ""})))
    _oh = d.get("origen_host") or ""
    # La atribución de origen solo se añade si efectivamente se obtuvo la etimología.
    if d.get("origen_url"):
        l.append("[COLOR grey]Origen: Wiktionary ({0}) - {1}[/COLOR]".format(
            "inglés" if _oh.find("en.wiktionary") >= 0 else "español",
            d["origen_url"]))
    l += ["[COLOR grey]Texto adaptado (recortado y filtrado) por EspaTV.[/COLOR]",
          "[COLOR grey]Licencia {0}[/COLOR]".format(_CC)]
    return "\n".join(l)


def _contexto_web(nombre):
    """Los enlaces de la ficha, para el menu contextual."""
    return [
        ("Ver el artículo en Wikipedia", "RunPlugin({0})".format(
            _u(action="open_browser_url", url=_url_wiki({"titulo": nombre, "host": _WIKI_ES})))),
        ("Ver la etimología en Wiktionary", "RunPlugin({0})".format(
            _u(action="open_browser_url", url=_url_wikt(nombre)))),
        ("Ver en Behind the Name", "RunPlugin({0})".format(
            _u(action="open_browser_url", url=_url_btn(nombre)))),
        ("Frecuencia de nombres en España (INE)", "RunPlugin({0})".format(
            _u(action="open_browser_url", url=_URL_INE))),
    ]


# Interfaz

def menu():
    # El punto verde de lo nuevo se apaga aquí, al entrar (ver ui_utils.punto/visto y
    # default._NUEVO_PORT), igual que hace live_tv_menu con el suyo.
    import ui_utils
    ui_utils.visto('nombres')
    h = _h()
    _categoria(h, "Diccionario de nombres")
    _fila(h, "[B][COLOR orchid]Buscar un nombre[/COLOR][/B]",
          _u(action="nombres_buscar"),
          "Escribe un nombre y te dice qué significa, de dónde viene, sus variantes "
          "y quién lo lleva.\n\nSe consulta en vivo en Wikipedia y Wiktionary.")
    # La lista procede de categorías de Wikipedia (existencia de artículo, no frecuencia de uso).
    _fila(h, "[B][COLOR mediumseagreen]Nombres con artículo en Wikipedia[/COLOR][/B]",
          _u(action="nombres_espana"),
          "Los nombres de pila que tienen artículo en la Wikipedia en español.\n"
          "Nombres tradicionales y de otras procedencias.")
    _fila(h, "[B][COLOR khaki]Índice A-Z[/COLOR][/B]",
          _u(action="nombres_indice"),
          "Recorre el diccionario letra a letra.")
    _fila(h, "[B][COLOR skyblue]Consultarlo en la web[/COLOR][/B]",
          _u(action="nombres_enlaces"),
          "Behind the Name, Wikipedia, Wiktionary y el INE, abiertos en el navegador.")
    _cerrar(h)


def _como_error(error):
    """Un error del hilo, envuelto para que la pantalla pueda avisar de él.

    _con_progreso() captura BaseException y la devuelve en `error` (si no, la traza va a
    stderr y en Kodi no llega a kodi.log). Pero las pantallas hacen `raise error` y un
    `except Exception` no la caza: el directorio se quedaría sin cerrar ("No se puede
    resolver el directorio").

    No se arregla cambiando los cinco `except Exception` por `except BaseException`:
    eso haría que el Ctrl+C del usuario se tragase la pantalla y siguiera pintando
    filas. Lo que se quiere es que la pantalla pueda avisar con su propio diálogo, y
    para eso necesita una excepción normal.

    El problema original se conserva dentro, así que el log y el aviso siguen
    diciendo qué pasó de verdad, incluido el nombre de la clase.
    """
    if isinstance(error, Exception):
        return error
    return _FalloDelHilo(error)


class _FalloDelHilo(Exception):
    """Una BaseException (SystemExit, KeyboardInterrupt) que salió del hilo.

    Envuelve la original para poder mostrarla en un diálogo de Kodi, que solo sabe
    manejar Exception. El texto incluye el tipo de la original, porque lo que importa es
    lo que pasó, no la clase de Python.
    """

    def __init__(self, original):
        self.original = original
        Exception.__init__(
            self, "el hilo terminó con {0}: {1}".format(
                type(original).__name__, original))


def buscar():
    """Pide el nombre y ENSEÑA LA EXPLICACIÓN DE INMEDIATO.

    Antes se pintaba una fila con el nombre y había que pulsarla, y al pulsarla se
    volumetricaba TODO otra vez: dos consultas y un paso que no aporta nada. Ahora
    se resuelve una vez, se abre el visor con la ficha y detrás queda el menú de la
    sección.

    Importante, y costó dinero averiguarlo: esta acción la pide Kodi como CARPETA
    (la fila del menú es una carpeta), así que tiene que cerrar el directorio. Sin
    endOfDirectory salía esto en kodi.log:

        CGUIMediaWindow::GetDirectory(...?action=nombres_buscar) failed

    y Kodi abortaba la navegación sin enseñar nada. Las CUATRO salidas de aquí
    (con nombre, teclado cancelado, cancelada a media ficha, nombre inexistente)
    cierran, y hay un test para cada una. Nada de Container.Update: desde dentro
    del directorio que se está rellenando genera un "updating in progress" que
    compite con la propia petición, y también se vio en el log.
    """
    h = _h()
    import ui_utils
    # str(...) or "": ui_utils.get_text devuelve str normalmente, pero si el modo
    # web está puesto devuelve lo que dé web_input, y un None ahí reventaba con
    # AttributeError antes de llegar a la pantalla.
    try:
        q = str(ui_utils.get_text("Buscar un nombre") or "").strip()
    except Exception as e:
        xbmc.log("{0} buscar(): {1}".format(_LOG, e), xbmc.LOGERROR)
        # Se repinta el menú en vez de cerrar con succeeded=False: cerrar en vacío
        # deja la ventana en blanco y parece que la sección está rota. El aviso va
        # aparte, que cerrar no informa de nada.
        xbmcgui.Dialog().ok("Diccionario de nombres",
                            "No se ha podido abrir el teclado.\n\n{0}".format(e))
        menu()
        return
    if not q:
        # Teclado cancelado. Se repinta el menú: cerrar en vacío deja la ventana
        # en blanco y el usuario ve una sección que parece rota.
        menu()
        return
    try:
        d, error = _con_progreso(lambda p: ficha(q, progreso=p))
        if error is not None:
            raise _como_error(error)
        if d is None:
            # None = cancelado sin que el trabajo terminase (una petición en vuelo no se puede
            # cortar). No es «no existe».
            menu()
            return
    except Exception as e:
        xbmc.log("{0} buscar(): {1}".format(_LOG, _err(e)), xbmc.LOGERROR)
        _fallo(h, "No se ha podido consultar Wikipedia.\n\n{0}".format(e), repintar=menu)
        return

    if d.get("encontrado"):
        # El directorio se cierra antes de abrir el visor modal para que la vista quede limpia al salir.
        menu()
        _mostrar(d)
    elif d.get("cancelado"):
        menu()
    else:
        resultados(q, h)            # no existe: se ofrecen los candidatos


def resultados(q, h=None):
    """Solo cuando el nombre NO existe: una fila gris y los candidatos del diccionario.

    Los candidatos se piden ANTES de pintar nada. Antes se pintaba la fila gris y
    luego se pedían, y si eso petaba el except acababa en endOfDirectory(
    succeeded=False) sobre un directorio que ya tenía una fila: Kodi lee
    succeeded=False como "no hay contenido" y en muchas skins vacía la lista.
    """
    if h is None:
        h = _h()
    _categoria(h, "Diccionario de nombres")
    try:
        # También en hilo: _diccionario() pagina dos categorías de 500 con 1 s entre
        # llamadas, y en el hilo principal congelaría la interfaz justo en el camino
        # "he buscado un nombre que no existe".
        candidatos, error = _con_progreso(lambda p: _candidatos(q))
        if error is not None:
            raise _como_error(error)
    except Exception as e:
        xbmc.log("{0} candidatos(): {1}".format(_LOG, _err(e)), xbmc.LOGWARNING)
        # Informa del error real en lugar de mostrar un mensaje genérico de ausencia.
        _fallo(h, "No se ha podido consultar el diccionario de nombres.\n\n{0}"
               .format(e), repintar=menu)
        return
    if candidatos is None:
        # Cancelado: no es que no haya información.
        menu()
        return
    encontrados = candidatos or []
    if not encontrados and _hay_fallo_de_red():
        # Mensaje específico si la causa del listado vacío fue un fallo de conectividad.
        _vacio(h, "No se ha podido consultar Wikipedia. Vuelve a intentarlo.")
        _cerrar(h, cacheToDisc=False)
        return
    if not encontrados:
        # Hay nombres que no están en ninguna fuente en español (en es.wikipedia "martina" es
        # el partido de San Martín). Aunque no haya nada que enseñar, se ofrece dónde mirar.
        _vacio(h, "No hay información de «{0}» en español".format(_bonito(q)))
    else:
        _vacio(h, "No hay artículo de nombre para «{0}». Estos se le parecen:"
                .format(_bonito(q)))
    # Todo el pintado va en un try con finally: una excepción en _fila() dejaría el
    # directorio sin cerrar. Es la pantalla que más filas pinta.
    try:
        for nombre in encontrados:
            _fila(h, "[B]{0}[/B]".format(_sane(nombre)),
                  _u(action="nombres_ver", nombre=nombre),
                  "Pulse para ver su significado y origen.",
                  contexto=_contexto_web(nombre))
        # Siempre una salida a la web, haya candidatos o no. Behind the Name se enlaza
        # pero no se raspa: lo prohibe su titular en /info/copyright.
        _fila(h, "[COLOR skyblue]Ver «{0}» en el Wiktionary[/COLOR]"
              .format(_sane(_bonito(q))),
              _u(action="open_browser_url", url=_url_wikt(q)),
              "Se abre en el navegador.", folder=False)
        _fila(h, "[COLOR skyblue]Frecuencia de los nombres en España (INE)[/COLOR]",
              _u(action="open_browser_url", url=_URL_INE),
              "Datos del Instituto Nacional de Estadística.", folder=False)
    finally:
        # cacheToDisc=False: la caché de directorios de Kodi guarda el resultado de una
        # búsqueda y al volver a entrar se vería el viejo sin llegar a ejecutar el script.
        _cerrar(h, cacheToDisc=False)


def _fallo(h, mensaje, repintar=None, cerrar=None):
    """Avisa del fallo y, si se le pasa, repinta la pantalla en vez de dejarla vacía.

    Si falla una consulta, cerrar con succeeded=False deja una carpeta vacía detrás del
    diálogo de error. Con `repintar` se vuelve a pintar lo que había (el menú de la sección).

    `cerrar` es para quien ya tiene su cierre: `ver()` usa `_cerrador()`, que es
    idempotente, y si además se cerrara aquí se cerraría dos veces el mismo handle.

    `repintar` y `cerrar` son excluyentes: `repintar` vuelve a generar la vista completa
    (incluyendo el cierre del directorio), por lo que ejecutar un cierre posterior
    duplicaría la llamada a endOfDirectory.
    """
    if repintar is not None and cerrar is not None:
        # No es un `assert`: con `python -O` los asserts desaparecen y esto tiene que
        # comprobarse también en producción.
        raise TypeError(
            "_fallo() no admite 'repintar' y 'cerrar' a la vez: 'repintar' ya cierra el "
            "directorio por dentro, y cerrarlo otra vez lo cierra dos veces")
    try:
        xbmcgui.Dialog().notification("Diccionario de nombres", "Ha fallado la consulta",
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
    except Exception:
        pass
    try:
        xbmcgui.Dialog().ok("Diccionario de nombres", mensaje)
    except Exception:
        pass
    if repintar is not None:
        try:
            repintar()
            return
        except Exception:
            # Si repintar falla, se continúa al cierre inferior.
            pass
    if cerrar is not None:
        cerrar()
    elif h >= 0:
        xbmcplugin.endOfDirectory(h, succeeded=False)


def _candidatos(prefijo):
    """Nombres del diccionario que empiezan por el texto escrito.

    Se buscan directamente sobre el diccionario ya descargado para evitar la ordenación
    por relevancia de prefixsearch, que relega los artículos de antropónimos.
    """
    clave = _clave("cand_", prefijo)
    cacheado = _cache_get(clave)
    # Lo que se devuelve tiene que ser una lista: con un "data" numérico, resultados()
    # revienta con TypeError, y con un texto pinta una fila por carácter.
    if isinstance(cacheado, list):
        return cacheado
    p = _norm(_bonito(prefijo))
    salida = []
    if p:
        for titulo in _diccionario():
            limpio = _sin_sufijo(titulo)
            if _norm(limpio).startswith(p):
                salida.append(limpio)
                if len(salida) >= _MAX_CANDIDATOS:
                    break
    _cache_put(clave, salida)
    return salida


def _mostrar(d):
    """Abre el visor con la ficha. No toca el directorio: esto no es un GetDirectory."""
    try:
        xbmcgui.Dialog().textviewer(d["nombre"], _texto_ficha(d))
    except Exception as e:
        # Se usa _texto_ficha() para asegurar la atribución de fuente y licencia CC BY-SA 4.0.
        xbmc.log("{0} textviewer: {1}".format(_LOG, e), xbmc.LOGERROR)
        try:
            cuerpo = _texto_ficha(d)
        except Exception:
            cuerpo = _sane(d.get("significado")) or str(e)
        xbmcgui.Dialog().ok("Diccionario de nombres", cuerpo)


def _cerrar(h, **kwargs):
    """Cierra el directorio, sin succeeded=False nunca.

    Centralizado porque este es el fallo que mas caro sale en todo el addon: una
    accion de carpeta que no llama a endOfDirectory deja la pantalla con "No se
    puede resolver el directorio" y el usuario ve que el boton esta roto.

    OJO, y esto es la mitad del equilibrio: `succeeded=False` aqui esta PROHIBIDO a proposito,
    porque esta funcion la usan las pantallas que pintan filas (espana, lista, resultados,
    menu, indice, enlaces). Sobre un directorio CON filas, `succeeded=False` hace que Kodi
    lo DESCARTE y vuelva al padre, con lo que el aviso que habias pintado desaparece. Para
    el caso contrario, el de una accion que solo abre un dialogo sobre un directorio VACIO,
    hay `_cerrador()`, que si lo usa. No cambiar uno por otro.
    """
    if h >= 0:
        xbmcplugin.endOfDirectory(h, **kwargs)


def _cerrar_sin_cache(h, **kwargs):
    """Cierra un directorio cuyo contenido NO se debe guardar en disco.

    `endOfDirectory()` sin argumentos usa `cacheToDisc=True`, y un aviso de corte de red
    pintado como fila se quedaría cacheado: al volver a abrir la misma letra saldría el aviso
    sin volver a preguntar, y reintentar no serviría.

    Se usa solo en las ramas de fallo de espana() y lista(), donde lo que se guarda es
    "no se ha podido cargar", que es informacion de ESTE momento y no de la fuente. Las
    listas que sí se han cargado se cachean como antes.
    """
    _cerrar(h, cacheToDisc=False, **kwargs)


def _cerrador(h):
    """El cierre de `ver()`: una sola vez, y para VOLVER ATRAS.

    `ver()` es una acción de CARPETA que no pinta ninguna fila: si cierra con
    `succeeded=True`, al cerrar el visor queda debajo una carpeta vacía.

    Aqui `succeeded=False` es lo correcto y no es el fallo que se corrigio antes, porque
    no hay lista que vaciar: no se ha pintado nada. Y no es de memoria, esta en el codigo
    de Kodi: `xbmc/interfaces/generic/ScriptRunner.cpp:164` acaba el script con
    `return !cancelled && !IsCancelled() && IsSuccessful();`, y `IsSuccessful()` es
    justamente este `succeeded`. Ese valor sube por
    `xbmc/filesystem/PluginDirectory.cpp:474` (`bool success = StartScript(...); return
    success;`) hasta el retorno de `GetDirectory`, y en `xbmc/windows/GUIMediaWindow.cpp:849`
    un `GetDirectory` que devuelve false hace `Update(m_history.RemoveParentPath())`, que es
    VOLVER AL DIRECTORIO PADRE. O sea que `succeeded=False` es el mecanismo de "ve a la
    carpeta anterior" en vez de quedarse en una vacia. Es el mismo que usa el propio addon
    en `default.py`, accion `pelis_flix`, que tambien abre una ventana modal encima.

    La diferencia con el bug anterior es exactamente la de las filas: alli el directorio
    tenia el aviso pintado y `succeeded=False` lo hacia desaparecer, y por eso esas
    pantallas siguen usando `_cerrar()`.

    El cierre precede a la apertura del visor para evitar que la ventana quede pendiente,
    y se utiliza cacheToDisc=False al ser un directorio vacío sin contenido persistible.
    """
    ya = [False]

    def _una(cacheToDisc=False):
        if ya[0]:
            return
        if h >= 0:
            xbmcplugin.endOfDirectory(h, succeeded=False, updateListing=False,
                                      cacheToDisc=cacheToDisc)
        # La marca de idempotencia se actualiza tras endOfDirectory para permitir reintentos
        # limpios si la llamada de Kodi lanza una excepción recuperable.
        ya[0] = True

    return _una


def ver(nombre):
    """Abre la ficha de un nombre.

    IMPORTANTE, y ya se rompió una vez: esto es una acción de CARPETA, no de item.
    Las tres pantallas que pintan nombres (los candidatos de resultados(), espana()
    y lista()) crean la fila con _fila(), que deja isFolder=True, así que Kodi pide
    su directorio con un GetDirectory y espera un endOfDirectory. Si no se llama,
    Kodi deja la lista a medias y pone "No se puede resolver el directorio".

    Se queda así, pero con contenido: la lista sigue siendo la de nombres y el
    diálogo va encima.
    Por eso se cierra SIEMPRE, y con `succeeded=False`: este directorio no tiene filas, y
    `succeeded=False` sobre un directorio vacío hace que Kodi vuelva a la carpeta anterior.
    El cierre es `_cerrador()`, no `_cerrar()`.
    """
    h = _h()
    cerrar = _cerrador(h)
    try:
        try:
            d, error = _con_progreso(lambda p: ficha(nombre, progreso=p))
            if error is not None:
                raise _como_error(error)
        except Exception as e:
            xbmc.log("{0} ver(): {1}".format(_LOG, _err(e)), xbmc.LOGERROR)
            cerrar()
            xbmcgui.Dialog().ok("Diccionario de nombres",
                                "No se ha podido consultar Wikipedia.\n\n{0}".format(e))
            return

        # Cancelado: no se dice nada, pero el directorio se cierra igual.
        if d is None or d.get("cancelado"):
            cerrar()
            return

        # El cierre del directorio se realiza antes de abrir el visor modal para restaurar
        # la navegación del contenedor subyacente de forma inmediata.
        cerrar()

        if not d["encontrado"] and _hay_fallo_de_red():
            # Sin el testigo, un corte de red se leería como «la wikipedia no tiene artículo»:
            # _api() devuelve None también con 429, 403 o 5xx.
            #
            # Sin repintar=menu: menu() vuelve a llamar a endOfDirectory sobre el mismo handle y
            # pintaría en un directorio ya cerrado. Se pasa `cerrar`, que es idempotente.
            _fallo(h, "No se ha podido consultar Wikipedia.\n\n"
                    "Puede ser que no haya conexion, o que Wikimedia esté "
                    "limitando las peticiones. Inténtalo en un momento.",
                   cerrar=cerrar)
            return
        if not d["encontrado"]:
            xbmcgui.Dialog().ok(
                "Diccionario de nombres",
                "La Wikipedia en español no tiene artículo de nombre para\n"
                "«{0}».{1}".format(
                    _sane(_bonito(nombre)),
                    "\n\nNo se busca en la Wikipedia en inglés a propósito: te daría "
                    "la explicación en otro idioma.\n\nPrueba con otro, o búscalo "
                    "en la web desde el menú de la sección."))
            return
        _mostrar(d)
    except Exception:
        # Red de seguridad: si algo de lo de dentro revienta (un diálogo que no
        # abre, por ejemplo), el directorio se cierra igualmente. Un GetDirectory
        # sin cerrar es una pantalla colgada con un "No se puede resolver el
        # directorio" que parece que el botón está roto.
        cerrar()
        raise


def espana():
    """Los nombres de pila con artículo en la Wikipedia en español."""
    h = _h()
    # Por el mismo motivo que el rótulo: esto no mide uso en España sino artículos que
    # existen en la wikipedia en español.
    _categoria(h, "Nombres en Wikipedia")
    try:
        # También en hilo: _diccionario() pagina dos categorías de 500, y eso son
        # varias peticiones. En el hilo principal congelarían la interfaz.
        nombres, error = _con_progreso(lambda p: _diccionario())
        if error is not None:
            raise _como_error(error)
        if nombres is None:
            # Cancelado. Antes pintaba "No se ha podido cargar la lista. Comprueba
            # la conexión", que culpa a la red de una pulsación de cancelar.
            _cerrar_sin_cache(h)
            return
    except Exception as e:
        xbmc.log("{0} espana(): {1}".format(_LOG, e), xbmc.LOGERROR)
        # Se pinta el aviso como fila y se cierra con éxito: cerrar con succeeded=False sin
        # filas deja una carpeta vacía detrás del diálogo.
        _vacio(h, "No se ha podido cargar la lista de nombres. {0}".format(e))
        _cerrar_sin_cache(h)
        return
    if not nombres:
        _vacio(h, "No se ha podido cargar la lista. Comprueba la conexión e inténtalo "
                  "de nuevo: no se guarda una lista vacía, así que reintentar sí sirve.")
        # Sin cache: el aviso dice "reintentar sí sirve", y con la caché del directorio
        # no servía, porque la siguiente vez salia el aviso cacheado sin preguntar.
        _cerrar_sin_cache(h)
        return
    for nombre in nombres:
        _fila(h, "[B]{0}[/B]".format(_sane(nombre)),
              _u(action="nombres_ver", nombre=nombre),
              "Pulse para ver su significado y origen.")
    _cerrar(h)


_ABECEDARIO = "ABCDEFGHIJKLMNOPQRSTUVWXYZ"


def indice():
    h = _h()
    _categoria(h, "Índice A-Z")
    for letra in _ABECEDARIO:
        _fila(h, "[B]{0}[/B]".format(letra), _u(action="nombres_lista", letra=letra),
              "Nombres de pila que empiezan por «{0}».".format(letra))
    _cerrar(h)


def lista(letra):
    """Los nombres que empiezan por esa letra, sacados del diccionario completo."""
    h = _h()
    letra = (letra or "").strip().upper()[:1]
    if letra not in _ABECEDARIO:
        letra = "A"
    _categoria(h, "Nombres con {0}".format(letra))
    try:
        todos, error = _con_progreso(lambda p: _diccionario())
        if error is not None:
            raise _como_error(error)
        if todos is None:
            # Cancelado. Antes pintaba "No hay nombres de pila con artículo que
            # empiecen por «L»", que afirma un hecho falso sobre la lengua española.
            _cerrar_sin_cache(h)
            return
    except Exception as e:
        xbmc.log("{0} lista({1}): {2}".format(_LOG, letra, _err(e)), xbmc.LOGERROR)
        _vacio(h, "No se ha podido cargar el índice. {0}".format(e))
        _cerrar_sin_cache(h)
        return
    nombres = [n for n in (todos or []) if _norm(n)[:1] == _norm(letra)]
    if not todos:
        # Si la lista completa no pudo obtenerse, se informa del problema de conexión
        # sin afirmar que no existen nombres con la letra indicada.
        _vacio(h, "No se ha podido cargar el índice. "
                  "Comprueba la conexión e inténtalo de nuevo.")
        _cerrar_sin_cache(h)
        return
    if not nombres:
        _vacio(h, "No hay nombres de pila con artículo que empiecen por "
                  "«{0}».".format(letra))
    for nombre in nombres:
        _fila(h, "[B]{0}[/B]".format(_sane(nombre)),
              _u(action="nombres_ver", nombre=nombre),
              "Pulse para ver su significado y origen.")
    _cerrar(h)


def enlaces():
    h = _h()
    _categoria(h, "Diccionario de nombres en la web")
    webs = (
        ("Behind the Name · significado y origen", "https://www.behindthename.com/names",
         "La web de referencia. Se abre en tu navegador; EspaTV no la consulta."),
        ("Wikipedia · nombres de pila", "https://es.wikipedia.org/wiki/Nombre_de_pila",
         "El artículo del que sale la lista de nombres de esta sección."),
        ("Wiktionary · etimologías", "https://es.wiktionary.org/wiki/Especial:Buscar",
         "Diccionario libre en español."),
        ("INE · nombres más frecuentes en España", _URL_INE,
         "Frecuencias oficiales de recién nacidos, por comunidad autónoma."),
    )
    for etiqueta, url, plot in webs:
        _fila(h, "[B]{0}[/B]".format(_sane(etiqueta)),
              _u(action="open_browser_url", url=url), plot, folder=False)
    _cerrar(h)