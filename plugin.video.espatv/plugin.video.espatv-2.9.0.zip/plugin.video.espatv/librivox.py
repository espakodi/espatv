# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Audiolibros de dominio público vía LibriVox (api.librivox.org)."""
import hashlib
import json
import os
import sys
import time
import urllib.parse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_API = "https://librivox.org/api/feed/audiobooks/"
_HTTP_TIMEOUT = 20
_PAGE_SIZE = 30
_CACHE_TTL = 6 * 3600

_PROFILE = xbmcvfs.translatePath(
    xbmcaddon.Addon("plugin.video.espatv").getAddonInfo('profile')
)
_CACHE_DIR = os.path.join(_PROFILE, 'librivox_cache')


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


def _cache_key(params):
    canonical = urllib.parse.urlencode(sorted(params.items()))
    return hashlib.sha1(canonical.encode('utf-8')).hexdigest()


def _cache_path(key):
    return os.path.join(_CACHE_DIR, key + '.json')


def _cache_get(key):
    path = _cache_path(key)
    try:
        with open(path, 'r', encoding='utf-8') as f:
            obj = json.load(f)
    except (OSError, ValueError):
        return None
    if (time.time() - obj.get('ts', 0)) >= _CACHE_TTL:
        return None
    return obj.get('data')


def _cache_put(key, data):
    try:
        if not os.path.isdir(_CACHE_DIR):
            os.makedirs(_CACHE_DIR, exist_ok=True)
        with open(_cache_path(key), 'w', encoding='utf-8') as f:
            json.dump({'ts': time.time(), 'data': data}, f, ensure_ascii=False)
    except OSError:
        pass


def _api_get(params):
    """Llama al endpoint LibriVox y cachea la respuesta. Devuelve dict o None."""
    request_params = dict(params)
    request_params.update({'format': 'json', 'extended': 1})
    key = _cache_key(request_params)

    cached = _cache_get(key)
    if cached is not None:
        return cached

    try:
        r = requests.get(_API, params=request_params, timeout=_HTTP_TIMEOUT)
        if r.status_code != 200:
            return None
        data = r.json()
    except (requests.RequestException, ValueError):
        return None

    _cache_put(key, data)
    return data


def _format_duration(seconds):
    try:
        s = int(seconds or 0)
    except (TypeError, ValueError):
        return ""
    if s <= 0:
        return ""
    hours, rem = divmod(s, 3600)
    minutes, _ = divmod(rem, 60)
    if hours:
        return "{0}h {1:02d}m".format(hours, minutes)
    return "{0}m".format(minutes)


def _author_label(authors):
    if not isinstance(authors, list):
        return ""
    parts = []
    for entry in authors:
        if not isinstance(entry, dict):
            continue
        name = "{0} {1}".format(
            entry.get('first_name', ''),
            entry.get('last_name', ''),
        ).strip()
        if name:
            parts.append(name)
    return ", ".join(parts)


def _section_duration(section):
    raw = section.get('playtime', 0)
    try:
        return int(raw)
    except (TypeError, ValueError):
        pass
    if isinstance(raw, str) and ':' in raw:
        parts = raw.split(':')
        try:
            nums = [int(p) for p in parts]
        except ValueError:
            return 0
        if len(nums) == 3:
            return nums[0] * 3600 + nums[1] * 60 + nums[2]
        if len(nums) == 2:
            return nums[0] * 60 + nums[1]
    return 0


def librivox_menu():
    handle = int(sys.argv[1])

    li = xbmcgui.ListItem(label="[B][COLOR khaki]Explorar catálogo[/COLOR][/B]")
    li.setArt({'icon': 'DefaultAudio.png'})
    li.setInfo('video', {'plot': "Catálogo completo de audiolibros de dominio público."})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=_u(action="librivox_list", page=1),
        listitem=li, isFolder=True,
    )

    li = xbmcgui.ListItem(label="[B][COLOR lightgreen]Audiolibros en español[/COLOR][/B]")
    li.setArt({'icon': 'DefaultAudio.png'})
    li.setInfo('video', {'plot': "Audiolibros gratuitos en español del archivo público de dominio público."})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=_u(action="archive_audiobooks_es"),
        listitem=li, isFolder=True,
    )

    li = xbmcgui.ListItem(label="[B][COLOR plum]Cuentos y narrativa infantil en español[/COLOR][/B]")
    li.setArt({'icon': 'DefaultAudio.png'})
    li.setInfo('video', {'plot': "Cuentos y literatura infantil en español de dominio público en LibriVox."})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=_u(action="librivox_list", page=1, language="Spanish", genre_id=85),
        listitem=li, isFolder=True,
    )

    li = xbmcgui.ListItem(label="[B][COLOR lightblue]Buscar audiolibro[/COLOR][/B]")
    li.setArt({'icon': 'DefaultMusicSearch.png'})
    li.setInfo('video', {'plot': "Buscar audiolibro por título o autor."})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=_u(action="librivox_search"),
        listitem=li, isFolder=True,
    )

    xbmcplugin.endOfDirectory(handle)


def librivox_list(page=1, title_search="", author_search="", language="Spanish", genre_id=""):
    handle = int(sys.argv[1])
    try:
        page_num = max(1, int(page))
    except (TypeError, ValueError):
        page_num = 1

    params = {
        'limit': _PAGE_SIZE,
        'offset': (page_num - 1) * _PAGE_SIZE,
    }
    if language:
        params['language'] = language
    if title_search:
        params['title'] = title_search
    if author_search:
        params['author'] = author_search
    if genre_id:
        params['genre_id'] = int(genre_id)

    data = _api_get(params)
    books = (data or {}).get('books') or []

    if not books:
        if page_num == 1:
            xbmcgui.Dialog().notification(
                "EspaTV", "Sin resultados", xbmcgui.NOTIFICATION_INFO, 2500,
            )
        xbmcplugin.endOfDirectory(handle)
        return

    for book in books:
        book_id = book.get('id', '')
        if not book_id:
            continue
        title = book.get('title', 'Sin título')
        author = _author_label(book.get('authors'))
        duration = _format_duration(book.get('totaltimesecs', 0))

        label_parts = ["[B]{0}[/B]".format(title)]
        if author:
            label_parts.append("[I]{0}[/I]".format(author))
        if duration:
            label_parts.append("[{0}]".format(duration))
        label = "  —  ".join(label_parts) if author else "  ".join(label_parts)

        plot_lines = [title]
        if author:
            plot_lines.append(author)
        description = (book.get('description') or '').strip()
        if description:
            plot_lines.append(description)

        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultAudio.png', 'thumb': 'DefaultAudio.png'})
        li.setInfo('video', {'plot': "\n\n".join(plot_lines)})
        xbmcplugin.addDirectoryItem(
            handle=handle,
            url=_u(action="librivox_book", book_id=str(book_id), title=title),
            listitem=li, isFolder=True,
        )

    if len(books) >= _PAGE_SIZE:
        next_kw = {'action': "librivox_list", 'page': page_num + 1}
        if language:
            next_kw['language'] = language
        if title_search:
            next_kw['title_search'] = title_search
        if author_search:
            next_kw['author_search'] = author_search
        if genre_id:
            next_kw['genre_id'] = genre_id
        li = xbmcgui.ListItem(
            label="[B][COLOR yellow]» Página siguiente ({0})[/COLOR][/B]".format(page_num + 1)
        )
        li.setArt({'icon': 'DefaultFolderBack.png'})
        xbmcplugin.addDirectoryItem(
            handle=handle, url=_u(**next_kw), listitem=li, isFolder=True,
        )

    xbmcplugin.endOfDirectory(handle)


def librivox_book(book_id, title=""):
    handle = int(sys.argv[1])
    if not book_id:
        xbmcplugin.endOfDirectory(handle)
        return
    if title:
        try:
            xbmcplugin.setPluginCategory(handle, title)
        except Exception:
            pass

    data = _api_get({'id': book_id})
    books = (data or {}).get('books') or []
    if not books:
        xbmcgui.Dialog().notification(
            "EspaTV", "Audiolibro no disponible",
            xbmcgui.NOTIFICATION_WARNING, 2500,
        )
        xbmcplugin.endOfDirectory(handle)
        return

    sections = books[0].get('sections') or []
    if not sections:
        xbmcgui.Dialog().notification(
            "EspaTV", "Sin capítulos disponibles",
            xbmcgui.NOTIFICATION_INFO, 2500,
        )
        xbmcplugin.endOfDirectory(handle)
        return

    for section in sections:
        listen_url = section.get('listen_url', '')
        if not listen_url:
            continue
        sec_title = section.get('title', 'Capítulo')
        section_number = section.get('section_number', '')
        if section_number:
            label = "[B]{0}.[/B] {1}".format(section_number, sec_title)
        else:
            label = sec_title
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultAudio.png'})
        li.setInfo('music', {
            'title': sec_title,
            'duration': _section_duration(section),
        })
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle=handle, url=listen_url, listitem=li, isFolder=False,
        )

    xbmcplugin.endOfDirectory(handle)


def librivox_search():
    handle = int(sys.argv[1])
    keyboard = xbmc.Keyboard("", "Buscar audiolibro (título)")
    keyboard.doModal()
    if not keyboard.isConfirmed():
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    query = keyboard.getText().strip()
    if not query:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    xbmcplugin.endOfDirectory(handle, succeeded=False)
    xbmc.executebuiltin("Container.Update({0})".format(
        _u(action="librivox_list", page=1, title_search=query)
    ))
