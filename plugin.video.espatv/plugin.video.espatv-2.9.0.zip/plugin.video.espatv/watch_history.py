# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Historial de reproducción de vídeos de Dailymotion."""
import datetime
import json
import os
import sys
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_FILENAME = "watch_history.json"
_MAX      = 100


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


def _profile():
    return xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))


def _load():
    fp = os.path.join(_profile(), _FILENAME)
    if not os.path.exists(fp):
        return []
    try:
        with open(fp, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return []


def _save(history):
    p = _profile()
    if not os.path.exists(p):
        os.makedirs(p)
    fp = os.path.join(p, _FILENAME)
    try:
        with open(fp, 'w', encoding='utf-8') as f:
            json.dump(history, f, ensure_ascii=False)
    except OSError:
        pass


def add(vid, title, thumb="", duration=0):
    if not vid:
        return
    history = _load()
    history = [e for e in history if e.get("vid") != vid]
    history.insert(0, {"vid": vid, "title": title, "thumb": thumb,
                        "duration": duration, "watched_at": int(time.time())})
    _save(history[:_MAX])


def get_watched_ids():
    return set(e.get("vid", "") for e in _load())


def show():
    h = int(sys.argv[1])
    history = _load()
    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _ico(name, fallback):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    if history:
        li = xbmcgui.ListItem(label="[B][COLOR gold]Lo más visto[/COLOR][/B]")
        li.setArt({'icon': _ico('top_watched.png', 'DefaultMusicTop100.png')})
        li.setInfo('video', {'plot': "Acceso rápido a tus 20 vídeos más recientes."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="most_watched"), listitem=li, isFolder=True)
        li = xbmcgui.ListItem(label="[COLOR red][B]Borrar todo el historial de visionado[/B][/COLOR]")
        li.setArt({'icon': _ico('adv_borrar.png', 'DefaultIconError.png')})
        li.setInfo('video', {'plot': "Tienes {0} vídeos en el historial.".format(len(history))})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="clear_watch_history"), listitem=li, isFolder=False)
    if not history:
        li = xbmcgui.ListItem(label="[COLOR gray]No has reproducido ningún vídeo aún[/COLOR]")
        li.setArt({'icon': _ico('info.png', 'DefaultIconInfo.png')})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return
    xbmcplugin.setContent(h, 'videos')
    ai = xbmcaddon.Addon().getAddonInfo('icon')
    for entry in history:
        vid     = entry.get('vid', '')
        vt      = entry.get('title', 'Video')
        dth     = entry.get('thumb', '') or ai
        du      = entry.get('duration', 0)
        try:
            du = int(du)
        except (ValueError, TypeError):
            du = 0
        watched_at = entry.get('watched_at', 0)
        try:
            date_str = datetime.datetime.fromtimestamp(watched_at).strftime("%d/%m/%Y %H:%M")
        except (ValueError, TypeError):
            date_str = ""
        li = xbmcgui.ListItem(label="[COLOR lime][V][/COLOR] {0}".format(vt))
        li.setArt({'thumb': dth, 'icon': dth})
        plot = "Visto: {0}".format(date_str)
        if du:
            plot += "\nDuración: {0}m {1}s".format(du // 60, du % 60)
        li.setInfo('video', {'title': vt, 'plot': plot, 'duration': du})
        li.setProperty("IsPlayable", "true")
        cm = []
        if vid:
            cm.append(("Descargar Video",        "RunPlugin({0})".format(_u(action='download_video', vid=vid, title=vt))))
            cm.append(("Eliminar del historial",  "RunPlugin({0})".format(_u(action="del_watch_entry", url=vid))))
            cm.append(("Abrir en navegador",      "RunPlugin({0})".format(_u(action="dm_open_browser", url=vid))))
            cm.append(("Copiar URL",              "RunPlugin({0})".format(_u(action='copy_url', url="https://www.dailymotion.com/video/" + str(vid)))))
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="pv", vid=vid), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def del_entry(vid):
    if not vid:
        return
    history = _load()
    _save([e for e in history if e.get("vid") != vid])
    xbmc.executebuiltin("Container.Refresh")


def clear():
    if xbmcgui.Dialog().yesno("EspaTV", "¿Borrar todo el historial de visionado?"):
        _save([])
        xbmc.executebuiltin("Container.Refresh")
