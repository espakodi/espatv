# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Internet Archive: películas de dominio público reproducibles directamente."""
import json
import os
import sys
import time
import urllib.parse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from _user_agents import desktop_headers as _dh, ACCEPT_HTML

_SEARCH_API   = "https://archive.org/advancedsearch.php"
_METADATA_API = "https://archive.org/metadata/{id}"
_THUMB_URL    = "https://archive.org/services/img/{id}"
_DOWNLOAD_URL = "https://archive.org/download/{id}/{file}"
_TTL          = 6 * 3600
_PAGE_SIZE    = 30

_HEADERS = _dh(accept=ACCEPT_HTML, referer="https://archive.org/")

_CATEGORIES = [
    ("Cine en español",            "mediatype:movies AND language:spa AND subject:feature"),
    ("Cine clásico (1920-1970)",   "mediatype:movies AND year:[1920 TO 1970] AND subject:feature"),
    ("Cine mudo",                  'mediatype:movies AND subject:"silent film"'),
    ("Documentales en español",    "mediatype:movies AND subject:documentary AND language:spa"),
    ("Film noir y thriller clásico", 'mediatype:movies AND subject:"film noir"'),
]

_AUDIOBOOKS_ES_CATEGORIES = [
    ("Lecturas dramatizadas en español",  "mediatype:audio AND language:spa AND subject:audiobook"),
    ("Literatura clásica española",
     "mediatype:audio AND language:spa AND (subject:literatura OR subject:cervantes OR subject:lorca)"),
    ("Poesía y teatro en español",
     "mediatype:audio AND language:spa AND (subject:poetry OR subject:teatro OR subject:poesia)"),
    ("Otros audiolibros en español",
     "mediatype:audio AND language:spa NOT collection:librivoxaudio"),
    ("Cuentos infantiles en español (DP)",
     "mediatype:audio AND language:spa AND (subject:cuentos OR subject:infantil OR subject:niños)"),
    ("Música y BSO en español (DP)",
     'mediatype:audio AND language:spa AND (subject:musica OR subject:soundtrack OR subject:"banda sonora")'),
]

_AUDIO_FORMAT_PRIORITY = [
    'VBR MP3', '64Kbps MP3', '128Kbps MP3',
    'MP3', 'Ogg Vorbis', 'Flac',
]

_DOC_ES_CATEGORIES = [
    ("Todos los documentales en español", "mediatype:movies AND subject:documentary AND language:spa"),
    ("Historia de España",                'mediatype:movies AND language:spa AND (subject:"historia de españa" OR title:("historia de españa"))'),
    ("Naturaleza y fauna ibérica",        'mediatype:movies AND language:spa AND (subject:naturaleza OR subject:wildlife OR subject:fauna)'),
    ("Ciencia y divulgación",             'mediatype:movies AND language:spa AND (subject:ciencia OR subject:science OR subject:divulgacion)'),
    ("Cultura y arte",                    'mediatype:movies AND language:spa AND (subject:cultura OR subject:arte OR subject:art)'),
    ("Guerra Civil Española",             'mediatype:movies AND language:spa AND (subject:"guerra civil" OR title:("guerra civil"))'),
    ("Sociedad y política",               'mediatype:movies AND language:spa AND (subject:sociedad OR subject:politica)'),
    ("Instituto Cervantes y archivo cultural",
     'mediatype:movies AND language:spa AND (subject:cervantes OR collection:cervantes OR subject:"instituto cervantes")'),
]

_FELIX_YT = [
    # Episodios numerados
    {"yt_id": "bW-u_hpJTXQ", "name": "Capítulo 1"},
    {"yt_id": "tyQVYOC3Z8g", "name": "Capítulo 2 — El azote del sol"},
    {"yt_id": "FwHMyGKRZfg", "name": "Capítulo 2 — El azote del sol (versión alternativa)"},
    {"yt_id": "iIdqxMTFXRk", "name": "Capítulo 3 — Operación anaconda"},
    {"yt_id": "ORglX50ONTQ", "name": "Capítulo 3 — El Hosquillo (4K Dolby 5.1)"},
    {"yt_id": "6iifho0jw_8", "name": "Capítulo 4 — El rodeo de los chigüires"},
    {"yt_id": "BS-Zyhrt8JQ", "name": "Capítulo 5 — La selva virgen venezolana"},
    {"yt_id": "yN6fLTJXNTY", "name": "Capítulo 5 — La selva virgen venezolana (1974)"},
    {"yt_id": "mDYfSbnKTHw", "name": "Capítulo 6 — Los yanomamos, un pueblo de la selva"},
    {"yt_id": "B8gSXjAmZcU", "name": "Capítulo 7 — En busca de los indios del Alto Orinoco"},
    {"yt_id": "80HX5kIL0t4", "name": "Capítulo 8 — El mundo del jaguar"},
    {"yt_id": "2GJHDeqao8Y", "name": "Capítulo 9 — El pueblo bravo"},
    {"yt_id": "84paPTXwPsQ", "name": "Capítulo 10"},
    {"yt_id": "avC1X0yBknM", "name": "Capítulo 11 — La nutria gigante"},
    {"yt_id": "SwCcDTIQ-Dk", "name": "Capítulo 12 — La montaña sagrada"},
    {"yt_id": "6BrSlt7JGRw", "name": "Capítulo 13 — Los llanos de Venezuela"},
    {"yt_id": "eYtV2N33Ovs", "name": "Capítulo 14 — El paraíso de las aves"},
    {"yt_id": "vPhsygQR8Xo", "name": "Capítulo 15 — El mundo del coral"},
    {"yt_id": "MkngIaasO4w", "name": "Capítulo 16 — La isla de los alcatraces"},
    {"yt_id": "X-BhRnr3ePA", "name": "Capítulo 17 — Mi amiga la nutria"},
    {"yt_id": "pq9V1eMPJyY", "name": "Capítulo 18 — El Edén perdido"},
    {"yt_id": "BXN8EbAyGGM", "name": "Capítulo 18 — El Valle de las Águilas (4K Dolby 5.1)"},
    {"yt_id": "ajifYiX3AEY", "name": "Capítulo 19 — Los prisioneros del bosque I"},
    {"yt_id": "44OzqnsV9Qg", "name": "Capítulo 20 — Los prisioneros del bosque II"},
    {"yt_id": "WICvS_oFSPU", "name": "Capítulo 21 — Los señores del bosque I"},
    {"yt_id": "IGsbIcTFN7w", "name": "Capítulo 22 — Los señores del bosque II"},
    {"yt_id": "nIgwdIxUaBc", "name": "Capítulo 23 — Los pequeños matadores I"},
    {"yt_id": "0TQ_Y3FenA4", "name": "Capítulo 24 — Los pequeños matadores II"},
    {"yt_id": "HcwN0ZTgGkA", "name": "Capítulo 25 — El buitre negro I"},
    {"yt_id": "vjdWL-ZMxpo", "name": "Capítulo 27 — Las cigüeñas I"},
    {"yt_id": "EIwlCvPuW1I", "name": "Capítulo 28 — Las cigüeñas II"},
    {"yt_id": "QenT2libnec", "name": "Capítulo 29 — El águila perdicera I"},
    {"yt_id": "F32BxXwU6Qo", "name": "Capítulo 30 — El águila perdicera II"},
    {"yt_id": "fFWbv-8gt00", "name": "Capítulo 31 — El macho montés I"},
    {"yt_id": "FOQ3NJPkf44", "name": "Capítulo 32 — El macho montés II"},
    {"yt_id": "nOMnmVgkB3c", "name": "Capítulo 33 — El pirata de la espesura"},
    {"yt_id": "bWW1QXyVdAA", "name": "Capítulo 34 — Las tablas de Daimiel I"},
    {"yt_id": "IR_Lk1wjEvY", "name": "Capítulo 35 — Las tablas de Daimiel II"},
    {"yt_id": "_LMIccjvUPw", "name": "Capítulo 36 — El proyectil viviente"},
    {"yt_id": "1iM_i5vN2cY", "name": "Capítulo 37 — El valle de las águilas"},
    {"yt_id": "FA4ayfuqsQg", "name": "Capítulo 38 — Taiga, el azor"},
    {"yt_id": "4mTdVRERKSM", "name": "Capítulo 39 — El cervatillo I"},
    {"yt_id": "DdODjUj4eOM", "name": "Capítulo 40 — El cervatillo II"},
    {"yt_id": "2lu70f5uHp8", "name": "Capítulo 41 — El Hosquillo"},
    {"yt_id": "Qsv7-XwRlGE", "name": "Capítulo 42 — Altanería I"},
    {"yt_id": "40HVuDDLLL8", "name": "Capítulo 43 — Altanería II"},
    {"yt_id": "1i283ZXHToQ", "name": "Capítulo 44 — El alcaudón"},
    {"yt_id": "9Z4zVADE7Gc", "name": "Capítulo 45 — Los últimos buitres de Europa"},
    {"yt_id": "mA8jqyxyjrI", "name": "Capítulo 46 — El águila real I"},
    {"yt_id": "XcFsMAPPX7w", "name": "Capítulo 47 — El águila real II"},
    {"yt_id": "UlA0RGT6X4M", "name": "Capítulo 48 — El lirón careto I"},
    {"yt_id": "HbHY39RjQD0", "name": "Capítulo 49 — El lirón careto II"},
    {"yt_id": "4bLO8d0e9O4", "name": "Capítulo 50 — El buitre leonado I"},
    {"yt_id": "BQchrLgq7dk", "name": "Capítulo 51 — El buitre leonado II"},
    {"yt_id": "Lj0Fc5UFev8", "name": "Capítulo 52 — Aves viajeras"},
    {"yt_id": "Ox02OTgmhAs", "name": "Capítulo 53 — El abejaruco I"},
    {"yt_id": "a05_TnJyxtQ", "name": "Capítulo 54 — El abejaruco II"},
    {"yt_id": "KWmTwVcDJg8", "name": "Capítulo 55 — El lobo"},
    {"yt_id": "eX-s3zGdFdc", "name": "Capítulo 56 — La olimpiada zoológica I"},
    {"yt_id": "B3vUXO9zJDI", "name": "Capítulo 57 — La olimpiada zoológica II"},
    {"yt_id": "iT0SfJv4qVc", "name": "Capítulo 58 — Los pájaros carpinteros I"},
    {"yt_id": "BDnUXBzuhr8", "name": "Capítulo 59 — Los pájaros carpinteros II"},
    {"yt_id": "zN3XZeciXik", "name": "Capítulo 60 — Los pájaros carpinteros III"},
    {"yt_id": "R_7mIsGz0P4", "name": "Capítulo 61 — El jabalí I"},
    {"yt_id": "R5TrNwHQHmY", "name": "Capítulo 62 — El jabalí II"},
    {"yt_id": "9ZYADNK4VlA", "name": "Capítulo 63 — El buitre sabio"},
    {"yt_id": "OP8TURcbRiQ", "name": "Capítulo 64 — La bella matadora"},
    {"yt_id": "rYtjDMl2NZQ", "name": "Capítulo 66 — El juego de la caza II"},
    {"yt_id": "NDL8T6YSnRk", "name": "Capítulo 67 — El cazador social"},
    {"yt_id": "EfKc6rZQiGE", "name": "Capítulo 68 — El clan familiar"},
    {"yt_id": "oLznBZ8MB4A", "name": "Capítulo 69 — Los matadores inocentes"},
    {"yt_id": "ykAsAx72yLw", "name": "Capítulo 70 — El cormorán"},
    {"yt_id": "qhVsTse98mY", "name": "Capítulo 71 — Los córvidos I"},
    {"yt_id": "5M_HQAfeYU4", "name": "Capítulo 72 — Los córvidos II"},
    {"yt_id": "OaEIL0H2Guo", "name": "Capítulo 73 — Las Rapaces Ibéricas"},
    {"yt_id": "zuzRR5bzdmo", "name": "Capítulo 74 — El Martín Pescador"},
    {"yt_id": "_RL3EaMqup4", "name": "Capítulo 75 — La perdiz roja"},
    {"yt_id": "Hb0HOM67Ea8", "name": "Capítulo 76 — Los roedores I"},
    {"yt_id": "3hn8gLOwWkY", "name": "Capítulo 77 — Los roedores II"},
    {"yt_id": "pxhi1qqcyMs", "name": "Capítulo 80 — La conquista del agua II"},
    {"yt_id": "gtKNsQyl_gA", "name": "Capítulo 83 — Al borde de la extinción I"},
    {"yt_id": "xQOeOsVTX1M", "name": "Capítulo 85 — Al borde de la extinción III"},
    {"yt_id": "rQCy1iNwr4w", "name": "Capítulo 86 — El río viviente I"},
    {"yt_id": "2smjnZiBfE0", "name": "Capítulo 87 — El río viviente II"},
    {"yt_id": "1b1XuZmGaQM", "name": "Capítulo 88 — Operación zorro I"},
    {"yt_id": "HCKJQq3oFB4", "name": "Capítulo 89 — Operación zorro II"},
    {"yt_id": "yBR91XWzkzA", "name": "Capítulo 90 — El águila Imperial I"},
    {"yt_id": "SBS-c5AaeUM", "name": "Capítulo 91 — El águila Imperial II"},
    {"yt_id": "19qHUd064Gk", "name": "Capítulo 92 — Parque nacional de Doñana I"},
    {"yt_id": "mzDs2n3Gb3Q", "name": "Capítulo 93 — Parque Nacional de Doñana II"},
    {"yt_id": "2zix-deVVng", "name": "Capítulo 94 — Parque nacional de Doñana III"},
    {"yt_id": "5-KFC29KEfU", "name": "Capítulo 95 — Parque nacional de Doñana IV"},
    {"yt_id": "pGc5j_j-pfU", "name": "Capítulo 96 — Las sierras de Cazorla y Segura I"},
    {"yt_id": "SjflEL4hOXE", "name": "Capítulo 97 — Las sierras de Cazorla y Segura II"},
    {"yt_id": "LB3duUd2Tx8", "name": "Capítulo 98 — El último lince"},
    {"yt_id": "Iy0nO29V9yE", "name": "Capítulo 99 — Pequeños cazadores I"},
    {"yt_id": "_oAPjn03y1g", "name": "Capítulo 100 — Pequeños cazadores II"},
    {"yt_id": "Bf0HRrPypK8", "name": "Capítulo 101 — Pequeños cazadores III"},
    {"yt_id": "ioI9a9pomyk", "name": "Capítulo 102 — Al borde del exterminio"},
    {"yt_id": "h22k5agYt8k", "name": "Capítulo 103 — Aves Esteparias I"},
    {"yt_id": "_z5v9_8ebPE", "name": "Capítulo 105 — Aves Esteparias III"},
    {"yt_id": "6Pn-DysRitw", "name": "Capítulo 106 — Rapaces nocturnas I"},
    {"yt_id": "HD2XowLdbvo", "name": "Capítulo 107 — Rapaces nocturnas II"},
    {"yt_id": "AvoW0fbNPwI", "name": "Capítulo 109 — El invierno en Canadá"},
    {"yt_id": "Ma_UzeIYmr8", "name": "Capítulo 110 — Aventura en Canadá"},
    {"yt_id": "eTa15H0rNBw", "name": "Capítulo 112 — El cementerio helado"},
    {"yt_id": "xCZbGtH0F1w", "name": "Capítulo 114 — Kluane"},
    {"yt_id": "duM0yidtNxY", "name": "Capítulo 115 — Gran fauna canadiense I"},
    {"yt_id": "3R4cBpBFnko", "name": "Capítulo 116 — Gran fauna canadiense II"},
    {"yt_id": "tQQBC7hl64I", "name": "Capítulo 117 — Operación peregrino"},
    {"yt_id": "iApRksl26K8", "name": "Capítulo 118 — Operación rescate"},
    {"yt_id": "z4T_ZYTCiI4", "name": "Capítulo 120 — El lago de los castores"},
    {"yt_id": "9J5kTWyE-2o", "name": "Capítulo 121 — Iditarod, 1000 millas sobre hielo I"},
    {"yt_id": "62HGvqweiAc", "name": "Capítulo 122 — Iditarod, 1000 millas sobre hielo II"},
    # Especiales, recopilaciones y extras
    {"yt_id": "GiaQu0eOjKU", "name": "Intro HD"},
    {"yt_id": "b9mMSstsg6U", "name": "Intro (versión alternativa)"},
    {"yt_id": "C_a14SQu9-o", "name": "Prisioneros del Bosque"},
    {"yt_id": "13Sm8MzkAQU", "name": "El Hombre y el Lobo"},
    {"yt_id": "UOCB5e__AOc", "name": "El lobo (versión alternativa)"},
    {"yt_id": "PT-AQcGNN7I", "name": "El lobo II"},
    {"yt_id": "VTeRJguWvr8", "name": "El lobo III"},
    {"yt_id": "7nni6fY_vWQ", "name": "El lobo IV"},
    {"yt_id": "pUUP21Tyt1c", "name": "Fauna Ibérica — El Buitre Negro"},
    {"yt_id": "UQFW-gBYP0k", "name": "Serie africana — El león I"},
    {"yt_id": "JzwKYIGPwfA", "name": "Serie Fauna Piscinera"},
    {"yt_id": "Kr8URNM0yNU", "name": "Fauna ibérica 2 (HD)"},
    {"yt_id": "QCCaXPdhgj8", "name": "El Lago de los Castores (1980)"},
    {"yt_id": "MlXg0Zxx01I", "name": "Recopilación"},
    {"yt_id": "Dn1wX2wQnsY", "name": "Final del último episodio"},
    {"yt_id": "BbnS7DjqMx8", "name": "El Concejal ibérico"},
    {"yt_id": "x8yZtCO1b3s", "name": "Lobos vs buitres"},
    {"yt_id": "7Mb3pPPZEN0", "name": "El Hombre y la Tierra en La 2 (promo)"},
    {"yt_id": "n1-AVAk2u5c", "name": "Regresa El Hombre y la Tierra en TVE"},
    {"yt_id": "UHYy5UXref4", "name": "Biografía de Félix Rodríguez de la Fuente (2ª parte)"},
    # Música y sintonías
    {"yt_id": "slq0z87-BFM", "name": "Banda sonora original"},
    {"yt_id": "EpgLSLH3QgM", "name": "Sintonía — Antón García Abril (versión completa, 1974)"},
    {"yt_id": "cSjN0fewEwg", "name": "Sintonía — Remasterizada 4K UHD"},
    {"yt_id": "xw22aHSPIJA", "name": "Cabecera y sintonía 1974-1981"},
    {"yt_id": "JlRfQ4WKvdI", "name": "Sintonía TV"},
    {"yt_id": "NguJXTRbJJQ", "name": "Tono para móvil"},
    # Divulgación y homenajes
    {"yt_id": "Ot4ihHDvLCc", "name": "La evolución del ser humano en 15 minutos"},
    {"yt_id": "qxr3wz_dMTc", "name": "Analizando El Hombre y la Tierra"},
    {"yt_id": "8shFuahwaP4", "name": "Recuerdos de El hombre y la tierra"},
    {"yt_id": "T3lrH7aYZB4", "name": "Sentir El Hombre y la Tierra en el Barranco del Río Dulce"},
    {"yt_id": "PSg_H2rAN7Y", "name": "Intro stop motion"},
    {"yt_id": "-tjlRwErE-A", "name": "Parodia — El chochín y el pardillo"},
    {"yt_id": "KpEwwWiPeuE", "name": "Cruz y Raya — El hombre y la Tierra (parodia)"},
]

_FELIX_CATEGORIES = [
    ("Todos sus documentales",
     '(creator:"felix rodriguez de la fuente" OR subject:"felix rodriguez de la fuente" OR title:"felix rodriguez de la fuente")'),
    ("El Hombre y la Tierra",
     'title:"el hombre y la tierra"'),
    ("Fauna ibérica y salvaje",
     '(creator:"felix rodriguez de la fuente" OR subject:"felix rodriguez de la fuente") AND (subject:fauna OR subject:naturaleza OR subject:wildlife)'),
]

_FORMAT_PRIORITY = [
    'h.264', 'MPEG4', '512Kb MPEG4', '256Kb MPEG4',
    'HiRes MPEG4', 'Ogg Video', 'DivX',
]


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def _handle():
    return int(sys.argv[1])


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'espatv_archive_cache.json')


def _load_cache():
    try:
        p = _cache_path()
        if not os.path.exists(p):
            return {}
        with open(p, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_cache(data):
    try:
        p = _cache_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = p + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, p)
    except OSError as e:
        xbmc.log("[EspaTV-AO] cache save: {0}".format(e), xbmc.LOGWARNING)


def _search(query, page=1):
    cache = _load_cache()
    cache_key = "{0}|{1}".format(query, page)
    entry = cache.get(cache_key, {})
    if entry and (time.time() - entry.get('ts', 0)) < _TTL:
        return entry['items']

    try:
        r = requests.get(
            _SEARCH_API,
            params={
                'q': query,
                'fl[]': ['identifier', 'title', 'year', 'description', 'subject'],
                'sort[]': 'downloads desc',
                'rows': _PAGE_SIZE,
                'page': page,
                'output': 'json',
            },
            headers=_HEADERS,
            timeout=15,
        )
        xbmc.log("[EspaTV-AO] search '{0}' p{1} -> {2}".format(query[:40], page, r.status_code), xbmc.LOGINFO)
        if r.status_code != 200:
            return []
        docs = r.json().get('response', {}).get('docs', [])
        items = []
        for d in docs:
            ident = d.get('identifier', '')
            if not ident:
                continue
            title = d.get('title', ident)
            if isinstance(title, list):
                title = title[0] if title else ident
            year = d.get('year', '')
            if isinstance(year, list):
                year = str(year[0]) if year else ''
            desc = d.get('description', '')
            if isinstance(desc, list):
                desc = ' '.join(str(x) for x in desc[:3])
            items.append({
                'id':    ident,
                'title': str(title).strip(),
                'year':  str(year)[:4],
                'plot':  str(desc)[:400],
                'thumb': _THUMB_URL.format(id=ident),
            })
        cache[cache_key] = {'ts': time.time(), 'items': items}
        _save_cache(cache)
        return items
    except (requests.RequestException, ValueError) as e:
        xbmc.log("[EspaTV-AO] search error: {0}".format(e), xbmc.LOGERROR)
        return []


def _best_video_url(identifier):
    """Devuelve URL directa al mejor archivo de vídeo del item, o ''."""
    try:
        r = requests.get(_METADATA_API.format(id=identifier), headers=_HEADERS, timeout=15)
        if r.status_code != 200:
            return ''
        files = r.json().get('files', [])

        by_format = {}
        for f in files:
            fmt = f.get('format', '')
            name = f.get('name', '')
            if fmt and name:
                by_format.setdefault(fmt, name)

        for fmt in _FORMAT_PRIORITY:
            if fmt in by_format:
                return _DOWNLOAD_URL.format(
                    id=identifier,
                    file=urllib.parse.quote(by_format[fmt]),
                )

        for f in files:
            name = f.get('name', '')
            if name.lower().endswith(('.mp4', '.ogv', '.avi')):
                return _DOWNLOAD_URL.format(
                    id=identifier,
                    file=urllib.parse.quote(name),
                )
        return ''
    except (requests.RequestException, ValueError) as e:
        xbmc.log("[EspaTV-AO] metadata {0}: {1}".format(identifier, e), xbmc.LOGERROR)
        return ''


def _add_items(h, items, query, page):
    for item in items:
        title = item['title']
        label = "{0} ({1})".format(title, item['year']) if item.get('year') else title
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultMovies.png', 'thumb': item['thumb'], 'poster': item['thumb']})
        li.setInfo('video', {
            'title':     title,
            'year':      int(item['year']) if item.get('year', '').isdigit() else 0,
            'plot':      item['plot'] or "Película de dominio público — Internet Archive.",
            'mediatype': 'movie',
        })
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='archive_play', archive_id=item['id'], title=title),
            listitem=li,
            isFolder=False,
        )
    if len(items) == _PAGE_SIZE:
        li = xbmcgui.ListItem(label="[COLOR limegreen]Página siguiente[/COLOR]")
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='archive_category', q=query, page=int(page) + 1),
            listitem=li,
            isFolder=True,
        )


def show_menu():
    h = _handle()
    li = xbmcgui.ListItem(label="[COLOR yellow][B]Buscar película...[/B][/COLOR]")
    li.setArt({'icon': 'DefaultAddonSearch.png'})
    li.setInfo('video', {'plot': "Busca por título en el catálogo de Internet Archive.\n\n[COLOR orange]La búsqueda se realiza al pulsar el botón. Los resultados provienen directamente de Internet Archive y no están controlados ni filtrados por este addon.[/COLOR]"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action='archive_search_ui'), listitem=li, isFolder=True)

    _disclaimer = "[COLOR orange]Los resultados provienen directamente de Internet Archive, filtrados por la temática de la categoría. El contenido específico de cada resultado no está controlado por este addon.[/COLOR]"
    for label, query in _CATEGORIES:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultMovies.png'})
        li.setInfo('video', {'plot': _disclaimer})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='archive_category', q=query, page=1),
            listitem=li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


def show_documentales_es_menu():
    h = _handle()
    items = [
        ("Internet Archive",
         'archive_documentales_archive',
         "Búsqueda en directo en Internet Archive.\nLos resultados se obtienen cada vez que entras; no hay enlaces fijos y el catálogo puede variar."),
        ("Félix Rodríguez de la Fuente",
         'archive_felix',
         "Félix Rodríguez de la Fuente (1928-1980). Naturalista, etólogo y divulgador español.\nPionero de los documentales de naturaleza en España. Autor de El Hombre y la Tierra.\n\nBúsqueda en directo en Internet Archive; el catálogo puede variar en cada consulta."),
        ("Eduard Punset — Redes",
         'archive_punset',
         "Eduard Punset (1936-2019). Divulgador científico español.\nDirector y presentador del programa Redes en RTVE, sobre ciencia, tecnología y evolución humana."),
    ]
    for label, action, plot in items:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(label))
        li.setArt({'icon': 'DefaultMovies.png'})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def show_felix_menu():
    h = _handle()
    items = [
        ("Internet Archive",
         'archive_felix_archive',
         "Búsqueda en directo en Internet Archive.\nLos resultados se obtienen cada vez que entras; el catálogo puede variar."),
        ("RTVE",
         'archive_felix_rtve',
         "Documentales de Félix Rodríguez de la Fuente en RTVE Play.\nResultados obtenidos en directo desde la API de RTVE."),
        ("YouTube",
         'archive_felix_yt',
         "Vídeos y documentales de Félix Rodríguez de la Fuente en YouTube."),
    ]
    for label, action, plot in items:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(label))
        li.setArt({'icon': 'DefaultMovies.png'})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def show_punset_menu():
    h = _handle()
    items = [
        ("RTVE — Redes",
         _u(action='archive_punset_rtve'),
         "Episodios del programa Redes en RTVE Play.\nResultados obtenidos en directo desde la API de RTVE.",
         True),
        ("YouTube — Playlist oficial",
         _u(action='felicidad_play', yt_id='PL99E1815B2926873A', ctype='playlist',
            name='Redes — Eduard Punset'),
         "Playlist oficial de Redes en YouTube.",
         False),
    ]
    for label, url, plot, is_folder in items:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(label))
        li.setArt({'icon': 'DefaultMovies.png'})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=is_folder)
    xbmcplugin.endOfDirectory(h)


def show_felix_archive_submenu():
    h = _handle()
    try:
        for label, query in _FELIX_CATEGORIES:
            li = xbmcgui.ListItem(label="[B]{0}[/B]".format(label))
            li.setArt({'icon': 'DefaultMovies.png'})
            li.setInfo('video', {'plot': "Búsqueda en directo en Internet Archive.\nLos resultados se obtienen cada vez que entras; el catálogo puede variar."})
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action='archive_category', q=query, page=1),
                listitem=li,
                isFolder=True,
            )
    except Exception as e:
        xbmc.log("[EspaTV-AO] felix_archive: {0}".format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("EspaTV", "Error cargando documentales de Félix",
                                      xbmcgui.NOTIFICATION_ERROR, 3000)
    xbmcplugin.endOfDirectory(h)


def show_felix_yt():
    h = _handle()
    if not _FELIX_YT:
        xbmcgui.Dialog().notification("EspaTV", "Próximamente — enlaces en preparación",
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(h)
        return
    for item in _FELIX_YT:
        yt_id = item["yt_id"]
        name = item["name"]
        li = xbmcgui.ListItem(label=name)
        li.setArt({'icon': "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id),
                   'thumb': "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(yt_id)})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="felicidad_play", yt_id=yt_id, name=name, ctype="video"),
            listitem=li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


def show_documentales_archive_submenu():
    h = _handle()
    try:
        for label, query in _DOC_ES_CATEGORIES:
            li = xbmcgui.ListItem(label="[B]{0}[/B]".format(label))
            li.setArt({'icon': 'DefaultMovies.png'})
            li.setInfo('video', {'plot': "Búsqueda en directo en Internet Archive.\nLos resultados se obtienen cada vez que entras; no hay enlaces fijos y el catálogo puede variar."})
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action='archive_category', q=query, page=1),
                listitem=li,
                isFolder=True,
            )
    except Exception as e:
        xbmc.log("[EspaTV-AO] documentales_menu: {0}".format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("EspaTV", "Error cargando documentales",
                                      xbmcgui.NOTIFICATION_ERROR, 3000)
    xbmcplugin.endOfDirectory(h)


def show_category(query, page=1):
    h = _handle()
    if not query:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    items = _search(query, page=int(page))
    if not items:
        xbmcgui.Dialog().notification("EspaTV", "Sin resultados en Internet Archive", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(h)
        return
    _add_items(h, items, query, page)
    xbmcplugin.endOfDirectory(h)


def search_ui():
    h = _handle()
    kb = xbmc.Keyboard("", "Buscar en Internet Archive...")
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    q = 'mediatype:movies AND title:({0})'.format(kb.getText().strip())
    items = _search(q)
    if not items:
        xbmcgui.Dialog().notification("EspaTV", "Sin resultados en Internet Archive", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    _add_items(h, items, q, 1)
    xbmcplugin.endOfDirectory(h)


def play(archive_id, title=""):
    h = _handle()
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Buscando enlace directo en Archive.org...")
    url = _best_video_url(archive_id)
    dp.close()

    if not url:
        xbmcgui.Dialog().notification(
            "EspaTV", "No se encontró vídeo reproducible",
            xbmcgui.NOTIFICATION_ERROR,
        )
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return

    xbmc.log("[EspaTV-AO] play {0} -> {1}".format(archive_id, url[:80]), xbmc.LOGINFO)
    ext = url.split('?')[0].rsplit('.', 1)[-1].lower()
    mime = {'ogv': 'video/ogg', 'avi': 'video/x-msvideo'}.get(ext, 'video/mp4')
    li = xbmcgui.ListItem(label=title, path=url)
    li.setMimeType(mime)
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(h, True, li)


def _best_audio_url(identifier):
    """Devuelve URL directa al mejor archivo de audio del item, o ''."""
    try:
        r = requests.get(_METADATA_API.format(id=identifier), headers=_HEADERS, timeout=15)
        if r.status_code != 200:
            return ''
        files = r.json().get('files', [])
        by_format = {}
        for f in files:
            fmt = f.get('format', '')
            name = f.get('name', '')
            if fmt and name:
                by_format.setdefault(fmt, name)
        for fmt in _AUDIO_FORMAT_PRIORITY:
            if fmt in by_format:
                return _DOWNLOAD_URL.format(
                    id=identifier,
                    file=urllib.parse.quote(by_format[fmt]),
                )
        for f in files:
            name = f.get('name', '')
            if name.lower().endswith(('.mp3', '.ogg', '.flac', '.opus')):
                return _DOWNLOAD_URL.format(
                    id=identifier,
                    file=urllib.parse.quote(name),
                )
        return ''
    except (requests.RequestException, ValueError) as e:
        xbmc.log("[EspaTV-AO] audio_url {0}: {1}".format(identifier, e), xbmc.LOGERROR)
        return ''


def _add_audio_items(h, items, query, page):
    for item in items:
        title = item['title']
        label = "{0} ({1})".format(title, item['year']) if item.get('year') else title
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultAudio.png', 'thumb': item['thumb']})
        li.setInfo('music', {
            'title': title,
            'comment': item['plot'] or "Audiolibro de dominio público — Internet Archive.",
        })
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='archive_play_audio', archive_id=item['id'], title=title),
            listitem=li,
            isFolder=False,
        )
    if len(items) == _PAGE_SIZE:
        li = xbmcgui.ListItem(label="[COLOR limegreen]Página siguiente[/COLOR]")
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='archive_audiobooks_category', q=query, page=int(page) + 1),
            listitem=li,
            isFolder=True,
        )


def show_audiobooks_es_menu():
    h = _handle()
    try:
        for label, query in _AUDIOBOOKS_ES_CATEGORIES:
            li = xbmcgui.ListItem(label="[B]{0}[/B]".format(label))
            li.setArt({'icon': 'DefaultAudio.png'})
            li.setInfo('video', {'plot': "Audiolibros en español de Internet Archive."})
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action='archive_audiobooks_category', q=query, page=1),
                listitem=li,
                isFolder=True,
            )
    except Exception as e:
        xbmc.log("[EspaTV-AO] audiobooks_menu: {0}".format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("EspaTV", "Error cargando audiolibros",
                                      xbmcgui.NOTIFICATION_ERROR, 3000)
    xbmcplugin.endOfDirectory(h)


def show_audiobooks_category(query, page=1):
    h = _handle()
    if not query:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    items = _search(query, page=int(page))
    if not items:
        xbmcgui.Dialog().notification("EspaTV", "Sin resultados en Internet Archive",
                                      xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(h)
        return
    _add_audio_items(h, items, query, page)
    xbmcplugin.endOfDirectory(h)


def play_audio(archive_id, title=""):
    h = _handle()
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Buscando enlace de audio en Archive.org...")
    url = _best_audio_url(archive_id)
    dp.close()
    if not url:
        xbmcgui.Dialog().notification(
            "EspaTV", "No se encontró audio reproducible",
            xbmcgui.NOTIFICATION_ERROR,
        )
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return
    xbmc.log("[EspaTV-AO] play_audio {0} -> {1}".format(archive_id, url[:80]), xbmc.LOGINFO)
    ext = url.split('?')[0].rsplit('.', 1)[-1].lower()
    mime = {'ogg': 'audio/ogg', 'flac': 'audio/flac', 'opus': 'audio/ogg'}.get(ext, 'audio/mpeg')
    li = xbmcgui.ListItem(label=title, path=url)
    li.setMimeType(mime)
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(h, True, li)
