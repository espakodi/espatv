# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Historial de búsquedas de Dailymotion y YouTube."""
import json
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _get_history_file():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    return os.path.join(p, 'search_history.json')


def load():
    f = _get_history_file()
    if not os.path.exists(f):
        return []
    try:
        with open(f, 'r', encoding='utf-8') as o:
            return json.load(o)
    except (OSError, ValueError) as e:
        xbmc.log("[EspaTV] Error loading history: {0}".format(e), xbmc.LOGERROR)
        return []


def add(q):
    q = q.strip()
    if not q:
        return
    h = load()
    if q in h:
        h.remove(q)
    h.insert(0, q)
    h = h[:50]
    try:
        with open(_get_history_file(), 'w', encoding='utf-8') as o:
            json.dump(h, o)
    except OSError:
        pass


def menu(skip_end=False):
    import yt_search as _yts
    h = load()
    addon = xbmcaddon.Addon()
    icon = addon.getAddonInfo('icon')
    _mp = os.path.join(addon.getAddonInfo('path'), 'resources', 'media')
    def _ico(name, fallback):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    li = xbmcgui.ListItem(label="[COLOR yellow][B][Categorías / Carpetas][/B][/COLOR]")
    li.setArt({'icon': _ico('catalogo.png', 'DefaultAddonService.png')})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="cat_menu"), listitem=li, isFolder=True)

    if not h:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay historial reciente[/COLOR]")
        li.setArt({'icon': _ico('info.png', 'DefaultIconInfo.png')})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label="[COLOR yellow][B]--- Historial DM ---[/B][/COLOR]")
        li.setArt({'icon': _ico('dailymotion.png', 'DefaultFolder.png')})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
        for q in h:
            li = xbmcgui.ListItem(label="[COLOR lime][DM][/COLOR] {0}".format(q))
            li.setArt({'icon': _ico('busqueda.png', 'DefaultFolder.png')})
            try:
                cm = [
                    ("Editar y buscar", "RunPlugin({0})".format(_u(action='edit_and_search', q=q, ot=icon))),
                    ("Añadir a Categoría...", "RunPlugin({0})".format(_u(action='cat_add_item_dialog', q=q))),
                    ("Eliminar de este historial", "RunPlugin({0}?action=remove_history_item&q={1})".format(sys.argv[0], urllib.parse.quote(q)))
                ]
                fav_params = json.dumps({'q': q, 'ot': icon})
                cm.append(("Añadir a Mis Favoritos", "RunPlugin({0})".format(_u(action='add_favorite', title=q, fav_url='lfr_' + q, icon=icon, platform='search', fav_action='lfr', params=fav_params))))
                cm.append(("Buscar en webs de torrent", "RunPlugin({0})".format(_u(action='elementum_search', q=q))))
                li.addContextMenuItems(cm)
            except (TypeError, ValueError) as e:
                xbmc.log("[EspaTV] Error adding CM to history item: {0}".format(e), xbmc.LOGERROR)
            target_url = _u(action="lfr", q=q, ot=icon, nh=1)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=target_url, listitem=li, isFolder=True)

        li = xbmcgui.ListItem(label="[COLOR blue][I]Nota: Puedes borrar elementos individuales con clic derecho[/I][/COLOR]")
        li.setArt({'icon': _ico('info.png', 'DefaultIconInfo.png')})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)

        li = xbmcgui.ListItem(label="[COLOR red]Borrar Historial DM...[/COLOR]")
        li.setArt({'icon': _ico('adv_borrar.png', 'DefaultIconError.png')})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="clear_history"), listitem=li, isFolder=False)

    yt_h = _yts.load_yt_history()
    if yt_h:
        li = xbmcgui.ListItem(label="[COLOR red][B]--- Historial YouTube ---[/B][/COLOR]")
        li.setArt({'icon': _ico('youtube.png', 'DefaultMusicVideos.png')})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li, isFolder=False)
        for q in yt_h:
            li = xbmcgui.ListItem(label="[COLOR red][YT][/COLOR] {0}".format(q))
            li.setArt({'icon': _ico('busqueda.png', 'DefaultMusicVideos.png')})
            cm = [
                ("Eliminar del historial YT", "RunPlugin({0})".format(_u(action="remove_yt_history_item", q=q)))
            ]
            li.addContextMenuItems(cm)
            xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="yt_search_results", query=q), listitem=li, isFolder=True)

        li = xbmcgui.ListItem(label="[COLOR red]Borrar Historial YouTube...[/COLOR]")
        li.setArt({'icon': _ico('adv_borrar.png', 'DefaultIconError.png')})
        xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="clear_yt_history"), listitem=li, isFolder=False)

    if not skip_end:
        xbmcplugin.endOfDirectory(int(sys.argv[1]))


def clear():
    h = load()
    if not h:
        return
    opts = ["Borrar TODO el historial", "Elegir elementos a borrar", "[COLOR red]Cancelar[/COLOR]"]
    sel = xbmcgui.Dialog().select("Limpiar Historial de Búsquedas", opts)
    if sel == 0:
        if xbmcgui.Dialog().yesno("Confirmar", "¿Estás seguro de que quieres vaciar TODO el historial?"):
            with open(_get_history_file(), 'w', encoding='utf-8') as o:
                json.dump([], o)
            xbmcgui.Dialog().notification("EspaTV", "Historial vaciado", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
    elif sel == 1:
        chosen = xbmcgui.Dialog().multiselect("Marca las búsquedas a eliminar", h)
        if chosen:
            new_h = [item for i, item in enumerate(h) if i not in chosen]
            with open(_get_history_file(), 'w', encoding='utf-8') as o:
                json.dump(new_h, o)
            xbmc.executebuiltin("Container.Refresh")


def remove(q):
    h = load()
    if q in h:
        h.remove(q)
        with open(_get_history_file(), 'w', encoding='utf-8') as o:
            json.dump(h, o)
    xbmc.executebuiltin("Container.Refresh")
