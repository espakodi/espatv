import json
import os
import sys
import threading
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

_ADDON = xbmcaddon.Addon()
_ADDON_PATH = _ADDON.getAddonInfo('path')


def _norm_mt(mt):
    # enricher usa 'show'; APIs de listado usan 'tv' — normaliza al vocabulario del enricher
    return 'show' if str(mt) in ('show', 'tv') else 'movie'


def _normalize(raw, meta):
    year_raw = str(raw.get('year', '') or '')
    year_meta = str((meta or {}).get('year', '') or '')
    year_str = year_raw or year_meta

    rating = 0.0
    try:
        rating = float((meta or {}).get('rating') or raw.get('rating') or 0)
    except (TypeError, ValueError):
        pass

    genres = (meta or {}).get('genres') or []
    genre_str = ' / '.join(str(g) for g in genres[:2]) if genres else str(raw.get('genre', '') or '')

    cast = (meta or {}).get('cast') or []
    cast_str = ', '.join(
        c.get('name', '') if isinstance(c, dict) else str(c)
        for c in cast[:3]
    )

    return {
        'title':    str(raw.get('title', '') or ''),
        'year':     year_str,
        'poster':   str((meta or {}).get('poster') or raw.get('poster', '') or ''),
        'fanart':   str((meta or {}).get('fanart', '') or ''),
        'rating':   rating,
        'genre':    genre_str,
        'director': str((meta or {}).get('director', '') or ''),
        'cast_str': cast_str,
        'plot':     str((meta or {}).get('overview') or raw.get('plot', '') or ''),
        'runtime':  int((meta or {}).get('runtime') or 0),
        'imdb_id':  str(raw.get('id', '') or raw.get('imdb_id', '') or ''),
        'tmdb_id':  str(((meta or {}).get('ids') or {}).get('tmdb', '') or ''),
        'media_type': _norm_mt(raw.get('media_type')),
    }


# ── Acciones del menú contextual (compartidas por el grid y el Modo Cine) ────

def add_to_kodi_favorites(addon_url, title, poster, tmdb_id, media_type):
    """Añade el título a los Favoritos nativos de Kodi. El favorito abre el menú
    '¿Dónde ver?' al pulsarlo (la peli no tiene una URL de reproducción fija).
    Devuelve True si Kodi confirmó el alta."""
    if not title:
        return False
    mode = 'tv' if media_type == 'show' else 'movie'
    path = '{0}?action=search_alt_prompt&q={1}&ot={2}&mode={3}&tmdb_id={4}'.format(
        addon_url,
        urllib.parse.quote(title),
        urllib.parse.quote(poster or ''),
        mode,
        urllib.parse.quote(str(tmdb_id or '')),
    )
    req = json.dumps({
        'jsonrpc': '2.0', 'id': 1, 'method': 'Favourites.AddFavourite',
        'params': {'title': title, 'type': 'media', 'path': path, 'thumbnail': poster or ''},
    })
    try:
        resp = json.loads(xbmc.executeJSONRPC(req))
        return isinstance(resp, dict) and 'error' not in resp
    except (ValueError, TypeError):
        return False


def resolve_trailer_key(tmdb_id, media_type, lang='es-ES'):
    """Devuelve la key de YouTube del tráiler del título, o '' si no hay/error."""
    if not tmdb_id:
        return ''
    import metadata_enricher as me
    try:
        return me.get_trailer_key(tmdb_id, media_type or 'movie', lang=lang) or ''
    except Exception:
        return ''


def play_trailer_key(key):
    """Reproduce el tráiler a pantalla completa. Debe llamarse con el modal YA cerrado:
    un PlayMedia fullscreen queda detrás de un WindowXMLDialog abierto con doModal."""
    if not key:
        return
    # Con el modal cerrado ya es seguro parar un tráiler "hover" que siguiera abriéndose
    # (dentro del modal, parar durante la apertura congela la GUI; aquí no): evita que un
    # windowed a medio resolver pise al fullscreen.
    if xbmc.Player().isPlaying():
        xbmc.Player().stop()
    xbmc.executebuiltin(f'PlayMedia(plugin://plugin.video.youtube/play/?video_id={key})')


_LABEL_TO_MODE = {'Lista': 'lista', 'Botón': 'boton', 'Grid directo': 'grid'}


def get_grid_mode():
    """Devuelve 'lista', 'boton' o 'grid'. La primera vez (ajuste = 'Preguntar')
    muestra un diálogo y persiste la elección en el propio ajuste."""
    addon = xbmcaddon.Addon()
    raw = (addon.getSetting('pelis_grid_mode') or 'Preguntar').strip()
    if raw != 'Preguntar':
        return _LABEL_TO_MODE.get(raw, 'boton')

    labels = ['Lista', 'Botón', 'Grid directo']
    idx = xbmcgui.Dialog().select(
        'EspaTV · Películas — ¿cómo quieres verlas?',
        ['Lista  ·  solo la lista, sin botón',
         'Botón  ·  acceso al Modo Grid como primer item',
         'Grid directo  ·  abre el grid automáticamente'])
    if idx < 0:
        idx = 1  # cancelar equivale a "Botón"; se guarda para no repreguntar
    chosen = labels[idx]
    addon.setSetting('pelis_grid_mode', chosen)
    xbmcgui.Dialog().notification('EspaTV', 'Puedes cambiarlo en Ajustes → Modo Cine',
                                  xbmcgui.NOTIFICATION_INFO, 5000)
    return _LABEL_TO_MODE[chosen]


class _MovieGridWindow(xbmcgui.WindowXMLDialog):

    def __init__(self, xml, addon_path, skin, res,
                 movies=None, source_title='', addon_url=''):
        super().__init__(xml, addon_path, skin, res)
        self._movies = movies or []
        self._source_title = source_title
        self._addon_url = addon_url
        self._closing = False
        self._pending_trailer_key = ''  # tráiler a reproducir tras cerrar (ver show_grid)

    def onInit(self):
        self._populate()
        threading.Thread(target=self._focus_poll_loop, daemon=True).start()
        threading.Thread(target=self._lazy_enrich_all, daemon=True).start()

    def _lazy_enrich_all(self):
        """Completa en segundo plano lo que falte (póster y datos del panel) para
        cualquier fuente. La lista ya está construida en el hilo principal; aquí solo
        se empujan propiedades, que sí es seguro desde un hilo."""
        import metadata_enricher as me
        monitor = xbmc.Monitor()
        pending = [(idx, m) for idx, m in enumerate(self._movies)
                   if not m.get('skip_enrich') and (not m.get('poster') or not m.get('director'))]
        if not pending:
            return
        self.setProperty('m_loading', 'Cargando carátulas…')
        try:
            for i in range(0, len(pending), 8):
                if self._closing or monitor.abortRequested():
                    return
                batch = pending[i:i + 8]
                items = [{
                    'imdb_id': m.get('imdb_id') or None,
                    'tmdb_id': m.get('tmdb_id') or None,
                    'title': m.get('title'),
                    'year': int(m['year']) if str(m.get('year', '')).isdigit() else None,
                    'media_type': m.get('media_type', 'movie'),
                } for _, m in batch]
                try:
                    results = me.batch_enrich(items, use_cache_only=False, max_workers=4)
                except Exception:
                    results = [None] * len(batch)
                if self._closing or monitor.abortRequested():
                    return
                try:
                    ctrl = self.getControl(200)
                    focused = ctrl.getSelectedPosition()
                except Exception:
                    return
                for (idx, m), meta in zip(batch, results):
                    if not meta:
                        continue
                    m.update(_normalize(m, meta))
                    if self._closing:
                        return
                    # La ventana puede cerrarse en mitad del lote: si getListItem
                    # o setProperty fallan porque ya no existe, lo ignoramos.
                    try:
                        if m.get('poster'):
                            ctrl.getListItem(idx).setProperty('m_poster', m['poster'])
                        if idx == focused:
                            self._update_panel(idx)
                    except Exception:
                        pass
                if monitor.waitForAbort(0.3):
                    return
        finally:
            try:
                self.setProperty('m_loading', '')
            except Exception:
                pass

    def _populate(self):
        self.setProperty('m_source', self._source_title)
        try:
            ctrl = self.getControl(200)
            ctrl.reset()
            items = []
            for m in self._movies:
                li = xbmcgui.ListItem(label=m['title'])
                li.setProperty('m_poster', m['poster'])
                li.setProperty('m_title', m['title'])
                sub_parts = []
                if m.get('year'):
                    sub_parts.append(m['year'])
                if m.get('rating') and float(m.get('rating', 0)) > 0:
                    sub_parts.append('★ {0:.1f}'.format(float(m['rating'])))
                li.setProperty('m_sub', ' · '.join(sub_parts))
                items.append(li)
            ctrl.addItems(items)
            if self._movies:
                self._update_panel(0)
        except Exception as e:
            xbmc.log('[EspaTV-Grid] Error poblando ventana: {0}'.format(e), xbmc.LOGERROR)

    def _update_panel(self, idx):
        if not 0 <= idx < len(self._movies):
            return
        m = self._movies[idx]
        self.setProperty('m_fanart', m.get('fanart') or m.get('poster', ''))
        self.setProperty('m_poster', m.get('poster', ''))
        self.setProperty('m_title', m.get('title', ''))

        parts = []
        if m.get('year'):
            parts.append(str(m['year']))
        if m.get('rating') and float(m.get('rating', 0)) > 0:
            parts.append('★ {0:.1f}'.format(float(m['rating'])))
        if m.get('runtime') and int(m.get('runtime', 0)) > 0:
            parts.append('{0} min'.format(m['runtime']))
        self.setProperty('m_meta', ' · '.join(parts))

        self.setProperty('m_genre', m.get('genre', ''))
        director = m.get('director', '')
        self.setProperty('m_director', 'Dir. ' + director if director else '')
        cast = m.get('cast_str', '')
        self.setProperty('m_cast', 'Con: ' + cast if cast else '')
        plot = m.get('plot', '')
        if not plot and not m.get('director'):
            plot = 'Cargando detalles…'
        self.setProperty('m_plot', plot)

    def _focus_poll_loop(self):
        monitor = xbmc.Monitor()
        last = -1
        while not self._closing and not monitor.abortRequested():
            try:
                ctrl = self.getFocus()
                if ctrl.getId() == 200:
                    pos = ctrl.getSelectedPosition()
                    if pos >= 0 and pos != last:
                        last = pos
                        self._update_panel(pos)
            except Exception:
                pass
            if monitor.waitForAbort(0.2):
                break

    def _open_search(self, m):
        # No cerramos el grid: el diálogo "¿Dónde buscar?" se abre encima y al
        # volver seguimos en el grid (igual que el Modo Cine).
        mode = 'show' if m.get('media_type') == 'show' else 'movie'
        url = '{0}?action=search_alt_prompt&q={1}&ot={2}&mode={3}&tmdb_id={4}'.format(
            self._addon_url,
            urllib.parse.quote(m.get('title', '')),
            urllib.parse.quote(m.get('poster', '')),
            mode,
            urllib.parse.quote(str(m.get('tmdb_id') or '')),
        )
        xbmc.executebuiltin('RunPlugin({0})'.format(url))

    def _show_synopsis(self, m):
        title = m.get('title', '')
        parts = []
        if m.get('year'):
            parts.append(str(m['year']))
        rating = float(m.get('rating') or 0)
        if rating > 0:
            parts.append(f'★ {rating:.1f}')
        runtime = int(m.get('runtime') or 0)
        if runtime > 0:
            parts.append(f'{runtime} min')
        if m.get('genre'):
            parts.append(m['genre'])
        body = title
        if parts:
            body += '\n' + ' · '.join(parts)
        credits = ' · '.join(p for p in (
            f"Dir. {m['director']}" if m.get('director') else '',
            f"Con: {m['cast_str']}" if m.get('cast_str') else '') if p)
        if credits:
            body += '\n' + credits
        if m.get('plot'):
            body += '\n\n' + m['plot']
        xbmcgui.Dialog().textviewer(title, body)

    def _show_context_menu(self):
        import core_settings
        try:
            pos = self.getControl(200).getSelectedPosition()
        except Exception:
            return
        if not 0 <= pos < len(self._movies):
            return
        m = self._movies[pos]
        media_type = m.get('media_type', 'movie')
        in_fav = core_settings.is_movie_favorited(m, media_type)
        opts = [
            ('synopsis',   'Ver sinopsis'),
            ('trailer',    'Ver tráiler'),
            ('search',     'Buscar / ¿Dónde ver?'),
            ('fav_espatv', 'Quitar de Mis Favoritos' if in_fav else 'Añadir a Mis Favoritos'),
            ('fav_kodi',   'Añadir a favoritos de Kodi'),
        ]
        sel = xbmcgui.Dialog().select(m.get('title', ''), [label for _, label in opts])
        if sel < 0:
            return
        action = opts[sel][0]
        if action == 'synopsis':
            self._show_synopsis(m)
        elif action == 'trailer':
            xbmcgui.Dialog().notification('EspaTV', 'Cargando tráiler…',
                                          xbmcgui.NOTIFICATION_INFO, 1500)
            lang = core_settings.load_trailer_config().get('lang', 'es-ES')
            key = resolve_trailer_key(m.get('tmdb_id'), media_type, lang)
            if key:
                # Cerramos el grid y reproducimos a pantalla completa (el modal tapa el
                # vídeo); show_grid lanza el PlayMedia una vez cerrado.
                self._pending_trailer_key = key
                self._closing = True
                self.close()
            else:
                xbmcgui.Dialog().notification('EspaTV', 'No hay tráiler disponible',
                                              xbmcgui.NOTIFICATION_INFO, 2500)
        elif action == 'search':
            self._open_search(m)
        elif action == 'fav_espatv':
            added = core_settings.toggle_movie_favorite(m, media_type)
            xbmcgui.Dialog().notification(
                'EspaTV', 'Añadida a Mis Favoritos' if added else 'Quitada de Mis Favoritos',
                xbmcgui.NOTIFICATION_INFO, 2000)
        elif action == 'fav_kodi':
            ok = add_to_kodi_favorites(self._addon_url, m.get('title', ''),
                                       m.get('poster', ''), m.get('tmdb_id'), media_type)
            xbmcgui.Dialog().notification(
                'EspaTV', 'Añadida a favoritos de Kodi' if ok else 'No se pudo añadir',
                xbmcgui.NOTIFICATION_INFO, 2500)

    def onClick(self, controlId):
        if controlId == 100:
            self._closing = True
            self.close()
        elif controlId == 200:
            pos = self.getControl(200).getSelectedPosition()
            if 0 <= pos < len(self._movies):
                self._open_search(self._movies[pos])

    def onAction(self, action):
        aid = action.getId()
        if aid in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK):
            self._closing = True
            self.close()
        elif aid == xbmcgui.ACTION_CONTEXT_MENU:
            self._show_context_menu()


def show_grid(movies, source_title):
    """Abre el Modo Grid con una lista ya normalizada."""
    win = _MovieGridWindow('pelis_grid.xml', _ADDON_PATH, 'Default', '1080i',
                           movies=movies, source_title=source_title, addon_url=sys.argv[0])
    key = ''
    try:
        win.doModal()
        key = win._pending_trailer_key
    finally:
        del win
    play_trailer_key(key)  # tras cerrar el grid: el tráiler fullscreen ya no queda tapado


def add_grid_button(handle, source, title, **params):
    """Añade el botón 'Modo Grid' que, al pulsarlo, abre el grid de esa fuente."""
    q = {'action': 'pelis_grid_open', 'source': source, 'title': title}
    q.update(params)
    url = sys.argv[0] + '?' + urllib.parse.urlencode(q)
    li = xbmcgui.ListItem(label='[COLOR FF38BDF8][B]Modo Grid[/B][/COLOR]')
    li.setArt({'icon': os.path.join(_ADDON_PATH, 'resources', 'media', 'modo_grid.png')})
    li.setInfo('video', {'plot': 'Vista visual de pósters al estilo Netflix con detalle de cada título.'})
    li.setProperty('IsPlayable', 'false')
    xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)


def apply_grid_mode(handle, source, title, **params):
    """Aplica el modo de vista a una sección de tops. Devuelve True si la sección
    debe terminar (modo 'grid': ya se abrió el grid). En 'boton' añade el botón;
    en 'lista' no hace nada."""
    mode = get_grid_mode()
    if mode == 'grid':
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        params['title'] = title
        show_from_source(source, params)
        return True
    if mode == 'boton':
        add_grid_button(handle, source, title, **params)
    return False


# ─── Loaders ────────────────────────────────────────────────────────────────
# Cada función fetcha su fuente (caché primero) y devuelve lista normalizada.

def _loader_cinemeta(params=None):
    import cinemeta, metadata_enricher as me
    films = cinemeta._get_top_films() or []
    result = []
    for f in films:
        year_int = int(f['year']) if str(f.get('year', '')).isdigit() else None
        meta = me.enrich(imdb_id=f.get('id'), title=f['title'], year=year_int, use_cache_only=True)
        result.append(_normalize(f, meta))
    return result


def _loader_cinemeta_genre(params=None):
    import cinemeta, metadata_enricher as me
    slug = (params or {}).get('slug', '')
    films = cinemeta._get_genre_films(slug) if slug else []
    result = []
    for f in films:
        year_int = int(f['year']) if str(f.get('year', '')).isdigit() else None
        meta = me.enrich(imdb_id=f.get('id'), title=f['title'], year=year_int, use_cache_only=True)
        result.append(_normalize(f, meta))
    return result


def _loader_filmaffinity_top(params=None):
    import filmaffinity, metadata_enricher as me
    films = filmaffinity._fetch_top() or []
    result = []
    for f in films:
        year_int = int(f['year']) if str(f.get('year', '')).isdigit() else None
        meta = me.enrich(tmdb_id=f.get('tmdb_id') or f.get('id'), title=f['title'],
                         year=year_int, use_cache_only=True)
        raw = {'title': f.get('title', ''), 'year': str(f.get('year', '')),
               'poster': f.get('poster', ''), 'plot': f.get('overview', ''),
               'rating': f.get('rating', 0)}
        result.append(_normalize(raw, meta))
    return result


def _loader_filmaffinity_cartelera(params=None):
    import filmaffinity, metadata_enricher as me
    films = filmaffinity._fetch_en_cines() or []
    result = []
    for f in films:
        year_int = int(f['year']) if str(f.get('year', '')).isdigit() else None
        meta = me.enrich(title=f['title'], year=year_int, media_type='movie', use_cache_only=True)
        raw = {'title': f.get('title', ''), 'year': str(f.get('year', '')),
               'poster': f.get('poster', '')}
        result.append(_normalize(raw, meta))
    return result


def _loader_filmaffinity_cat(params=None):
    import filmaffinity, metadata_enricher as me
    src = (params or {}).get('src', '')
    films = filmaffinity._fetch_cat(src) or []
    result = []
    for f in films:
        mt = f.get('media_type', 'movie')
        meta = me.enrich(title=f['title'], media_type=mt, use_cache_only=True)
        raw = {'title': f.get('title', ''), 'poster': f.get('poster', ''), 'media_type': mt}
        result.append(_normalize(raw, meta))
    return result


def _loader_filmaffinity_topfa(params=None):
    import filmaffinity, metadata_enricher as me
    films = filmaffinity._fetch_topfa() or []
    result = []
    for f in films:
        year_int = int(f['year']) if str(f.get('year', '')).isdigit() else None
        # topfa no trae tmdb_id (el 'id' es de FilmAffinity): enriquecer por título+año
        meta = me.enrich(title=f['title'], year=year_int, media_type='movie', use_cache_only=True)
        raw = {'title': f.get('title', ''), 'year': str(f.get('year', '')),
               'poster': f.get('poster', ''), 'rating': f.get('rating', 0)}
        result.append(_normalize(raw, meta))
    return result


def _loader_filmaffinity_list(params=None):
    import filmaffinity, metadata_enricher as me
    genre = (params or {}).get('genre', 'movie:')
    media_type, genre_id = genre.split(':', 1) if ':' in genre else ('movie', genre)
    films = filmaffinity._fetch(media_type, genre_id) or []
    result = []
    for f in films:
        year_int = int(f.get('year', 0)) if str(f.get('year', '')).isdigit() else None
        meta = me.enrich(tmdb_id=f.get('tmdb_id'), title=f['title'], year=year_int,
                         media_type=_norm_mt(media_type), use_cache_only=True)
        raw = {'title': f.get('title', ''), 'year': str(f.get('year', '')),
               'poster': f.get('poster', ''), 'tmdb_id': str(f.get('tmdb_id', '')),
               'media_type': media_type}
        result.append(_normalize(raw, meta))
    return result


def _loader_peliculas_top(params=None):
    import peliculas_top as pt, metadata_enricher as me
    result = []
    for title in pt.get_movies_list():
        meta = me.enrich(title=title, media_type='movie', use_cache_only=True)
        result.append(_normalize({'title': title, 'year': '', 'poster': '', 'plot': ''}, meta))
    return result


def _loader_oscar(params=None):
    import oscar_movies as om, metadata_enricher as me
    result = []
    for title in om._get_movies_list():
        d = om._get_details(title)
        year_int = d.get('film_year') or None
        meta = me.enrich(title=title, year=year_int, media_type='movie', use_cache_only=True)
        raw = {'title': title, 'year': str(year_int or ''), 'poster': '',
               'plot': d.get('plot', ''), 'rating': d.get('rating', 0),
               'genre': d.get('genre', ''), 'director': d.get('director', '')}
        result.append(_normalize(raw, meta))
    return result


def _loader_sensacine_cartelera(params=None):
    import sensacine, metadata_enricher as me
    result = []
    for f in (sensacine._fetch_cartelera() or []):
        meta = me.enrich(title=f['title'], media_type='movie', use_cache_only=True)
        result.append(_normalize({'title': f.get('title', ''), 'poster': f.get('poster', '')}, meta))
    return result


def _loader_sensacine_estrenos(params=None):
    import sensacine, metadata_enricher as me
    result = []
    for f in (sensacine._fetch_estrenos() or []):
        meta = me.enrich(title=f['title'], media_type='movie', use_cache_only=True)
        result.append(_normalize({'title': f.get('title', ''), 'poster': f.get('poster', '')}, meta))
    return result


def _loader_sensacine_mejores(params=None):
    import sensacine, metadata_enricher as me
    result = []
    for f in (sensacine._fetch_mejores() or []):
        meta = me.enrich(title=f['title'], media_type='movie', use_cache_only=True)
        result.append(_normalize({'title': f.get('title', ''), 'poster': f.get('poster', '')}, meta))
    return result


def _loader_sensacine_taquilla(params=None):
    import sensacine, metadata_enricher as me
    result = []
    for f in (sensacine._fetch_taquilla() or []):
        meta = me.enrich(title=f['title'], media_type='movie', use_cache_only=True)
        result.append(_normalize({'title': f.get('title', ''), 'poster': f.get('poster', '')}, meta))
    return result


def _loader_tmdb_list(params=None):
    import tmdb_lists, metadata_enricher as me
    endpoint = (params or {}).get('endpoint', 'movie/top_rated')
    media_type = (params or {}).get('media_type', 'movie')
    items, _ = tmdb_lists._fetch_page(endpoint, media_type, 1)
    result = []
    for item in (items or []):
        year_int = item.get('year') or None
        meta = me.enrich(tmdb_id=item.get('tmdb_id'), title=item.get('title', ''),
                         year=year_int, media_type=_norm_mt(media_type), use_cache_only=True)
        result.append(_normalize(item, meta))
    return result


def _loader_streaming(params=None):
    import streaming_tops, metadata_enricher as me
    media_type = (params or {}).get('media_type', 'movie')
    try:
        provider_id = int((params or {}).get('provider_id', ''))
    except (ValueError, TypeError):
        return []
    items, _ = streaming_tops._fetch_provider_list(provider_id, media_type, 1)
    result = []
    for item in (items or []):
        year_int = item.get('year') or None
        meta = me.enrich(tmdb_id=item.get('tmdb_id'), title=item.get('title', ''),
                         year=year_int, media_type=_norm_mt(media_type), use_cache_only=True)
        result.append(_normalize(item, meta))
    return result


def _loader_trakt(params=None):
    import trakt_tops, metadata_enricher as me
    path = (params or {}).get('path', 'movies/trending')
    media_type = (params or {}).get('media_type', 'movie')
    wrapped = str((params or {}).get('wrapped', 'true')).lower() == 'true'
    items, _ = trakt_tops._fetch_list(path, media_type, wrapped, 1)
    result = []
    for item in (items or []):
        year_int = item.get('year') or None
        meta = me.enrich(tmdb_id=item.get('tmdb_id'), imdb_id=item.get('imdb_id'),
                         title=item.get('title', ''), year=year_int,
                         media_type=_norm_mt(media_type), use_cache_only=True)
        raw = {'title': item.get('title', ''), 'year': str(item.get('year', '')),
               'plot': item.get('overview', ''), 'rating': item.get('rating', 0),
               'genre': item.get('genres', ''), 'runtime': item.get('runtime', 0),
               'tmdb_id': str(item.get('tmdb_id', '')), 'imdb_id': item.get('imdb_id', ''),
               'media_type': media_type}
        result.append(_normalize(raw, meta))
    return result


def _loader_mdblist(params=None):
    import mdblist, metadata_enricher as me
    list_id = (params or {}).get('list_id', '')
    items = mdblist._fetch_list_items(list_id) or []
    result = []
    for item in items:
        year_int = item.get('year') or None
        media_type = item.get('media_type', 'movie')
        meta = me.enrich(tmdb_id=item.get('tmdb_id'), imdb_id=item.get('imdb_id'),
                         title=item.get('title', ''), year=year_int,
                         media_type=_norm_mt(media_type), use_cache_only=True)
        raw = {'title': item.get('title', ''), 'year': str(item.get('year', '')),
               'tmdb_id': str(item.get('tmdb_id', '')), 'imdb_id': item.get('imdb_id', ''),
               'media_type': media_type}
        result.append(_normalize(raw, meta))
    return result


def _loader_anime_anilist(params=None):
    import anime_tops
    sort_key = (params or {}).get('sort_key', 'SCORE')
    result = []
    items, _ = anime_tops._fetch_anilist(sort_key, 1)
    for item in (items or []):
        raw = {'title': item.get('title', ''), 'poster': item.get('poster', ''),
               'plot': item.get('plot', ''), 'rating': item.get('rating', 0),
               'genre': item.get('genres', '')}
        m = _normalize(raw, None)
        m['skip_enrich'] = True  # anime: datos de AniList, no enriquecer con TMDB
        result.append(m)
    return result


def _loader_movie_favorites(params=None):
    # Los favoritos ya se guardan normalizados (misma forma que devuelve _normalize), así
    # que se devuelven tal cual; re-normalizar perdería tmdb_id/fanart/director (que
    # _normalize toma de 'meta', no del registro). skip_enrich: la fila es 100% local.
    import core_settings
    media_type = (params or {}).get('media_type', 'movie')
    return [dict(f, skip_enrich=True) for f in core_settings.get_movie_favorites(media_type)]


def _loader_anime_mal(params=None):
    import anime_tops
    ranking_type = (params or {}).get('ranking_type', 'bypopularity')
    result = []
    items, _ = anime_tops._fetch_mal(ranking_type, 1)
    for item in (items or []):
        raw = {'title': item.get('title', ''), 'poster': item.get('poster', ''),
               'plot': item.get('plot', ''), 'rating': item.get('rating', 0),
               'genre': item.get('genres', '')}
        m = _normalize(raw, None)
        m['skip_enrich'] = True  # anime: datos de MAL, no enriquecer con TMDB
        result.append(m)
    return result


_LOADERS = {
    'cinemeta_top':           _loader_cinemeta,
    'cinemeta_genre':         _loader_cinemeta_genre,
    'filmaffinity_top':       _loader_filmaffinity_top,
    'filmaffinity_topfa':     _loader_filmaffinity_topfa,
    'filmaffinity_cartelera': _loader_filmaffinity_cartelera,
    'filmaffinity_cat':       _loader_filmaffinity_cat,
    'filmaffinity_list':      _loader_filmaffinity_list,
    'peliculas_top':          _loader_peliculas_top,
    'oscar':                  _loader_oscar,
    'sensacine_cartelera':    _loader_sensacine_cartelera,
    'sensacine_estrenos':     _loader_sensacine_estrenos,
    'sensacine_mejores':      _loader_sensacine_mejores,
    'sensacine_taquilla':     _loader_sensacine_taquilla,
    'tmdb_list':              _loader_tmdb_list,
    'streaming':              _loader_streaming,
    'trakt':                  _loader_trakt,
    'mdblist':                _loader_mdblist,
    'anime_anilist':          _loader_anime_anilist,
    'anime_mal':              _loader_anime_mal,
    'movie_favorites':        _loader_movie_favorites,
}


def show_from_source(source, params=None):
    """Punto de entrada genérico. source = clave de _LOADERS; params = dict de URL."""
    loader = _LOADERS.get(source)
    if not loader:
        xbmc.log('[EspaTV-Grid] fuente desconocida: {0}'.format(source), xbmc.LOGWARNING)
        return
    title = (params or {}).get('title', 'Top Películas')
    dp = xbmcgui.DialogProgress()
    dp.create('EspaTV', 'Abriendo {0}…'.format(title))
    dp.update(30)
    try:
        movies = loader(params) or []
    except Exception as e:
        xbmc.log('[EspaTV-Grid] loader error ({0}): {1}'.format(source, e), xbmc.LOGERROR)
        dp.close()
        xbmcgui.Dialog().notification('EspaTV', 'No se pudo cargar la lista',
                                      xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    dp.update(100)
    dp.close()
    if not movies:
        xbmcgui.Dialog().notification('EspaTV', 'Sin resultados para mostrar',
                                      xbmcgui.NOTIFICATION_WARNING, 3000)
        return
    show_grid(movies, title)


# ─── Compatibilidad con los 3 dispatchers originales ────────────────────────

def show_from_cinemeta():
    show_from_source('cinemeta_top', {'title': 'Top Cinemeta · Películas Populares'})

def show_from_peliculas_top():
    show_from_source('peliculas_top', {'title': 'Mejores de la Historia'})

def show_from_filmaffinity_top():
    show_from_source('filmaffinity_top', {'title': 'Top Valoradas · FilmAffinity / TMDB'})
