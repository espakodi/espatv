# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Playlists de YouTube guardadas por el usuario."""
import json
import os
import re
import sys
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

try:
    import requests
except ImportError:
    requests = None

from _user_agents import desktop_headers as _dh, ACCEPT_HTML


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _has_yt_addon():
    try:
        xbmcaddon.Addon("plugin.video.youtube")
        return True
    except RuntimeError:
        return False


def _install_yt_addon():
    import traceback
    dialog = xbmcgui.Dialog()
    try:
        if dialog.yesno("Instalar YouTube",
                        "El addon oficial de YouTube no está instalado.\n\n"
                        "¿Quieres instalarlo ahora?",
                        nolabel="Cancelar", yeslabel="Sí, Instalar"):
            xbmc.log("[EspaTV] YouTube: el usuario acepta, instalando", xbmc.LOGINFO)
            xbmc.executebuiltin("InstallAddon(plugin.video.youtube)")
            dialog.notification("EspaTV", "Instalando YouTube...", xbmcgui.NOTIFICATION_INFO, 2500)
            return False
        else:
            xbmc.log("[EspaTV] YouTube: instalación cancelada por el usuario", xbmc.LOGINFO)
            dialog.notification("EspaTV", "Tendrás que instalar YouTube manualmente.", xbmcgui.NOTIFICATION_WARNING)
            return False
    except (RuntimeError, AttributeError) as script_error:
        tb = traceback.format_exc()
        xbmc.log("[EspaTV] YouTube: error al instalar: {0}\n\t{1}".format(str(script_error), str(tb)), xbmc.LOGERROR)
        dialog.notification("EspaTV Error", "Fallo al llamar la API del sistema", xbmcgui.NOTIFICATION_ERROR)
        return False


def _open_browser(url, name=""):
    url = url.replace('"', '').replace("'", '') if url else ""
    try:
        if xbmc.getCondVisibility("System.Platform.Android"):
            xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","text/html","{0}")'.format(url))
        else:
            import webbrowser
            webbrowser.open(url)
        xbmcgui.Dialog().notification("EspaTV", "Abriendo en el navegador...", xbmcgui.NOTIFICATION_INFO, 2000)
    except (ImportError, OSError):
        xbmcgui.Dialog().ok("Abrir en navegador", "No se pudo abrir automaticamente.\n\nAbre esta URL:\n{0}".format(url))


def _open_yt_app(url, name=""):
    url = url.replace('"', '').replace("'", '') if url else ""
    try:
        xbmc.executebuiltin('StartAndroidActivity("com.google.android.youtube","android.intent.action.VIEW","","{0}")'.format(url))
        xbmcgui.Dialog().notification("EspaTV", "Abriendo app YouTube...", xbmcgui.NOTIFICATION_INFO, 2000)
    except (RuntimeError, OSError):
        xbmcgui.Dialog().ok("App YouTube", "No se pudo abrir la app YouTube.\nAsegurate de que esta instalada.")


def _get_yt_playlists_file():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    return os.path.join(p, 'yt_playlists.json')


def _load_yt_playlists():
    path = _get_yt_playlists_file()
    if not os.path.exists(path):
        return []
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return []


def _save_yt_playlists(data):
    path = _get_yt_playlists_file()
    with open(path, 'w', encoding='utf-8') as f:
        f.write(json.dumps(data, ensure_ascii=False, indent=2))


def _extract_yt_playlist_id(url):
    m = re.search(r'[?&]list=([A-Za-z0-9_-]+)', url)
    if m:
        return m.group(1)
    return None


def _fetch_yt_playlist_title(list_id):
    try:
        import urllib.request as _ur
        url = "https://www.youtube.com/oembed?url=https://www.youtube.com/playlist?list={0}&format=json".format(list_id)
        if requests:
            r = requests.get(url, timeout=5, headers={"User-Agent": "Kodi/EspaTV"})
            if r.status_code == 200:
                data = r.json()
                title = data.get("title", "")
                if title:
                    return title
    except (Exception,):
        pass
    try:
        import urllib.request as _ur
        pl_url = "https://www.youtube.com/playlist?list={0}".format(list_id)
        req = _ur.Request(pl_url, headers=_dh(accept=ACCEPT_HTML))
        html = _ur.urlopen(req, timeout=8).read(51200).decode("utf-8", errors="ignore")
        m = re.search(r'<title>([^<]+)</title>', html)
        if m:
            title = m.group(1).strip()
            if title.endswith(" - YouTube"):
                title = title[:-10].strip()
            if title:
                return title
    except (OSError, ValueError):
        pass
    return None


def add_from_url(url):
    if not url:
        return False
    list_id = _extract_yt_playlist_id(url)
    if not list_id:
        xbmcgui.Dialog().ok("EspaTV", "No se pudo extraer el ID de la playlist.\n\nAsegúrate de pegar una URL válida de playlist de YouTube.\nEjemplo: https://www.youtube.com/playlist?list=PLxxxxxx")
        return False
    saved = _load_yt_playlists()
    for s in saved:
        if s.get('list_id') == list_id:
            xbmcgui.Dialog().notification("EspaTV", "Esta playlist ya está guardada", xbmcgui.NOTIFICATION_WARNING)
            return False
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Obteniendo información de la playlist...")
    title = _fetch_yt_playlist_title(list_id)
    dp.close()
    if not title:
        kb = xbmc.Keyboard('', 'Nombre para esta playlist')
        kb.doModal()
        if not kb.isConfirmed() or not kb.getText().strip():
            title = "Playlist {0}".format(list_id[:12])
        else:
            title = kb.getText().strip()
    saved.append({
        'list_id': list_id,
        'name': title,
        'url': url.strip(),
        'ts': int(time.time()),
    })
    _save_yt_playlists(saved)
    xbmcgui.Dialog().notification("EspaTV", "Playlist guardada: {0}".format(title), xbmcgui.NOTIFICATION_INFO)
    return True


def remove_playlist(list_id):
    saved = _load_yt_playlists()
    saved = [s for s in saved if s.get('list_id') != list_id]
    _save_yt_playlists(saved)


def menu():
    h = int(sys.argv[1])

    li = xbmcgui.ListItem(label="[COLOR limegreen][B]Añadir playlist (teclado)[/B][/COLOR]")
    li.setArt({'icon': 'DefaultAddSource.png'})
    li.setInfo('video', {'plot': "Pega la URL de una playlist de YouTube usando el teclado de Kodi.\nEjemplo: https://www.youtube.com/playlist?list=PLxxxxxx"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="yt_playlist_add"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR lightskyblue][B]Añadir desde móvil/PC[/B][/COLOR]")
    li.setArt({'icon': 'DefaultNetwork.png'})
    li.setInfo('video', {'plot': "Abre un servidor temporal en tu red local.\nDesde el navegador de tu móvil o PC, pega la URL de la playlist de YouTube.\nMás cómodo para URLs largas."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="yt_playlist_add_remote"), listitem=li, isFolder=False)

    saved = _load_yt_playlists()
    if not saved:
        li = xbmcgui.ListItem(label="[COLOR grey]No tienes playlists de YouTube guardadas[/COLOR]")
        li.setInfo('video', {'plot':
            "Para guardar una playlist de YouTube:\n"
            "1. Copia la URL de la playlist en YouTube\n"
            "2. Usa 'Añadir playlist (teclado)' o 'Añadir desde móvil/PC'\n"
            "3. La playlist aparecerá aquí para acceder rápidamente\n\n"
            "Para eliminar una playlist guardada:\n"
            "Mantén pulsado sobre ella → Eliminar playlist"})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
    else:
        for s in saved:
            list_id = s.get('list_id', '')
            name = s.get('name', 'Sin nombre')
            li = xbmcgui.ListItem(label=name)
            li.setArt({'icon': 'DefaultVideoPlaylists.png'})
            li.setInfo('video', {'plot': "Playlist de YouTube\nID: {0}\n\nPulsa para abrir.".format(list_id)})
            ctx = [
                ("Eliminar playlist", "RunPlugin({0})".format(_u(action="yt_playlist_remove", list_id=list_id))),
            ]
            li.addContextMenuItems(ctx)
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="yt_playlist_open", list_id=list_id, name=name), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)


def add_action():
    kb = xbmc.Keyboard('', 'Pega la URL de la playlist de YouTube')
    kb.doModal()
    if not kb.isConfirmed():
        return
    url = kb.getText().strip()
    if not url:
        return
    if add_from_url(url):
        xbmc.executebuiltin("Container.Refresh")


def add_remote():
    import url_remote
    url = url_remote.receive_text("Pegar playlist de YouTube")
    if not url:
        return
    if add_from_url(url):
        xbmc.executebuiltin("Container.Refresh")


def fetch_videos(list_id, include_extra=False):
    try:
        import urllib.request as _ur
        pl_url = "https://www.youtube.com/playlist?list={0}".format(list_id)
        req = _ur.Request(pl_url, headers=_dh(accept=ACCEPT_HTML))
        html = _ur.urlopen(req, timeout=10).read().decode("utf-8", errors="ignore")

        results = []
        seen = set()

        chunks = html.split('"playlistVideoRenderer":')
        for chunk in chunks[1:]:
            v_idx = chunk.find('"videoId":"')
            if v_idx != -1:
                vid = chunk[v_idx + 11: v_idx + 22]
                title = vid
                t_idx = chunk.find('"title":{"runs":[{"text":"', v_idx)
                if t_idx != -1 and (t_idx - v_idx) < 3000:
                    t_start = t_idx + 26
                    t_end = chunk.find('"', t_start)
                    if t_end != -1:
                        title = chunk[t_start:t_end].replace('\\"', '"').replace('\\/', '/').replace('\\\\', '\\')
                if title == vid:
                    t_idx2 = chunk.find('"title":{"simpleText":"', v_idx)
                    if t_idx2 != -1 and (t_idx2 - v_idx) < 3000:
                        t_start2 = t_idx2 + 23
                        t_end2 = chunk.find('"', t_start2)
                        if t_end2 != -1:
                            title = chunk[t_start2:t_end2].replace('\\"', '"').replace('\\/', '/').replace('\\\\', '\\')
                if vid and len(vid) == 11 and vid not in seen:
                    seen.add(vid)
                    item = {"vid": vid, "title": title}

                    if include_extra:
                        idx_start = max(0, v_idx - 100)
                        chunk_slice = chunk[idx_start:v_idx + 2000]

                        channel = ""
                        c_idx = chunk_slice.find('"shortBylineText"')
                        if c_idx != -1:
                            c_text_idx = chunk_slice.find('"text":"', c_idx)
                            if c_text_idx != -1:
                                c_end = chunk_slice.find('"', c_text_idx + 8)
                                if c_end != -1:
                                    channel = chunk_slice[c_text_idx + 8:c_end].replace('\\"', '"')
                        item["channel"] = channel

                        views = ""
                        v_idx_search = chunk_slice.find('"viewCountText"')
                        if v_idx_search != -1:
                            v_text_idx = chunk_slice.find('"simpleText":"', v_idx_search)
                            if v_text_idx != -1:
                                v_end = chunk_slice.find('"', v_text_idx + 14)
                                if v_end != -1:
                                    views = chunk_slice[v_text_idx + 14:v_end]
                        item["views"] = views

                        date = ""
                        d_idx = chunk_slice.find('"publishedTimeText"')
                        if d_idx != -1:
                            d_text_idx = chunk_slice.find('"simpleText":"', d_idx)
                            if d_text_idx != -1:
                                d_end = chunk_slice.find('"', d_text_idx + 14)
                                if d_end != -1:
                                    date = chunk_slice[d_text_idx + 14:d_end]
                        item["date"] = date

                        duration = ""
                        dur_idx = chunk_slice.find('"lengthText"')
                        if dur_idx != -1:
                            dur_text_idx = chunk_slice.find('"simpleText":"', dur_idx)
                            if dur_text_idx != -1:
                                dur_end = chunk_slice.find('"', dur_text_idx + 14)
                                if dur_end != -1:
                                    duration = chunk_slice[dur_text_idx + 14:dur_end]
                        item["duration"] = duration

                        description = ""
                        desc_idx = chunk_slice.find('"description"')
                        if desc_idx != -1:
                            desc_text_idx = chunk_slice.find('"simpleText":"', desc_idx)
                            if desc_text_idx != -1:
                                desc_end = chunk_slice.find('"', desc_text_idx + 14)
                                if desc_end != -1:
                                    description = chunk_slice[desc_text_idx + 14:desc_end]
                        item["description"] = description

                    results.append(item)

        if not results:
            pattern = re.compile(r'"videoId"\s*:\s*"([A-Za-z0-9_\-]{11})".{0,1500}?"title"\s*:\s*\{"runs"\s*:\s*\[\{"text"\s*:\s*"([^"]+)"')
            for match in pattern.finditer(html):
                v, t = match.groups()
                if v not in seen:
                    seen.add(v)
                    results.append({"vid": v, "title": t})
            if not results:
                video_ids = re.findall(r'"videoId"\s*:\s*"([A-Za-z0-9_\-]{11})"', html)
                for vid in video_ids:
                    if vid not in seen:
                        seen.add(vid)
                        results.append({"vid": vid, "title": vid})

        return results
    except (OSError, ValueError):
        return []


def show_list(list_id, name=""):
    if not list_id:
        return
    h = int(sys.argv[1])
    videos = fetch_videos(list_id)
    if not videos:
        li = xbmcgui.ListItem(label="[COLOR grey]No se pudieron obtener los vídeos[/COLOR]")
        li.setInfo('video', {'plot': "No se pudo cargar la playlist.\nPrueba a abrirla en el navegador."})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return
    for i, v in enumerate(videos):
        vid = v["vid"]
        title = v["title"]
        thumb = "https://i.ytimg.com/vi/{0}/hqdefault.jpg".format(vid)
        li = xbmcgui.ListItem(label="{0}. {1}".format(i + 1, title))
        li.setArt({"icon": "DefaultVideo.png", "thumb": thumb, "fanart": thumb})
        li.setInfo("video", {"plot": title, "title": title})
        play_url = _u(action="felicidad_play", yt_id=vid, name=title, ctype="video")
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def open_playlist(list_id, name=""):
    if not list_id:
        return
    h = int(sys.argv[1])
    has_yt = _has_yt_addon()
    is_android = xbmc.getCondVisibility("System.Platform.Android")
    if has_yt:
        li = xbmcgui.ListItem(label="[COLOR limegreen][B]Modo Cine[/B][/COLOR]")
        li.setArt({'icon': 'DefaultMovies.png'})
        li.setInfo('video', {'plot': "Navega los vídeos con miniaturas grandes, metadata completa y fondo dinámico."})
        xbmcplugin.addDirectoryItem(handle=h,
            url=_u(action="yt_cinema_mode", list_id=list_id, name=name),
            listitem=li, isFolder=False)

        li = xbmcgui.ListItem(label="[COLOR limegreen][B]Ver playlist[/B][/COLOR]")
        li.setArt({'icon': 'DefaultVideoPlaylists.png'})
        li.setInfo('video', {'plot': "Muestra todos los vídeos de la playlist.\nElige cuál reproducir."})
        xbmcplugin.addDirectoryItem(handle=h,
            url=_u(action="yt_playlist_list", list_id=list_id, name=name),
            listitem=li, isFolder=True)

        li = xbmcgui.ListItem(label="[COLOR limegreen]Reproducir todo[/COLOR]")
        li.setArt({'icon': 'DefaultVideo.png'})
        li.setInfo('video', {'plot': "Reproduce todos los vídeos de la playlist en cola.\nSin necesidad de API keys."})
        xbmcplugin.addDirectoryItem(handle=h,
            url=_u(action="yt_playlist_open_exec", list_id=list_id, name=name, method="addon"),
            listitem=li, isFolder=False)
    else:
        li = xbmcgui.ListItem(label="[COLOR red][B]Instalar addon YouTube (necesario)[/B][/COLOR]")
        li.setArt({'icon': 'DefaultAddonHelper.png'})
        li.setInfo('video', {'plot': "El addon YouTube de Kodi es necesario para abrir playlists aquí.\nPulsa para ver las instrucciones de instalación."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="youtube_install"), listitem=li, isFolder=False)

    if is_android:
        li = xbmcgui.ListItem(label="[COLOR lightskyblue]Abrir en la app YouTube[/COLOR]")
        li.setArt({'icon': 'DefaultAddonProgram.png'})
        li.setInfo('video', {'plot': "Abre la playlist en la aplicación YouTube de Android."})
        xbmcplugin.addDirectoryItem(handle=h,
            url=_u(action="yt_playlist_open_exec", list_id=list_id, name=name, method="yt_app"),
            listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR orange]Abrir en el navegador[/COLOR]")
    li.setArt({'icon': 'DefaultNetwork.png'})
    li.setInfo('video', {'plot': "Abre la playlist en el navegador web."})
    xbmcplugin.addDirectoryItem(handle=h,
        url=_u(action="yt_playlist_open_exec", list_id=list_id, name=name, method="browser"),
        listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def open_exec(list_id, name="", method="addon"):
    if not list_id:
        return
    web_url = "https://www.youtube.com/playlist?list={0}".format(list_id)
    if method == "addon":
        if not _has_yt_addon():
            _install_yt_addon()
            return
        xbmcgui.Dialog().notification("EspaTV", "Cargando playlist...", xbmcgui.NOTIFICATION_INFO, 2000)
        videos = fetch_videos(list_id)
        if not videos:
            xbmcgui.Dialog().ok("EspaTV", "No se pudieron obtener los vídeos de la playlist.\n\nPrueba a abrirla en el navegador o en la app YouTube.")
            return
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        for v in videos:
            url = "plugin://plugin.video.youtube/play/?video_id={0}".format(v["vid"])
            li = xbmcgui.ListItem(v["title"])
            playlist.add(url, li)
        xbmc.Player().play(playlist)
        xbmcgui.Dialog().notification("EspaTV", "{0} vídeos en cola".format(len(videos)), xbmcgui.NOTIFICATION_INFO, 2000)
    elif method == "yt_app":
        _open_yt_app(web_url, name)
    elif method == "browser":
        _open_browser(web_url, name)
