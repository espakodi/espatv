# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Búsqueda de vídeos y canales en YouTube, con historial persistente."""
import json
import os
import re
import sys
import urllib.parse
import urllib.request
import urllib.error

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from _user_agents import desktop_headers as _dh, ACCEPT_HTML

_YT_SP_DURATION = [
    ("Cualquier duración", ""),
    ("Cortos (< 4 min)",   "EgIYAQ=="),
    ("Medios (4-20 min)",  "EgIYAw=="),
    ("Largos (> 20 min)",  "EgIYAg=="),
]
_YT_SP_DATE = [
    ("Cualquier fecha", ""),
    ("Última hora",     "EgIIAQ=="),
    ("Hoy",             "EgIIAg=="),
    ("Esta semana",     "EgIIAw=="),
    ("Este mes",        "EgIIBA=="),
    ("Este año",        "EgIIBQ=="),
]
_YT_SP_SORT = [
    ("Relevancia",        ""),
    ("Fecha de subida",   "CAISAhAB"),
    ("Número de visitas", "CAMSAhAB"),
    ("Valoración",        "CAESAhAB"),
]


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _get_yt_history_file():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    return os.path.join(p, 'yt_search_history.json')


def load_yt_history():
    f = _get_yt_history_file()
    if not os.path.exists(f):
        return []
    try:
        with open(f, 'r', encoding='utf-8') as fh:
            return json.load(fh)
    except (ValueError, IOError):
        return []


def _add_yt_to_history(q):
    q = q.strip()
    if not q:
        return
    hist = load_yt_history()
    if q in hist:
        hist.remove(q)
    hist.insert(0, q)
    hist = hist[:30]
    try:
        with open(_get_yt_history_file(), 'w', encoding='utf-8') as fh:
            json.dump(hist, fh)
    except IOError:
        pass


def remove_yt_history_item(q):
    if not q:
        return
    yh = load_yt_history()
    yh = [x for x in yh if x != q]
    try:
        with open(_get_yt_history_file(), 'w', encoding='utf-8') as o:
            json.dump(yh, o)
    except OSError:
        pass
    xbmc.executebuiltin("Container.Refresh")


def clear_yt_history():
    yh = load_yt_history()
    if yh and xbmcgui.Dialog().yesno("Confirmar", "¿Borrar todo el historial de YouTube? ({0} elementos)".format(len(yh))):
        try:
            with open(_get_yt_history_file(), 'w', encoding='utf-8') as o:
                json.dump([], o)
        except OSError:
            pass
        xbmcgui.Dialog().notification("EspaTV", "Historial YouTube borrado", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")


def _yt_parse_initial_data(html):
    m = re.search(r'var ytInitialData\s*=\s*(\{.*?\});\s*</script>', html)
    if not m:
        return None
    try:
        return json.loads(m.group(1))
    except (ValueError, TypeError):
        return None


def _yt_extract_videos(data):
    results = []
    try:
        sections = data["contents"]["twoColumnSearchResultsRenderer"]["primaryContents"]["sectionListRenderer"]["contents"]
    except (KeyError, TypeError):
        return results
    for section in sections:
        isr = section.get("itemSectionRenderer")
        if not isr:
            continue
        for item in isr.get("contents", []):
            vr = item.get("videoRenderer")
            if not vr:
                continue
            vid = vr.get("videoId", "")
            if not vid:
                continue
            title = ""
            runs = vr.get("title", {}).get("runs", [])
            if runs:
                title = runs[0].get("text", "")
            dur = vr.get("lengthText", {}).get("simpleText", "")
            channel = ""
            chan_runs = vr.get("ownerText", {}).get("runs", [])
            if chan_runs:
                channel = chan_runs[0].get("text", "")
            views = vr.get("viewCountText", {}).get("simpleText", "")
            if not views:
                views = vr.get("shortViewCountText", {}).get("simpleText", "")
            published = vr.get("publishedTimeText", {}).get("simpleText", "")
            results.append({
                "vid": vid,
                "title": title or "Video",
                "duration": dur,
                "channel": channel,
                "views": views,
                "published": published,
            })
    return results


def _yt_fallback_parse(html):
    results = []
    seen = set()
    pattern = re.compile(r'"videoRenderer":\{"videoId":"([^"]{11})".*?"title":\{"runs":\[\{"text":"([^"]+)"\}')
    for m in pattern.finditer(html):
        vid, title = m.group(1), m.group(2)
        if vid not in seen:
            seen.add(vid)
            results.append({"vid": vid, "title": title, "duration": "", "channel": "", "views": ""})
        if len(results) >= 20:
            break
    return results


def fetch_search_results(query, sp=""):
    """Devuelve la lista de resultados sin construir UI. Lanza OSError/ValueError si falla."""
    encoded = urllib.parse.quote_plus(query)
    url = "https://www.youtube.com/results?search_query={0}".format(encoded)
    if sp:
        url += "&sp={0}".format(urllib.parse.quote(sp, safe=''))
    req = urllib.request.Request(url, headers=_dh(accept=ACCEPT_HTML))
    html = urllib.request.urlopen(req, timeout=15).read().decode("utf-8")
    data = _yt_parse_initial_data(html)
    return _yt_extract_videos(data) if data else _yt_fallback_parse(html)


def search_results(query, sp=""):
    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Buscando en YouTube: {0}...".format(query))
    try:
        results = fetch_search_results(query, sp)
        dp.update(60)
        dp.close()
    except (urllib.error.URLError, OSError, ValueError) as e:
        dp.close()
        xbmc.log("[EspaTV] Error buscando en YouTube: {0}".format(e), xbmc.LOGERROR)
        xbmcgui.Dialog().ok("EspaTV", "Error al buscar en YouTube:\n{0}".format(str(e)))
        return

    if not results:
        xbmcgui.Dialog().ok("EspaTV", "No se encontraron resultados para:\n{0}".format(query))
        return

    xbmcplugin.setContent(h, 'videos')

    li_cinema = xbmcgui.ListItem(label="[COLOR FF38BDF8][B]Modo Cine[/B][/COLOR]")
    li_cinema.setArt({'icon': 'DefaultMovies.png'})
    li_cinema.setInfo('video', {'plot': "Navega los resultados con miniaturas grandes y fondo dinámico."})
    xbmcplugin.addDirectoryItem(handle=h,
        url=_u(action="yt_search_cinema", query=query, sp=sp),
        listitem=li_cinema, isFolder=False)

    for r in results:
        vid = r["vid"]
        title = r["title"]
        dur = r["duration"]
        channel = r["channel"]
        views = r["views"]

        li = xbmcgui.ListItem(label=title)
        thumb = 'https://i.ytimg.com/vi/{0}/hqdefault.jpg'.format(vid)
        li.setArt({'icon': 'DefaultMusicVideos.png', 'thumb': thumb})

        published = r.get("published", "")
        plot_lines = []
        if channel:
            plot_lines.append("Canal: {0}".format(channel))
        if dur:
            plot_lines.append("Duración: {0}".format(dur))
        if views:
            plot_lines.append("Vistas: {0}".format(views))
        if published:
            plot_lines.append("Subido: {0}".format(published))
        plot = "\n".join(plot_lines) if plot_lines else title
        li.setInfo('video', {'plot': plot, 'title': title})

        fav_params = json.dumps({"yt_id": vid, "name": title, "ctype": "video", "burl": ""})
        li.addContextMenuItems([("Añadir a Mis Favoritos", "RunPlugin({0})".format(
            _u(action='add_favorite', title=title, fav_url='yt_{0}'.format(vid),
               icon=thumb, platform='youtube', fav_action='felicidad_play', params=fav_params)
        ))])
        play_url = _u(action="felicidad_play", yt_id=vid, name=title, ctype="video")
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[COLOR yellow][B]Buscar otra cosa en YouTube...[/B][/COLOR]")
    li.setArt({'icon': 'DefaultAddonsSearch.png'})
    li.setInfo('video', {'plot': 'YouTube muestra hasta 20 resultados por búsqueda. Si necesitas más, prueba con términos más específicos.'})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="yt_search"), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)


def channel_search():
    kb = xbmc.Keyboard('', 'Nombre del canal de YouTube')
    kb.doModal()
    if not kb.isConfirmed():
        return
    q = kb.getText().strip()
    if not q:
        return
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Buscando canales: {0}...".format(q))
    try:
        encoded = urllib.parse.quote_plus(q)
        url = "https://www.youtube.com/results?search_query={0}&sp=EgIQAg%3D%3D".format(encoded)
        req = urllib.request.Request(url, headers=_dh(accept=ACCEPT_HTML))
        html = urllib.request.urlopen(req, timeout=15).read().decode("utf-8")
        dp.update(60)
        data = _yt_parse_initial_data(html)
        dp.close()
    except (urllib.error.URLError, OSError, ValueError) as e:
        dp.close()
        xbmcgui.Dialog().ok("EspaTV", "Error al buscar canales:\n{0}".format(str(e)))
        return

    if not data:
        xbmcgui.Dialog().ok("EspaTV", "No se pudo obtener datos de YouTube.")
        return

    channels = []
    try:
        sections = data["contents"]["twoColumnSearchResultsRenderer"]["primaryContents"]["sectionListRenderer"]["contents"]
        for section in sections:
            isr = section.get("itemSectionRenderer")
            if not isr:
                continue
            for item in isr.get("contents", []):
                cr = item.get("channelRenderer")
                if cr:
                    ch_id = cr.get("channelId", "")
                    ch_title = cr.get("title", {}).get("simpleText", "")
                    ch_subs = cr.get("videoCountText", {}).get("simpleText", "")
                    ch_desc = ""
                    desc_runs = cr.get("descriptionSnippet", {}).get("runs", [])
                    for r in desc_runs:
                        ch_desc += r.get("text", "")
                    ch_thumb = ""
                    thumbs = cr.get("thumbnail", {}).get("thumbnails", [])
                    if thumbs:
                        ch_thumb = thumbs[-1].get("url", "")
                        if ch_thumb.startswith("//"):
                            ch_thumb = "https:" + ch_thumb
                    channels.append({
                        "id": ch_id, "title": ch_title, "subs": ch_subs,
                        "desc": ch_desc, "thumb": ch_thumb
                    })
    except (KeyError, TypeError):
        pass

    if not channels:
        xbmcgui.Dialog().ok("EspaTV", "No se encontraron canales para:\n{0}".format(q))
        return

    h = int(sys.argv[1])
    for ch in channels:
        label = ch["title"]
        if ch["subs"]:
            label += " [COLOR gray]({0})[/COLOR]".format(ch["subs"])
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': ch["thumb"] or 'DefaultActor.png', 'thumb': ch["thumb"] or 'DefaultActor.png'})
        plot = ch["desc"][:300] if ch["desc"] else "Canal de YouTube"
        li.setInfo('video', {'title': ch["title"], 'plot': plot})
        play_url = _u(action="felicidad_play", yt_id=ch["id"], name=ch["title"], ctype="channel")
        fav_params = json.dumps({"yt_id": ch["id"], "name": ch["title"], "ctype": "channel", "burl": ""})
        li.addContextMenuItems([("Añadir a Mis Favoritos", "RunPlugin({0})".format(
            _u(action='add_favorite', title=ch["title"], fav_url='yt_ch_{0}'.format(ch["id"]),
               icon=ch["thumb"], platform='youtube', fav_action='felicidad_play', params=fav_params)
        ))])
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def search():
    opts = ["Búsqueda normal", "Buscar con filtros", "Buscar canal de YouTube", "Escribir desde movil/PC"]
    sel = xbmcgui.Dialog().select("Búsqueda en YouTube", opts)
    if sel < 0:
        return

    if sel == 2:
        channel_search()
        return

    if sel == 3:
        import url_remote
        q = url_remote.receive_text("Buscar en YouTube")
        if not q:
            return
    else:
        kb = xbmc.Keyboard('', 'Buscar en YouTube')
        kb.doModal()
        if not kb.isConfirmed():
            return
        q = kb.getText().strip()
        if not q:
            return

    sp = ""
    if sel == 1:
        dur_labels = [x[0] for x in _YT_SP_DURATION]
        d = xbmcgui.Dialog().select("Filtrar por duración", dur_labels)
        if d > 0:
            sp = _YT_SP_DURATION[d][1]

        date_labels = [x[0] for x in _YT_SP_DATE]
        dt = xbmcgui.Dialog().select("Filtrar por fecha", date_labels)
        if dt > 0:
            sp = _YT_SP_DATE[dt][1]

        sort_labels = [x[0] for x in _YT_SP_SORT]
        s = xbmcgui.Dialog().select("Ordenar por", sort_labels)
        if s > 0:
            sp = _YT_SP_SORT[s][1]

    _add_yt_to_history(q)
    search_results(q, sp)
