# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
import os
import sys
import json
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings

_cats_file = None

def _get_cats_file():
    global _cats_file
    if _cats_file is None:
        profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
        if not os.path.exists(profile):
            os.makedirs(profile)
        _cats_file = os.path.join(profile, 'custom_categories.json')
    return _cats_file

def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def _handle():
    return int(sys.argv[1])

def load_cats():
    f = _get_cats_file()
    if not os.path.exists(f):
        return {}
    try:
        with open(f, 'r', encoding='utf-8') as fp:
            return json.load(fp)
    except (OSError, ValueError):
        return {}

def save_cats(data):
    f = _get_cats_file()
    try:
        with open(f, 'w', encoding='utf-8') as fp:
            json.dump(data, fp, ensure_ascii=False)
    except OSError:
        pass


def main_menu():
    cats = load_cats()
    h = _handle()
    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _ico(name, fallback):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    li = xbmcgui.ListItem(label="[COLOR yellow][B]+ CREAR NUEVA CATEGORÍA[/B][/COLOR]")
    li.setArt({'icon': _ico('adv_ruta_dl.png', 'DefaultAddonService.png')})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cat_create"), listitem=li, isFolder=False)

    for name in sorted(cats.keys()):
        num_items = len(cats[name])
        li = xbmcgui.ListItem(label="{0} [COLOR gray]({1})[/COLOR]".format(name, num_items))
        li.setArt({'icon': _ico('cat_web.png', 'DefaultFolder.png')})
        cm = [
            ("Renombrar Categoría", "RunPlugin({0})".format(_u(action='cat_rename', name=name))),
            ("Borrar Categoría", "RunPlugin({0})".format(_u(action='cat_delete', name=name))),
        ]
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cat_view", name=name), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[COLOR cyan][B][Importar / Exportar][/B][/COLOR]")
    li.setArt({'icon': _ico('fav_export.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Opciones para importar y exportar tus categorías."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cat_io_menu"), listitem=li, isFolder=True)
        
    xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.is_iptv_cache_active())

def io_menu():
    h = _handle()
    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _ico(name, fallback):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    li = xbmcgui.ListItem(label="[COLOR cyan]Exportar Categorías...[/COLOR]")
    li.setArt({'icon': _ico('fav_export.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Guarda tus categorías en un archivo JSON para compartirlas o hacer una copia de seguridad."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cat_export"), listitem=li, isFolder=False)
    
    li = xbmcgui.ListItem(label="[COLOR cyan]Importar Categorías...[/COLOR]")
    li.setArt({'icon': _ico('fav_import.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Carga categorías desde un archivo JSON. Puedes fusionarlas con las existentes o reemplazarlas."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="cat_import"), listitem=li, isFolder=False)
        
    xbmcplugin.endOfDirectory(h)

def create_category():
    kb = xbmc.Keyboard('', 'Nombre de la nueva categoría')
    kb.doModal()
    if not kb.isConfirmed():
        return
    name = kb.getText().strip()
    if not name:
        return

    cats = load_cats()
    if name in cats:
        xbmcgui.Dialog().notification("EspaTV", "La categoría ya existe", xbmcgui.NOTIFICATION_ERROR)
        return

    cats[name] = []
    save_cats(cats)
    xbmc.executebuiltin("Container.Refresh")

def delete_category(name):
    if not name:
        return
    if not xbmcgui.Dialog().yesno(
        "Borrar Categoría",
        "¿Estás seguro de borrar '{0}'?\nSe perderá la organización de los elementos dentro.".format(name),
    ):
        return

    cats = load_cats()
    if name not in cats:
        xbmcgui.Dialog().notification(
            "EspaTV", "Error: Categoría '{0}' no encontrada".format(name), xbmcgui.NOTIFICATION_ERROR)
        return

    del cats[name]
    save_cats(cats)
    time.sleep(0.2)
    xbmc.executebuiltin("Container.Refresh")

def rename_category(name):
    if not name:
        return
    kb = xbmc.Keyboard(name, 'Renombrar categoría')
    kb.doModal()
    if not kb.isConfirmed():
        return
    new_name = kb.getText().strip()
    if not new_name or new_name == name:
        return

    cats = load_cats()
    if new_name in cats:
        xbmcgui.Dialog().notification("EspaTV", "Ya existe una categoría con ese nombre", xbmcgui.NOTIFICATION_ERROR)
        return

    cats[new_name] = cats.pop(name, [])
    save_cats(cats)
    xbmc.executebuiltin("Container.Refresh")

def view_category(name):
    if not name:
        return
    
    cats = load_cats()
    items = cats.get(name, [])
    h = _handle()
    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    def _ico(name, fallback):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback
    
    if not items:
        li = xbmcgui.ListItem(label="[COLOR gray]Categoría vacía. Añade elementos desde el historial.[/COLOR]")
        li.setArt({'icon': _ico('info.png', 'DefaultIconInfo.png')})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
    else:
        addon = xbmcaddon.Addon()
        icon = addon.getAddonInfo('icon')
        
        for q in items:
            li = xbmcgui.ListItem(label=q)
            li.setArt({'icon': _ico('busqueda.png', 'DefaultFolder.png'), 'thumb': icon})
            
            cm = []
            cm.append(("Editar y buscar", "RunPlugin({0})".format(_u(action='edit_and_search', q=q, ot=icon))))
            cm.append(("Mover a otra categoría...", "RunPlugin({0})".format(_u(action='cat_move_item', from_cat=name, q=q))))
            cm.append(("Quitar de esta categoría", "RunPlugin({0})".format(_u(action='cat_remove_item', cat=name, q=q))))
            li.addContextMenuItems(cm)
            
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="lfr", q=q, ot=icon, nh=1), listitem=li, isFolder=True)
            
    xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.is_iptv_cache_active())

def add_item_dialog(q):
    if not q:
        return False

    cats = load_cats()

    if not cats:
        if not xbmcgui.Dialog().yesno("Sin Categorías", "No tienes categorías creadas.\n¿Quieres crear una ahora?"):
            return False
        create_category()
        cats = load_cats()
        if not cats:
            return False

    cat_names = sorted(cats.keys())
    sel = xbmcgui.Dialog().select("Añadir '{0}' a...".format(q), cat_names)
    if sel < 0:
        return False

    target_cat = cat_names[sel]
    if q not in cats[target_cat]:
        cats[target_cat].append(q)
        save_cats(cats)
        xbmcgui.Dialog().notification("EspaTV", "Añadido a '{0}'".format(target_cat), xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification("EspaTV", "Ya estaba en esa categoría", xbmcgui.NOTIFICATION_INFO)

    return True

def remove_item(cat, q):
    if not cat or not q:
        return
    cats = load_cats()
    if cat in cats and q in cats[cat]:
        cats[cat].remove(q)
        save_cats(cats)
        xbmc.executebuiltin("Container.Refresh")

def move_item(from_cat, q):
    if not from_cat or not q:
        return

    cats = load_cats()
    other_cats = [c for c in sorted(cats.keys()) if c != from_cat]

    if not other_cats:
        xbmcgui.Dialog().notification("EspaTV", "No hay otras categorías", xbmcgui.NOTIFICATION_INFO)
        return

    sel = xbmcgui.Dialog().select("Mover '{0}' a...".format(q), other_cats)
    if sel < 0:
        return

    target_cat = other_cats[sel]

    if from_cat in cats and q in cats[from_cat]:
        cats[from_cat].remove(q)
    if q not in cats[target_cat]:
        cats[target_cat].append(q)

    save_cats(cats)
    xbmcgui.Dialog().notification("EspaTV", "Movido a '{0}'".format(target_cat), xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def export_categories():
    cats = load_cats()
    if not cats:
        xbmcgui.Dialog().notification("EspaTV", "No hay categorías para exportar", xbmcgui.NOTIFICATION_INFO)
        return
    
    ts = time.strftime("%Y%m%d_%H%M")
    default_name = "EspaTV_categorias_{0}.json".format(ts)
    
    d = xbmcgui.Dialog().browse(3, 'Guardar Categorías', 'files', '', False, False, default_name)
    if not d: return
    
    if os.path.isdir(d):
        d = os.path.join(d, default_name)
    elif not d.lower().endswith(".json"):
        d += ".json"
    
    try:
        with open(d, 'w', encoding='utf-8') as f:
            json.dump(cats, f, ensure_ascii=False, indent=2)
    except OSError as e:
        xbmcgui.Dialog().ok("Error", str(e))
        return

    total_items = sum(len(v) for v in cats.values())
    xbmcgui.Dialog().ok(
        "Exportar Categorías",
        "Guardado correctamente:\n{0}\n\nCategorías: {1}\nElementos: {2}".format(
            os.path.basename(d), len(cats), total_items),
    )

def import_categories():
    f = xbmcgui.Dialog().browse(1, 'Seleccionar archivo de categorías', 'files', '.json', False, False, '')
    if not f:
        return

    try:
        with open(f, 'r', encoding='utf-8') as fp:
            new_cats = json.load(fp)
    except (OSError, ValueError) as e:
        xbmcgui.Dialog().ok("Error", str(e))
        return

    if not isinstance(new_cats, dict):
        xbmcgui.Dialog().ok("Error", "El archivo no tiene el formato correcto.")
        return

    opts = ["Fusionar con las existentes", "Reemplazar todas"]
    sel = xbmcgui.Dialog().select("¿Cómo importar?", opts)
    if sel < 0:
        return

    if sel == 0:
        existing = load_cats()
        for cat_name, items in new_cats.items():
            if cat_name in existing:
                for item in items:
                    if item not in existing[cat_name]:
                        existing[cat_name].append(item)
            else:
                existing[cat_name] = items
        save_cats(existing)
        xbmcgui.Dialog().notification("EspaTV", "Categorías fusionadas", xbmcgui.NOTIFICATION_INFO)
    else:
        save_cats(new_cats)
        xbmcgui.Dialog().notification("EspaTV", "Categorías reemplazadas", xbmcgui.NOTIFICATION_INFO)

    xbmc.executebuiltin("Container.Refresh")