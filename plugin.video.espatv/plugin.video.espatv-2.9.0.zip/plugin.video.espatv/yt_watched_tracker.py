# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Seguimiento de vídeos de YouTube marcados como vistos."""
import json
import os

import xbmc
import xbmcgui

import core_settings

_FILE = os.path.join(core_settings._PROFILE_PATH, 'watched_yt.json')


def load():
    if not os.path.exists(_FILE):
        return set()
    try:
        with open(_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return set(data) if isinstance(data, list) else set()
    except (OSError, ValueError):
        return set()


def save(ids):
    try:
        with open(_FILE, 'w', encoding='utf-8') as f:
            json.dump(list(ids), f)
    except OSError:
        pass


def toggle(yt_id):
    if not yt_id:
        return
    ids = load()
    if yt_id in ids:
        ids.discard(yt_id)
        xbmcgui.Dialog().notification("EspaTV", "Desmarcado como visto", xbmcgui.NOTIFICATION_INFO, 1500)
    else:
        ids.add(yt_id)
        xbmcgui.Dialog().notification("EspaTV", "Marcado como visto", xbmcgui.NOTIFICATION_INFO, 1500)
    save(ids)
    xbmc.executebuiltin("Container.Refresh")
