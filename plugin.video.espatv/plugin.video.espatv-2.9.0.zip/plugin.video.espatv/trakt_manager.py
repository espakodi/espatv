# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
import os
import sys
import json
import time
import threading
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import requests

import core_settings


_TRAKT_API_BASE = "https://api.trakt.tv"
_TMDB_API_BASE = "https://api.themoviedb.org/3"
_TMDB_IMG_BASE = "https://image.tmdb.org/t/p/w342"


def _trakt_headers(api_key):
    return {
        'Content-Type': 'application/json',
        'trakt-api-version': '2',
        'trakt-api-key': api_key,
    }


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def _handle():
    return int(sys.argv[1])

def _get_thumb_cache_path(list_id):
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    return os.path.join(p, "trakt_thumbs_{0}.json".format(list_id))

def _load_thumb_cache(list_id):
    path = _get_thumb_cache_path(list_id)
    if not os.path.exists(path):
        return {}
    try:
        with open(path, 'r', encoding='utf-8') as f:
            return json.load(f)
    except (OSError, ValueError):
        return {}

def _get_tmdb_data(tmdb_id, fallback, media_type='movie'):
    if not tmdb_id:
        return fallback, [], ''
    endpoint = 'tv' if media_type == 'show' else 'movie'
    try:
        r = requests.get(
            "{0}/{1}/{2}".format(_TMDB_API_BASE, endpoint, tmdb_id),
            params={
                "api_key": core_settings.get_tmdb_api_key(),
                "append_to_response": "credits",
                "language": "es-ES",
            },
            timeout=8,
        )
        if r.status_code == 200:
            d = r.json()
            poster_path = d.get("poster_path")
            thumb = "{0}{1}".format(_TMDB_IMG_BASE, poster_path) if poster_path else fallback
            credits = d.get('credits') or {}
            cast = [
                {
                    'name': a.get('name', ''),
                    'role': a.get('character', ''),
                    'thumbnail': "https://image.tmdb.org/t/p/w185{0}".format(a['profile_path']) if a.get('profile_path') else '',
                }
                for a in (credits.get('cast') or [])[:10]
            ]
            if media_type == 'show':
                creators = d.get('created_by') or []
                director = ', '.join(c.get('name', '') for c in creators if c.get('name')) or next(
                    (p.get('name', '') for p in (credits.get('crew') or []) if p.get('job') == 'Director'),
                    '',
                )
            else:
                director = next(
                    (p.get('name', '') for p in (credits.get('crew') or []) if p.get('job') == 'Director'),
                    '',
                )
            return thumb, cast, director
    except (requests.RequestException, ValueError):
        pass
    return fallback, [], ''

def menu_collections():
    li = xbmcgui.ListItem(label="Listas de Trakt.tv")
    li.setArt({'icon': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_root"), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(_handle())

def menu_trakt_root():
    core_settings.seed_default_trakt_lists(core_settings.get_trakt_api_key())

    li = xbmcgui.ListItem(label="Actualizar nombres y datos")
    li.setArt({'icon': _tm_media_icon('adv_refrescar.png', 'DefaultAddonService.png')})
    li.setInfo('video', {'plot': "Obtiene el nombre real y el número de ítems de todas las listas desde Trakt."})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_refresh_defaults"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR cyan]Descubrir listas de Trakt[/COLOR]")
    li.setArt({'icon': 'DefaultVideoPlaylists.png'})
    li.setInfo('video', {'plot': "Explora las listas curadas más populares y trending de Trakt.tv."})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_discover_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[COLOR blue]Opciones / Importar Lista[/COLOR]")
    li.setArt({'icon': 'DefaultAddonService.png'})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_options"), listitem=li, isFolder=True)

    lists = core_settings.get_trakt_lists()
    for l in lists:
        count = l.get('item_count', 0)
        label = "{0} [COLOR gray]({1} ítems)[/COLOR]".format(l['name'], count)
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _tm_media_icon('top_trakt_listas.png', 'DefaultFolder.png')})
        li.setInfo('video', {'plot': "ID: {0}\nUsuario: {1}\nTotal: {2} elementos.".format(l['id'], l['user'], count)})

        cm = [("Eliminar lista", "RunPlugin({0})".format(_u(action='trakt_delete_list', list_id=l['id'])))]
        li.addContextMenuItems(cm)

        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_view_list", list_id=l['id']), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(_handle())

def refresh_all_lists():
    api_key = core_settings.get_trakt_api_key()
    if not api_key:
        xbmcgui.Dialog().notification("Error", "No hay API Key configurada", xbmcgui.NOTIFICATION_ERROR)
        return
    lists = core_settings.get_trakt_lists()
    if not lists:
        xbmcgui.Dialog().notification("Trakt", "No hay listas para actualizar", xbmcgui.NOTIFICATION_INFO)
        return
    headers = _trakt_headers(api_key)
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaTV", "Actualizando listas de Trakt...")
    total = len(lists)
    for i, l in enumerate(lists):
        if pDialog.iscanceled():
            break
        pDialog.update(int((i / total) * 100), "({0}/{1}) {2}".format(i + 1, total, l['name']))
        try:
            r = requests.get(
                "{0}/lists/{1}".format(_TRAKT_API_BASE, l['id']),
                headers=headers, timeout=5,
            )
            if r.status_code == 200:
                data = r.json()
                l['name'] = data.get('name', l['name'])
                user_data = data.get('user')
                if isinstance(user_data, dict):
                    l['user'] = user_data.get('username', l.get('user', 'official'))
                else:
                    l['user'] = l.get('user', 'official')
                l['item_count'] = data.get('item_count', l.get('item_count', 0))
        except (requests.RequestException, ValueError):
            pass
    pDialog.close()
    settings = core_settings.get_trakt_settings()
    existing = {l['id']: l for l in settings.get('lists', [])}
    for l in lists:
        if l['id'] in existing:
            existing[l['id']].update(l)
    settings['lists'] = list(existing.values())
    core_settings.save_trakt_settings(settings)
    xbmcgui.Dialog().notification("EspaTV", "Listas actualizadas correctamente", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def menu_options():
    li = xbmcgui.ListItem(label="[COLOR yellow][B]Guía: Cómo obtener tu API Key (Paso a Paso)[/B][/COLOR]")
    li.setArt({'icon': 'DefaultIconInfo.png'})
    li.setInfo('video', {'plot': "Instrucciones detalladas de cómo registrarte en Trakt.tv para obtener tu propia llave Client ID."})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_help_guide"), listitem=li, isFolder=False)

    key = core_settings.get_trakt_api_key()
    status = "[COLOR green]CONFIGURADA[/COLOR]" if key else "[COLOR red]NO CONFIGURADA[/COLOR]"

    li = xbmcgui.ListItem(label="Configurar API Key {0}".format(status))
    li.setArt({'icon': 'DefaultAddonService.png'})
    li.setInfo('video', {'plot': "Pulsa aquí para introducir tu Client ID una vez lo tengas."})
    xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_set_key"), listitem=li, isFolder=False)

    if key:
        li = xbmcgui.ListItem(label="Importar Lista por ID")
        li.setArt({'icon': 'DefaultAddonService.png'})
        li.setInfo('video', {'plot': "Introduce el ID numérico de la lista pública (ej: 21583416)"})
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action="trakt_import"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(_handle())

def help_guide():
    heading = "[COLOR yellow]GUÍA: CONFIGURAR TRAKT.TV[/COLOR]"
    text = (
        "[B]PASO 1: REGISTRO[/B]\n"
        "Entra en tu navegador (PC o móvil) a:\n"
        "[COLOR cyan]https://trakt.tv/oauth/applications[/COLOR]\n"
        "Identifícate con tu cuenta de usuario.\n\n"

        "[B]PASO 2: CREAR APLICACIÓN[/B]\n"
        "Pulsa el botón verde [B]NEW APPLICATION[/B].\n\n"

        "[B]PASO 3: RELLENAR DATOS[/B]\n"
        "Copia y pega exactamente esto en los cuadros:\n"
        " • [B]Name:[/B] EspaTV\n"
        " • [B]Description:[/B] Addon de Kodi\n"
        " • [B]Redirect uri:[/B] urn:ietf:wg:oauth:2.0:oob\n"
        " • [B]Javascript (cors) origins:[/B] (Vacío)\n"
        " • [B]Permissions:[/B] No marques nada.\n\n"
        "Baja al final y dale al botón morado [B]SAVE APP[/B].\n\n"

        "[B]PASO 4: OBTENER EL CÓDIGO[/B]\n"
        "Tras guardar, aparecerán varios códigos.\n"
        "Busca el que dice [B]Client ID[/B] (es una línea de letras y números).\n\n"
        "Copia ese código y pégalo en el menú 'Configurar API Key' de este addon.\n\n"
        "--------------------------------------------------\n"
        "[I]* Nota: La API Key es personal y gratuita. Solo sirve para que el addon pueda leer las listas públicas de Trakt.tv.[/I]"
    )
    xbmcgui.Dialog().textviewer(heading, text)

def set_api_key():
    k = xbmc.Keyboard(core_settings.get_trakt_api_key(), 'Introduce Trakt Client ID (API Key)')
    k.doModal()
    if k.isConfirmed():
        key = k.getText().strip()
        core_settings.set_trakt_api_key(key)
        xbmcgui.Dialog().notification("EspaTV", "API Key Guardada", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")

def import_list():
    key = core_settings.get_trakt_api_key()
    if not key:
        xbmcgui.Dialog().notification("Error", "Configura la API Key primero", xbmcgui.NOTIFICATION_ERROR)
        return

    k = xbmc.Keyboard('', 'Introduce ID numérico de la lista')
    k.doModal()
    if not k.isConfirmed():
        return
    list_id = k.getText().strip()
    if not list_id:
        return

    headers = _trakt_headers(key)
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaTV", "Importando lista de Trakt...")
    try:
        r = requests.get(
            "{0}/lists/{1}".format(_TRAKT_API_BASE, list_id),
            headers=headers, timeout=15,
        )
        if r.status_code != 200:
            xbmcgui.Dialog().notification(
                "Error Trakt",
                "Error {0}: No se pudo leer la lista".format(r.status_code),
                xbmcgui.NOTIFICATION_ERROR,
            )
            return
        data = r.json()
        name = data.get('name', 'Lista {0}'.format(list_id))
        user_data = data.get('user', {})
        user = user_data.get('username', 'Unknown') if isinstance(user_data, dict) else 'Unknown'
        item_count = data.get('item_count', 0)
        core_settings.add_trakt_list(list_id, name, user, item_count)
    except (requests.RequestException, ValueError) as e:
        xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)
        return
    finally:
        pDialog.close()

    if xbmcgui.Dialog().yesno("EspaTV", "Lista '{0}' importada con éxito.\n\n¿Quieres abrirla ahora mismo?".format(name)):
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='trakt_view_list', list_id=list_id)))
    else:
        xbmc.executebuiltin("Container.Update({0})".format(_u(action='trakt_root')))

def _trigger_bg_enrich_trakt(items):
    import metadata_enricher as me
    def _fetch():
        try:
            results = me.batch_enrich(items, max_workers=2)
            if any(results):
                xbmc.executebuiltin("Container.Refresh")
        except Exception:
            pass
    threading.Thread(target=_fetch, daemon=True).start()


def view_list(list_id, show_covers=False):
    try:
        key = core_settings.get_trakt_api_key()
        if not key:
            xbmcgui.Dialog().notification("Error", "Falta API Key", xbmcgui.NOTIFICATION_ERROR)
            return

        headers = _trakt_headers(key)
        url = "{0}/lists/{1}/items?extended=full".format(_TRAKT_API_BASE, list_id)

        try:
            r = requests.get(url, headers=headers, timeout=15)
            items = r.json()
        except (requests.RequestException, ValueError):
            xbmcplugin.endOfDirectory(_handle())
            return

        if not isinstance(items, list):
            msg = items.get('message', 'Error desconocido') if isinstance(items, dict) else "Respuesta no válida"
            xbmcgui.Dialog().ok("Error Trakt", "No se pudieron cargar los elementos:\n{0}".format(msg))
            xbmcplugin.endOfDirectory(_handle())
            return

        import metadata_enricher as me
        addon = xbmcaddon.Addon()
        ai = addon.getAddonInfo('icon')
        af = addon.getAddonInfo('fanart')

        # trakt_thumbs cache: compatibilidad hacia atrás para usuarios que ya tenían carátulas guardadas
        cache = _load_thumb_cache(list_id)

        missing_meta = []

        for item in items:
            if not isinstance(item, dict):
                continue
            t = item.get('type')
            data = item.get(t)
            if not data:
                continue

            title = data.get('title')
            year = data.get('year')
            overview = data.get('overview') or ''
            tagline = data.get('tagline') or ''
            genres = data.get('genres') or []
            rating = data.get('rating') or 0
            runtime = data.get('runtime') or 0
            certification = data.get('certification') or ''
            ids = data.get('ids') or {}
            tmdb_id = ids.get('tmdb')
            imdb_id = ids.get('imdb') or ''

            item_key = "{0}_{1}".format(title, year)
            label = "{0} ({1})".format(title, year) if year else title
            li = xbmcgui.ListItem(label=label)

            meta = me.enrich(
                tmdb_id=tmdb_id, imdb_id=imdb_id,
                title=title, year=year,
                media_type=t, use_cache_only=True,
            )

            if meta:
                me.apply_to_listitem(li, meta, addon_fanart=af)
                thumb = meta.get('poster') or ai
            else:
                cached = cache.get(item_key)
                if isinstance(cached, dict):
                    thumb = cached.get('thumb') or ai
                    cast = cached.get('cast') or []
                    director = cached.get('director') or ''
                elif cached:
                    thumb = cached or ai
                    cast, director = [], ''
                else:
                    thumb = ai
                    cast, director = [], ''
                    missing_meta.append({
                        'tmdb_id': tmdb_id,
                        'imdb_id': imdb_id,
                        'title': title,
                        'year': year,
                        'media_type': t,
                    })

                li.setArt({'icon': 'DefaultVideo.png', 'thumb': thumb, 'poster': thumb, 'fanart': af})
                li.setInfo('video', {
                    'title': title,
                    'year': year,
                    'plot': "[B]{0}[/B]\n\n{1}".format(tagline, overview) if tagline else overview,
                    'mediatype': 'movie' if t == 'movie' else 'tvshow',
                    'genre': ' / '.join(genres),
                    'rating': rating,
                    'mpaa': certification,
                    'duration': runtime * 60 if runtime else 0,
                    'director': director,
                })
                if cast:
                    li.setCast(cast)

            params_json = json.dumps({'q': title})
            fav_url = _u(action='add_favorite', title=title, fav_url=title, icon=thumb, platform='Trakt', fav_action='lfr', params=params_json)
            li.addContextMenuItems([("Añadir a Mis Favoritos", "RunPlugin({0})".format(fav_url))])

            li.setProperty('IsPlayable', 'false')
            play_url = _u(action='search_alt_prompt', q=title, ot=thumb,
                          mode=('movie' if t == 'movie' else 'show'), tmdb_id=(tmdb_id or ''))
            xbmcplugin.addDirectoryItem(handle=_handle(), url=play_url, listitem=li, isFolder=False)

        if missing_meta:
            _trigger_bg_enrich_trakt(missing_meta)

        xbmcplugin.endOfDirectory(_handle())
    except (requests.RequestException, ValueError, RuntimeError, OSError) as e:
        xbmcgui.Dialog().ok("Error Trakt", "Ocurrió un error al ver la lista:\n{0}".format(e))

def cache_covers(list_id):
    if not xbmcgui.Dialog().yesno(
        "EspaTV",
        "[B]AVISO DE CARGA:[/B]\n\n"
        "Al guardar las carátulas, el addon mostrará las fotos siempre que entres.\n\n"
        "Esto hará que la lista [COLOR yellow]tarde más en cargar[/COLOR] cada vez.\n\n"
        "¿Quieres continuar con la descarga?",
    ):
        return

    key = core_settings.get_trakt_api_key()
    headers = _trakt_headers(key)
    url = "{0}/lists/{1}/items?extended=full".format(_TRAKT_API_BASE, list_id)

    try:
        r = requests.get(url, headers=headers, timeout=15)
        items = r.json()
    except (requests.RequestException, ValueError):
        xbmcgui.Dialog().notification("Error", "No se pudo conectar con Trakt", xbmcgui.NOTIFICATION_ERROR)
        return

    if not isinstance(items, list):
        msg = items.get('message', 'Error desconocido') if isinstance(items, dict) else "Respuesta no válida"
        xbmcgui.Dialog().ok("Error Trakt", "No se pudo obtener la lista para cachear:\n{0}".format(msg))
        return

    total = len(items)
    if total == 0:
        xbmcgui.Dialog().notification("Trakt", "La lista está vacía", xbmcgui.NOTIFICATION_INFO)
        return

    cache = {}
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaTV", "Descargando carátulas...")
    try:
        for i, item in enumerate(items):
            if pDialog.iscanceled():
                break
            if not isinstance(item, dict):
                continue
            t = item.get('type')
            data = item.get(t)
            if not data:
                continue
            title = data.get('title')
            year = data.get('year')
            tmdb_id = data.get('ids', {}).get('tmdb')
            item_key = "{0}_{1}".format(title, year)
            percent = int((float(i) / total) * 100)
            pDialog.update(percent, "Procesando ({0}/{1}): {2}".format(i, total, title))
            thumb, cast, director = _get_tmdb_data(tmdb_id, None, t)
            if thumb:
                cache[item_key] = {'thumb': thumb, 'cast': cast, 'director': director}
    finally:
        pDialog.close()

    if not cache:
        return

    try:
        with open(_get_thumb_cache_path(list_id), 'w', encoding='utf-8') as f:
            json.dump(cache, f)
    except OSError as e:
        xbmcgui.Dialog().ok("Error Cache", "No se pudo escribir el archivo:\n{0}".format(e))
        return

    xbmcgui.Dialog().notification("EspaTV", "Carátulas guardadas correctamente", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def clear_cache(list_id):
    path = _get_thumb_cache_path(list_id)
    if not os.path.exists(path):
        return
    try:
        os.remove(path)
    except OSError as e:
        xbmcgui.Dialog().notification("Error", str(e), xbmcgui.NOTIFICATION_ERROR)
        return
    xbmcgui.Dialog().notification("EspaTV", "Cache eliminada: Volvemos a carga rápida", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")

def delete_list(list_id):
    if xbmcgui.Dialog().yesno("Eliminar Lista", "¿Seguro que quieres borrar esta lista de tu colección?"):
        core_settings.remove_trakt_list(list_id)
        xbmc.executebuiltin("Container.Refresh")


# Descubrimiento de listas curadas de Trakt

def _discovery_cache_path():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(p, 'espatv_trakt_discovery_cache.json')

def _load_discovery_cache():
    try:
        path = _discovery_cache_path()
        if not os.path.exists(path):
            return {}
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}

def _save_discovery_cache(data):
    try:
        path = _discovery_cache_path()
        os.makedirs(os.path.dirname(path), exist_ok=True)
        tmp = path + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError:
        pass

_DISCOVERY_TTL = 6 * 3600

def _fetch_list_index(path, page=1):
    cache = _load_discovery_cache()
    cache_key = "{0}|{1}".format(path, page)
    entry = cache.get(cache_key, {})
    now = time.time()
    if entry and (now - entry.get('ts', 0)) < _DISCOVERY_TTL:
        return entry['lists'], entry.get('total_pages', 1)

    api_key = core_settings.get_trakt_api_key()
    headers = _trakt_headers(api_key)
    url = "{0}/{1}".format(_TRAKT_API_BASE, path)
    try:
        r = requests.get(url, params={'limit': 20, 'page': page}, headers=headers, timeout=12)
        if r.status_code != 200:
            stale = entry.get('lists')
            return (stale, entry.get('total_pages', 1)) if stale else ([], 1)
        raw = r.json()
        total_pages = int(r.headers.get('X-Pagination-Page-Count', 1))
    except (requests.RequestException, ValueError):
        stale = entry.get('lists')
        return (stale, entry.get('total_pages', 1)) if stale else ([], 1)

    lists = []
    for item in (raw if isinstance(raw, list) else []):
        lst = item.get('list') or item  # trending wraps in {"like_count": N, "list": {...}}
        lid  = (lst.get('ids') or {}).get('trakt')
        name = (lst.get('name') or '').strip()
        if not lid or not name:
            continue
        user = (lst.get('user') or {}).get('username') or ''
        lists.append({
            'id':         lid,
            'name':       name,
            'desc':       (lst.get('description') or '').strip(),
            'user':       user,
            'item_count': lst.get('item_count') or 0,
            'likes':      item.get('like_count') or lst.get('likes') or 0,
        })

    cache[cache_key] = {'ts': now, 'lists': lists, 'total_pages': total_pages}
    _save_discovery_cache(cache)
    return lists, total_pages


def _tm_media_icon(name, fallback='DefaultVideoPlaylists.png'):
    p = os.path.join(
        xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path')),
        'resources', 'media', name,
    )
    return p if os.path.exists(p) else fallback


def menu_discover_lists():
    h = _handle()
    entries = [
        ("Listas trending ahora", "trakt_browse_list_index", "lists/trending",
         "Las listas curadas más populares en este momento en Trakt.tv.",
         'top_lists_trending.png'),
        ("Listas más populares",  "trakt_browse_list_index", "lists/popular",
         "Las listas con más seguidores de toda la historia de Trakt.tv.",
         'top_lists_popular.png'),
        ("Buscar listas...",      "trakt_search_lists",      "",
         "Busca listas de Trakt por nombre o temática.",
         'adv_busqueda.png'),
    ]
    for label, action, path, plot, icon_file in entries:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _tm_media_icon(icon_file)})
        li.setInfo('video', {'plot': plot})
        kwargs = {'action': action}
        if path:
            kwargs['path'] = path
        xbmcplugin.addDirectoryItem(handle=h, url=_u(**kwargs), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def browse_list_index(path, page=1):
    h = _handle()
    page = int(page)
    lists, total_pages = _fetch_list_index(path, page)
    if not lists:
        xbmcgui.Dialog().notification("EspaTV", "No se encontraron listas", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(h)
        return
    for lst in lists:
        count = lst['item_count']
        likes = lst['likes']
        parts = []
        if lst['user']:
            parts.append("por {0}".format(lst['user']))
        if count:
            parts.append("{0} ítems".format(count))
        if likes:
            parts.append("{0} likes".format(likes))
        subtitle = "  ·  ".join(parts)
        label = "{0}  [COLOR gray]{1}[/COLOR]".format(lst['name'], subtitle) if subtitle else lst['name']
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _tm_media_icon('top_trakt_listas.png')})
        lines = [lst['desc']] if lst['desc'] else []
        if subtitle:
            lines.append(subtitle)
        li.setInfo('video', {'plot': '\n'.join(lines)})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='trakt_view_list', list_id=lst['id']),
            listitem=li,
            isFolder=True,
        )
    if page < total_pages:
        li = xbmcgui.ListItem(
            label="[COLOR limegreen]Página siguiente ({0}/{1})[/COLOR]".format(page + 1, total_pages))
        li.setArt({'icon': 'DefaultFolder.png'})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='trakt_browse_list_index', path=path, page=page + 1),
            listitem=li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


def search_trakt_lists():
    kb = xbmc.Keyboard('', 'Buscar listas en Trakt.tv')
    kb.doModal()
    if not kb.isConfirmed():
        xbmcplugin.endOfDirectory(_handle())
        return
    query = kb.getText().strip()
    if not query:
        xbmcplugin.endOfDirectory(_handle())
        return

    api_key = core_settings.get_trakt_api_key()
    headers = _trakt_headers(api_key)
    url = "{0}/search".format(_TRAKT_API_BASE)
    try:
        r = requests.get(url, params={'type': 'list', 'query': query, 'limit': 20},
                         headers=headers, timeout=12)
        raw = r.json() if r.status_code == 200 else []
    except (requests.RequestException, ValueError):
        raw = []

    h = _handle()
    lists = []
    for item in (raw if isinstance(raw, list) else []):
        lst = item.get('list') or {}
        lid  = (lst.get('ids') or {}).get('trakt')
        name = (lst.get('name') or '').strip()
        if not lid or not name:
            continue
        user = (lst.get('user') or {}).get('username') or ''
        lists.append({
            'id': lid, 'name': name,
            'desc': (lst.get('description') or '').strip(),
            'user': user, 'item_count': lst.get('item_count') or 0, 'likes': 0,
        })

    if not lists:
        xbmcgui.Dialog().notification("EspaTV", "Sin resultados para: {0}".format(query),
                                      xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(h)
        return

    for lst in lists:
        parts = ["por {0}".format(lst['user'])] if lst['user'] else []
        if lst['item_count']:
            parts.append("{0} ítems".format(lst['item_count']))
        subtitle = "  ·  ".join(parts)
        label = "{0}  [COLOR gray]{1}[/COLOR]".format(lst['name'], subtitle) if subtitle else lst['name']
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': _tm_media_icon('top_trakt_listas.png')})
        li.setInfo('video', {'plot': lst['desc'] or subtitle})
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action='trakt_view_list', list_id=lst['id']),
            listitem=li, isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)
