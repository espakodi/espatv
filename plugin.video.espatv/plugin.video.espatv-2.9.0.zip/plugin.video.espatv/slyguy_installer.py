# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Instalación de addons del repositorio SlyGuy."""
import xbmc
import xbmcaddon
import xbmcgui

from install_helpers import _auto_install_slyguy_repo

_SLYGUY_REPO_ID = "repository.slyguy"


def install(addon_id, addon_name):
    try:
        xbmcaddon.Addon(addon_id)
        xbmcgui.Dialog().notification("EspaTV", "Abriendo {0}...".format(addon_name), xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("RunAddon({0})".format(addon_id))
        return
    except RuntimeError:
        pass
    try:
        xbmcaddon.Addon(_SLYGUY_REPO_ID)
        if xbmcgui.Dialog().yesno("EspaTV", "{0} no está instalado pero el repositorio SlyGuy sí.\n\n¿Instalar {0} ahora?".format(addon_name)):
            xbmc.executebuiltin("InstallAddon({0})".format(addon_id))
            xbmcgui.Dialog().ok("EspaTV", "Se ha solicitado la instalación de {0}.\n\nSi Kodi te pide confirmación, acepta.\nDespués vuelve y pulsa de nuevo para abrirlo.".format(addon_name))
        return
    except RuntimeError:
        pass
    opts = ["Instalar repositorio automáticamente", "Ver instrucciones manuales"]
    sel = xbmcgui.Dialog().select("Se necesita el repo SlyGuy para {0}".format(addon_name), opts)
    if sel == 0:
        _auto_install_slyguy_repo(addon_id, addon_name)
    elif sel == 1:
        show_instructions(addon_name)


def show_instructions(addon_name):
    t = (
        "[B]Cómo instalar {0}[/B]\n\n"
        "1. Ve a [B]Ajustes → Sistema → Addons[/B]\n"
        "   Activa [B]Orígenes desconocidos[/B]\n\n"
        "2. Ve a [B]Ajustes → Administrador de archivos[/B]\n"
        "   Añade fuente: [B]https://k.slyguy.xyz[/B]\n"
        "   Nombre: [B]slyguy[/B]\n\n"
        "3. Ve a [B]Addons → Instalar desde ZIP[/B]\n"
        "   Selecciona [B]slyguy → repository.slyguy.zip[/B]\n\n"
        "4. Ve a [B]Addons → Instalar desde repositorio[/B]\n"
        "   SlyGuy → Video addons → [B]{0}[/B]\n\n"
        "Tras instalarlo, vuelve a TV en Directo y pulsa de nuevo."
    ).format(addon_name)
    xbmcgui.Dialog().textviewer("Instalar {0}".format(addon_name), t)
