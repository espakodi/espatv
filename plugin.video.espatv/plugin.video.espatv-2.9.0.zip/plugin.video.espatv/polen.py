# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Niveles de Polen y Alergias: Open-Meteo/CAMS (toda España) + Aerobiologia.cat/XAC (Cataluña/Baleares)."""
import os
import sys
import json
import time
import datetime
import xml.etree.ElementTree as ET
import urllib.parse
import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs

_LOG = "[EspaTV-POLEN]"
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")
_TIMEOUT = 12
_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
_CACHE_FILE = os.path.join(_PROFILE, "polen_cache.json")
_CACHE_TTL = 3600
_CACHE_VERSION = 1

_NIVELES_COLOR = {
    "Nulo":     "grey",
    "Bajo":     "lightgreen",
    "Medio":    "gold",
    "Alto":     "orange",
    "Muy Alto": "red",
}
_SEVERIDAD = {"Muy Alto": 4, "Alto": 3, "Medio": 2, "Bajo": 1, "Nulo": 0}

_CONSEJOS = {
    "Gramíneas":          "Evitar salidas al campo en primavera. Mantener ventanas cerradas, especialmente por la mañana.",
    "Olivo":              "Polinización intensa en mayo-junio, especialmente en el sur. Usar gafas de sol y mascarilla.",
    "Ciprés":             "Polinización en invierno (enero-marzo). Evitar parques y cementerios con cipreses.",
    "Cupressáceas":       "Polinización en invierno (enero-marzo). Evitar parques y cementerios con cipreses.",
    "Plátano de sombra":  "Polinización explosiva en marzo-abril. Evitar avenidas arboladas en días de viento.",
    "Plátano":            "Polinización explosiva en marzo-abril. Evitar avenidas arboladas en días de viento.",
    "Parietaria":         "Crece en muros y descampados. Evitar desbrozar maleza. Polinización muy prolongada.",
    "Urticáceas":         "Crece en muros y descampados. Evitar desbrozar maleza. Polinización muy prolongada.",
    "Quenopodiáceas":     "Presentes en zonas áridas y bordes de caminos. Polinización en verano y otoño.",
    "Chenopodiaceas":     "Presentes en zonas áridas y bordes de caminos. Polinización en verano y otoño.",
    "Quercus":            "Zonas de dehesa y bosque mediterráneo. Polinización primaveral (marzo-mayo).",
    "Roble/Encina":       "Zonas de dehesa y bosque mediterráneo. Polinización primaveral (marzo-mayo).",
    "Artemisia":          "Maleza muy alergénica. Fin de verano y otoño. Evitar descampados sin vegetación.",
    "Abedul":             "Polinización en primavera (marzo-mayo). Frecuente en el norte y noroeste de España.",
    "Aliso":              "Polinización invernal y primaveral. Zonas húmedas y riberas de ríos.",
    "Ambrosía":           "Maleza invasora muy alergénica. Polinización de julio a octubre.",
    "Fresno":             "Polinización en febrero-abril, antes de que aparezcan las hojas.",
    "Plantago":           "Llantén. Polinización en primavera-verano. Habitual en suelos pobres y caminos.",
    "Llantén":            "Polinización en primavera-verano. Habitual en suelos pobres y caminos.",
    "Alternaria":         "Hongo alérgeno. Picos en fin de verano. Evitar ambientes húmedos y vegetación en descomposición.",
    "Cladosporium":       "Hongo en materia vegetal en descomposición. Picos en verano. Evitar jardines tras lluvias.",
    "Pino":               "Polen muy visible pero poco alergénico. Polinización en primavera.",
    "Arizónica":          "Cupressácea muy alergénica. Polinización en invierno (enero-marzo).",
}

# Todas las provincias españolas con coordenadas de su capital
_PROVINCIAS = {
    # Andalucía
    "Almería":            (36.8381,  -2.4597),
    "Cádiz":              (36.5297,  -6.2929),
    "Córdoba":            (37.8882,  -4.7794),
    "Granada":            (37.1773,  -3.5986),
    "Huelva":             (37.2614,  -6.9447),
    "Jaén":               (37.7796,  -3.7849),
    "Málaga":             (36.7213,  -4.4214),
    "Sevilla":            (37.3891,  -5.9845),
    # Aragón
    "Huesca":             (42.1401,  -0.4089),
    "Teruel":             (40.3440,  -1.1065),
    "Zaragoza":           (41.6488,  -0.8891),
    # Asturias
    "Asturias":           (43.3614,  -5.8593),
    # Baleares
    "Illes Balears":      (39.5696,   2.6502),
    # Canarias
    "Las Palmas":         (28.1235, -15.4363),
    "S.C. Tenerife":      (28.4636, -16.2518),
    # Cantabria
    "Cantabria":          (43.1828,  -3.9878),
    # Castilla-La Mancha
    "Albacete":           (38.9943,  -1.8585),
    "Ciudad Real":        (38.9848,  -3.9274),
    "Cuenca":             (40.0704,  -2.1374),
    "Guadalajara":        (40.6296,  -3.1621),
    "Toledo":             (39.8628,  -4.0273),
    # Castilla y León
    "Ávila":              (40.6566,  -4.6814),
    "Burgos":             (42.3439,  -3.6969),
    "León":               (42.5987,  -5.5671),
    "Palencia":           (42.0097,  -4.5288),
    "Salamanca":          (40.9701,  -5.6635),
    "Segovia":            (40.9429,  -4.1088),
    "Soria":              (41.7636,  -2.4649),
    "Valladolid":         (41.6523,  -4.7245),
    "Zamora":             (41.5034,  -5.7447),
    # Cataluña
    "Barcelona":          (41.3851,   2.1734),
    "Girona":             (41.9794,   2.8214),
    "Lleida":             (41.6176,   0.6200),
    "Tarragona":          (41.1189,   1.2445),
    # Extremadura
    "Badajoz":            (38.8794,  -6.9707),
    "Cáceres":            (39.4752,  -6.3724),
    # Galicia
    "A Coruña":           (43.3623,  -8.4115),
    "Lugo":               (43.0097,  -7.5567),
    "Ourense":            (42.3359,  -7.8639),
    "Pontevedra":         (42.4328,  -8.6471),
    # La Rioja
    "La Rioja":           (42.2871,  -2.5396),
    # Madrid
    "Madrid":             (40.4168,  -3.7038),
    # Murcia
    "Murcia":             (37.9922,  -1.1307),
    # Navarra
    "Navarra":            (42.6954,  -1.6761),
    # País Vasco
    "Álava":              (42.8466,  -2.6726),
    "Guipúzcoa":          (43.3128,  -1.9751),
    "Vizcaya":            (43.2627,  -2.9253),
    # Comunidad Valenciana
    "Alicante":           (38.3452,  -0.4815),
    "Castellón":          (39.9865,  -0.0513),
    "Valencia":           (39.4699,  -0.3763),
    # Ciudades autónomas
    "Ceuta":              (35.8894,  -5.3198),
    "Melilla":            (35.2923,  -2.9381),
}

# Menú de primer nivel: lista de CCAAs con sus provincias
_CCAA = {
    "Andalucía":            ["Almería", "Cádiz", "Córdoba", "Granada", "Huelva", "Jaén", "Málaga", "Sevilla"],
    "Aragón":               ["Huesca", "Teruel", "Zaragoza"],
    "Asturias":             ["Asturias"],
    "Illes Balears":        ["Illes Balears"],
    "Canarias":             ["Las Palmas", "S.C. Tenerife"],
    "Cantabria":            ["Cantabria"],
    "Castilla-La Mancha":   ["Albacete", "Ciudad Real", "Cuenca", "Guadalajara", "Toledo"],
    "Castilla y León":      ["Ávila", "Burgos", "León", "Palencia", "Salamanca", "Segovia", "Soria", "Valladolid", "Zamora"],
    "Cataluña":             ["Barcelona", "Girona", "Lleida", "Tarragona"],
    "Extremadura":          ["Badajoz", "Cáceres"],
    "Galicia":              ["A Coruña", "Lugo", "Ourense", "Pontevedra"],
    "La Rioja":             ["La Rioja"],
    "Madrid":               ["Madrid"],
    "Murcia":               ["Murcia"],
    "Navarra":              ["Navarra"],
    "País Vasco":           ["Álava", "Guipúzcoa", "Vizcaya"],
    "Comunidad Valenciana": ["Alicante", "Castellón", "Valencia"],
    "Ceuta y Melilla":      ["Ceuta", "Melilla"],
}

# Provincias con datos oficiales de estaciones medidas (aerobiologia.cat)
# Licencia: CC BY-NC-SA 4.0 — https://aerobiologia.cat/pia/es/terms
_AEROBIO_STATIONS = {
    "Barcelona":     "barcelona",
    "Girona":        "girona",
    "Lleida":        "lleida",
    "Tarragona":     "tarragona",
    "Illes Balears": "palma",
}

_AEROBIO_NIVEL = {"0": "Nulo", "1": "Bajo", "2": "Medio", "3": "Alto", "4": "Muy Alto"}
_AEROBIO_TREND = {"A": "↑ Sube", "=": "→ Estable", "D": "↓ Baja", "!": "⚠ Excepcional"}


# Caché

def _load_cache():
    try:
        if not os.path.exists(_CACHE_FILE):
            return {"version": _CACHE_VERSION, "entries": {}}
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            data = json.load(f)
        if data.get("version") != _CACHE_VERSION:
            return {"version": _CACHE_VERSION, "entries": {}}
        if "entries" not in data:
            data["entries"] = {}
        return data
    except (OSError, json.JSONDecodeError) as e:
        xbmc.log(f"{_LOG} Error leyendo caché: {e}", xbmc.LOGWARNING)
        return {"version": _CACHE_VERSION, "entries": {}}


def _save_cache(obj):
    try:
        os.makedirs(_PROFILE, exist_ok=True)
        with open(_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False)
    except OSError as e:
        xbmc.log(f"{_LOG} Error guardando caché: {e}", xbmc.LOGWARNING)


def _cache_get(key):
    cache = _load_cache()
    entry = cache["entries"].get(key)
    if not entry:
        return None
    if time.time() - float(entry.get("ts", 0)) >= _CACHE_TTL:
        return None
    return entry.get("data")


def _cache_set(key, data):
    cache = _load_cache()
    cache["entries"][key] = {"ts": time.time(), "data": data}
    _save_cache(cache)


# Helpers de la UI

def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


# Peticiones HTTP

def _http_get_json(url):
    headers = {"User-Agent": "EspaTV/1.0 (Kodi addon; polen)"}
    resp = requests.get(url, headers=headers, timeout=_TIMEOUT)
    resp.raise_for_status()
    return resp.json()


def _http_get_text(url):
    headers = {"User-Agent": "EspaTV/1.0 (Kodi addon; polen)"}
    resp = requests.get(url, headers=headers, timeout=_TIMEOUT)
    resp.raise_for_status()
    return resp.text


# Open-Meteo / Copernicus CAMS — cobertura nacional
# Umbrales según escala REA (Red Española de Aerobiología), en grains/m³

def _nivel_grass(v):
    if v < 1:    return "Nulo"
    if v < 26:   return "Bajo"
    if v < 51:   return "Medio"
    if v < 101:  return "Alto"
    return "Muy Alto"


def _nivel_olive(v):
    if v < 1:    return "Nulo"
    if v < 31:   return "Bajo"
    if v < 101:  return "Medio"
    if v < 301:  return "Alto"
    return "Muy Alto"


def _nivel_birch(v):
    if v < 1:    return "Nulo"
    if v < 16:   return "Bajo"
    if v < 51:   return "Medio"
    if v < 101:  return "Alto"
    return "Muy Alto"


def _nivel_mugwort(v):
    if v < 1:    return "Nulo"
    if v < 11:   return "Bajo"
    if v < 31:   return "Medio"
    if v < 101:  return "Alto"
    return "Muy Alto"


_OPENMETEO_VARS = [
    ("grass_pollen",   "Gramíneas", _nivel_grass),
    ("olive_pollen",   "Olivo",     _nivel_olive),
    ("birch_pollen",   "Abedul",    _nivel_birch),
    ("alder_pollen",   "Aliso",     _nivel_birch),   # misma escala que abedul
    ("mugwort_pollen", "Artemisia", _nivel_mugwort),
    ("ragweed_pollen", "Ambrosía",  _nivel_mugwort),  # misma escala que artemisia
]


def _fetch_openmeteo(lat, lon):
    cache_key = f"openmeteo:{lat}:{lon}"
    cached = _cache_get(cache_key)
    if cached is not None:
        return cached

    vars_str = ",".join(k for k, _, _ in _OPENMETEO_VARS)
    url = (
        "https://air-quality-api.open-meteo.com/v1/air-quality"
        f"?latitude={lat}&longitude={lon}"
        f"&hourly={vars_str}&timezone=Europe%2FMadrid&forecast_days=1"
    )
    try:
        data = _http_get_json(url)
    except Exception as e:
        xbmc.log(f"{_LOG} Open-Meteo error: {e}", xbmc.LOGERROR)
        return None

    hourly = data.get("hourly") or {}
    times = hourly.get("time") or []
    if not times:
        return None

    # Localizar el índice de la hora actual (fix bug "valor_ahora")
    now_iso = datetime.datetime.now().strftime("%Y-%m-%dT%H:00")
    try:
        idx_now = times.index(now_iso)
    except ValueError:
        idx_now = 0

    fetched_at = time.time()
    data_date = times[0][:10] if times else ""

    result = []
    for key, nombre, nivel_fn in _OPENMETEO_VARS:
        values = hourly.get(key) or []
        nums = [float(v) for v in values if v is not None]
        if not nums:
            continue
        valor_max = max(nums)
        valor_ahora_raw = values[idx_now] if idx_now < len(values) else None
        valor_ahora = float(valor_ahora_raw) if valor_ahora_raw is not None else 0.0
        nivel = nivel_fn(valor_max)
        result.append({
            "tipo":          nombre,
            "nivel":         nivel,
            "detalle":       f"máx hoy {valor_max:.1f} grains/m³  (ahora {valor_ahora:.1f})",
            "color":         _NIVELES_COLOR[nivel],
            "recomendacion": _CONSEJOS.get(nombre, "Consulta a tu médico si presentas síntomas."),
            "fuente":        "Open-Meteo / Copernicus CAMS",
            "_fetched_at":   fetched_at,
            "_data_date":    data_date,
        })

    result.sort(key=lambda x: _SEVERIDAD[x["nivel"]], reverse=True)
    if result:
        _cache_set(cache_key, result)
    return result or None


# Aerobiologia.cat / XAC — Cataluña y Baleares
# Fuente: Xarxa Aerobiològica de Catalunya (UAB) — CC BY-NC-SA 4.0

def _fetch_aerobio(locality):
    cache_key = f"aerobio:{locality}"
    cached = _cache_get(cache_key)
    if cached is not None:
        return cached

    url = f"https://aerobiologia.cat/api/v0/forecast/{locality}/es/xml"
    try:
        raw = _http_get_text(url)
        root = ET.fromstring(raw)
    except Exception as e:
        xbmc.log(f"{_LOG} Aerobiologia.cat error ({locality}): {e}", xbmc.LOGERROR)
        return None

    nombres = {}
    taxons_node = root.find("taxons")
    if taxons_node is not None:
        for section in taxons_node:          # <pollens>, <spores>
            for child in section:
                nombres[child.tag] = child.get("es", child.tag)

    report = root.find("report")
    if report is None:
        return None

    # Extraer rango de fechas del XML (defensivo)
    def _text_or(tag, default=""):
        node = report.find(tag)
        return (node.text or default).strip() if node is not None else default

    data_date_start = _text_or("startDate", default="")
    data_date_end   = _text_or("endDate",   default="")
    fetched_at = time.time()

    def _parse_values(tag, default=""):
        node = report.find(tag)
        if node is None:
            return {}
        return {c.tag: (c.text or default) for sec in node for c in sec}

    niveles_raw    = _parse_values("current",  default="0")
    tendencias_raw = _parse_values("forecast", default="=")

    result = []
    for code, nombre in nombres.items():
        nivel = _AEROBIO_NIVEL.get(niveles_raw.get(code, "0").strip(), "Nulo")
        trend = _AEROBIO_TREND.get(tendencias_raw.get(code, "=").strip(), "→ Estable")
        result.append({
            "tipo":          nombre,
            "nivel":         nivel,
            "detalle":       trend,
            "color":         _NIVELES_COLOR[nivel],
            "recomendacion": _CONSEJOS.get(nombre, "Consulta a tu médico si presentas síntomas."),
            "fuente":        "Aerobiologia.cat / XAC — UAB",
            "_fetched_at":   fetched_at,
            "_data_date":    data_date_start,
            "_data_date_end": data_date_end,
        })

    result.sort(key=lambda x: _SEVERIDAD[x["nivel"]], reverse=True)
    if result:
        _cache_set(cache_key, result)
    return result or None


# Selección de fuentes

def _get_pollen_data(provincia):
    station = _AEROBIO_STATIONS.get(provincia)
    if station:
        data = _fetch_aerobio(station)
        if data:
            return data
    coords = _PROVINCIAS.get(provincia)
    if coords:
        return _fetch_openmeteo(*coords)
    return None


def _peor_nivel_cached(provincia):
    """Devuelve (nivel, color) del polen más alto SOLO si está en caché. Si no, (None, None)."""
    station = _AEROBIO_STATIONS.get(provincia)
    if station:
        cached = _cache_get(f"aerobio:{station}")
        if cached:
            top = cached[0]
            return top["nivel"], top["color"]
    coords = _PROVINCIAS.get(provincia)
    if coords:
        cached = _cache_get(f"openmeteo:{coords[0]}:{coords[1]}")
        if cached:
            top = cached[0]
            return top["nivel"], top["color"]
    return None, None


# Renderizado de la UI

def polen_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_polen.png", "DefaultAddonHealth.png")

    for ccaa in sorted(_CCAA):
        provs = _CCAA[ccaa]
        n_oficial = sum(1 for p in provs if p in _AEROBIO_STATIONS)
        sufijo = f"  ({len(provs)} prov.)"
        if n_oficial:
            sufijo += f"  [COLOR gold]★ {n_oficial} oficial[/COLOR]"
        li = xbmcgui.ListItem(label=f"[B]{ccaa}[/B]{sufijo}")
        li.setArt({"icon": icon})
        li.setInfo("video", {"plot": f"Provincias de {ccaa}.\n★ = datos de estaciones medidas (aerobiologia.cat / XAC)."})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="polen_ccaa", ccaa=ccaa),
            listitem=li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


def polen_ccaa(ccaa):
    h = int(sys.argv[1])
    icon = _icon("cat_polen.png", "DefaultAddonHealth.png")

    for prov in sorted(_CCAA.get(ccaa, [])):
        oficial = prov in _AEROBIO_STATIONS
        nivel, color = _peor_nivel_cached(prov)
        badge = ""
        if nivel:
            badge = f"  [COLOR {color}]● {nivel}[/COLOR]"
        if oficial:
            badge += "  [COLOR gold]★[/COLOR]"
        li = xbmcgui.ListItem(label=f"[B]{prov}[/B]{badge}")
        li.setArt({"icon": icon})
        fuente = "Aerobiologia.cat / XAC — UAB" if oficial else "Open-Meteo / Copernicus CAMS"
        li.setInfo("video", {"plot": f"Niveles de polen en {prov}.\nFuente: {fuente}"})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="polen_provincia", provincia=prov),
            listitem=li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


def polen_provincia(provincia):
    h = int(sys.argv[1])
    icon = _icon("cat_polen.png", "DefaultAddonHealth.png")
    icon_info = _icon("info.png", "DefaultIconInfo.png")
    datos = _get_pollen_data(provincia)

    if not datos:
        li = xbmcgui.ListItem(label="[COLOR red]Sin datos disponibles[/COLOR]")
        li.setArt({"icon": "DefaultIconError.png"})
        li.setInfo("video", {"plot": "No se pudieron obtener datos de polen.\nComprueba tu conexión a internet."})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)
    else:
        # Header con metadatos de actualización
        meta = datos[0]
        fa = meta.get("_fetched_at")
        dd = meta.get("_data_date") or ""
        dd_end = meta.get("_data_date_end") or ""
        if fa:
            fa_str = datetime.datetime.fromtimestamp(float(fa)).strftime("%Y-%m-%d %H:%M")
        else:
            fa_str = "—"
        if dd and dd_end and dd != dd_end:
            rango = f"Datos del {dd} al {dd_end}"
        elif dd:
            rango = f"Datos para {dd}"
        else:
            rango = "Datos para hoy"
        header_label = f"[COLOR cyan][B]ℹ Actualizado: {fa_str}  ·  {rango}[/B][/COLOR]"
        header_li = xbmcgui.ListItem(label=header_label)
        header_li.setArt({"icon": icon_info})
        header_li.setInfo("video", {"plot":
            f"[B]Información de actualización[/B]\n\n"
            f"Última obtención: {fa_str}\n"
            f"{rango}\n"
            f"Fuente: {meta.get('fuente', '—')}\n\n"
            f"[COLOR grey]Los datos se cachean automáticamente durante 1 hora "
            f"para evitar consultas innecesarias a las APIs.[/COLOR]"
        })
        header_li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=header_li, isFolder=False)

        # Items de polen
        for item in datos:
            label = f"[B][COLOR {item['color']}]{item['nivel']}[/COLOR][/B] — {item['tipo']}"
            if item.get("detalle"):
                label += f"  ({item['detalle']})"
            li = xbmcgui.ListItem(label=label)
            li.setArt({"icon": icon})

            item_fa = item.get("_fetched_at")
            item_fa_str = (
                datetime.datetime.fromtimestamp(float(item_fa)).strftime("%Y-%m-%d %H:%M")
                if item_fa else "—"
            )
            item_dd = item.get("_data_date") or "hoy"

            plot = (
                f"[B]{item['tipo']}[/B]\n"
                f"Nivel: [COLOR {item['color']}]{item['nivel']}[/COLOR]"
                + (f"  —  {item['detalle']}" if item.get("detalle") else "")
                + f"\nProvincia: {provincia}\n\n"
                f"[B]Recomendación para alérgicos:[/B]\n{item['recomendacion']}\n\n"
                f"[COLOR grey]Datos para: {item_dd}\n"
                f"Obtenido: {item_fa_str}\n"
                f"Fuente: {item['fuente']}[/COLOR]"
            )
            li.setInfo("video", {"title": item["tipo"], "plot": plot})
            li.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)

    xbmcplugin.setContent(h, "files")
    xbmcplugin.endOfDirectory(h)
