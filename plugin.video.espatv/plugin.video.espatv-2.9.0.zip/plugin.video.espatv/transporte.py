# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Horarios de Transporte: submenú agregador de metros y cercanías."""
import os
import sys
import urllib.parse

import xbmcgui
import xbmcplugin

_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def menu():
    h = int(sys.argv[1])

    icon_metro = _icon("cat_transporte.png")

    li = xbmcgui.ListItem(label="[B]Metro de Madrid[/B]")
    li.setArt({"icon": icon_metro})
    li.setInfo("video", {"plot": "Próximos trenes por estación — Metro de Madrid.\nFuente: API CRTM (tiempo real)."})
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="metro_madrid_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Metrovalencia[/B]")
    li.setArt({"icon": icon_metro})
    li.setInfo("video", {"plot": "Próximos trenes entre dos estaciones de Metrovalencia.\nFuente: web oficial FGV."})
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="metro_valencia_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Metro de Barcelona[/B]")
    li.setArt({"icon": icon_metro})
    li.setInfo("video", {"plot": "Próximos trenes por estación — Metro de Barcelona (TMB).\nRequiere claves gratuitas de developer.tmb.cat."})
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="metro_barcelona_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B]Metro de Málaga[/B]")
    li.setArt({"icon": icon_metro})
    li.setInfo("video", {"plot": "Horario de parada — Metro de Málaga L1 y L2.\nMuestra el horario previsto, no tiempo real. Incidencias o retrasos no se reflejan.\nDatos actualizados semanalmente desde la web oficial."})
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="metro_malaga_menu"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[COLOR grey]Más ciudades próximamente. Se priorizan las de mayor población. Conseguir datos públicos de cada red no siempre es posible.[/COLOR]")
    li.setArt({"icon": "DefaultIconInfo.png", "thumb": "DefaultIconInfo.png"})
    li.setInfo("video", {"plot": "Más ciudades próximamente. Se priorizan las de mayor población. Conseguir datos públicos de cada red no siempre es posible."})
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)
