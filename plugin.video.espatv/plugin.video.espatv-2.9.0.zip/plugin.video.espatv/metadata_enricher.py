# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Enriquecimiento centralizado de metadatos de películas y series vía TMDB.

Caché SQLite unificada (espatv_metadata.db) compartida por todas las listas.
Clave canónica: ``tmdb:{type}:{id}`` > ``imdb:{id}`` > ``title:{type}:{title}:{year}``.
TTL: 30 días.
"""
import json
import os
import sqlite3
import threading
import time
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
import xbmc
import xbmcaddon
import xbmcvfs

import core_settings

_TMDB_BASE = "https://api.themoviedb.org/3"
_IMG_W342  = "https://image.tmdb.org/t/p/w342"
_IMG_W185  = "https://image.tmdb.org/t/p/w185"
_IMG_ORIG  = "https://image.tmdb.org/t/p/original"
_TTL_SEC   = 30 * 86400
_LOG_TAG   = "[EspaTV-ME]"

_KODI_MEDIATYPE = {'movie': 'movie', 'show': 'tvshow'}

_write_lock   = threading.Lock()
_thread_local = threading.local()
_session      = requests.Session()

# Caché en memoria de trailers (tmdb_id, media_type) -> youtube_key ('' = sin trailer).
# Separada del enrich SQLite: el trailer se resuelve bajo demanda contra /videos.
_trailer_cache = {}
_trailer_lock  = threading.Lock()




def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("{0} {1}".format(_LOG_TAG, msg), level)




def _api_key():
    key = core_settings.get_tmdb_api_key()
    if not key and not getattr(_thread_local, 'warned_no_key', False):
        _log("TMDB API key vacía; las llamadas devolverán datos vacíos", xbmc.LOGWARNING)
        _thread_local.warned_no_key = True
    return key




def _profile_dir():
    return xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))


def _db_path():
    return os.path.join(_profile_dir(), 'espatv_metadata.db')


def _connection():
    conn = getattr(_thread_local, 'conn', None)
    if conn is not None:
        return conn
    path = _db_path()
    parent = os.path.dirname(path)
    if parent and not os.path.exists(parent):
        os.makedirs(parent, exist_ok=True)
    conn = sqlite3.connect(path, timeout=10)
    conn.execute("PRAGMA journal_mode=WAL")
    conn.execute("PRAGMA synchronous=NORMAL")
    conn.execute(
        "CREATE TABLE IF NOT EXISTS meta ("
        " key TEXT PRIMARY KEY,"
        " data TEXT NOT NULL,"
        " fetched_at INTEGER NOT NULL"
        ")"
    )
    conn.commit()
    _thread_local.conn = conn
    return conn


def _reset_thread_state():
    """Cierra la conexión thread-local. Pensado para uso en tests."""
    conn = getattr(_thread_local, 'conn', None)
    if conn is not None:
        try:
            conn.close()
        except sqlite3.Error:
            pass
        del _thread_local.conn
    if hasattr(_thread_local, 'warned_no_key'):
        del _thread_local.warned_no_key




def _cache_get(key):
    if not key:
        return None
    try:
        row = _connection().execute(
            "SELECT data, fetched_at FROM meta WHERE key=?", (key,)
        ).fetchone()
    except sqlite3.Error as e:
        _log("cache_get: {0}".format(e), xbmc.LOGWARNING)
        return None
    if not row or (time.time() - row[1]) >= _TTL_SEC:
        return None
    try:
        return json.loads(row[0])
    except ValueError:
        return None


def _cache_set(key, meta):
    if not key:
        return
    try:
        payload = json.dumps(meta, ensure_ascii=False)
    except (TypeError, ValueError) as e:
        _log("cache_set encode: {0}".format(e), xbmc.LOGWARNING)
        return
    now = int(time.time())
    try:
        with _write_lock:
            conn = _connection()
            conn.execute(
                "INSERT OR REPLACE INTO meta(key, data, fetched_at) VALUES(?,?,?)",
                (key, payload, now),
            )
            conn.commit()
    except sqlite3.Error as e:
        _log("cache_set: {0}".format(e), xbmc.LOGWARNING)


def _delete_keys(keys):
    rows = [(k,) for k in keys if k]
    if not rows:
        return
    try:
        with _write_lock:
            conn = _connection()
            conn.executemany("DELETE FROM meta WHERE key=?", rows)
            conn.commit()
    except sqlite3.Error as e:
        _log("delete_keys: {0}".format(e), xbmc.LOGWARNING)


def delete_by_imdb_ids(imdb_ids):
    """Elimina del caché las entradas con esos IMDB IDs."""
    _delete_keys(["imdb:{0}".format(i) for i in imdb_ids if i])


def delete_items(items):
    """Elimina del caché los descriptores ``{tmdb_id, imdb_id, title, year, media_type}``."""
    keys = [
        _canon_key(i.get('tmdb_id'), i.get('imdb_id'), i.get('title'),
                   i.get('year'), i.get('media_type', 'movie'))
        for i in items
    ]
    _delete_keys(keys)


def clear_all(vacuum=True):
    """Vacía toda la caché de metadatos.

    Con vacuum=True compacta el archivo para devolver el espacio al disco. Hace
    falta porque DELETE deja páginas libres que SQLite reutiliza pero no libera,
    y en modo WAL el .db no encoge hasta hacer checkpoint TRUNCATE tras el VACUUM.
    """
    try:
        with _write_lock:
            conn = _connection()
            conn.execute("DELETE FROM meta")
            conn.commit()
            if vacuum:
                # VACUUM no puede ejecutarse dentro de una transacción.
                prev_iso = conn.isolation_level
                conn.isolation_level = None
                try:
                    conn.execute("VACUUM")
                    conn.execute("PRAGMA wal_checkpoint(TRUNCATE)")
                finally:
                    conn.isolation_level = prev_iso
    except sqlite3.Error as e:
        _log("clear_all: {0}".format(e), xbmc.LOGWARNING)




def _to_int(value):
    if value is None or value == '' or isinstance(value, bool):
        return None
    try:
        return int(value)
    except (TypeError, ValueError):
        return None


def _canon_key(tmdb_id, imdb_id, title, year, media_type):
    tmdb_int = _to_int(tmdb_id)
    if tmdb_int:
        return "tmdb:{0}:{1}".format(media_type, tmdb_int)
    if imdb_id:
        return "imdb:{0}".format(imdb_id)
    if title:
        normalized = title.lower().strip()
        if normalized:
            return "title:{0}:{1}:{2}".format(media_type, normalized, year or '')
    return None




def _build_cast(credits):
    return [
        {
            'name':      a.get('name', ''),
            'role':      a.get('character', ''),
            'thumbnail': "{0}{1}".format(_IMG_W185, a['profile_path']) if a.get('profile_path') else '',
        }
        for a in (credits.get('cast') or [])[:10]
    ]


def _build_director(media_type, payload):
    crew = (payload.get('credits') or {}).get('crew') or []
    director_from_crew = next(
        (p.get('name', '') for p in crew if p.get('job') == 'Director'),
        '',
    )
    if media_type == 'show':
        creators = ', '.join(
            c.get('name', '') for c in (payload.get('created_by') or []) if c.get('name')
        )
        return creators or director_from_crew
    return director_from_crew


def _parse(d, media_type):
    poster_path   = d.get('poster_path')
    backdrop_path = d.get('backdrop_path')
    credits       = d.get('credits') or {}
    genres        = [g.get('name', '') for g in (d.get('genres') or [])]
    ext_ids       = d.get('external_ids') or {}
    imdb_id       = d.get('imdb_id') or ext_ids.get('imdb_id', '')

    raw_date = d.get('release_date') or d.get('first_air_date') or ''
    year = int(raw_date[:4]) if raw_date[:4].isdigit() else 0

    runtime = d.get('runtime') or 0
    if not runtime and media_type == 'show':
        rt_list = d.get('episode_run_time') or []
        runtime = rt_list[0] if rt_list else 0

    try:
        rating = float(d.get('vote_average') or 0)
    except (TypeError, ValueError):
        rating = 0.0

    return {
        'ids':            {'tmdb': d.get('id'), 'imdb': imdb_id},
        'media_type':     media_type,
        'title':          d.get('title') or d.get('name') or '',
        'original_title': d.get('original_title') or d.get('original_name') or '',
        'year':           year,
        'overview':       d.get('overview') or '',
        'tagline':        d.get('tagline') or '',
        'genres':         genres,
        'rating':         rating,
        'votes':          int(d.get('vote_count') or 0),
        'runtime':        runtime,
        'certification':  _pick_certification(d, media_type),
        'director':       _build_director(media_type, d),
        'cast':           _build_cast(credits),
        'poster':         "{0}{1}".format(_IMG_W342, poster_path) if poster_path else '',
        'fanart':         "{0}{1}".format(_IMG_ORIG, backdrop_path) if backdrop_path else '',
    }




def _tmdb_get(path, params):
    api_key = _api_key()
    if not api_key:
        return None
    full = dict(params, api_key=api_key)
    url = "{0}/{1}".format(_TMDB_BASE, path)
    try:
        r = _session.get(url, params=full, timeout=8)
        if r.status_code in (401, 403):
            core_settings.mark_tmdb_key_dead(api_key)
            next_key = core_settings.get_tmdb_api_key()
            if next_key and next_key != api_key:
                full['api_key'] = next_key
                r = _session.get(url, params=full, timeout=8)
        if r.status_code != 200:
            return None
        return r.json()
    except (requests.RequestException, ValueError) as e:
        _log("request error ({0}): {1}".format(path, e), xbmc.LOGWARNING)
        return None


def _norm_tmdb_item(r, is_tv):
    """Normaliza un result de TMDB (movie/tv) al formato del buscador, o None si no sirve."""
    title = (r.get('name') if is_tv else r.get('title')) or ''
    if not title:
        return None
    date = (r.get('first_air_date') if is_tv else r.get('release_date')) or ''
    pp = r.get('poster_path') or ''
    return {
        'tmdb_id':    str(r.get('id') or ''),
        'title':      title,
        'year':       date[:4] if len(date) >= 4 else '',
        'poster':     f"{_IMG_W342}{pp}" if pp else '',
        'overview':   r.get('overview') or '',
        'media_type': 'show' if is_tv else 'movie',
        'popularity': r.get('popularity') or 0,
    }


def search_multi(query, limit=40):
    """Busca películas y series en TMDB (/search/multi).

    Devuelve una lista normalizada de dicts ordenada por popularidad, o []
    si no hay query, no hay red o falla la clave. Cada dict:
    {tmdb_id, title, year, poster, overview, media_type ('movie'|'show'), popularity}.
    """
    q = (query or '').strip()
    if not q:
        return []
    data = _tmdb_get('search/multi', {'query': q, 'language': 'es-ES', 'include_adult': 'false'})
    out = []
    for r in (data or {}).get('results', []):
        if r.get('media_type') not in ('movie', 'tv'):
            continue
        item = _norm_tmdb_item(r, r.get('media_type') == 'tv')
        if item:
            out.append(item)
    out.sort(key=lambda x: x['popularity'], reverse=True)
    return out[:limit]


def search_person(name, limit=8):
    """Busca personas (directores/actores) en TMDB. Devuelve lista de
    {id, name, department, popularity, known_for} ordenada por popularidad, o []."""
    q = (name or '').strip()
    if not q:
        return []
    data = _tmdb_get('search/person', {'query': q, 'language': 'es-ES', 'include_adult': 'false'})
    out = []
    for p in (data or {}).get('results', []):
        pid = p.get('id')
        if not pid:
            continue
        known = [k.get('title') or k.get('name') for k in (p.get('known_for') or [])]
        out.append({
            'id':         str(pid),
            'name':       p.get('name') or '',
            'department': p.get('known_for_department') or '',
            'popularity': p.get('popularity') or 0,
            'known_for':  [k for k in known if k][:3],
        })
    out.sort(key=lambda x: x['popularity'], reverse=True)
    return out[:limit]


def discover(media_type, params, limit=40):
    """Descubre películas o series vía /discover. `media_type` es 'movie' o 'show'.
    `params` son filtros TMDB (with_crew, with_genres, primary_release_year, ...).
    Devuelve lista normalizada o []."""
    is_tv = media_type == 'show'
    endpoint = 'discover/tv' if is_tv else 'discover/movie'
    base = {'language': 'es-ES', 'region': 'ES', 'include_adult': 'false',
            'sort_by': 'popularity.desc', 'page': 1}
    data = _tmdb_get(endpoint, dict(base, **params))
    out = []
    for r in (data or {}).get('results', []):
        item = _norm_tmdb_item(r, is_tv)
        if item:
            out.append(item)
    return out[:limit]


def _pick_certification(d, media_type):
    """Extrae la certificación por edades: primero ES, luego US."""
    try:
        if media_type == 'show':
            results = (d.get('content_ratings') or {}).get('results') or []
            for pref in ('ES', 'US'):
                for entry in results:
                    if entry.get('iso_3166_1') == pref:
                        cert = entry.get('rating', '')
                        if cert:
                            return cert
        else:
            results = (d.get('release_dates') or {}).get('results') or []
            for pref in ('ES', 'US'):
                for entry in results:
                    if entry.get('iso_3166_1') == pref:
                        for rd in entry.get('release_dates') or []:
                            cert = rd.get('certification', '')
                            if cert:
                                return cert
    except Exception as e:
        _log("_pick_certification: {0}".format(e), xbmc.LOGWARNING)
    return ''


def _fetch_by_tmdb_id(tmdb_id, media_type):
    endpoint = 'tv' if media_type == 'show' else 'movie'
    base = {'append_to_response': 'credits,external_ids,release_dates,content_ratings', 'language': 'es-ES'}
    payload = _tmdb_get("{0}/{1}".format(endpoint, tmdb_id), base)
    if not payload:
        return None
    if not payload.get('overview'):
        en = _tmdb_get("{0}/{1}".format(endpoint, tmdb_id), {'language': 'en-US'})
        if en:
            if not payload.get('overview') and en.get('overview'):
                payload['overview'] = en['overview']
            if not payload.get('poster_path') and en.get('poster_path'):
                payload['poster_path'] = en['poster_path']
    return _parse(payload, media_type)


def _find_by_imdb(imdb_id, media_type):
    payload = _tmdb_get("find/{0}".format(imdb_id), {'external_source': 'imdb_id'})
    if not payload:
        return None
    movies = payload.get('movie_results') or []
    shows  = payload.get('tv_results') or []
    if media_type == 'show' and shows:
        return _fetch_by_tmdb_id(shows[0].get('id'), 'show')
    if media_type == 'movie' and movies:
        return _fetch_by_tmdb_id(movies[0].get('id'), 'movie')
    if movies:
        return _fetch_by_tmdb_id(movies[0].get('id'), 'movie')
    if shows:
        return _fetch_by_tmdb_id(shows[0].get('id'), 'show')
    return None


def _pick_search_match(results, year, media_type):
    if not results:
        return None
    target = _to_int(year)
    if not target:
        return results[0]
    date_field = 'first_air_date' if media_type == 'show' else 'release_date'
    same_year = [
        r for r in results
        if (r.get(date_field) or '')[:4].isdigit()
        and int((r.get(date_field) or '')[:4]) == target
    ]
    if same_year:
        return max(same_year, key=lambda r: r.get('vote_count') or 0)
    return results[0]


def _search_by_title(title, year, media_type):
    endpoint = 'tv' if media_type == 'show' else 'movie'
    year_key = 'first_air_date_year' if media_type == 'show' else 'year'
    params   = {'query': title, 'language': 'es-ES'}
    if year:
        params[year_key] = year
    payload = _tmdb_get("search/{0}".format(endpoint), params)
    if not payload:
        return None
    pick = _pick_search_match(payload.get('results') or [], year, media_type)
    if not pick:
        return None
    return _fetch_by_tmdb_id(pick.get('id'), media_type)




def enrich(tmdb_id=None, imdb_id=None, title=None, year=None,
           media_type='movie', use_cache_only=False):
    """Devuelve un dict con metadatos completos. ``{}`` si no hay datos."""
    tmdb_int = _to_int(tmdb_id)
    key = _canon_key(tmdb_int, imdb_id, title, year, media_type)
    if not key:
        return {}

    cached = _cache_get(key)
    if cached is not None:
        return cached
    if use_cache_only:
        return {}

    if tmdb_int:
        meta = _fetch_by_tmdb_id(tmdb_int, media_type)
    elif imdb_id:
        meta = _find_by_imdb(imdb_id, media_type)
    elif title:
        meta = _search_by_title(title, year, media_type)
    else:
        meta = None

    if not meta:
        return {}

    _cache_set(key, meta)
    fetched_tmdb = (meta.get('ids') or {}).get('tmdb')
    fetched_imdb = (meta.get('ids') or {}).get('imdb')
    if fetched_tmdb:
        alt = "tmdb:{0}:{1}".format(media_type, fetched_tmdb)
        if alt != key:
            _cache_set(alt, meta)
    if fetched_imdb:
        alt = "imdb:{0}".format(fetched_imdb)
        if alt != key:
            _cache_set(alt, meta)
    return meta


def _find_trailer_key(endpoint, tmdb_int, language):
    payload = _tmdb_get(f'{endpoint}/{tmdb_int}/videos', {'language': language})
    for v in (payload or {}).get('results', []):
        if v.get('site') == 'YouTube' and v.get('type') == 'Trailer' and v.get('key'):
            return v['key']
    return ''


def get_trailer_key(tmdb_id, media_type='movie', lang='en-US'):
    """Devuelve la key de YouTube del primer trailer del título, o '' si no hay.

    Consulta /videos en el idioma pedido; si no hay tráiler ahí (frecuente fuera de
    en-US, donde TMDB tiene el oficial), reintenta en en-US. Cachea por sesión."""
    tmdb_int = _to_int(tmdb_id)
    if not tmdb_int:
        return ''
    ck = (media_type, tmdb_int, lang)
    with _trailer_lock:
        if ck in _trailer_cache:
            return _trailer_cache[ck]
    endpoint = 'tv' if media_type == 'show' else 'movie'
    key = _find_trailer_key(endpoint, tmdb_int, lang)
    if not key and lang != 'en-US':
        key = _find_trailer_key(endpoint, tmdb_int, 'en-US')
    with _trailer_lock:
        _trailer_cache[ck] = key
    return key


def batch_enrich(items, use_cache_only=False, max_workers=4):
    """Enriquece una lista de descriptores en paralelo, preservando el orden."""
    results = [{} for _ in items]

    def _one(idx, item):
        return idx, enrich(
            tmdb_id=item.get('tmdb_id'),
            imdb_id=item.get('imdb_id'),
            title=item.get('title'),
            year=item.get('year'),
            media_type=item.get('media_type', 'movie'),
            use_cache_only=use_cache_only,
        )

    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = [ex.submit(_one, i, item) for i, item in enumerate(items)]
        for future in as_completed(futures):
            try:
                idx, meta = future.result()
                results[idx] = meta or {}
            except Exception as e:  # pragma: no cover
                _log("batch_enrich item: {0}".format(e), xbmc.LOGWARNING)
    return results


def batch_fetch_with_progress(items, progress_dialog, max_workers=6):
    """Descarga metadatos en paralelo con barra de progreso. Devuelve nº de éxitos."""
    total = len(items)
    if total == 0:
        return 0

    def _fetch(item):
        return enrich(
            tmdb_id=item.get('tmdb_id'),
            imdb_id=item.get('imdb_id'),
            title=item.get('title'),
            year=item.get('year'),
            media_type=item.get('media_type', 'movie'),
        )

    completed = 0
    success   = 0
    with ThreadPoolExecutor(max_workers=max_workers) as ex:
        futures = {ex.submit(_fetch, item): item for item in items}
        for future in as_completed(futures):
            if progress_dialog.iscanceled():
                break
            item = futures[future]
            completed += 1
            label = item.get('title') or '...'
            progress_dialog.update(
                int(completed * 100 / total),
                "({0}/{1}) {2}".format(completed, total, label),
            )
            try:
                if future.result():
                    success += 1
            except Exception as e:  # pragma: no cover
                _log("batch_fetch item: {0}".format(e), xbmc.LOGWARNING)
    return success




def build_plot_header(rating, genres, runtime=None, director=None):
    """Devuelve una cabecera visual para el plot: '★ 8.2 · 120 min · Acción / Drama\nDir: X\n\n'."""
    parts = []

    try:
        rating_f = float(rating) if rating else 0.0
    except (TypeError, ValueError):
        rating_f = 0.0

    if rating_f > 0:
        color = 'gold' if rating_f >= 7.0 else ('white' if rating_f >= 5.0 else 'tomato')
        parts.append("[COLOR {0}]★ {1:.1f}[/COLOR]".format(color, rating_f))

    try:
        rt = int(runtime) if runtime else 0
    except (TypeError, ValueError):
        rt = 0
    if rt > 0:
        parts.append("{0} min".format(rt))

    if genres:
        if isinstance(genres, list):
            genre_str = ' / '.join(g for g in genres[:3] if g)
        else:
            genre_str = str(genres).strip()
        if genre_str:
            parts.append(genre_str)

    header = ''
    if parts:
        header = '  ·  '.join(parts) + '\n'
    if director:
        header += '[I]Dir: {0}[/I]\n'.format(director)
    if header:
        header += '\n'
    return header


def _build_plot(meta):
    header = build_plot_header(
        meta.get('rating'), meta.get('genres'),
        runtime=meta.get('runtime'), director=meta.get('director'),
    )
    tagline  = meta.get('tagline') or ''
    overview = meta.get('overview') or ''
    body = "[B]{0}[/B]\n\n{1}".format(tagline, overview) if tagline else overview
    return header + body


def _kodi_mediatype(media_type):
    return _KODI_MEDIATYPE.get(media_type, 'movie')


def fetch_watch_providers(tmdb_id, media_type='movie'):
    """Devuelve proveedores en España (flatrate/free/buy/rent) desde TMDB. {} si no hay."""
    tid = _to_int(tmdb_id)
    if not tid:
        return {}
    cache_key = 'providers:{0}:{1}'.format(media_type, tid)
    cached = _cache_get(cache_key)
    if cached is not None:
        return cached
    if not _api_key():
        return {}
    endpoint = 'tv' if media_type == 'show' else 'movie'
    data = _tmdb_get('{0}/{1}/watch/providers'.format(endpoint, tid), {})
    if not data:
        return {}
    es = data.get('results', {}).get('ES', {})
    result = {
        'flatrate': [p['provider_name'] for p in es.get('flatrate', [])],
        'free':     [p['provider_name'] for p in es.get('free', [])],
        'buy':      [p['provider_name'] for p in es.get('buy', [])],
        'rent':     [p['provider_name'] for p in es.get('rent', [])],
        'link':     es.get('link', ''),
    }
    _cache_set(cache_key, result)
    return result


def apply_to_listitem(li, meta, addon_fanart=''):
    """Aplica los metadatos completos a un ``xbmcgui.ListItem``."""
    if not meta:
        return
    poster = meta.get('poster') or ''
    fanart = meta.get('fanart') or addon_fanart
    li.setArt({
        'icon':   'DefaultVideo.png',
        'thumb':  poster or fanart,
        'poster': poster,
        'fanart': fanart,
    })
    info = {
        'title':     meta.get('title') or '',
        'year':      meta.get('year') or 0,
        'plot':      _build_plot(meta),
        'mediatype': _kodi_mediatype(meta.get('media_type')),
        'genre':     ' / '.join(meta.get('genres') or []),
        'rating':    meta.get('rating') or 0,
        'votes':     str(meta.get('votes') or 0),
        'duration':  (meta.get('runtime') or 0) * 60,
    }
    original = meta.get('original_title') or ''
    if original:
        info['originaltitle'] = original
    director = meta.get('director') or ''
    if director:
        info['director'] = director
    certification = meta.get('certification') or ''
    if certification:
        info['mpaa'] = certification
    li.setInfo('video', info)
    cast = meta.get('cast') or []
    if cast:
        li.setCast(cast)
