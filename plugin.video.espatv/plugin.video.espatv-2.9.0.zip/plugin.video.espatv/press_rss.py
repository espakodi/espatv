# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Titulares RSS de prensa española."""
import json
import os
import re
import sys
import urllib.parse
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

try:
    import requests
except ImportError:
    requests = None

_PRENSA_FEEDS = [
    {"name": "El País",         "url": "https://feeds.elpais.com/mrss-s/pages/ep/site/elpais.com/portada"},
    {"name": "El Mundo",        "url": "https://e00-elmundo.uecdn.es/elmundo/rss/portada.xml"},
    {"name": "ABC",             "url": "https://www.abc.es/rss/2.0/portada/"},
    {"name": "El Confidencial", "url": "https://rss.elconfidencial.com/espana/"},
    {"name": "20 Minutos",      "url": "https://www.20minutos.es/rss"},
    {"name": "elDiario.es",     "url": "https://www.eldiario.es/rss/"},
    {"name": "Europa Press",    "url": "https://www.europapress.es/rss/rss.aspx"},
    {"name": "RTVE Noticias",   "url": "https://www.rtve.es/rss/temas_noticias.xml"},
    {"name": "Marca",           "url": "https://e00-marca.uecdn.es/rss/portada.xml"},
    {"name": "Diario AS",       "url": "https://feeds.as.com/mrss-s/pages/as/site/as.com/portada"},
    {"name": "Mundo Deportivo", "url": "https://www.mundodeportivo.com/rss/home.xml"},
]


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


_CUSTOM_PRESS_FILE = "custom_press_feeds.json"


def _load_custom_feeds():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    fp = os.path.join(p, _CUSTOM_PRESS_FILE)
    if not os.path.exists(fp):
        return []
    try:
        with open(fp, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def _save_custom_feeds(feeds):
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    fp = os.path.join(p, _CUSTOM_PRESS_FILE)
    try:
        with open(fp, 'w', encoding='utf-8') as f:
            json.dump(feeds, f, ensure_ascii=False)
    except OSError:
        pass


def add_custom_feed():
    kb = xbmc.Keyboard('', 'URL del feed RSS')
    kb.doModal()
    if not kb.isConfirmed():
        return
    url = kb.getText().strip()
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in ('http', 'https') or not parsed.netloc:
        xbmcgui.Dialog().ok('EspaTV', 'Introduce una URL válida (http:// o https://).')
        return
    feeds = _load_custom_feeds()
    existing = [feed['url'] for feed in _PRENSA_FEEDS] + [feed.get('url', '') for feed in feeds]
    if url in existing:
        xbmcgui.Dialog().notification('EspaTV', 'Esa fuente ya existe', xbmcgui.NOTIFICATION_WARNING)
        return
    kb2 = xbmc.Keyboard('', 'Nombre para este feed')
    kb2.doModal()
    name = (kb2.getText().strip() if kb2.isConfirmed() else '').replace('[', '').replace(']', '')
    if not name:
        name = parsed.netloc
    feeds.append({'name': name, 'url': url})
    _save_custom_feeds(feeds)
    xbmcgui.Dialog().notification('EspaTV', f"Feed '{name}' añadido", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin('Container.Refresh')


def delete_custom_feed(url):
    feeds = _load_custom_feeds()
    name = next((feed.get('name', 'Fuente') for feed in feeds if feed.get('url') == url), 'Fuente')
    if xbmcgui.Dialog().yesno('EspaTV', f"¿Eliminar el feed '{name}'?"):
        feeds = [feed for feed in feeds if feed.get('url') != url]
        _save_custom_feeds(feeds)
        xbmcgui.Dialog().notification('EspaTV', 'Fuente eliminada', xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin('Container.Refresh')


def menu():
    h = int(sys.argv[1])
    _news_icon = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'news.png')
    for feed in _PRENSA_FEEDS:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(feed['name']))
        li.setArt({'icon': _news_icon})
        li.setInfo('video', {'plot': "Explora los últimos titulares de {0}.".format(feed['name'])})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="press_list", raw_url=feed['url'], name=feed['name']), listitem=li, isFolder=True)

    for feed in _load_custom_feeds():
        name = feed.get('name', 'Fuente')
        url = feed.get('url', '')
        li = xbmcgui.ListItem(label=f"[COLOR aqua][B]{name}[/B][/COLOR]")
        li.setArt({'icon': _news_icon})
        li.setInfo('video', {'plot': f"Explora los últimos titulares de {name}."})
        li.addContextMenuItems([("Eliminar esta fuente", f"RunPlugin({_u(action='press_delete_feed', raw_url=url)})")])
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="press_list", raw_url=url, name=name), listitem=li, isFolder=True)

    li_add = xbmcgui.ListItem(label="[B]Añadir fuente RSS...[/B]")
    li_add.setArt({'icon': 'DefaultAddSource.png'})
    li_add.setInfo('video', {'plot': "Añade tu propio feed RSS al menú de Prensa."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="press_add_feed"), listitem=li_add, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def show_list(feed_url, feed_name):
    h = int(sys.argv[1])
    _news_icon = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'news.png')
    try:
        r = requests.get(feed_url, timeout=10)
        r.raise_for_status()
        root = ET.fromstring(r.content)
        items = root.findall('.//item')
        if not items:
            items = root.findall('.//{http://www.w3.org/2005/Atom}entry')

        for item in items:
            t_elem = item.find('title')
            if t_elem is None:
                t_elem = item.find('{http://www.w3.org/2005/Atom}title')
            title = (t_elem.text or "") if t_elem is not None else "Sin Titular"
            title = title.replace("<![CDATA[", "").replace("]]>", "").strip()
            if not title:
                title = "Sin Titular"

            d_elem = item.find('description')
            if d_elem is None:
                d_elem = item.find('{http://www.w3.org/2005/Atom}summary')
            desc = (d_elem.text or "") if d_elem is not None else ""
            desc = desc.replace("<![CDATA[", "").replace("]]>", "").strip()
            desc = re.sub(r'<[^>]+>', '', desc)

            thumb = _news_icon
            media_content = item.find('{http://search.yahoo.com/mrss/}content')
            if media_content is not None and media_content.get('url'):
                thumb = media_content.get('url')
            else:
                media_thumb = item.find('{http://search.yahoo.com/mrss/}thumbnail')
                if media_thumb is not None and media_thumb.get('url'):
                    thumb = media_thumb.get('url')
                else:
                    enclosure = item.find('enclosure')
                    if enclosure is not None and enclosure.get('type', '').startswith('image'):
                        thumb = enclosure.get('url')

            li = xbmcgui.ListItem(label=title)
            li.setArt({'icon': thumb, 'thumb': thumb})
            li.setInfo('video', {'title': title, 'plot': desc})

            safe_desc = desc[:500] if len(desc) > 500 else desc
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="press_read", title=title, desc=safe_desc),
                listitem=li, isFolder=False)

    except Exception as exc:
        xbmc.log("[EspaTV] Error cargando prensa ({0}): {1}".format(feed_url, exc), xbmc.LOGERROR)
        xbmcgui.Dialog().notification("EspaTV", "Error leyendo el feed.", xbmcgui.NOTIFICATION_ERROR)

    xbmcplugin.endOfDirectory(h)


def read(title, desc):
    xbmcgui.Dialog().textviewer(title, desc)
