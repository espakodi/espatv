# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Calendario Astronómico Anual: equinoccios y solsticios calculados, lluvias de
meteoros de pico anual y eclipses tabulados."""
import datetime
import math
import os
import sys
import urllib.parse

import xbmcgui
import xbmcplugin

from fases_luna import _jde_to_utc

_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

# Meeus, Astronomical Algorithms cap. 27, tabla 27.B (años 1000-3000).
# clave -> (coeficientes del JDE medio, nombre, tipo)
_ESTACIONES = [
    ((2451623.80984, 365242.37404,  0.05169, -0.00411, -0.00057),
     "Equinoccio de primavera", "equinoccio",
     "El Sol cruza el ecuador celeste hacia el norte. Inicio astronómico de la primavera "
     "en el hemisferio norte."),
    ((2451716.56767, 365241.62603,  0.00325,  0.00888, -0.00030),
     "Solsticio de verano", "solsticio",
     "El día más largo del año en el hemisferio norte. El Sol alcanza su punto más alto."),
    ((2451810.21715, 365242.01767, -0.11575,  0.00337,  0.00078),
     "Equinoccio de otoño", "equinoccio",
     "El Sol cruza el ecuador celeste hacia el sur. Inicio astronómico del otoño "
     "en el hemisferio norte."),
    ((2451900.05952, 365242.74049, -0.06223, -0.00823,  0.00032),
     "Solsticio de invierno", "solsticio",
     "La noche más larga del año en el hemisferio norte. El Sol alcanza su punto más bajo."),
]

# Correcciones periódicas (A, B, C) de la tabla 27.C
_TERMINOS = [
    (485, 324.96,   1934.136), (203, 337.23,  32964.467), (199, 342.08,     20.186),
    (182,  27.85, 445267.112), (156,  73.14,  45036.886), (136, 171.52,  22518.443),
    (77,  222.54,  65928.934), (74,  296.72,   3034.906), (70,  243.58,   9037.513),
    (58,  119.81,  33718.147), (52,  297.17,    150.678), (50,   21.02,   2281.226),
    (45,  247.54,  29929.562), (44,  325.15,  31555.956), (29,   60.93,   4443.417),
    (18,  155.12,  67555.328), (17,  288.79,   4562.452), (16,  198.04,  62894.029),
    (14,  199.76,  31436.921), (12,   95.39,  14577.848), (12,  287.11,  31931.756),
    (12,  320.81,  34777.259), (9,   227.73,   1222.114), (8,    15.45,  16859.074),
]

# Meeus devuelve Tiempo Dinámico; en esta década TT-UT ronda los 70 s. Sin restarlo,
# el resultado se desvía poco más de un minuto de la hora publicada por el ROA.
_DELTA_T_S = 70

# (mes, dia, nombre, descripcion). El pico se repite cada año con una deriva de un día.
_METEOROS = [
    (1,  3,  "Cuadrántidas",
     "Pico de hasta 120 meteoros/hora en condiciones óptimas. Radiante en Boyero."),
    (5,  6,  "Eta Acuáridas",
     "Meteoros del cometa Halley. Hasta 50/hora. Mejor vista desde el hemisferio sur."),
    (7,  28, "Delta Acuáridas del Sur",
     "Lluvia moderada, hasta 20 meteoros/hora. Buena vista desde latitudes del sur."),
    (8,  12, "Perseidas",
     "La lluvia más famosa del verano. Hasta 100 meteoros/hora. Radiante en Perseo."),
    (10, 7,  "Dracónidas",
     "Corta pero intensa. Pico variable; en años buenos supera los 100 meteoros/hora."),
    (10, 21, "Oriónidas",
     "Meteoros del cometa Halley. Hasta 20/hora. Radiante en Orión."),
    (11, 17, "Leónidas",
     "Famosa por sus tormentas históricas. Hasta 15 meteoros/hora en años normales."),
    (12, 13, "Gemínidas",
     "La más activa del año, hasta 120 meteoros/hora. Origen: asteroide Faetón."),
    (12, 21, "Úrsidas",
     "Lluvia modesta (10/hora) coincidente con el solsticio. Radiante en la Osa Menor."),
]

# Fechas y visibilidad según los catálogos de eclipses de la NASA/GSFC.
# (mes, dia, nombre, tipo, descripcion)
_ECLIPSES = {
    2026: [
        (2,  17, "Eclipse anular de Sol",    "eclipse_solar",
         "Anularidad sobre la Antártida. Parcial en el sur de Sudamérica y África. No visible desde España."),
        (3,  3,  "Eclipse total de Luna",    "eclipse_lunar",
         "Visible desde el este de Asia, Australia, el Pacífico y América. No visible desde España."),
        (8,  12, "Eclipse total de Sol",     "eclipse_solar",
         "La totalidad cruza el Ártico, Groenlandia, Islandia y el norte de España. El eclipse total "
         "más importante en la Península en más de un siglo."),
        (8,  28, "Eclipse parcial de Luna",  "eclipse_lunar",
         "Visible desde el Pacífico oriental, América, Europa y África, España incluida."),
    ],
    2027: [
        (2,  6,  "Eclipse anular de Sol",    "eclipse_solar",
         "Anularidad sobre Chile, Argentina y el Atlántico. No visible desde España."),
        (2,  20, "Eclipse penumbral de Luna", "eclipse_lunar",
         "Visible desde América, Europa, África y Asia, España incluida. La penumbra apenas "
         "oscurece el disco."),
        (7,  18, "Eclipse penumbral de Luna", "eclipse_lunar",
         "Visible desde el este de África, Asia, Australia y el Pacífico. No visible desde España."),
        (8,  2,  "Eclipse total de Sol",     "eclipse_solar",
         "La totalidad cruza Marruecos, el sur de España, Argelia, Libia y Egipto. Uno de los "
         "eclipses totales más largos del siglo."),
        (8,  17, "Eclipse penumbral de Luna", "eclipse_lunar",
         "Visible desde el Pacífico y América. No visible desde España."),
    ],
    2028: [
        (1,  12, "Eclipse parcial de Luna",  "eclipse_lunar",
         "Visible desde América, Europa y África, España incluida."),
        (1,  26, "Eclipse anular de Sol",    "eclipse_solar",
         "La anularidad cruza Ecuador, Perú, Brasil, Surinam, Portugal y España."),
        (7,  6,  "Eclipse parcial de Luna",  "eclipse_lunar",
         "Visible desde Europa, África, Asia y Australia, España incluida."),
        (7,  22, "Eclipse total de Sol",     "eclipse_solar",
         "La totalidad cruza Australia y Nueva Zelanda. No visible desde España."),
        (12, 31, "Eclipse total de Luna",    "eclipse_lunar",
         "Visible desde Europa, África, Asia, Australia y el Pacífico, España incluida."),
    ],
    2029: [
        (1,  14, "Eclipse parcial de Sol",   "eclipse_solar",
         "Visible desde América del Norte y Central. No visible desde España."),
        (6,  12, "Eclipse parcial de Sol",   "eclipse_solar",
         "Visible desde el Ártico, Escandinavia, Alaska y el norte de Asia. No visible desde España."),
        (6,  26, "Eclipse total de Luna",    "eclipse_lunar",
         "Visible desde América, Europa, África y Oriente Medio, España incluida."),
        (7,  11, "Eclipse parcial de Sol",   "eclipse_solar",
         "Visible desde el sur de Chile y Argentina. No visible desde España."),
        (12, 5,  "Eclipse parcial de Sol",   "eclipse_solar",
         "Visible desde el sur de Argentina, Chile y la Antártida. No visible desde España."),
        (12, 20, "Eclipse total de Luna",    "eclipse_lunar",
         "Visible desde América, Europa, África y Asia, España incluida."),
    ],
    2030: [
        (6,  1,  "Eclipse anular de Sol",    "eclipse_solar",
         "La anularidad cruza Argelia, Túnez, Grecia, Turquía, Rusia, el norte de China y Japón. "
         "Desde España se ve como parcial."),
        (6,  15, "Eclipse parcial de Luna",  "eclipse_lunar",
         "Visible desde Europa, África, Asia y Australia, España incluida."),
        (11, 25, "Eclipse total de Sol",     "eclipse_solar",
         "La totalidad cruza Botsuana, Sudáfrica y Australia. No visible desde España."),
        (12, 9,  "Eclipse penumbral de Luna", "eclipse_lunar",
         "Visible desde América, Europa, África y Asia, España incluida."),
    ],
    2031: [
        (5,  7,  "Eclipse penumbral de Luna", "eclipse_lunar",
         "Visible desde América, Europa y África, España incluida."),
        (5,  21, "Eclipse anular de Sol",    "eclipse_solar",
         "Anularidad sobre Angola, Congo, Zambia, Tanzania, el sur de India, Malasia e Indonesia. "
         "No visible desde España."),
        (6,  5,  "Eclipse penumbral de Luna", "eclipse_lunar",
         "Visible desde las Indias Orientales, Australia y el Pacífico. No visible desde España."),
        (10, 30, "Eclipse penumbral de Luna", "eclipse_lunar",
         "Visible desde América. No visible desde España."),
        (11, 14, "Eclipse híbrido de Sol",   "eclipse_solar",
         "Eclipse híbrido sobre el Pacífico y Panamá. No visible desde España."),
    ],
    2032: [
        (4,  25, "Eclipse total de Luna",    "eclipse_lunar",
         "Visible desde el este de África, Asia, Australia y el Pacífico. No visible desde España."),
        (5,  9,  "Eclipse anular de Sol",    "eclipse_solar",
         "Anularidad sobre el Atlántico sur. No visible desde España."),
        (10, 18, "Eclipse total de Luna",    "eclipse_lunar",
         "Visible desde África, Europa, Asia y Australia, España incluida."),
        (11, 3,  "Eclipse parcial de Sol",   "eclipse_solar",
         "Visible desde Asia. No visible desde España."),
    ],
    2033: [
        (3,  30, "Eclipse total de Sol",     "eclipse_solar",
         "La totalidad cruza el este de Rusia y Alaska. No visible desde España."),
        (4,  14, "Eclipse total de Luna",    "eclipse_lunar",
         "Visible desde Europa, África, Asia y Australia, España incluida."),
        (9,  23, "Eclipse parcial de Sol",   "eclipse_solar",
         "Visible desde el sur de Sudamérica y la Antártida. No visible desde España."),
        (10, 8,  "Eclipse total de Luna",    "eclipse_lunar",
         "Visible desde Asia, Australia, el Pacífico y América. No visible desde España."),
    ],
    2034: [
        (3,  20, "Eclipse total de Sol",     "eclipse_solar",
         "La totalidad cruza Nigeria, Chad, Sudán, Egipto, Arabia Saudí, Irán, Pakistán, India y "
         "China. Desde España se ve como parcial."),
        (4,  3,  "Eclipse penumbral de Luna", "eclipse_lunar",
         "Visible desde Europa, África, Asia y Australia, España incluida."),
        (9,  12, "Eclipse anular de Sol",    "eclipse_solar",
         "Anularidad sobre Chile, Bolivia, Argentina, Paraguay y Brasil. No visible desde España."),
        (9,  28, "Eclipse parcial de Luna",  "eclipse_lunar",
         "Visible desde América, Europa y África, España incluida."),
    ],
    2035: [
        (2,  22, "Eclipse penumbral de Luna", "eclipse_lunar",
         "Visible desde el este de Asia, el Pacífico y América. No visible desde España."),
        (3,  9,  "Eclipse anular de Sol",    "eclipse_solar",
         "Anularidad sobre Nueva Zelanda y el Pacífico. No visible desde España."),
        (8,  19, "Eclipse parcial de Luna",  "eclipse_lunar",
         "Visible desde América, Europa, África y Oriente Medio, España incluida."),
        (9,  2,  "Eclipse total de Sol",     "eclipse_solar",
         "La totalidad cruza China, Corea y Japón. No visible desde España."),
    ],
}

_TIPO_CONFIG = {
    "eclipse_solar":  ("●", "tomato",         "Eclipse Solar"),
    "eclipse_lunar":  ("○", "deepskyblue",    "Eclipse Lunar"),
    "meteor":         ("★", "gold",           "Lluvia de Meteoros"),
    "conjuncion":     ("◆", "plum",           "Conjunción Planetaria"),
    "equinoccio":     ("◈", "mediumseagreen", "Equinoccio"),
    "solsticio":      ("☼", "orange",         "Solsticio"),
    "planeta":        ("◎", "lightblue",      "Evento Planetario"),
}

_MESES_ES = ["", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
             "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]
_DIAS_ES  = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"]


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _estacion_utc(year, coefs):
    """Instante UTC de un equinoccio o solsticio (Meeus cap. 27)."""
    a, b, c, d, e = coefs
    Y = (year - 2000) / 1000
    jde0 = a + b * Y + c * Y ** 2 + d * Y ** 3 + e * Y ** 4
    T = (jde0 - 2451545.0) / 36525
    W = math.radians(35999.373 * T - 2.47)
    delta = 1 + 0.0334 * math.cos(W) + 0.0007 * math.cos(2 * W)
    S = sum(A * math.cos(math.radians(B + C * T)) for A, B, C in _TERMINOS)
    return _jde_to_utc(jde0 + (0.00001 * S) / delta - _DELTA_T_S / 86400.0)


def _eventos(year):
    """Todos los eventos del año ordenados por fecha."""
    eventos = []

    for coefs, nombre, tipo, desc in _ESTACIONES:
        dt = _estacion_utc(year, coefs)
        if dt is None:
            continue
        eventos.append({
            "date": dt.date(), "nombre": nombre, "tipo": tipo,
            "desc": f"{desc} Momento exacto: {dt:%H:%M} UTC.",
        })

    for mes, dia, nombre, desc in _METEOROS:
        eventos.append({
            "date": datetime.date(year, mes, dia), "nombre": nombre, "tipo": "meteor",
            "desc": f"{desc} La fecha del pico es aproximada y varía un día según el año.",
        })

    for mes, dia, nombre, tipo, desc in _ECLIPSES.get(year, []):
        eventos.append({
            "date": datetime.date(year, mes, dia), "nombre": nombre,
            "tipo": tipo, "desc": desc,
        })

    eventos.sort(key=lambda ev: ev["date"])
    return eventos


def calendario_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_calendario_astro.png")
    today = datetime.date.today()
    year = today.year

    mes_actual = 0
    for ev in _eventos(year):
        fecha = ev["date"]
        icono_tipo, _, _ = _TIPO_CONFIG.get(ev["tipo"], ("✨", "white", ev["tipo"]))
        days_left = (fecha - today).days

        if fecha.month != mes_actual:
            mes_actual = fecha.month
            sep = xbmcgui.ListItem(label=f"[COLOR gold]──  {_MESES_ES[mes_actual]} {year}  ──[/COLOR]")
            sep.setArt({"icon": "DefaultAddonNone.png"})
            sep.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=sep, isFolder=False)

        if days_left < 0:
            fecha_color = "grey"
        elif days_left == 0:
            fecha_color = "tomato"
        elif days_left <= 14:
            fecha_color = "gold"
        else:
            fecha_color = "white"

        dia_semana = _DIAS_ES[fecha.weekday()]
        label = (f"{icono_tipo} [B][COLOR {fecha_color}]{ev['nombre']}[/COLOR][/B]   "
                 f"[COLOR grey]{dia_semana} {fecha.day} {_MESES_ES[fecha.month]}[/COLOR]")
        plot = (f"{icono_tipo}  {ev['nombre']}\n"
                f"{dia_semana} {fecha.day} de {_MESES_ES[fecha.month].lower()} de {year}\n\n"
                f"{ev['desc']}")
        if days_left > 0:
            plot += f"\n\n[COLOR grey]Faltan {days_left} día{'s' if days_left != 1 else ''}[/COLOR]"

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon})
        li.setInfo("video", {"title": ev["nombre"], "plot": plot})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)
