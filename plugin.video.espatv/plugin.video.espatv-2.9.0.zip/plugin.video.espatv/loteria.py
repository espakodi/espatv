# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Resultados de lotería española: scraping de 20minutos.es (SELAE no permite acceso programático)."""
import os
import re
import sys
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

try:
    import requests as _requests
    try:
        from urllib3.exceptions import InsecureRequestWarning
        _requests.packages.urllib3.disable_warnings(InsecureRequestWarning)
    except (ImportError, AttributeError):
        pass
except ImportError:
    _requests = None

_LOG_TAG = "[EspaTV-Loteria]"
_ADDON = xbmcaddon.Addon()
_PROFILE_DIR = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
_CACHE_TTL = 30 * 60  # resultados cambian pocas veces al día

from _user_agents import desktop_headers as _dh, ACCEPT_HTML

_SOURCE_URL = "https://www.20minutos.es/loterias/"
_HEADERS = _dh(accept=ACCEPT_HTML)

# Mapeo clase CSS de 20minutos → nombre mostrado + color + descripción
_GAMES = [
    {"id": "primitiva",      "name": "La Primitiva",               "color": "gold",         "icon": "lot_primitiva.png",    "desc": "6 números del 1 al 49 + Complementario + Reintegro."},
    {"id": "bonoloto",       "name": "Bonoloto",                   "color": "limegreen",     "icon": "lot_bonoloto.png",     "desc": "6 números del 1 al 49 · sorteos lunes a viernes."},
    {"id": "elgordo",        "name": "El Gordo de la Primitiva",   "color": "orange",        "icon": "lot_gordo.png",        "desc": "5 números del 1 al 54 + Número Clave (0-9)."},
    {"id": "euromillones",   "name": "Euromillones",               "color": "deepskyblue",   "icon": "lot_euromillones.png", "desc": "5 números del 1 al 50 + 2 Estrellas del 1 al 12."},
    {"id": "once-ordinario", "name": "Cupón ONCE",                 "color": "coral",         "icon": "lot_once.png",         "desc": "Sorteo diario de la Organización Nacional de Ciegos."},
    {"id": "loteria-nacional","name": "Lotería Nacional",          "color": "mediumpurple",  "icon": "lot_nacional.png",     "desc": "Sorteo de Los Jueves y Especiales de Lotería Nacional."},
    {"id": "quiniela",       "name": "La Quiniela",                "color": "tomato",        "icon": "lot_quiniela.png",     "desc": "Pronósticos de 15 partidos de fútbol."},
]


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("{0} {1}".format(_LOG_TAG, msg), level)


def _cache_path():
    return os.path.join(_PROFILE_DIR, "loteria_20m.html")


def _cache_valid():
    path = _cache_path()
    if not os.path.exists(path):
        return False
    return (time.time() - os.path.getmtime(path)) < _CACHE_TTL


def _fetch_html():
    """Descarga la página de loterías de 20minutos con caché."""
    cache = _cache_path()
    if _cache_valid():
        try:
            with open(cache, "r", encoding="utf-8") as fh:
                return fh.read()
        except (OSError, ValueError):
            pass

    if _requests is None:
        _log("requests no disponible", xbmc.LOGERROR)
        return None

    try:
        resp = _requests.get(_SOURCE_URL, headers=_HEADERS, timeout=15, verify=False)  # certs de 20minutos fallan en Android antiguo
        if resp.status_code != 200:
            _log("HTTP {0} al obtener loteria".format(resp.status_code), xbmc.LOGERROR)
            return None
        html = resp.text
        try:
            os.makedirs(_PROFILE_DIR, exist_ok=True)
            with open(cache, "w", encoding="utf-8") as fh:
                fh.write(html)
        except OSError:
            pass
        return html
    except Exception as exc:
        _log("Error fetch: {0}".format(exc), xbmc.LOGERROR)
        return None


def _parse_game(html, game_id):
    """
    Localiza el primer bloque <div class="sorteo {game_id}"> y extrae números, extras y fecha.
    Devuelve dict con claves: date, numbers, extras, jackpot. None si no se encuentra.
    """
    marker = '<div class="sorteo {0}"'.format(game_id)
    idx = html.find(marker)
    if idx == -1:
        return None
    block = html[idx:idx + 1200]

    date_m = re.search(r'<h3 class="titre">([^<]+)</h3>', block)
    date_str = date_m.group(1).strip() if date_m else ""
    # Quitar prefijo tipo "Primitiva - "
    if " - " in date_str:
        date_str = date_str.split(" - ", 1)[1]

    # Números principales (spans sin clase)
    numbers = re.findall(r'<span>(\d+)</span>', block)

    # Extras (complementario, reintegro, estrellas, clave, jackpot, etc.)
    extras = re.findall(r'<span class="n[a-z0-9]+"[^>]*>([^<]+)</span>', block)

    # Jackpot separado si está como J:
    jackpot = ""
    for e in extras:
        if e.startswith("J:") or e.startswith("J: "):
            jackpot = e
            break

    return {
        "date": date_str,
        "numbers": numbers,
        "extras": [e for e in extras if not e.startswith("J")],
        "jackpot": jackpot,
    }


def _build_plot(game, result):
    nums = "  ".join(result["numbers"]) if result["numbers"] else "—"
    lines = [
        "[B][COLOR {color}]{name}[/COLOR][/B]".format(**game),
        "[COLOR gray]{date}[/COLOR]".format(**result),
        "",
        "[B]Números:[/B]  {0}".format(nums),
    ]
    for extra in result["extras"]:
        lines.append("  {0}".format(extra))
    if result.get("jackpot"):
        lines.append("")
        lines.append("[COLOR gold]{0}[/COLOR]".format(result["jackpot"]))
    return "\n".join(lines)


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def loteria_menu():
    h = int(sys.argv[1])
    _mp = os.path.join(_ADDON.getAddonInfo('path'), 'resources', 'media')

    def _ri(name, fallback='DefaultAddonGame.png'):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    try:
        ts = os.path.getmtime(_cache_path())
        updated_at = time.strftime("%d/%m/%Y  %H:%M", time.localtime(ts))
    except OSError:
        updated_at = None
    upd_label = "[COLOR grey]Actualizado: {0}[/COLOR]".format(updated_at) if updated_at else "[COLOR grey]Sin datos descargados aún[/COLOR]"
    li_upd = xbmcgui.ListItem(label=upd_label)
    li_upd.setArt({"icon": "DefaultIconInfo.png"})
    li_upd.setInfo("video", {"plot": "Última actualización: {0}".format(updated_at or "—")})
    li_upd.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li_upd, isFolder=False)

    for game in _GAMES:
        label = "[B][COLOR {color}]{name}[/COLOR][/B]".format(**game)
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": _ri(game["icon"])})
        li.setInfo("video", {"plot": game["desc"], "title": game["name"]})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="loteria_result", game_id=game["id"]),
            listitem=li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(h)


def loteria_result(game_id):
    h = int(sys.argv[1])
    game = next((g for g in _GAMES if g["id"] == game_id), None)
    game_name = game["name"] if game else game_id

    xbmcgui.Dialog().notification(
        "EspaTV", "Consultando resultados…",
        xbmcgui.NOTIFICATION_INFO, 1500,
    )

    html = _fetch_html()
    if not html:
        li = xbmcgui.ListItem(
            label="[COLOR red]Sin datos — comprueba la conexión[/COLOR]"
        )
        li.setInfo("video", {"plot": "No se pudo descargar la página de resultados.\nComprueba tu conexión."})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    result = _parse_game(html, game_id)
    if not result:
        li = xbmcgui.ListItem(
            label="[COLOR gray]Sin resultado reciente para {0}[/COLOR]".format(game_name)
        )
        li.setInfo("video", {"plot": "No hay datos para este sorteo en este momento.\nPuede que no haya habido sorteo hoy."})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
    else:
        nums_str = "  ".join(result["numbers"]) if result["numbers"] else "—"
        extras_str = "  |  ".join(result["extras"]) if result["extras"] else ""
        label = "[B][COLOR gold]{name}[/COLOR][/B]   {nums}".format(
            name=game_name, nums=nums_str
        )
        if extras_str:
            label += "   [COLOR gray]{0}[/COLOR]".format(extras_str)

        plot = _build_plot(game, result) if game else "\n".join(
            [nums_str] + result["extras"]
        )

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": "DefaultAddonGame.png"})
        li.setInfo("video", {"plot": plot, "title": game_name})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="money_money"), listitem=li, isFolder=False)

    # Botón refrescar
    li_r = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar resultado ][/COLOR]")
    li_r.setArt({"icon": "DefaultAddonService.png"})
    li_r.setInfo("video", {"plot": "Elimina la caché y recarga los datos."})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="loteria_refresh", game_id=game_id),
        listitem=li_r,
        isFolder=True,
    )
    xbmcplugin.endOfDirectory(h)


def loteria_refresh(game_id):
    cache = _cache_path()
    try:
        if os.path.exists(cache):
            os.remove(cache)
    except OSError:
        pass
    xbmc.executebuiltin(
        "Container.Update({0})".format(_u(action="loteria_result", game_id=game_id))
    )
