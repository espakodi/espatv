# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Calendario de emisión: próximos episodios de las series en emisión.

Un JSON (TTL 6 h) cubre toda la ventana. El fetch dispara ~80 llamadas a TMDB
en paralelo (12 workers) y una a Trakt para horas de emisión en UTC.
"""
import json
import os
import sys
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed
from datetime import date, datetime, timedelta, timezone

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings

_TMDB_BASE = "https://api.themoviedb.org/3"
_IMG_W342  = "https://image.tmdb.org/t/p/w342"
_IMG_ORIG  = "https://image.tmdb.org/t/p/original"

_CACHE_FILE  = 'espatv_calendario_series.json'
_TTL_SEC     = 6 * 3600
_DAYS_AHEAD  = 14
_MAX_SHOWS   = 40           # ≈ 2 páginas de /tv/on_the_air
_MAX_WORKERS = 12

_DAY_NAMES   = ['lunes', 'martes', 'miércoles', 'jueves',
                'viernes', 'sábado', 'domingo']
_MONTH_NAMES = ['enero', 'febrero', 'marzo', 'abril', 'mayo', 'junio',
                'julio', 'agosto', 'septiembre', 'octubre', 'noviembre', 'diciembre']

# TMDB devuelve air_time en hora local del país de origen, sin TZ.
# La TZ de referencia permite que el usuario haga la conversión manual.
_COUNTRY_INFO = {
    'US': ('Estados Unidos', 'ET, UTC-5/-4'),
    'GB': ('Reino Unido',    'GMT, UTC+0/+1'),
    'CA': ('Canadá',         'ET, UTC-5/-4'),
    'AU': ('Australia',      'AEST, UTC+10/+11'),
    'NZ': ('Nueva Zelanda',  'NZST, UTC+12/+13'),
    'IE': ('Irlanda',        'GMT, UTC+0/+1'),
    'ES': ('España',         'CET, UTC+1/+2'),
    'FR': ('Francia',        'CET, UTC+1/+2'),
    'DE': ('Alemania',       'CET, UTC+1/+2'),
    'IT': ('Italia',         'CET, UTC+1/+2'),
    'PT': ('Portugal',       'WET, UTC+0/+1'),
    'NL': ('Países Bajos',   'CET, UTC+1/+2'),
    'BE': ('Bélgica',        'CET, UTC+1/+2'),
    'SE': ('Suecia',         'CET, UTC+1/+2'),
    'NO': ('Noruega',        'CET, UTC+1/+2'),
    'DK': ('Dinamarca',      'CET, UTC+1/+2'),
    'FI': ('Finlandia',      'EET, UTC+2/+3'),
    'PL': ('Polonia',        'CET, UTC+1/+2'),
    'TR': ('Turquía',        'TRT, UTC+3'),
    'RU': ('Rusia',          'MSK, UTC+3'),
    'JP': ('Japón',          'JST, UTC+9'),
    'KR': ('Corea del Sur',  'KST, UTC+9'),
    'CN': ('China',          'CST, UTC+8'),
    'TW': ('Taiwán',         'CST, UTC+8'),
    'HK': ('Hong Kong',      'HKT, UTC+8'),
    'IN': ('India',          'IST, UTC+5:30'),
    'TH': ('Tailandia',      'ICT, UTC+7'),
    'MX': ('México',         'CT, UTC-6/-5'),
    'AR': ('Argentina',      'ART, UTC-3'),
    'BR': ('Brasil',         'BRT, UTC-3'),
    'CL': ('Chile',          'CLT, UTC-4/-3'),
    'CO': ('Colombia',       'COT, UTC-5'),
    'PE': ('Perú',           'PET, UTC-5'),
    'IL': ('Israel',         'IST, UTC+2/+3'),
    'ZA': ('Sudáfrica',      'SAST, UTC+2'),
}

_LOG_TAG = "[EspaTV-CS]"


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("{0} {1}".format(_LOG_TAG, msg), level)


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


def _handle():
    return int(sys.argv[1])


def _api_key():
    return core_settings.get_tmdb_api_key()


_session = requests.Session()


def _tmdb_get(path, params=None):
    # Reusa conexión (~80 llamadas por calendario) y rota la clave del pool si
    # TMDB la rechaza, igual que metadata_enricher._tmdb_get.
    key = _api_key()
    if not key:
        return None
    full = dict(params or {}, api_key=key, language='es-ES')
    url = "{0}/{1}".format(_TMDB_BASE, path)
    try:
        r = _session.get(url, params=full, timeout=10)
        if r.status_code in (401, 403):
            core_settings.mark_tmdb_key_dead(key)
            next_key = core_settings.get_tmdb_api_key()
            if next_key and next_key != key:
                full['api_key'] = next_key
                r = _session.get(url, params=full, timeout=10)
        if r.status_code != 200:
            return None
        return r.json()
    except (requests.RequestException, ValueError) as e:
        _log("error {0}: {1}".format(path, e), xbmc.LOGERROR)
        return None


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, _CACHE_FILE)


def _load_cache():
    p = _cache_path()
    if not os.path.exists(p):
        return None
    try:
        with open(p, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else None
    except (OSError, ValueError):
        return None


def _save_cache(data):
    p = _cache_path()
    try:
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = p + '.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, p)
    except OSError as e:
        _log("cache save: {0}".format(e), xbmc.LOGWARNING)


def _today():
    return date.today()


def _parse_date(s):
    # Parseo manual en vez de datetime.strptime: strptime falla de forma
    # intermitente en el intérprete de Kodi (importación perezosa de _strptime)
    # y devuelve None para fechas válidas, lo que vaciaba el calendario.
    try:
        y, m, d = s.split('-')
        return date(int(y), int(m), int(d))
    except (TypeError, ValueError, AttributeError):
        return None


def _spanish_day_label(d, today):
    delta = (d - today).days
    if delta == 0:
        return "Hoy"
    if delta == 1:
        return "Mañana"
    weekday = _DAY_NAMES[d.weekday()].capitalize()
    month   = _MONTH_NAMES[d.month - 1]
    return "{0} {1} {2}".format(weekday, d.day, month)


def _air_time_line(aired_at_utc, air_time=None, origin_cc=None):
    if aired_at_utc:
        try:
            # Parseo manual (sin strptime; ver nota en _parse_date).
            dpart, _, tpart = aired_at_utc[:19].partition('T')
            y, mo, d = dpart.split('-')
            hh, mi, ss = tpart.split(':')
            utc_dt = datetime(int(y), int(mo), int(d), int(hh), int(mi), int(ss), tzinfo=timezone.utc)
            local_dt = utc_dt.astimezone()
            return ("[B]Hora de emisión:[/B] {0}  "
                    "[COLOR grey](hora local — fuente: Trakt)[/COLOR]"
                    .format(local_dt.strftime('%H:%M')))
        except (TypeError, ValueError):
            pass
    if air_time:
        cc = (origin_cc or '').upper()
        info = _COUNTRY_INFO.get(cc)
        if info:
            country, tz = info
            return ("[B]Hora de emisión:[/B] {0}  "
                    "[COLOR grey](hora local de {1} — {2})[/COLOR]"
                    .format(air_time, country, tz))
        return ("[B]Hora de emisión:[/B] {0}  "
                "[COLOR grey](hora local del país de origen)[/COLOR]"
                .format(air_time))
    return ''


# Construcción del calendario

def _fetch_on_the_air_shows():
    out  = []
    seen = set()
    for page in (1, 2):
        data = _tmdb_get('tv/on_the_air', {'page': page})
        if not data:
            break
        for r in (data.get('results') or []):
            sid = r.get('id')
            if not sid or sid in seen:
                continue
            seen.add(sid)
            out.append(r)
            if len(out) >= _MAX_SHOWS:
                return out
        if data.get('page', 1) >= data.get('total_pages', 1):
            break
    return out


def _build_episode(detail, season_no, ep_data, show_fallback):
    poster_path   = detail.get('poster_path') or ''
    backdrop_path = detail.get('backdrop_path') or ''
    origin = detail.get('origin_country') or show_fallback.get('origin_country') or []
    return {
        'air_date':      ep_data.get('air_date') or '',
        'air_time':      detail.get('air_time') or '',
        'origin_cc':     (origin[0] if origin else ''),
        'show_id':       detail.get('id') or show_fallback.get('id'),
        'show_name':     detail.get('name') or show_fallback.get('name', ''),
        'show_orig':     detail.get('original_name') or '',
        'show_overview': detail.get('overview') or show_fallback.get('overview', ''),
        'poster':        "{0}{1}".format(_IMG_W342, poster_path) if poster_path else '',
        'fanart':        "{0}{1}".format(_IMG_ORIG, backdrop_path) if backdrop_path else '',
        'season':        ep_data.get('season_number') if ep_data.get('season_number') is not None else season_no,
        'episode':       ep_data.get('episode_number') or 0,
        'ep_name':       ep_data.get('name') or '',
        'ep_overview':   ep_data.get('overview') or '',
    }


def _fetch_show_episodes(show, today, until):
    # Devuelve (lista, motivo) o None.
    # None = fallo de red en /tv/{id}; el caller lo trata como sistémico y conserva la caché.
    sid = show.get('id')
    if not sid:
        return ([], 'no_sid')

    detail = _tmdb_get('tv/{0}'.format(sid))
    if detail is None:
        return None

    # TMDB puede devolver HTTP 200 con {"status_code": 7, ...} en vez de 4xx.
    if 'status_code' in detail and 'status_message' in detail:
        return ([], 'tmdb_error_body')
    if not detail.get('next_episode_to_air') and not detail.get('last_episode_to_air'):
        return ([], 'no_episode_metadata')

    nxt  = detail.get('next_episode_to_air') or {}
    last = detail.get('last_episode_to_air') or {}

    season_no = nxt.get('season_number')
    if season_no is None:
        season_no = last.get('season_number')
    if season_no is None:
        return ([], 'no_season_no')

    season = _tmdb_get('tv/{0}/season/{1}'.format(sid, season_no))
    out  = []
    seen = set()
    season_failed = (season is None) or ('status_code' in (season or {}))

    season_eps_total = 0
    season_eps_with_date = 0
    if not season_failed:
        season_eps_total = len(season.get('episodes') or [])
        for ep in (season.get('episodes') or []):
            if ep.get('air_date'):
                season_eps_with_date += 1
            d = _parse_date(ep.get('air_date'))
            if not d or d < today or d > until:
                continue
            built = _build_episode(detail, season_no, ep, show)
            key = (built['show_id'], built['season'], built['episode'])
            if key in seen:
                continue
            seen.add(key)
            out.append(built)

    # /season puede tener air_date=null aunque next_episode_to_air sí tenga fecha.
    # También cubre estreno de nueva temporada y fallos parciales de /season.
    nxt_season = nxt.get('season_number')
    nxt_air = nxt.get('air_date')
    if nxt_air and nxt_season is not None:
        d = _parse_date(nxt_air)
        if d and today <= d <= until:
            built = _build_episode(detail, nxt_season, nxt, show)
            key = (built['show_id'], built['season'], built['episode'])
            if key not in seen:
                seen.add(key)
                out.append(built)

    if not out:
        if season_failed:
            reason = 'season_failed_and_nxt_outside'
        elif season_eps_total == 0:
            reason = 'season_empty'
        elif season_eps_with_date == 0:
            reason = 'season_eps_no_dates'
        elif not nxt_air:
            reason = 'season_dates_outside_no_nxt'
        else:
            reason = 'all_outside_window'
        return (out, reason)
    return (out, 'ok' if not season_failed else 'ok_via_fallback')


def _fetch_trakt_air_times(today, days):
    """Devuelve {(tmdb_id, temporada, ep): 'YYYY-MM-DDTHH:MM:SS'} (UTC) o {} ante cualquier error."""
    api_key = core_settings.get_trakt_api_key()
    if not api_key:
        return {}
    url = 'https://api.trakt.tv/calendars/all/shows/{0}/{1}'.format(today, days)
    headers = {
        'Content-Type':      'application/json',
        'trakt-api-version': '2',
        'trakt-api-key':     api_key,
    }
    try:
        r = requests.get(url, headers=headers, timeout=10)
        if r.status_code == 429:
            try:
                wait = int(r.headers.get('Retry-After', '2'))
            except (TypeError, ValueError):
                wait = 2
            time.sleep(min(max(wait, 1), 10))
            r = requests.get(url, headers=headers, timeout=10)
        if r.status_code != 200:
            _log("trakt calendar: HTTP {0}".format(r.status_code), xbmc.LOGWARNING)
            return {}
        data = r.json()
    except (requests.RequestException, ValueError) as e:
        _log("trakt calendar error: {0}".format(e), xbmc.LOGWARNING)
        return {}

    # Trakt devuelve una lista; ante un error con HTTP 200 puede ser un dict.
    if not isinstance(data, list):
        return {}
    result = {}
    for entry in data:
        fa = entry.get('first_aired') or ''
        if not fa:
            continue
        show = entry.get('show') or {}
        ep   = entry.get('episode') or {}
        tmdb_id = (show.get('ids') or {}).get('tmdb')
        season  = ep.get('season')
        ep_num  = ep.get('number')
        if tmdb_id and season is not None and ep_num is not None:
            result[(int(tmdb_id), int(season), int(ep_num))] = fa[:19]
    _log("trakt calendar: {0} entradas".format(len(result)))
    return result


_FAILED_FETCH_COOLDOWN_SEC = 30 * 60


def _serve_stale(cached):
    # Persiste last_failed_attempt para que el cooldown sobreviva reinicios.
    # stale=True solo en memoria, no contaminar la caché en disco.
    cached['last_failed_attempt'] = int(time.time())
    _save_cache(cached)
    cached['stale'] = True
    return cached


def _build_calendar(force_refresh=False):
    if not _api_key():
        return {'episodes': [], 'generated_at': 0,
                'window_days': _DAYS_AHEAD, 'error': 'no_api_key'}

    cached = _load_cache()
    if not force_refresh and cached:
        gen = cached.get('generated_at', 0)
        if not isinstance(gen, (int, float)):
            gen = 0
        age = time.time() - gen
        last_fail = cached.get('last_failed_attempt')
        if not isinstance(last_fail, (int, float)):
            last_fail = 0
        in_cooldown = (
            last_fail and (time.time() - last_fail) < _FAILED_FETCH_COOLDOWN_SEC
            and cached.get('episodes')
        )
        if age < _TTL_SEC or in_cooldown:
            if in_cooldown:
                cached['stale'] = True
            return cached

    today = _today()
    until = today + timedelta(days=_DAYS_AHEAD)

    with ThreadPoolExecutor(max_workers=2) as pre_ex:
        trakt_future = pre_ex.submit(_fetch_trakt_air_times, today, _DAYS_AHEAD)
        shows_future = pre_ex.submit(_fetch_on_the_air_shows)
        shows       = shows_future.result()
        trakt_times = trakt_future.result()

    _log("on_the_air: {0} series, trakt: {1} entradas".format(
        len(shows) if shows else 0, len(trakt_times)))
    if not shows:
        # Fallo de red: mejor mostrar caché caducada que pantalla en blanco.
        if cached and cached.get('episodes'):
            cached['stale'] = True
            return cached
        return {'episodes': [], 'generated_at': int(time.time()),
                'window_days': _DAYS_AHEAD, 'error': 'fetch_failed'}

    all_eps       = []
    seen_eps      = set()
    success_count = 0
    fail_count    = 0
    reasons       = {}
    with ThreadPoolExecutor(max_workers=_MAX_WORKERS) as ex:
        futures = [ex.submit(_fetch_show_episodes, s, today, until) for s in shows]
        for f in as_completed(futures):
            try:
                result = f.result()
            except Exception as e:
                _log("fetch episodes: {0}".format(e), xbmc.LOGWARNING)
                fail_count += 1
                continue
            if result is None:
                fail_count += 1
                continue
            eps, reason = result
            reasons[reason] = reasons.get(reason, 0) + 1
            success_count += 1
            for ep in eps:
                key = (ep['show_id'], ep['season'], ep['episode'])
                if key in seen_eps:
                    continue
                seen_eps.add(key)
                all_eps.append(ep)
    _log("resultado: {0} series OK, {1} fallos, {2} episodios en ventana {3}→{4} | motivos: {5}".format(
        success_count, fail_count, len(all_eps), today, until, reasons))

    # Bajo throttling TMDB devuelve HTTP 200 con /season de temporadas viejas,
    # no un 429 limpio. >50% all_outside_window indica degradación.
    suspicious = reasons.get('all_outside_window', 0) > len(shows) // 2
    if suspicious and cached and cached.get('episodes'):
        _log("degradación detectada: {0}/{1} shows con all_outside_window — conservando caché previa".format(
            reasons.get('all_outside_window', 0), len(shows)), xbmc.LOGWARNING)
        return _serve_stale(cached)

    # No sobreescribir 6 h de caché con un calendario vacío por fallo transitorio.
    if success_count == 0 and fail_count > 0:
        _log("all per-show fetches failed ({0})".format(fail_count), xbmc.LOGWARNING)
        if cached and cached.get('episodes'):
            return _serve_stale(cached)
        return {'episodes': [], 'generated_at': int(time.time()),
                'window_days': _DAYS_AHEAD, 'error': 'fetch_failed'}

    if trakt_times:
        for ep in all_eps:
            key = (int(ep.get('show_id') or 0),
                   int(ep.get('season') or 0),
                   int(ep.get('episode') or 0))
            fa = trakt_times.get(key)
            if fa:
                ep['aired_at_utc'] = fa

    all_eps.sort(key=lambda e: (
        e.get('air_date', ''),
        e.get('show_name', ''),
        int(e.get('season') or 0),
        int(e.get('episode') or 0),
    ))

    payload = {
        'generated_at':  int(time.time()),
        'window_days':   _DAYS_AHEAD,
        'episodes':      all_eps,
        'shows_fetched': len(shows),
    }
    if fail_count:
        payload['partial_fail'] = fail_count
    if cached and cached.get('last_manual_refresh'):
        payload['last_manual_refresh'] = cached['last_manual_refresh']
    _save_cache(payload)
    return payload


# Presentación

def _addon_fanart():
    return xbmcaddon.Addon().getAddonInfo('fanart')


def _add_refresh_button(h, age_min):
    # Sin [B] manual: el patch de accesibilidad de default.py aplica la negrita
    # global (solo lo hace si el label no lleva ya [B]).
    label = ("[COLOR limegreen]Actualizar calendario[/COLOR]"
             "   [COLOR grey](datos de hace {0} min)[/COLOR]").format(age_min)
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': 'DefaultRecentlyAddedEpisodes.png', 'fanart': _addon_fanart()})
    li.setInfo('video', {'plot':
        "Vuelve a consultar TMDB para regenerar el calendario.\n\n"
        "Los datos se cachean durante {0} h para no saturar la API.".format(_TTL_SEC // 3600)})
    # isFolder=False + IsPlayable=false: la acción refresca en el sitio
    # (Container.Refresh) en vez de navegar, así no apila historial al pulsar.
    li.setProperty('IsPlayable', 'false')
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action='calendario_series_refresh'), listitem=li, isFolder=False)


def _add_day_separator(h, day_label):
    sep = xbmcgui.ListItem(label="[COLOR cyan]── {0} ──[/COLOR]".format(day_label))
    sep.setArt({'icon': 'DefaultFolder.png', 'fanart': _addon_fanart()})
    sep.setInfo('video', {'plot': day_label})
    xbmcplugin.addDirectoryItem(handle=h, url='', listitem=sep, isFolder=False)


def _add_empty_message(h, days):
    li = xbmcgui.ListItem(
        label="[COLOR yellow]No hay episodios programados en los próximos {0} días.[/COLOR]".format(days))
    li.setArt({'icon': 'DefaultIconInfo.png', 'fanart': _addon_fanart()})
    xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)


def _add_no_apikey_message(h):
    li = xbmcgui.ListItem(
        label="[COLOR red]Configura la API key de TMDB en los ajustes del addon[/COLOR]")
    li.setArt({'icon': 'DefaultIconError.png', 'fanart': _addon_fanart()})
    xbmcplugin.addDirectoryItem(handle=h, url='', listitem=li, isFolder=False)


def _add_episode_item(h, ep, addon_fanart):
    season  = int(ep.get('season') or 0)
    episode = int(ep.get('episode') or 0)
    s_e     = "S{0:02d}E{1:02d}".format(season, episode)
    ep_name = ep.get('ep_name') or ''
    title_part = " — {0}".format(ep_name) if ep_name else ''
    # Sin [B] manual: el patch de accesibilidad aplica la negrita global.
    label = "{0}   [COLOR grey]{1}{2}[/COLOR]".format(
        ep.get('show_name', '?'), s_e, title_part)
    li = xbmcgui.ListItem(label=label)

    poster = ep.get('poster') or ''
    art    = {'icon': 'DefaultTVShows.png'}
    if poster:
        art.update({'thumb': poster, 'poster': poster})
    art['fanart'] = ep.get('fanart') or addon_fanart
    li.setArt(art)

    plot_lines = []
    time_line = _air_time_line(ep.get('aired_at_utc'), ep.get('air_time'), ep.get('origin_cc'))
    if time_line:
        plot_lines.append(time_line)
    if ep_name:
        plot_lines.append("[B]{0}[/B]".format(ep_name))
    if ep.get('ep_overview'):
        plot_lines.append(ep['ep_overview'])
    if ep.get('show_overview'):
        plot_lines.append("[I]{0}[/I]".format(ep['show_overview']))

    # Sin 'title' ni mediatype='episode': con ellos el skin muestra el título de
    # InfoLabel (texto plano) en la lista en vez del label, y ese título no pasa
    # por el patch de accesibilidad (default.py), así que no salía en negrita.
    # Dejando solo 'plot', el skin muestra el label (que sí formatea el patch) y
    # el panel de info sigue mostrando la sinopsis con hora de emisión.
    li.setInfo('video', {'plot': "\n\n".join(plot_lines)})

    show_name = ep.get('show_name', '')
    tmdb_id   = ep.get('show_id') or ''
    cm = [
        ("¿Dónde ver en España?", "RunPlugin({0})".format(
            _u(action='show_watch_providers', title=show_name, tmdb_id=tmdb_id))),
        ("Buscar en más fuentes", "Container.Update({0})".format(
            _u(action='search_movie_multi', q=show_name, tmdb_id=tmdb_id,
               media_type='show', season=season, episode=episode))),
    ]
    li.addContextMenuItems(cm)
    li.setProperty('IsPlayable', 'false')
    url = _u(action='search_alt_prompt', q=show_name, ot=poster, mode='show',
             tmdb_id=tmdb_id, season=season, episode=episode)
    xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=False)


def show_calendar():
    # Siempre sirve desde caché (TTL 6 h). El refresco forzado lo hace refresh()
    # antes de un Container.Refresh, no esta función.
    h  = _handle()
    af = _addon_fanart()

    if not _api_key():
        _add_no_apikey_message(h)
        # Sin cacheToDisc=False Kodi cachearía el error; al configurar la key y volver seguiría viéndolo.
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    # Sin UNSORTED, algunos skins reordenan alfabéticamente y rompen los separadores de día.
    xbmcplugin.addSortMethod(h, xbmcplugin.SORT_METHOD_UNSORTED)

    payload = _build_calendar()

    if payload.get('error') == 'fetch_failed':
        xbmcgui.Dialog().notification(
            "EspaTV", "No se pudo obtener el calendario de TMDB",
            xbmcgui.NOTIFICATION_ERROR, 3000)

    eps  = payload.get('episodes') or []
    days = payload.get('window_days', _DAYS_AHEAD)

    raw_gen = payload.get('generated_at')
    gen_at  = int(raw_gen) if isinstance(raw_gen, (int, float)) else 0
    age_min = max(0, int((time.time() - gen_at) / 60))

    # Render con cada sección aislada: un fallo en el aviso o en un episodio
    # concreto no debe vaciar el resto, y endOfDirectory ha de llamarse siempre
    # (sin él Kodi deja el directorio colgado y solo muestra lo añadido antes
    # del fallo). El cacheToDisc lo decide la opción "Recordar posición en las
    # listas": si está activa la lista se cachea y el contador "datos de hace
    # X min" puede quedar congelado hasta refrescar.
    painted = 0
    try:
        try:
            _add_refresh_button(h, age_min)
        except Exception as e:
            _log("render botón actualizar: {0}".format(e), xbmc.LOGWARNING)

        if payload.get('stale'):
            try:
                warn = xbmcgui.ListItem(
                    label="[COLOR orange]Mostrando datos antiguos: TMDB no responde ahora mismo[/COLOR]")
                warn.setArt({'icon': 'DefaultIconWarning.png', 'fanart': af})
                warn.setInfo('video', {'plot': "Se muestra la última actualización correcta del calendario."})
                xbmcplugin.addDirectoryItem(handle=h, url='', listitem=warn, isFolder=False)
            except Exception as e:
                _log("render aviso datos antiguos: {0}".format(e), xbmc.LOGWARNING)

        if not eps:
            _add_empty_message(h, days)
        else:
            today    = _today()
            last_day = None
            for ep in eps:
                try:
                    d = _parse_date(ep.get('air_date'))
                    if not d:
                        continue
                    if d != last_day:
                        _add_day_separator(h, _spanish_day_label(d, today))
                        last_day = d
                    _add_episode_item(h, ep, af)
                    painted += 1
                except Exception as e:
                    _log("render episodio {0}: {1}".format(ep.get('show_name', '?'), e), xbmc.LOGWARNING)
            _log("pintados {0}/{1} episodios".format(painted, len(eps)))
    finally:
        xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.remember_list_position())


_REFRESH_COOLDOWN_SEC = 24 * 3600


def refresh():
    # TMDB bajo rate-limit devuelve 200 con datos viejos, no errores limpios.
    # Limitar a 1 refresh diario reduce la probabilidad de degradar la caché.
    cached = _load_cache() or {}
    raw_last = cached.get('last_manual_refresh', 0)
    last_manual = raw_last if isinstance(raw_last, (int, float)) else 0
    now = int(time.time())
    elapsed = now - int(last_manual)
    # elapsed < 0: reloj del sistema retrocedió; no bloquear al usuario.
    # El botón es isFolder=False: refrescamos en el sitio con Container.Refresh
    # (re-ejecuta action=calendario_series sobre la caché) en vez de navegar a
    # un directorio nuevo, que apilaría historial en cada pulsación.
    if last_manual and 0 <= elapsed < _REFRESH_COOLDOWN_SEC:
        remaining = _REFRESH_COOLDOWN_SEC - elapsed
        h_left = remaining // 3600
        m_left = (remaining % 3600) // 60
        xbmcgui.Dialog().notification(
            "EspaTV",
            "Solo 1 actualización al día. Próxima en {0}h {1:02d}m".format(h_left, m_left),
            xbmcgui.NOTIFICATION_INFO, 5000)
        return

    # Marcar antes del fetch: si falla también cuenta; evita reintentos en bucle durante degradación.
    cached['last_manual_refresh'] = now
    _save_cache(cached)
    xbmcgui.Dialog().notification("EspaTV", "Actualizando calendario...", xbmcgui.NOTIFICATION_INFO, 2000)
    _build_calendar(force_refresh=True)        # regenera la caché en disco
    xbmc.executebuiltin("Container.Refresh")   # recarga la lista actual con la caché fresca
