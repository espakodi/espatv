# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Música Libre: CC music + Radio Online. Sin API key."""
import hashlib
import json
import os
import sys
import time
import urllib.parse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_LOG     = "[EspaTV-MUS]"
_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
_CACHE_DIR  = os.path.join(_PROFILE, "musica_cache")
_CACHE_TTL  = 24 * 3600
_TIMEOUT    = 20
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

# Internet Archive — búsqueda de audio con licencia Creative Commons
_ARCHIVE_SEARCH = "https://archive.org/advancedsearch.php"
_ARCHIVE_META   = "https://archive.org/metadata/{identifier}"

# Radio Browser — estaciones de radio libres, sin API key
_RADIO_API = "https://de1.api.radio-browser.info/json/stations/search"

_GENEROS_ARCHIVE = [
    ("Clasica",    "classical"),
    ("Jazz",       "jazz"),
    ("Folk",       "folk"),
    ("Ambient",    "ambient"),
    ("Electronica","electronic"),
    ("Rock",       "rock"),
    ("Pop",        "pop"),
    ("Flamenco",   "flamenco"),
]

_BSO_LIBRE_CATEGORIAS = [
    ("Mas Populares",                '(subject:"soundtrack" OR title:"soundtrack")',                                              "downloads",  "cc_pd"),
    ("Novedades",                    '(subject:"soundtrack" OR title:"soundtrack")',                                              "publicdate", "cc_pd"),
    ("Kevin MacLeod (Royalty Free)", 'creator:"Kevin MacLeod"',                                                                   "downloads",  None),
    ("Clasica (Dominio Publico)",    '(subject:"classical" AND (subject:"piano" OR subject:"orchestral"))',                       "downloads",  "cc_pd"),
    ("Cinematic / Orquestal",        '(subject:"cinematic" OR subject:"orchestral") AND (subject:"soundtrack" OR title:"film")',  "downloads",  "cc_pd"),
    ("Bandas Sonoras (film score)",  'subject:"film score" OR title:"film score"',                                                "downloads",  "cc_pd"),
    ("Royalty Free Music",           'subject:"royalty free" OR title:"royalty free"',                                            "downloads",  "cc_pd"),
    ("Buscar...",                    "__SEARCH__",                                                                                "downloads",  "cc_pd"),
]

_PAISES_RADIO = [
    ("ES", "España"),
    ("MX", "Mexico"),
    ("AR", "Argentina"),
    ("CL", "Chile"),
    ("CO", "Colombia"),
    ("PE", "Peru"),
    ("VE", "Venezuela"),
    ("UY", "Uruguay"),
]

_GENEROS_RADIO = [
    ("pop",        "Pop"),
    ("rock",       "Rock"),
    ("jazz",       "Jazz"),
    ("classical",  "Clasica"),
    ("electronic", "Electronica"),
    ("flamenco",   "Flamenco"),
    ("folk",       "Folk"),
    ("news",       "Noticias"),
    ("sports",     "Deportes"),
]


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _cache_path(key):
    os.makedirs(_CACHE_DIR, exist_ok=True)
    return os.path.join(_CACHE_DIR, hashlib.md5(key.encode()).hexdigest() + ".json")


def _load_cache(key):
    fp = _cache_path(key)
    try:
        with open(fp, "r", encoding="utf-8") as f:
            obj = json.load(f)
        if time.time() - obj.get("ts", 0) < _CACHE_TTL:
            return obj.get("data")
    except (OSError, ValueError):
        pass
    return None


def _save_cache(key, data):
    fp = _cache_path(key)
    try:
        with open(fp, "w", encoding="utf-8") as f:
            json.dump({"ts": time.time(), "data": data}, f, ensure_ascii=False)
    except OSError as e:
        xbmc.log("{0} Error cache: {1}".format(_LOG, e), xbmc.LOGWARNING)


# API de Internet Archive

def _fetch_archive(query, sort="downloads", rows=30, license_filter="cc"):
    """license_filter:
       - "cc"    → solo Creative Commons (música CC)
       - "cc_pd" → CC o dominio público
       - None    → sin filtro de licencia
    """
    if license_filter == "cc":
        lic_clause = " AND licenseurl:(*creativecommons*)"
    elif license_filter == "cc_pd":
        lic_clause = " AND licenseurl:(*creativecommons* OR *publicdomain*)"
    else:
        lic_clause = ""

    cache_key = "archive_{0}_{1}_{2}".format(query, sort, license_filter or "any")
    cached = _load_cache(cache_key)
    if cached is not None:
        return cached

    params = {
        "q":       "{0} AND mediatype:audio{1}".format(query, lic_clause),
        "fl[]":    ["identifier", "title", "creator", "downloads"],
        "sort[]":  ["{0} desc".format(sort)],
        "rows":    rows,
        "page":    1,
        "output":  "json",
    }
    try:
        headers = {"User-Agent": "EspaTV/1.0 (Kodi addon; musica libre CC)"}
        resp = requests.get(_ARCHIVE_SEARCH, params=params, headers=headers, timeout=_TIMEOUT)
        resp.raise_for_status()
        docs = resp.json().get("response", {}).get("docs", [])
        _save_cache(cache_key, docs)
        return docs
    except Exception as e:
        xbmc.log("{0} Error Archive search: {1}".format(_LOG, e), xbmc.LOGERROR)
        return []


def _resolve_archive_mp3(identifier):
    """Devuelve la URL del primer MP3 disponible en el item de Archive.org."""
    cache_key = "archive_meta_{0}".format(identifier)
    cached = _load_cache(cache_key)
    if cached is not None:
        return cached

    try:
        url = _ARCHIVE_META.format(identifier=urllib.parse.quote(identifier, safe=""))
        headers = {"User-Agent": "EspaTV/1.0"}
        resp = requests.get(url, headers=headers, timeout=_TIMEOUT)
        resp.raise_for_status()
        files = resp.json().get("files", [])
        # Preferir 64Kbps o 128Kbps MP3 sobre VBR para compatibilidad Kodi
        for fmt in ("64Kbps MP3", "128Kbps MP3", "VBR MP3", "MP3"):
            for f in files:
                if f.get("format") == fmt and f.get("name", "").endswith(".mp3"):
                    audio_url = "https://archive.org/download/{0}/{1}".format(
                        identifier, urllib.parse.quote(f["name"])
                    )
                    _save_cache(cache_key, audio_url)
                    return audio_url
        # Fallback: cualquier .mp3
        for f in files:
            if f.get("name", "").lower().endswith(".mp3"):
                audio_url = "https://archive.org/download/{0}/{1}".format(
                    identifier, urllib.parse.quote(f["name"])
                )
                _save_cache(cache_key, audio_url)
                return audio_url
    except Exception as e:
        xbmc.log("{0} Error Archive meta {1}: {2}".format(_LOG, identifier, e), xbmc.LOGERROR)
    return None


# API de Radio Browser

def _fetch_radio(country=None, tag=None, limit=50):
    cache_key = "radio_{0}_{1}".format(country or "all", tag or "all")
    cached = _load_cache(cache_key)
    if cached is not None:
        return cached

    params = {
        "hidebroken": "true",
        "limit":      limit,
        "order":      "clickcount",
        "reverse":    "true",
    }
    if country:
        params["countrycode"] = country
    if tag:
        params["tag"] = tag

    try:
        headers = {"User-Agent": "EspaTV/1.0 (Kodi addon; radio browser)"}
        resp = requests.get(_RADIO_API, params=params, headers=headers, timeout=_TIMEOUT)
        resp.raise_for_status()
        stations = resp.json()
        _save_cache(cache_key, stations)
        return stations
    except Exception as e:
        xbmc.log("{0} Error radio: {1}".format(_LOG, e), xbmc.LOGERROR)
        return []


# Menús

def musica_libre_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_musica_libre.png")

    li_cc = xbmcgui.ListItem(label="[B][COLOR gold]Musica Creative Commons[/COLOR][/B]")
    li_cc.setArt({"icon": icon})
    li_cc.setInfo("video", {"plot": "Musica con licencia Creative Commons. Libre y gratuita."})
    li_cc.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="musica_archive_menu"), listitem=li_cc, isFolder=True)

    li_radio = xbmcgui.ListItem(label="[B][COLOR deepskyblue]Radio Online Libre[/COLOR][/B]")
    li_radio.setArt({"icon": icon})
    li_radio.setInfo("video", {"plot": "Miles de emisoras de radio online de todo el mundo. Sin registro."})
    li_radio.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="musica_radio_menu"), listitem=li_radio, isFolder=True)

    li_bso = xbmcgui.ListItem(label="[B][COLOR khaki]Bandas Sonoras Cine Español[/COLOR][/B]")
    li_bso.setArt({"icon": _icon("cat_bso.png", "DefaultAudio.png")})
    li_bso.setInfo("video", {"plot": "Piezas musicales de películas clásicas españolas (dominio público).\nSara Montiel, Lola Flores, Imperio Argentina y más."})
    li_bso.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="bso_menu"), listitem=li_bso, isFolder=True)

    li_bso_libre = xbmcgui.ListItem(label="[B][COLOR orange]Bandas Sonoras Cine (Dominio Público)[/COLOR][/B]")
    li_bso_libre.setArt({"icon": _icon("cat_bso.png", "DefaultAudio.png")})
    li_bso_libre.setInfo("video", {"plot": "Bandas sonoras de películas internacionales libres de derechos.\nCine mudo, Hollywood clásico, terror, aventura y más. Vía Archive.org."})
    li_bso_libre.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="bso_libre_menu"), listitem=li_bso_libre, isFolder=True)

    xbmcplugin.endOfDirectory(h)


def archive_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_musica_libre.png")

    li_top = xbmcgui.ListItem(label="[B][COLOR gold]Mas Populares[/COLOR][/B]")
    li_top.setArt({"icon": icon})
    li_top.setInfo("video", {"plot": "Audios CC mas descargados."})
    li_top.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="musica_archive_lista", query="music", sort="downloads", titulo="Mas Populares"),
        listitem=li_top, isFolder=True,
    )

    li_new = xbmcgui.ListItem(label="[B][COLOR deepskyblue]Novedades[/COLOR][/B]")
    li_new.setArt({"icon": icon})
    li_new.setInfo("video", {"plot": "Ultimas subidas con licencia CC."})
    li_new.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="musica_archive_lista", query="music", sort="publicdate", titulo="Novedades"),
        listitem=li_new, isFolder=True,
    )

    sep = xbmcgui.ListItem(label="[COLOR grey]──  Por genero  ──[/COLOR]")
    sep.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=sep, isFolder=False)

    for titulo, tag in _GENEROS_ARCHIVE:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(titulo))
        li.setArt({"icon": icon})
        li.setInfo("video", {"plot": "Musica {0} con licencia CC.".format(titulo)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="musica_archive_lista", query="subject:{0}".format(tag), sort="downloads", titulo=titulo),
            listitem=li, isFolder=True,
        )

    xbmcplugin.endOfDirectory(h)


def archive_lista(query, sort, titulo):
    h = int(sys.argv[1])
    if titulo:
        xbmcplugin.setPluginCategory(h, titulo)
    xbmcgui.Dialog().notification("Musica CC", "Buscando música…", xbmcgui.NOTIFICATION_INFO, 1500)

    docs = _fetch_archive(query, sort)

    if not docs:
        li = xbmcgui.ListItem(label="[COLOR grey]Sin resultados[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for doc in docs:
        identifier = doc.get("identifier", "")
        if not identifier:
            continue
        track_title  = doc.get("title", identifier)
        creator      = doc.get("creator", "")
        downloads    = doc.get("downloads", 0)
        thumb        = "https://archive.org/services/img/{0}".format(identifier)

        label = "[B]{0}[/B]".format(track_title)
        if creator:
            label += "  [COLOR grey]{0}[/COLOR]".format(creator)

        plot = "{0}".format(track_title)
        if creator:
            plot += "\nArtista: {0}".format(creator)
        if downloads:
            plot += "\nDescargas: {0}".format(downloads)
        plot += "\nFuente: Música CC"

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": thumb, "thumb": thumb})
        li.setInfo("music", {"title": track_title, "artist": creator})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="musica_archive_play", identifier=identifier, titulo=track_title),
            listitem=li, isFolder=False,
        )

    xbmcplugin.endOfDirectory(h)


def archive_play(identifier, titulo):
    h = int(sys.argv[1])
    xbmcgui.Dialog().notification("Musica CC", "Resolviendo audio…", xbmcgui.NOTIFICATION_INFO, 1200)
    audio_url = _resolve_archive_mp3(identifier)
    if not audio_url:
        xbmcgui.Dialog().ok("Musica Libre", "No se encontro audio MP3 para este item.\nPrueba con otro.")
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return
    li = xbmcgui.ListItem(titulo or identifier, path=audio_url)
    li.setInfo("music", {"title": titulo or identifier})
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(h, True, li)


# API de Radio Browser

def radio_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_musica_libre.png")

    li_top = xbmcgui.ListItem(label="[B][COLOR gold]Top 50 Mundial[/COLOR][/B]")
    li_top.setArt({"icon": icon})
    li_top.setInfo("video", {"plot": "Las 50 emisoras mas escuchadas del mundo."})
    li_top.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="musica_radio_lista", country="", tag="", titulo="Top 50 Mundial"),
        listitem=li_top, isFolder=True,
    )

    sep_paises = xbmcgui.ListItem(label="[COLOR grey]──  Por pais  ──[/COLOR]")
    sep_paises.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=sep_paises, isFolder=False)

    for code, nombre in _PAISES_RADIO:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(nombre))
        li.setArt({"icon": icon})
        li.setInfo("video", {"plot": "Emisoras de radio de {0}.".format(nombre)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="musica_radio_lista", country=code, tag="", titulo=nombre),
            listitem=li, isFolder=True,
        )

    sep_gen = xbmcgui.ListItem(label="[COLOR grey]──  Por genero  ──[/COLOR]")
    sep_gen.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=sep_gen, isFolder=False)

    for tag, nombre in _GENEROS_RADIO:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(nombre))
        li.setArt({"icon": icon})
        li.setInfo("video", {"plot": "Emisoras de radio de genero {0}.".format(nombre)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="musica_radio_lista", country="", tag=tag, titulo=nombre),
            listitem=li, isFolder=True,
        )

    xbmcplugin.endOfDirectory(h)


def radio_lista(country, tag, titulo):
    h = int(sys.argv[1])
    if titulo:
        xbmcplugin.setPluginCategory(h, titulo)
    xbmcgui.Dialog().notification("Radio Online", "Buscando emisoras…", xbmcgui.NOTIFICATION_INFO, 1500)

    stations = _fetch_radio(country=country or None, tag=tag or None)
    icon = _icon("cat_musica_libre.png")

    if not stations:
        li = xbmcgui.ListItem(label="[COLOR grey]Sin emisoras disponibles[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for st in stations:
        nombre   = st.get("name", "")
        url_st   = st.get("url_resolved") or st.get("url", "")
        pais     = st.get("country", "")
        tags_str = st.get("tags", "")
        favicon  = st.get("favicon", "") or icon
        bitrate  = st.get("bitrate", 0)

        if not url_st or not nombre:
            continue

        label = "[B]{0}[/B]".format(nombre)
        if pais:
            label += "  [COLOR grey]{0}[/COLOR]".format(pais)

        plot = nombre
        if pais:
            plot += "\nPais: {0}".format(pais)
        if tags_str:
            plot += "\nGeneros: {0}".format(tags_str[:80])
        if bitrate:
            plot += "\nBitrate: {0} kbps".format(bitrate)

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": favicon, "thumb": favicon})
        li.setInfo("music", {"title": nombre, "album": pais})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="musica_radio_play", url=url_st, nombre=nombre),
            listitem=li, isFolder=False,
        )

    xbmcplugin.endOfDirectory(h)


def radio_play(url, nombre):
    h = int(sys.argv[1])
    if not url:
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return
    li = xbmcgui.ListItem(nombre or url, path=url)
    li.setInfo("music", {"title": nombre or url})
    li.setProperty("IsPlayable", "true")
    xbmcplugin.setResolvedUrl(h, True, li)


# BSO libres (Archive.org)

def bso_libre_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_bso.png", "DefaultAudio.png")

    xbmcplugin.setPluginCategory(h, "Bandas Sonoras Cine (Libre)")

    for titulo, query, sort, lic in _BSO_LIBRE_CATEGORIAS:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(titulo))
        li.setArt({"icon": icon})
        li.setInfo("video", {"plot": "Bandas sonoras libres de derechos — {0}".format(titulo)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="bso_libre_lista", query=query, sort=sort,
                   titulo=titulo, lic=(lic or "")),
            listitem=li, isFolder=True,
        )

    xbmcplugin.endOfDirectory(h)


def bso_libre_lista(query, sort, titulo, lic):
    h = int(sys.argv[1])

    # Búsqueda interactiva
    if query == "__SEARCH__":
        kb = xbmc.Keyboard("", "Buscar bandas sonoras")
        kb.doModal()
        if not kb.isConfirmed() or not kb.getText().strip():
            xbmcplugin.endOfDirectory(h)
            return
        term = kb.getText().strip()
        # Sanear término: comillas dobles solo, escapar caracteres conflictivos de Lucene
        safe = term.replace('"', '').replace('(', '').replace(')', '')
        query = '("{0}" AND (subject:"soundtrack" OR title:"soundtrack" OR title:"score" OR subject:"film score"))'.format(safe)
        titulo = "Búsqueda: {0}".format(term)

    if titulo:
        xbmcplugin.setPluginCategory(h, titulo)
    xbmcgui.Dialog().notification("BSO Libre", "Buscando bandas sonoras…", xbmcgui.NOTIFICATION_INFO, 1500)

    license_filter = lic if lic in ("cc", "cc_pd") else None
    docs = _fetch_archive(query, sort, license_filter=license_filter)

    if not docs:
        li = xbmcgui.ListItem(label="[COLOR grey]Sin resultados[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    for doc in docs:
        identifier = doc.get("identifier", "")
        if not identifier:
            continue
        track_title = doc.get("title", identifier)
        creator     = doc.get("creator", "")
        downloads   = doc.get("downloads", 0)
        thumb       = "https://archive.org/services/img/{0}".format(identifier)

        label = "[B]{0}[/B]".format(track_title)
        if creator:
            label += "  [COLOR grey]{0}[/COLOR]".format(creator)

        plot = track_title
        if creator:
            plot += "\nAutor: {0}".format(creator)
        if downloads:
            plot += "\nDescargas: {0}".format(downloads)
        plot += "\nFuente: Archive.org (libre de derechos)"

        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": thumb, "thumb": thumb})
        li.setInfo("music", {"title": track_title, "artist": creator})
        li.setProperty("IsPlayable", "true")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="musica_archive_play", identifier=identifier, titulo=track_title),
            listitem=li, isFolder=False,
        )

    xbmcplugin.endOfDirectory(h)
