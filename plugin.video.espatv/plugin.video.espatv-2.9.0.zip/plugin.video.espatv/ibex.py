# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Cotizaciones del IBEX 35, S&P 500 y criptomonedas desde Yahoo Finance."""
import datetime
import json
import os
import sys
import time
import urllib.parse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from _user_agents import UA_DESKTOP

_CHART_URL = "https://query1.finance.yahoo.com/v8/finance/chart/{symbol}"
_QUOTE_URL = "https://query1.finance.yahoo.com/v7/finance/quote"
_HEADERS = {'User-Agent': UA_DESKTOP, 'Accept': 'application/json'}
_HTTP_TIMEOUT = 15
_QUOTE_TIMEOUT = 20

_PROFILE = xbmcvfs.translatePath(
    xbmcaddon.Addon("plugin.video.espatv").getAddonInfo('profile')
)
_CACHE_FILE       = os.path.join(_PROFILE, 'ibex_cache.json')
_SP500_CACHE_FILE = os.path.join(_PROFILE, 'sp500_cache.json')
_CRYPTO_CACHE_FILE= os.path.join(_PROFILE, 'crypto_cache.json')
_CACHE_TTL = 300

_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'media')


def _icon(name, fallback='DefaultIconInfo.png'):
    p = os.path.join(_MEDIA, name)
    return p if os.path.exists(p) else fallback


_INDEX_SYMBOL       = "^IBEX"
_SP500_INDEX_SYMBOL = "^GSPC"
_HISTORICO_RANGE    = "1mo"
_HISTORICO_LIMIT    = 25

# Componentes IBEX 35. Formato: (ticker, símbolo Yahoo Finance, nombre)
_IBEX_35 = (
    ("ACS",   "ACS.MC",   "ACS Construcciones"),
    ("ACX",   "ACX.MC",   "Acerinox"),
    ("AENA",  "AENA.MC",  "Aena"),
    ("AMS",   "AMS.MC",   "Amadeus IT Group"),
    ("ANA",   "ANA.MC",   "Acciona"),
    ("BBVA",  "BBVA.MC",  "BBVA"),
    ("BKT",   "BKT.MC",   "Bankinter"),
    ("CABK",  "CABK.MC",  "CaixaBank"),
    ("CLNX",  "CLNX.MC",  "Cellnex Telecom"),
    ("COL",   "COL.MC",   "Colonial"),
    ("ELE",   "ELE.MC",   "Endesa"),
    ("ENG",   "ENG.MC",   "Enagás"),
    ("FDR",   "FDR.MC",   "Fluidra"),
    ("FER",   "FER.MC",   "Ferrovial"),
    ("GRF",   "GRF.MC",   "Grifols"),
    ("IAG",   "IAG.MC",   "IAG (Iberia)"),
    ("IBE",   "IBE.MC",   "Iberdrola"),
    ("IDR",   "IDR.MC",   "Indra"),
    ("ITX",   "ITX.MC",   "Inditex"),
    ("LOG",   "LOG.MC",   "Logista"),
    ("MAP",   "MAP.MC",   "Mapfre"),
    ("MEL",   "MEL.MC",   "Meliá Hotels"),
    ("MRL",   "MRL.MC",   "Merlin Properties"),
    ("MTS",   "MTS.MC",   "ArcelorMittal"),
    ("NTGY",  "NTGY.MC",  "Naturgy"),
    ("PUIG",  "PUIG.MC",  "Puig"),
    ("RED",   "RED.MC",   "Redeia (REE)"),
    ("REP",   "REP.MC",   "Repsol"),
    ("ROVI",  "ROVI.MC",  "Laboratorios Rovi"),
    ("SAB",   "SAB.MC",   "Banco Sabadell"),
    ("SAN",   "SAN.MC",   "Banco Santander"),
    ("SCYR",  "SCYR.MC",  "Sacyr"),
    ("SLR",   "SLR.MC",   "Solaria"),
    ("TEF",   "TEF.MC",   "Telefónica"),
    ("UNI",   "UNI.MC",   "Unicaja Banco"),
)

# Top valores del S&P 500 (por capitalización bursátil)
_SP500_TOP = (
    ("AAPL",  "AAPL",  "Apple"),
    ("MSFT",  "MSFT",  "Microsoft"),
    ("NVDA",  "NVDA",  "NVIDIA"),
    ("AMZN",  "AMZN",  "Amazon"),
    ("GOOGL", "GOOGL", "Alphabet (Class A)"),
    ("META",  "META",  "Meta Platforms"),
    ("TSLA",  "TSLA",  "Tesla"),
    ("BRK-B", "BRK-B", "Berkshire Hathaway"),
    ("LLY",   "LLY",   "Eli Lilly"),
    ("JPM",   "JPM",   "JPMorgan Chase"),
    ("V",     "V",     "Visa"),
    ("XOM",   "XOM",   "ExxonMobil"),
    ("UNH",   "UNH",   "UnitedHealth"),
    ("MA",    "MA",    "Mastercard"),
    ("AVGO",  "AVGO",  "Broadcom"),
    ("PG",    "PG",    "Procter & Gamble"),
    ("HD",    "HD",    "Home Depot"),
    ("JNJ",   "JNJ",   "Johnson & Johnson"),
    ("MRK",   "MRK",   "Merck"),
    ("COST",  "COST",  "Costco"),
    ("ABBV",  "ABBV",  "AbbVie"),
    ("PEP",   "PEP",   "PepsiCo"),
    ("KO",    "KO",    "Coca-Cola"),
    ("ADBE",  "ADBE",  "Adobe"),
    ("WMT",   "WMT",   "Walmart"),
    ("CRM",   "CRM",   "Salesforce"),
    ("AMD",   "AMD",   "Advanced Micro Devices"),
    ("NFLX",  "NFLX",  "Netflix"),
    ("ORCL",  "ORCL",  "Oracle"),
    ("BAC",   "BAC",   "Bank of America"),
)

# Criptomonedas top (por capitalización). Formato: (ticker, símbolo Yahoo XXX-USD, nombre)
_CRYPTO = (
    ("BTC",   "BTC-USD",  "Bitcoin"),
    ("ETH",   "ETH-USD",  "Ethereum"),
    ("USDT",  "USDT-USD", "Tether"),
    ("BNB",   "BNB-USD",  "BNB"),
    ("SOL",   "SOL-USD",  "Solana"),
    ("XRP",   "XRP-USD",  "XRP"),
    ("USDC",  "USDC-USD", "USD Coin"),
    ("ADA",   "ADA-USD",  "Cardano"),
    ("DOGE",  "DOGE-USD", "Dogecoin"),
    ("AVAX",  "AVAX-USD", "Avalanche"),
    ("DOT",   "DOT-USD",  "Polkadot"),
    ("TRX",   "TRX-USD",  "Tron"),
    ("LINK",  "LINK-USD", "Chainlink"),
    ("MATIC", "MATIC-USD","Polygon"),
    ("LTC",   "LTC-USD",  "Litecoin"),
)


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


def _load_cache(cache_file=None):
    cf = cache_file if cache_file is not None else _CACHE_FILE
    try:
        with open(cf, 'r', encoding='utf-8') as f:
            obj = json.load(f)
    except (OSError, ValueError):
        return None
    if (time.time() - obj.get('ts', 0)) >= _CACHE_TTL:
        return None
    return obj.get('data')


def _save_cache(data, cache_file=None):
    cf = cache_file if cache_file is not None else _CACHE_FILE
    try:
        if not os.path.isdir(_PROFILE):
            os.makedirs(_PROFILE, exist_ok=True)
        with open(cf, 'w', encoding='utf-8') as f:
            json.dump({'ts': time.time(), 'data': data}, f, ensure_ascii=False)
    except OSError:
        pass


def _fetch_chart(symbol, interval="1d", chart_range="5d"):
    try:
        r = requests.get(
            _CHART_URL.format(symbol=symbol),
            params={'interval': interval, 'range': chart_range},
            headers=_HEADERS, timeout=_HTTP_TIMEOUT,
        )
        if r.status_code != 200:
            return None
        return r.json()
    except (requests.RequestException, ValueError):
        return None


def _extract_quote(chart_json):
    if not chart_json:
        return None
    result = (chart_json.get('chart') or {}).get('result') or []
    if not result:
        return None
    meta = result[0].get('meta') or {}
    return {
        'price': meta.get('regularMarketPrice'),
        'prev_close': meta.get('chartPreviousClose') or meta.get('previousClose'),
        'open': meta.get('regularMarketOpen'),
        'high': meta.get('regularMarketDayHigh'),
        'low':  meta.get('regularMarketDayLow'),
        'volume': meta.get('regularMarketVolume'),
        'fifty_two_week_high': meta.get('fiftyTwoWeekHigh'),
        'fifty_two_week_low':  meta.get('fiftyTwoWeekLow'),
        'currency': meta.get('currency') or 'EUR',
        'symbol': meta.get('symbol') or '',
        'exchange': meta.get('exchangeName') or meta.get('fullExchangeName') or '',
        'long_name': meta.get('longName') or meta.get('shortName') or '',
        'market_time': meta.get('regularMarketTime'),
    }


def _fmt_es_number(value, decimals=2, sign=False):
    """Formato europeo: miles con punto, decimales con coma."""
    if value is None:
        return "-"
    fmt = "{0:+,.{1}f}" if sign else "{0:,.{1}f}"
    raw = fmt.format(value, decimals)
    return raw.translate(str.maketrans({',': '.', '.': ','}))


def _fmt_price(value, currency="EUR"):
    if value is None:
        return "-"
    suffix = " €" if currency == "EUR" else " " + currency
    return _fmt_es_number(value, 2) + suffix


def _fmt_volume(v):
    try:
        v = float(v)
    except (TypeError, ValueError):
        return "-"
    if v >= 1_000_000_000:
        return _fmt_es_number(v / 1_000_000_000.0, 2) + " mil M"
    if v >= 1_000_000:
        return _fmt_es_number(v / 1_000_000.0, 2) + " M"
    if v >= 1_000:
        return _fmt_es_number(v / 1_000.0, 1) + " K"
    return _fmt_es_number(v, 0)


def _fmt_market_cap(v, currency="EUR"):
    try:
        v = float(v)
    except (TypeError, ValueError):
        return "-"
    suffix = " €" if currency == "EUR" else " " + currency
    if v >= 1_000_000_000_000:
        return _fmt_es_number(v / 1_000_000_000_000.0, 2) + " bn" + suffix
    if v >= 1_000_000_000:
        return _fmt_es_number(v / 1_000_000_000.0, 2) + " mil M" + suffix
    if v >= 1_000_000:
        return _fmt_es_number(v / 1_000_000.0, 1) + " M" + suffix
    return _fmt_es_number(v, 0) + suffix


def _fmt_ts(ts):
    try:
        return datetime.datetime.fromtimestamp(int(ts)).strftime("%d/%m/%Y %H:%M:%S")
    except (TypeError, ValueError, OSError):
        return ""


def _color_for_change(change):
    if change is None:
        return "white"
    if change > 0:
        return "lightgreen"
    if change < 0:
        return "lightcoral"
    return "white"


def _arrow_for_change(change):
    if change is None:
        return ""
    if change > 0:
        return "▲"
    if change < 0:
        return "▼"
    return "·"


def _change_label(change_abs, change_pct):
    if change_abs is None or change_pct is None:
        return ""
    color = _color_for_change(change_abs)
    arrow = _arrow_for_change(change_abs)
    return " [COLOR {0}]{1} {2} ({3}%)[/COLOR]".format(
        color, arrow,
        _fmt_es_number(change_abs, 2, sign=True),
        _fmt_es_number(change_pct, 2, sign=True),
    )


def _pct_label(change_pct):
    if change_pct is None:
        return ""
    color = _color_for_change(change_pct)
    arrow = _arrow_for_change(change_pct)
    return " [COLOR {0}]{1} {2}%[/COLOR]".format(
        color, arrow, _fmt_es_number(change_pct, 2, sign=True),
    )


def _change_from_quote(quote):
    price = quote.get('price')
    prev = quote.get('prev_close')
    if price is None or not prev:
        return None, None
    abs_change = price - prev
    pct_change = abs_change / prev * 100.0
    return abs_change, pct_change


def _add_static(handle, label, plot=""):
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': 'DefaultIconInfo.png'})
    li.setProperty("IsPlayable", "false")
    if plot:
        li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(
        handle=handle, url=_u(action="noop"), listitem=li, isFolder=False,
    )


def _add_timestamp_item(handle, ts, prefix="Última cotización"):
    label = _fmt_ts(ts)
    if not label:
        return
    li = xbmcgui.ListItem(
        label="[B][COLOR lightgray]{0}: {1}[/COLOR][/B]".format(prefix, label)
    )
    li.setArt({'icon': _icon('adv_cache.png')})
    li.setProperty("IsPlayable", "false")
    li.setInfo('video', {'plot': "Hora del último dato proporcionado por la fuente (Yahoo Finance)."})
    xbmcplugin.addDirectoryItem(
        handle=handle, url=_u(action="noop"), listitem=li, isFolder=False,
    )


def _load_cache_ts(cache_file):
    try:
        with open(cache_file, 'r', encoding='utf-8') as f:
            return int(json.load(f).get('ts', 0))
    except (OSError, ValueError):
        return 0


def _add_folder(handle, label, action, plot="", icon="DefaultIconInfo.png"):
    li = xbmcgui.ListItem(label=label)
    li.setArt({'icon': icon})
    if plot:
        li.setInfo('video', {'plot': plot})
    xbmcplugin.addDirectoryItem(
        handle=handle, url=_u(action=action), listitem=li, isFolder=True,
    )


def _historico_rows(chart_json):
    if not chart_json:
        return []
    result = (chart_json.get('chart') or {}).get('result') or []
    if not result:
        return []
    timestamps = result[0].get('timestamp') or []
    quote_block = ((result[0].get('indicators') or {}).get('quote') or [{}])[0]
    closes = quote_block.get('close') or []
    opens = quote_block.get('open') or []

    rows = []
    for ts, op, cl in zip(timestamps, opens, closes):
        if cl is None:
            continue
        date = datetime.datetime.fromtimestamp(ts).strftime("%d/%m/%Y")
        if op is None or op == 0:
            pct = None
        else:
            pct = (cl - op) / op * 100.0
        rows.append({'date': date, 'close': cl, 'pct': pct})
    rows.reverse()
    return rows


def _bulk_quotes(symbols):
    if not symbols:
        return {}
    try:
        r = requests.get(
            _QUOTE_URL,
            params={'symbols': ",".join(symbols)},
            headers=_HEADERS, timeout=_QUOTE_TIMEOUT,
        )
        if r.status_code != 200:
            return {}
        payload = r.json()
    except (requests.RequestException, ValueError):
        return {}
    out = {}
    for q in (payload.get('quoteResponse') or {}).get('result') or []:
        sym = q.get('symbol')
        if not sym:
            continue
        out[sym] = {
            'price': q.get('regularMarketPrice'),
            'pct': q.get('regularMarketChangePercent'),
            'change': q.get('regularMarketChange'),
            'currency': q.get('currency') or 'USD',
            'open': q.get('regularMarketOpen'),
            'prev_close': q.get('regularMarketPreviousClose'),
            'high': q.get('regularMarketDayHigh'),
            'low': q.get('regularMarketDayLow'),
            'volume': q.get('regularMarketVolume'),
            'market_cap': q.get('marketCap'),
            'fifty_two_week_high': q.get('fiftyTwoWeekHigh'),
            'fifty_two_week_low':  q.get('fiftyTwoWeekLow'),
            'pe_trailing': q.get('trailingPE'),
            'dividend_yield': q.get('trailingAnnualDividendYield'),
            'long_name': q.get('longName') or q.get('shortName') or '',
            'exchange': q.get('fullExchangeName') or q.get('exchange') or '',
            'market_time': q.get('regularMarketTime'),
        }
    return out


def _per_symbol_quotes(symbols, progress=None):
    """Fallback: una llamada chart por símbolo. Honra cancelación del progress."""
    out = {}
    total = len(symbols)
    for idx, sym in enumerate(symbols):
        if progress is not None and progress.iscanceled():
            break
        if progress is not None:
            pct = int(idx * 100 / total) if total else 0
            progress.update(pct, "Consultando {0} ({1}/{2})...".format(sym, idx + 1, total))
        quote = _extract_quote(_fetch_chart(sym, chart_range="2d"))
        if not quote:
            continue
        price = quote.get('price')
        prev = quote.get('prev_close')
        pct_change = (price - prev) / prev * 100.0 if (price is not None and prev) else None
        out[sym] = {
            'price': price,
            'pct': pct_change,
            'currency': quote.get('currency') or 'USD',
            'open': quote.get('open'),
            'prev_close': prev,
            'high': quote.get('high'),
            'low': quote.get('low'),
            'volume': quote.get('volume'),
            'fifty_two_week_high': quote.get('fifty_two_week_high'),
            'fifty_two_week_low':  quote.get('fifty_two_week_low'),
            'long_name': quote.get('long_name') or '',
            'exchange': quote.get('exchange') or '',
            'market_time': quote.get('market_time'),
        }
    return out




def _market_menu(handle, title, index_symbol, cache_file,
                 refresh_action, historico_action, empresas_action,
                 extra_folders=None):
    li_r = xbmcgui.ListItem(label="[B][COLOR aqua][ Refrescar datos ][/COLOR][/B]")
    li_r.setArt({'icon': _icon('adv_refrescar.png')})
    li_r.setProperty("IsPlayable", "false")
    li_r.setInfo('video', {'plot': "Borra la caché y recarga los datos de mercado."})
    xbmcplugin.addDirectoryItem(handle=handle, url=_u(action=refresh_action),
                                listitem=li_r, isFolder=False)

    quote = _load_cache(cache_file)
    if quote is None:
        quote = _extract_quote(_fetch_chart(index_symbol))
        if quote:
            _save_cache(quote, cache_file)

    if not quote:
        xbmcgui.Dialog().notification(
            "EspaTV", "No se pudo obtener cotización de {0}".format(title),
            xbmcgui.NOTIFICATION_WARNING, 3000,
        )
        xbmcplugin.endOfDirectory(handle)
        return

    currency = quote.get('currency') or ('USD' if '-USD' in index_symbol else 'EUR')
    abs_change, pct_change = _change_from_quote(quote)
    label = "[B][COLOR royalblue]{0}[/COLOR][/B]  {1}{2}".format(
        title, _fmt_price(quote.get('price'), currency),
        _change_label(abs_change, pct_change),
    )
    plot_lines = ["{0} — Cotización actual".format(title)]
    plot_lines.append("Precio: {0}".format(_fmt_price(quote.get('price'), currency)))
    if quote.get('prev_close') is not None:
        plot_lines.append("Cierre anterior: {0}".format(_fmt_price(quote['prev_close'], currency)))
    if quote.get('high') is not None:
        plot_lines.append("Máx. día: {0}".format(_fmt_price(quote['high'], currency)))
    if quote.get('low') is not None:
        plot_lines.append("Mín. día: {0}".format(_fmt_price(quote['low'], currency)))
    _add_static(handle, label, "\n".join(plot_lines))

    # Timestamp: hora del último dato del mercado (o, en su defecto, hora de la caché)
    market_ts = quote.get('market_time') or _load_cache_ts(cache_file)
    _add_timestamp_item(handle, market_ts, "Última cotización")

    _add_folder(handle, "[B][COLOR khaki]Histórico (último mes)[/COLOR][/B]", historico_action,
                "Cierres diarios de {0} en el último mes.".format(title))
    _add_folder(handle, "[B][COLOR khaki]Componentes de {0}[/COLOR][/B]".format(title),
                empresas_action,
                "Cotizaciones de los componentes de {0}.".format(title))

    if extra_folders:
        for f_label, f_action, f_icon_name, f_plot in extra_folders:
            li = xbmcgui.ListItem(label=f_label)
            li.setArt({'icon': _icon(f_icon_name)})
            li.setInfo('video', {'plot': f_plot})
            xbmcplugin.addDirectoryItem(handle=handle, url=_u(action=f_action),
                                        listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(handle)


def _market_historico(handle, index_symbol, title="Histórico"):
    rows = _historico_rows(_fetch_chart(index_symbol, chart_range=_HISTORICO_RANGE))
    if not rows:
        xbmcgui.Dialog().notification(
            "EspaTV", "Sin datos históricos para {0}".format(title),
            xbmcgui.NOTIFICATION_WARNING, 2500,
        )
        xbmcplugin.endOfDirectory(handle)
        return
    currency = 'USD' if '-USD' in index_symbol else 'EUR'
    for row in rows[:_HISTORICO_LIMIT]:
        label = "[B]{0}[/B]  {1}{2}".format(
            row['date'], _fmt_price(row['close'], currency), _pct_label(row['pct']),
        )
        _add_static(handle, label)
    xbmcplugin.endOfDirectory(handle)


def _market_empresas(handle, members, title):
    symbols = [s[1] for s in members]
    quotes = _bulk_quotes(symbols)
    if not quotes:
        progress = xbmcgui.DialogProgress()
        progress.create("EspaTV", "Cargando cotizaciones de {0}...".format(title))
        try:
            quotes = _per_symbol_quotes(symbols, progress=progress)
        finally:
            progress.close()
    if not quotes:
        xbmcgui.Dialog().notification(
            "EspaTV", "No se pudieron obtener las cotizaciones",
            xbmcgui.NOTIFICATION_WARNING, 2500,
        )
        xbmcplugin.endOfDirectory(handle)
        return

    market_ts = 0
    for s in symbols:
        q = quotes.get(s) or {}
        if q.get('market_time'):
            market_ts = q['market_time']
            break
    _add_timestamp_item(handle, market_ts, "Última cotización")

    for ticker, symbol, name in members:
        q = quotes.get(symbol) or {}
        price = q.get('price')
        pct = q.get('pct')
        currency = q.get('currency') or ('USD' if symbol.endswith('-USD') else 'EUR')
        label = "[B]{0}[/B]  {1}  {2}{3}".format(
            ticker, name, _fmt_price(price, currency), _pct_label(pct),
        )
        plot_lines = [
            "{0} ({1})".format(name, ticker),
            "Precio: {0}".format(_fmt_price(price, currency)),
        ]
        if q.get('prev_close') is not None:
            plot_lines.append("Cierre anterior: {0}".format(_fmt_price(q['prev_close'], currency)))
        if q.get('high') is not None and q.get('low') is not None:
            plot_lines.append("Rango día: {0} – {1}".format(
                _fmt_price(q['low'], currency), _fmt_price(q['high'], currency),
            ))
        plot_lines.append("Pulsa para ver detalle completo.")

        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultIconInfo.png'})
        li.setInfo('video', {'plot': "\n".join(plot_lines)})
        xbmcplugin.addDirectoryItem(
            handle=handle,
            url=_u(action="market_detail", ticker=ticker, symbol=symbol, name=name),
            listitem=li, isFolder=True,
        )
    xbmcplugin.endOfDirectory(handle)


def _market_detail(handle, ticker, symbol, name):
    if not symbol:
        xbmcplugin.endOfDirectory(handle)
        return
    try:
        xbmcplugin.setPluginCategory(handle, "{0} — {1}".format(ticker or symbol, name or symbol))
    except Exception:
        pass

    quote = _extract_quote(_fetch_chart(symbol)) or {}
    bulk = _bulk_quotes([symbol]).get(symbol) or {}
    info = dict(quote)
    for k, v in bulk.items():
        if v is not None:
            info[k] = v

    if info.get('price') is None:
        xbmcgui.Dialog().notification(
            "EspaTV", "Sin datos para {0}".format(ticker or symbol),
            xbmcgui.NOTIFICATION_WARNING, 2500,
        )
        xbmcplugin.endOfDirectory(handle)
        return

    currency = info.get('currency') or ('USD' if symbol.endswith('-USD') else 'EUR')

    abs_change = info.get('change')
    pct_change = info.get('pct')
    if abs_change is None and info.get('price') is not None and info.get('prev_close'):
        abs_change = info['price'] - info['prev_close']
        pct_change = abs_change / info['prev_close'] * 100.0

    header_label = "[B][COLOR royalblue]{0}[/COLOR][/B]  {1}{2}".format(
        name or ticker or symbol,
        _fmt_price(info.get('price'), currency),
        _change_label(abs_change, pct_change),
    )
    header_plot = "{0} ({1})".format(name or ticker or symbol, ticker or symbol)
    if info.get('exchange'):
        header_plot += "\nMercado: {0}".format(info['exchange'])
    _add_static(handle, header_label, header_plot)

    _add_timestamp_item(handle, info.get('market_time'), "Última cotización")

    detail_rows = [
        ("Apertura",        _fmt_price(info.get('open'), currency)),
        ("Cierre anterior", _fmt_price(info.get('prev_close'), currency)),
        ("Máximo día",      _fmt_price(info.get('high'), currency)),
        ("Mínimo día",      _fmt_price(info.get('low'), currency)),
        ("Volumen",         _fmt_volume(info.get('volume'))),
        ("Máx. 52 semanas", _fmt_price(info.get('fifty_two_week_high'), currency)),
        ("Mín. 52 semanas", _fmt_price(info.get('fifty_two_week_low'), currency)),
    ]
    if info.get('market_cap') is not None:
        detail_rows.append(("Cap. mercado", _fmt_market_cap(info['market_cap'], currency)))
    if info.get('pe_trailing') is not None:
        detail_rows.append(("PER (trailing)", _fmt_es_number(info['pe_trailing'], 2)))
    if info.get('dividend_yield') is not None:
        detail_rows.append(("Rentab. dividendo",
                            _fmt_es_number(info['dividend_yield'] * 100, 2) + " %"))

    for k, v in detail_rows:
        _add_static(handle, "[B]{0}:[/B]  {1}".format(k, v))

    li_h = xbmcgui.ListItem(
        label="[B][COLOR khaki]» Histórico (último mes) — {0}[/COLOR][/B]".format(ticker or symbol)
    )
    li_h.setArt({'icon': _icon('cat_ibex.png')})
    li_h.setInfo('video', {'plot': "Cierres diarios de {0} en el último mes.".format(name or ticker or symbol)})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=_u(action="stock_historico", symbol=symbol, name=name or ticker or symbol),
        listitem=li_h, isFolder=True,
    )

    xbmcplugin.endOfDirectory(handle)


def _market_refresh(cache_file, menu_action):
    try:
        if os.path.exists(cache_file):
            os.remove(cache_file)
    except OSError:
        pass
    xbmcgui.Dialog().notification(
        "EspaTV", "Caché borrada — recargando…",
        xbmcgui.NOTIFICATION_INFO, 2000,
    )
    xbmc.executebuiltin("Container.Update({0})".format(_u(action=menu_action)))




def ibex_menu():
    _market_menu(
        int(sys.argv[1]), "IBEX 35", _INDEX_SYMBOL,
        _CACHE_FILE, "ibex_refresh", "ibex_historico", "ibex_empresas",
        extra_folders=[
            ("[B][COLOR skyblue]S&P 500[/COLOR][/B]",
             "sp500_menu", "cat_sp500.png",
             "Índice S&P 500 y principales valores estadounidenses."),
            ("[B][COLOR gold]Criptomonedas top[/COLOR][/B]",
             "crypto_menu", "cat_crypto.png",
             "Bitcoin, Ethereum y más criptomonedas por capitalización."),
        ],
    )


def ibex_historico():
    _market_historico(int(sys.argv[1]), _INDEX_SYMBOL, "IBEX 35")


def ibex_empresas():
    _market_empresas(int(sys.argv[1]), _IBEX_35, "IBEX 35")


def ibex_refresh():
    _market_refresh(_CACHE_FILE, "ibex_menu")


def sp500_menu():
    _market_menu(
        int(sys.argv[1]), "S&P 500", _SP500_INDEX_SYMBOL,
        _SP500_CACHE_FILE, "sp500_refresh", "sp500_historico", "sp500_empresas",
    )


def sp500_historico():
    _market_historico(int(sys.argv[1]), _SP500_INDEX_SYMBOL, "S&P 500")


def sp500_empresas():
    _market_empresas(int(sys.argv[1]), _SP500_TOP, "S&P 500")


def sp500_refresh():
    _market_refresh(_SP500_CACHE_FILE, "sp500_menu")


def crypto_menu():
    _market_menu(
        int(sys.argv[1]), "Criptomonedas", "BTC-USD",
        _CRYPTO_CACHE_FILE, "crypto_refresh", "crypto_historico", "crypto_empresas",
    )


def crypto_historico():
    _market_historico(int(sys.argv[1]), "BTC-USD", "Bitcoin (BTC)")


def crypto_empresas():
    _market_empresas(int(sys.argv[1]), _CRYPTO, "Criptomonedas")


def crypto_refresh():
    _market_refresh(_CRYPTO_CACHE_FILE, "crypto_menu")


def market_detail(ticker, symbol, name):
    _market_detail(int(sys.argv[1]), ticker, symbol, name)


def stock_historico(symbol, name=""):
    _market_historico(int(sys.argv[1]), symbol, name or symbol)
