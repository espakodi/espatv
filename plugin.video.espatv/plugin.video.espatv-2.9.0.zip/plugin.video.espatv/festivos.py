# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Festivos Nacionales y Autonómicos de España, calculados para cualquier año."""
import datetime
import sys
import urllib.parse
import os

import xbmcgui
import xbmcplugin

_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

# (mes, dia, nombre) — festivos nacionales de fecha fija
_NACIONALES_FIJOS = [
    (1,  1,  "Año Nuevo"),
    (1,  6,  "Epifanía del Señor — Reyes Magos"),
    (5,  1,  "Día del Trabajo"),
    (8,  15, "Asunción de la Virgen"),
    (10, 12, "Fiesta Nacional de España"),
    (11, 1,  "Todos los Santos"),
    (12, 6,  "Día de la Constitución Española"),
    (12, 8,  "Inmaculada Concepción"),
    (12, 25, "Natividad del Señor — Navidad"),
]

# (código, nombre, [(mes, dia, nombre), ...])
_CCAA_INFO = [
    ("AN", "Andalucía",             [(2, 28, "Día de Andalucía")]),
    ("AR", "Aragón",                [(4, 23, "Día de Aragón"), (10, 12, "Fiesta Nacional de España")]),
    ("AS", "Asturias",              [(9, 8,  "Día de Asturias")]),
    ("IB", "Islas Baleares",        [(3, 1,  "Día de las Islas Baleares")]),
    ("CN", "Canarias",              [(5, 30, "Día de Canarias")]),
    ("CB", "Cantabria",             [(8, 15, "Nuestra Señora La Virgen Grande")]),
    ("CM", "Castilla-La Mancha",    [(5, 31, "Día de Castilla-La Mancha")]),
    ("CL", "Castilla y León",       [(4, 23, "Día de Castilla y León")]),
    ("CT", "Cataluña",              [(9, 11, "Diada de Catalunya"), (6, 24, "Sant Joan")]),
    ("CE", "Ceuta",                 [(3, 5,  "Día de Ceuta")]),
    ("VC", "Comunitat Valenciana",  [(10, 9, "Día de la Comunitat Valenciana"), (3, 19, "San José / Las Fallas")]),
    ("EX", "Extremadura",           [(9, 8,  "Día de Extremadura")]),
    ("GA", "Galicia",               [(7, 25, "Día de Galicia"), (5, 17, "Día das Letras Galegas")]),
    ("RI", "La Rioja",              [(6, 9,  "Día de La Rioja")]),
    ("MD", "Comunidad de Madrid",   [(5, 2,  "Día de la Comunidad de Madrid"), (5, 15, "San Isidro")]),
    ("ML", "Melilla",               [(9, 17, "Día de Melilla")]),
    ("MU", "Región de Murcia",      [(6, 9,  "Día de la Región de Murcia")]),
    ("NC", "Navarra",               [(9, 27, "Día de Navarra"), (7, 7,  "San Fermín")]),
    ("PV", "País Vasco",            [(10, 25, "Día del País Vasco"), (7, 31, "San Ignacio de Loyola")]),
]

_DIAS_ES   = ["Lunes", "Martes", "Miércoles", "Jueves", "Viernes", "Sábado", "Domingo"]
_MESES_ES  = ["", "enero", "febrero", "marzo", "abril", "mayo", "junio",
              "julio", "agosto", "septiembre", "octubre", "noviembre", "diciembre"]


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _fecha_str(fecha):
    return f"{_DIAS_ES[fecha.weekday()]} {fecha.day} de {_MESES_ES[fecha.month]} de {fecha.year}"


def _pascua(year):
    """Domingo de Pascua gregoriano (algoritmo gregoriano anónimo, Butcher-Meeus)."""
    a = year % 19
    b, c = divmod(year, 100)
    d, e = divmod(b, 4)
    f = (b + 8) // 25
    g = (b - f + 1) // 3
    h = (19 * a + b - d - g + 15) % 30
    i, k = divmod(c, 4)
    L = (32 + 2 * e + 2 * i - h - k) % 7
    m = (a + 11 * h + 22 * L) // 451
    month, day = divmod(h + L - 7 * m + 114, 31)
    return datetime.date(year, month, day + 1)


def _nota_domingo(fecha):
    # El Art. 37.2 ET traslada al lunes el descanso, pero quien mueve el festivo en el
    # calendario es cada CCAA, no el Estado: por eso se avisa en vez de cambiar la fecha.
    if fecha.weekday() != 6:
        return ""
    lunes = fecha + datetime.timedelta(days=1)
    return ("Cae en domingo; tu comunidad autónoma puede trasladarlo al "
            f"lunes {lunes.day} de {_MESES_ES[lunes.month]}.")


def _nacionales(year):
    """Festivos nacionales del año: los de fecha fija más el Viernes Santo."""
    fechas = [(datetime.date(year, mes, dia), nombre) for mes, dia, nombre in _NACIONALES_FIJOS]
    fechas.append((_pascua(year) - datetime.timedelta(days=2), "Viernes Santo"))
    return sorted(fechas)


def _item(fecha, nombre, tipo):
    return {
        "nombre":    nombre,
        "fecha_str": _fecha_str(fecha),
        "days_left": (fecha - datetime.date.today()).days,
        "tipo":      tipo,
        "date":      fecha,
        "nota":      _nota_domingo(fecha),
    }


def _fundir_misma_fecha(items):
    """Un dia festivo, una fila.

    Hay comunidades cuyo festivo propio cae sobre uno nacional. Aragon repite el 12 de
    octubre con el mismo nombre, y Cantabria celebra la Virgen Grande el 15 de agosto,
    que ya es la Asuncion. Sin esto salen dos filas para un solo dia de fiesta.
    """
    por_fecha = {}
    for it in items:
        previo = por_fecha.get(it["date"])
        if previo is None:
            por_fecha[it["date"]] = it
            continue
        if it["nombre"] not in previo["nombre"]:
            previo["nombre"] += " / " + it["nombre"]
        # Que sea festivo en toda Espana manda sobre el matiz autonomico.
        if it["tipo"] == "nacional":
            previo["tipo"] = "nacional"
    return list(por_fecha.values())


def _build_items_zona(year, zona_code):
    items = [_item(fecha, nombre, "nacional") for fecha, nombre in _nacionales(year)]
    if zona_code != "ES":
        ccaa_extra = next((extras for code, _, extras in _CCAA_INFO if code == zona_code), [])
        items += [_item(datetime.date(year, mes, dia), nombre, "autonomico")
                  for mes, dia, nombre in ccaa_extra]
    items = _fundir_misma_fecha(items)
    items.sort(key=lambda x: x["date"])
    return items


def festivos_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_festivos.png")

    li_nac = xbmcgui.ListItem(label="[B][COLOR gold]Festivos Nacionales (toda España)[/COLOR][/B]")
    li_nac.setArt({"icon": icon})
    li_nac.setInfo("video", {"plot": "Festivos nacionales comunes a todo el territorio español."})
    li_nac.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="festivos_zona", zona="ES"),
                                listitem=li_nac, isFolder=True)

    for code, nombre, _ in _CCAA_INFO:
        li = xbmcgui.ListItem(label="[B][COLOR deepskyblue]{0}[/COLOR][/B]".format(nombre))
        li.setArt({"icon": icon})
        li.setInfo("video", {"plot": "Festivos nacionales mas los festivos propios de {0}.".format(nombre)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="festivos_zona", zona=code),
                                    listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def festivos_zona(zona_code):
    h = int(sys.argv[1])
    icon = _icon("cat_festivos.png")
    if zona_code == "ES":
        titulo = "Festivos Nacionales"
    else:
        titulo = next((nombre for code, nombre, _ in _CCAA_INFO if code == zona_code), zona_code)

    xbmcplugin.setPluginCategory(h, titulo)
    today = datetime.date.today()

    for year in (today.year, today.year + 1):
        sep = xbmcgui.ListItem(label=f"[COLOR gold]── Festivos {year} — {titulo} ──[/COLOR]")
        sep.setArt({"icon": icon})
        sep.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=sep, isFolder=False)

        for it in _build_items_zona(year, zona_code):
            days_left = it["days_left"]
            if days_left < 0:
                color = "grey"
                resta = "ya paso"
            elif days_left == 0:
                color = "tomato"
                resta = "HOY"
            else:
                resta = f"en {days_left} dia{'s' if days_left != 1 else ''}"
                if days_left <= 7:
                    color = "gold"
                elif days_left <= 30:
                    color = "khaki"
                else:
                    color = "white"

            tipo_str = ("[COLOR deepskyblue][nacional][/COLOR]" if it["tipo"] == "nacional"
                        else "[COLOR plum][autonomico][/COLOR]")
            marca = "   [COLOR grey](en domingo)[/COLOR]" if it["nota"] else ""
            label = (f"[B][COLOR {color}]{it['nombre']}[/COLOR][/B]   "
                     f"[COLOR grey]{it['fecha_str']}[/COLOR]   {tipo_str}{marca}")
            plot = f"{it['nombre']}\n{it['fecha_str']}\n{resta}\nFestivo {it['tipo']}"
            if it["nota"]:
                plot += f"\n\n{it['nota']}"
            li = xbmcgui.ListItem(label=label)
            li.setArt({"icon": icon})
            li.setInfo("video", {"title": it["nombre"], "plot": plot})
            li.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)
