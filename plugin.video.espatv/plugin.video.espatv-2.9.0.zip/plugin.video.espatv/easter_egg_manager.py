import os
import json
import xbmcgui
import xbmcvfs
import xbmcaddon

_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon("plugin.video.espatv").getAddonInfo('profile'))
_SAVE_FILE = os.path.join(_PROFILE, 'easter_eggs_found.json')

EASTER_EGGS = {
    "trololo":            "Trololo",
    "info_note":          "Never Gonna Give You Up",
    "caramelldansen":     "Caramelldansen",
    "nyan_cat":           "Nyan Cat",
    "money_money":        "Money Money Money",
    "keyboard_cat":       "Keyboard Cat",
    "video_killed_radio": "Video Killed the Radio Star",
    "universo":           "El secreto de EspaKodi",
}
TOTAL = len(EASTER_EGGS)
_VALID_IDS = set(EASTER_EGGS.keys())

_FINAL_MSG = (
    "¡Enhorabuena!\n\n"
    "Has encontrado los {total} Easter eggs de EspaTV.\n\n"
    "Eso merece algo especial:\n"
    "t.me/espakodivip"
).format(total=TOTAL)


def _load():
    try:
        with open(_SAVE_FILE, 'r', encoding='utf-8') as f:
            data = json.load(f)
        if not isinstance(data, list):
            return set()
        return set(data) & _VALID_IDS
    except Exception:
        return set()


def _save(found):
    try:
        if not os.path.isdir(_PROFILE):
            os.makedirs(_PROFILE, exist_ok=True)
        with open(_SAVE_FILE, 'w', encoding='utf-8') as f:
            json.dump(sorted(found), f, ensure_ascii=False)
    except Exception:
        pass


def trigger(egg_id):
    try:
        if egg_id not in _VALID_IDS:
            return
        found = _load()
        if egg_id in found:
            xbmcgui.Dialog().notification(
                "EspaTV", "Ya encontraste este Easter egg antes",
                xbmcgui.NOTIFICATION_INFO, 2500)
            return
        found.add(egg_id)
        _save(found)
        count = len(found)
        xbmcgui.Dialog().notification(
            "EspaTV",
            "Easter egg encontrado! {0} de {1}".format(count, TOTAL),
            xbmcgui.NOTIFICATION_INFO, 4000)
        if count >= TOTAL:
            xbmcgui.Dialog().ok("EspaTV — Todos los Easter eggs", _FINAL_MSG)
    except Exception:
        pass
