# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Astronomía y Cielos: submenú agregador de Fases Lunares y Calendario Astronómico."""
import os
import sys
import urllib.parse

import xbmcgui
import xbmcplugin

_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def menu():
    h = int(sys.argv[1])

    li1 = xbmcgui.ListItem(label="[B][COLOR deepskyblue]Fases Lunares[/COLOR][/B]")
    li1.setArt({"icon": _icon("cat_fases_luna.png")})
    li1.setInfo("video", {"plot": "Fase lunar actual y próximas 8 fases calculadas mediante el algoritmo de Meeus.\nCálculo local sin conexión a internet."})
    li1.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="fases_menu"), listitem=li1, isFolder=True)

    li2 = xbmcgui.ListItem(label="[B][COLOR gold]Calendario Astronómico Anual[/COLOR][/B]")
    li2.setArt({"icon": _icon("cat_calendario_astro.png")})
    li2.setInfo("video", {"plot": "Eclipses, lluvias de meteoros, equinoccios y solsticios del año actual.\nDatos del Real Observatorio de la Armada (ROA)."})
    li2.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="calendario_astro_menu"), listitem=li2, isFolder=True)

    xbmcplugin.endOfDirectory(h)
