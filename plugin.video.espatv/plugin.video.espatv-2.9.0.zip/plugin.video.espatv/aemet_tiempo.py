# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
import os
import json
import random
import threading
import time
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

try:
    import requests
except ImportError:
    requests = None


_ADDON = xbmcaddon.Addon()
_ADDON_PATH = os.path.dirname(os.path.abspath(__file__))
_PROFILE_DIR = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
_TEMP_DIR = xbmcvfs.translatePath("special://temp/")
_LOG_TAG = "[EspaTV-AEMET]"

_AEMET_XML_URL = "https://www.aemet.es/xml/municipios/localidad_{code}.xml"

# Nombre solo para la etiqueta del menú: al abrir, el nombre real lo trae el XML
# de AEMET. Los códigos sí deben existir en municipios_aemet.json (lo verifica un test).
_SAMPLE_CITIES = [
    ("Madrid (Madrid)", "28079"),
    ("Málaga (Málaga)", "29067"),
    ("Barcelona (Barcelona)", "08019"),
    ("Sevilla (Sevilla)", "41091"),
    ("València (Valencia/València)", "46250"),
    ("Bilbao (Bizkaia)", "48020"),
    ("Zaragoza (Zaragoza)", "50297"),
    ("Palma (Illes Balears)", "07040"),
    ("Las Palmas de Gran Canaria (Las Palmas)", "35016"),
    ("Santiago de Compostela (A Coruña)", "15078"),
]
_AEMET_ICON_URL = os.path.join(os.path.dirname(__file__), "resources", "weather", "{code}.png")
_MUNICIPIOS_FILE = os.path.join(_ADDON_PATH, "resources", "municipios_aemet.json")
_LOCATIONS_FILE = os.path.join(_PROFILE_DIR, "aemet_locations.json")
_CACHE_TTL_SECONDS = 45 * 60

# Mapa manual en lugar de unicodedata: algunas builds de Kodi (sobre todo en Android)
# distribuyen una stdlib recortada que no incluye los datos de normalización Unicode.
_ACCENT_MAP = {
    "á": "a", "é": "e", "í": "i", "ó": "o", "ú": "u",
    "ü": "u", "ñ": "n", "ç": "c",
    "Á": "A", "É": "E", "Í": "I", "Ó": "O", "Ú": "U",
    "Ü": "U", "Ñ": "N", "Ç": "C",
    "à": "a", "è": "e", "ì": "i", "ò": "o", "ù": "u",
    "À": "A", "È": "E", "Ì": "I", "Ò": "O", "Ù": "U",
}

_DIAS_SEMANA = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"]
_MESES = [
    "Ene", "Feb", "Mar", "Abr", "May", "Jun",
    "Jul", "Ago", "Sep", "Oct", "Nov", "Dic",
]

_WIND_DIRECTIONS = {
    "N": "Norte", "NE": "Noreste", "E": "Este", "SE": "Sureste",
    "S": "Sur", "SO": "Suroeste", "O": "Oeste", "NO": "Noroeste",
    "C": "Calma",
}


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("{tag} {msg}".format(tag=_LOG_TAG, msg=msg), level)


def _log_err(msg):
    _log(msg, xbmc.LOGERROR)


def normalize(text):
    return "".join(_ACCENT_MAP.get(c, c) for c in text).lower()


_municipios_cache = None


def _load_municipios():
    global _municipios_cache
    if _municipios_cache is not None:
        return _municipios_cache
    try:
        with open(_MUNICIPIOS_FILE, "r", encoding="utf-8") as fh:
            _municipios_cache = json.load(fh)
        _log("Municipios cargados: {0}".format(len(_municipios_cache)))
    except (OSError, ValueError) as exc:
        _log_err("Error cargando municipios: {0}".format(exc))
        _municipios_cache = {}
    return _municipios_cache


def search_municipios(query, limit=50):
    db = _load_municipios()
    if not query or not db:
        return []

    q = normalize(query.strip())
    if not q:
        return []

    starts = []
    contains = []

    for display_name, code in db.items():
        normalized = normalize(display_name)
        name_part = normalized.split(" (")[0] if " (" in normalized else normalized
        if name_part.startswith(q):
            starts.append((display_name, code))
        elif q in normalized:
            contains.append((display_name, code))

    starts.sort(key=lambda x: x[0])
    contains.sort(key=lambda x: x[0])
    return (starts + contains)[:limit]


def _extract_province(display_name):
    if " (" in display_name and display_name.endswith(")"):
        return display_name.split(" (")[-1][:-1]
    return ""


def _get_all_provinces():
    db = _load_municipios()
    return sorted({_extract_province(n) for n in db if " (" in n and n.endswith(")")})


def _municipios_of_province(province):
    db = _load_municipios()
    return sorted(
        ((name, code) for name, code in db.items() if _extract_province(name) == province),
        key=lambda x: x[0].split(" (")[0],
    )


def _ensure_profile_dir():
    if not os.path.exists(_PROFILE_DIR):
        os.makedirs(_PROFILE_DIR)


def load_locations():
    if not os.path.exists(_LOCATIONS_FILE):
        return []
    try:
        with open(_LOCATIONS_FILE, "r", encoding="utf-8") as fh:
            data = json.load(fh)
    except (OSError, ValueError) as exc:
        _log_err("Error leyendo ubicaciones: {0}".format(exc))
        return []
    return data if isinstance(data, list) else []


def _save_locations(locations):
    _ensure_profile_dir()
    try:
        with open(_LOCATIONS_FILE, "w", encoding="utf-8") as fh:
            json.dump(locations, fh, ensure_ascii=False, indent=2)
    except OSError as exc:
        _log_err("Error guardando ubicaciones: {0}".format(exc))


def save_location(name, code):
    code = str(code).zfill(5)
    locations = load_locations()
    for loc in locations:
        if loc.get("code") == code:
            xbmcgui.Dialog().notification(
                "EspaTV", "Esta ubicación ya está guardada",
                xbmcgui.NOTIFICATION_WARNING, 3000,
            )
            return
    locations.append({"name": name, "code": code})
    _save_locations(locations)
    xbmcgui.Dialog().notification(
        "EspaTV", "Ubicación guardada: {0}".format(name),
        xbmcgui.NOTIFICATION_INFO, 3000,
    )


def remove_location(code):
    code = str(code).zfill(5)
    locations = load_locations()
    filtered = [loc for loc in locations if loc.get("code") != code]
    if len(filtered) < len(locations):
        _save_locations(filtered)
        xbmcgui.Dialog().notification(
            "EspaTV", "Ubicación eliminada",
            xbmcgui.NOTIFICATION_INFO, 2000,
        )


def _cache_path(code):
    return os.path.join(_TEMP_DIR, "aemet_{0}.xml".format(code))


def _cache_is_valid(path):
    if not os.path.exists(path):
        return False
    age = time.time() - os.path.getmtime(path)
    return age < _CACHE_TTL_SECONDS


def _cache_age_text(path):
    if not os.path.exists(path):
        return ""
    minutes = int((time.time() - os.path.getmtime(path)) / 60)
    if minutes < 60:
        return "hace {0} min".format(minutes)
    hours = minutes // 60
    return "hace {0}h {1}min".format(hours, minutes % 60)


def _download_xml(code):
    code = str(code).zfill(5)
    url = _AEMET_XML_URL.format(code=code)
    cache = _cache_path(code)

    if _cache_is_valid(cache):
        _log("Cache valida para {0}".format(code))
        try:
            with open(cache, "rb") as fh:
                return fh.read()
        except OSError:
            pass

    if requests is None:
        _log_err("Modulo requests no disponible")
        return _read_stale_cache(cache)

    try:
        _log("Descargando XML de AEMET: {0}".format(url))
        resp = requests.get(url, timeout=15, headers={"User-Agent": "Kodi/EspaTV"})
    except requests.RequestException as exc:
        _log_err("Error descargando XML: {0}".format(exc))
        return _read_stale_cache(cache)

    if resp.status_code != 200:
        _log_err("HTTP {0} desde AEMET".format(resp.status_code))
        return _read_stale_cache(cache)

    content = resp.content
    try:
        with open(cache, "wb") as fh:
            fh.write(content)
    except OSError as exc:
        _log_err("Error escribiendo cache: {0}".format(exc))
    return content


def _read_stale_cache(cache_path):
    if not os.path.exists(cache_path):
        return None
    _log("Usando cache expirada: {0}".format(cache_path))
    try:
        with open(cache_path, "rb") as fh:
            return fh.read()
    except OSError:
        return None


def _safe_text(element):
    if element is None:
        return ""
    return (element.text or "").strip()


def _safe_attr(element, attr, default=""):
    if element is None:
        return default
    return element.attrib.get(attr, default)


def _pick_best_period_value(elements, preferred_periods=None):
    """Selecciona el valor del periodo con mayor cobertura (00-24 > medias jornadas > tramos de 6h)."""
    if preferred_periods is None:
        preferred_periods = ["00-24", "00-12", "12-24", "00-06", "06-12", "12-18", "18-24"]

    by_period = {}
    for elem in elements:
        periodo = _safe_attr(elem, "periodo")
        text = _safe_text(elem)
        by_period[periodo] = (text, elem)

    for pref in preferred_periods:
        if pref in by_period:
            text, elem = by_period[pref]
            if text:
                return text, elem
    for text, elem in by_period.values():
        if text:
            return text, elem
    if by_period:
        first_key = next(iter(by_period))
        return by_period[first_key]
    return "", None


def _pick_best_sky(elements):
    by_period = {}
    for elem in elements:
        periodo = _safe_attr(elem, "periodo")
        desc = _safe_attr(elem, "descripcion")
        icon_code = _safe_text(elem)
        by_period[periodo] = {"desc": desc, "icon": icon_code}

    preferred = ["00-24", "06-12", "12-18", "00-12", "12-24", "18-24", "00-06"]
    for pref in preferred:
        if pref in by_period and by_period[pref]["desc"]:
            return by_period[pref]["desc"], by_period[pref]["icon"]

    for data in by_period.values():
        if data["desc"]:
            return data["desc"], data["icon"]

    return "", ""


def _format_date(fecha_str):
    try:
        t = time.strptime(fecha_str, "%Y-%m-%d")
    except (ValueError, TypeError, AttributeError):
        return fecha_str
    return "{dow} {day} {mon}".format(
        dow=_DIAS_SEMANA[t.tm_wday],
        day=t.tm_mday,
        mon=_MESES[t.tm_mon - 1],
    )


def _is_today(fecha_str):
    try:
        t = time.strptime(fecha_str, "%Y-%m-%d")
    except (ValueError, TypeError, AttributeError):
        return False
    now = time.localtime()
    return t.tm_year == now.tm_year and t.tm_mon == now.tm_mon and t.tm_mday == now.tm_mday


def _icon_url(code):
    if not code:
        return ""
    return _AEMET_ICON_URL.format(code=code)


def _wind_label(direction, speed):
    if not direction and not speed:
        return ""
    if direction == "C" or (not direction and speed == "0"):
        return "Calma"
    if speed and speed != "0":
        dir_name = _WIND_DIRECTIONS.get(direction, direction)
        if dir_name:
            return "{0} a {1} km/h".format(dir_name, speed)
        return "{0} km/h".format(speed)
    dir_name = _WIND_DIRECTIONS.get(direction, direction)
    return dir_name if dir_name else ""


def _parse_day(dia_elem):
    fecha = _safe_attr(dia_elem, "fecha")
    es_hoy = _is_today(fecha)

    temp_elem = dia_elem.find("temperatura")
    temp_max = _safe_text(temp_elem.find("maxima")) if temp_elem is not None else ""
    temp_min = _safe_text(temp_elem.find("minima")) if temp_elem is not None else ""

    sens_elem = dia_elem.find("sens_termica")
    sens_max = _safe_text(sens_elem.find("maxima")) if sens_elem is not None else ""
    sens_min = _safe_text(sens_elem.find("minima")) if sens_elem is not None else ""

    hum_elem = dia_elem.find("humedad_relativa")
    hum_max = _safe_text(hum_elem.find("maxima")) if hum_elem is not None else ""
    hum_min = _safe_text(hum_elem.find("minima")) if hum_elem is not None else ""

    uv = _safe_text(dia_elem.find("uv_max"))

    sky_desc, sky_icon = _pick_best_sky(dia_elem.findall("estado_cielo"))
    precip_val, _ = _pick_best_period_value(dia_elem.findall("prob_precipitacion"))

    best_wind_dir = ""
    best_wind_vel = ""
    max_vel = -1
    for v_elem in dia_elem.findall("viento"):
        d = _safe_text(v_elem.find("direccion"))
        vel_str = _safe_text(v_elem.find("velocidad"))
        try:
            vel_num = int(vel_str)
        except (ValueError, TypeError):
            vel_num = 0
        periodo = _safe_attr(v_elem, "periodo")
        if periodo == "00-24" and d:
            best_wind_dir = d
            best_wind_vel = vel_str
            break
        if vel_num > max_vel and d:
            max_vel = vel_num
            best_wind_dir = d
            best_wind_vel = vel_str

    racha_val, _ = _pick_best_period_value(dia_elem.findall("racha_max"))

    hourly = []
    if temp_elem is not None:
        for dato in temp_elem.findall("dato"):
            hora = _safe_attr(dato, "hora")
            t_val = _safe_text(dato)
            s_val = ""
            h_val = ""
            if sens_elem is not None:
                for sd in sens_elem.findall("dato"):
                    if _safe_attr(sd, "hora") == hora:
                        s_val = _safe_text(sd)
                        break
            if hum_elem is not None:
                for hd in hum_elem.findall("dato"):
                    if _safe_attr(hd, "hora") == hora:
                        h_val = _safe_text(hd)
                        break
            hourly.append({
                "hora": hora,
                "temp": t_val or "—",
                "sens": s_val or "—",
                "humedad": h_val or "—",
            })

    periodos = []
    for ec in dia_elem.findall("estado_cielo"):
        periodo = _safe_attr(ec, "periodo")
        desc = _safe_attr(ec, "descripcion")
        icon = _safe_text(ec)
        if not desc:
            continue
        p_precip = ""
        for pp in dia_elem.findall("prob_precipitacion"):
            if _safe_attr(pp, "periodo") == periodo:
                p_precip = _safe_text(pp)
                break
        p_wind_dir = ""
        p_wind_vel = ""
        for wv in dia_elem.findall("viento"):
            if _safe_attr(wv, "periodo") == periodo:
                p_wind_dir = _safe_text(wv.find("direccion"))
                p_wind_vel = _safe_text(wv.find("velocidad"))
                break
        p_racha = ""
        for rm in dia_elem.findall("racha_max"):
            if _safe_attr(rm, "periodo") == periodo:
                p_racha = _safe_text(rm)
                break
        periodos.append({
            "periodo": periodo,
            "estado": desc,
            "icon_code": icon,
            "icon_url": _icon_url(icon),
            "prob_precip": p_precip,
            "viento_dir": p_wind_dir,
            "viento_vel": p_wind_vel,
            "racha": p_racha,
        })

    return {
        "fecha": fecha,
        "fecha_display": _format_date(fecha),
        "es_hoy": es_hoy,
        "temp_max": temp_max,
        "temp_min": temp_min,
        "estado_cielo": sky_desc,
        "icon_code": sky_icon,
        "icon_url": _icon_url(sky_icon),
        "prob_precip": precip_val,
        "viento_dir": best_wind_dir,
        "viento_vel": best_wind_vel,
        "racha_max": racha_val,
        "sens_max": sens_max,
        "sens_min": sens_min,
        "humedad_max": hum_max,
        "humedad_min": hum_min,
        "uv_max": uv,
        "periodos": periodos,
        "temp_horaria": hourly,
    }


def fetch_forecast(code):
    """Descarga + parsea la predicción AEMET. Devuelve None si falla."""
    xml_bytes = _download_xml(code)
    if not xml_bytes:
        return None

    try:
        root = ET.fromstring(xml_bytes)
    except ET.ParseError as exc:
        _log_err("XML invalido para {0}: {1}".format(code, exc))
        return None

    nombre = _safe_text(root.find(".//nombre"))
    provincia = _safe_text(root.find(".//provincia"))
    elaborado = _safe_text(root.find(".//elaborado"))

    prediccion = root.find(".//prediccion")
    if prediccion is None:
        _log_err("XML sin bloque <prediccion> para {0}".format(code))
        return None

    dias = [_parse_day(dia_elem) for dia_elem in prediccion.findall("dia")]

    cache = _cache_path(code)
    stale = not _cache_is_valid(cache)

    return {
        "nombre": nombre,
        "provincia": provincia,
        "elaborado": elaborado,
        "stale": stale,
        "cache_age": _cache_age_text(cache) if stale else "",
        "dias": dias,
    }


def _build_forecast_plot(day):
    lines = []

    if day["temp_max"] or day["temp_min"]:
        lines.append("Temperatura: {0}°C máx / {1}°C mín".format(
            day["temp_max"] or "—", day["temp_min"] or "—"))

    if day["sens_max"] or day["sens_min"]:
        lines.append("Sensación: {0}°C máx / {1}°C mín".format(
            day["sens_max"] or "—", day["sens_min"] or "—"))

    if day["humedad_max"] or day["humedad_min"]:
        lines.append("Humedad: {0}% — {1}%".format(
            day["humedad_max"] or "—", day["humedad_min"] or "—"))

    wind = _wind_label(day["viento_dir"], day["viento_vel"])
    if wind:
        wind_line = "Viento: {0}".format(wind)
        if day["racha_max"]:
            wind_line += " (ráfagas: {0} km/h)".format(day["racha_max"])
        lines.append(wind_line)

    if day["prob_precip"] and day["prob_precip"] != "0":
        lines.append("Prob. lluvia: {0}%".format(day["prob_precip"]))

    if day["uv_max"]:
        lines.append("Índice UV: {0}".format(day["uv_max"]))

    valid_hourly = [h for h in day.get("temp_horaria", []) if h["temp"] != "—"]
    if valid_hourly:
        lines.append("")
        lines.append("Detalle horario:")
        for h in valid_hourly:
            t = "{0}°C".format(h["temp"])
            s = "{0}°C".format(h["sens"]) if h["sens"] != "—" else "—"
            hu = "{0}%".format(h["humedad"]) if h["humedad"] != "—" else "—"
            lines.append("  {hora}h: {t}   Sens: {s}   Hum: {hu}".format(
                hora=h["hora"], t=t, s=s, hu=hu,
            ))

    if day.get("periodos"):
        lines.append("")
        lines.append("Por tramos:")
        for p in day["periodos"]:
            tramo = "  {0}: {1}".format(p["periodo"], p["estado"])
            extras = []
            if p["prob_precip"]:
                extras.append("lluvia {0}%".format(p["prob_precip"]))
            pw = _wind_label(p["viento_dir"], p["viento_vel"])
            if pw:
                extras.append(pw)
            if extras:
                tramo += " — " + ", ".join(extras)
            lines.append(tramo)

    return "\n".join(lines)


def _fmt_day_label(day):
    # HOY en ámbar; el resto sin color para que el skin controle el tono según foco
    if day.get("es_hoy"):
        return "[COLOR FFFBBF24][B]HOY · [/B][/COLOR]" + day["fecha_display"]
    return day["fecha_display"]


def _fmt_state_rain(day):
    estado = day.get("estado_cielo", "")
    precip = day.get("prob_precip", "")
    if precip and precip != "0":
        return "{0} · {1}%".format(estado, precip)
    return estado


class _WeatherWindow(xbmcgui.WindowXMLDialog):
    """Ventana interactiva de pronóstico con vista detallada lateral (Modo Tiempo)."""

    def __init__(self, xml, addon_path, skin, res, forecast=None, code="", name=""):
        super().__init__(xml, addon_path, skin, res)
        self._forecast = forecast or {}
        self._dias = self._forecast.get("dias", [])
        self._code = code
        self._name = name
        self._closing = False

    def onInit(self):
        self._populate()
        threading.Thread(target=self._focus_poll_loop, daemon=True).start()

    def _populate(self):
        city = self._forecast.get("nombre", "") or self._name
        prov = self._forecast.get("provincia", "")
        self.setProperty("aemet_city", "{0} ({1})".format(city, prov) if prov else city)
        elaborado = self._forecast.get("elaborado", "")
        self.setProperty("aemet_updated",
                         "Actualizado: " + elaborado.replace("T", " a las ")[:22] if elaborado else "")
        try:
            ctrl = self.getControl(200)
            ctrl.reset()
            items = []
            for day in self._dias:
                li = xbmcgui.ListItem(label=day["fecha_display"])
                li.setProperty("w_icon", day.get("icon_url", ""))
                li.setProperty("w_date", _fmt_day_label(day))
                li.setProperty("w_sub", _fmt_state_rain(day))
                li.setProperty("w_tmax", "[B][COLOR FFFBBF24]{0}°[/COLOR][/B]".format(day.get("temp_max") or "—"))
                li.setProperty("w_tmin", "[COLOR FF7DD3FC]{0}°[/COLOR]".format(day.get("temp_min") or "—"))
                items.append(li)
            ctrl.addItems(items)
            self._update_panel(0)
        except Exception as e:
            _log_err("Error poblando ventana Modo Tiempo: {0}".format(e))

    def _load_city(self, code, name):
        code = str(code).zfill(5)
        dp = xbmcgui.DialogProgress()
        dp.create("El Tiempo", "Cargando previsión de {0}...".format(name))
        forecast = fetch_forecast(code)
        dp.close()
        if not forecast or not forecast.get("dias"):
            xbmcgui.Dialog().notification("EspaTV", "No se pudo cargar {0}".format(name),
                                          xbmcgui.NOTIFICATION_ERROR, 3000)
            return
        self._forecast = forecast
        self._dias = forecast["dias"]
        self._code, self._name = code, name
        self._populate()

    def _update_panel(self, idx):
        if not (0 <= idx < len(self._dias)):
            return
        day = self._dias[idx]
        self.setProperty("aemet_icon", day.get("icon_url", ""))
        prefix = "[COLOR FFFBBF24][B]HOY · [/B][/COLOR]" if day.get("es_hoy") else ""
        self.setProperty("aemet_date", prefix + day["fecha_display"])
        self.setProperty("aemet_state", day.get("estado_cielo", ""))
        self.setProperty("aemet_tmax", "[B][COLOR FFFBBF24]{0}°[/COLOR][/B]".format(day.get("temp_max") or "—"))
        self.setProperty("aemet_tmin", "[COLOR FF7DD3FC]mín {0}°[/COLOR]".format(day.get("temp_min") or "—"))
        wind = _wind_label(day.get("viento_dir", ""), day.get("viento_vel", ""))
        self.setProperty("aemet_wind", "Viento: {0}".format(wind or "—"))
        self.setProperty("aemet_racha", "Ráfagas: {0} km/h".format(day["racha_max"]) if day.get("racha_max") else "")
        if day.get("humedad_max") or day.get("humedad_min"):
            self.setProperty("aemet_humidity", "Humedad: {0}% — {1}%".format(
                day.get("humedad_min") or "—", day.get("humedad_max") or "—"))
        else:
            self.setProperty("aemet_humidity", "")
        self.setProperty("aemet_rain", "Lluvia: {0}%".format(day.get("prob_precip") or "0"))
        self.setProperty("aemet_uv", "UV: {0}".format(day["uv_max"]) if day.get("uv_max") else "")
        if day.get("sens_max") or day.get("sens_min"):
            self.setProperty("aemet_sens", "Sensación: {0}° / {1}°".format(
                day.get("sens_max") or "—", day.get("sens_min") or "—"))
        else:
            self.setProperty("aemet_sens", "")
        lines = ["{0}: {1}{2}".format(p["periodo"], p["estado"],
                 " · {0}%".format(p["prob_precip"]) if p.get("prob_precip") else "")
                 for p in day.get("periodos", []) if p.get("estado")]
        self.setProperty("aemet_periods", "\n".join(lines))

    def _focus_poll_loop(self):
        monitor = xbmc.Monitor()
        last = -1
        while not self._closing and not monitor.abortRequested():
            try:
                ctrl = self.getFocus()
                if ctrl.getId() == 200:
                    pos = ctrl.getSelectedPosition()
                    if pos >= 0 and pos != last:
                        last = pos
                        self._update_panel(pos)
            except Exception:
                pass
            if monitor.waitForAbort(0.2):
                break

    def onClick(self, controlId):
        if controlId == 100:
            self._closing = True
            self.close()
        elif controlId == 101:
            self._change_city()
        elif controlId == 102:
            self._add_city()
        elif controlId == 200:
            pos = self.getControl(200).getSelectedPosition()
            if 0 <= pos < len(self._dias):
                day = self._dias[pos]
                xbmcgui.Dialog().textviewer(
                    "{0} - {1}".format(self._forecast.get("nombre", ""), day["fecha_display"]),
                    _build_forecast_plot(day))

    def _change_city(self):
        locs = load_locations()
        if not locs:
            xbmcgui.Dialog().notification("EspaTV", "No tienes localidades guardadas",
                                          xbmcgui.NOTIFICATION_INFO, 3000)
            return
        sel = xbmcgui.Dialog().select("Cambiar localidad", [loc.get("name", "") for loc in locs])
        if sel >= 0:
            self._load_city(locs[sel].get("code", ""), locs[sel].get("name", ""))

    def _add_city(self):
        display, code = _select_add_method()
        if display and code:
            save_location(display, code)
            self._load_city(code, display)

    def onAction(self, action):
        if action.getId() in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK):
            self._closing = True
            self.close()


def show_weather_view(handle, code, name):
    code = str(code).zfill(5)
    dp = xbmcgui.DialogProgress()
    dp.create("El Tiempo", "Cargando previsión de {0}...".format(name))
    forecast = fetch_forecast(code)
    dp.close()
    if not forecast or not forecast.get("dias"):
        xbmcgui.Dialog().notification("EspaTV", "No se pudo obtener el pronóstico",
                                      xbmcgui.NOTIFICATION_ERROR, 4000)
        return
    addon_path = _ADDON.getAddonInfo("path")
    win = _WeatherWindow("aemet_cinema.xml", addon_path, "Default", "1080i",
                         forecast=forecast, code=code, name=name)
    win.doModal()
    del win


def show_aemet_menu(handle, build_url):
    li = xbmcgui.ListItem(label="[COLOR limegreen][B]Añadir ubicación[/B][/COLOR]")
    li.setArt({"icon": "DefaultAddSource.png"})
    li.setInfo("video", {"plot":
        "Busca un municipio de España y añádelo a tu lista.\n"
        "Podrás consultar su predicción en cualquier momento."})
    xbmcplugin.addDirectoryItem(
        handle=handle, url=build_url(action="aemet_search"),
        listitem=li, isFolder=True)

    locations = load_locations()
    if not locations:
        sample_name, sample_code = random.choice(_SAMPLE_CITIES)
        li = xbmcgui.ListItem(label="[COLOR grey]Ejemplo:[/COLOR]  " + sample_name)
        li.setArt({"icon": "DefaultAddonWeather.png"})
        li.setInfo("video", {"plot":
            "Ciudad de muestra. Añade tus propias ubicaciones con 'Añadir ubicación'."})
        xbmcplugin.addDirectoryItem(
            handle=handle,
            url=build_url(action="aemet_forecast", code=sample_code, name=sample_name),
            listitem=li, isFolder=True)
    else:
        for loc in locations:
            name = loc.get("name", "")
            code = loc.get("code", "")
            li = xbmcgui.ListItem(label=name)
            li.setArt({"icon": "DefaultAddonWeather.png"})
            li.setInfo("video", {"plot":
                "Pulsa para ver el pronóstico de 7 días.\n"
                "Código AEMET: {0}".format(code)})
            li.addContextMenuItems([(
                "Quitar de guardados",
                "RunPlugin({0})".format(build_url(action="aemet_remove", code=code)),
            )])
            xbmcplugin.addDirectoryItem(
                handle=handle,
                url=build_url(action="aemet_forecast", code=code, name=name),
                listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(handle)


def _pick_by_name():
    kb = xbmc.Keyboard("", "Buscar municipio (ej: Madrid, Bilbao...)")
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        return None, None
    results = search_municipios(kb.getText().strip())
    if not results:
        xbmcgui.Dialog().notification("EspaTV", "Sin resultados",
                                      xbmcgui.NOTIFICATION_WARNING, 3000)
        return None, None
    sel = xbmcgui.Dialog().select("Seleccionar municipio", [d for d, _ in results])
    if sel < 0:
        return None, None
    return results[sel]


def _pick_from_popular():
    sel = xbmcgui.Dialog().select("Ciudades más populares",
                                  [name for name, _ in _SAMPLE_CITIES])
    if sel < 0:
        return None, None
    return _SAMPLE_CITIES[sel]


def _pick_by_province():
    provinces = _get_all_provinces()
    if not provinces:
        xbmcgui.Dialog().notification("EspaTV", "Lista de municipios no disponible",
                                      xbmcgui.NOTIFICATION_ERROR, 3000)
        return None, None
    psel = xbmcgui.Dialog().select("Seleccionar provincia", provinces)
    if psel < 0:
        return None, None
    province = provinces[psel]
    muns = _municipios_of_province(province)
    if not muns:
        return None, None
    labels = [name.split(" (")[0] for name, _ in muns]
    msel = xbmcgui.Dialog().select(province, labels)
    if msel < 0:
        return None, None
    return muns[msel]


def _pick_by_code():
    kb = xbmc.Keyboard("", "Código AEMET del municipio (ej: 28079)")
    kb.doModal()
    if not kb.isConfirmed() or not kb.getText().strip():
        return None, None
    raw = kb.getText().strip()
    if not raw.isdigit() or len(raw) > 5:
        xbmcgui.Dialog().notification("EspaTV", "Código no válido (1-5 dígitos)",
                                      xbmcgui.NOTIFICATION_ERROR, 3000)
        return None, None
    code = raw.zfill(5)
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Verificando municipio {0}...".format(code))
    forecast = fetch_forecast(code)
    dp.close()
    if not forecast:
        xbmcgui.Dialog().notification("EspaTV", "No encontrado: {0}".format(code),
                                      xbmcgui.NOTIFICATION_ERROR, 3000)
        return None, None
    name = forecast.get("nombre", code)
    prov = forecast.get("provincia", "")
    display = "{0} ({1})".format(name, prov) if prov else name
    return display, code


def _select_add_method():
    options = [
        "Buscar por nombre",
        "Ciudades más populares",
        "Buscar por provincia",
        "Introducir código AEMET",
    ]
    choice = xbmcgui.Dialog().select("Añadir ubicación", options)
    if choice == 0:
        return _pick_by_name()
    if choice == 1:
        return _pick_from_popular()
    if choice == 2:
        return _pick_by_province()
    if choice == 3:
        return _pick_by_code()
    return None, None


def search_location_ui(handle, build_url):
    display, code = _select_add_method()
    if display and code:
        save_location(display, code)
        xbmc.executebuiltin("Container.Refresh")
    xbmcplugin.endOfDirectory(handle, succeeded=False)


def show_forecast(handle, build_url, code, name):
    code = str(code).zfill(5)

    dp = xbmcgui.DialogProgress()
    dp.create("El Tiempo", "Cargando pronóstico de {0}...".format(name))
    forecast = fetch_forecast(code)
    dp.close()

    if not forecast or not forecast.get("dias"):
        xbmcgui.Dialog().notification(
            "EspaTV", "No se pudo obtener el pronóstico",
            xbmcgui.NOTIFICATION_ERROR, 4000)
        return

    if forecast.get("stale"):
        xbmcgui.Dialog().notification(
            "EspaTV",
            "Datos no actualizados ({0})".format(forecast.get("cache_age", "")),
            xbmcgui.NOTIFICATION_WARNING, 4000)

    li_view = xbmcgui.ListItem(label="[COLOR FF38BDF8][B]Modo Tiempo[/B][/COLOR]")
    li_view.setArt({"icon": os.path.join(_ADDON_PATH, "resources", "media", "tiempo.png")})
    li_view.setInfo("video", {"plot": "Interfaz visual inmersiva con la previsión de 7 días."})
    xbmcplugin.addDirectoryItem(
        handle=handle,
        url=build_url(action="aemet_weather_view", code=code, name=name),
        listitem=li_view, isFolder=False)

    elaborado = forecast.get("elaborado", "")
    if elaborado:
        elab_display = elaborado.replace("T", " a las ")[:22]
        li = xbmcgui.ListItem(label="[COLOR grey]{0} — Actualizado: {1}[/COLOR]".format(
            name, elab_display))
        li.setArt({"icon": "DefaultIconInfo.png"})
        xbmcplugin.addDirectoryItem(handle=handle, url="", listitem=li, isFolder=False)

    for idx, day in enumerate(forecast["dias"]):
        fecha = day["fecha_display"]
        estado = day.get("estado_cielo", "")
        t_max = day.get("temp_max", "—")
        t_min = day.get("temp_min", "—")

        if day["es_hoy"]:
            label = "[COLOR gold]HOY[/COLOR] — {fecha} — {estado} — {tmax}°/{tmin}°".format(
                fecha=fecha, estado=estado, tmax=t_max, tmin=t_min)
        else:
            label = "{fecha} — {estado} — {tmax}°/{tmin}°".format(
                fecha=fecha, estado=estado, tmax=t_max, tmin=t_min)

        li = xbmcgui.ListItem(label=label)
        li.setArt({
            "icon": day.get("icon_url", "DefaultAddonWeather.png"),
            "thumb": day.get("icon_url", ""),
        })

        plot = _build_forecast_plot(day)
        li.setInfo("video", {"plot": plot, "title": label})

        day_url = build_url(action="aemet_day_info", code=code, name=name, day_index=str(idx))
        xbmcplugin.addDirectoryItem(handle=handle, url=day_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(handle)


def show_day_info(code, name, day_index):
    code = str(code).zfill(5)
    forecast = fetch_forecast(code)
    if not forecast or not forecast.get("dias"):
        return

    try:
        idx = int(day_index)
        day = forecast["dias"][idx]
    except (IndexError, ValueError):
        return

    fecha = day["fecha_display"]
    label = "{0} - {1}".format(name, fecha)
    plot = _build_forecast_plot(day)
    xbmcgui.Dialog().textviewer(label, plot)
