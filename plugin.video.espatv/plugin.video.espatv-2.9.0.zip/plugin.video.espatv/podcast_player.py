# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Reproductor de podcasts: lista los feeds curados, lee el RSS y devuelve los
audios como elementos reproducibles. Cachea XMLs si IPTV cache está activo."""
import hashlib
import json
import os
import sys
import time
import urllib.parse
import xml.etree.ElementTree as ET

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings

try:
    import requests
except ImportError:
    xbmc.log("[EspaTV/podcast] requests no disponible", xbmc.LOGERROR)
    raise


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _err(msg):
    try:
        from default import _log_error
        _log_error(msg)
    except ImportError:
        xbmc.log("[EspaTV ERROR] {0}".format(msg), xbmc.LOGERROR)


_CUSTOM_PODCAST_FILE = "custom_podcasts.json"


_PODCAST_FEEDS = [
    {"name": "El Larguero (Cadena SER)", "url": "https://fapi-top.prisasd.com/podcast/playser/el_larguero/itunestfp/podcast.xml", "icon": "DefaultMusicSongs.png", "desc": "Manu Carreño con lo mejor del deporte cada noche."},
    {"name": "Hora 25 (Cadena SER)", "url": "https://fapi-top.prisasd.com/podcast/playser/hora_25/itunestfp/podcast.xml", "icon": "DefaultMusicSongs.png", "desc": "Àngels Barceló con las noticias del día."},
    {"name": "Herrera en COPE", "url": "https://www.cope.es/api/es/programas/herrera-en-cope/audios/rss.xml", "icon": "DefaultMusicSongs.png", "desc": "Carlos Herrera en las mañanas de COPE."},
    {"name": "La Vida Moderna (SER)", "url": "https://fapi-top.prisasd.com/podcast/playser/la_vida_moderna/itunestfp/podcast.xml", "icon": "DefaultMusicSongs.png", "desc": "Humor y actualidad."},
    {"name": "Todopoderosos", "url": "http://feeds.feedburner.com/todopoderosos", "icon": "DefaultMusicSongs.png", "desc": "Podcast de humor con Berto Romero y más."},
    {"name": "Wild Project", "url": "https://thewildproject.libsyn.com/rss", "icon": "DefaultMusicSongs.png", "desc": "Jordi Wild entrevista a personalidades."},
    {"name": "Entiende tu mente", "url": "http://www.spreaker.com/show/2630773/episodes/feed", "icon": "DefaultMusicSongs.png", "desc": "Podcast de psicología y desarrollo personal."},
    {"name": "Nadie Sabe Nada (SER)", "url": "https://fapi-top.prisasd.com/podcast/playser/nadie_sabe_nada/itunestfp/podcast.xml", "icon": "DefaultMusicSongs.png", "desc": "Buenafuente y Berto Romero improvisando cada sábado."},
    {"name": "Criminopatía", "url": "https://feeds.megaphone.fm/ASCCT6415418901", "icon": "DefaultMusicSongs.png", "desc": "True crime en español. Casos reales narrados en detalle."},
    {"name": "El Partidazo de COPE", "url": "https://www.cope.es/api/es/programas/el-partidazo-de-cope/audios/rss.xml", "icon": "DefaultMusicSongs.png", "desc": "Juanma Castaño con la mejor actualidad deportiva nocturna."},
    {"name": "Tiempo de Juego (COPE)", "url": "https://www.cope.es/api/es/programas/tiempo-de-juego/audios/rss.xml", "icon": "DefaultMusicSongs.png", "desc": "Paco González y el mejor fútbol en directo."},
    {"name": "A Vivir (Cadena SER)", "url": "https://fapi-top.prisasd.com/podcast/playser/a_vivir_que_son_dos_dias/itunestfp/podcast.xml", "icon": "DefaultMusicSongs.png", "desc": "Javier del Pino cada fin de semana en la SER."},
    {"name": "La Ventana (Cadena SER)", "url": "https://fapi-top.prisasd.com/podcast/playser/la_ventana/itunestfp/podcast.xml", "icon": "DefaultMusicSongs.png", "desc": "Carles Francino cada tarde en Cadena SER."},
    {"name": "Estirando el Chicle", "url": "https://www.omnycontent.com/d/playlist/2446592a-b80e-4d28-a4fd-ae4c0140ac11/42658bb8-4afa-4449-9c7a-aea9010e5b53/5942eb19-73a6-4772-8093-aea9010e5b61/podcast.rss", "icon": "DefaultMusicSongs.png", "desc": "Carolina Iglesias y Victoria Martín rajan de todo."},
    {"name": "La Ruina", "url": "https://anchor.fm/s/a4e7fe88/podcast/rss", "icon": "DefaultMusicSongs.png", "desc": "Ignasi Taltavull y Tomàs Fuentes y las peores anécdotas."},
    {"name": "La Órbita de Endor (LODE)", "url": "https://feeds.ivoox.com/feed_fg_f113302_filtro_1.xml", "icon": "DefaultMusicSongs.png", "desc": "El podcast friki por excelencia. Cine, series y cómics."},
    {"name": "Lo Que Tú Digas con Álex Fidalgo", "url": "https://anchor.fm/s/101d1e078/podcast/rss", "icon": "DefaultMusicSongs.png", "desc": "Charlas sin guion, sin filtros y sin censuras."},
    {"name": "Aquí Hay Dragones", "url": "https://feeds.ivoox.com/feed_fg_f1576365_filtro_1.xml", "icon": "DefaultMusicSongs.png", "desc": "Historia y humor con Rodrigo Cortés, Cansado, Gómez-Jurado y Arturo."},
    {"name": "SER Historia", "url": "https://fapi-top.prisasd.com/podcast/playser/ser_historia/itunestfp/podcast.xml", "icon": "DefaultMusicSongs.png", "desc": "Nacho Ares nos acerca los grandes misterios de la historia."},
    {"name": "La Escóbula de la Brújula", "url": "https://www.omnycontent.com/d/playlist/2446592a-b80e-4d28-a4fd-ae4c0140ac11/9afe58f0-d402-4e05-a5ce-aead00a0ba96/fd25a142-cbf1-4f2b-9146-aead00a0bab7/podcast.rss", "icon": "DefaultMusicSongs.png", "desc": "Historia, misterio y leyendas con Jesús Callejo y equipo."},
    {"name": "Misterios y Cubatas", "url": "https://anchor.fm/s/10084e580/podcast/rss", "icon": "DefaultMusicSongs.png", "desc": "Podcast de misterio, conspiraciones y muchas risas."},
    {"name": "El Podcast de Marian Rojas Estapé", "url": "https://feeds.simplecast.com/8YhIPHu1", "icon": "DefaultMusicSongs.png", "desc": "Salud mental, psicología y bienestar emocional."},
    {"name": "Poco se habla!", "url": "https://anchor.fm/s/f04e75c8/podcast/rss", "icon": "DefaultMusicSongs.png", "desc": "Humor y salseo con Ana Brito y Xuso Jones."},
    {"name": "Saldremos mejores", "url": "https://www.omnycontent.com/d/playlist/2446592a-b80e-4d28-a4fd-ae4c0140ac11/172ad2c5-9214-4b21-85fe-aeaa01143b70/58c58f5a-82b3-4be2-aa54-aeaa01143b82/podcast.rss", "icon": "DefaultMusicSongs.png", "desc": "Actualidad y análisis social en tono de humor con Inés y Nerea."},
    {"name": "El Descampao", "url": "https://feeds.ivoox.com/feed_fg_f1268956_filtro_1.xml", "icon": "DefaultMusicSongs.png", "desc": "Documentales sonoros, cine, música e historia friki."},
    {"name": "Nude Project", "url": "https://anchor.fm/s/107d78054/podcast/rss", "icon": "DefaultMusicSongs.png", "desc": "Entrevistas a emprendedores, artistas e ídolos jóvenes."},
    {"name": "Crims (CCMA)", "url": "https://dinamics.3cat.cat/public/podcast/catradio/xml/9/5/podprograma1859.xml", "icon": "DefaultMusicSongs.png", "desc": "El mítico true-crime narrado por Carles Porta."},
    {"name": "Tengo un Plan", "url": "https://anchor.fm/s/1007af750/podcast/rss", "icon": "DefaultMusicSongs.png", "desc": "Sergio Beguería y Juan Domínguez: éxito y desarrollo personal."},
    {"name": "ROCA PROJECT", "url": "https://anchor.fm/s/ff4c5068/podcast/rss", "icon": "DefaultMusicSongs.png", "desc": "Carlos Roca con entrevistas inspiracionales sin filtro."},
    {"name": "WORLDCAST", "url": "https://feeds.megaphone.fm/HOT7749589265", "icon": "DefaultMusicSongs.png", "desc": "Pedro Buerbaum conversando con los invitados más virales."},
    {"name": "Black Mango Podcast", "url": "https://anchor.fm/s/e0c735b8/podcast/rss", "icon": "DefaultMusicSongs.png", "desc": "Historia, misterios oscuros y casos reales."},
    {"name": "La ContraCrónica", "url": "https://feeds.ivoox.com/feed_fg_f1267769_filtro_1.xml", "icon": "DefaultMusicSongs.png", "desc": "Fernando Díaz Villanueva analiza la política, la economía y el mundo."},
    {"name": "A solas con... Vicky Martín Berrocal", "url": "https://www.omnycontent.com/d/playlist/2446592a-b80e-4d28-a4fd-ae4c0140ac11/d46d806d-6f59-403c-871f-b04400f4e432/52f42c98-c91e-469f-9579-b04400f56b06/podcast.rss", "icon": "DefaultMusicSongs.png", "desc": "Charlas íntimas e inspiradoras con invitadas mediáticas."},
    {"name": "Crónicas de la Calle Morgue", "url": "https://feeds.ivoox.com/feed_fg_f11436296_filtro_1.xml", "icon": "DefaultMusicSongs.png", "desc": "Relatos de crímenes reales llenos de detalle y crudeza."}
]


def _load_custom_podcasts():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    fp = os.path.join(p, _CUSTOM_PODCAST_FILE)
    if not os.path.exists(fp):
        return []
    try:
        with open(fp, 'r', encoding='utf-8') as f:
            data = json.load(f)
        return data if isinstance(data, list) else []
    except (OSError, ValueError):
        return []


def _save_custom_podcasts(pods):
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p)
    fp = os.path.join(p, _CUSTOM_PODCAST_FILE)
    try:
        with open(fp, 'w', encoding='utf-8') as f:
            json.dump(pods, f, ensure_ascii=False)
    except OSError:
        pass


def _podcast_add_custom():
    kb = xbmc.Keyboard('', 'URL del feed RSS del podcast')
    kb.doModal()
    if not kb.isConfirmed():
        return
    url = kb.getText().strip()
    parsed = urllib.parse.urlparse(url)
    if parsed.scheme not in ('http', 'https') or not parsed.netloc:
        xbmcgui.Dialog().ok('EspaTV', 'Introduce una URL válida (http:// o https://).')
        return
    pods = _load_custom_podcasts()
    existing = [pod['url'] for pod in _PODCAST_FEEDS] + [pod.get('url', '') for pod in pods]
    if url in existing:
        xbmcgui.Dialog().notification('EspaTV', 'Ese podcast ya existe', xbmcgui.NOTIFICATION_WARNING)
        return
    kb2 = xbmc.Keyboard('', 'Nombre para este podcast')
    kb2.doModal()
    name = (kb2.getText().strip() if kb2.isConfirmed() else '').replace('[', '').replace(']', '')
    if not name:
        name = parsed.netloc
    pods.append({'name': name, 'url': url, 'desc': ''})
    _save_custom_podcasts(pods)
    xbmcgui.Dialog().notification('EspaTV', f"Podcast '{name}' añadido", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin('Container.Refresh')


def _podcast_delete_custom(url):
    pods = _load_custom_podcasts()
    name = next((pod.get('name', 'Podcast') for pod in pods if pod.get('url') == url), 'Podcast')
    if xbmcgui.Dialog().yesno('EspaTV', f"¿Eliminar el podcast '{name}'?"):
        pods = [pod for pod in pods if pod.get('url') != url]
        _save_custom_podcasts(pods)
        xbmcgui.Dialog().notification('EspaTV', 'Podcast eliminado', xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin('Container.Refresh')


def _podcast_menu():
    h = int(sys.argv[1])
    for pod in _PODCAST_FEEDS:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(pod["name"]))
        li.setArt({'icon': pod.get("icon", "DefaultMusicSongs.png")})
        li.setInfo('video', {'plot': pod.get("desc", "")})
        fav_params = json.dumps({"url": pod["url"], "title": pod["name"]})
        li.addContextMenuItems([("Añadir a Mis Favoritos", "RunPlugin({0})".format(_u(action='add_favorite', title=pod["name"], fav_url='podcast_{0}'.format(pod["name"]), icon=pod.get("icon", "DefaultMusicSongs.png"), platform='podcast', fav_action='podcast_feed', params=fav_params)))])
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="podcast_feed", url=pod["url"], title=pod["name"]), listitem=li, isFolder=True)

    for pod in _load_custom_podcasts():
        name = pod.get("name", "Podcast")
        url = pod.get("url", "")
        li = xbmcgui.ListItem(label=f"[COLOR aqua][B]{name}[/B][/COLOR]")
        li.setArt({'icon': "DefaultMusicSongs.png"})
        li.setInfo('video', {'plot': f"Tu podcast\nURL: {url}"})
        li.addContextMenuItems([("Eliminar este podcast", f"RunPlugin({_u(action='podcast_delete_custom', url=url)})")])
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="podcast_feed", url=url, title=name), listitem=li, isFolder=True)

    li_add = xbmcgui.ListItem(label="[B]Añadir podcast RSS...[/B]")
    li_add.setArt({'icon': 'DefaultAddSource.png'})
    li_add.setInfo('video', {'plot': "Añade tu propio feed RSS de podcast al menú."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="podcast_add_custom"), listitem=li_add, isFolder=False)

    xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.is_iptv_cache_active())


def _podcast_feed(feed_url, feed_title=""):
    h = int(sys.argv[1])
    dp = xbmcgui.DialogProgress()
    dp.create("Podcast", "Cargando episodios...")
    try:
        dp.update(30, "Descargando feed...")
        content = None
        c_file = ""
        ttl = core_settings.get_iptv_cache_ttl()
        if core_settings.is_iptv_cache_active() and ttl > 0:
            c_dir = core_settings.get_iptv_cache_dir()
            c_key = hashlib.md5(feed_url.encode('utf-8')).hexdigest()
            c_file = os.path.join(c_dir, 'pod_' + c_key + '.xml')
            if os.path.exists(c_file):
                try:
                    with open(c_file, 'r', encoding='utf-8') as f:
                        meta = json.load(f)
                    if (time.time() - meta.get('ts', 0)) < ttl:
                        content = meta.get('data', '').encode('utf-8')
                except (OSError, ValueError):
                    pass

        if not content:
            r = requests.get(feed_url, timeout=15, headers={"User-Agent": "Kodi EspaTV"})
            if r.status_code != 200:
                dp.close()
                xbmcgui.Dialog().ok("Podcast", "Error al descargar el feed: HTTP {0}".format(r.status_code))
                xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.is_iptv_cache_active()); return
            content = r.content
            if core_settings.is_iptv_cache_active() and c_file:
                try:
                    with open(c_file, 'w', encoding='utf-8') as f:
                        json.dump({'ts': time.time(), 'data': content.decode('utf-8', 'ignore')}, f)
                except OSError:
                    pass

        dp.update(70, "Procesando episodios...")
        root = ET.fromstring(content)
        channel = root.find("channel")
        if channel is None:
            dp.close()
            xbmcgui.Dialog().ok("Podcast", "Feed no válido.")
            xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.is_iptv_cache_active()); return
        items = channel.findall("item")
        dp.close()
        if not items:
            xbmcgui.Dialog().ok("Podcast", "No se encontraron episodios.")
            xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.is_iptv_cache_active()); return
        xbmcplugin.setContent(h, 'songs')
        for item in items[:50]:
            title_el = item.find("title")
            title = title_el.text.strip() if title_el is not None and title_el.text else "Episodio"
            desc_el = item.find("description")
            desc = desc_el.text.strip() if desc_el is not None and desc_el.text else ""
            pub_el = item.find("pubDate")
            pub_date = pub_el.text.strip() if pub_el is not None and pub_el.text else ""
            enclosure = item.find("enclosure")
            audio_url = enclosure.get("url", "") if enclosure is not None else ""
            if not audio_url:
                link_el = item.find("link")
                audio_url = link_el.text.strip() if link_el is not None and link_el.text else ""
            if not audio_url:
                continue
            # Miniatura: buscar en el namespace itunes:image (href en cualquier tag con "image")
            thumb = ""
            for el in item:
                if "image" in el.tag and el.get("href"):
                    thumb = el.get("href", "")
                    break
            label = title
            if pub_date:
                try:
                    short_date = pub_date.split(",")[1].strip()[:12] if "," in pub_date else pub_date[:16]
                    label = "[COLOR gray]{0}[/COLOR] {1}".format(short_date, title)
                except (IndexError, AttributeError):
                    pass
            li = xbmcgui.ListItem(label=label)
            li.setArt({'icon': thumb or 'DefaultMusicSongs.png', 'thumb': thumb or 'DefaultMusicSongs.png'})
            plot = ""
            if feed_title: plot += "Podcast: {0}\n".format(feed_title)
            if pub_date: plot += "Fecha: {0}\n".format(pub_date)
            if desc: plot += "\n{0}".format(desc[:500])
            li.setInfo('video', {'title': title, 'plot': plot})
            li.setProperty("IsPlayable", "true")
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="play_podcast", url=audio_url, title=title), listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.is_iptv_cache_active())
    except (requests.RequestException, ValueError, ImportError, ET.ParseError) as e:
        try:
            dp.close()
        except RuntimeError:
            pass
        _err("Podcast feed error: {0}".format(e))
        xbmcgui.Dialog().ok("Podcast", "Error al cargar el feed:\n{0}".format(e))
        try:
            xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.is_iptv_cache_active())
        except RuntimeError:
            pass


def _play_podcast(url, title=""):
    h = int(sys.argv[1])
    try:
        li = xbmcgui.ListItem(path=url)
        if title: li.setInfo('video', {'title': title})
        li.setContentLookup(False)
        xbmcplugin.setResolvedUrl(h, True, li)
    except RuntimeError as e:
        _err("Podcast play error: {0}".format(e))
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
