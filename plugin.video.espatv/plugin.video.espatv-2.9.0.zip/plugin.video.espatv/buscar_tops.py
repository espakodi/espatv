"""Búsqueda nativa de películas y series en EspaTV.

Submenú con varios modos:
- Por título: combina TMDB (/search/multi) con un índice de los tops cacheados
  (Modo Cine, TMDB, Trakt, FilmAffinity, SensaCine, Cinemeta, etc.), con
  tolerancia a erratas (fuzzy) e historial. Fallback offline a los tops.
- Por director / género / año: descubrimiento vía TMDB (/discover, /search/person).

Al pulsar un resultado se abre el menú nativo de EspaTV (search_alt_prompt).
"""
import contextlib
import difflib
import json
import os
import re
import sys
import unicodedata
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import metadata_enricher as me

_LOG_TAG = "[EspaTV-Buscar]"

# Tope de resultados renderizados (una query genérica puede casar cientos en los
# tops cacheados; Kodi se ralentiza pintándolos todos).
_MAX_RESULTS = 60
# Longitud mínima de query para el barrido por substring/fuzzy en los tops.
_MIN_QUERY = 2
# Umbral de similitud (difflib) para aceptar un match con erratas.
_FUZZY_MIN = 0.8

_HISTORY_FILE = 'buscar_tops_history.json'
_HISTORY_MAX = 30

# Géneros TMDB de película (IDs verificados en filmaffinity.py del propio addon).
_GENRES = [
    ("Acción", "28"), ("Aventura", "12"), ("Animación", "16"), ("Comedia", "35"),
    ("Ciencia Ficción", "878"), ("Documental", "99"), ("Drama", "18"),
    ("Fantasía", "14"), ("Terror", "27"), ("Thriller", "53"),
    ("Musical", "10402"), ("Western", "37"), ("Bélica", "10752"),
]

# Ficheros de caché de tops -> etiqueta mostrada. El harvester es genérico, así
# que un cambio de esquema interno no rompe nada: simplemente recoge menos.
_TOP_CACHES = [
    ("espatv_flix_cache.json",          "Modo Cine"),
    ("espatv_tmdb_lists_cache.json",    "TMDB"),
    ("espatv_trakt_tops_cache.json",    "Trakt"),
    ("espatv_trakt_discovery_cache.json", "Trakt"),
    ("espatv_fa_cache.json",            "FilmAffinity"),
    ("espatv_sc_cache.json",            "SensaCine"),
    ("espatv_cinemeta_cache.json",      "Cinemeta"),
    ("espatv_streaming_tops_cache.json", "Streaming"),
    ("espatv_anime_cache.json",         "Anime"),
]


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"{_LOG_TAG} {msg}", level)


def _u(**kw):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kw)


def _norm(s):
    # sin acentos, solo alfanumérico, para comparar títulos
    s = unicodedata.normalize('NFKD', s or '').encode('ascii', 'ignore').decode('ascii')
    return ''.join(c if (c.isalnum() or c == ' ') else ' ' for c in s.lower()).strip()


def _profile_dir():
    return xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))


@contextlib.contextmanager
def _progress(label):
    """Indicador 'Buscando...' en segundo plano mientras se consulta TMDB."""
    dlg = xbmcgui.DialogProgressBG()
    try:
        dlg.create("EspaTV", label)
        yield
    finally:
        try:
            dlg.close()
        except Exception:
            pass


# Índice de tops cacheados

_SHOW_TOKENS  = {'tv', 'show', 'shows', 'serie', 'series', 'tvshow', 'tvshows'}
_MOVIE_TOKENS = {'movie', 'movies', 'pelicula', 'peliculas', 'film', 'films'}


def _mt_from_key(key, parent):
    """Infiere movie/show por el nombre de la clave de caché (trakt usa movies//shows/,
    tmdb_lists usa tv/.. y movie/..). Por tokens para no casar 'tv' dentro de otra palabra."""
    tokens = set(re.split(r'[^a-z]+', str(key).lower()))
    if tokens & _SHOW_TOKENS:
        return 'show'
    if tokens & _MOVIE_TOKENS:
        return 'movie'
    return parent


def _norm_mt(value):
    v = str(value).lower()
    if v in ('tv', 'show', 'tvshow', 'series', 'serie'):
        return 'show'
    if v in ('movie', 'film', 'pelicula'):
        return 'movie'
    return ''


def _harvest(obj, source, mt_hint, out):
    """Recorre recursivamente un JSON de caché y recoge dicts con pinta de película/serie.

    Un dict cuenta como item si tiene 'title'/'name' y al menos un campo de
    identidad (tmdb_id/poster/year/media_type/imdb_id).
    """
    if isinstance(obj, dict):
        title = obj.get('title') or obj.get('name')
        ident = any(obj.get(k) for k in ('tmdb_id', 'poster', 'year', 'media_type', 'imdb_id'))
        if title and ident:
            mt = _norm_mt(obj.get('media_type')) or mt_hint or 'movie'
            out.append({
                'tmdb_id':    str(obj.get('tmdb_id') or ''),
                'title':      str(title),
                'year':       str(obj.get('year') or ''),
                'poster':     str(obj.get('poster') or ''),
                'overview':   str(obj.get('overview') or obj.get('plot') or ''),
                'media_type': mt,
                'source':     source,
            })
            return  # no seguir bajando dentro de un item ya identificado
        for k, v in obj.items():
            _harvest(v, source, _mt_from_key(k, mt_hint), out)
    elif isinstance(obj, list):
        for v in obj:
            _harvest(v, source, mt_hint, out)


def _load_index():
    """Construye el índice de tops cacheados. Devuelve dict keyed por clave canónica:
    {canon_key: {title, year, poster, overview, media_type, tmdb_id, sources:set}}.
    Cada fichero se lee de forma aislada: un error en uno no afecta al resto.
    """
    raw = []
    base = _profile_dir()
    for fname, label in _TOP_CACHES:
        path = os.path.join(base, fname)
        if not os.path.exists(path):
            continue
        try:
            with open(path, encoding='utf-8') as fh:
                data = json.load(fh)
            _harvest(data, label, '', raw)
        except (OSError, ValueError) as e:
            _log(f"caché ilegible {fname}: {e}", xbmc.LOGWARNING)

    # Películas legendarias (lista en código, solo títulos).
    try:
        import peliculas_top
        for t in peliculas_top.get_movies_list():
            raw.append({'tmdb_id': '', 'title': str(t), 'year': '', 'poster': '',
                        'overview': '', 'media_type': 'movie', 'source': 'Legendarias'})
    except Exception as e:
        _log(f"peliculas_top no disponible: {e}", xbmc.LOGWARNING)

    index = {}
    for it in raw:
        key = it['tmdb_id'] or (_norm(it['title']) + '|' + it['media_type'])
        if not key.strip('|'):
            continue
        cur = index.get(key)
        if cur is None:
            index[key] = {
                'tmdb_id':    it['tmdb_id'],
                'title':      it['title'],
                'year':       it['year'],
                'poster':     it['poster'],
                'overview':   it['overview'],
                'media_type': it['media_type'],
                'sources':    {it['source']},
            }
        else:
            cur['sources'].add(it['source'])
            for f in ('tmdb_id', 'year', 'poster', 'overview'):
                if not cur[f] and it[f]:
                    cur[f] = it[f]
    return index


# Búsqueda por título (TMDB + tops + fuzzy)

def _match_rank(q, title_norm):
    """Relevancia textual: 0 exacto, 1 prefijo, 2 palabra que empieza por q, 3 contiene, 4 otro."""
    if not q:
        return 4
    if title_norm == q:
        return 0
    if title_norm.startswith(q):
        return 1
    if any(w.startswith(q) for w in title_norm.split()):
        return 2
    if q in title_norm:
        return 3
    return 4


def _fuzzy_match(q, title_norm):
    """True si q casa el título por substring o por similitud (erratas) con alguna palabra."""
    if q in title_norm:
        return True
    for w in title_norm.split():
        sm = difflib.SequenceMatcher(None, q, w)
        if sm.real_quick_ratio() >= _FUZZY_MIN and sm.ratio() >= _FUZZY_MIN:
            return True
    return False


def search(query):
    """Devuelve la lista fusionada de resultados (TMDB + tops), ordenada por
    relevancia y limitada a _MAX_RESULTS. Nunca lanza.

    Cada resultado: {tmdb_id, title, year, poster, overview, media_type,
    popularity, sources(list)}.
    """
    qn = _norm(query)
    try:
        index = _load_index()
    except Exception as e:
        _log(f"fallo construyendo índice: {e}", xbmc.LOGERROR)
        index = {}

    by_tmdb = {it['tmdb_id']: it['sources'] for it in index.values() if it['tmdb_id']}
    by_norm = {}
    for it in index.values():
        by_norm.setdefault(_norm(it['title']) + '|' + it['media_type'], set()).update(it['sources'])

    results = []
    seen_tmdb = set()
    seen_norm = set()

    for it in me.search_multi(query):
        nk = _norm(it['title']) + '|' + it['media_type']
        srcs = set()
        if it['tmdb_id'] and it['tmdb_id'] in by_tmdb:
            srcs |= by_tmdb[it['tmdb_id']]
        if nk in by_norm:
            srcs |= by_norm[nk]
        results.append(dict(it, sources=sorted(srcs)))
        if it['tmdb_id']:
            seen_tmdb.add(it['tmdb_id'])
        seen_norm.add(nk)

    # Items en los tops que TMDB no devolvió (o estamos offline). Substring + fuzzy.
    # Solo con query de longitud suficiente: 1 letra casaría medio catálogo.
    if len(qn) >= _MIN_QUERY:
        for it in index.values():
            if not _fuzzy_match(qn, _norm(it['title'])):
                continue
            if it['tmdb_id'] and it['tmdb_id'] in seen_tmdb:
                continue
            nk = _norm(it['title']) + '|' + it['media_type']
            if nk in seen_norm:
                continue
            seen_norm.add(nk)
            results.append({
                'tmdb_id':    it['tmdb_id'],
                'title':      it['title'],
                'year':       it['year'],
                'poster':     it['poster'],
                'overview':   it['overview'],
                'media_type': it['media_type'],
                'popularity': 0,
                'sources':    sorted(it['sources']),
            })

    # Orden: relevancia textual, luego en-tus-tops, luego popularidad de TMDB.
    results.sort(key=lambda x: (
        _match_rank(qn, _norm(x['title'])),
        0 if x['sources'] else 1,
        -(x.get('popularity') or 0),
    ))
    if len(results) > _MAX_RESULTS:
        _log(f"{len(results)} resultados para '{query}', mostrando {_MAX_RESULTS}", xbmc.LOGINFO)
    return results[:_MAX_RESULTS]


# Descubrimiento (director / género / año)

def _pick_director(personas):
    """Elige el person_id más relevante: preferentemente del departamento de dirección."""
    directores = [p for p in personas if p.get('department') == 'Directing']
    if directores:
        return directores[0]['id']
    return personas[0]['id'] if personas else None


def _merge_discover(*listas):
    """Fusiona listas de discover dedupeando por tmdb_id+tipo y ordena por popularidad."""
    out, seen = [], set()
    for lst in listas:
        for it in lst:
            k = (it['tmdb_id'], it['media_type'])
            if k in seen:
                continue
            seen.add(k)
            out.append(it)
    out.sort(key=lambda x: x.get('popularity') or 0, reverse=True)
    return out[:_MAX_RESULTS]


# Renderizado

def _render(handle, results, vacio_msg):
    if not results:
        xbmcgui.Dialog().notification("EspaTV", vacio_msg, xbmcgui.NOTIFICATION_INFO, 3000)
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return

    addon = xbmcaddon.Addon()
    af = addon.getAddonInfo('fanart')
    ai = addon.getAddonInfo('icon')

    for it in results:
        title  = it['title']
        year   = it.get('year') or ''
        poster = it.get('poster') or ai
        mt     = it.get('media_type') or 'movie'
        sources = it.get('sources') or []

        label = f"{title} ({year})" if year else title
        if sources:
            label += f"  [COLOR gold][{', '.join(sources)}][/COLOR]"

        li = xbmcgui.ListItem(label=label)
        li.setArt({'thumb': poster, 'poster': poster, 'icon': poster, 'fanart': af})
        info = {'title': title, 'plot': it.get('overview') or '',
                'mediatype': 'tvshow' if mt == 'show' else 'movie'}
        if str(year).isdigit():
            info['year'] = int(year)
        li.setInfo('video', info)
        li.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(
            handle=handle,
            url=_u(action='search_alt_prompt', q=title, ot=poster, mode=mt, tmdb_id=it.get('tmdb_id', '')),
            listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


# Submenú y modos (llamados desde el router; el input lo recoge el router)

def menu(handle):
    addon = xbmcaddon.Addon()
    media = os.path.join(addon.getAddonInfo('path'), 'resources', 'media')

    def ic(name, fb='DefaultAddonsSearch.png'):
        p = os.path.join(media, name)
        return p if os.path.exists(p) else fb

    for label, action, icon, plot in [
        ("Buscar por título",   'bt_titulo',   'adv_busqueda.png',
         "Por título en TMDB y en tus tops a la vez. Tolera erratas."),
        ("Buscar por director", 'bt_director', 'adv_busqueda.png',
         "Películas de un director (datos de TMDB)."),
        ("Buscar por género",   'bt_generos',  'top_mejores.png',
         "Películas por género, ordenadas por popularidad."),
        ("Buscar por año",      'bt_anio',     'adv_busqueda.png',
         "Películas y series estrenadas en un año concreto."),
    ]:
        li = xbmcgui.ListItem(label=f"[B]{label}[/B]")
        li.setArt({'icon': ic(icon)})
        li.setInfo('video', {'plot': plot})
        xbmcplugin.addDirectoryItem(handle, _u(action=action), li, isFolder=True)

    if _hist_load():
        li = xbmcgui.ListItem(label="[B][COLOR orange]Búsquedas recientes[/COLOR][/B]")
        li.setArt({'icon': ic('historial.png')})
        xbmcplugin.addDirectoryItem(handle, _u(action='bt_historial'), li, isFolder=True)

    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def buscar_titulo(handle, query):
    _hist_add(query)
    with _progress("Buscando..."):
        results = search(query)
    _render(handle, results, f"Sin resultados para '{query}'")


def buscar_director(handle, name):
    with _progress(f"Buscando películas de {name}..."):
        personas = me.search_person(name)
        pid = _pick_director(personas)
        results = me.discover('movie', {'with_crew': pid, 'sort_by': 'popularity.desc'}) if pid else []
    _render(handle, results, f"No se encontró '{name}' o sus películas")


def generos_menu(handle):
    addon = xbmcaddon.Addon()
    media = os.path.join(addon.getAddonInfo('path'), 'resources', 'media')
    for label, gid in _GENRES:
        li = xbmcgui.ListItem(label=f"[B]{label}[/B]")
        ipath = os.path.join(media, 'top_mejores.png')
        li.setArt({'icon': ipath if os.path.exists(ipath) else 'DefaultGenre.png'})
        xbmcplugin.addDirectoryItem(handle, _u(action='bt_genero', id=gid, label=label),
                                    li, isFolder=True)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def buscar_genero(handle, genre_id, label):
    with _progress(f"Cargando {label}..."):
        results = me.discover('movie', {'with_genres': genre_id, 'vote_count.gte': 100,
                                         'sort_by': 'popularity.desc'})
    _render(handle, results, f"Sin resultados para el género {label}")


def buscar_anio(handle, year):
    y = str(year).strip()
    if not (y.isdigit() and 1900 <= int(y) <= 2100):
        _render(handle, [], "Introduce un año válido (ej. 1999)")
        return
    with _progress(f"Cargando estrenos de {y}..."):
        pelis  = me.discover('movie', {'primary_release_year': y, 'vote_count.gte': 50,
                                        'sort_by': 'popularity.desc'})
        series = me.discover('show',  {'first_air_date_year': y, 'vote_count.gte': 50,
                                       'sort_by': 'popularity.desc'})
    _render(handle, _merge_discover(pelis, series), f"Sin estrenos en {y}")


# Historial

def _hist_path():
    return os.path.join(_profile_dir(), _HISTORY_FILE)


def _hist_load():
    try:
        with open(_hist_path(), encoding='utf-8') as fh:
            h = json.load(fh)
        return [str(x) for x in h] if isinstance(h, list) else []
    except (OSError, ValueError):
        return []


def _hist_save(h):
    """Escritura atómica (tmp + os.replace): un proceso interrumpido no deja el
    JSON a medias ni borra el historial existente."""
    try:
        d = _profile_dir()
        os.makedirs(d, exist_ok=True)
        tmp = os.path.join(d, _HISTORY_FILE + '.tmp')
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(h, fh)
        os.replace(tmp, _hist_path())
    except OSError as e:
        _log(f"no se pudo guardar historial: {e}", xbmc.LOGWARNING)


def _hist_add(query):
    q = (query or '').strip()
    if not q:
        return
    h = [x for x in _hist_load() if x.lower() != q.lower()]
    h.insert(0, q)
    _hist_save(h[:_HISTORY_MAX])


def _hist_clear():
    _hist_save([])


def historial_menu(handle):
    hist = _hist_load()
    if not hist:
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return
    for q in hist:
        li = xbmcgui.ListItem(label=q)
        li.setArt({'icon': 'DefaultAddonsSearch.png'})
        li.addContextMenuItems([
            ("Eliminar del historial", f"RunPlugin({_u(action='bt_hist_remove', q=q)})"),
        ])
        xbmcplugin.addDirectoryItem(handle, _u(action='bt_titulo', q=q), li, isFolder=True)
    li = xbmcgui.ListItem(label="[COLOR red]Borrar historial[/COLOR]")
    li.setArt({'icon': 'DefaultIconError.png'})
    xbmcplugin.addDirectoryItem(handle, _u(action='bt_hist_clear'), li, isFolder=False)
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


def hist_remove(query):
    q = (query or '').strip()
    _hist_save([x for x in _hist_load() if x.lower() != q.lower()])
    xbmc.executebuiltin("Container.Refresh")


def hist_clear_ui():
    if xbmcgui.Dialog().yesno("EspaTV", "¿Borrar el historial de búsquedas?"):
        _hist_clear()
        xbmc.executebuiltin("Container.Refresh")
