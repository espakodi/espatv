# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Fases Lunares: cálculo astronómico local basado en el algoritmo de Jean Meeus."""
import datetime
import math
import os
import sys
import urllib.parse

import xbmcgui
import xbmcplugin

_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

_FASES = [
    (0.00, "🌑 Luna Nueva",         "sin luna visible"),
    (0.25, "🌓 Cuarto Creciente",   "mitad derecha iluminada"),
    (0.50, "🌕 Luna Llena",         "disco completo visible"),
    (0.75, "🌗 Cuarto Menguante",   "mitad izquierda iluminada"),
]
_FASE_NOMBRES = ["Luna Nueva", "Cuarto Creciente", "Luna Llena", "Cuarto Menguante"]
_FASE_ICONOS  = ["○", "◑", "●", "◐"]

_DIAS_ES  = ["Lun", "Mar", "Mié", "Jue", "Vie", "Sáb", "Dom"]
_MESES_ES = ["", "ene", "feb", "mar", "abr", "may", "jun",
             "jul", "ago", "sep", "oct", "nov", "dic"]


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


# Algoritmo de Meeus, Astronomical Algorithms Cap. 49

def _jde_phase(k, phase_frac):
    """
    Calcula el JDE (Julian Day Ephemeris) para la fase dada de la lunación k.
    phase_frac: 0=Luna Nueva, 0.25=Cuarto Creciente, 0.5=Luna Llena, 0.75=Cuarto Menguante
    """
    kp  = k + phase_frac
    T   = kp / 1236.85
    T2  = T * T
    T3  = T2 * T
    T4  = T3 * T

    JDE = (2451550.09766
           + 29.530588861 * kp
           + 0.00015437 * T2
           - 0.000000150 * T3
           + 0.00000000073 * T4)

    M   = math.radians(2.5534  + 29.10535670 * kp - 0.0000014 * T2 - 0.00000011 * T3)
    Mp  = math.radians(201.5643 + 385.81693528 * kp + 0.0107582 * T2 - 0.00001238 * T3 - 0.000000058 * T4)
    F   = math.radians(160.7108 + 390.67050284 * kp - 0.0016118 * T2 - 0.00000227 * T3 + 0.000000011 * T4)
    Om  = math.radians(124.7746 - 1.56375588 * kp + 0.0020672 * T2 + 0.00000215 * T3)

    E   = 1 - 0.002516 * T - 0.0000074 * T2
    E2  = E * E

    if phase_frac == 0.0:
        corr = (-0.40720 * math.sin(Mp)
                + 0.17241 * E  * math.sin(M)
                + 0.01608 * math.sin(2 * Mp)
                + 0.01039 * math.sin(2 * F)
                + 0.00739 * E  * math.sin(Mp - M)
                - 0.00514 * E  * math.sin(Mp + M)
                + 0.00208 * E2 * math.sin(2 * M)
                - 0.00111 * math.sin(Mp - 2 * F)
                - 0.00057 * math.sin(Mp + 2 * F)
                + 0.00056 * E  * math.sin(2 * Mp + M)
                - 0.00042 * math.sin(3 * Mp)
                + 0.00042 * E  * math.sin(M + 2 * F)
                + 0.00038 * E  * math.sin(M - 2 * F)
                - 0.00024 * E  * math.sin(2 * Mp - M)
                - 0.00017 * math.sin(Om)
                - 0.00007 * math.sin(Mp + 2 * M)
                + 0.00004 * math.sin(2 * Mp - 2 * F)
                + 0.00004 * math.sin(3 * M)
                + 0.00003 * math.sin(Mp + M - 2 * F)
                + 0.00003 * math.sin(2 * Mp + 2 * F)
                - 0.00003 * math.sin(Mp + M + 2 * F)
                + 0.00003 * math.sin(Mp - M + 2 * F)
                - 0.00002 * math.sin(Mp - M - 2 * F)
                - 0.00002 * math.sin(3 * Mp + M)
                + 0.00002 * math.sin(4 * Mp))
    elif phase_frac == 0.5:
        corr = (-0.40614 * math.sin(Mp)
                + 0.17302 * E  * math.sin(M)
                + 0.01614 * math.sin(2 * Mp)
                + 0.01043 * math.sin(2 * F)
                + 0.00734 * E  * math.sin(Mp - M)
                - 0.00515 * E  * math.sin(Mp + M)
                + 0.00209 * E2 * math.sin(2 * M)
                - 0.00111 * math.sin(Mp - 2 * F)
                - 0.00057 * math.sin(Mp + 2 * F)
                + 0.00056 * E  * math.sin(2 * Mp + M)
                - 0.00042 * math.sin(3 * Mp)
                + 0.00042 * E  * math.sin(M + 2 * F)
                + 0.00038 * E  * math.sin(M - 2 * F)
                - 0.00024 * E  * math.sin(2 * Mp - M)
                - 0.00017 * math.sin(Om)
                - 0.00007 * math.sin(Mp + 2 * M)
                + 0.00004 * math.sin(2 * Mp - 2 * F)
                + 0.00004 * math.sin(3 * M)
                + 0.00003 * math.sin(Mp + M - 2 * F)
                + 0.00003 * math.sin(2 * Mp + 2 * F)
                - 0.00003 * math.sin(Mp + M + 2 * F)
                + 0.00003 * math.sin(Mp - M + 2 * F)
                - 0.00002 * math.sin(Mp - M - 2 * F)
                - 0.00002 * math.sin(3 * Mp + M)
                + 0.00002 * math.sin(4 * Mp))
    else:
        # Cuartos
        corr = (-0.62801 * math.sin(Mp)
                + 0.17172 * E  * math.sin(M)
                - 0.01183 * E  * math.sin(Mp + M)
                + 0.00862 * math.sin(2 * Mp)
                + 0.00804 * math.sin(2 * F)
                + 0.00454 * E  * math.sin(Mp - M)
                + 0.00204 * E2 * math.sin(2 * M)
                - 0.00180 * math.sin(Mp - 2 * F)
                - 0.00070 * math.sin(Mp + 2 * F)
                - 0.00040 * math.sin(3 * Mp)
                - 0.00034 * E  * math.sin(2 * Mp - M)
                + 0.00032 * E  * math.sin(M + 2 * F)
                + 0.00032 * E  * math.sin(M - 2 * F)
                - 0.00028 * E2 * math.sin(Mp + 2 * M)
                + 0.00027 * E  * math.sin(2 * Mp + M)
                - 0.00017 * math.sin(Om)
                - 0.00005 * math.sin(Mp - M - 2 * F)
                + 0.00004 * math.sin(2 * Mp + 2 * F)
                - 0.00004 * math.sin(Mp + M + 2 * F)
                + 0.00004 * math.sin(Mp - 2 * M)
                + 0.00003 * math.sin(Mp + M - 2 * F)
                + 0.00003 * math.sin(3 * M)
                + 0.00002 * math.sin(2 * Mp - 2 * F)
                + 0.00002 * math.sin(Mp - M + 2 * F)
                - 0.00002 * math.sin(3 * Mp + M))
        # Corrección adicional para cuartos
        W = (0.00306
             - 0.00038 * E * math.cos(M)
             + 0.00026 * math.cos(Mp)
             - 0.00002 * math.cos(Mp - M)
             + 0.00002 * math.cos(Mp + M)
             + 0.00002 * math.cos(2 * F))
        corr += W if phase_frac == 0.25 else -W

    return JDE + corr


def _jde_to_utc(jde):
    jde_adj = jde + 0.5
    Z = int(jde_adj)
    F = jde_adj - Z
    if Z < 2299161:
        A = Z
    else:
        alpha = int((Z - 1867216.25) / 36524.25)
        A = Z + 1 + alpha - alpha // 4
    B = A + 1524
    C = int((B - 122.1) / 365.25)
    D = int(365.25 * C)
    E = int((B - D) / 30.6001)
    day   = B - D - int(30.6001 * E)
    month = E - 1 if E < 14 else E - 13
    year  = C - 4716 if month > 2 else C - 4715
    frac  = F * 24
    hour  = int(frac)
    frac  = (frac - hour) * 60
    minute = int(frac)
    second = int((frac - minute) * 60)
    try:
        return datetime.datetime(year, month, day, hour, minute, second,
                                 tzinfo=datetime.timezone.utc)
    except ValueError:
        return None


def _k_approx(dt):
    year_frac = dt.year + (dt.month - 1) / 12.0 + dt.day / 365.25
    return (year_frac - 2000.0) * 12.3685


def _find_next_phases(n=5):
    """Devuelve las próximas n fases (a partir de hoy)."""
    now_utc = datetime.datetime.now(datetime.timezone.utc)
    k0 = math.floor(_k_approx(now_utc))
    results = []
    k = k0 - 1
    fracs = [0.0, 0.25, 0.5, 0.75]
    while len(results) < n + 4:
        for fi, frac in enumerate(fracs):
            jde = _jde_phase(k, frac)
            dt  = _jde_to_utc(jde)
            if dt and dt >= now_utc:
                results.append((dt, fi))
        k += 1
        if k > k0 + 15:
            break
    results.sort(key=lambda x: x[0])
    return results[:n]


def _current_phase_description():
    """Describe la fase lunar actual de forma aproximada."""
    now = datetime.datetime.now(datetime.timezone.utc)
    k0  = math.floor(_k_approx(now))
    # Buscar la última fase nueva
    phases_past = []
    for k in range(k0 - 1, k0 + 2):
        for fi, frac in enumerate([0.0, 0.25, 0.5, 0.75]):
            jde = _jde_phase(k, frac)
            dt  = _jde_to_utc(jde)
            if dt and dt <= now:
                phases_past.append((dt, fi))
    if not phases_past:
        return "Calculando…", _FASE_ICONOS[0]
    phases_past.sort(key=lambda x: x[0])
    last_dt, last_fi = phases_past[-1]
    return _FASE_NOMBRES[last_fi], _FASE_ICONOS[last_fi]


def fases_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_fases_luna.png")

    current_name, current_icono = _current_phase_description()
    li_now = xbmcgui.ListItem(
        label="[B][COLOR deepskyblue]Fase actual:[/COLOR][/B]  {0} {1}".format(current_icono, current_name)
    )
    li_now.setArt({"icon": icon})
    li_now.setInfo("video", {"plot": "Fase lunar aproximada en este momento: {0} {1}".format(current_icono, current_name)})
    li_now.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li_now, isFolder=False)

    sep = xbmcgui.ListItem(label="[COLOR grey]────  Próximas fases  ────[/COLOR]")
    sep.setArt({"icon": "DefaultAddonNone.png"})
    sep.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=sep, isFolder=False)

    next_phases = _find_next_phases(8)
    for dt, fi in next_phases:
        nombre  = _FASE_NOMBRES[fi]
        icono   = _FASE_ICONOS[fi]
        dia_es  = _DIAS_ES[dt.weekday()]
        mes_es  = _MESES_ES[dt.month]
        fecha   = "{0} {1} {2} {3}".format(dia_es, dt.day, mes_es, dt.year)
        hora    = "{0:02d}:{1:02d} UTC".format(dt.hour, dt.minute)
        label   = "[B]{0} {1}[/B]   [COLOR deepskyblue]{2}[/COLOR]   [COLOR grey]{3}[/COLOR]".format(
            icono, nombre, fecha, hora
        )
        plot    = "{0} {1}\n{2}  {3}".format(icono, nombre, fecha, hora)
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon})
        li.setInfo("video", {"title": nombre, "plot": plot})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)
