# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
# Skyline Webcams se abre en el navegador intencionalmente para respetar su
# modelo de financiación por publicidad web y mantener el servicio disponible.
import sys
import os
import re
import time
import hashlib
import webbrowser
import urllib.parse

import requests
import xbmc
import xbmcgui
import xbmcplugin
import xbmcaddon
import xbmcvfs


_SKY_BASE     = "https://www.skylinewebcams.com"
_SKY_UA       = "Mozilla/5.0 (Windows NT 10.0; rv:75.0) Gecko/20100101 Firefox/75.0"
_SKY_TTL_CAMS = 300              # listas de camaras (estado en vivo/offline)
_SKY_TTL_NAV  = 14 * 24 * 3600   # paginas de navegacion (paises, regiones, categorias)



def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _params():
    return dict(urllib.parse.parse_qsl(sys.argv[2][1:]))


def _cam_icon():
    return os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'webcam.png')


def _notify_error(msg):
    xbmcgui.Dialog().notification("EspaTV", msg, xbmcgui.NOTIFICATION_ERROR)


def _notify_warn(msg):
    xbmcgui.Dialog().notification("EspaTV", msg, xbmcgui.NOTIFICATION_WARNING)


def _notify_info(msg):
    xbmcgui.Dialog().notification("EspaTV", msg, xbmcgui.NOTIFICATION_INFO)



def menu():
    h = int(sys.argv[1])
    icon = _cam_icon()
    try:
        from youtube_data import WEBCAMS_ES
    except Exception as e:
        xbmc.log("[EspaTV] No se pudo cargar WEBCAMS_ES: {0}".format(e), xbmc.LOGERROR)
        WEBCAMS_ES = {}

    for cat_name, items in WEBCAMS_ES.items():
        if isinstance(items, dict):
            total_items = sum(len(sub) for sub in items.values())
        else:
            total_items = len(items)
        li = xbmcgui.ListItem(label="[B]{0}[/B] [COLOR gray]({1})[/COLOR]".format(cat_name, total_items))
        li.setArt({'icon': icon})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="webcams_list", cat=cat_name), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="[B][COLOR aquamarine]Skyline Webcams[/COLOR][/B]")
    li.setArt({'icon': icon})
    li.setInfo('video', {'plot': "Webcams en directo de todo el mundo. Se abren en el navegador."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="skyline_menu"), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def lista(cat_name, subcat_name=""):
    h = int(sys.argv[1])
    icon = _cam_icon()
    try:
        from youtube_data import WEBCAMS_ES
    except Exception as e:
        xbmc.log("[EspaTV] No se pudo cargar WEBCAMS_ES: {0}".format(e), xbmc.LOGERROR)
        xbmcplugin.endOfDirectory(h)
        return

    node = WEBCAMS_ES.get(cat_name, [])

    if isinstance(node, dict) and not subcat_name:
        for sub_name, sub_items in node.items():
            li = xbmcgui.ListItem(label="[B]{0}[/B] [COLOR gray]({1})[/COLOR]".format(sub_name, len(sub_items)))
            li.setArt({'icon': icon})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="webcams_list", cat=cat_name, subcat=sub_name), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(h)
        return

    if isinstance(node, dict) and subcat_name:
        items = node.get(subcat_name, [])
    elif isinstance(node, list):
        items = node
    else:
        items = []

    if not items:
        xbmcplugin.endOfDirectory(h)
        return

    for item in items:
        name = item.get("name", "Camara")
        desc = item.get("desc", name)
        stream_url = item.get("url", "")
        yt_id = item.get("yt_id", "")
        li = xbmcgui.ListItem(label="[B][COLOR red]●[/COLOR] {0}[/B]".format(name))
        li.setArt({'icon': icon, 'thumb': icon})
        li.setInfo('video', {'title': name, 'plot': "{0}\nPulsa para ver en directo.".format(desc)})
        li.setProperty("IsPlayable", "true")

        if yt_id:
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="play_youtube_live", yt_id=yt_id, title=name), listitem=li, isFolder=False)
        else:
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="play_webcam", stream_url=stream_url, title=name), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def play():
    h = int(sys.argv[1])
    p = _params()
    stream_url = p.get("stream_url", "")
    title = p.get("title", "")
    if not stream_url:
        _notify_warn("Camara no disponible.")
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return
    xbmc.log("[EspaTV] Reproduciendo webcam: {0}".format(stream_url), xbmc.LOGINFO)
    li = xbmcgui.ListItem(path=stream_url)
    li.setInfo('video', {'title': title})
    li.setMimeType('application/vnd.apple.mpegurl')
    li.setContentLookup(False)
    xbmcplugin.setResolvedUrl(h, True, li)



def _sky_cache_dir():
    d = os.path.join(xbmcvfs.translatePath('special://temp/'), 'espatv_skyline')
    try:
        os.makedirs(d, exist_ok=True)
    except Exception as e:
        xbmc.log("[EspaTV] No se pudo crear cache dir: {0}".format(e), xbmc.LOGWARNING)
    return d


def _sky_fetch(url, ttl=_SKY_TTL_CAMS):
    cache_file = None
    try:
        cache_file = os.path.join(_sky_cache_dir(), hashlib.md5(url.encode()).hexdigest() + '.html')
        if os.path.exists(cache_file) and (time.time() - os.path.getmtime(cache_file)) < ttl:
            with open(cache_file, 'r', encoding='utf-8', errors='replace') as f:
                return f.read()
    except Exception as e:
        xbmc.log("[EspaTV] Cache read fallo: {0}".format(e), xbmc.LOGWARNING)

    r = requests.get(url, headers={"User-Agent": _SKY_UA}, timeout=15, verify=False)
    r.raise_for_status()
    html = r.text

    if cache_file:
        try:
            with open(cache_file, 'w', encoding='utf-8') as f:
                f.write(html)
        except Exception as e:
            xbmc.log("[EspaTV] Cache write fallo: {0}".format(e), xbmc.LOGWARNING)
    return html



def sky_menu():
    h = int(sys.argv[1])
    icon = _cam_icon()
    opciones = [
        ("TOP Camaras en vivo",  "skyline_camaras",    _SKY_BASE + "/es/top-live-cams.html"),
        ("Nuevas camaras",       "skyline_camaras",    _SKY_BASE + "/es/new-livecams.html"),
        ("Por Paises",           "skyline_paises",     _SKY_BASE + "/es.html"),
        ("Por Categorias",       "skyline_categorias", _SKY_BASE + "/es.html"),
    ]
    for label, action, url in opciones:
        li = xbmcgui.ListItem(label="[B][COLOR white]{0}[/COLOR][/B]".format(label))
        li.setArt({'icon': icon})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action, url=url), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def sky_paises():
    h = int(sys.argv[1])
    icon = _cam_icon()
    try:
        html = _sky_fetch(_SKY_BASE + "/es.html", ttl=_SKY_TTL_NAV)
    except Exception as e:
        xbmc.log("[EspaTV] Skyline paises fetch fallo: {0}".format(e), xbmc.LOGERROR)
        _notify_error("Error al conectar con Skyline.")
        xbmcplugin.endOfDirectory(h)
        return
    bloques = re.findall(r'<div class="continent [^"]*"><strong>(.*?)</strong>(.*?)</div></div></div>', html, re.DOTALL)
    count = 0
    for continente, contenido in bloques:
        continente = re.sub(r'<[^>]+>', '', continente).strip()
        for path, pais in re.findall(r'href="(/es/webcam/[^"]+\.html)"[^>]*>(.*?)</a>', contenido, re.DOTALL):
            pais = re.sub(r'<[^>]+>', '', pais).strip()
            if not pais:
                continue
            li = xbmcgui.ListItem(label="[B][COLOR yellow]{0}[/COLOR] [COLOR white]{1}[/COLOR][/B]".format(continente, pais))
            li.setArt({'icon': icon})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="skyline_regiones", url=_SKY_BASE + path), listitem=li, isFolder=True)
            count += 1
    if count == 0:
        _notify_warn("No se encontraron paises en Skyline.")
    xbmcplugin.endOfDirectory(h)


def sky_regiones():
    h = int(sys.argv[1])
    url = _params().get("url", "")
    if not url:
        _notify_warn("URL no disponible.")
        xbmcplugin.endOfDirectory(h)
        return
    icon = _cam_icon()
    try:
        html = _sky_fetch(url, ttl=_SKY_TTL_NAV)
    except Exception as e:
        xbmc.log("[EspaTV] Skyline regiones fetch fallo: {0}".format(e), xbmc.LOGERROR)
        _notify_error("Error al conectar con Skyline.")
        xbmcplugin.endOfDirectory(h)
        return
    items = re.findall(r'<a href="(/es/webcam/[^"]+\.html)" class="btn btn-primary tag">(.*?)</a>', html, re.DOTALL)
    if items:
        for path, nombre in items:
            nombre = re.sub(r'<[^>]+>', '', nombre).strip()
            if not nombre:
                continue
            li = xbmcgui.ListItem(label="[B][COLOR white]{0}[/COLOR][/B]".format(nombre))
            li.setArt({'icon': icon})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="skyline_camaras", url=_SKY_BASE + path), listitem=li, isFolder=True)
        xbmcplugin.endOfDirectory(h)
    else:
        _sky_camaras_desde_html(h, html)


def sky_categorias():
    h = int(sys.argv[1])
    try:
        html = _sky_fetch(_SKY_BASE + "/es.html", ttl=_SKY_TTL_NAV)
    except Exception as e:
        xbmc.log("[EspaTV] Skyline categorias fetch fallo: {0}".format(e), xbmc.LOGERROR)
        _notify_error("Error al conectar con Skyline.")
        xbmcplugin.endOfDirectory(h)
        return
    bloques = re.findall(r'C[aá]maras en directo por categor[ií]a.*?class="mega-dropdown hidden-sm">', html, re.DOTALL)
    seen = set()
    count = 0
    for bloque in bloques:
        for path, titulo, foto in re.findall(r'<a href="(/es/[^"]+)"[^>]*>.*?<p class="tcam">(.*?)</p>.*?<img[^>]+src="([^"]+)"', bloque, re.DOTALL):
            titulo = re.sub(r'<[^>]+>', '', titulo).strip()
            if not titulo or path in seen:
                continue
            seen.add(path)
            li = xbmcgui.ListItem(label="[B][COLOR white]{0}[/COLOR][/B]".format(titulo))
            li.setArt({'icon': foto, 'thumb': foto})
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="skyline_camaras", url=_SKY_BASE + path), listitem=li, isFolder=True)
            count += 1
    if count == 0:
        _notify_warn("No se encontraron categorias en Skyline.")
    xbmcplugin.endOfDirectory(h)


def sky_camaras():
    h = int(sys.argv[1])
    url = _params().get("url", "")
    if not url:
        _notify_warn("URL no disponible.")
        xbmcplugin.endOfDirectory(h)
        return
    try:
        html = _sky_fetch(url)
    except Exception as e:
        xbmc.log("[EspaTV] Skyline camaras fetch fallo: {0}".format(e), xbmc.LOGERROR)
        _notify_error("Error al conectar con Skyline.")
        xbmcplugin.endOfDirectory(h)
        return
    _sky_camaras_desde_html(h, html)


def sky_open_browser():
    url = _params().get("url", "")
    if not url:
        _notify_warn("URL no disponible.")
        return
    try:
        _notify_info("Abriendo en el navegador...")
        if xbmc.getCondVisibility("System.Platform.Android"):
            xbmc.executebuiltin('StartAndroidActivity("","android.intent.action.VIEW","text/html","{0}")'.format(url))
        else:
            import webbrowser
            webbrowser.open(url)
        xbmc.log("[EspaTV] Skyline abierto en navegador: {0}".format(url), xbmc.LOGINFO)
    except Exception as e:
        xbmc.log("[EspaTV] No se pudo abrir el navegador: {0}".format(e), xbmc.LOGERROR)
        _notify_error("No se pudo abrir el navegador.")


def _sky_camaras_desde_html(h, html):
    camaras = []
    for path, block in re.findall(r'<a href="(es/webcam/[^"]+)"[^>]*>(.*?)</a>', html, re.DOTALL):
        img  = re.search(r'<img[^>]+src="([^"]+)"', block)
        tcam = re.search(r'class="tcam">(.*?)</p>', block)
        if not (img and tcam):
            continue
        nombre = re.sub(r'<[^>]+>', '', tcam.group(1)).strip()
        if not nombre:
            continue
        subt    = re.search(r'class="subt">(.*?)</p>', block)
        lcam    = re.search(r'class="lcam">(.*?)</span>', block)
        descrip = re.sub(r'<[^>]+>', '', subt.group(1)).strip() if subt else ''
        offline = bool(lcam)
        foto    = img.group(1)
        camaras.append((offline, nombre, descrip, foto, _SKY_BASE + "/" + path))

    camaras.sort(key=lambda x: x[0])  # online primero

    for offline, nombre, descrip, foto, cam_url in camaras:
        estado = "[COLOR gray][OFFLINE][/COLOR]" if offline else "[COLOR lime][EN VIVO][/COLOR]"
        li = xbmcgui.ListItem(label="[B]{0} [COLOR white]{1}[/COLOR][/B] [COLOR gray]{2}[/COLOR]".format(estado, nombre, descrip))
        li.setArt({'icon': foto, 'thumb': foto, 'fanart': foto})
        li.setInfo('video', {'title': nombre, 'plot': "{0}\n\n{1}".format(
            descrip, "Offline." if offline else "En directo. Se abrira en el navegador.")})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="skyline_open_browser", url=cam_url), listitem=li, isFolder=False)

    if not camaras:
        _notify_warn("No se encontraron camaras.")
    xbmcplugin.endOfDirectory(h)
