# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Cartelera y estrenos de SensaCine."""
import html
import json
import os
import re
import sys
import threading
import time
import urllib.parse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from _user_agents import desktop_headers as _dh, ACCEPT_HTML

_CARTELERA_URL = "https://www.sensacine.com/peliculas/en-cartelera/cines/"
_ESTRENOS_URL  = "https://www.sensacine.com/peliculas/estrenos/"
_MEJORES_URL   = "https://www.sensacine.com/peliculas/mejores-peliculas/"  # esta sí pagina con ?page=N
_TAQUILLA_URL  = "https://www.sensacine.com/peliculas/taquilla/"
_HEADERS = _dh(accept=ACCEPT_HTML, referer="https://www.sensacine.com/")
_SC_TTL = 6 * 3600
_SC_TTL_LONG = 7 * 24 * 3600  # mejores cambia poco; refresco semanal
_SC_MIN_FILMS = 3
_MEJORES_PAGES = 5


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def _handle():
    return int(sys.argv[1])


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'espatv_sc_cache.json')


def _load_cache():
    empty = {"cartelera": {}, "estrenos": {}, "mejores": {}, "taquilla": {}}
    try:
        path = _cache_path()
        if not os.path.exists(path):
            return empty
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        for key in empty:
            if not isinstance(data.get(key), dict):
                data[key] = {}
        return data
    except (OSError, ValueError) as e:
        xbmc.log("[EspaTV-SC] cache load error: {0}".format(e), xbmc.LOGWARNING)
        return empty


def _save_cache(data):
    # tmp ÚNICO por hilo: dos escrituras concurrentes con el mismo .tmp se pisaban y
    # dejaban el JSON corrupto ("Extra data"), lo que vaciaba toda la caché al leerla.
    path = _cache_path()
    tmp = '{0}.{1}.tmp'.format(path, threading.get_ident())
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError as e:
        xbmc.log("[EspaTV-SC] cache save error: {0}".format(e), xbmc.LOGWARNING)
        try:
            os.remove(tmp)
        except OSError:
            pass


def _cache_fresh(cache):
    c = cache.get("cartelera", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _SC_TTL


def _scrape_cartelera():
    try:
        r = requests.get(_CARTELERA_URL, headers=_HEADERS, timeout=12)
        xbmc.log("[EspaTV-SC] cartelera -> {0}".format(r.status_code), xbmc.LOGINFO)
        if r.status_code != 200:
            return None
        films = []
        seen = set()
        for block in re.split(r'(?=<div[^>]+class="[^"]*entity-card[^"]*")', r.text):
            id_m = re.search(r'/peliculas/pelicula-(\d+)/', block)
            if not id_m:
                continue
            fid = id_m.group(1)
            if fid in seen:
                continue
            title_m = re.search(r'class="meta-title-link"[^>]*>([^<]+)</a>', block)
            if not title_m:
                continue
            seen.add(fid)
            title = html.unescape(title_m.group(1).strip())
            img_m = re.search(r'data-src="(https://[^"]+acsta\.net[^"]*)"', block)
            if not img_m:
                img_m = re.search(r'\bsrc="(https://[^"]+acsta\.net[^"]*)"', block)
            poster = img_m.group(1) if img_m else ''
            films.append({'id': fid, 'title': title, 'poster': poster})
        if len(films) < _SC_MIN_FILMS:
            xbmc.log(
                "[EspaTV-SC] resultado sospechoso ({0} films), ignorando".format(len(films)),
                xbmc.LOGWARNING,
            )
            return None
        xbmc.log("[EspaTV-SC] scrapeadas {0} películas".format(len(films)), xbmc.LOGINFO)
        return films
    except (requests.RequestException, ValueError) as e:
        xbmc.log("[EspaTV-SC] scrape error: {0}".format(e), xbmc.LOGERROR)
        return None


def _fetch_cartelera():
    cache = _load_cache()

    if _cache_fresh(cache):
        films = cache["cartelera"]["films"]
        xbmc.log(
            "[EspaTV-SC] cartelera desde caché ({0} títulos)".format(len(films)),
            xbmc.LOGINFO,
        )
        return films

    scraped = _scrape_cartelera()
    if scraped is not None:
        films = scraped
        cache["cartelera"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("cartelera", {}).get("films"):
        films = cache["cartelera"]["films"]
        xbmc.log("[EspaTV-SC] SC inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []

    _save_cache(cache)
    return films


def _trigger_bg_enrich(films):
    import metadata_enricher as me
    def _fetch():
        try:
            items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
            results = me.batch_enrich(items, max_workers=2)
            if any(results):
                xbmc.executebuiltin("Container.Refresh")
        except Exception:
            pass
    threading.Thread(target=_fetch, daemon=True).start()


def show_cartelera():
    import pelis_grid as _pg
    if _pg.apply_grid_mode(_handle(), 'sensacine_cartelera', 'En Cines España'):
        return

    import metadata_enricher as me

    films = _fetch_cartelera()
    if not films:
        xbmcgui.Dialog().notification("EspaTV", "No se pudo cargar SensaCine", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = xbmcaddon.Addon().getAddonInfo('fanart')
    first_title = films[0]['title'] if films else None
    has_meta = bool(me.enrich(title=first_title, media_type='movie', use_cache_only=True)) if first_title else False
    if not has_meta:
        _trigger_bg_enrich(films)

    for f in films:
        li = xbmcgui.ListItem(label=f['title'])
        meta = me.enrich(title=f['title'], media_type='movie', use_cache_only=True)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster']})
            li.setInfo('video', {'title': f['title'], 'mediatype': 'movie'})
            poster = f['poster']
        tmdb_id = (meta.get('ids') or {}).get('tmdb', '') if meta else ''
        cm = [
            ("¿Dónde ver en España?", "RunPlugin({0})".format(
                _u(action='show_watch_providers', title=f['title'], tmdb_id=tmdb_id))),
            ("Buscar en más fuentes", "RunPlugin({0})".format(
                _u(action='search_movie_multi', q=f['title'], tmdb_id=tmdb_id, media_type='movie'))),
            ("Copiar título", "RunPlugin({0})".format(
                _u(action='copy_title', title=f['title']))),
        ]
        li.addContextMenuItems(cm)
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=poster, mode='movie', tmdb_id=tmdb_id)
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def _estrenos_fresh(cache):
    c = cache.get("estrenos", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _SC_TTL


def _scrape_estrenos():
    try:
        r = requests.get(_ESTRENOS_URL, headers=_HEADERS, timeout=12)
        xbmc.log("[EspaTV-SC] estrenos -> {0}".format(r.status_code), xbmc.LOGINFO)
        if r.status_code != 200:
            return None
        films = []
        seen = set()
        for block in re.split(r'(?=<div[^>]+class="[^"]*entity-card[^"]*")', r.text):
            id_m = re.search(r'/peliculas/pelicula-(\d+)/', block)
            if not id_m:
                continue
            fid = id_m.group(1)
            if fid in seen:
                continue
            title_m = re.search(r'class="meta-title-link"[^>]*>([^<]+)</a>', block)
            if not title_m:
                continue
            seen.add(fid)
            title = html.unescape(title_m.group(1).strip())
            img_m = re.search(r'data-src="(https://[^"]+acsta\.net[^"]*)"', block)
            if not img_m:
                img_m = re.search(r'\bsrc="(https://[^"]+acsta\.net[^"]*)"', block)
            poster = img_m.group(1) if img_m else ''
            films.append({'id': fid, 'title': title, 'poster': poster})
        if len(films) < _SC_MIN_FILMS:
            xbmc.log(
                "[EspaTV-SC] estrenos sospechoso ({0} films), ignorando".format(len(films)),
                xbmc.LOGWARNING,
            )
            return None
        xbmc.log("[EspaTV-SC] estrenos: {0} películas".format(len(films)), xbmc.LOGINFO)
        return films
    except (requests.RequestException, ValueError) as e:
        xbmc.log("[EspaTV-SC] estrenos error: {0}".format(e), xbmc.LOGERROR)
        return None


def _fetch_estrenos():
    cache = _load_cache()

    if _estrenos_fresh(cache):
        films = cache["estrenos"]["films"]
        xbmc.log(
            "[EspaTV-SC] estrenos desde caché ({0} títulos)".format(len(films)),
            xbmc.LOGINFO,
        )
        return films

    scraped = _scrape_estrenos()
    if scraped is not None:
        films = scraped
        cache["estrenos"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("estrenos", {}).get("films"):
        films = cache["estrenos"]["films"]
        xbmc.log("[EspaTV-SC] estrenos inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []

    _save_cache(cache)
    return films


def show_estrenos():
    import pelis_grid as _pg
    if _pg.apply_grid_mode(_handle(), 'sensacine_estrenos', 'Estrenos'):
        return

    import metadata_enricher as me

    films = _fetch_estrenos()
    if not films:
        xbmcgui.Dialog().notification("EspaTV", "No se pudo cargar SensaCine Estrenos", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = xbmcaddon.Addon().getAddonInfo('fanart')
    first_title = films[0]['title'] if films else None
    has_meta = bool(me.enrich(title=first_title, media_type='movie', use_cache_only=True)) if first_title else False
    if not has_meta:
        _trigger_bg_enrich(films)

    for f in films:
        li = xbmcgui.ListItem(label=f['title'])
        meta = me.enrich(title=f['title'], media_type='movie', use_cache_only=True)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster']})
            li.setInfo('video', {'title': f['title'], 'mediatype': 'movie'})
            poster = f['poster']
        tmdb_id = (meta.get('ids') or {}).get('tmdb', '') if meta else ''
        cm = [
            ("¿Dónde ver en España?", "RunPlugin({0})".format(
                _u(action='show_watch_providers', title=f['title'], tmdb_id=tmdb_id))),
            ("Buscar en más fuentes", "RunPlugin({0})".format(
                _u(action='search_movie_multi', q=f['title'], tmdb_id=tmdb_id, media_type='movie'))),
            ("Copiar título", "RunPlugin({0})".format(
                _u(action='copy_title', title=f['title']))),
        ]
        li.addContextMenuItems(cm)
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=poster, mode='movie', tmdb_id=tmdb_id)
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def _scrape_listing(url, label, seen=None):
    """Scraper genérico de listados de SensaCine. Devuelve la lista cruda (sin umbral)
    o None ante error de red/HTTP. El umbral _SC_MIN_FILMS lo aplica el llamador."""
    try:
        r = requests.get(url, headers=_HEADERS, timeout=12)
        xbmc.log("[EspaTV-SC] {0} -> {1}".format(label, r.status_code), xbmc.LOGINFO)
        if r.status_code != 200:
            return None
        films = []
        if seen is None:
            seen = set()
        # taquilla usa 'movie-card-bo'; cartelera/estrenos/mejores usan 'entity-card'
        for block in re.split(r'(?=<div[^>]+class="[^"]*(?:entity-card|movie-card-bo)[^"]*")', r.text):
            id_m = re.search(r'/peliculas/pelicula-(\d+)/', block)
            if not id_m:
                continue
            fid = id_m.group(1)
            if fid in seen:
                continue
            title_m = re.search(r'class="meta-title-link"[^>]*>([^<]+)</a>', block)
            if not title_m:
                continue
            seen.add(fid)
            title = html.unescape(title_m.group(1).strip())
            img_m = re.search(r'data-src="(https://[^"]+acsta\.net[^"]*)"', block)
            if not img_m:
                img_m = re.search(r'\bsrc="(https://[^"]+acsta\.net[^"]*)"', block)
            poster = img_m.group(1) if img_m else ''
            films.append({'id': fid, 'title': title, 'poster': poster})
        return films
    except (requests.RequestException, ValueError) as e:
        xbmc.log("[EspaTV-SC] {0} error: {1}".format(label, e), xbmc.LOGERROR)
        return None


def _mejores_fresh(cache):
    c = cache.get("mejores", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _SC_TTL_LONG


def _scrape_mejores():
    seen = set()
    films = []
    for page in range(1, _MEJORES_PAGES + 1):
        url = _MEJORES_URL if page == 1 else "{0}?page={1}".format(_MEJORES_URL, page)
        page_films = _scrape_listing(url, "mejores p{0}".format(page), seen=seen)
        if page_films is None:
            break
        films.extend(page_films)
        if not page_films:
            break
    if len(films) < _SC_MIN_FILMS:
        xbmc.log(
            "[EspaTV-SC] mejores sospechoso ({0} films), ignorando".format(len(films)),
            xbmc.LOGWARNING,
        )
        return None
    xbmc.log("[EspaTV-SC] mejores: {0} películas".format(len(films)), xbmc.LOGINFO)
    return films


def _fetch_mejores():
    cache = _load_cache()

    if _mejores_fresh(cache):
        films = cache["mejores"]["films"]
        xbmc.log("[EspaTV-SC] mejores desde caché ({0} títulos)".format(len(films)), xbmc.LOGINFO)
        return films

    scraped = _scrape_mejores()
    if scraped is not None:
        films = scraped
        cache["mejores"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("mejores", {}).get("films"):
        films = cache["mejores"]["films"]
        xbmc.log("[EspaTV-SC] mejores inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []

    _save_cache(cache)
    return films


def show_mejores():
    import pelis_grid as _pg
    if _pg.apply_grid_mode(_handle(), 'sensacine_mejores', 'Mejores Películas'):
        return

    import metadata_enricher as me

    films = _fetch_mejores()
    if not films:
        xbmcgui.Dialog().notification("EspaTV", "No se pudo cargar SensaCine Mejores", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = xbmcaddon.Addon().getAddonInfo('fanart')
    first_title = films[0]['title'] if films else None
    has_meta = bool(me.enrich(title=first_title, media_type='movie', use_cache_only=True)) if first_title else False
    if not has_meta:
        _trigger_bg_enrich(films)

    for f in films:
        li = xbmcgui.ListItem(label=f['title'])
        meta = me.enrich(title=f['title'], media_type='movie', use_cache_only=True)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster']})
            li.setInfo('video', {'title': f['title'], 'mediatype': 'movie'})
            poster = f['poster']
        tmdb_id = (meta.get('ids') or {}).get('tmdb', '') if meta else ''
        cm = [
            ("¿Dónde ver en España?", "RunPlugin({0})".format(
                _u(action='show_watch_providers', title=f['title'], tmdb_id=tmdb_id))),
            ("Buscar en más fuentes", "RunPlugin({0})".format(
                _u(action='search_movie_multi', q=f['title'], tmdb_id=tmdb_id, media_type='movie'))),
            ("Copiar título", "RunPlugin({0})".format(
                _u(action='copy_title', title=f['title']))),
        ]
        li.addContextMenuItems(cm)
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=poster, mode='movie', tmdb_id=tmdb_id)
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def _taquilla_fresh(cache):
    c = cache.get("taquilla", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _SC_TTL


def _scrape_taquilla():
    films = _scrape_listing(_TAQUILLA_URL, "taquilla")
    if films is None:
        return None
    if len(films) < _SC_MIN_FILMS:
        xbmc.log(
            "[EspaTV-SC] taquilla sospechosa ({0} films), ignorando".format(len(films)),
            xbmc.LOGWARNING,
        )
        return None
    xbmc.log("[EspaTV-SC] taquilla: {0} películas".format(len(films)), xbmc.LOGINFO)
    return films


def _fetch_taquilla():
    cache = _load_cache()

    if _taquilla_fresh(cache):
        films = cache["taquilla"]["films"]
        xbmc.log("[EspaTV-SC] taquilla desde caché ({0} títulos)".format(len(films)), xbmc.LOGINFO)
        return films

    scraped = _scrape_taquilla()
    if scraped is not None:
        films = scraped
        cache["taquilla"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("taquilla", {}).get("films"):
        films = cache["taquilla"]["films"]
        xbmc.log("[EspaTV-SC] taquilla inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []

    _save_cache(cache)
    return films


def show_taquilla():
    import pelis_grid as _pg
    if _pg.apply_grid_mode(_handle(), 'sensacine_taquilla', 'Taquilla'):
        return

    import metadata_enricher as me

    films = _fetch_taquilla()
    if not films:
        xbmcgui.Dialog().notification("EspaTV", "No se pudo cargar SensaCine Taquilla", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = xbmcaddon.Addon().getAddonInfo('fanart')
    first_title = films[0]['title'] if films else None
    has_meta = bool(me.enrich(title=first_title, media_type='movie', use_cache_only=True)) if first_title else False
    if not has_meta:
        _trigger_bg_enrich(films)

    for f in films:
        li = xbmcgui.ListItem(label=f['title'])
        meta = me.enrich(title=f['title'], media_type='movie', use_cache_only=True)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster']})
            li.setInfo('video', {'title': f['title'], 'mediatype': 'movie'})
            poster = f['poster']
        tmdb_id = (meta.get('ids') or {}).get('tmdb', '') if meta else ''
        cm = [
            ("¿Dónde ver en España?", "RunPlugin({0})".format(
                _u(action='show_watch_providers', title=f['title'], tmdb_id=tmdb_id))),
            ("Buscar en más fuentes", "RunPlugin({0})".format(
                _u(action='search_movie_multi', q=f['title'], tmdb_id=tmdb_id, media_type='movie'))),
            ("Copiar título", "RunPlugin({0})".format(
                _u(action='copy_title', title=f['title']))),
        ]
        li.addContextMenuItems(cm)
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=poster, mode='movie', tmdb_id=tmdb_id)
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def cache_cartelera_meta():
    import metadata_enricher as me

    films = _fetch_cartelera()
    if not films:
        xbmcgui.Dialog().notification("EspaTV", "No hay películas en cartelera", xbmcgui.NOTIFICATION_ERROR)
        return

    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaTV", "Descargando metadatos cartelera...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "EspaTV",
        "Metadatos guardados: {0}/{1}".format(count, len(items)),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_cartelera_meta():
    import metadata_enricher as me

    films = _fetch_cartelera()
    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    me.delete_items(items)
    xbmcgui.Dialog().notification("EspaTV", "Metadatos de cartelera eliminados", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def cache_estrenos_meta():
    import metadata_enricher as me

    films = _fetch_estrenos()
    if not films:
        xbmcgui.Dialog().notification("EspaTV", "No hay estrenos disponibles", xbmcgui.NOTIFICATION_ERROR)
        return

    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaTV", "Descargando metadatos estrenos...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "EspaTV",
        "Metadatos guardados: {0}/{1}".format(count, len(items)),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_estrenos_meta():
    import metadata_enricher as me

    films = _fetch_estrenos()
    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    me.delete_items(items)
    xbmcgui.Dialog().notification("EspaTV", "Metadatos de estrenos eliminados", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")
