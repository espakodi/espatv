# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Agenda Cultural Nacional: Fiestas de Interés Turístico y RSS de cultura.gob.es."""
import datetime
import json
import os
import re
import sys
import time
import urllib.parse
import xml.etree.ElementTree as ET

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_LOG     = "[EspaTV-AGC]"
_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
_CACHE_FILE = os.path.join(_PROFILE, "agenda_cultural_cache.json")
_CACHE_TTL  = 24 * 3600
_TIMEOUT    = 15
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

# (url, nombre_mostrado, color)
_FEEDS_RSS = [
    ("https://www.abc.es/rss/feeds/abc_cultura.xml",
     "ABC Cultura", "gold"),
    ("https://feeds.elpais.com/mrss-s/pages/ep/site/elpais.com/section/cultura/portada",
     "El País Cultura", "deepskyblue"),
    ("https://www.lavanguardia.com/rss/cultura.xml",
     "La Vanguardia Cultura", "plum"),
]

# Fiestas de Interés Turístico Internacional/Nacional: selección extendida
# (mes, dia_aprox, nombre, lugar, descripcion)
_FIESTAS_BIT = [
    # Enero
    (1,  17, "San Antón — La Encamisá", "Torrejoncillo (Cáceres)",
     "Fiesta de Interes Turistico Nacional. Procesion nocturna a caballo con antorchas en honor a San Antonio Abad."),
    (1,  19, "Tamborrada de San Sebastian", "San Sebastian (Guipuzcoa)",
     "Fiesta de Interes Turistico Internacional. La ciudad entera toca tambores durante 24 horas el Dia de San Sebastian."),
    (1,  20, "Fiesta del Almendro en Flor", "Tejeda (Gran Canaria)",
     "Fiesta de Interes Turistico Nacional. Celebracion de la floracion del almendro en los barrancos canarios."),
    # Febrero
    (2,  2,  "Carnaval de Santa Cruz de Tenerife", "Santa Cruz de Tenerife",
     "Fiesta de Interes Turistico Internacional. Uno de los carnavales mas famosos del mundo, con cabalgatas y eleccion de la Reina."),
    (2,  2,  "Carnaval de Cadiz", "Cadiz",
     "Fiesta de Interes Turistico Internacional. Conocido por sus chirigotas, comparsas y coplas satiricas unicas."),
    (2,  2,  "Carnaval de Las Palmas de Gran Canaria", "Las Palmas",
     "Fiesta de Interes Turistico Internacional. Segundo carnaval mas importante de Espana tras Tenerife."),
    (2,  2,  "Carnaval de Sitges", "Sitges (Barcelona)",
     "Fiesta de Interes Turistico Nacional. Carnaval con fuerte presencia artistica e internacional."),
    (2,  2,  "Carnaval de Verin", "Verin (Ourense)",
     "Fiesta de Interes Turistico Nacional. Famoso por sus Cigarrones y las mascaras tradicionales gallegas."),
    (2,  2,  "Carnaval de Aguilas", "Aguilas (Murcia)",
     "Fiesta de Interes Turistico Internacional. Uno de los mejores carnavales del sureste español."),
    (2,  2,  "Antroxu de Oviedo y Gijon", "Asturias",
     "Fiesta de Interes Turistico Nacional. El carnaval tradicional asturiano con comparsas y desfiles."),
    # Marzo
    (3,  15, "Las Fallas de Valencia", "Valencia",
     "Fiesta de Interes Turistico Internacional y Patrimonio de la Humanidad (UNESCO). Monumentos que se queman la noche del 19 de marzo."),
    (3,  19, "Semana de Musica Religiosa de Cuenca", "Cuenca",
     "Fiesta de Interes Turistico Internacional. Festival de musica sacra y polifonica de referencia mundial."),
    # Abril
    (4,  6,  "Semana Santa de Sevilla", "Sevilla",
     "Fiesta de Interes Turistico Internacional. La mas famosa de España: pasos, saetas, nazarenos y madrugada."),
    (4,  6,  "Semana Santa de Zamora", "Zamora",
     "Fiesta de Interes Turistico Internacional. Una de las mas austeras y recogidas. Declarada de Interes Internacional."),
    (4,  6,  "Semana Santa de Malaga", "Malaga",
     "Fiesta de Interes Turistico Internacional. Conocida por sus tronos y la Legion."),
    (4,  6,  "Semana Santa de Cuenca", "Cuenca",
     "Fiesta de Interes Turistico Internacional. Procesiones por la ciudad medieval con musica de tambor."),
    (4,  6,  "Semana Santa de Cartagena", "Cartagena (Murcia)",
     "Fiesta de Interes Turistico Internacional. Procesiones con imagenes barrocas y tradicion marinera."),
    (4,  6,  "Semana Santa de Hellin", "Hellin (Albacete)",
     "Fiesta de Interes Turistico Nacional. Famosa mundialmente por la Tamborada: miles de tambores suenan sin parar."),
    (4,  21, "Feria de Abril de Sevilla", "Sevilla",
     "Fiesta de Interes Turistico Internacional. Casetas, flamenco, caballos y trajes de flamenca a orillas del Guadalquivir."),
    (4,  23, "Dia de Sant Jordi", "Cataluna",
     "Fiesta de Interes Turistico Nacional. Intercambio de rosas y libros. Dia Internacional del Libro."),
    (4,  23, "Moros y Cristianos de Alcoy", "Alcoy (Alicante)",
     "Fiesta de Interes Turistico Internacional. Recreacion de batallas medievales entre moros y cristianos."),
    (4,  30, "Feria del Caballo de Jerez", "Jerez de la Frontera (Cadiz)",
     "Fiesta de Interes Turistico Nacional. Exhibicion de caballos de pura raza española, flamenco y vino de Jerez."),
    # Mayo
    (5,  1,  "Romeria del Rocio", "Almonte (Huelva)",
     "Fiesta de Interes Turistico Internacional. Mas de un millon de personas peregrinan a la aldea del Rocio en Pentecostes."),
    (5,  1,  "Las Cruces de Mayo", "Cordoba y otras ciudades",
     "Fiesta de Interes Turistico Internacional en Cordoba. Altares y cruces florales compiten por toda la ciudad."),
    (5,  1,  "Feria de San Isidro — Madrid", "Madrid",
     "Feria taurina mas importante del mundo. Ciclo de corridas en Las Ventas durante el mes de mayo."),
    (5,  1,  "Patios de Cordoba", "Cordoba",
     "Patrimonio Inmaterial de la Humanidad (UNESCO). Vecinos abren sus patios floridos al publico durante dos semanas."),
    (5,  15, "Romeria de la Virgen de la Cabeza", "Andujar (Jaen)",
     "Fiesta de Interes Turistico Internacional. Una de las romerias mas antiguas y multitudinarias de Espana."),
    (5,  25, "Corpus Christi de Toledo", "Toledo",
     "Fiesta de Interes Turistico Internacional. Procesion con la custodia por las calles medievales de la ciudad imperial."),
    (5,  25, "Corpus Christi de Sitges", "Sitges (Barcelona)",
     "Fiesta de Interes Turistico Nacional. Las calles se cubren de alfombras florales para la procesion del Corpus."),
    # Junio
    (6,  7,  "El Colacho — Salto del Obispo", "Castrillo de Murcia (Burgos)",
     "Fiesta de Interes Turistico Nacional. Hombres disfrazados del diablo saltan sobre bebes tendidos en colchones."),
    (6,  13, "La Patum de Berga", "Berga (Barcelona)",
     "Patrimonio Inmaterial de la Humanidad (UNESCO). Espectaculo de fuego, gegants y figuras medievales en Corpus Christi."),
    (6,  20, "Hogueras de San Juan de Alicante", "Alicante",
     "Fiesta de Interes Turistico Internacional. Monumentos de papel que se queman la noche de San Juan."),
    (6,  24, "Nit de Foc — San Juan de Valencia", "Valencia",
     "Fiesta de Interes Turistico Nacional. La noche de San Juan valenciana con mascletaes y hogueras."),
    (6,  24, "Foguerons de Sant Joan", "Ciutadella (Menorca)",
     "Fiesta de Interes Turistico Internacional. Jinetes hacen cabriolas a caballo entre la multitud en las fiestas de San Juan."),
    (6,  29, "Batalla del Vino", "Haro (La Rioja)",
     "Fiesta de Interes Turistico Nacional. Miles de personas se empapan de vino riojano en las bodegas de Haro."),
    # Julio
    (7,  1,  "Rapa das Bestas", "Sabucedo (Pontevedra)",
     "Fiesta de Interes Turistico Internacional. Captura y marca de caballos salvajes en los montes gallegos."),
    (7,  6,  "Sanfermines", "Pamplona (Navarra)",
     "Fiesta de Interes Turistico Internacional. Encierros con toros por las calles de Pamplona. Del 6 al 14 de julio."),
    (7,  15, "Festival de Jazz de San Sebastian", "San Sebastian",
     "Fiesta de Interes Turistico Internacional. Uno de los festivales de jazz mas prestigiosos de Europa."),
    (7,  25, "Dia de Santiago y Ofrenda al Apostol", "Santiago de Compostela",
     "Fiesta de Interes Turistico Internacional. Celebraciones del Dia de Galicia y ofrenda nacional al Apostol Santiago."),
    # Agosto
    (8,  5,  "Bajada de la Virgen de las Nieves", "Santa Cruz de La Palma",
     "Fiesta de Interes Turistico Internacional. Se celebra cada 5 anos. La Palma para en pleno agosto."),
    (8,  7,  "Misterio de Elche", "Elche (Alicante)",
     "Patrimonio Inmaterial de la Humanidad (UNESCO). Drama sacro lirico del siglo XIII interpretado en la Basilica de Santa Maria."),
    (8,  13, "FIB — Festival Internacional de Benicassim", "Benicassim (Castellon)",
     "Festival de musica alternativa y rock de referencia en Europa. Celebrado cada agosto desde 1995."),
    (8,  14, "La Tomatina de Bunol", "Bunol (Valencia)",
     "Fiesta de Interes Turistico Internacional. Batalla de tomates el ultimo miercoles de agosto."),
    (8,  22, "Semana Grande de San Sebastian", "San Sebastian",
     "Fiesta de Interes Turistico Internacional. Fiestas patronales con fuegos artificiales sobre la bahia de La Concha."),
    (8,  24, "Semana Grande de Bilbao — Aste Nagusia", "Bilbao",
     "Fiesta de Interes Turistico Nacional. Fiestas patronales de Bilbao con la Marijaia como simbolo festivo."),
    # Septiembre
    (9,  7,  "Vendimia de La Rioja", "Logroño",
     "Fiesta de Interes Turistico Nacional. Celebracion de la vendimia con la Ofrenda de Frutos a la Virgen del Camino."),
    (9,  11, "Diada Nacional de Catalunya", "Cataluna",
     "Dia Nacional de Cataluna. Actos y concentraciones conmemorativos en toda la region."),
    (9,  13, "Festival de Cine de San Sebastian", "San Sebastian",
     "Uno de los festivales de cine mas prestigiosos del mundo. La Concha de Oro premia lo mejor del cine internacional."),
    (9,  15, "Feria de Pedro Romero — Corrida Goyesca", "Ronda (Malaga)",
     "Fiesta de Interes Turistico Nacional. Corrida goyesca donde los toreros visten trajes del siglo XVIII."),
    (9,  20, "Fiesta del Marisco de O Grove", "O Grove (Pontevedra)",
     "Fiesta de Interes Turistico Nacional. El mejor marisco gallego en una feria multitudinaria."),
    (9,  25, "Vendimia de Jerez", "Jerez de la Frontera",
     "Fiesta de Interes Turistico Nacional. Pisado de la uva en honor a la Virgen de la Merced."),
    (9,  25, "Vendimia de Requena", "Requena (Valencia)",
     "Fiesta de Interes Turistico Nacional. Celebracion de la vendimia en la capital de la uva valenciana."),
    # Octubre
    (10, 8,  "El Pilar de Zaragoza", "Zaragoza",
     "Fiesta de Interes Turistico Internacional. Ofrenda de Flores a la Virgen del Pilar y procesion del Rosario de Cristal."),
    (10, 20, "Moros y Cristianos de Crevillent", "Crevillent (Alicante)",
     "Fiesta de Interes Turistico Nacional. Una de las fiestas de Moros y Cristianos mas antiguas de la Comunitat Valenciana."),
    # Noviembre
    (11, 1,  "Todos los Santos", "Espana",
     "Tradicion espanola de visitar cementerios, comer bunuelos y castanas asadas."),
    (11, 11, "Magostos y Castanadas", "Galicia y Cataluna",
     "Fiesta popular de otono: castanas asadas y celebraciones de la cosecha."),
    # Diciembre
    (12, 22, "El Gordo — Loteria de Navidad", "Espana",
     "El sorteo de Navidad de la Loteria Nacional, el mas grande del mundo por volumen de premios."),
    (12, 24, "Navidad y Belenes Vivientes", "Espana",
     "Tradicion navidena española: belenes vivientes, cabalgatas de Reyes y celebraciones familiares."),
]

_MESES_ES = ["", "Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio",
             "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"]


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _days_until(month, day):
    today = datetime.date.today()
    try:
        target = datetime.date(today.year, month, day)
        if target < today:
            target = datetime.date(today.year + 1, month, day)
        return (target - today).days
    except ValueError:
        return None


def _fetch_rss(feed_url):
    import hashlib as _hl
    cache_key = "rss_" + _hl.md5(feed_url.encode()).hexdigest()[:12]
    try:
        with open(_CACHE_FILE, "r", encoding="utf-8") as f:
            obj = json.load(f)
        entry = obj.get(cache_key, {})
        if time.time() - entry.get("ts", 0) < _CACHE_TTL:
            return entry.get("items", [])
    except (OSError, ValueError):
        pass

    try:
        headers = {
            "User-Agent": "EspaTV/1.0 (Kodi addon; agenda cultural)",
            "Accept": "application/rss+xml, */*",
        }
        resp = requests.get(feed_url, headers=headers, timeout=_TIMEOUT)
        resp.raise_for_status()
        root = ET.fromstring(resp.content)
        channel = root.find("channel")
        items = []
        if channel is not None:
            for item in channel.findall("item")[:20]:
                title = (item.findtext("title") or "").strip()
                desc  = (item.findtext("description") or "").strip()
                pub   = (item.findtext("pubDate") or "").strip()
                if title:
                    items.append({"title": title, "desc": desc, "pub": pub})
        try:
            with open(_CACHE_FILE, "r", encoding="utf-8") as f:
                obj = json.load(f)
        except (OSError, ValueError):
            obj = {}
        obj[cache_key] = {"ts": time.time(), "items": items}
        with open(_CACHE_FILE, "w", encoding="utf-8") as f:
            json.dump(obj, f, ensure_ascii=False)
        return items
    except Exception as e:
        xbmc.log("{0} Error RSS {1}: {2}".format(_LOG, feed_url[:60], e), xbmc.LOGWARNING)
        return []


def agenda_menu():
    h = int(sys.argv[1])
    icon = _icon("cat_agenda_cultural.png")
    today = datetime.date.today()

    # Sección: Noticias de Cultura (múltiples fuentes RSS)
    for feed_url, feed_label, feed_color in _FEEDS_RSS:
        li_noticias = xbmcgui.ListItem(
            label="[B][COLOR {0}]{1}[/COLOR][/B]".format(feed_color, feed_label)
        )
        li_noticias.setArt({"icon": icon})
        li_noticias.setInfo("video", {"plot": "Ultimas noticias de {0}.".format(feed_label)})
        li_noticias.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="agenda_cultural_noticias", feed_url=feed_url, feed_label=feed_label),
            listitem=li_noticias, isFolder=True,
        )

    sep = xbmcgui.ListItem(label="[COLOR gold]──  Fiestas de Interés Turístico  ──[/COLOR]")
    sep.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=sep, isFolder=False)

    # Fiestas ordenadas por proximidad (precomputar _days_until una vez por entrada)
    _fiestas_with_days = [(_days_until(m, d), m, d, n, l, desc) for m, d, n, l, desc in _FIESTAS_BIT]
    fiestas_sorted = sorted(
        [(dl, m, d, n, l, desc) for dl, m, d, n, l, desc in _fiestas_with_days if dl is not None],
        key=lambda x: x[0],
    )
    mes_actual = 0
    for days_left, mes, dia, nombre, lugar, desc in fiestas_sorted:

        if mes != mes_actual:
            mes_actual = mes
            sep_mes = xbmcgui.ListItem(label="[COLOR grey]── {0} ──[/COLOR]".format(_MESES_ES[mes]))
            sep_mes.setProperty("IsPlayable", "false")
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="noop"), listitem=sep_mes, isFolder=False)

        if days_left <= 7:
            color = "gold"
        elif days_left <= 30:
            color = "khaki"
        else:
            color = "white"

        resta = ""
        if days_left == 0:
            resta = "  [COLOR tomato]¡HOY![/COLOR]"
        elif days_left <= 30:
            resta = "  [COLOR {0}]en {1}d[/COLOR]".format(color, days_left)

        label = "[B][COLOR {0}]{1}[/COLOR][/B]{2}   [COLOR grey]{3}[/COLOR]".format(
            color, nombre, resta, lugar
        )
        plot  = "{0}\n{1}\n\n{2}".format(nombre, lugar, desc)
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon})
        li.setInfo("video", {"title": nombre, "plot": plot})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="agenda_cultural_fiesta", title=nombre, plot=plot),
            listitem=li,
            isFolder=False,
        )

    xbmcplugin.endOfDirectory(h)


def agenda_cultural_noticias(feed_url="", feed_label="Noticias de Cultura"):
    h = int(sys.argv[1])
    xbmcplugin.setPluginCategory(h, feed_label)
    icon = _icon("cat_agenda_cultural.png")
    url = feed_url or _FEEDS_RSS[0][0]
    items = _fetch_rss(url)
    if not items:
        li = xbmcgui.ListItem(label="[COLOR grey]Sin noticias disponibles en este momento[/COLOR]")
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return
    for it in items:
        plot = "{0}\n\n{1}\n\n{2}".format(it["title"], it.get("pub", ""), it.get("desc", ""))
        li = xbmcgui.ListItem(label=it["title"])
        li.setArt({"icon": icon})
        li.setInfo("video", {"title": it["title"], "plot": plot})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="agenda_cultural_fiesta", title=it["title"], plot=plot),
            listitem=li,
            isFolder=False,
        )
    xbmcplugin.endOfDirectory(h)


def agenda_cultural_fiesta(title, plot):
    xbmcgui.Dialog().textviewer(title, plot)
