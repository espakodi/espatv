# EspaTV — Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""FilmAffinity / TMDB: cartelera, top y catálogo por géneros."""
import html
import json
import os
import re
import ssl
import sys
import threading
import time
import urllib.parse
from concurrent.futures import ThreadPoolExecutor, as_completed

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings
from _user_agents import desktop_headers as _dh, ACCEPT_HTML

_TMDB_API = "https://api.themoviedb.org/3"
_TMDB_IMG = "https://image.tmdb.org/t/p/w342"

_FA_BASE = "https://www.filmaffinity.com/es"
_FA_HEADERS = _dh(accept=ACCEPT_HTML, referer="https://www.filmaffinity.com/es/")
_CARTELERA_TTL = 6 * 3600
_TOPFA_TTL = 7 * 24 * 3600  # el top de la comunidad cambia poco; refresco semanal
_FA_MIN_FILMS = 3


class _Tls13Adapter(requests.adapters.HTTPAdapter):
    # Cloudflare sirve un managed challenge (HTTP 403) al fingerprint TLS del
    # Python 3.8 de Kodi cuando negocia TLS 1.2. Forzando TLS 1.3 el handshake
    # pasa: el bloqueo es de capa TLS, cambiar cabeceras no tiene efecto.
    def init_poolmanager(self, *args, **kwargs):
        ctx = ssl.create_default_context()
        ctx.minimum_version = ssl.TLSVersion.TLSv1_3
        kwargs["ssl_context"] = ctx
        return super().init_poolmanager(*args, **kwargs)


def _fa_get(url, timeout=12):
    with requests.Session() as s:
        s.mount("https://", _Tls13Adapter())
        return s.get(url, headers=_FA_HEADERS, timeout=timeout)

_GENRES = [
    ("Top General",     "movie", ""),
    ("Accion",          "movie", "28"),
    ("Animacion",       "movie", "16"),
    ("Aventura",        "movie", "12"),
    ("Comedia",         "movie", "35"),
    ("Ciencia Ficcion", "movie", "878"),
    ("Documental",      "movie", "99"),
    ("Drama",           "movie", "18"),
    ("Fantasia",        "movie", "14"),
    ("Terror",          "movie", "27"),
    ("Thriller",        "movie", "53"),
    ("Musical",         "movie", "10402"),
    ("Western",         "movie", "37"),
    ("Belica",          "movie", "10752"),
    ("Series TV",       "tv",    ""),
]

def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def _handle():
    return int(sys.argv[1])

def _media_icon(name, fallback='DefaultVideoPlaylists.png'):
    p = os.path.join(
        xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('path')),
        'resources', 'media', name,
    )
    return p if os.path.exists(p) else fallback

_GENRE_ICONS = {
    "":      'top_mejores.png',
    "28":    'top_accion.png',
    "16":    'top_animacion.png',
    "12":    'top_aventura.png',
    "35":    'top_comedia.png',
    "878":   'top_scifi.png',
    "99":    'cat_documentales.png',
    "18":    'top_drama.png',
    "14":    'top_fantasia.png',
    "27":    'top_terror.png',
    "53":    'top_thriller.png',
    "10402": 'cat_musica.png',
    "37":    'top_western.png',
    "10752": 'top_belica.png',
    "tv":    'cat_series.png',
}

def _fetch(media_type, genre_id):
    params = {
        "api_key": core_settings.get_tmdb_api_key(),
        "language": "es-ES",
        "region": "ES",
        "sort_by": "vote_average.desc",
        "vote_count.gte": 1000,
        "page": 1,
    }
    if genre_id:
        params["with_genres"] = genre_id
    try:
        r = requests.get(
            "{0}/discover/{1}".format(_TMDB_API, media_type),
            params=params, timeout=10,
        )
        xbmc.log("[EspaTV-TMDB] {0} -> {1}".format(r.url, r.status_code), xbmc.LOGINFO)
        if r.status_code != 200:
            return []
        movies = []
        for item in r.json().get("results", []):
            title  = item.get("title") or item.get("name", "")
            date   = item.get("release_date") or item.get("first_air_date", "")
            year   = int(date[:4]) if date and len(date) >= 4 else 0
            path   = item.get("poster_path", "")
            poster = "{0}{1}".format(_TMDB_IMG, path) if path else ""
            movies.append({
                "title": title, "year": year, "poster": poster,
                "tmdb_id": item.get("id"), "media_type": media_type,
            })
        return movies
    except (requests.RequestException, ValueError) as e:
        xbmc.log("[EspaTV-TMDB] Error: {0}".format(e), xbmc.LOGERROR)
        return []

def menu():
    for label, media_type, genre_id in _GENRES:
        li = xbmcgui.ListItem(label=label)
        icon_key = media_type if media_type == 'tv' and not genre_id else genre_id
        li.setArt({'icon': _media_icon(_GENRE_ICONS.get(icon_key, 'top_mejores.png'))})
        url = _u(action="filmaffinity_list", genre="{0}:{1}".format(media_type, genre_id))
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(_handle())

def show_list(genre):
    import pelis_grid as _pg
    _lbl = 'Series' if genre.startswith('tv') else 'Películas'
    if _pg.apply_grid_mode(_handle(), 'filmaffinity_list', 'Top {0} TMDB'.format(_lbl), genre=genre):
        return

    import metadata_enricher as me

    media_type, genre_id = genre.split(":", 1) if ":" in genre else ("movie", genre)
    movies = _fetch(media_type, genre_id)
    if not movies:
        xbmcgui.Dialog().notification("EspaTV", "No se pudieron cargar los titulos", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = xbmcaddon.Addon().getAddonInfo('fanart')
    canon_type = 'show' if media_type == 'tv' else 'movie'
    enrich_items = [{'tmdb_id': m['tmdb_id'], 'title': m['title'], 'year': m['year'],
                     'media_type': canon_type} for m in movies]
    metas = me.batch_enrich(enrich_items, use_cache_only=False, max_workers=4)

    for m, meta in zip(movies, metas):
        label = "{0} ({1})".format(m['title'], m['year']) if m['year'] else m['title']
        li = xbmcgui.ListItem(label=label)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or m['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': m['poster'], 'poster': m['poster']})
            li.setInfo('video', {'title': m['title'], 'year': m['year'], 'mediatype': 'movie'})
            poster = m['poster']
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=m['title'], ot=poster, mode=canon_type, tmdb_id=m['tmdb_id'])
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'espatv_fa_cache.json')


def _load_cache():
    empty = {"cartelera": {}, "posters": {}, "top": {}, "topfa": {}, "cat": {}}
    try:
        path = _cache_path()
        if not os.path.exists(path):
            return empty
        with open(path, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        for key in empty:
            if not isinstance(data.get(key), dict):
                data[key] = {}
        return data
    except (OSError, ValueError) as e:
        xbmc.log("[EspaTV-FA] cache load error: {0}".format(e), xbmc.LOGWARNING)
        return empty


def _save_cache(data):
    # tmp ÚNICO por hilo: dos escrituras concurrentes con el mismo .tmp se pisaban y
    # dejaban el JSON corrupto ("Extra data"), lo que vaciaba toda la caché al leerla.
    path = _cache_path()
    tmp = '{0}.{1}.tmp'.format(path, threading.get_ident())
    try:
        os.makedirs(os.path.dirname(path), exist_ok=True)
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, path)
    except OSError as e:
        xbmc.log("[EspaTV-FA] cache save error: {0}".format(e), xbmc.LOGWARNING)
        try:
            os.remove(tmp)
        except OSError:
            pass


def _cartelera_fresh(cache):
    c = cache.get("cartelera", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _CARTELERA_TTL


# En FA, las series llevan el sufijo "(Serie de TV)" / "(Miniserie de TV)" en el título.
_FA_TV_SUFFIX = re.compile(r'\s*\((?:Mini)?[Ss]erie de TV[^)]*\)\s*$')


def _split_type(title):
    # 'Rick y Morty (Serie de TV)' -> ('Rick y Morty', 'show')
    if _FA_TV_SUFFIX.search(title):
        return _FA_TV_SUFFIX.sub('', title).strip(), 'show'
    return title, 'movie'


def _scrape_cat(path):
    """Scrapea una página cat_*.html (cartelera, plataformas, alquiler...).

    Todas comparten el markup: data-movie-id + movie-title + póster en
    pics.filmaffinity.com. Devuelve dicts {id, title, poster, media_type}.
    """
    try:
        r = _fa_get("{0}/{1}".format(_FA_BASE, path))
        xbmc.log("[EspaTV-FA] {0} -> {1}".format(path, r.status_code), xbmc.LOGINFO)
        if r.status_code != 200:
            return None
        films = []
        seen = set()
        for block in re.split(r'(?=<div[^>]+data-movie-id=")', r.text):
            id_m = re.search(r'data-movie-id="(\d+)"', block)
            if not id_m:
                continue
            fid = id_m.group(1)
            if fid in seen:
                continue
            title_m = re.search(r'class="[^"]*movie-title[^"]*"[^>]*title="([^"]+)"', block)
            if not title_m:
                title_m = re.search(r'class="poster-wrap"[^>]*title="([^"]+)"', block)
            if not title_m:
                continue
            seen.add(fid)
            title, media_type = _split_type(html.unescape(title_m.group(1).strip()))
            poster_m = re.search(r'(https://pics\.filmaffinity\.com/[^"\s]+\.jpg)', block)
            poster = poster_m.group(1).replace("-msmall.jpg", "-large.jpg").replace("-mmed.jpg", "-large.jpg") if poster_m else ""
            films.append({'id': fid, 'title': title, 'poster': poster, 'media_type': media_type})
        if len(films) < _FA_MIN_FILMS:
            xbmc.log(
                "[EspaTV-FA] {0}: resultado sospechoso ({1} films), ignorando".format(path, len(films)),
                xbmc.LOGWARNING,
            )
            return None
        xbmc.log("[EspaTV-FA] {0}: scrapeadas {1} películas".format(path, len(films)), xbmc.LOGINFO)
        return films
    except (requests.RequestException, ValueError) as e:
        xbmc.log("[EspaTV-FA] {0} scrape error: {1}".format(path, e), xbmc.LOGERROR)
        return None


def _scrape_filmaffinity():
    return _scrape_cat("cat_new_th_es.html")


def _tmdb_poster(title):
    try:
        r = requests.get(
            "{0}/search/movie".format(_TMDB_API),
            params={"api_key": core_settings.get_tmdb_api_key(), "query": title, "language": "es-ES"},
            timeout=8,
        )
        if r.status_code != 200:
            return ""
        results = r.json().get("results", [])
        if not results:
            return ""
        path = results[0].get("poster_path", "")
        return "{0}{1}".format(_TMDB_IMG, path) if path else ""
    except (requests.RequestException, ValueError):
        return ""


def _resolve_posters(films, poster_cache):
    _key = lambda t: t.lower().strip()
    misses = [f for f in films if _key(f['title']) not in poster_cache]
    if misses:
        xbmc.log("[EspaTV-FA] TMDB: {0} posters nuevos a resolver".format(len(misses)), xbmc.LOGINFO)
        with ThreadPoolExecutor(max_workers=8) as ex:
            future_map = {ex.submit(_tmdb_poster, f['title']): f['title'] for f in misses}
            for future in as_completed(future_map):
                title = future_map[future]
                poster_cache[_key(title)] = future.result()
    return [dict(f, poster=poster_cache.get(_key(f['title']), '')) for f in films]


def _fetch_en_cines():
    cache = _load_cache()

    if _cartelera_fresh(cache):
        films = cache["cartelera"]["films"]
        xbmc.log(
            "[EspaTV-FA] cartelera desde caché ({0} títulos)".format(len(films)),
            xbmc.LOGINFO,
        )
    else:
        scraped = _scrape_filmaffinity()
        if scraped is not None:
            films = scraped
            cache["cartelera"] = {"fetched_at": time.time(), "films": films}
        elif cache.get("cartelera", {}).get("films"):
            films = cache["cartelera"]["films"]
            xbmc.log("[EspaTV-FA] FA inaccesible, usando caché caducada", xbmc.LOGWARNING)
        else:
            return []

    poster_cache = cache.setdefault("posters", {})
    films_with_posters = _resolve_posters(films, poster_cache)
    _save_cache(cache)
    return films_with_posters


def _trigger_bg_enrich(films):
    import metadata_enricher as me
    def _fetch():
        try:
            items = [{'title': f['title'], 'media_type': f.get('media_type', 'movie')} for f in films]
            results = me.batch_enrich(items, max_workers=2)
            if any(results):
                xbmc.executebuiltin("Container.Refresh")
        except Exception:
            pass
    threading.Thread(target=_fetch, daemon=True).start()


def show_cartelera():
    import pelis_grid as _pg
    if _pg.apply_grid_mode(_handle(), 'filmaffinity_cartelera', 'En Cines España'):
        return

    import metadata_enricher as me

    films = _fetch_en_cines()
    if not films:
        xbmcgui.Dialog().notification("EspaTV", "No se pudo cargar FilmAffinity", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = xbmcaddon.Addon().getAddonInfo('fanart')
    first_title = films[0]['title'] if films else None
    has_meta = bool(me.enrich(title=first_title, media_type='movie', use_cache_only=True)) if first_title else False
    if not has_meta:
        _trigger_bg_enrich(films)

    for f in films:
        li = xbmcgui.ListItem(label=f['title'])
        meta = me.enrich(title=f['title'], media_type='movie', use_cache_only=True)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster']})
            li.setInfo('video', {'title': f['title'], 'mediatype': 'movie'})
            poster = f['poster']
        tmdb_id = (meta.get('ids') or {}).get('tmdb', '') if meta else ''
        cm = [
            ("¿Dónde ver en España?", "RunPlugin({0})".format(
                _u(action='show_watch_providers', title=f['title'], tmdb_id=tmdb_id))),
            ("Buscar en más fuentes", "Container.Update({0})".format(
                _u(action='search_movie_multi', q=f['title'], tmdb_id=tmdb_id, media_type='movie'))),
        ]
        li.addContextMenuItems(cm)
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=poster, mode='movie', tmdb_id=tmdb_id)
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


# Secciones cat_*.html: novedades por plataforma, cines por país y alquiler/venta.
# Todas comparten parser (_scrape_cat) y se sirven por show_cat(src) / un único
# loader de grid. En cines España (cat_new_th_es) NO está aquí: es la cartelera.
_CAT_SECTIONS = [
    {"src": "netflix",      "label": "Novedades Netflix",          "path": "cat_new_netflix.html",   "icon": "top_netflix.png",    "group": "streaming", "ttl": 12 * 3600},
    {"src": "hbo",          "label": "Novedades HBO Max",          "path": "cat_new_hbo_es.html",    "icon": "top_max.png",        "group": "streaming", "ttl": 12 * 3600},
    {"src": "amazon",       "label": "Novedades Prime Video",      "path": "cat_new_amazon_es.html", "icon": "top_amazon.png",     "group": "streaming", "ttl": 12 * 3600},
    {"src": "disney",       "label": "Novedades Disney+",          "path": "cat_disneyplus.html",    "icon": "top_disney.png",     "group": "streaming", "ttl": 12 * 3600},
    {"src": "movistar",     "label": "Novedades Movistar Plus+",   "path": "cat_new_movistar_f.html","icon": "top_movistar.png",   "group": "streaming", "ttl": 12 * 3600},
    {"src": "filmin",       "label": "Novedades Filmin",           "path": "cat_new_filmin.html",    "icon": "fa_filmin.png",      "group": "streaming", "ttl": 12 * 3600},
    {"src": "apple",        "label": "Novedades Apple TV+",        "path": "cat_apple_tv_plus.html", "icon": "top_appletv.png",    "group": "streaming", "ttl": 12 * 3600},
    {"src": "skyshowtime",  "label": "Novedades SkyShowtime",      "path": "cat_skyshowtime.html",   "icon": "fa_skyshowtime.png", "group": "streaming", "ttl": 12 * 3600},
    {"src": "th_us",        "label": "En cines (USA)",             "path": "cat_new_th_us.html",     "icon": "fa_cines_intl.png",  "group": "cines",     "ttl": 12 * 3600},
    {"src": "th_uk",        "label": "En cines (Reino Unido)",     "path": "cat_new_th_uk.html",     "icon": "fa_cines_intl.png",  "group": "cines",     "ttl": 12 * 3600},
    {"src": "th_fr",        "label": "En cines (Francia)",         "path": "cat_new_th_fr.html",     "icon": "fa_cines_intl.png",  "group": "cines",     "ttl": 12 * 3600},
    {"src": "rent",         "label": "Novedades en alquiler",      "path": "cat_new_re_es.html",     "icon": "fa_alquiler.png",    "group": "rent",      "ttl": 12 * 3600},
    {"src": "buy",          "label": "Novedades en venta",         "path": "cat_new_sa_es.html",     "icon": "fa_venta.png",       "group": "rent",      "ttl": 12 * 3600},
    {"src": "upc_movistar", "label": "Próximos en Movistar Plus+", "path": "cat_upc_movistar_f.html","icon": "top_movistar.png",   "group": "otros",     "ttl": _CARTELERA_TTL},
    {"src": "current_tv",   "label": "Actualidad TV",              "path": "cat_current_tv.html",    "icon": "top_encines_tv.png", "group": "otros",     "ttl": _CARTELERA_TTL},
]


def _cat_section(src):
    return next((s for s in _CAT_SECTIONS if s["src"] == src), None)


def cat_sections_for(group):
    """Secciones de un grupo, para construir los submenús en default.py."""
    return [s for s in _CAT_SECTIONS if s["group"] == group]


def _cat_fresh(cache, src, ttl):
    c = cache.get("cat", {}).get(src, {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < ttl


def _fetch_cat(src):
    section = _cat_section(src)
    if not section:
        return []
    cache = _load_cache()
    catcache = cache.setdefault("cat", {})
    if _cat_fresh(cache, src, section["ttl"]):
        films = catcache[src]["films"]
        xbmc.log("[EspaTV-FA] {0} desde caché ({1} títulos)".format(src, len(films)), xbmc.LOGINFO)
        return films
    scraped = _scrape_cat(section["path"])
    if scraped is not None:
        films = scraped
        catcache[src] = {"fetched_at": time.time(), "films": films}
    elif catcache.get(src, {}).get("films"):
        films = catcache[src]["films"]
        xbmc.log("[EspaTV-FA] {0} inaccesible, usando caché caducada".format(src), xbmc.LOGWARNING)
    else:
        return []
    _save_cache(cache)
    return films


def show_cat(src):
    section = _cat_section(src)
    if not section:
        xbmcplugin.endOfDirectory(_handle())
        return

    import pelis_grid as _pg
    if _pg.apply_grid_mode(_handle(), 'filmaffinity_cat', section["label"], src=src):
        return

    import metadata_enricher as me

    films = _fetch_cat(src)
    if not films:
        xbmcgui.Dialog().notification("EspaTV", "No se pudo cargar FilmAffinity", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = xbmcaddon.Addon().getAddonInfo('fanart')
    first = films[0]
    has_meta = bool(me.enrich(title=first['title'], media_type=first.get('media_type', 'movie'), use_cache_only=True))
    if not has_meta:
        _trigger_bg_enrich(films)

    for f in films:
        media_type = f.get('media_type', 'movie')
        li = xbmcgui.ListItem(label=f['title'])
        meta = me.enrich(title=f['title'], media_type=media_type, use_cache_only=True)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f.get('poster', '')
        else:
            poster = f.get('poster', '')
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': poster, 'poster': poster})
            li.setInfo('video', {'title': f['title'], 'mediatype': 'tvshow' if media_type == 'show' else 'movie'})
        # "¿Dónde ver?" y "Buscar en más fuentes" son movie-only (fetch_watch_providers
        # y search_movie_multi usan /movie/); para series darían datos erróneos.
        if media_type == 'movie':
            tmdb_id = (meta.get('ids') or {}).get('tmdb', '') if meta else ''
            li.addContextMenuItems([
                ("¿Dónde ver en España?", "RunPlugin({0})".format(
                    _u(action='show_watch_providers', title=f['title'], tmdb_id=tmdb_id))),
                ("Buscar en más fuentes", "Container.Update({0})".format(
                    _u(action='search_movie_multi', q=f['title'], tmdb_id=tmdb_id, media_type='movie'))),
            ])
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=poster,
                 mode='show' if media_type == 'show' else 'movie', tmdb_id=tmdb_id)
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def _top_fresh(cache):
    c = cache.get("top", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _CARTELERA_TTL


def _fetch_tmdb_top_rated():
    try:
        r = requests.get(
            "{0}/movie/top_rated".format(_TMDB_API),
            params={"api_key": core_settings.get_tmdb_api_key(), "language": "es-ES", "page": 1},
            timeout=12,
        )
        xbmc.log("[EspaTV-FA] top_rated -> {0}".format(r.status_code), xbmc.LOGINFO)
        if r.status_code != 200:
            return None
        films = []
        for m in r.json().get("results", []):
            title = m.get("title", "").strip()
            if not title:
                continue
            poster_path = m.get("poster_path", "")
            poster = "{0}{1}".format(_TMDB_IMG, poster_path) if poster_path else ""
            year = str(m.get("release_date", ""))[:4]
            rating = "{0:.1f}".format(m.get("vote_average", 0))
            films.append({"tmdb_id": m.get("id"), "id": str(m.get("id", "")),
                          "title": title, "year": year, "rating": rating, "poster": poster,
                          "overview": m.get("overview", "")})
        if len(films) < _FA_MIN_FILMS:
            xbmc.log(
                "[EspaTV-FA] top_rated sospechoso ({0} films), ignorando".format(len(films)),
                xbmc.LOGWARNING,
            )
            return None
        xbmc.log("[EspaTV-FA] top_rated: {0} películas".format(len(films)), xbmc.LOGINFO)
        return films
    except (requests.RequestException, ValueError) as e:
        xbmc.log("[EspaTV-FA] top_rated error: {0}".format(e), xbmc.LOGERROR)
        return None


def _fetch_top():
    cache = _load_cache()
    if _top_fresh(cache):
        films = cache["top"]["films"]
        xbmc.log(
            "[EspaTV-FA] top desde caché ({0} títulos)".format(len(films)),
            xbmc.LOGINFO,
        )
        return films
    fetched = _fetch_tmdb_top_rated()
    if fetched is not None:
        films = fetched
        cache["top"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("top", {}).get("films"):
        films = cache["top"]["films"]
        xbmc.log("[EspaTV-FA] TMDB inaccesible, usando caché top caducada", xbmc.LOGWARNING)
    else:
        return []
    _save_cache(cache)
    return films


def show_top():
    import pelis_grid as _pg
    mode = _pg.get_grid_mode()
    if mode == 'grid':
        xbmcplugin.endOfDirectory(_handle(), succeeded=False)
        _pg.show_from_filmaffinity_top()
        return

    import metadata_enricher as me

    films = _fetch_top()
    if not films:
        xbmcgui.Dialog().notification("EspaTV", "No se pudo cargar FilmAffinity Top", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = xbmcaddon.Addon().getAddonInfo('fanart')
    if mode == 'boton':
        icon_grid = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media', 'modo_grid.png')
        li_grid = xbmcgui.ListItem(label='[COLOR FF38BDF8][B]Modo Grid[/B][/COLOR]')
        li_grid.setArt({'icon': icon_grid})
        li_grid.setInfo('video', {'plot': 'Vista inmersiva de las top valoradas al estilo Netflix.'})
        li_grid.setProperty('IsPlayable', 'false')
        xbmcplugin.addDirectoryItem(handle=_handle(), url=_u(action='pelis_grid_filmaffinity'),
                                    listitem=li_grid, isFolder=False)
    enrich_items = [{'tmdb_id': f.get('tmdb_id') or f.get('id'), 'title': f['title'],
                     'year': int(f['year']) if f.get('year', '').isdigit() else None,
                     'media_type': 'movie'} for f in films]
    metas = me.batch_enrich(enrich_items, use_cache_only=False, max_workers=4)

    for f, meta in zip(films, metas):
        year_int = int(f['year']) if f.get('year', '').isdigit() else 0
        label = "{0} ({1})".format(f['title'], year_int) if year_int else f['title']
        li = xbmcgui.ListItem(label=label)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster']})
            header = me.build_plot_header(f.get('rating'), None)
            li.setInfo('video', {
                'title':     f['title'],
                'year':      year_int,
                'plot':      header + f.get('overview', ''),
                'mediatype': 'movie',
            })
            poster = f['poster']
        tmdb_id = (meta.get('ids') or {}).get('tmdb', '') if meta else f.get('tmdb_id', '')
        cm = [
            ("¿Dónde ver en España?", "RunPlugin({0})".format(
                _u(action='show_watch_providers', title=f['title'], tmdb_id=tmdb_id))),
            ("Buscar en más fuentes", "Container.Update({0})".format(
                _u(action='search_movie_multi', q=f['title'], tmdb_id=tmdb_id, media_type='movie'))),
        ]
        li.addContextMenuItems(cm)
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=poster, mode='movie', tmdb_id=tmdb_id)
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def _scrape_topgen():
    try:
        r = _fa_get("{0}/topgen.php".format(_FA_BASE))
        xbmc.log("[EspaTV-FA] topgen -> {0}".format(r.status_code), xbmc.LOGINFO)
        if r.status_code != 200:
            return None
        films = []
        seen = set()
        for block in re.split(r'(?=<div[^>]+data-movie-id=")', r.text):
            id_m = re.search(r'data-movie-id="(\d+)"', block)
            if not id_m:
                continue
            fid = id_m.group(1)
            if fid in seen:
                continue
            title_m = re.search(r'class="mc-title"[^>]*>\s*<a[^>]*title="([^"]+)"', block)
            if not title_m:
                title_m = re.search(r'class="mc-title"[^>]*>\s*<a[^>]*>([^<]+)</a>', block)
            if not title_m:
                continue
            seen.add(fid)
            title = html.unescape(title_m.group(1).strip())
            year_m = re.search(r'class="mc-year">(\d{4})', block)
            year = year_m.group(1) if year_m else ""
            poster_m = re.search(r'<img[^>]+(?:data-src|src)="(https://pics\.filmaffinity\.com/[^"]+)"', block)
            poster = poster_m.group(1) if poster_m else ""
            if poster:
                poster = poster.replace("-msmall.jpg", "-large.jpg").replace("-mmed.jpg", "-large.jpg")
            rating_m = re.search(r'class="avg-rating">([\d,\.]+)', block)
            rating = rating_m.group(1).replace(",", ".") if rating_m else ""
            director_m = re.search(r'class="mc-director"[^>]*>.*?<a[^>]*title="([^"]+)"', block, re.DOTALL)
            if not director_m:
                director_m = re.search(r'class="mc-director"[^>]*>.*?<a[^>]*>([^<]+)</a>', block, re.DOTALL)
            director = html.unescape(director_m.group(1).strip()) if director_m else ""
            films.append({'id': fid, 'title': title, 'year': year, 'poster': poster,
                          'rating': rating, 'director': director})
        if len(films) < _FA_MIN_FILMS:
            xbmc.log(
                "[EspaTV-FA] topgen sospechoso ({0} films), ignorando".format(len(films)),
                xbmc.LOGWARNING,
            )
            return None
        xbmc.log("[EspaTV-FA] topgen: {0} películas".format(len(films)), xbmc.LOGINFO)
        return films
    except (requests.RequestException, ValueError) as e:
        xbmc.log("[EspaTV-FA] topgen error: {0}".format(e), xbmc.LOGERROR)
        return None


def _topfa_fresh(cache):
    c = cache.get("topfa", {})
    return bool(c.get("films")) and (time.time() - c.get("fetched_at", 0)) < _TOPFA_TTL


def _fetch_topfa():
    cache = _load_cache()
    if _topfa_fresh(cache):
        films = cache["topfa"]["films"]
        xbmc.log("[EspaTV-FA] topfa desde caché ({0} títulos)".format(len(films)), xbmc.LOGINFO)
        return films
    fetched = _scrape_topgen()
    if fetched is not None:
        films = fetched
        cache["topfa"] = {"fetched_at": time.time(), "films": films}
    elif cache.get("topfa", {}).get("films"):
        films = cache["topfa"]["films"]
        xbmc.log("[EspaTV-FA] topgen inaccesible, usando caché caducada", xbmc.LOGWARNING)
    else:
        return []
    _save_cache(cache)
    return films


def show_topfa():
    import pelis_grid as _pg
    if _pg.apply_grid_mode(_handle(), 'filmaffinity_topfa', 'Top FilmAffinity'):
        return

    import metadata_enricher as me

    films = _fetch_topfa()
    if not films:
        xbmcgui.Dialog().notification("EspaTV", "No se pudo cargar Top FilmAffinity", xbmcgui.NOTIFICATION_ERROR)
        xbmcplugin.endOfDirectory(_handle())
        return

    af = xbmcaddon.Addon().getAddonInfo('fanart')
    # Los items de topgen NO traen tmdb_id (el 'id' es de FilmAffinity): enriquecer por título+año.
    enrich_items = [{'title': f['title'],
                     'year': int(f['year']) if f.get('year', '').isdigit() else None,
                     'media_type': 'movie'} for f in films]
    metas = me.batch_enrich(enrich_items, use_cache_only=False, max_workers=4)

    for f, meta in zip(films, metas):
        year_int = int(f['year']) if f.get('year', '').isdigit() else 0
        rating = f.get('rating', '')
        label = "{0} ({1})".format(f['title'], year_int) if year_int else f['title']
        if rating:
            label = "{0}  [COLOR yellow]FA {1}[/COLOR]".format(label, rating)
        li = xbmcgui.ListItem(label=label)
        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster') or f['poster']
        else:
            li.setArt({'icon': 'DefaultVideo.png', 'thumb': f['poster'], 'poster': f['poster']})
            header = me.build_plot_header(rating, None, director=f.get('director'))
            li.setInfo('video', {'title': f['title'], 'year': year_int,
                                  'plot': header, 'mediatype': 'movie'})
            poster = f['poster']
        tmdb_id = (meta.get('ids') or {}).get('tmdb', '') if meta else ''
        cm = [
            ("¿Dónde ver en España?", "RunPlugin({0})".format(
                _u(action='show_watch_providers', title=f['title'], tmdb_id=tmdb_id))),
            ("Buscar en más fuentes", "Container.Update({0})".format(
                _u(action='search_movie_multi', q=f['title'], tmdb_id=tmdb_id, media_type='movie'))),
        ]
        li.addContextMenuItems(cm)
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=poster, mode='movie', tmdb_id=tmdb_id)
        xbmcplugin.addDirectoryItem(handle=_handle(), url=url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(_handle())


def cache_cartelera_meta():
    """Descarga y guarda metadatos TMDB para la cartelera actual de FilmAffinity."""
    import metadata_enricher as me

    films = _fetch_en_cines()
    if not films:
        xbmcgui.Dialog().notification("EspaTV", "No hay películas en cartelera", xbmcgui.NOTIFICATION_ERROR)
        return

    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaTV", "Descargando metadatos cartelera...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "EspaTV",
        "Metadatos guardados: {0}/{1}".format(count, len(items)),
        xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")


def clear_cartelera_meta():
    """Elimina del caché los metadatos de las películas en cartelera."""
    import metadata_enricher as me

    films = _fetch_en_cines()
    items = [{'title': f['title'], 'media_type': 'movie'} for f in films]
    me.delete_items(items)
    xbmcgui.Dialog().notification("EspaTV", "Metadatos de cartelera eliminados", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")
