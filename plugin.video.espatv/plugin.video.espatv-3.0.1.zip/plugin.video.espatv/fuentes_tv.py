# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Router y pantalla raíz de HyperXStream: los servidores Xtream y listas M3U.

Este módulo no habla con ningún servidor ni descarga nada. Solo decide a qué función de
`fuentes_vistas`, `fuentes_servidores` o `fuentes_remoto` le toca, y pinta el menú.

Tres cosas de aquí que no hay que cambiar sin pensarlo:
- **El prefijo de las acciones es `fuentes_`** y el router de `default.py` las captura con un
  `startswith`. Nada de esto depende de ningún otro addon, y el nombre visible de la sección es
  una sola constante, `_NOMBRE`, para poder cambiarlo sin tocar más.
- **Una acción de script se cierra ella misma.** Si se abre como carpeta (un atajo, un favorito),
  hay que terminar el directorio o Kodi se queda esperando un listado que no llega y, con el
  `Container.Update` del final, se realimenta en bucle. Por eso `_SCRIPT_ACTIONS` y `_fin()`.
- **Aquí no se lee ni un byte de red**, ni al abrir el menú ni al pintarlo: se lee el JSON y ya.
"""

import sys
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

import ui_utils

_LOG = '[EspaTV/FUENTES]'

#: El nombre visible. Si cambia, cambiarlo también en las etiquetas de `settings.xml`.
_NOMBRE = 'HyperXStream'

_BASE = 'plugin://plugin.video.espatv/'

#: Acciones que son un botón, no una carpeta: abren, hacen su cosa y se cierran.
_SCRIPT_ACTIONS = frozenset({
    'fuentes_srv_add', 'fuentes_srv_edit', 'fuentes_srv_del', 'fuentes_srv_up',
    'fuentes_srv_down', 'fuentes_srv_rename', 'fuentes_srv_check', 'fuentes_srv_scan', 'fuentes_guia_bajar',
    'fuentes_check', 'fuentes_scan',
    'fuentes_fav_toggle', 'fuentes_play', 'fuentes_guia_programa',
    'fuentes_remoto_url', 'fuentes_remoto_fichero', 'fuentes_remoto_importar_fichero',
    'fuentes_remoto_importar_web',
    'fuentes_remoto_exportar',
    'fuentes_remoto_texto', 'fuentes_remoto_movil', 'fuentes_remoto_texto_pegado',
    'fuentes_remoto_sincro', 'fuentes_remoto_sincro_ahora', 'fuentes_remoto_sincro_quitar',
    'fuentes_cache_borrar', 'fuentes_ajustes', 'fuentes_guia', 'fuentes_indexar',
    'fuentes_refrescar', 'fuentes_cache_ttl', 'fuentes_config_ua',
})


def _log(texto, nivel=xbmc.LOGDEBUG):
    xbmc.log('{0} {1}'.format(_LOG, texto), nivel)


def _u(**params):
    return _BASE + '?' + urllib.parse.urlencode(
        {k: v for k, v in params.items() if v not in (None, '')})


def _icon(nombre):
    return ui_utils.media_icon(nombre) or 'DefaultAddonPVRClient.png'


def _handle():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1


def _fin(cerrado=True, reemplazar=False):
    """Cierra el directorio. `reemplazar` es `updateListing`, para no apilar historial.

    La firma de Kodi es `endOfDirectory(handle, succeeded, updateListing, cacheToDisc)`, y
    `updateListing=True` indica sustituir la pantalla en vez de añadir otra encima, evitando
    apilar pantallas en la paginación.

    Con `cacheToDisc=True` en estas listas de la sección, volver atrás recupera el contenido
    en caché en vez de solicitarlo nuevamente.
    """
    h = _handle()
    if h < 0:
        return
    try:
        xbmcplugin.endOfDirectory(h, cerrado, bool(reemplazar), True)
    except Exception as e:      # pragma: no cover - solo si Kodi va mal
        _log('no se ha podido cerrar el listado: {0}'.format(e), xbmc.LOGWARNING)


def _refrescar():
    """Vuelve a pintar el sitio en el que estamos, sin volver atrás en el historial."""
    h = _handle()
    if h >= 0:
        try:
            xbmc.executebuiltin('Container.Refresh')
        except Exception as e:  # pragma: no cover
            _log('no se ha podido refrescar: {0}'.format(e), xbmc.LOGDEBUG)


def raiz():
    """La pantalla de la sección. Con fuentes, el menú; sin ellas, lo único que hay que hacer."""
    import fuentes_store

    ui_utils.visto('fuentes_tv')
    fuentes = fuentes_store.fuentes()

    if not fuentes:
        ui_utils.add_item(
            action='fuentes_srv_add',
            title='[B]Añade tu primer servidor[/B]',
            thumbnail=_icon('servidores_xtream.png'), folder=False,
            plot='No incluye servidores de serie. Pega tu enlace Xtream o lista M3U '
                 '(ej: http://servidor:puerto/get.php?username=X&password=Y), o introduce servidor, '
                 'usuario y clave por separado. También puedes enviarlos desde el móvil o PC.')
        ui_utils.add_item(
            action='fuentes_remoto_importar_web',
            title='Traer una configuración desde el móvil o PC',
            thumbnail=_icon('url_remote.png'), folder=False,
            plot='Abre una página temporal en la red local para pegar la configuración '
                 'o enviar un archivo desde el móvil o el ordenador.')
        ui_utils.add_item(
            action='fuentes_guia',
            title='Cómo funciona',
            thumbnail=_icon('info_guia.png'), folder=False,
            plot='Qué es un servidor Xtream, qué hace falta para añadir uno y qué se guarda.')
        # La suscripción se comprueba también aquí: esta rama sale antes del hook, y con la
        # lista vacía (instalación nueva o fuentes borradas) es cuando más falta hace.
        import fuentes_remoto
        fuentes_remoto.sincro_si_toca()
        ui_utils.close_item_list()
        return

    n = len(fuentes)
    ui_utils.add_item(
        action='fuentes_servidores',
        title='Servidores y listas  [COLOR gray]({0})[/COLOR]'.format(n),
        thumbnail=_icon('xtream_servidores.png'), folder=True,
        plot='Estado, comprobación y edición de paneles Xtream y listas M3U.')
    ui_utils.add_item(
        action='fuentes_cats', sec='live', folder=True,
        title='TV y radio en directo',
        thumbnail=_icon('xtream_live.png'),
        plot='Los canales en directo de tus servidores, agrupados en las categorías que da cada panel.')
    ui_utils.add_item(
        action='fuentes_cats', sec='vod', folder=True,
        title='Películas',
        thumbnail=_icon('cat_cine.png'),
        plot='Las películas de tus servidores, con el año, la sinopsis y la nota que manda el panel.')
    ui_utils.add_item(
        action='fuentes_cats', sec='series', folder=True,
        title='Series',
        thumbnail=_icon('cat_series.png'),
        plot='Las series de tus servidores, organizadas por temporada y capítulo con su sinopsis.')
    ui_utils.add_item(
        action='fuentes_search_all', folder=True,
        title='Buscar en todos los servidores',
        thumbnail=_icon('busqueda.png'),
        plot='Busca un canal, una película o una serie por su nombre en todos tus servidores '
             'a la vez. En los Xtream busca en lo que ya se ha bajado o indexado; las listas '
             'M3U se leen enteras.')
    ui_utils.add_item(
        action='fuentes_fav', folder=True,
        title='Favoritos',
        thumbnail=_icon('favoritos.png'),
        plot='Accesos directos a tus canales y contenidos guardados.')
    ui_utils.add_item(
        action='fuentes_top', folder=True,
        title='Lo más usado',
        thumbnail=_icon('xtream_top_usado.png'),
        # Sin `sec`: mas_usados('') acaba en uso_top(None), que no filtra por sección.
        # El plot aclara que la sección muestra contenidos con más de una reproducción.
        plot='Lo que más repites, de todas las secciones. Lo visto una sola vez está en el '
             'Historial.')
    ui_utils.add_item(
        action='fuentes_hist', folder=True,
        title='Historial',
        thumbnail=_icon('historial.png'),
        plot='Las últimas 50 reproducciones, de todas las secciones, de la más reciente a la '
             'más antigua.')
    ui_utils.add_item(
        action='fuentes_config', folder=True,
        title='Configuración de {0}'.format(_NOMBRE),
        thumbnail=_icon('opciones.png'),
        plot='Copias de seguridad, sincronización remota, gestión de caché y opciones de conexión.')
    ui_utils.add_item(
        action='fuentes_guia', folder=False,
        title='Cómo funciona',
        thumbnail=_icon('info_guia.png'),
        plot='Información sobre fuentes admitidas, configuración y privacidad.')
    ui_utils.add_item(
        action='fuentes_srv_add', folder=False,
        title='Añadir un servidor',
        thumbnail=_icon('servidores_xtream.png'),
        plot='Pega el enlace completo de tu panel (http://servidor:puerto/get.php?username=X&password=Y) '
             'o introduce servidor, usuario y contraseña por separado. '
             'No se conecta a nada al guardar; comprobar que contesta es otra acción.')
    ui_utils.add_item(
        action='fuentes_srv_add', tipo='m3u', folder=False,
        title='Añadir una lista M3U',
        thumbnail=_icon('xtream_anadir_m3u.png'),
        plot='Dirección web directa de la lista remota (.m3u o .m3u8).')
    # Comprobación de suscripción: lee el JSON local sin peticiones de red y si toca
    # ejecuta la verificación en segundo plano con notificación final.
    import fuentes_remoto
    fuentes_remoto.sincro_si_toca()
    ui_utils.close_item_list()


def route(accion, params):
    """Punto de entrada desde el router de `default.py` para las acciones `fuentes_`."""
    # Abierta como carpeta (un atajo, un widget, un favorito): se cierra ya, o Kodi espera un
    # listado que no llega y el Container.Refresh del final realimenta la acción en bucle.
    # Es el mismo patrón que `iptv_lists.route()` (`iptv_lists.py:2418-2422`).
    #
    # `cerrada` va luego al `except`, para no cerrar dos veces si la acción falla: cerrar de
    # más no rompe nada hoy, pero en cuanto una acción de script cierre por su cuenta (como
    # hacen varias de las de `iptv_lists` en su `finally`) el error pasa a ser suyo.
    cerrada = False
    if accion in _SCRIPT_ACTIONS and _handle() >= 0:
        _fin(False)
        cerrada = True

    fid = params.get('fid', '')
    seccion = params.get('sec', 'live')

    # Cada rama importa lo que usa DENTRO del try:
    #   * un módulo que falte o con error de sintaxis lo recoge el `except` de esa rama, con
    #     el nombre de la acción en el aviso, y el directorio se cierra
    #   * una acción desconocida no importa nada y sale por el `else`
    #   * abrir la raíz no carga las vistas, ni borrar un servidor la configuración remota
    try:
        if accion == 'fuentes_tv':
            raiz()
        elif accion == 'fuentes_servidores':
            import fuentes_servidores
            fuentes_servidores.menu()
        elif accion == 'fuentes_srv_add':
            import fuentes_servidores
            fuentes_servidores.anadir(params.get('tipo'))
        elif accion in ('fuentes_srv_edit', 'fuentes_srv_del', 'fuentes_srv_up',
                        'fuentes_srv_down', 'fuentes_srv_rename'):
            import fuentes_servidores
            if accion == 'fuentes_srv_edit':
                fuentes_servidores.editar(fid)
            elif accion == 'fuentes_srv_del':
                fuentes_servidores.borrar(fid)
            elif accion == 'fuentes_srv_up':
                fuentes_servidores.mover(fid, -1)
            elif accion == 'fuentes_srv_down':
                fuentes_servidores.mover(fid, 1)
            else:
                fuentes_servidores.renombrar(fid)
        elif accion in ('fuentes_check', 'fuentes_scan'):
            import fuentes_servidores
            if accion == 'fuentes_check':
                fuentes_servidores.comprobar()
            else:
                fuentes_servidores.analizar()
        elif accion in ('fuentes_srv_check', 'fuentes_srv_scan'):
            # Las de una sola fuente, las del menú contextual. Sin esto estaban en
            # `_SCRIPT_ACTIONS` y nadie las despachaba: caían en el `else` de
            # "acción desconocida", con su aviso, y la pulsación no hacía nada.
            import fuentes_servidores
            if accion == 'fuentes_srv_check':
                fuentes_servidores.comprobar(solo=fid)
            else:
                fuentes_servidores.analizar(solo=fid)
        elif accion == 'fuentes_mas_usr':
            import fuentes_servidores
            fuentes_servidores.mas_usado_por_fuente()
        elif accion == 'fuentes_editor':
            # **El Editor visible.** Las opciones de una fuente estaban solo en su menú
            # contextual; esta pantalla las pone como filas. Con `fid` son las de esa fuente, y
            # sin él la pantalla para elegir. **No está en `_SCRIPT_ACTIONS`**: es una carpeta.
            import fuentes_servidores
            if fid:
                fuentes_servidores.editor_de(fid)
            else:
                fuentes_servidores.editor()
        elif accion == 'fuentes_guia_bajar':
            import fuentes_vistas
            fuentes_vistas.bajar_guia(params)
        elif accion == 'fuentes_scan_filtros':
            import fuentes_servidores
            fuentes_servidores.filtros()
        elif accion == 'fuentes_scan_filtro':
            import fuentes_servidores
            fuentes_servidores.aplicar_filtro(params)
        elif accion == 'fuentes_guia_programa':
            import fuentes_vistas
            fuentes_vistas.ver_programa(params)
        elif accion == 'fuentes_cats':
            import fuentes_vistas
            # `elegir` viene de «Cambiar de servidor»: la pantalla de elegir aunque haya un
            # último servidor apuntado.
            fuentes_vistas.categorias(fid, seccion, params.get('elegir') == '1')
        elif accion == 'fuentes_cats_todos':
            # Opción «Todos» de la pantalla de selección: las categorías de todas las
            # fuentes pedidas concurrentemente.
            import fuentes_vistas
            fuentes_vistas.categorias_todas(seccion)
        elif accion == 'fuentes_list':
            import fuentes_vistas
            # `g` es el `group-title` de una lista M3U, que no tiene identificador. Con Xtream no
            # se usa, porque ahi el filtro va por `category_id`.
            fuentes_vistas.listado(fid, seccion, params.get('cat', ''), _pagina(params),
                                   params.get('g', ''))
        elif accion == 'fuentes_m3u':
            import fuentes_vistas
            fuentes_vistas.m3u(fid)
        elif accion == 'fuentes_series':
            import fuentes_vistas
            fuentes_vistas.series(fid, params.get('cat', ''), _pagina(params))
        elif accion == 'fuentes_seasons':
            import fuentes_vistas
            fuentes_vistas.temporadas(fid, params.get('serie', ''))
        elif accion == 'fuentes_episodes':
            import fuentes_vistas
            # `temp` vacío lista todos los capítulos de la serie.
            fuentes_vistas.episodios(fid, params.get('serie', ''), params.get('temp', ''))
        elif accion == 'fuentes_faceta':
            # Xtream no provee facetas por país/idioma en categorías.
            import fuentes_vistas
            fuentes_vistas.sin_facetas(seccion)
        elif accion == 'fuentes_search_all':
            import fuentes_vistas
            # Búsqueda global manteniendo la sección de origen.
            fuentes_vistas.buscar_todo(params.get('texto', ''), params.get('sec', ''), fid)
        elif accion == 'fuentes_fav':
            import fuentes_vistas
            fuentes_vistas.favoritos()
        elif accion == 'fuentes_fav_toggle':
            import fuentes_vistas
            fuentes_vistas.alternar_favorito(params)
        elif accion == 'fuentes_top':
            import fuentes_vistas
            fuentes_vistas.mas_usados(params.get('sec', ''))
        elif accion == 'fuentes_hist':
            import fuentes_vistas
            fuentes_vistas.historial()
        elif accion == 'fuentes_play':
            import fuentes_vistas
            # `nombre` primero: en el historial y en «Lo más usado», `title` es el rótulo de la
            # fila («3x La 1»), y `reproducir()` guarda como nombre lo que recibe.
            fuentes_vistas.reproducir(fid, params.get('sid', ''), seccion,
                                       params.get('nombre') or params.get('title', ''),
                                       params.get('ext', ''))
        elif accion == 'fuentes_config':
            import fuentes_remoto
            fuentes_remoto.configuracion()
        elif accion == 'fuentes_config_ua':
            import fuentes_remoto
            fuentes_remoto.dialogo_ua()
        # Importar configuración desde fichero local.
        # Va como rama propia para que el router y los tests de rutas detecten la acción atendida.
        elif accion == 'fuentes_remoto_importar_fichero':
            import fuentes_remoto
            fuentes_remoto.importar_fichero()
        elif accion == 'fuentes_remoto_importar_web':
            import fuentes_remoto
            fuentes_remoto.importar_web('backup')
        elif accion in ('fuentes_remoto_fichero', 'fuentes_remoto_texto',
                         'fuentes_remoto_url', 'fuentes_remoto_movil',
                         'fuentes_remoto_exportar', 'fuentes_remoto_texto_pegado',
                         'fuentes_remoto_sincro', 'fuentes_remoto_sincro_ahora',
                         'fuentes_remoto_sincro_quitar'):
            # Estas (nueve) estaban en `_SCRIPT_ACTIONS` y **no tenían rama**: caían en el
            # `else` de "acción desconocida", con su aviso, y la pulsación no hacía nada.
            import fuentes_remoto
            if accion == 'fuentes_remoto_fichero':
                fuentes_remoto.exportar_fichero()
            elif accion == 'fuentes_remoto_texto':
                fuentes_remoto.exportar_texto()
            elif accion == 'fuentes_remoto_exportar':
                fuentes_remoto.exportar(params.get('como', 'fichero'))
            elif accion == 'fuentes_remoto_texto_pegado':
                # Pegar un texto no es una descarga, asi que **no** pasa por
                # `fuentes_remoto_activo`. Es la razon de que sean dos acciones y no una:
                # la de la URL puede meter una credencial ajena y exige el ajuste; esta no.
                fuentes_remoto.importar_texto()
            elif accion == 'fuentes_remoto_url':
                fuentes_remoto.importar_url()
            elif accion == 'fuentes_remoto_sincro':
                fuentes_remoto.sincronizar()
            elif accion == 'fuentes_remoto_sincro_ahora':
                fuentes_remoto.sincro_ahora()
            elif accion == 'fuentes_remoto_sincro_quitar':
                fuentes_remoto.sincro_quitar()
            else:
                # Opciones para pasar la configuración al móvil de forma segura en red local.
                fuentes_remoto.sin_qr()
        elif accion == 'fuentes_cache_borrar':
            import fuentes_remoto
            fuentes_remoto.borrar_cache()
        elif accion == 'fuentes_indexar':
            import fuentes_vistas
            fuentes_vistas.indexar(fid, params.get('texto', ''), params.get('sec', ''))
        elif accion == 'fuentes_refrescar':
            import fuentes_vistas
            fuentes_vistas.refrescar(params)
        elif accion == 'fuentes_cache_ttl':
            import fuentes_remoto
            fuentes_remoto.dialogo_ttl()
        elif accion == 'fuentes_guia':
            import fuentes_remoto
            fuentes_remoto.guia()
        elif accion == 'fuentes_ajustes':
            xbmc.executebuiltin('Addon.OpenSettings(plugin.video.espatv)')
        else:
            # Una acción que no existe se avisa y **se cierra el directorio**, que es lo
            # importante: sin cerrar, un favorito o un widget que apunten aquí dejan la
            # pantalla esperando, y con el `Container.Refresh` del final realimenta la acción
            # en bucle. Es el mismo motivo por el que `_SCRIPT_ACTIONS` se pre-cierra.
            #
            # No se hace `raise`: el `else` final de `default.py` pinta el menú principal, y
            # una excepción aquí dejaría la pantalla a medias.
            _log('acción desconocida: {0}'.format(accion), xbmc.LOGWARNING)
            if not cerrada:
                _fin(False)
    except Exception as e:
        import traceback
        # Saneado: una excepcion de `_download` lleva la URL con la credencial, y
        # esto se escribe en el `kodi.log` de la tele.
        import fuentes_xtream
        _log('error en {0}: {1}'.format(
            accion, fuentes_xtream._sin_credenciales(e)), xbmc.LOGERROR)
        _log(fuentes_xtream._sin_credenciales(
            traceback.format_exc()), xbmc.LOGERROR)
        try:
            # El aviso dice QUÉ botón ha fallado, no solo en qué sección: en una pantalla
            # con diez botones, "ha ocurrido un error en HyperXStream" no dice nada
            # accionable.
            xbmcgui.Dialog().notification(
                'EspaTV',
                '{0}: error en {1}'.format(_NOMBRE, accion))
        except Exception:       # pragma: no cover
            pass
        if not cerrada:
            _fin(False)


def _pagina(params):
    """La página pedida, o 0. Un `page` que no es un número es 0, no un fallo."""
    try:
        return max(int(params.get('page', 0)), 0)
    except (TypeError, ValueError):
        return 0
