# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Mover tu configuración a otro sitio y traérsela: a un fichero, a un texto, a un móvil.

Principio de diseño de este módulo:

**Nada de esto depende de servicios externos.** Lo que hay aquí es **tu** configuración —los
servidores y listas que has añadido tú— saliendo y entrando **a donde tú digas**: un fichero del
disco, un texto que copias y pegas, o una dirección que tú escribes. El ajuste
`fuentes_remoto_activo` existe para poder **importar desde una URL remota**, que es la única
puerta que se puede usar sin querer.

Tres reglas que no se rompen:

- **Exportar lleva las contraseñas, y hay que decirlo.** Un fichero con tus servidores es un
  fichero con tus claves dentro. Por eso la exportación **no** se puede lanzar sin un diálogo que
  lo diga. Lo que no se hace es mandarlo a ningún sitio: no hay a quién.
- **Importar desde una URL es la única acción que puede añadir un servidor sin preguntar** (la
  descarga puede traer credenciales ajenas), y por eso `fuentes_remoto_activo` está apagado de
  serie y por eso al importar **siempre** se enseña lo que viene antes de guardarlo. Pegar un
  texto no es una descarga —lo escribes tú— y por eso no pasa por el ajuste.
- **La auto-sincronización obedece al mismo interruptor**: con el ajuste apagado no se marca ni
  se descarga nada (`sincro_si_toca` y `_sincronizar` lo comprueban). Una puerta que el usuario
  cerró no se vuelve a abrir sola.
- **Traer desde el móvil o PC** abre un servidor web **efímero en tu red local**, a demanda: lo
  que llega lo has enviado tú desde tu propio navegador. No pasa por el ajuste porque no es una
  dirección ajena, pero se enseña lo recibido antes de guardar, igual que el resto.
"""
import json
import os
import time

import xbmc
import xbmcgui
import xbmcvfs

import ui_utils

_LOG = '[EspaTV/FUENTES]'

_NOMBRE = 'HyperXStream'

#: Lo que va en la cabecera de un texto exportado, para que al pegar se sepa qué es y no se
#: confunda con cualquier otro texto.
CABECERA = '# {0}: servidores y listas. contiene usuario y contraseña. No lo compartas.'.format(
    _NOMBRE)


def _log(texto, nivel=xbmc.LOGDEBUG):
    xbmc.log('{0} {1}'.format(_LOG, texto), nivel)


def _handle():
    try:
        return int(__import__('sys').argv[1])
    except (IndexError, ValueError):
        return -1


def _fin(cerrado=True, reemplazar=False):
    h = _handle()
    if h < 0:
        return
    try:
        import xbmcplugin
        xbmcplugin.endOfDirectory(h, cerrado, bool(reemplazar), True)
    except Exception as e:                              # pragma: no cover
        _log('no se ha podido cerrar el listado: {0}'.format(e), xbmc.LOGWARNING)


def _aviso(texto, titulo=None):
    xbmcgui.Dialog().ok(titulo or _NOMBRE, texto)


def _pregunta(titulo, defecto=''):
    return (xbmcgui.Dialog().input(titulo, defecto) or '').strip()


def _pregunta_clave(titulo):
    """Escondida: la máscara va en `option=` con nombre (ver `fuentes_servidores`)."""
    return (xbmcgui.Dialog().input(titulo, '', option=xbmcgui.ALPHANUM_HIDE_INPUT) or '').strip()


def _icon(nombre):
    return ui_utils.media_icon(nombre) or 'DefaultAddonPVRClient.png'


def _remoto_activo():
    """Comprueba si se permite importar desde una URL (apagado de serie)."""
    import xbmcaddon
    try:
        valor = xbmcaddon.Addon().getSetting('fuentes_remoto_activo')
    except Exception:                                  # pragma: no cover
        return False
    return str(valor).strip().lower() in ('1', 'true', 'yes', 'si', 'on')


def _u(**params):
    import urllib.parse
    return ('plugin://plugin.video.espatv/?'
            + urllib.parse.urlencode({k: v for k, v in params.items()
                                      if v not in (None, '')}))


# --- la configuracion que se mueve ------------------------------------------

def _paquete():
    """Devuelve la lista de fuentes a exportar, excluyendo cachés y contadores."""
    import fuentes_store
    return list(fuentes_store.fuentes())


def a_texto(fuentes=None):
    """La configuración como texto, una fuente por línea.

    El formato es servidor|usuario|clave|nombre|tipo|sin_cifrar|url, con los campos vacíos
    donde no apliquen. Los separadores internos se sustituyen para no romper las columnas.
    """
    fuentes = _paquete() if fuentes is None else fuentes
    lineas = [CABECERA]
    for f in fuentes:
        if not isinstance(f, dict):
            continue
        partes = [str(f.get('servidor') or ''), str(f.get('usuario') or ''),
                  str(f.get('clave') or ''), str(f.get('nombre') or ''),
                  str(f.get('tipo') or 'xtream'), '1' if f.get('inseguro') else '0',
                  str(f.get('url') or '')]
        # Los separadores de dentro se sustituyen para evitar que un salto de línea
        # o tabulador dentro de un nombre rompa la estructura de columnas al exportar/importar.
        for malo, bueno in (('\t', ' '), ('\n', ' '), ('\r', ' '), ('|', '/')):
            partes = [p.replace(malo, bueno) for p in partes]
        lineas.append('|'.join(partes))
    return '\n'.join(lineas)


def desde_texto(texto):
    """Lee el texto de una exportación y devuelve las fuentes sin guardarlas.

    Acepta tanto el formato por líneas como el código de una sola línea (prefijo HXS1:).
    """
    texto = str(texto or '').strip()
    if texto.startswith(PREFIJO_CODIGO):
        return desde_codigo(texto[len(PREFIJO_CODIGO):])
    fuentes = []
    for numero, linea in enumerate(str(texto or '').splitlines()):
        if not linea.strip() or linea.lstrip().startswith('#'):
            continue
        partes = linea.split('|')
        if len(partes) < 6:
            _log('línea {0} de la importación: no tiene los 6 campos'.format(numero + 1),
                 xbmc.LOGWARNING)
            continue
        servidor, usuario, clave, nombre, tipo, inseguro = partes[:6]
        url = partes[6] if len(partes) > 6 else ''
        if not servidor and not url:
            continue
        if tipo == 'm3u':
            fuentes.append({'nombre': nombre or url, 'tipo': 'm3u', 'url': url,
                            'servidor': '', 'usuario': '', 'clave': ''})
        else:
            fuentes.append({'nombre': nombre or servidor, 'tipo': 'xtream',
                            'servidor': servidor.rstrip('/'), 'usuario': usuario,
                            'clave': clave, 'inseguro': inseguro.strip() in ('1', 'true')})
    return fuentes


def a_json(fuentes=None):
    """Lo mismo, en JSON. Para un fichero que se pueda volver a leer con un programa."""
    fuentes = _paquete() if fuentes is None else fuentes
    return json.dumps({'version': 1, 'seccion': _NOMBRE, 'fuentes': fuentes},
                      ensure_ascii=False, indent=2)


def desde_json(texto):
    """Lee un JSON de exportación. Devuelve las fuentes, sin guardarlas."""
    try:
        datos = json.loads(texto)
    except ValueError as e:
        raise ValueError('El fichero no es un JSON válido: {0}'.format(e)) from e
    if isinstance(datos, list):
        if not datos or not all(isinstance(f, dict) for f in datos):
            raise ValueError('El fichero no tiene la forma de una exportación.')
        return [f for f in datos if isinstance(f, dict)]
    if not isinstance(datos, dict):
        raise ValueError('El fichero no tiene la forma de una exportación.')
    lista = datos.get('fuentes')
    if not isinstance(lista, list):
        raise ValueError('El JSON no trae la lista de fuentes.')
    return [f for f in lista if isinstance(f, dict)]


#: Marca del código de una sola línea. Los dos puntos no salen nunca en base64url, así que el
#: prefijo no se confunde con el principio del código.
PREFIJO_CODIGO = 'HXS1:'


def a_codigo(fuentes=None):
    """La configuración como un código de una sola línea en base64url.

    Permite copiar o introducir la configuración en interfaces con teclado de una línea.
    """
    import base64
    fuentes = _paquete() if fuentes is None else fuentes
    crudo = json.dumps({'version': 1, 'seccion': _NOMBRE, 'fuentes': fuentes},
                       ensure_ascii=False, separators=(',', ':')).encode('utf-8')
    return PREFIJO_CODIGO + base64.urlsafe_b64encode(crudo).decode('ascii').rstrip('=')


def desde_codigo(codigo):
    """Lo contrario de `a_codigo()`. Devuelve las fuentes, sin guardarlas.

    Tolera que le llegue sin el prefijo y con espacios alrededor, que es lo que pasa cuando
    alguien lo copia a mano desde la pantalla de la tele.
    """
    import base64
    codigo = str(codigo or '').strip().replace(' ', '').replace('\n', '')
    if codigo.startswith(PREFIJO_CODIGO):
        codigo = codigo[len(PREFIJO_CODIGO):]
    codigo += '=' * (-len(codigo) % 4)
    try:
        crudo = base64.urlsafe_b64decode(codigo.encode('ascii'))
        datos = json.loads(crudo.decode('utf-8'))
    except Exception as e:
        raise ValueError('Ese código no es una configuración de {0}.'.format(_NOMBRE)) from e
    if not isinstance(datos, dict) or not isinstance(datos.get('fuentes'), list):
        raise ValueError('Ese código no tiene la forma de una configuración.')
    return [f for f in datos['fuentes'] if isinstance(f, dict)]


def importar_fichero():
    """Trae una configuración desde un fichero del disco.

    Lee mediante xbmcvfs.File para soportar rutas especiales de Kodi (special://, smb://)
    y muestra el contenido antes de guardarlo.
    """
    if not _remoto_activo():
        _aviso('Traer una configuración de un fichero está apagado.\n\n'
               'Se puede encender en Ajustes → {0} → Servicio propio.'.format(_NOMBRE))
        return
    try:
        ruta = xbmcgui.Dialog().browse(1, 'Traer configuración de {0}'.format(_NOMBRE),
                                      'files', '.json|.txt', False, False, '')
    except Exception as e:
        _aviso('No se ha podido abrir el selector de ficheros.\n\n{0}'.format(e))
        return
    if not ruta:
        return

    import fuentes_xtream
    try:
        # En bytes y por el decodificador de las listas: el Bloc de notas guarda con BOM o en
        # UTF-16, y `read()` lo dejaba delante del `{`.
        with xbmcvfs.File(ruta) as f:
            cuerpo = iptv_parse_decode(bytes(f.readBytes()))
    except Exception as e:
        _aviso('No se ha podido leer el fichero.\n\n{0}'.format(
            fuentes_xtream._sin_credenciales(e)))
        return

    try:
        fuentes = desde_json(cuerpo) if cuerpo.lstrip().startswith('{') else desde_texto(cuerpo)
    except ValueError as e:
        _aviso('Ese fichero no es una configuración.\n\n{0}'.format(e))
        return
    if not fuentes:
        _aviso('En ese fichero no hay ninguna fuente.')
        return

    if not _pregunta_si_guardar(fuentes):
        return
    _guarda(fuentes)


def _lineas_de_vista(fuentes):
    """Las líneas del diálogo de confirmación, con tope y aviso solo si hay credenciales.

    Avisa de la contraseña únicamente si hay servidores que la incluyan, y cuenta
    listas y servidores por separado.
    """
    import fuentes_xtream

    tope = 8
    xtream = sum(1 for f in fuentes if (f.get('tipo') or 'xtream') != 'm3u')
    m3u = len(fuentes) - xtream
    partes = []
    if xtream:
        partes.append('{0} servidor(es)'.format(xtream))
    if m3u:
        partes.append('{0} lista(s) M3U'.format(m3u))
    lineas = ['Vas a añadir {0}.'.format(' y '.join(partes) if partes else 'nada'), '']
    for f in fuentes[:tope]:
        donde = fuentes_xtream._sin_credenciales(
            f.get('servidor') or f.get('url') or '')
        con_usuario = ' ({0})'.format(f['usuario']) if f.get('usuario') else ''
        lineas.append('  {0}{1}  ·  {2}'.format(f.get('nombre') or '?', con_usuario, donde))
    if len(fuentes) > tope:
        lineas.append('  ... y {0} más.'.format(len(fuentes) - tope))
    lineas += ['', 'Comprueba que son las que esperas.\n\n']
    if xtream:
        lineas.append('Los servidores se guardan con su usuario y su contraseña, '
                      'revísalos antes de darle a "Sí".')
    else:
        lineas.append('Pulsa "Sí" para guardarlas.')
    return lineas


def _pregunta_si_guardar(fuentes):
    """Diálogo de confirmación antes de importar fuentes.

    Muestra nombre, servidor y usuario, omitiendo contraseñas por seguridad. Delega en
    `_lineas_de_vista()`, que es la que reparten con `importar_url()` e `importar_texto()`.
    """
    lineas = _lineas_de_vista(fuentes)
    return xbmcgui.Dialog().yesno(_NOMBRE, chr(10).join(lineas))


def _confirma_credenciales():
    """Aviso previo a la exportación para advertir de la inclusión de contraseñas."""
    return xbmcgui.Dialog().yesno(
        _NOMBRE,
        'Lo que salga lleva tus usuarios y contraseñas de los servidores. Guárdalo donde solo '
        'tú puedas leerlo, y no lo mandes por WhatsApp ni por correo.\n'
        '¿Seguir con la exportación?')


# --- las pantallas ----------------------------------------------------------

def configuracion():
    """La pantalla de configuración de la sección.

    Es el sitio donde se decide qué se hace con la configuración: mandarla a un fichero, verla
    como código, o traerse una de otra parte. Y donde se está el botón de borrar la caché, que es
    lo único que hay que hacer cuando un servidor va mal y se sospecha que es caché nuestra.
    """
    import fuentes_store

    total = len(fuentes_store.fuentes())
    if total:
        ui_utils.add_item(
            action='fuentes_scan_filtros', folder=True,
            title='Analizar y elegir servidor ({0})'.format(total),
            thumbnail=_icon('adv_cache.png'),
            plot='Comprobación global de servidores y ordenación por estado, '
                 'caducidad, idioma o número de categorías.')
    ui_utils.add_item(
        action='fuentes_remoto_fichero', folder=False,
        title='Guardar mi configuración en un fichero',
        thumbnail=_icon('fav_export.png'),
        plot='Crea una copia de seguridad en un archivo con todos tus servidores y listas para '
             'guardarlos o usarlos en otro equipo.')
    ui_utils.add_item(
        action='fuentes_remoto_importar_fichero', folder=False,
        title='Traer una configuración de un fichero',
        thumbnail=_icon('url_pegar.png'),
        plot='Restaura tus servidores y listas desde un archivo de copia de seguridad previo. '
             'Muestra un resumen antes de guardar.'
             + ('\nEstá apagado en Ajustes.' if not _remoto_activo() else ''))
    ui_utils.add_item(
        action='fuentes_remoto_texto', folder=False,
        title='Ver mi configuración como código',
        thumbnail=_icon('url_marcadores.png'),
        plot='Muestra un código de texto compacto con tus servidores para copiarlo o '
             'fotografiarlo y llevarlo a otro equipo.')
    ui_utils.add_item(
        action='fuentes_remoto_texto_pegado', folder=False,
        title='Traer una configuración de un texto',
        thumbnail=_icon('url_pegar.png'),
        plot='Importa servidores pegando el texto de configuración con vista '
             'previa antes de confirmar.')
    ui_utils.add_item(
        action='fuentes_remoto_url', folder=False,
        title='Traer una configuración de una dirección',
        thumbnail=_icon('xtream_url_remota.png'),
        plot='Descarga e importa servidores y listas desde un enlace web puntual (una sola vez), '
             'mostrando un resumen antes de guardar.'
             + (' Está apagado en Ajustes.' if not _remoto_activo() else ''))
    # Sincronización recurrente de servidores: si ya existe suscripción activa, sus acciones van antes para operar sobre la configuración actual; la suscripción nueva va al final.
    sus = _lee_sincro()
    if sus.get('url'):
        cadencia = next((e for e, s in CADENCIAS if s == _ttl_de_suscripcion(sus)),
                        CADENCIAS[0][0])
        # Refleja el estado de la última comprobación junto con el número de fallos consecutivos.
        # La variable `ultimas` es la que se pinta: se calcula aquí y se consume abajo, para que el
        # contador de fallos y el reintento con espera se vean de verdad (antes se calculaban y el
        # plot seguía leyendo `sus.get('ultimas')`, así que la mejora solo existía en el código).
        ultimas = sus.get('ultimas') or 'aún no'
        try:
            fallos = int(sus.get('fallos') or 0)
        except (TypeError, ValueError):
            fallos = 0
        if fallos > 0:
            ultimas = '{0} ({1} vez/veces seguidas; se reintenta cada {2} min)'.format(
                ultimas, fallos, REINTENTO_FALLO // 60)
        ui_utils.add_item(
            action='fuentes_remoto_sincro_ahora', folder=False,
            title='Actualizar ahora: {0}'.format(cadencia),
            thumbnail=_icon('xtream_refrescar.png'),
            plot='Comprueba de inmediato el enlace web sincronizado ({0}) para actualizar '
                 'contraseñas o incorporar nuevos servidores.\n'
                 'Última comprobación: {1}.'.format(_sus_donde(sus), ultimas))
        ui_utils.add_item(
            action='fuentes_remoto_sincro_quitar', folder=False,
            title='Quitar la sincronización',
            thumbnail=_icon('adv_borrar.png'),
            plot='Deja de comprobar el enlace web. Los servidores y listas que ya se '
                 'importaron se quedan como están.')
    ui_utils.add_item(
        action='fuentes_remoto_sincro', folder=False,
        title='Sincronizar una configuración de una dirección',
        thumbnail=_icon('xtream_url_remota.png'),
        plot='Guarda un enlace web con tu configuración para mantener los servidores al día. '
             'Eliges cada cuánto se comprueba (de 6 horas a 7 días, o solo cuando lo pidas), '
             'y cuando toca se hace al entrar en {0}. Añade lo nuevo y actualiza las claves '
             'que camben.\n\n'
             'Tres cosas que conviene saber: no recupera lo que hayas borrado tú; si cambias '
             'un servidor desde el Editor (su usuario o su dirección), la sincronización deja '
             'de gestionarlo; y si una lista M3U cambia de dirección en el remoto, llega como '
             'lista nueva y la vieja se queda.'.format(_NOMBRE)
             + (' Está apagado en Ajustes.' if not _remoto_activo() else ''))
    ui_utils.add_item(
        action='fuentes_remoto_importar_web', folder=False,
        title='Traer una configuración desde el móvil o PC',
        thumbnail=_icon('url_remote.png'),
        plot='Abre una página temporal en la red local para pegar la configuración o enviar '
             'un archivo desde el móvil o el ordenador.')
    ui_utils.add_item(
        action='fuentes_cache_ttl', folder=False,
        title=f'Cuánto se guarda lo descargado: {_ttl_elegido()}',
        thumbnail=_icon('xtream_cache_ttl.png'),
        plot='Cuánto tiempo se reutiliza lo ya descargado de cada servidor (se guarda en '
             'el perfil del addon) antes de volver a pedirlo.')
    ui_utils.add_item(
        action='fuentes_config_ua', folder=False,
        title=f'Identificación ante servidores: {_ua_etiqueta()}',
        thumbnail=_icon('adv_seguridad.png'),
        plot='Identidad (User-Agent) que envía el addon para conectar con tus proveedores. '
             'Simula navegadores habituales o reproductores multimedia para evitar bloqueos del servidor.')
    ui_utils.add_item(
        action='fuentes_indexar', folder=False,
        title='Indexar mis servidores para buscar',
        thumbnail=_icon('xtream_indexar.png'),
        plot='Descarga los índices de canales y contenidos para habilitar la '
             'búsqueda global inmediata.')
    ui_utils.add_item(
        action='fuentes_cache_borrar', folder=False,
        title='Borrar lo que tengo guardado',
        thumbnail=_icon('xtream_borrar_cache.png'),
        plot='Elimina listados e índices en caché. No afecta a las cuentas '
             'ni a los favoritos guardados.')
    ui_utils.add_item(
        action='fuentes_remoto_movil', folder=False,
        title='¿Y si quiero usarla en el móvil?',
        thumbnail=_icon('url_movil.png'),
        plot='Instrucciones y métodos para transferir tus servidores al móvil o a otro ordenador '
             'mediante la red local.')
    ui_utils.add_item(
        action='fuentes_guia', folder=False,
        title='Cómo funciona esta sección',
        thumbnail=_icon('info_guia.png'),
        plot='Información sobre configuración de paneles Xtream y privacidad.')
    ui_utils.add_item(
        action='fuentes_ajustes', folder=False,
        title='Ajustes de {0}'.format(_NOMBRE),
        thumbnail=_icon('opciones.png'),
        plot='Ajustes avanzados: vista en mosaico, formato de reproducción de streams y permisos '
             'de importación remota.')
    _fin()


def guia():
    """Qué es esto y por qué no trae ningún servidor de serie.

    Sale desde dos sitios (la raíz y la configuración) y no requiere conexión a la red.
    """
    texto = (
        'Aquí puedes añadir dos cosas: servidores Xtream y listas M3U.\n\n'
        'Un servidor Xtream te da canales, películas y series. Necesitas la dirección, '
        'un usuario y una contraseña:\n\n'
        '    http://servidor:puerto\n\n'
        'A veces te dan una sola dirección con todo junto:\n\n'
        '    http://servidor:puerto/get.php?username=USUARIO&password=CLAVE\n\n'
        'Una lista M3U es un fichero o un enlace con las direcciones de los canales dentro.\n\n'
        'QUÉ SE GUARDA Y DÓNDE: lo que añadas se guarda en tu perfil de Kodi, en un fichero '
        'que solo lee este addon. Con «Guardar mi configuración en un fichero» puedes llevarlo '
        'a otro equipo o guardarlo como copia.\n\n'
        'Si ya tenías una configuración de antes, la puedes traer desde el móvil o el '
        'ordenador con "Traer una configuración desde el móvil o PC", que está en '
        '"Configuración de {0}", en esta misma sección.\n\n'
        'El addon no trae ningún servidor de serie: todo lo que ves sale de lo que añades tú.'
        .format(_NOMBRE))
    # En textviewer porque el texto es largo y Dialog().ok() no permite scroll.
    xbmcgui.Dialog().textviewer('Cómo funciona {0}'.format(_NOMBRE), texto)


def _ttl_elegido():
    """La etiqueta del TTL que rige ahora. Una guardada que no se reconoce vale `TTL_S`, y se
    enseña la etiqueta de ese, que es lo que de verdad se está usando."""
    import fuentes_xtream
    actual = fuentes_xtream.ttl_de()
    return next(e for e, s in fuentes_xtream.TTL_ELEGIBLES if s == actual)


def dialogo_ttl():
    """Elegir el TTL desde la configuración de la sección, sin pasar por Ajustes.

    Escribe el mismo ajuste que Ajustes (`fuentes_cache_ttl`) y con la misma etiqueta.
    """
    import xbmcaddon
    import fuentes_xtream
    opciones = [e for e, _ in fuentes_xtream.TTL_ELEGIBLES]
    actual = _ttl_elegido()
    marcadas = [f'{o}  [ACTIVO]' if o == actual else o for o in opciones]
    sel = xbmcgui.Dialog().select('Cuánto se guarda lo descargado', marcadas)
    if sel < 0:
        return
    xbmcaddon.Addon().setSetting('fuentes_cache_ttl', opciones[sel])
    xbmcgui.Dialog().notification(_NOMBRE, f'Se guarda: {opciones[sel]}')
    xbmc.executebuiltin('Container.Refresh')


#: User-Agent configurables en dialogo_ua(): rótulo y valor.
#: Si un panel corta la emisión, VLC suele tolerar mejor la reproducción de flujos IPTV.
UA_PRESETS = (
    ('Por defecto del sistema (Chrome 138)', ''),
    ('Reproductor multimedia (VLC 3.0.20): si un panel corta el vídeo',
     'VLC/3.0.20 LibVLC/3.0.20'),
    ('Reproductor IPTV Smarters Pro (Android TV)', 'IPTVSmartersPro/3.1.5 (Android TV)'),
)


def _ua_limpio(valor):
    """Sin caracteres de control: un `\\r\\n` en una cabecera parte la petición en dos."""
    return ''.join(c for c in str(valor or '') if c.isprintable()).strip()


def _ua_etiqueta():
    """Etiqueta resumida del User-Agent configurado para los menús."""
    import xbmcaddon
    val = _ua_limpio(xbmcaddon.Addon().getSetting('fuentes_ua'))
    if not val:
        return 'Por defecto (Chrome 138)'
    if val == UA_PRESETS[1][1]:
        return 'VLC 3.0'
    if val == UA_PRESETS[2][1]:
        return 'IPTV Smarters Pro'
    return val[:22] + '…' if len(val) > 25 else val


def dialogo_ua():
    """Selector de identidad (User-Agent) ante servidores Xtream e IPTV.

    Escribe el ajuste `fuentes_ua`. Permite elegir presets estándar o manual.
    """
    import xbmcaddon
    addon = xbmcaddon.Addon()
    actual = _ua_limpio(addon.getSetting('fuentes_ua'))

    es_preset = any(actual == valor for _, valor in UA_PRESETS)
    marcadas = [f'{titulo}  [ACTIVO]' if actual == valor else titulo
                for titulo, valor in UA_PRESETS]
    marcadas.append('Personalizado...' if es_preset
                    else f'Personalizado ({actual})  [ACTIVO]')

    sel = xbmcgui.Dialog().select('Identificación ante el servidor (User-Agent)', marcadas)
    if sel < 0:
        return

    if sel < len(UA_PRESETS):
        elegido = UA_PRESETS[sel][1]
    else:
        # `get_text()` devuelve '' al cancelar, no None: vacío es «no tocar nada», y para
        # volver al de serie está su propia opción.
        elegido = _ua_limpio(ui_utils.get_text('Escribe el User-Agent', actual))
        if not elegido:
            return

    addon.setSetting('fuentes_ua', elegido)
    etiqueta = _ua_etiqueta()
    xbmcgui.Dialog().notification(_NOMBRE, f'User-Agent: {etiqueta}')
    xbmc.executebuiltin('Container.Refresh')


def borrar_cache():
    """Vacía la caché y los contadores. Los servidores y listas no se tocan."""
    import fuentes_store

    if not xbmcgui.Dialog().yesno(
            _NOMBRE,
            'Se borran los canales, las categorías y los datos de la cuenta descargados, y la '
            'próxima vez tardará más. Tus servidores, listas y favoritos no se tocan.\n'
            '¿Borrar la caché?'):
        return
    fuentes_store.limpiar_cache()
    fuentes_store.limpiar_huerfanos()
    xbmcgui.Dialog().notification(_NOMBRE, 'Caché borrada.')
    import xbmc as _xbmc
    _xbmc.executebuiltin('Container.Refresh')


def exportar(como='fichero'):
    """Exporta fuentes y listas según el formato elegido.

    `como` puede ser `'fichero'` (JSON o texto) o `'texto'` (para copiar al portapapeles).
    """
    if como == 'texto':
        return exportar_texto()
    return exportar_fichero()


def exportar_fichero():
    """Escribe la configuración en un fichero del disco.

    Selector con `browse(3...)` y el grupo `'files'`, que es el de las fuentes de Kodi.
    Escribe con `backups._escribir_bytes` porque `open()` no entiende `special://` ni `smb://`.
    """
    if not _confirma_credenciales():
        return
    import backups
    try:
        # Sin texto por defecto: al cancelar, Kodi devuelve ese texto, y aquí era el nombre
        # del fichero, que se intentaba guardar en una ruta relativa.
        destino = xbmcgui.Dialog().browse(
            3, 'Guardar configuración de {0}'.format(_NOMBRE), 'files', '', False, False, '')
    except Exception as e:
        _aviso('No se ha podido abrir el selector de carpetas.\n\n{0}'.format(e))
        return
    if not destino:
        return
    destino = backups._en_carpeta(destino, f'{_NOMBRE}-fuentes.json', ('.json', '.txt'))

    try:
        if destino.lower().endswith('.txt'):
            datos = a_texto().encode('utf-8')
        else:
            datos = a_json().encode('utf-8')
        if not backups._escribir_bytes(destino, datos):
            raise OSError('no se ha podido escribir en {0}'.format(destino))
    except OSError as e:
        _aviso('No se ha podido escribir el fichero.\n\n{0}'.format(e))
        return
    xbmcgui.Dialog().notification(
        _NOMBRE, 'Guardado. Recuerda que lleva tus contraseñas.')


def io_open_escribiendo(ruta):
    """Abre para escribir, creando las carpetas que falten.

    Va con `newline=''` y codificación explícita. Sin eso, en Windows un salto de
    línea se convierte al escribir en la pareja retorno de carro + salto,
    y un fichero que se lee en un móvil los necesita tal cual, no doblados.
    """
    carpeta = os.path.dirname(ruta)
    if carpeta:
        os.makedirs(carpeta, exist_ok=True)
    return open(ruta, 'w', encoding='utf-8', newline='')


def exportar_texto():
    """Muestra la configuración como código de una sola línea en un textviewer."""
    if not _confirma_credenciales():
        return
    codigo = a_codigo()
    xbmcgui.Dialog().textviewer(
        f'{_NOMBRE}: {len(_paquete())} servidor(es)',
        'Lleva dentro tus servidores, con sus usuarios y contraseñas. En otro Kodi se mete '
        'con "Traer una configuración de un texto".\n\n'
        'Kodi no deja copiar el texto de esta ventana, pero puedes hacerle una foto. Para '
        'llevar la configuración a otro equipo es más fiable "Guardar mi configuración en '
        'un fichero".\n\n'
        'Si haces la foto, bórrala cuando ya no te haga falta, porque con este código '
        f'cualquiera puede usar tus servidores.\n\n{codigo}')


def importar_url():
    """Descarga una configuración de una URL y muestra su contenido antes de guardarlo.

    Requiere que fuentes_remoto_activo esté activado en ajustes.
    """
    if not _remoto_activo():
        _aviso('Importar desde una URL está apagado.\n\n'
               'Se puede encender en Ajustes → {0} → Servicio propio. Está apagado porque '
               'lo que se descarga de fuera trae sus propias contraseñas.'.format(_NOMBRE))
        return

    url = _pregunta('Dirección de la configuración')
    if not url:
        return
    if not url.lower().startswith(('http://', 'https://')):
        url = 'http://' + url

    fuentes, error = _trae_de_url(url)
    if error:
        _aviso(error)
        return
    if not fuentes:
        _aviso('En esa dirección no hay ninguna fuente.')
        return

    # Vista previa usando _lineas_de_vista() para limitar la visualización y advertir credenciales.
    if not xbmcgui.Dialog().yesno(_NOMBRE, chr(10).join(
            ['Lo que trae esa dirección:'] + [''] + _lineas_de_vista(fuentes))):
        return
    _guarda(fuentes)


def _trae_de_url(url):
    """Descarga una dirección y parsea las fuentes. Devuelve (fuentes, texto_de_error)."""
    import iptv_lists
    import fuentes_xtream

    try:
        crudo = iptv_lists._download(url, False, None, limit=1024 * 1024, lan_ok=True)
        cuerpo = iptv_parse_decode(crudo)
    except Exception as e:
        return None, 'No se ha podido descargar.\n\n{0}'.format(
            fuentes_xtream._sin_credenciales(e))
    # Si la respuesta comienza por '<', se trata de una página web y no de una configuración.
    if cuerpo.lstrip().startswith('<'):
        return None, ('En esa dirección hay una página web, no una configuración.\n\n'
                      'Se ha abierto lo que haya en ese sitio, y no tiene dentro ningún '
                      'servidor ni ninguna lista. Si la lista está subida como fichero, la '
                      'dirección tiene que acabar en .json o en .txt.')
    try:
        fuentes = desde_json(cuerpo) if cuerpo.lstrip().startswith('{') else desde_texto(cuerpo)
    except ValueError as e:
        return None, 'Lo que hay en esa dirección no es una configuración.\n\n{0}'.format(e)
    if not fuentes:
        return None, 'En esa dirección no hay ninguna fuente.'
    return fuentes, None


def iptv_parse_decode(crudo):
    """Bytes a texto, con la decodificación que ya sabe hacer el proyecto."""
    import iptv_parse as P
    return P.decode(crudo)


def _sanea(f):
    """Campos que valen para guardar, o `None`. Es lo que `_guarda()` hacía, aparte.

    La comprobación es la de siempre: una lista M3U sin dirección no se puede abrir y un
    servidor Xtream sin `servidor` tampoco. Con None, quien llama decide si cuenta como
    «repetida» (`_guarda`) o como «sin poder aplicar» (la sincronización).
    """
    campos = dict(f)
    nombre = (str(campos.pop('nombre', '') or '').strip()
              or campos.get('servidor') or campos.get('url') or 'Sin nombre')
    if campos.get('tipo') == 'm3u':
        if not campos.get('url'):
            return None
    elif not campos.get('servidor'):
        return None
    return dict(campos, nombre=nombre)


def _cerrojo_sincro():
    """El cerrojo con nombre para el claim de «intento en marcha».

    Es el mismo cerrojo por fichero que usa el resto del proyecto (`iptv_store.Store(profile)
    .lock(...)`, como `fuentes_store._escribe_uso`). Sin él, dos aperturas de la sección que se
    crucen leen las dos el fichero antes de que ninguna escriba la marca, y lanzan dos descargas
    de lo mismo. Con él, la segunda espera a que la primera acabe, ve la marca y sale.
    """
    import iptv_store
    return iptv_store.Store(os.path.dirname(_sincro_ruta()))


def _ttl_de_suscripcion(sus):
    """Los segundos de cadencia de la suscripción, o `0` («solo a mano») si no se puede leer.

    El fichero de la suscripción está en el perfil y puede estar editado a mano: un `ttl_s`
    que no es número cuenta como «solo a mano» en vez de romper la pantalla.
    """
    return _entero(sus.get('ttl_s'))


def _entero(valor, defecto=0):
    """Convierte a entero o devuelve defecto si el valor no es convertible."""
    try:
        return int(valor)
    except (TypeError, ValueError):
        return defecto


def _apunta_suscripcion(**cambios):
    """Guarda cambios en el fichero de suscripción y limpia la marca de ejecución.

    Si no hay suscripción o no se pudo leer, no escribe nada para no sobreescribir datos previos.

    La lectura-modificación-escritura va bajo el mismo cerrojo que `sincro_si_toca()`
    para evitar condiciones de carrera entre la cancelación y el hilo en segundo plano.
    """
    import iptv_store
    try:
        with _cerrojo_sincro().lock('fuentes_sincro.json.lock'):
            sus = _lee_sincro()
            if not sus.get('url'):
                _log('no se apunta nada en la suscripción: no hay ninguna (o no se ha podido leer)')
                return False
            sus['en_marcha'] = 0
            sus.update(cambios)
            return _escribe_sincro(sus)
    except (iptv_store.LockBusy, iptv_store.StoreError):
        _log('el fichero de la suscripción está ocupado: no se apunta nada')
        return False


def _en_hilo():
    """`True` si el hilo actual no es el principal. Kodi no deja dialogar desde un hilo."""
    import threading
    return threading.current_thread() is not threading.main_thread()


def _avisa_no_guardado(que='la sincronización'):
    """Avisa de que no se ha podido guardar. Desde el hilo no cabe `xbmcgui`, se usa el builtin."""
    if _en_hilo():
        xbmc.executebuiltin('Notification({0},No se ha podido guardar {1})'.format(
            _NOMBRE, str(que).replace(',', ' ')))
    else:
        xbmcgui.Dialog().notification(
            _NOMBRE, 'No se ha podido guardar {0}.'.format(que),
            xbmcgui.NOTIFICATION_WARNING)


def _guarda(fuentes):
    """Importa las fuentes aprobadas y muestra el recuento de guardadas y omitidas."""
    import fuentes_store

    validas = [c for c in (_sanea(f) for f in fuentes) if c]
    # Un solo guardado para todo el lote. Con `anadir()` una por una eran N lecturas y
    # escrituras del estado (medido: 400 fuentes, 12,2 s); con `anadir_varios()`, una.
    anadidas = fuentes_store.anadir_varios(validas)
    # `None` es «no se ha podido guardar»; `[]` es «se guardó y no había nada que añadir», que
    # es lo normal al reimportar tu propia copia. Confundirlos hacía decir «no se ha podido
    # guardar» cuando todo había ido bien.
    guardadas = len(anadidas or [])
    repetidas = len(fuentes) - guardadas
    partes = ['Se han guardado {0} servidor(es).'.format(guardadas)]
    if repetidas:
        partes.append('{0} ya estaban o no venían bien.'.format(repetidas))
    _aviso('\n\n'.join(partes))
    if anadidas is None:
        _avisa_no_guardado('la importación')
    xbmc.executebuiltin('Container.Refresh')
    return guardadas, repetidas


# --- la sincronización de una dirección --------------------------------------
#
# Comprueba la suscripción con su cadencia: añade lo que falta, actualiza claves
# y respeta las eliminaciones manuales locales.
# Al abrir la sección se lee el JSON local y, si toca, un hilo daemon descarga los cambios.

#: Cadencias disponibles. El valor 0 deshabilita la comprobación automática periódica.
CADENCIAS = (
    ('Solo cuando yo lo pulse', 0),
    ('Cada 6 horas', 6 * 3600),
    ('Cada 12 horas', 12 * 3600),
    ('Cada 24 horas', 24 * 3600),
    ('Cada 7 días', 7 * 86400),
)

#: El fichero de la suscripción. Uno solo, a propósito: una suscripción con varias direcciones
#: ninguna de las dos se sabe si vale o está fallando. Si algún día hacen falta dos, se
#: convierte la clave en una lista y punto.
SINCRO = 'fuentes_sincro.json'

#: Cuánto vale la marca de intento en marcha. No es por el tamaño de la descarga (un megabyte
#: como mucho, la misma tope que una importación): es la red de seguridad para que dos aperturas
#: de la sección cruzadas no lancen dos descargas para lo mismo —y, si el proceso muere a mitad
#: de una descarga y la marca se queda puesta, el plazo para que caduque sola. Lo de que «queda
#: limpia en los dos caminos» vale para una excepción (el `finally` de `_sincronizar`); si
#: Kodi mata el proceso, no hay `finally` que corra, y de eso se encarga este plazo.
EN_MARCHA_S = 15 * 60

#: Cuánto tarda en reintentarse una comprobación que ha fallado. Con una URL no disponible, cada
#: apertura de la sección reintentaba la descarga: un megabyte y hasta el timeout de red, para
#: volver a fallar. El reintento se acerca moviendo `ts` hacia atrás lo justo, así que no hace
#: falta ningún campo nuevo en el fichero de la suscripción.
REINTENTO_FALLO = 15 * 60


def _sus_donde(sus):
    """La dirección de la suscripción, con la credencial tapada si la lleva.

    Una suscripción de servicio puede ser `get.php?username=..&password=..`, y este texto va a
    acabar en un plot que se ve en la tele: `_sin_credenciales` es el mismo saneado que usan las
    demás pantallas.
    """
    import fuentes_xtream
    return fuentes_xtream._sin_credenciales(str(sus.get('url') or ''))


def _sincro_ruta():
    import xbmcaddon
    return os.path.join(xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile')), SINCRO)


def _lee_sincro():
    """La suscripción guardada, o `{}`. Nunca lanza.

    Aquí NO se aparta lo corrupto como hace el almacén de servidores: una suscripción rota solo
    puede significar «declararla otra vez», y el addon no puede saber qué había dentro para
    reinventarla. Quedarse sin ella y decirlo en el log es más honesto.
    """
    try:
        with open(_sincro_ruta(), 'r', encoding='utf-8') as f:
            datos = json.load(f)
        if isinstance(datos, dict):
            return datos
    except (OSError, ValueError) as e:
        _log('la suscripción no se ha podido leer: {0}'.format(e))
    return {}


def _escribe_sincro(datos):
    import core_settings
    try:
        os.makedirs(os.path.dirname(_sincro_ruta()), exist_ok=True)
    except OSError as e:
        _log('no se ha podido preparar la carpeta de la suscripción: {0}'.format(e),
             xbmc.LOGWARNING)
        return False
    return core_settings.atomic_write_json(_sincro_ruta(), datos, durable=True)


def _huella_de(f):
    """Identificador único de una fuente para deduplicación y sincronización."""
    import fuentes_store
    return fuentes_store.huella(f.get('tipo') or 'xtream',
                                f.get('servidor') or f.get('url') or '',
                                f.get('usuario') or '')


def _aplica_sincro(fuentes, limpiar=False):
    """Aplica la sincronización de fuentes remotas y devuelve el resumen de cambios.

    Actualiza credenciales de fuentes existentes si cambiaron en el remoto, preservando
    el nombre local y respetando las fuentes eliminadas por el usuario.
    """
    import fuentes_store

    sus = _lee_sincro()
    previas = set() if limpiar else set(sus.get('esperadas') or [])
    ignoradas = set() if limpiar else set(sus.get('ignoradas') or [])
    vivas = {_huella_de(f): f for f in fuentes_store.fuentes()}
    nuevas = actualizadas = dejadas = borradas = 0
    # La misma cuenta repetida dentro del mismo remoto se aplica una vez: el lote es un conjunto.
    procesadas = set()

    # Las fuentes existentes en el addon se consideran conocidas para detectar
    # eliminaciones manuales y evitar que la sincronización las recree.
    previas |= set(vivas)
    if not limpiar:
        # Los borrados se marcan antes de añadir para no tratarlos como nuevas fuentes.
        for h in previas:
            if vivas.get(h) is None and h not in ignoradas:
                ignoradas.add(h)
    # Lo conocido es lo previo más lo que sigue activo localmente.
    esperadas = set(previas)

    # Las fuentes eliminadas manualmente se consultan del registro para no recrearlas.
    borradas_locales = set() if limpiar else fuentes_store.borradas()

    # Las cuentas nuevas se juntan aquí y se dan de alta todas de una vez, fuera del bucle.
    por_anadir = []

    for cruda in fuentes:
        campos = _sanea(cruda)
        if not campos:
            dejadas += 1
            continue
        h = _huella_de(campos)
        if h in procesadas:
            continue
        procesadas.add(h)
        local = vivas.get(h)
        if local is None:
            if h in ignoradas or h in borradas_locales:
                # Se borró localmente y no se recupera automáticamente aunque siga en remoto.
                borradas += 1
                continue
            por_anadir.append((h, campos))
            continue
        # Se registran las existentes para respetar su eliminación si el usuario las borra después.
        esperadas.add(h)
        cambio = {}
        if str(local.get('clave') or '') != str(campos.get('clave') or ''):
            cambio['clave'] = str(campos.get('clave') or '')
        if bool(local.get('inseguro')) != bool(campos.get('inseguro')):
            cambio['inseguro'] = bool(campos.get('inseguro'))
        if not cambio:
            continue
        if fuentes_store.editar(local['id'], **cambio):
            actualizadas += 1
        else:
            dejadas += 1

    # Las cuentas que hay que dar de alta se añaden en lote.
    if por_anadir:
        anadidas = fuentes_store.anadir_varios([c for _h, c in por_anadir])
        if anadidas is None:
            # No se ha podido guardar de verdad (cerrojo ocupado, disco lleno). Se avisa, y
            # nada de esto se apunta como borrado: la siguiente comprobación lo reintenta.
            _avisa_no_guardado()
            for _h, _c in por_anadir:
                dejadas += 1
        else:
            # `[]` aquí sería «ya estaban todas», no un fallo: no se avisa. Y lo que cuenta es
            # lo que está vivo DESPUÉS del lote, no lo que esta llamada ha añadido: si otra
            # ventana de Kodi o el hilo de fondo la dio de alta primero, no es un fallo.
            vivas_despues = set(_huella_de(f) for f in fuentes_store.fuentes())
            nuevas = sum(1 for h, _c in por_anadir if h in vivas_despues)
            for h, _c in por_anadir:
                if h in vivas_despues:
                    esperadas.add(h)
                else:
                    dejadas += 1

    # Poda de esperadas: solo se conservan fuentes activas (o recibidas en este lote) y que no
    # estén marcadas como borradas. `ignoradas` conserva lo eliminado manualmente para no
    # reincorporarlo si el remoto lo sigue mandando.
    return {'nuevas': nuevas, 'actualizadas': actualizadas, 'dejadas': dejadas,
            'borradas': borradas,
            'esperadas': sorted(h for h in esperadas
                                if (h in vivas or h in procesadas) and h not in ignoradas),
            'ignoradas': sorted(ignoradas)}


def _resumen(nuevas, actualizadas, dejadas, borradas=0):
    """El resultado en una línea sin comas para evitar conflictos con executebuiltin.

    `borradas` se separa de `dejadas` para distinguir las omitidas intencionadamente por el usuario.
    """
    partes = []
    if nuevas:
        partes.append('{0} nuevas'.format(nuevas))
    if actualizadas:
        partes.append('{0} actualizadas'.format(actualizadas))
    if borradas:
        partes.append('{0} que ya habías borrado'.format(borradas))
    if dejadas:
        partes.append('{0} sin aplicar'.format(dejadas))
    return ' y '.join(partes) if partes else 'todo está como estaba'


def _sincronizar(url):
    """Comprueba la suscripción remota y aplica los cambios. Devuelve el resumen o None."""
    import fuentes_xtream

    if not _remoto_activo():
        _log('no se comprueba la suscripción: la configuración remota está apagada',
             xbmc.LOGWARNING)
        return None

    cerrada = False
    try:
        try:
            fuentes, error = _trae_de_url(url)
        except Exception as e:                          # pragma: no cover
            error = fuentes_xtream._sin_credenciales(e)
            fuentes = None
        if error or not fuentes:
            # Backoff tras fallo: retrasa el siguiente intento para no saturar la red.
            fallos = 0
            try:
                fallos = int(_lee_sincro().get('fallos') or 0) + 1
            except (TypeError, ValueError):
                fallos = 1
            sus = _lee_sincro()
            ttl = _ttl_de_suscripcion(sus)
            ts = int(time.time())
            if ttl > REINTENTO_FALLO:
                ts = ts - (ttl - REINTENTO_FALLO)
            cerrada = _apunta_suscripcion(
                ts=ts, fallos=fallos, ultimas='ha fallado la última comprobación')
            _log('no se ha podido sincronizar {0} ({1}º fallo): {2}'.format(
                fuentes_xtream._sin_credenciales(url), fallos,
                error or 'no trae fuentes'), xbmc.LOGWARNING)
            return None

        resultado = _aplica_sincro(fuentes)
        texto = _resumen(resultado['nuevas'], resultado['actualizadas'],
                          resultado['dejadas'], resultado.get('borradas'))
        if not _apunta_suscripcion(url=url, ts=int(time.time()), fallos=0,
                                   esperadas=resultado['esperadas'],
                                   ignoradas=resultado['ignoradas'],
                                   ultimas=texto):
            # Aplicado pero no suscrito: se dice, y en el mismo texto, para que no salgan
            # seguidos «no se ha podido guardar» y «Sincronizada: 2 nuevas».
            texto = '{0} (suscripción sin guardar)'.format(texto)
        return texto
    except Exception as e:
        _log('la sincronización de {0} ha reventado: {1}'.format(
            fuentes_xtream._sin_credenciales(url), fuentes_xtream._sin_credenciales(e)),
            xbmc.LOGERROR)
        # El fallo también se cuenta para asegurar el backoff en reintentos.
        try:
            _apunta_suscripcion(fallos=_entero(_lee_sincro().get('fallos')) + 1,
                                ultimas='ha fallado la última comprobación')
        except Exception:                           # pragma: no cover
            pass
        return None
    finally:
        # Si un camino ya cerró la marca (`_apunta` la quita), no se vuelve a escribir.
        # `_apunta_suscripcion` toma el cerrojo; si está ocupado, sale sin escribir.
        if not cerrada:
            try:
                _apunta_suscripcion()
            except Exception:                       # pragma: no cover
                pass


def sincronizar():
    """Declara una suscripción remota con revisión previa y cadencia de comprobación."""
    if not _remoto_activo():
        _aviso('Sincronizar exige el mismo permiso que importar de una URL.\n\n'
               'Se enciende en Ajustes → {0} → Servicio propio. Es la única puerta que puede '
               'meter una contraseña que tú no has escrito.'.format(_NOMBRE))
        return

    sus = _lee_sincro()
    previa = str(sus.get('url') or '').strip()
    url = _pregunta('Dirección de la configuración a sincronizar',
                    defecto=previa)
    if not url:
        return
    # Lo mismo que `importar_url()`: escribir `ejemplo.com/lista.json` es natural y va en http.
    if not url.lower().startswith(('http://', 'https://')):
        url = 'http://' + url

    # Si ya existía una suscripción con otra dirección, se solicita confirmación previa.
    if previa and previa != url:
        import fuentes_xtream
        if not xbmcgui.Dialog().yesno(
                _NOMBRE,
                'Ahora se comprueba: {0}\nSi sigues, se guarda: {1}\n'
                '(los servidores de la otra se quedan).'.format(
                    fuentes_xtream._sin_credenciales(previa),
                    fuentes_xtream._sin_credenciales(url))):
            return

    fuentes, error = _trae_de_url(url)
    if error:
        _aviso(error)
        return
    if not fuentes:
        _aviso('En esa dirección no hay ninguna fuente.')
        return
    if not _pregunta_si_guardar(fuentes):
        return

    # Al declarar de nuevo se reinicia el seguimiento de borrados para aplicar la lista aprobada.
    resultado = _aplica_sincro(fuentes, limpiar=True)
    texto_resumen = _resumen(resultado['nuevas'], resultado['actualizadas'],
                             resultado['dejadas'], resultado.get('borradas'))

    sel = xbmcgui.Dialog().select(
        'Con qué cadencia se comprueba',
        [e for e, _ in CADENCIAS])
    # La escritura final también va bajo el cerrojo (igual que `_apunta_suscripcion`): si el
    # hilo de fondo está cerrando la marca justo ahora, sin cerrojo revertía la declaración
    # nueva y volvía la suscripción anterior (medido).
    import iptv_store
    try:
        with _cerrojo_sincro().lock('fuentes_sincro.json.lock'):
            sus = _lee_sincro()
            sus.update({'url': url, 'ts': int(time.time()), 'en_marcha': 0,
                        'ttl_s': _ttl_de_cadencia(sel),
                        'esperadas': resultado['esperadas'],
                        'ignoradas': resultado['ignoradas'],
                        'ultimas': texto_resumen})
            guardado = _escribe_sincro(sus)
    except (iptv_store.LockBusy, iptv_store.StoreError):
        guardado = False
    if not guardado:
        _avisa_no_guardado()
        return
    xbmcgui.Dialog().notification(
        _NOMBRE, 'Suscripción guardada. ' + str(sus.get('ultimas') or ''))
    if sus['ttl_s'] == 0:
        _aviso('La has dejado en «Solo cuando yo lo pulse».\n\nLo de esta dirección ya está '
               'aplicado: la próxima vez que se compruebe será cuando des a «Actualizar '
               'ahora», o si vuelves a declarar la sincronización.')
    xbmc.executebuiltin('Container.Refresh')


def _ttl_de_cadencia(sel):
    """Los segundos de la cadencia elegida en el `select`. Cancelar (sel < 0) es «solo a mano»."""
    return CADENCIAS[sel][1] if 0 <= sel < len(CADENCIAS) else 0


def sincro_ahora():
    """Comprueba la suscripción inmediatamente sin esperar al ciclo de cadencia.

    **Mira la marca de «en marcha» antes de disparar.** Sin esa comprobación, pulsar el botón
    mientras la comprobación automática estaba descargando lanzaba **dos** `_sincronizar`
    solapados (medido: dos descargas de la misma URL, separadas 0,3 s). El botón está para
    forzar, no para duplicar.
    """
    import fuentes_xtream
    import iptv_store

    try:
        with _cerrojo_sincro().lock('fuentes_sincro.json.lock'):
            sus = _lee_sincro()
            url = str(sus.get('url') or '')
            if not url:
                _aviso('No hay ninguna sincronización que actualizar.\n\n'
                       'Se declara con «Sincronizar una configuración de una dirección».')
                return
            if int(time.time()) - _entero(sus.get('en_marcha')) < EN_MARCHA_S:
                xbmcgui.Dialog().notification(
                    _NOMBRE, 'Ya hay una comprobación en marcha. Espera a que acabe.',
                    xbmcgui.NOTIFICATION_INFO)
                return
            # La marca se pone aquí y la quita `_sincronizar` al terminar (`_apunta`).
            sus['en_marcha'] = int(time.time())
            if not _escribe_sincro(sus):
                _avisa_no_guardado('el estado de la comprobación')
                return
    except (iptv_store.LockBusy, iptv_store.StoreError):
        return
    texto = _sincronizar(url)
    if texto:
        xbmcgui.Dialog().notification(_NOMBRE, texto)
    else:
        _log('«actualizar ahora» de {0} ha fallado: lo que hay sigue valiendo'.format(
            fuentes_xtream._sin_credenciales(url)), xbmc.LOGWARNING)
        xbmcgui.Dialog().notification(
            _NOMBRE, 'No se ha podido comprobar. Lo que hay sigue valiendo.',
            xbmcgui.NOTIFICATION_WARNING)
    xbmc.executebuiltin('Container.Refresh')


def sincro_quitar():
    """Deja la suscripción en blanco sin borrar los servidores previamente añadidos.

    La lectura y escritura van bajo el mismo cerrojo que `_apunta_sincripcion()`,
    `sincro_ahora()` y `sincro_si_toca()` para evitar condiciones de carrera con el
    hilo en segundo plano. El diálogo de confirmación se muestra antes de adquirir el cerrojo.
    """
    import iptv_store

    if not _lee_sincro().get('url'):
        _aviso('No hay ninguna sincronización que quitar.')
        return
    if not xbmcgui.Dialog().yesno(
            _NOMBRE,
            'Se deja de comprobar esa dirección. Los servidores que ya trajo se quedan.\n'
            '¿Quitar la sincronización?'):
        return
    try:
        with _cerrojo_sincro().lock('fuentes_sincro.json.lock'):
            if not _lee_sincro().get('url'):
                _aviso('No hay ninguna sincronización que quitar.')
                return
            # Sobrescribe con un diccionario vacío para mantener el archivo consistente
            guardado = _escribe_sincro({'version': 1, 'ts': int(time.time())})
    except (iptv_store.LockBusy, iptv_store.StoreError):
        _aviso('Ahora mismo no se ha podido quitar: una comprobación está usando el fichero '
               'de la suscripción. Inténtalo dentro de un momento.')
        return
    if not guardado:
        _avisa_no_guardado()
        return
    xbmcgui.Dialog().notification(_NOMBRE, 'Sincronización quitada.')
    xbmc.executebuiltin('Container.Refresh')


def sincro_si_toca():
    """Comprobación periódica no bloqueante. Descarga en un hilo daemon si el TTL venció."""
    if not _remoto_activo():
        return
    sus = _lee_sincro()
    url = str(sus.get('url') or '').strip()
    ttl = _ttl_de_suscripcion(sus)
    if not url or ttl <= 0:
        return
    ahora = int(time.time())
    # Todo el claim bajo un cerrojo: leer, decidir y marcar van juntos, o dos aperturas cruzadas
    # lanzan dos hilos para lo mismo. Si el cerrojo está ocupado por otro proceso, se sale.
    #
    # **Los enteros van por `_entero()`.** El fichero es del perfil y se puede editar a mano: un
    # `ts` o un `en_marcha` que no sea número debe leerse como «no hay nada», en la línea de
    # `_ttl_de_suscripcion()`. Con el `int()` a pelo, un `"ayer"` escrito a mano hacía saltar la
    # pantalla raíz ENTERA (el error subía a `route()`, que cierra el directorio con
    # `succeeded=False`, y en muchas skins eso se lee como «no hay contenido»).
    import iptv_store
    try:
        with _cerrojo_sincro().lock('fuentes_sincro.json.lock'):
            sus = _lee_sincro()
            url = str(sus.get('url') or '').strip()
            if not url:
                return
            if ahora - _entero(sus.get('ts')) < ttl:
                return
            if ahora - _entero(sus.get('en_marcha')) < EN_MARCHA_S:
                return
            sus['en_marcha'] = ahora
            # Si la marca no se pudo escribir en disco se cancela para evitar comprobaciones duplicadas.
            if not _escribe_sincro(sus):
                _avisa_no_guardado('la marca de la comprobación')
                return
    except (iptv_store.LockBusy, iptv_store.StoreError):
        # Otro proceso está con el mismo fichero: se sale sin insistir. A la siguiente
        # apertura toca la comprobación, y no pasa nada por esperar.
        return
    # La ruta que lanza el hilo, para refrescar solo si el contenedor sigue en la sección.
    ruta = ''
    try:
        ruta = str(xbmc.getInfoLabel('Container.FolderPath') or '')
    except Exception:                                   # pragma: no cover
        pass
    _lanza_hilo(ruta, url)


def _lanza_hilo(ruta, url):
    """El hilo de la comprobación. Aparte para que los tests lo espíen sin esperar hilos."""
    def _hace():
        texto = _sincronizar(url)
        # Notificación mediante builtin para ejecución segura desde hilo secundario.
        if texto:
            xbmc.executebuiltin(
                'Notification({0},Sincronizada: {1})'.format(_NOMBRE, texto.replace(',', ' ·')))
        else:
            xbmc.executebuiltin(
                'Notification({0},No se ha podido comprobar la sincronización · '
                'lo que tienes guardado sigue valiendo)'.format(_NOMBRE))
        try:
            if xbmc.getInfoLabel('Container.FolderPath') == ruta:
                xbmc.executebuiltin('Container.Refresh')
        except Exception:                               # pragma: no cover
            pass
    import threading
    hilo = threading.Thread(target=_hace, daemon=True)
    hilo.start()


def importar_texto():
    """Importa fuentes a partir de texto introducido directamente por el usuario."""
    texto = _pregunta('Pega aquí la configuración')
    if not texto:
        return
    try:
        fuentes = desde_texto(texto)
    except ValueError as e:
        _aviso('No he entendido ese texto.\n\n{0}'.format(e))
        return
    if not fuentes:
        _aviso('No he reconocido ninguna fuente en ese texto.')
        return
    # Vista previa formateada de las fuentes reconocidas.
    if not xbmcgui.Dialog().yesno(_NOMBRE, chr(10).join(
            ['Lo que has pegado:'] + [''] + _lineas_de_vista(fuentes))):
        return
    _guarda(fuentes)


def importar_web(tipo=None):
    """Trae una configuración o servidor desde el móvil o PC mediante un servidor web efímero."""
    import web_input

    if tipo == 'm3u':
        got = web_input.receive_config(
            title='Añadir lista M3U',
            label_txt='Pega la dirección de la lista M3U (URL directa)',
            placeholder_txt='https://ejemplo.com/canales.m3u8\nhttp://servidor:puerto/lista.m3u',
            # Un .m3u subido no sirve: una fuente es una dirección y lo que llega se guarda tal
            # cual, así que el contenido de la lista se rechaza más abajo. Solo un .txt con
            # la dirección dentro.
            label_file='o elige un archivo de texto con la dirección (.txt)',
            accept_file='.txt',
            help_txt='Pega el enlace web de tu lista M3U (URL que empiece por http:// o https://). La página se cierra sola al enviar.',
            waiting='Esperando la lista M3U...')
    elif tipo == 'xtream':
        got = web_input.receive_config(
            title='Añadir servidor Xtream',
            label_txt='Pega el enlace de tu panel Xtream o los datos de conexión',
            placeholder_txt='http://servidor:8080/get.php?username=usuario&password=clave\n\n'
                            'O en líneas separadas:\n'
                            'http://servidor:8080\n'
                            'usuario\n'
                            'contraseña',
            label_file='o elige un archivo de texto con los datos (.txt)',
            accept_file='.txt',
            help_txt='Pega tu enlace Xtream (con usuario y contraseña) o los datos en 3 líneas (servidor, usuario y clave).',
            waiting='Esperando los datos del servidor...')
    elif tipo == 'backup':
        got = web_input.receive_config(
            title='Importar copia de seguridad',
            label_txt='Pega el código o texto de la copia (JSON, HXS1:... o texto)',
            placeholder_txt='Pega aquí el código o contenido JSON de la copia de seguridad...',
            label_file='o elige un archivo de copia (.json o .txt)',
            accept_file='.json,.txt',
            help_txt='Pega el texto de tu copia de seguridad o sube el archivo JSON exportado.',
            waiting='Esperando la copia de seguridad...')
    else:
        got = web_input.receive_config(
            title='Añadir servidor o lista',
            label_txt='Pega el enlace de tu panel Xtream o la dirección de tu lista M3U',
            placeholder_txt='http://servidor:8080/get.php?username=usuario&password=clave\n'
                            'https://ejemplo.com/lista.m3u8',
            label_file='o elige un archivo de texto con la dirección (.txt)',
            accept_file='.txt',
            help_txt='Admite enlaces Xtream (con usuario y contraseña) o URLs M3U.',
            waiting='Esperando datos...')

    if got is None:
        _aviso('No se ha podido abrir la página.\n\nEste aparato no parece estar conectado a '
               'una red local, o los puertos están ocupados.')
        return
    if not got:
        return

    if 'data' in got:
        try:
            cuerpo = iptv_parse_decode(got['data'])
        except Exception as e:
            _aviso('No se ha podido leer el fichero recibido.\n\n{0}'.format(e))
            return
    else:
        cuerpo = str(got.get('text') or '').strip()

    if not cuerpo:
        _aviso('No se ha recibido ningún texto ni fichero.')
        return

    cuerpo_strip = cuerpo.lstrip()
    if cuerpo_strip.startswith('#EXTM3U'):
        _aviso('Se ha recibido una lista M3U en texto crudo.\n\n'
               'EspaTV necesita la dirección web (URL) de la lista '
               '(http://... o https://...) o tus servidores Xtream.')
        return

    try:
        if cuerpo_strip.startswith('{') or cuerpo_strip.startswith('['):
            fuentes = desde_json(cuerpo)
        else:
            fuentes = desde_texto(cuerpo)
    except ValueError as e:
        _aviso('No se ha podido interpretar la configuración.\n\n{0}'.format(e))
        return

    if not fuentes:
        import iptv_parse as P
        xtream = P.parse_xtream_url(cuerpo)
        if xtream:
            srv, usr, pwd = xtream
            fuentes = [{
                'nombre': srv,
                'tipo': 'xtream',
                'servidor': srv,
                'usuario': usr,
                'clave': pwd,
                'inseguro': False,
            }]

    # Lo de abajo adivina una fuente a partir de texto suelto, y solo vale donde se ha pedido
    # una: en la copia de seguridad, un texto que no se entiende es un error, no una lista M3U
    # que se llame «hola.que», y en el de listas, dos líneas no son un servidor Xtream.
    if not fuentes and tipo in ('xtream', None):
        # Servidor, usuario y contraseña pegados en líneas separadas.
        lineas = [L.strip() for L in cuerpo.splitlines() if L.strip()]
        if len(lineas) in (2, 3):
            srv_cand = lineas[0]
            if not srv_cand.lower().startswith(('http://', 'https://')):
                if not srv_cand.startswith(('#', '<', '/', '@', '!')) and ' ' not in srv_cand and ('.' in srv_cand or ':' in srv_cand):
                    srv_cand = 'http://' + srv_cand
            if srv_cand.lower().startswith(('http://', 'https://')) and not srv_cand.lower().startswith(('http://#', 'https://#')):
                srv = srv_cand.rstrip('/')
                usr = lineas[1]
                pwd = lineas[2] if len(lineas) > 2 else ''
                fuentes = [{
                    'nombre': srv,
                    'tipo': 'xtream',
                    'servidor': srv,
                    'usuario': usr,
                    'clave': pwd,
                    'inseguro': False,
                }]

    if not fuentes and tipo != 'backup':
        c = cuerpo.strip()
        # Una sola palabra: ni espacios ni saltos de línea, o la dirección se guarda con ellos.
        una = len(c.split()) == 1
        if una and not c.lower().startswith(('http://', 'https://')) and (':' in c or '.' in c):
            c = 'http://' + c
        if una and c.lower().startswith(('http://', 'https://')):
            import urllib.parse
            try:
                anfitrion = urllib.parse.urlsplit(c).netloc.rpartition('@')[2]
            except ValueError:          # `urlsplit` lanza con un `[` sin cerrar en el host
                anfitrion = ''
            if tipo == 'xtream':
                # En modo Xtream, una URL sin credenciales es la base del panel, no una M3U. El
                # usuario y la clave se piden abajo.
                srv = c.rstrip('/')
                fuentes = [{
                    'nombre': anfitrion or srv,
                    'tipo': 'xtream',
                    'servidor': srv,
                    'usuario': '',
                    'clave': '',
                    'inseguro': False,
                }]
            elif anfitrion:
                fuentes = [{
                    'nombre': anfitrion,
                    'tipo': 'm3u',
                    'url': c,
                    'servidor': '',
                    'usuario': '',
                    'clave': '',
                }]

    if not fuentes:
        _aviso('No se ha reconocido ninguna fuente en lo recibido.')
        return

    # Un servidor adivinado de la dirección sola o de dos líneas llega sin usuario o sin clave, y
    # así no contesta nunca: se pide lo que falta con el teclado antes de guardar algo que no
    # sirve. Solo con uno: una copia con varias incompletas no es para preguntarlas una a una.
    if tipo in ('xtream', None) and len(fuentes) == 1 and fuentes[0].get('tipo') == 'xtream':
        f = fuentes[0]
        if not f.get('usuario'):
            f['usuario'] = _pregunta('Usuario')
            if not f['usuario']:
                return
        if not f.get('clave'):
            f['clave'] = _pregunta_clave('Contraseña')
            if not f['clave']:
                return

    if not _pregunta_si_guardar(fuentes):
        return
    _guarda(fuentes)


def sin_qr():
    """Cómo pasar la configuración al móvil o traerla de él.

    Para conectar con el móvil o PC dentro de casa no hace falta ningún servicio ajeno:
    se usa la propia red local de forma directa y segura.
    """
    texto = (
        'PASAR LA CONFIGURACIÓN CON EL MÓVIL O PC.\n\n'
        'Para pasar datos con el móvil o el ordenador no hace falta ningún servidor ajeno. '
        'Todo se hace dentro de tu red local, sin intermediarios y sin que tus claves salgan '
        'de casa.\n\n'
        'FORMAS DE USARLO:\n\n'
        'DESDE EL MÓVIL O PC CON EL SERVIDOR WEB TEMPORAL. Pulsa "Traer una configuración desde '
        'el móvil o PC". Kodi abre un servidor temporal en tu red local y te da una dirección. '
        'Ábrela en el navegador de tu móvil o PC para pegar el código o subir el fichero (.json o '
        '.txt) directamente.\n\n'
        'CON UN FICHERO. "Guardar mi configuración en un fichero" guarda tus servidores en el disco. '
        'Pásalo a tu móvil u otro equipo por tu red o un pendrive, y pulsa "Traer una configuración '
        'de un fichero".\n\n'
        'CON EL CÓDIGO DE UNA LÍNEA. "Ver mi configuración como código" enseña en pantalla un '
        'código de una línea. Kodi no deja copiarlo, así que lo práctico es fotografiarlo para '
        'meterlo en otro Kodi con "Traer una configuración de un texto". Si haces una foto, '
        'bórrala cuando termines porque lleva tus contraseñas.')
    # En textviewer para permitir lectura completa del texto.
    xbmcgui.Dialog().textviewer('Pasar la configuración al móvil', texto)