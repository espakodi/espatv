# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Centro unificado de Cine Clásico: buscador, Filmoteca, listas maestras y dominio público."""
import os
import sys
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")


def _handle():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return 0


def _icon(name, fallback="DefaultMovies.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)


_ARCHIVE_ROWS = [
    ("Westerns clásicos",
     'subject:"western" AND mediatype:movies'),
    ("Cine clásico · Feature Films",
     "collection:feature_films AND mediatype:movies"),
    ("Cine en español (largometrajes)",
     '(language:spa OR language:Spanish) AND (subject:feature OR subject:pelicula OR subject:cine) AND mediatype:movies'),
    ("Film Noir y thriller clásico",
     'subject:"film noir" AND mediatype:movies'),
    ("Cine mudo (1895-1930)",
     "collection:silent_films AND mediatype:movies"),
    ("Ciencia ficción y terror clásico",
     "collection:SciFi_Horror AND mediatype:movies"),
    ("Comedia clásica (1910-1960)",
     'subject:"comedy" AND year:[1910 TO 1960] AND mediatype:movies'),
    ("Animación clásica",
     "collection:classic_cartoons AND mediatype:movies"),
    ("Archivo Prelinger (siglo XX)",
     "collection:prelinger AND mediatype:movies"),
    ("Blender Foundation (animación CC)",
     'creator:"Blender Foundation" AND mediatype:movies'),
]

_ARCHIVE_PLOTS = {
    "Westerns clásicos": "Más de 35.000 títulos del oeste americano y europeo de dominio público.",
    "Cine clásico · Feature Films": "Colección general de largometrajes históricos de Internet Archive (+28.000 títulos).",
    "Cine en español (largometrajes)": "Películas y largometrajes en lengua española disponibles en Internet Archive.",
    "Film Noir y thriller clásico": "Cine negro clásico americano y europeo de los años 40 y 50.",
    "Cine mudo (1895-1930)": "Obras maestras del cine silente internacional de principios del siglo XX.",
    "Ciencia ficción y terror clásico": "Clásicos de serie B, ciencia ficción de los años 50 y terror clásico.",
    "Comedia clásica (1910-1960)": "Comedias legendarias de la era dorada del cine.",
    "Animación clásica": "Cortos clásicos de animación tradicional de los años 30 a 50.",
    "Archivo Prelinger (siglo XX)": "Más de 10.000 documentos fílmicos de valor histórico, cultural y educativo.",
    "Blender Foundation (animación CC)": "Cortometrajes y películas abiertas producidas por la Blender Foundation (Creative Commons).",
}

# Monográficos por figuras clásicas del cine de dominio público:
_LEYENDAS_ROWS = [
    ("Charlie Chaplin · Obras maestras",
     '(subject:"Charlie Chaplin" OR title:"Charlie Chaplin") AND mediatype:movies'),
    ("Buster Keaton · Colección clásica",
     '(subject:"Buster Keaton" OR title:"Buster Keaton") AND mediatype:movies'),
    ("Sherlock Holmes · Cine clásico",
     '(subject:"Sherlock Holmes" OR title:"Sherlock Holmes") AND mediatype:movies'),
]

_LEYENDAS_PLOTS = {
    "Charlie Chaplin · Obras maestras": "Filmografía clásica de Charles Chaplin en dominio público.",
    "Buster Keaton · Colección clásica": "Clásicos cómicos y escenas de acción histórica de Buster Keaton.",
    "Sherlock Holmes · Cine clásico": "Adaptaciones cinematográficas clásicas del detective Sherlock Holmes.",
}

# Clasificaciones temáticas y por épocas del Catálogo Mundial de Internet Archive
_CATALOGO_MUNDIAL_ROWS = [
    ("Listar todas las películas (por popularidad)",
     "(collection:feature_films OR subject:feature) AND mediatype:movies AND year:[1895 TO 1980]",
     "cm_listar_todas.png",
     "Catálogo completo de largometrajes históricos de dominio público (+16.000 títulos) ordenados por descargas."),
    ("Cine mudo y orígenes (1895-1929)",
     "(collection:feature_films OR subject:feature) AND mediatype:movies AND year:[1895 TO 1929]",
     "cm_mudo_20s.png",
     "Los inicios de la cinematografía y obras maestras del cine silente internacional (+4.600 títulos)."),
    ("Años 30 · La era dorada (1930-1939)",
     "(collection:feature_films OR subject:feature) AND mediatype:movies AND year:[1930 TO 1939]",
     "cm_anos_30.png",
     "Nacimiento del cine sonoro, grandes comedias y primeras superproducciones de Hollywood (+3.700 títulos)."),
    ("Años 40 · Obras maestras y posguerra (1940-1949)",
     "(collection:feature_films OR subject:feature) AND mediatype:movies AND year:[1940 TO 1949]",
     "cm_anos_40.png",
     "Cine negro clásico, grandes dramas bélicos y obras cumbre del cine clásico (+3.300 títulos)."),
    ("Años 50 · Technicolor y serie B (1950-1959)",
     "(collection:feature_films OR subject:feature) AND mediatype:movies AND year:[1950 TO 1959]",
     "cm_anos_50.png",
     "Westerns en color, auge de la ciencia ficción, serie B y suspense de los años 50 (+2.200 títulos)."),
    ("Años 60 y 70 · Cine de culto (1960-1979)",
     "(collection:feature_films OR subject:feature) AND mediatype:movies AND year:[1960 TO 1979]",
     "cm_anos_60_70.png",
     "Películas de culto, cine independiente y producciones internacionales de dominio público (+2.200 títulos)."),
    ("Comedia clásica y Slapstick",
     "(collection:feature_films OR subject:feature) AND mediatype:movies AND subject:comedy AND year:[1895 TO 1980]",
     "cm_comedia.png",
     "Comedias de enredo, slapstick y humor legendario de la época dorada (+1.300 títulos)."),
    ("Misterio, Thriller e Intriga",
     "(collection:feature_films OR subject:feature) AND mediatype:movies AND (subject:mystery OR subject:suspense OR subject:thriller) AND year:[1895 TO 1980]",
     "cm_misterio.png",
     "Películas policíacas, misterios detectivescos, espionaje e intriga clásica."),
    ("Terror clásico y Ciencia Ficción",
     "(collection:feature_films OR subject:feature) AND mediatype:movies AND (subject:horror OR subject:scifi) AND year:[1895 TO 1980]",
     "cm_terror_scifi.png",
     "Monstruos clásicos, casas encantadas, invasiones espaciales y serie B."),
    ("Westerns clásicos",
     'subject:"western" AND mediatype:movies',
     "cm_western.png",
     "Duelos, forajidos, sheriffs y leyendas de la frontera americana."),
    ("Cine clásico en español (o subtitulado)",
     "(collection:feature_films OR subject:feature) AND mediatype:movies AND (language:spa OR language:Spanish)",
     "cm_espanol.png",
     "Largometrajes clásicos de habla hispana o con versión subtitulada en español."),
]


def show_menu():
    try:
        import ui_utils
        ui_utils.visto('cine_clasico')
    except Exception:
        pass

    h = _handle()
    if h == 0:
        return

    # Búsqueda en catálogos
    _add_item(h,
              label="[B]Buscar película (Internet Archive)[/B]",
              url=_u(action="archive_search_ui"),
              icon=_icon("archive.png", "DefaultAddonsSearch.png"),
              plot="Busca por título en el catálogo de Internet Archive con reproducción directa.")

    _add_item(h,
              label="[B]Búsqueda avanzada (Director · Año · Género)[/B]",
              url=_u(action="buscar_tops_menu"),
              icon=_icon("adv_busqueda.png", "DefaultAddonsSearch.png"),
              plot="Búsqueda especializada en catálogo y tops: por director, por año/década o por género.")

    _add_item(h,
              label="[B]Todas las películas (Internet Archive · Catálogo Mundial)[/B]",
              url=_u(action="todavia_mas_catalogo_mundial"),
              icon=_icon("archive_mundial.png", "DefaultMovies.png"),
              plot="Catálogo completo de películas de Internet Archive: listado general y clasificaciones por época, género, año e idioma.")

    # Filmoteca y cine español
    _add_item(h,
              label="[B]Filmoteca Española (Cine clásico restaurado)[/B]",
              url=_u(action="filmoteca_seccion", prog_id="58930", name="Filmoteca Española — Cine clásico"),
              icon=_icon("filmoteca_cine.png"),
              plot="Joyas del patrimonio fílmico y cine clásico español restauradas por Filmoteca Española y RTVE Play.")

    _add_item(h,
              label="[B]RTVE Play · Cine en abierto[/B]",
              url=_u(action="rtve_category", cat_id="866", cat_name="Cine"),
              icon=_icon("cat_cine.png"),
              plot="Películas completas disponibles gratuitamente en abierto en RTVE Play.")

    # Listas y selecciones
    _add_item(h,
              label="[B]1001 películas que ver antes de morir[/B]",
              url=_u(action="letterboxd_list",
                     list_key="1001 películas que ver",
                     list_url="https://letterboxd.com/peterstanley/list/1001-movies-you-must-see-before-you-die/"),
              icon=_icon("cine_1001_peliculas.png", "DefaultMovies.png"),
              plot="El célebre canon histórico de las 1001 películas imprescindibles según Letterboxd con metadatos y búsqueda de fuentes.")

    _add_item(h,
              label="[B]Grandes Clásicos de la Historia (130+ obras)[/B]",
              url=_u(action="peliculas_top", page=1),
              icon=_icon("top_peliculas_hist.png"),
              plot="Selección curada de clásicos legendarios de todos los tiempos: Casablanca, Psicosis, El Padrino, 12 hombres sin piedad, Cinema Paradiso...")

    _add_item(h,
              label="[B]Ganadoras del Oscar a Mejor Película (1939-hoy)[/B]",
              url=_u(action="oscar_movies", page=1),
              icon=_icon("oscar.png"),
              plot="Todas las películas ganadoras del Oscar desde 1939 hasta la actualidad, ordenadas cronológicamente con sinopsis y directores.")

    _add_item(h,
              label="[B]Archivo Histórico y NO-DO[/B]",
              url=_u(action="filmoteca_menu"),
              icon=_icon("cat_filmoteca.png"),
              plot="Fondo audiovisual histórico: noticiarios NO-DO (1943-1981), Archivo Alfonso XIII (1902-1931), documentales en B/N y series históricas.")

    # Colecciones de dominio público
    _add_item(h,
              label="[B]Colecciones de Dominio Público (Internet Archive)[/B]",
              url=_u(action="todavia_mas_archive"),
              icon=_icon("archive.png", "DefaultFolder.png"),
              plot="Catálogo masivo de cine libre y dominio público: Westerns, Cine mudo, Film Noir, Ciencia Ficción, Comedia clásica, Feature Films, Animación y Prelinger.")

    _add_item(h,
              label="[B]Cine Clásico Restaurado en HD/4K (Dominio Público)[/B]",
              url=_u(action="todavia_mas_restaurados"),
              icon=_icon("cine_restaurado_hd.png", "DefaultFolder.png"),
              plot="Películas de dominio público restauradas en alta definición y 4K: Cult Cinema Classics y PizzaFlix.")

    _add_item(h,
              label="[B]Grandes Leyendas del Cine[/B]",
              url=_u(action="todavia_mas_leyendas"),
              icon=_icon("cine_clasico.png", "DefaultFolder.png"),
              plot="Monográficos de las grandes figuras de la época dorada: Charlie Chaplin, Buster Keaton y Sherlock Holmes.")

    # Canales FAST
    _add_item(h,
              label="[B]Cine y Películas FAST en directo (24/7)[/B]",
              url=_u(action="view_custom_iptv", url="https://iptv-org.github.io/iptv/categories/movies.m3u"),
              icon=_icon("tv_cine_fast.png", "DefaultAddonPVRClient.png"),
              plot="Canales FAST gratuitos y lineales de cine y películas en streaming en directo.")

    xbmcplugin.endOfDirectory(h, cacheToDisc=True)


def show_archive_extra():
    h = _handle()
    if h == 0:
        return
    for label, query in _ARCHIVE_ROWS:
        desc = _ARCHIVE_PLOTS.get(label, "Resultados en directo desde Internet Archive.")
        plot = f"{desc}\n\nReproducción directa desde Archive.org (dominio público)."
        _add_item(h,
                  label=f"[B]{label}[/B]",
                  url=_u(action="archive_category", q=query, page=1),
                  icon=_icon("archive.png", "DefaultMovies.png"),
                  plot=plot)
    xbmcplugin.endOfDirectory(h, cacheToDisc=True)


def show_leyendas():
    h = _handle()
    if h == 0:
        return
    for label, query in _LEYENDAS_ROWS:
        desc = _LEYENDAS_PLOTS.get(label, "Resultados en directo desde Internet Archive.")
        plot = f"{desc}\n\nReproducción directa desde Archive.org (dominio público)."
        _add_item(h,
                  label=f"[B]{label}[/B]",
                  url=_u(action="archive_category", q=query, page=1),
                  icon=_icon("cine_clasico.png", "DefaultMovies.png"),
                  plot=plot)
    xbmcplugin.endOfDirectory(h, cacheToDisc=True)


def show_restaurados_hd():
    h = _handle()
    if h == 0:
        return
    channels = [
        ("Cult Cinema Classics (1080p/4K)",
         "UCycDFnpMeWzaITQSD1dWsOA",
         "Cult Cinema Classics",
         "canal_cult_cinema.png",
         "Más de 1.200 películas clásicas de dominio público restauradas en 1080p y 4K: cine negro, westerns, serie B, Buster Keaton, Charles Chaplin y terror clásico."),
        ("PizzaFlix (Cine clásico, Westerns y Serie B)",
         "UCE34fwgW7kWr7tc7YiOWtRw",
         "PizzaFlix",
         "canal_pizzaflix.png",
         "Archivo histórico remasterizado en alta definición de cine de dominio público: comedias clásicas, westerns, ciencia ficción y series de culto."),
    ]
    for label, channel_id, channel_name, icon_name, plot in channels:
        _add_item(
            h,
            label=f"[B]{label}[/B]",
            url=_u(action="yt_channel_tab", channel_id=channel_id, channel_name=channel_name, tab="videos"),
            icon=_icon(icon_name, "DefaultVideoPlaylists.png"),
            plot=plot,
        )
    xbmcplugin.endOfDirectory(h, cacheToDisc=True)


def show_catalogo_mundial():
    h = _handle()
    if h == 0:
        return

    _add_item(
        h,
        label="[B]Filtrar por año exacto...[/B]",
        url=_u(action="todavia_mas_filtro_ano"),
        icon=_icon("cm_filtro_ano.png", "DefaultAddonsSearch.png"),
        plot="Introduce un año específico (1895-1980) para listar únicamente las películas estrenadas ese año.",
        is_folder=False,
    )

    for label, query, icon_name, desc in _CATALOGO_MUNDIAL_ROWS:
        _add_item(
            h,
            label=f"[B]{label}[/B]",
            url=_u(action="archive_category", q=query, page=1),
            icon=_icon(icon_name, "DefaultMovies.png"),
            plot=f"{desc}\n\nReproducción directa desde Internet Archive (dominio público).",
            is_folder=True,
        )

    xbmcplugin.endOfDirectory(h, cacheToDisc=True)


def filtro_por_ano(ano=None):
    if not ano:
        kb = xbmcgui.Dialog().input("Filtrar por año (1895-1980):", type=xbmcgui.INPUT_NUMERIC)
        if not kb or not kb.strip().isdigit():
            return
        ano = int(kb.strip())
    else:
        try:
            ano = int(ano)
        except (ValueError, TypeError):
            return

    if ano < 1895 or ano > 1980:
        xbmcgui.Dialog().notification("EspaTV", "Introduce un año entre 1895 y 1980", xbmcgui.NOTIFICATION_WARNING)
        return

    q = f"(collection:feature_films OR subject:feature) AND mediatype:movies AND year:{ano}"
    target_url = _u(action="archive_category", q=q, page=1)
    xbmc.executebuiltin(f"Container.Update({target_url})")


def _add_item(h, label, url, icon, plot, is_folder=True):
    li = xbmcgui.ListItem(label=label)
    li.setContentLookup(False)
    li.setArt({'icon': icon, 'thumb': icon, 'poster': icon})
    li.setInfo('video', {'title': label, 'plot': plot})
    xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=is_folder)


