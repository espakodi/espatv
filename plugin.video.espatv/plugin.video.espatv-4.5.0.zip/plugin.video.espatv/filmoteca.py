# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Filmoteca Española, NO-DO y Archivo Histórico de RTVE Play."""

import hashlib
import html
import json
import os
import re
import sys
import time
import urllib.parse
import urllib.request
from urllib.parse import quote, urlencode

import xbmc
import xbmcgui
import xbmcplugin

from _user_agents import UA_DESKTOP
import core_settings

_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")

_HEADERS = {
    "User-Agent": UA_DESKTOP,
}

_PAGE_SIZE = 30

_FILMOTECA_SECTIONS = (
    {
        "name": "NO-DO (1943-1981)",
        "prog_id": "50991",
        "icon": os.path.join(_MEDIA, "filmoteca_nodo.png"),
        "plot": "Noticiarios cinematográficos oficiales y documentales de la España del siglo XX digitalizados por RTVE y Filmoteca Española.",
    },
    {
        "name": "NO-DO — Imágenes del Deporte",
        "prog_id": "82494",
        "icon": os.path.join(_MEDIA, "filmoteca_deporte.png"),
        "plot": "Ediciones monográficas deportivas históricas producidas por el equipo de NO-DO entre los años 50 y 70.",
    },
    {
        "name": "Filmoteca Española — Cine clásico",
        "prog_id": "58930",
        "icon": os.path.join(_MEDIA, "filmoteca_cine.png"),
        "plot": "Selección del archivo de cine clásico y joyas del patrimonio fílmico restauradas por Filmoteca Española.",
    },
    {
        "name": "Archivo Real Alfonso XIII (1902-1931)",
        "prog_id": "82495",
        "icon": os.path.join(_MEDIA, "filmoteca_real.png"),
        "plot": "Primeras filmaciones históricas de la época alfonsina, acontecimientos de principios del siglo XX y documentos de época.",
    },
    {
        "name": "Archivo Histórico de RTVE",
        "prog_id": "82496",
        "icon": os.path.join(_MEDIA, "filmoteca_documentales.png"),
        "plot": "Fondo documental, monográficos y películas históricas del gran archivo audiovisual de Televisión Española.",
    },
    {
        "name": "Documentales históricos en Blanco y Negro",
        "prog_id": "82493",
        "icon": os.path.join(_MEDIA, "filmoteca_docs_bn.png"),
        "plot": "Reportajes y documentales monográficos de los años 40, 50 y 60 conservados en blanco y negro.",
    },
    {
        "name": "Documentales históricos en Color",
        "prog_id": "82510",
        "icon": os.path.join(_MEDIA, "filmoteca_docs_color.png"),
        "plot": "Producciones documentales de historia, sociedad y costumbres en color de los años 60, 70 y transición.",
    },
    {
        "name": "Memoria de España",
        "prog_id": "43138",
        "icon": os.path.join(_MEDIA, "filmoteca_memoria.png"),
        "plot": "Serie documental histórica de 27 capítulos sobre la evolución de España desde la Prehistoria hasta la época contemporánea.",
    },
    {
        "name": "Informe Semanal — Archivo histórico",
        "prog_id": "1631",
        "icon": os.path.join(_MEDIA, "filmoteca_informe.png"),
        "plot": "Archivo histórico del programa decano de la televisión en España con los grandes reportajes de nuestra historia.",
    },
)

_LEGACY_QUERY_MAP = {
    "noticiarios": "50991",
    "nodo": "50991",
    "no-do": "50991",
    "filmoteca": "58930",
    "documental historia españa": "82496",
    "memoria de españa": "43138",
    "informe semanal": "1631",
}


def _log(msg):
    xbmc.log("[EspaTV][filmoteca] {0}".format(msg), xbmc.LOGINFO)


def _log_error(msg):
    xbmc.log("[EspaTV][filmoteca] ERROR: {0}".format(msg), xbmc.LOGERROR)


def _handle():
    return int(sys.argv[1])


def _u(**kwargs):
    return "{0}?{1}".format(sys.argv[0], urlencode(kwargs))


def _clean_text(text):
    if not text:
        return ""
    t = html.unescape(str(text))
    t = re.sub(r"<[^>]+>", "", t)
    return t.strip()


def _format_duration(dur_val):
    try:
        dur_int = int(dur_val or 0)
    except (ValueError, TypeError):
        return 0, ""
    dur_sec = dur_int // 1000 if dur_int > 86400 else dur_int
    if dur_sec <= 0:
        return 0, ""
    hours = dur_sec // 3600
    mins = (dur_sec % 3600) // 60
    secs = dur_sec % 60
    if hours > 0:
        dur_label = "{0} h {1} min".format(hours, mins) if mins else "{0} h".format(hours)
    elif mins > 0:
        dur_label = "{0} min {1} s".format(mins, secs) if secs else "{0} min".format(mins)
    else:
        dur_label = "{0} s".format(secs)
    return dur_sec, dur_label


def _emission_sort_key(item):
    doe = str(item.get("dateOfEmission") or "")
    if len(doe) >= 10 and doe[2] == "-" and doe[5] == "-":
        return doe[6:10] + doe[3:5] + doe[0:2] + doe[11:]
    pub = str(item.get("publicationDate") or "")
    if len(pub) >= 10 and pub[2] == "-" and pub[5] == "-":
        return pub[6:10] + pub[3:5] + pub[0:2] + pub[11:]
    return "99999999"


def _fetch_json(url, timeout=15):
    ttl = core_settings.get_iptv_cache_ttl()
    cache_file = ""
    if core_settings.is_iptv_cache_active() and ttl > 0:
        cache_dir = core_settings.get_iptv_cache_dir()
        cache_key = hashlib.md5(url.encode("utf-8")).hexdigest()
        cache_file = os.path.join(cache_dir, "filmoteca_" + cache_key + ".json")
        if os.path.isfile(cache_file):
            try:
                if (time.time() - os.path.getmtime(cache_file)) < ttl:
                    with open(cache_file, "r", encoding="utf-8") as f:
                        data = json.load(f)
                        if isinstance(data, dict) and "content" in data:
                            return data["content"]
            except (OSError, ValueError):
                pass

    req = urllib.request.Request(url, headers=_HEADERS)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        raw = resp.read()
    data = json.loads(raw.decode("utf-8", errors="replace"))

    if core_settings.is_iptv_cache_active() and ttl > 0 and cache_file:
        try:
            core_settings.atomic_write_json(cache_file, {"ts": time.time(), "url": url, "content": data})
        except OSError:
            pass

    return data


def _find_section_icon(prog_id):
    for sec in _FILMOTECA_SECTIONS:
        if sec.get("prog_id") == str(prog_id):
            return sec.get("icon", "")
    return os.path.join(_MEDIA, "filmoteca_documentales.png")


def _add_filmoteca_video_item(h, item, fallback_icon=""):
    if not isinstance(item, dict):
        return
    raw_title = item.get("title") or item.get("name") or ""
    title = _clean_text(raw_title) or "Vídeo histórico"
    raw_desc = item.get("shortDescription") or item.get("description") or ""
    desc = _clean_text(raw_desc)
    thumb = item.get("thumbnail") or item.get("imageSEO") or item.get("image") or fallback_icon or "DefaultVideo.png"

    dur_sec, dur_label = _format_duration(item.get("duration", 0))
    pub_date = str(item.get("publicationDate", "") or "")
    video_id = str(item.get("id", "")).strip()
    if not video_id:
        return

    plot_parts = []
    if desc:
        plot_parts.append(desc)
    if dur_label:
        plot_parts.append("Duración: {0}".format(dur_label))
    if pub_date:
        plot_parts.append("Publicado: {0}".format(pub_date[:10]))
    plot = "\n\n".join(plot_parts) if plot_parts else title

    art_thumb = "DefaultVideo.png" if core_settings.is_modo_ligero_active() else thumb
    li = xbmcgui.ListItem(label=title)
    li.setArt({
        "icon": art_thumb,
        "thumb": art_thumb,
        "poster": art_thumb,
        "fanart": art_thumb,
        "banner": art_thumb,
    })
    li.setContentLookup(False)
    li.setProperty("IsPlayable", "true")

    li.setInfo("video", {
        "title": title,
        "plot": plot,
        "duration": dur_sec,
    })

    web_url = item.get("htmlShortUrl", item.get("htmlUrl", "")) or ""
    if not web_url and video_id:
        web_url = "https://www.rtve.es/v/{0}/".format(video_id)

    cm = [
        ("Buscar en Dailymotion", "Container.Update({0})".format(_u(action="lfr", q=title, ot=""))),
        ("Ver en RTVE.es", "RunPlugin({0})".format(_u(action="rtve_open_web", url=web_url, title=title))),
    ]
    if web_url:
        cm.append(("Copiar URL", "RunPlugin({0})".format(_u(action="copy_url", url=web_url))))

    fav_params = json.dumps({"video_id": video_id, "title": title, "ctype": "video", "burl": web_url})
    cm.append(("Añadir a Mis Favoritos (EspaTV)", "RunPlugin({0})".format(
        _u(action="add_favorite", title=title, fav_url="rtve_" + video_id,
           icon=thumb, platform="rtve", fav_action="play_rtve_video", params=fav_params))))
    li.addContextMenuItems(cm)

    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="play_rtve_video", video_id=video_id, title=title),
        listitem=li,
        isFolder=False,
    )


def show_filmoteca_menu():
    """Menú principal de Filmoteca y NO-DO."""
    h = _handle()
    try:
        xbmcplugin.setPluginCategory(h, "Filmoteca y NO-DO")
    except Exception:
        pass

    try:
        li = xbmcgui.ListItem(label="[B][COLOR khaki]Buscar en archivo histórico de RTVE...[/COLOR][/B]")
        ico_buscar = os.path.join(_MEDIA, "filmoteca_buscar.png")
        li.setArt({"icon": ico_buscar, "thumb": ico_buscar, "poster": ico_buscar})
        li.setContentLookup(False)
        li.setInfo("video", {"plot": "Buscar contenido histórico por título o temática en el catálogo de RTVE Play."})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="filmoteca_search"), listitem=li, isFolder=True)

        for sec in _FILMOTECA_SECTIONS:
            li = xbmcgui.ListItem(label="[B]{0}[/B]".format(sec["name"]))
            li.setArt({"icon": sec["icon"], "thumb": sec["icon"], "poster": sec["icon"]})
            li.setContentLookup(False)
            li.setInfo("video", {"plot": sec["plot"]})
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="filmoteca_seccion", prog_id=sec["prog_id"], name=sec["name"]),
                listitem=li,
                isFolder=True,
            )
    except Exception as e:
        _log_error("show_filmoteca_menu: {0}".format(e))

    try:
        xbmcplugin.endOfDirectory(h)
    except RuntimeError:
        pass


def show_filmoteca_seccion(prog_id_or_query="", name="", page=1):
    h = _handle()
    if not prog_id_or_query:
        try:
            xbmcplugin.endOfDirectory(h, succeeded=False)
        except RuntimeError:
            pass
        return

    try:
        page = int(page)
    except (ValueError, TypeError):
        page = 1
    if page < 1:
        page = 1

    target = str(prog_id_or_query).strip()
    prog_id = ""
    if target.isdigit():
        prog_id = target
    else:
        prog_id = _LEGACY_QUERY_MAP.get(target.lower(), "")

    if name:
        try:
            xbmcplugin.setPluginCategory(h, name)
        except Exception:
            pass

    fallback_icon = _find_section_icon(prog_id)

    if prog_id:
        api_url = "https://api.rtve.es/api/programas/{0}/videos.json?page={1}&size={2}".format(
            prog_id, page, _PAGE_SIZE
        )
    else:
        api_url = (
            "https://api.rtve.es/api/search/contents"
            "?search={0}&page={1}&size={2}&context=tve"
            "&type=completo&tipology=video"
            "&isExpanded=true&isChild=true"
            "&useOntology=false"
        ).format(quote(target), page, _PAGE_SIZE)

    try:
        data = _fetch_json(api_url)
        page_info = data.get("page", {}) if isinstance(data, dict) else {}
        items = page_info.get("items", []) or []

        if not items:
            xbmcgui.Dialog().notification(
                "Filmoteca", "Sin resultados disponibles en esta sección",
                xbmcgui.NOTIFICATION_INFO, 2500
            )
            try:
                xbmcplugin.endOfDirectory(h, succeeded=True, cacheToDisc=True)
            except RuntimeError:
                pass
            return

        # Para Memoria de España (43138), ordenar cronológicamente por emisión si caben en una página
        if prog_id == "43138" and len(items) <= _PAGE_SIZE:
            try:
                items = sorted(items, key=_emission_sort_key)
            except Exception:
                pass

        for item in items:
            _add_filmoteca_video_item(h, item, fallback_icon)

        total_pages = int(page_info.get("totalPages", 1) or 1)
        current_page = int(page_info.get("number", page) or page)

        if current_page > 1:
            li_prev = xbmcgui.ListItem(label="[COLOR yellow]← Página anterior ({0}/{1})[/COLOR]".format(
                current_page - 1, total_pages
            ))
            li_prev.setArt({"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})
            li_prev.setContentLookup(False)
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="filmoteca_seccion", prog_id=prog_id or target, name=name, page=current_page - 1),
                listitem=li_prev,
                isFolder=True,
            )

        if current_page < total_pages:
            li_next = xbmcgui.ListItem(label="[COLOR limegreen]Página siguiente ({0}/{1})[/COLOR]".format(
                current_page + 1, total_pages
            ))
            li_next.setArt({"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})
            li_next.setContentLookup(False)
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="filmoteca_seccion", prog_id=prog_id or target, name=name, page=current_page + 1),
                listitem=li_next,
                isFolder=True,
            )

        try:
            xbmcplugin.endOfDirectory(h, succeeded=True, cacheToDisc=True)
        except RuntimeError:
            pass

    except (OSError, ValueError, KeyError) as e:
        _log_error("show_filmoteca_seccion ({0}): {1}".format(target, e))
        xbmcgui.Dialog().notification(
            "Filmoteca", "Sección no disponible temporalmente",
            xbmcgui.NOTIFICATION_WARNING, 3000
        )
        try:
            xbmcplugin.endOfDirectory(h, succeeded=False)
        except RuntimeError:
            pass


def filmoteca_search(query="", page=1):
    h = _handle()
    if not query:
        kb = xbmc.Keyboard("", "Buscar en archivo histórico de RTVE")
        kb.doModal()
        if not kb.isConfirmed() or not kb.getText().strip():
            try:
                xbmcplugin.endOfDirectory(h, succeeded=False)
            except RuntimeError:
                pass
            return
        query = kb.getText().strip()

    try:
        page = int(page)
    except (ValueError, TypeError):
        page = 1
    if page < 1:
        page = 1

    try:
        xbmcplugin.setPluginCategory(h, "Búsqueda: {0}".format(query))
    except Exception:
        pass

    api_url = (
        "https://api.rtve.es/api/search/contents"
        "?search={0}&page={1}&size={2}&context=tve"
        "&type=completo&tipology=video"
        "&isExpanded=true&isChild=true"
        "&useOntology=false"
    ).format(quote(query), page, _PAGE_SIZE)

    ico_buscar = os.path.join(_MEDIA, "filmoteca_buscar.png")

    try:
        data = _fetch_json(api_url)
        page_info = data.get("page", {}) if isinstance(data, dict) else {}
        items = page_info.get("items", []) or []

        if not items:
            xbmcgui.Dialog().notification(
                "Filmoteca", "Sin resultados para '{0}'".format(query),
                xbmcgui.NOTIFICATION_INFO, 2500
            )
            try:
                xbmcplugin.endOfDirectory(h, succeeded=True, cacheToDisc=True)
            except RuntimeError:
                pass
            return

        for item in items:
            _add_filmoteca_video_item(h, item, ico_buscar)

        total_pages = int(page_info.get("totalPages", 1) or 1)
        current_page = int(page_info.get("number", page) or page)

        if current_page > 1:
            li_prev = xbmcgui.ListItem(label="[COLOR yellow]← Página anterior ({0}/{1})[/COLOR]".format(
                current_page - 1, total_pages
            ))
            li_prev.setArt({"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})
            li_prev.setContentLookup(False)
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="filmoteca_search", q=query, page=current_page - 1),
                listitem=li_prev,
                isFolder=True,
            )

        if current_page < total_pages:
            li_next = xbmcgui.ListItem(label="[COLOR limegreen]Página siguiente ({0}/{1})[/COLOR]".format(
                current_page + 1, total_pages
            ))
            li_next.setArt({"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})
            li_next.setContentLookup(False)
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="filmoteca_search", q=query, page=current_page + 1),
                listitem=li_next,
                isFolder=True,
            )

        try:
            xbmcplugin.endOfDirectory(h, succeeded=True, cacheToDisc=True)
        except RuntimeError:
            pass

    except (OSError, ValueError, KeyError) as e:
        _log_error("filmoteca_search ({0}): {1}".format(query, e))
        xbmcgui.Dialog().notification(
            "Filmoteca", "Error en la búsqueda",
            xbmcgui.NOTIFICATION_WARNING, 3000
        )
        try:
            xbmcplugin.endOfDirectory(h, succeeded=False)
        except RuntimeError:
            pass

