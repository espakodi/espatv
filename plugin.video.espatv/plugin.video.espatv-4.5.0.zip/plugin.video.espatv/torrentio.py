# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Cliente de Torrentio (protocolo Stremio) y normalización de sus fuentes.

Sin dependencias de Kodi: se importa y se testea con Python normal.
"""
import json
import re
import socket
import urllib.error
import urllib.parse
import urllib.request

from debrid_filesel import episode_keys

DEFAULT_URL = "https://torrentio.strem.fun"

_VIDEO_EXTS = (
    ".mkv", ".mp4", ".avi", ".ts", ".mov", ".wmv", ".webm", ".m4v", ".mpg", ".mpeg", ".flv",
)
_USER_AGENT = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
    "(KHTML, like Gecko) Chrome/124.0 Safari/537.36"
)
_MAX_RAW = 500
_MIN_BYTES = 100 * 1000 * 1000
_MAX_MOVIE_BYTES = 60 * 1000 * 1000 * 1000

_HASH_RE = re.compile(r"^[0-9a-f]{40}$")
_IMDB_RE = re.compile(r"^tt\d{7,10}$")
_KEY_IN_URL_RE = re.compile(
    r"(?:realdebrid|alldebrid|premiumize|torbox|debridlink|offcloud|putio)=", re.I
)

# Sin el emoji, el primer número del texto (el año) se colaría como seeders.
_SIZE_RE = re.compile(r"\U0001F4BE\s*([\d.,]+)\s*(TB|GB|MB|KB)", re.I)
_SEED_RE = re.compile(r"\U0001F464\s*(\d+)")
_PROV_RE = re.compile("\N{GEAR}\N{VARIATION SELECTOR-16}?\\s*(\\S+)")
_META_MARKS = ("\U0001F464", "\U0001F4BE", "\N{GEAR}")
_FLAG_RE = re.compile("[\U0001F1E6-\U0001F1FF]{2}")

_NAME_QUALITY_RE = re.compile(r"(?<![a-z0-9])(4k|2160p|1440p|1080p|720p|480p)(?![a-z0-9])", re.I)
_RELEASE_QUALITY_RES = (
    (re.compile(r"(?<![a-z0-9])(2160p|4k|uhd)(?![a-z0-9])", re.I), "2160p"),
    (re.compile(r"(?<![a-z0-9])1440p(?![a-z0-9])", re.I), "1440p"),
    (re.compile(r"(?<![a-z0-9])1080[pi](?![a-z0-9])", re.I), "1080p"),
    (re.compile(r"(?<![a-z0-9])720p(?![a-z0-9])", re.I), "720p"),
    (re.compile(r"(?<![a-z0-9])480p(?![a-z0-9])", re.I), "480p"),
)
# El hueco entre 480p y 720p hace que un 4K quede más cerca de 1080p que un 480p.
QUALITY_RANK = {"2160p": 6, "1440p": 5, "1080p": 4, "720p": 3, "480p": 1, "SD": 0}
_LOW_QUALITY_TOKENS = frozenset((
    "cam", "hdcam", "hqcam", "camrip", "hdts", "telesync", "telecine", "hdtc", "scr", "dvdscr",
))
_CAM_WORDS = _LOW_QUALITY_TOKENS
_PACK_RE = re.compile(r"(?<![a-z0-9])(s\d{2}|season\s*\d+|temporada\s*\d+|complete|integrale)(?![a-z0-9])", re.I)
_EP_IN_RELEASE_RE = re.compile(r"s\d{1,2}[ ._-]?ep?\d{1,3}(?!\d)", re.I)
# "S01E01-10" nombra varios episodios; "S01E01-720p" es un episodio con su calidad.
_EP_RANGE_RE = re.compile(r"s\d{1,2}[ ._-]?ep?\d{1,3}[ ._]?-\s?e?p?\d{1,3}(?![\dp])", re.I)

# Palabras que también son palabras corrientes en un título ("Cast Away", "The Spa"):
# solo cuentan escritas en mayúsculas o en minúsculas, nunca como "Cast".
_AMBIGUOUS = frozenset(("cast", "esp", "spa", "lat"))
_CASTILIAN = frozenset(("castellano", "cast", "spanish", "español", "espanol", "esp", "spa"))
_LATIN = frozenset(("latino", "latam", "lat"))
_MULTI = frozenset(("multi", "dual"))
_SUBS_ONLY = frozenset(("vose",))
_LANG_WORDS = r"(?:castellano|spanish|espa[ñn]ol|latino|spa|esp|lat)"
_SUB_WORDS = r"(?:subtitles?|subtitulad[oa]s?|subtitulos?|subs?)"
# En los dos órdenes: «Spanish Subtitles» y «Subtitulado.Esp» (visto en un estreno real). Primero
# «subs + idioma», para que en «Castellano.Subs.Esp» no se lleve el «Castellano» del audio.
_SUB_PHRASE_RES = (
    re.compile(rf"(?<![a-z0-9]){_SUB_WORDS}[ ._-]*{_LANG_WORDS}(?![a-z0-9])", re.I),
    re.compile(rf"(?<![a-z0-9]){_LANG_WORDS}[ ._-]*{_SUB_WORDS}(?![a-z0-9])", re.I),
)
_CODE_RUN_RE = re.compile(r"(?<![A-Za-z0-9])[A-Z]{2,3}(?:[ ._/|,+-]+[A-Z]{2,3})+(?![A-Za-z0-9])")
_ES_CODE_RE = re.compile(r"(?<![A-Za-z0-9])ES(?![A-Za-z0-9])")
_LATAM_FLAGS = frozenset(("MX", "AR", "CO", "CL", "PE", "VE", "UY", "CR"))
_MAX_SHORT_FLAGS = 3

LANG_BADGES = {0: "[ESP]", 1: "[LAT]", 2: "[MULTI+ES]", 3: "[ESP?]", 4: ""}


class TorrentioError(Exception):
    def __init__(self, message, http_status=None):
        super().__init__(message)
        self.http_status = http_status


def _looks_like_video(name):
    return str(name or "").lower().endswith(_VIDEO_EXTS)


def _basename(path):
    return str(path or "").replace("\\", "/").rsplit("/", 1)[-1]


def _parse_size(text):
    m = _SIZE_RE.search(text or "")
    if not m:
        return 0
    raw = m.group(1)
    if "," in raw and "." in raw:
        raw = raw.replace(",", "")
    else:
        raw = raw.replace(",", ".")
    try:
        value = float(raw)
    except ValueError:
        return 0
    return int(value * {"TB": 1e12, "GB": 1e9, "MB": 1e6, "KB": 1e3}[m.group(2).upper()])


def _parse_quality(name, release):
    """Primero lo que ya clasificó Torrentio en `name`; luego el nombre del release."""
    second = name.split("\n", 1)[1] if "\n" in name else ""
    m = _NAME_QUALITY_RE.search(second)
    if m:
        value = m.group(1).lower()
        return "2160p" if value == "4k" else value
    for rx, quality in _RELEASE_QUALITY_RES:
        if rx.search(release):
            return quality
    return "SD"


def _is_low_quality(name, release):
    words = re.findall(r"[^\W_]+", f"{name} {release}".casefold())
    return any(w in _LOW_QUALITY_TOKENS for w in words)


_is_cam = _is_low_quality


def _looks_like_pack(text):
    if _EP_RANGE_RE.search(text):
        return True
    return bool(_PACK_RE.search(text)) and not _EP_IN_RELEASE_RE.search(text)


def _flag_codes(text):
    return [chr(ord(a) - 0x1F1E6 + 65) + chr(ord(b) - 0x1F1E6 + 65) for a, b in _FLAG_RE.findall(text or "")]


def _words(text):
    """Palabras en minúsculas; las ambiguas ('Cast') solo valen si no van en Title Case."""
    out = set()
    for tok in re.findall(r"[^\W_]+", text):
        low = tok.casefold()
        if low in _AMBIGUOUS and not (tok.isupper() or tok.islower()):
            continue
        out.add(low)
    return out


def spanish_rank(text, flags_line=""):
    """0 castellano, 1 latino, 2 multi con español, 3 dudoso o solo subtítulos, 4 sin español.

    ``text`` es release + ruta + línea de idiomas; ``flags_line`` la línea de banderas.
    Torrentio mezcla audio y subtítulos en las banderas: más de 3 no prueban audio.
    """
    text = f"{text or ''} {flags_line or ''}"
    subs_es = False
    for rx in _SUB_PHRASE_RES:
        text, found = rx.subn(" ", text)
        subs_es = subs_es or bool(found)
    words = _words(text)

    code_list_es = False
    for run in _CODE_RUN_RE.findall(text):
        codes = re.findall(r"[A-Z]{2,3}", run)
        if "ES" in codes and len(codes) >= 3:
            code_list_es = True
    lone_es = bool(_ES_CODE_RE.search(text)) and not text.isupper()

    cast = bool(words & _CASTILIAN) or lone_es
    lat = bool(words & _LATIN)
    multi = bool(words & _MULTI) or code_list_es
    if code_list_es:
        cast = True

    flags = _flag_codes(text)
    flag_es = "ES" in flags
    flag_lat = bool(_LATAM_FLAGS & set(flags))
    short_flags = len(flags) <= _MAX_SHORT_FLAGS
    if short_flags and (flag_es or flag_lat) and not (cast or lat or subs_es):
        cast, lat = flag_es, flag_lat and not flag_es
        multi = multi or len(flags) > 1
    long_flags_es = not short_flags and (flag_es or flag_lat)

    if cast or lat:
        if multi:
            return 2
        return 0 if cast else 1
    if subs_es or (words & _SUBS_ONLY) or long_flags_es:
        return 3
    return 4


class Stream:
    """Una fuente de Torrentio normalizada."""

    def __init__(self, raw):
        self.info_hash = str(raw.get("infoHash") or "").lower()
        file_idx = raw.get("fileIdx")
        self.file_idx = file_idx if isinstance(file_idx, int) else None
        # Es la respuesta de un tercero; un campo con otro tipo no debe tumbar el listado entero.
        name = str(raw.get("name") or "")
        title = str(raw.get("title") or "")
        lines = [ln.strip() for ln in title.split("\n") if ln.strip()]
        self.release = lines[0] if lines else ""

        meta_at = next((i for i, ln in enumerate(lines) if i and any(m in ln for m in _META_MARKS)), None)
        meta_line = lines[meta_at] if meta_at is not None else ""
        before_meta = lines[1:meta_at] if meta_at is not None else lines[1:]
        path_lines = [ln for ln in before_meta if _looks_like_video(ln)]
        lang_lines = lines[meta_at + 1:] if meta_at is not None else before_meta

        hints = raw.get("behaviorHints")
        filename = str((hints.get("filename") if isinstance(hints, dict) else "") or "")
        if _looks_like_video(filename):
            self.file_hint = _basename(filename)
        else:
            self.file_hint = _basename(path_lines[0]) if path_lines else None

        self.size_bytes = _parse_size(meta_line)
        seeds = _SEED_RE.search(meta_line)
        self.seeders = int(seeds.group(1)) if seeds else 0
        prov = _PROV_RE.search(meta_line)
        self.provider = prov.group(1) if prov else ""

        self.quality = _parse_quality(name, self.release)
        self.is_low_quality = _is_low_quality(name, self.release)
        self.is_cam = self.is_low_quality
        folders = [ln.replace("\\", "/").rsplit("/", 1)[0] for ln in path_lines if "/" in ln.replace("\\", "/")]
        self.is_pack = any(_looks_like_pack(t) for t in [self.release, *folders])

        evidence = " ".join([self.release, *path_lines, self.file_hint or ""])
        flags_line = " ".join(lang_lines)
        self.lang_rank = spanish_rank(evidence, flags_line)
        self.cached = None

    def __repr__(self):
        return f"<Stream {self.quality} {self.info_hash[:8]} seeds={self.seeders} cached={self.cached}>"


def parse_streams(raw_streams):
    """Convierte la respuesta de Torrentio; descarta lo irresoluble y deduplica por (hash, fichero)."""
    best = {}
    for raw in (raw_streams or [])[:_MAX_RAW]:
        if not isinstance(raw, dict):
            continue
        stream = Stream(raw)
        if not _HASH_RE.match(stream.info_hash):
            continue
        key = (stream.info_hash, stream.file_idx)
        prev = best.get(key)
        if prev is None or stream.seeders > prev.seeders:
            best[key] = stream
    return list(best.values())


def filter_streams(streams, media_type, episode_key=None, only_spanish=False):
    """Descarta lo que no merece ni comprobarse. Nunca por semillas: lo cacheado se ve sin ellas."""
    out = []
    for s in streams:
        if s.size_bytes and s.size_bytes < _MIN_BYTES:
            continue
        if media_type == "movie" and s.size_bytes > _MAX_MOVIE_BYTES:
            continue
        if media_type == "series":
            if not s.file_hint:
                continue
            hint_eps = episode_keys(s.file_hint)
            if episode_key and hint_eps and episode_key not in hint_eps:
                continue
        if only_spanish and s.lang_rank > 2:
            continue
        out.append(s)
    return out


def sort_streams(streams, preferred_quality="1080p", prefer_spanish=True):
    """Caché primero, luego idioma, cercanía a la calidad preferida (a igual distancia, la menor),
    semillas y tamaño. Las fuentes de calidad preliminar se sitúan al final."""
    pref = QUALITY_RANK.get(preferred_quality, QUALITY_RANK["1080p"])

    def key(s):
        diff = QUALITY_RANK.get(s.quality, 0) - pref
        cached = 0 if s.cached is True else (1 if s.cached is None else 2)
        return (
            1 if s.is_low_quality else 0,
            cached,
            s.lang_rank if prefer_spanish else 0,
            abs(diff),
            diff > 0,
            -s.seeders,
            s.size_bytes,
        )

    return sorted(streams, key=key)


def normalize_imdb_id(value):
    text = str(value or "").strip().lower()
    if re.fullmatch(r"\d{1,10}", text):
        text = "tt" + text.zfill(7)
    return text if _IMDB_RE.match(text) else None


def normalize_base_url(url):
    """Quita espacios, barras finales y el /manifest.json que se copia de Stremio."""
    text = (url or "").strip().rstrip("/")
    if text.lower().endswith("/manifest.json"):
        text = text[: -len("/manifest.json")]
    return text.rstrip("/")


def validate_base_url(url):
    """Devuelve la URL normalizada o lanza ValueError con el motivo, listo para mostrar."""
    text = normalize_base_url(url)
    parts = urllib.parse.urlsplit(text)
    if parts.scheme not in ("http", "https") or not parts.netloc:
        raise ValueError("La dirección debe empezar por http:// o https://")
    if _KEY_IN_URL_RE.search(text):
        raise ValueError("Quita tu clave Debrid de la URL de Torrentio: EspaTV usa tu cuenta directamente")
    return text


class TorrentioClient:
    def __init__(self, base_url=DEFAULT_URL, timeout=12):
        self.base_url = validate_base_url(base_url or DEFAULT_URL)
        self.timeout = timeout

    def get_streams(self, media_type, imdb_id, season=None, episode=None):
        """Fuentes ya normalizadas. Lanza TorrentioError si el servicio no contesta bien."""
        imdb = normalize_imdb_id(imdb_id)
        if imdb is None:
            raise ValueError("ID de IMDb no válido")
        if media_type == "movie":
            path = f"/stream/movie/{imdb}.json"
        elif media_type == "series":
            if season is None or episode is None:
                raise ValueError("Una serie necesita temporada y episodio")
            path = f"/stream/series/{imdb}:{int(season)}:{int(episode)}.json"
        else:
            raise ValueError(f"Tipo desconocido: {media_type}")

        request = urllib.request.Request(
            self.base_url + path,
            headers={"User-Agent": _USER_AGENT, "Accept": "application/json"},
        )
        try:
            with urllib.request.urlopen(request, timeout=self.timeout) as response:
                body = response.read().decode("utf-8", "replace")
            data = json.loads(body or "{}")
        except urllib.error.HTTPError as e:
            raise TorrentioError(f"HTTP {e.code}", e.code)
        except (urllib.error.URLError, socket.timeout, OSError) as e:
            raise TorrentioError(str(e))
        except ValueError:
            raise TorrentioError("respuesta no válida")
        streams = data.get("streams") if isinstance(data, dict) else None
        return parse_streams(streams if isinstance(streams, list) else [])
