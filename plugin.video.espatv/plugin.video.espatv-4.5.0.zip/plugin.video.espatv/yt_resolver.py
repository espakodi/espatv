# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Resolvedor nativo de streams de YouTube para EspaTV (sin dependencias externas)."""

import json
import re
import sys
import threading
import time
import urllib.error
import urllib.parse
import urllib.request

try:
    import xbmc
    import xbmcgui
    import xbmcplugin
except ImportError:
    xbmc = None
    xbmcgui = None
    xbmcplugin = None

import youtube_bridge

try:
    import yt_watched_tracker
except ImportError:
    yt_watched_tracker = None

try:
    import ytdlp_resolver
except ImportError:
    ytdlp_resolver = None

try:
    import core_settings
except ImportError:
    core_settings = None


_IOS_HEADERS = {
    "User-Agent": "com.google.ios.youtube/20.20.7 (iPhone16,2; U; CPU iOS 17_5_1 like Mac OS X)",
    "X-YouTube-Client-Name": "5",
    "X-YouTube-Client-Version": "20.20.7",
    "Content-Type": "application/json",
}

_ANDROID_HEADERS = {
    "User-Agent": "com.google.android.youtube/20.10.38 (Linux; U; Android 14) gzip",
    "X-YouTube-Client-Name": "3",
    "X-YouTube-Client-Version": "20.10.38",
    "Content-Type": "application/json",
}

_VISIONOS_HEADERS = {
    "User-Agent": (
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/605.1.15 "
        "(KHTML, like Gecko) Version/18.0 Safari/605.1.15"
    ),
    "X-YouTube-Client-Name": "101",
    "X-YouTube-Client-Version": "0.1",
    "Content-Type": "application/json",
}

_TIMEOUT = 12


def _extract_video_id(video_id_or_url):
    if not video_id_or_url:
        return ""
    s = str(video_id_or_url).strip()
    if "/" in s or "?" in s or "&" in s:
        m = re.search(r"(?:v=|\/|vi\/|shorts\/|live\/|embed\/)([0-9A-Za-z_-]{11})", s)
        if m:
            return m.group(1)
    return s


def _post_player(payload, headers):
    url = "https://www.youtube.com/youtubei/v1/player?prettyPrint=false"
    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            return json.loads(raw)
    except (urllib.error.URLError, ValueError, OSError) as exc:
        if xbmc:
            xbmc.log(f"[EspaTV/yt_resolver] Error HTTP en player: {exc}", xbmc.LOGWARNING)
        return None


def resolve(video_id, audio_only=False):
    video_id = _extract_video_id(video_id)
    if not video_id:
        return None

    visitor_data = None
    if not audio_only:
        payload_ios = {
            "videoId": video_id,
            "params": "2AMB",
            "context": {
                "client": {
                    "clientName": "IOS",
                    "clientVersion": "20.20.7",
                    "deviceMake": "Apple",
                    "deviceModel": "iPhone16,2",
                    "osName": "iOS",
                    "osVersion": "17.5.1.21F90",
                    "hl": "es",
                    "gl": "ES",
                }
            },
        }
        data_ios = _post_player(payload_ios, _IOS_HEADERS)
        if data_ios:
            visitor_data = data_ios.get("responseContext", {}).get("visitorData")
            status = data_ios.get("playabilityStatus", {}).get("status", "")
            streaming = data_ios.get("streamingData", {})
            hls_url = streaming.get("hlsManifestUrl")
            vdetails = data_ios.get("videoDetails", {})

            captions_track = (
                data_ios.get("captions", {})
                .get("playerCaptionsTracklistRenderer", {})
                .get("captionTracks", [])
            )
            subs = []
            for t in captions_track:
                lc = t.get("languageCode", "")
                if lc in ("es", "es-419", "es-ES", "en") and t.get("baseUrl"):
                    subs.append(t["baseUrl"] + "&fmt=vtt")

            if status == "OK" and hls_url:
                return {
                    "url": hls_url,
                    "type": "hls",
                    "user_agent": _IOS_HEADERS["User-Agent"],
                    "title": vdetails.get("title", ""),
                    "channel": vdetails.get("author", ""),
                    "channel_id": vdetails.get("channelId", ""),
                    "duration": int(vdetails.get("lengthSeconds", 0) or 0),
                    "is_live": bool(vdetails.get("isLiveContent", False)),
                    "subtitles": subs,
                }

    payload_android = {
        "videoId": video_id,
        "params": "2AMB",
        "context": {
            "client": {
                "clientName": "ANDROID",
                "clientVersion": "20.10.38",
                "androidSdkVersion": 34,
                "osName": "Android",
                "osVersion": "14",
                "hl": "es",
                "gl": "ES",
            }
        },
    }
    if visitor_data:
        payload_android["context"]["client"]["visitorData"] = visitor_data

    data_android = _post_player(payload_android, _ANDROID_HEADERS)
    if data_android:
        status = data_android.get("playabilityStatus", {}).get("status", "")
        streaming = data_android.get("streamingData", {})
        vdetails = data_android.get("videoDetails", {})

        if status == "OK":
            if audio_only:
                adaptive = streaming.get("adaptiveFormats", [])
                best_audio = next((f["url"] for f in adaptive if f.get("itag") == 140 and "url" in f), None)
                if not best_audio:
                    best_audio = next((f["url"] for f in adaptive if f.get("itag") == 251 and "url" in f), None)
                if not best_audio:
                    best_audio = next((f["url"] for f in adaptive if f.get("mimeType", "").startswith("audio/") and "url" in f), None)

                if best_audio:
                    return {
                        "url": best_audio,
                        "type": "audio",
                        "user_agent": _ANDROID_HEADERS["User-Agent"],
                        "title": vdetails.get("title", ""),
                        "channel": vdetails.get("author", ""),
                        "channel_id": vdetails.get("channelId", ""),
                        "duration": int(vdetails.get("lengthSeconds", 0) or 0),
                        "subtitles": [],
                    }

            for fmt in streaming.get("formats", []):
                if fmt.get("itag") == 18 and "url" in fmt:
                    return {
                        "url": fmt["url"],
                        "type": "mp4",
                        "user_agent": _ANDROID_HEADERS["User-Agent"],
                        "title": vdetails.get("title", ""),
                        "channel": vdetails.get("author", ""),
                        "channel_id": vdetails.get("channelId", ""),
                        "duration": int(vdetails.get("lengthSeconds", 0) or 0),
                        "subtitles": [],
                    }

    payload_vision = {
        "videoId": video_id,
        "context": {
            "client": {
                "clientName": "VISIONOS",
                "clientVersion": "0.1",
                "deviceMake": "Apple",
                "deviceModel": "RealityDevice14,1",
                "osName": "visionOS",
                "osVersion": "1.3.21O771",
                "hl": "es",
                "gl": "ES",
            }
        },
    }
    if visitor_data:
        payload_vision["context"]["client"]["visitorData"] = visitor_data

    data_vision = _post_player(payload_vision, _VISIONOS_HEADERS)
    if data_vision:
        streaming = data_vision.get("streamingData", {})
        hls_url = streaming.get("hlsManifestUrl")
        vdetails = data_vision.get("videoDetails", {})
        if hls_url:
            return {
                "url": hls_url,
                "type": "hls",
                "user_agent": _VISIONOS_HEADERS["User-Agent"],
                "title": vdetails.get("title", ""),
                "channel": vdetails.get("author", ""),
                "channel_id": vdetails.get("channelId", ""),
                "duration": int(vdetails.get("lengthSeconds", 0) or 0),
                "subtitles": [],
            }

    if ytdlp_resolver and ytdlp_resolver.is_available():
        try:
            yt_web = f"https://www.youtube.com/watch?v={video_id}"
            stream_url = ytdlp_resolver.resolve(yt_web)
            if stream_url:
                return {
                    "url": stream_url,
                    "type": "ytdlp",
                    "user_agent": "",
                    "title": "",
                    "channel": "",
                    "duration": 0,
                    "subtitles": [],
                }
        except (OSError, ValueError) as exc:
            if xbmc:
                xbmc.log(f"[EspaTV/yt_resolver] Error en fallback yt-dlp: {exc}", xbmc.LOGWARNING)

    return None


def get_sponsorblock_segments(video_id):
    video_id = _extract_video_id(video_id)
    if not video_id:
        return []
    cats = urllib.parse.quote('["sponsor","selfpromo","intro","outro"]')
    url = f"https://sponsor.ajay.app/api/skipSegments?videoID={video_id}&categories={cats}"
    req = urllib.request.Request(url, headers={"User-Agent": "EspaTV-Kodi"})
    try:
        with urllib.request.urlopen(req, timeout=3) as resp:
            data = json.loads(resp.read().decode("utf-8", errors="replace"))
            segments = []
            for item in data:
                segment = item.get("segment")
                if isinstance(segment, list) and len(segment) == 2:
                    segments.append((float(segment[0]), float(segment[1])))
            return segments
    except (urllib.error.HTTPError, urllib.error.URLError, ValueError, OSError):
        return []


def _sponsorblock_monitor(video_id):
    segments = get_sponsorblock_segments(video_id)
    if not segments or not xbmc:
        return
    player = xbmc.Player()
    monitor = xbmc.Monitor()
    for _ in range(16):
        if monitor.abortRequested() or player.isPlaying():
            break
        time.sleep(0.5)
    skipped = set()
    while not monitor.abortRequested() and player.isPlaying():
        try:
            pos = player.getTime()
            for idx, (start, end) in enumerate(segments):
                if idx not in skipped and start <= pos < (end - 1.0):
                    skipped.add(idx)
                    player.seekTime(end)
                    if xbmcgui:
                        xbmcgui.Dialog().notification("SponsorBlock", "Segmento patrocinado saltado", xbmcgui.NOTIFICATION_INFO, 1500)
                    break
        except RuntimeError:
            break
        if monitor.waitForAbort(1.0):
            break


def build_listitem(video_id, info, title="", audio_only=False):
    """Construye (stream_url, li) con ListItem configurado para HLS/MP4, cabeceras y subtítulos."""
    stream_url = info["url"]
    stream_type = info.get("type", "mp4")
    ua = info.get("user_agent", "")
    thumb = f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg"
    final_title = title or info.get("title") or video_id
    channel_name = info.get("channel", "")
    duration_sec = info.get("duration", 0)

    li = xbmcgui.ListItem(label=final_title, path=stream_url)
    li.setArt({"icon": thumb, "thumb": thumb, "fanart": thumb})
    if audio_only:
        li.setInfo("music", {
            "title": final_title,
            "artist": channel_name,
            "duration": duration_sec,
        })
    else:
        li.setInfo("video", {
            "title": final_title,
            "studio": channel_name,
            "plot": f"Canal: {channel_name}" if channel_name else final_title,
            "duration": duration_sec,
        })
    li.setProperty("IsPlayable", "true")
    li.setContentLookup(False)

    has_isa = True
    if xbmc:
        try:
            has_isa = bool(xbmc.getCondVisibility("System.AddonIsEnabled(inputstream.adaptive)"))
        except RuntimeError:
            has_isa = True

    if stream_type == "hls" and has_isa:
        li.setProperty("inputstream", "inputstream.adaptive")
        li.setProperty("inputstream.adaptive.manifest_type", "hls")
        li.setMimeType("application/vnd.apple.mpegurl")
        if ua:
            encoded_ua = urllib.parse.quote(ua)
            li.setProperty("inputstream.adaptive.stream_headers", f"User-Agent={encoded_ua}")
            li.setProperty("inputstream.adaptive.manifest_headers", f"User-Agent={encoded_ua}")
    elif ua:
        encoded_ua = urllib.parse.quote(ua)
        stream_url = f"{stream_url}|User-Agent={encoded_ua}"
        li.setPath(stream_url)

    try:
        import yt_storage
        yt_settings = yt_storage.get_settings()
    except (ImportError, OSError, ValueError):
        yt_settings = {}

    if yt_settings.get("subtitles", True):
        subs = info.get("subtitles", [])
        if subs:
            li.setSubtitles(subs)

    return stream_url, li


def play_video(video_id, title="", audio_only=False, use_resolved_url=True, allow_addon_fallback=True):
    video_id = _extract_video_id(video_id)
    h = -1
    if len(sys.argv) > 1:
        try:
            h = int(sys.argv[1])
        except (ValueError, TypeError):
            h = -1

    player_mode = 0
    try:
        cs = core_settings or sys.modules.get("core_settings")
        if cs and hasattr(cs, "get_yt_player_mode"):
            player_mode = cs.get_yt_player_mode()
        else:
            import core_settings as _cs
            player_mode = _cs.get_yt_player_mode()
    except Exception:
        player_mode = 0

    if not allow_addon_fallback or audio_only:
        player_mode = 2

    if player_mode == 3 and xbmcgui:
        ask_opts = [
            "Reproductor interno de EspaTV",
            "Addon oficial de YouTube (plugin.video.youtube)",
        ]
        chosen = xbmcgui.Dialog().select("Elegir reproductor para YouTube", ask_opts)
        if chosen < 0:
            if use_resolved_url and h >= 0 and xbmcplugin:
                xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem(label=title or video_id))
            return False
        player_mode = 1 if chosen == 1 else 2

    def _play_via_addon():
        if yt_watched_tracker:
            try:
                yt_watched_tracker.mark_watched(video_id, title=title or video_id)
            except (OSError, ValueError, AttributeError):
                pass
        if xbmcgui:
            xbmcgui.Dialog().notification("EspaTV", "Usando addon de YouTube…", xbmcgui.NOTIFICATION_INFO, 1500)
        yt_addon_url = f"plugin://plugin.video.youtube/play/?video_id={video_id}"
        if use_resolved_url and h >= 0 and xbmcplugin:
            li_fallback = xbmcgui.ListItem(label=title or video_id, path=yt_addon_url)
            li_fallback.setProperty("IsPlayable", "true")
            xbmcplugin.setResolvedUrl(h, True, li_fallback)
        elif xbmc:
            xbmc.executebuiltin(f'PlayMedia("{yt_addon_url}")')
        return True

    bridge_active = False
    try:
        bridge_active = bool(youtube_bridge.is_active())
    except Exception:
        bridge_active = False

    has_official_yt = False
    if not audio_only and allow_addon_fallback and xbmc:
        try:
            has_official_yt = (
                bool(xbmc.getCondVisibility("System.AddonIsEnabled(plugin.video.youtube)"))
                and not bridge_active
            )
        except RuntimeError:
            has_official_yt = False

    if player_mode == 1:
        if has_official_yt:
            return _play_via_addon()
        if bridge_active and xbmcgui:
            xbmcgui.Dialog().notification("EspaTV", "Puente YouTube activo: usando reproductor interno", xbmcgui.NOTIFICATION_WARNING)
        elif xbmcgui:
            xbmcgui.Dialog().notification("EspaTV", "Addon YouTube no disponible: usando reproductor interno", xbmcgui.NOTIFICATION_WARNING)

    info = resolve(video_id, audio_only=audio_only)
    if not info or not info.get("url"):
        if xbmc:
            xbmc.log(f"[EspaTV/yt_resolver] No se pudo resolver: {video_id}", xbmc.LOGWARNING)
        if player_mode == 0 and has_official_yt:
            return _play_via_addon()

        if use_resolved_url and h >= 0 and xbmcplugin:
            xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem(label=title or video_id))
        if xbmcgui:
            xbmcgui.Dialog().notification("EspaTV", "No se pudo resolver el vídeo de YouTube", xbmcgui.NOTIFICATION_WARNING)
        return False

    stream_url, li = build_listitem(video_id, info, title=title, audio_only=audio_only)
    final_title = title or info.get("title") or video_id
    channel_name = info.get("channel", "")
    duration_sec = info.get("duration", 0)

    if yt_watched_tracker:
        try:
            yt_watched_tracker.mark_watched(
                video_id,
                title=final_title,
                channel=channel_name,
                duration=duration_sec,
            )
        except (OSError, ValueError, AttributeError) as exc:
            if xbmc:
                xbmc.log(f"[EspaTV/yt_resolver] Error marcando visto: {exc}", xbmc.LOGWARNING)

    if use_resolved_url and h >= 0:
        xbmcplugin.setResolvedUrl(h, True, li)
    else:
        xbmc.Player().play(stream_url, li)

    try:
        import yt_storage
        yt_settings = yt_storage.get_settings()
    except (ImportError, OSError, ValueError):
        yt_settings = {}

    if yt_settings.get("sponsorblock", False) and not info.get("is_live", False):
        t = threading.Thread(target=_sponsorblock_monitor, args=(video_id,), daemon=True)
        t.start()

    return True
