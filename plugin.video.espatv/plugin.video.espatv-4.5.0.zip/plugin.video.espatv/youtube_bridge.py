# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Gestor del puente de compatibilidad YouTube para EspaTV.
Permite alternar entre el addon de YouTube del usuario y el mini-addon puente de EspaTV.
"""

import errno
import json
import os
import shutil
import tempfile
import time

try:
    import xbmc
    import xbmcgui
    import xbmcvfs
except ImportError:
    xbmc = None
    xbmcgui = None
    xbmcvfs = None

_OFFICIAL_ID = "plugin.video.youtube"
_BRIDGE_VERSION = "99.0.0"
_MARKER_FILENAME = ".espatv_bridge"
_LOCK_FILENAME = ".youtube_bridge.lock"
# Cubre un copytree/rmtree lento en tarjetas SD; pasado este tiempo el bloqueo se da por huérfano
_LOCK_TIMEOUT_SECONDS = 120
_TITLE = "Puente YouTube"
_IN_USE_MSG = "Hay ficheros del addon de YouTube en uso. Reinicia Kodi e inténtalo de nuevo."
_STORAGE_FULL_MSG = (
    "No hay suficiente espacio libre de almacenamiento en tu dispositivo para activar el puente "
    "de YouTube. Libera espacio (borrando caché de Kodi o aplicaciones) e inténtalo de nuevo."
)
_PERMISSION_MSG = (
    "No se pudo modificar la carpeta del addon por restricciones de permisos en tu dispositivo (Firestick/Android).\n\n"
    "Puedes usar en su lugar el ajuste:\n"
    "Ajustes > YouTube > Reproductor de YouTube -> Interno de EspaTV\n"
    "para reproducir vídeos con el motor nativo de EspaTV sin modificar carpetas."
)


def _log(msg, level=None):
    if xbmc:
        xbmc.log(f"[Puente YouTube] {msg}", level if level is not None else xbmc.LOGWARNING)


def _get_paths():
    """Rutas del puente. Vacías si no se puede preguntar a Kodi: nunca se adivina una
    instalación para escribir en ella."""
    addons_dir = ""
    if xbmcvfs:
        try:
            addons_dir = xbmcvfs.translatePath("special://home/addons")
        except (RuntimeError, ValueError):
            addons_dir = ""
    if not isinstance(addons_dir, str) or not os.path.isdir(addons_dir):
        addons_dir = ""

    def under(name):
        return os.path.join(addons_dir, name) if addons_dir else ""

    return {
        "addons_dir": addons_dir,
        "bridge_dest": under(_OFFICIAL_ID),
        "backup_dest": under(f"{_OFFICIAL_ID}.official_bak"),
        # Sin addon.xml en su raíz: Kodi no carga nada de lo que haya dentro. Ahí se prepara
        # el puente, se aparta el que se retira y se guardan respaldos antiguos
        "work_dir": under(f"{_OFFICIAL_ID}.espatv"),
        "template_dir": os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "bridge_yt"),
        "lock_file": under(_LOCK_FILENAME),
    }


def _acquire_lock(lock_path):
    """Adquiere un bloqueo para evitar concurrencia en disco."""
    if not lock_path:
        return False
    for _ in range(2):
        try:
            fd = os.open(lock_path, os.O_CREAT | os.O_EXCL | os.O_WRONLY)
        except FileExistsError:
            try:
                if time.time() - os.path.getmtime(lock_path) <= _LOCK_TIMEOUT_SECONDS:
                    return False
                os.remove(lock_path)
            except OSError:
                return False
            continue
        except OSError:
            return False
        with os.fdopen(fd, "w", encoding="utf-8") as f:
            f.write(str(os.getpid()))
        return True
    return False


def _release_lock(lock_path):
    """Libera el archivo de bloqueo."""
    if lock_path and os.path.exists(lock_path):
        try:
            os.remove(lock_path)
        except OSError:
            pass


def _new_slot(work_dir, prefix):
    os.makedirs(work_dir, exist_ok=True)
    return tempfile.mkdtemp(prefix=prefix, dir=work_dir)


def _clean_work(work_dir):
    """Borra lo que quede de preparaciones y retiradas anteriores; los respaldos se conservan."""
    if not work_dir or not os.path.isdir(work_dir):
        return
    for name in os.listdir(work_dir):
        path = os.path.join(work_dir, name)
        if name.startswith(("staging_", "trash_")):
            shutil.rmtree(path, ignore_errors=True)
        else:
            # Un hueco de respaldo vacío queda cuando se deshace un cambio
            try:
                os.rmdir(path)
            except OSError:
                pass
    try:
        os.rmdir(work_dir)
    except OSError:
        pass


def _safe_copy_file(src, dst):
    shutil.copyfile(src, dst)
    try:
        shutil.copystat(src, dst)
    except OSError:
        pass


def _copytree_safe(src, dst, ignore=None):
    orig_copystat = shutil.copystat

    def safe_copystat(*args, **kwargs):
        try:
            orig_copystat(*args, **kwargs)
        except OSError:
            pass

    try:
        shutil.copystat = safe_copystat
        shutil.copytree(src, dst, copy_function=_safe_copy_file, ignore=ignore)
    finally:
        shutil.copystat = orig_copystat


def _move(src, dst, done):
    try:
        os.rename(src, dst)
        done.append((src, dst, "rename"))
    except OSError as exc:
        if exc.errno in (errno.EXDEV, errno.EBUSY):
            try:
                _copytree_safe(src, dst, ignore=shutil.ignore_patterns("__pycache__"))
            except OSError:
                shutil.rmtree(dst, ignore_errors=True)
                raise
            shutil.rmtree(src, ignore_errors=True)
            if os.path.exists(src):
                shutil.rmtree(dst, ignore_errors=True)
                raise PermissionError(errno.EBUSY, f"Sigue en uso y no se pudo liberar: {src}")
            done.append((src, dst, "copy"))
        else:
            raise


def _rollback(done):
    for item in reversed(done):
        src, dst = item[0], item[1]
        try:
            if len(item) > 2 and item[2] == "copy":
                if os.path.exists(dst):
                    if os.path.exists(src):
                        shutil.rmtree(src, ignore_errors=True)
                    _copytree_safe(dst, src, ignore=shutil.ignore_patterns("__pycache__"))
                    shutil.rmtree(dst, ignore_errors=True)
            else:
                os.rename(dst, src)
        except OSError as exc:
            _log(f"No se pudo deshacer {dst} -> {src}: {exc}", xbmc.LOGERROR if xbmc else None)


def is_bridge_folder(folder_path):
    """Comprueba si una carpeta corresponde al puente de EspaTV mediante su marcador."""
    if not folder_path or not os.path.isdir(folder_path):
        return False
    return os.path.isfile(os.path.join(folder_path, _MARKER_FILENAME))


def get_status():
    """Devuelve el estado del puente: 'active', 'official', 'backup_ready' o 'not_installed'."""
    paths = _get_paths()
    bridge_dest = paths["bridge_dest"]

    if not bridge_dest:
        return "not_installed"
    if os.path.isdir(bridge_dest):
        return "active" if is_bridge_folder(bridge_dest) else "official"
    if os.path.isdir(paths["backup_dest"]):
        return "backup_ready"
    return "not_installed"


def is_active():
    """True si plugin.video.youtube es ahora el puente de EspaTV y no el addon de YouTube original."""
    return get_status() == "active"


def get_status_label():
    """Etiqueta legible del estado para menús y ajustes."""
    return {
        "active": "Activado, EspaTV reproduce los vídeos de YouTube de otros addons",
        "official": "Desactivado, se usa tu addon de YouTube",
        "backup_ready": "Desactivado, tu addon de YouTube está guardado y no hay ninguno instalado",
    }.get(get_status(), "Desactivado, no hay addon de YouTube instalado")


def _cond(name):
    try:
        return bool(xbmc.getCondVisibility(f"System.{name}({_OFFICIAL_ID})"))
    except RuntimeError:
        return False


def _bridge_loaded():
    """True si Kodi tiene cargado y habilitado el puente. AddonVersion solo ve addons habilitados."""
    return xbmc.getInfoLabel(f"System.AddonVersion({_OFFICIAL_ID})") == _BRIDGE_VERSION


def _wait_for(check, seconds=4):
    monitor = xbmc.Monitor()
    for _ in range(int(seconds * 10)):
        if check():
            return True
        if monitor.waitForAbort(0.1):
            break
    return check()


def _sync_kodi_after_enable(enable_addon):
    """Reescanea los addons y, si toca, habilita el puente. True si queda funcionando.

    Kodi registra deshabilitado un addon que no conocía; uno que ya conocía conserva su estado.
    UpdateLocalAddons es asíncrono, así que se espera a verlo en vez de bloquear el hilo."""
    if not xbmc:
        return False
    xbmc.executebuiltin("UpdateLocalAddons()")
    _wait_for(lambda: _bridge_loaded() or (_cond("HasAddon") and not _cond("AddonIsEnabled")))
    if enable_addon and not _bridge_loaded():
        resp = xbmc.executeJSONRPC(json.dumps({
            "jsonrpc": "2.0",
            "id": 1,
            "method": "Addons.SetAddonEnabled",
            "params": {"addonid": _OFFICIAL_ID, "enabled": True},
        }))
        if '"error"' in str(resp):
            _log(f"No se pudo habilitar {_OFFICIAL_ID}: {resp}")
        _wait_for(_bridge_loaded)
    return _bridge_loaded()


def _notify(msg, kind="INFO", ms=5000):
    if xbmcgui:
        xbmcgui.Dialog().notification(_TITLE, msg, getattr(xbmcgui, f"NOTIFICATION_{kind}"), ms)


def _show(interactive, msg):
    """msg es (tipo, texto): 'dialog' para un aviso con Aceptar, o un nivel de notificación."""
    if interactive and msg and xbmcgui:
        kind, text = msg
        if kind == "dialog":
            xbmcgui.Dialog().ok(_TITLE, text)
        else:
            _notify(text, kind)


def _run_locked(paths, action, interactive):
    """Ejecuta action(paths) con el bloqueo cogido y avisa después de soltarlo: un aviso que se
    queda abierto minutos no debe impedir otro cambio."""
    if not _acquire_lock(paths["lock_file"]):
        _show(interactive, ("WARNING", "Hay otro cambio en curso, inténtalo en unos segundos"))
        return False
    try:
        ok, msg = action(paths)
    finally:
        _release_lock(paths["lock_file"])
    _show(interactive, msg)
    return ok


def enable(interactive=True):
    """Activa el puente de YouTube resguardando el addon de YouTube original si existe."""
    paths = _get_paths()
    if not paths["bridge_dest"] or not os.path.isdir(paths["template_dir"]):
        _show(interactive, ("ERROR", "No se encuentra la plantilla del puente"))
        return False
    return _run_locked(paths, _enable_locked, interactive)


def _enable_locked(paths):
    bridge_dest = paths["bridge_dest"]
    backup_dest = paths["backup_dest"]
    work_dir = paths["work_dir"]
    done = []
    enable_addon = False
    try:
        st = get_status()
        if st == "active":
            return True, ("INFO", "El puente ya está activado")

        # Si el usuario tenía el oficial deshabilitado, el puente hereda ese estado
        enable_addon = st != "official" or (bool(xbmc) and _cond("AddonIsEnabled"))

        # Deshabilita temporalmente el addon oficial para liberar ficheros en uso
        if st == "official" and bool(xbmc) and _cond("AddonIsEnabled"):
            try:
                xbmc.executeJSONRPC(json.dumps({
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "Addons.SetAddonEnabled",
                    "params": {"addonid": _OFFICIAL_ID, "enabled": False},
                }))
                _wait_for(lambda: not _cond("AddonIsEnabled"), seconds=2)
            except Exception as exc:
                _log(f"No se pudo deshabilitar temporalmente el addon oficial: {exc}")

        _clean_work(work_dir)
        # Se prepara entero fuera de su sitio para que un fallo al copiar no toque el oficial
        staged = os.path.join(_new_slot(work_dir, "staging_"), "addon")
        _copytree_safe(paths["template_dir"], staged, ignore=shutil.ignore_patterns("__pycache__"))
        marker = os.path.join(staged, _MARKER_FILENAME)
        if not os.path.exists(marker):
            with open(marker, "w", encoding="utf-8") as f:
                f.write("EspaTV YouTube Bridge Marker\n")

        try:
            if os.path.isdir(bridge_dest):
                # El oficial actual es el más reciente: pasa a ser el respaldo que se restaurará.
                # Un respaldo anterior se guarda aparte, donde Kodi no lo carga
                if os.path.isdir(backup_dest):
                    _move(backup_dest, os.path.join(_new_slot(work_dir, "official_"), _OFFICIAL_ID), done)
                _move(bridge_dest, backup_dest, done)
            _move(staged, bridge_dest, done)
        except OSError:
            _rollback(done)
            raise
        finally:
            _clean_work(work_dir)

        if _sync_kodi_after_enable(enable_addon):
            msg = ("Puente activado. Los vídeos de YouTube que abran otros addons y skins "
                   "se reproducen ya con EspaTV.")
            if st == "official":
                msg += ("\n\nReinicia Kodi cuando puedas: el servicio de tu addon de YouTube "
                        "sigue en memoria hasta entonces.")
        elif not enable_addon:
            msg = ("Puente instalado, pero deshabilitado porque tu addon de YouTube lo estaba.\n\n"
                   "Habilítalo en Mis addons > Addons de vídeo > YouTube (Puente EspaTV).")
        else:
            msg = ("Puente instalado, pero Kodi no lo ha habilitado.\n\n"
                   "Habilítalo en Mis addons > Addons de vídeo > YouTube (Puente EspaTV).")
        return True, ("dialog", msg)

    except OSError as exc:
        _clean_work(work_dir)
        if enable_addon and bool(xbmc) and not _cond("AddonIsEnabled"):
            try:
                xbmc.executeJSONRPC(json.dumps({
                    "jsonrpc": "2.0",
                    "id": 1,
                    "method": "Addons.SetAddonEnabled",
                    "params": {"addonid": _OFFICIAL_ID, "enabled": True},
                }))
            except Exception:
                pass
        if getattr(exc, "errno", None) == errno.ENOSPC:
            _log(f"Espacio insuficiente al activar el puente: {exc}", xbmc.LOGERROR if xbmc else None)
            return False, ("dialog", _STORAGE_FULL_MSG)
        if isinstance(exc, PermissionError) or getattr(exc, "errno", None) in (errno.EACCES, errno.EPERM):
            _log(f"Permiso denegado o fichero en uso al activar: {exc}")
            return False, ("dialog", _PERMISSION_MSG)
        _log(f"Error de sistema al activar: {exc}", xbmc.LOGERROR if xbmc else None)
        return False, ("ERROR", f"No se pudo activar: {exc}")


def disable(interactive=True):
    """Desactiva el puente de YouTube y restaura el addon de YouTube original si había copia.

    También restaura desde 'backup_ready' (original en respaldo y nada en su sitio).
    """
    paths = _get_paths()
    if not paths["bridge_dest"]:
        return False
    return _run_locked(paths, _disable_locked, interactive)


def _disable_locked(paths):
    bridge_dest = paths["bridge_dest"]
    backup_dest = paths["backup_dest"]
    work_dir = paths["work_dir"]
    done = []
    try:
        st = get_status()
        if st not in ("active", "backup_ready"):
            return True, ("INFO", "El puente no está activado")

        _clean_work(work_dir)
        try:
            if st == "active":
                # Se aparta de golpe porque un rmtree interrumpido sobre bridge_dest dejaría
                # una carpeta sin marcador que pasaría por el addon oficial
                _move(bridge_dest, os.path.join(_new_slot(work_dir, "trash_"), "addon"), done)
            if os.path.isdir(backup_dest):
                _move(backup_dest, bridge_dest, done)
        except OSError:
            _rollback(done)
            raise
        finally:
            _clean_work(work_dir)

        if xbmc:
            xbmc.executebuiltin("UpdateLocalAddons()")
        if os.path.isdir(bridge_dest):
            return True, ("dialog", "Tu addon de YouTube está de vuelta.\n\n"
                                    "Si alguna de sus funciones falla, reinicia Kodi.")
        return True, ("INFO", "Puente desactivado. No había ningún addon de YouTube que restaurar")

    except OSError as exc:
        if getattr(exc, "errno", None) == errno.ENOSPC:
            _log(f"Espacio insuficiente al desactivar el puente: {exc}", xbmc.LOGERROR if xbmc else None)
            return False, ("dialog", _STORAGE_FULL_MSG)
        if isinstance(exc, PermissionError) or getattr(exc, "errno", None) in (errno.EACCES, errno.EPERM):
            _log(f"Permiso denegado o fichero en uso al desactivar: {exc}")
            return False, ("dialog", _IN_USE_MSG)
        _log(f"Error de sistema al desactivar: {exc}", xbmc.LOGERROR if xbmc else None)
        return False, ("ERROR", f"No se pudo restaurar: {exc}")


_INFO_TEXT = (
    "[B]Qué es[/B]\n"
    "Algunos addons y skins de Kodi reproducen vídeos de YouTube a través del addon de YouTube "
    "para Kodi (el que se instala desde el repositorio de Kodi; no lo hace Google). Ese addon puede "
    "necesitar claves de API de Google, con cuota diaria, y últimamente da muchos errores y cortes "
    "al reproducir.\n\n"
    "El puente hace que esas llamadas las atienda EspaTV con su propio motor de reproducción, sin "
    "claves ni cuotas.\n\n"
    "[B]Cómo funciona[/B]\n"
    "Al activarlo, EspaTV guarda tu addon de YouTube y pone en su lugar un addon mínimo con el "
    "mismo identificador. Cuando otro addon o una skin pide un vídeo de YouTube, ese addon mínimo "
    "se lo pasa a EspaTV y EspaTV lo reproduce. Al desactivarlo vuelve tu addon de YouTube tal "
    "cual estaba; sus ajustes y tu sesión no se tocan.\n\n"
    "[B]Qué deja de funcionar mientras está activado[/B]\n"
    "El puente solo reproduce vídeos. No funcionan la navegación, el inicio de sesión, las "
    "suscripciones de tu cuenta, la búsqueda ni los widgets del addon de YouTube, ni los addons que "
    "usan sus módulos. Para navegar por YouTube usa este menú de EspaTV.\n\n"
    "[B]Cuándo te conviene[/B]\n"
    "Si al abrir vídeos de YouTube desde otros addons o skins te salen errores o cortes (por ejemplo "
    "por la cuota de la API), o si no tienes instalado el addon de YouTube.\n\n"
    "[B]Al cambiarlo[/B]\n"
    "Conviene reiniciar Kodi después de activarlo o desactivarlo. Puedes volver atrás cuando "
    "quieras desde este mismo botón."
)


def show_info_and_toggle():
    """Explica qué es el puente y, al cerrar la explicación, ofrece activarlo o desactivarlo."""
    if not xbmcgui:
        return False
    xbmcgui.Dialog().textviewer(_TITLE, f"[B]Estado:[/B] {get_status_label()}\n\n{_INFO_TEXT}")
    return toggle(explained=True)


def toggle(interactive=True, explained=False):
    """Alterna el estado del puente solicitando confirmación interactiva.

    explained: el usuario acaba de leer la explicación completa, así que la confirmación es breve."""
    st = get_status()

    if st == "active":
        if interactive and xbmcgui:
            confirm = xbmcgui.Dialog().yesno(
                _TITLE,
                "El puente de EspaTV está activado.\n\n"
                "¿Quieres desactivarlo y volver a tu addon de YouTube?",
                nolabel="Cancelar",
                yeslabel="Desactivar puente",
            )
            if not confirm:
                return False
        return disable(interactive=interactive)

    if st == "backup_ready" and interactive and xbmcgui:
        sel = xbmcgui.Dialog().select(
            _TITLE,
            ["Recuperar mi addon de YouTube", "Activar el puente de EspaTV"],
        )
        if sel < 0:
            return False
        if sel == 0:
            return disable(interactive=interactive)
        return enable(interactive=interactive)

    if interactive and xbmcgui:
        if explained:
            msg = "¿Quieres activar el puente ahora?"
        else:
            msg = (
                "El puente cambia el addon de YouTube por uno que solo reproduce vídeos, "
                "con el motor de EspaTV (sin cuotas de API).\n\n"
                "Mientras esté activado no funcionan la navegación, el inicio de sesión, la "
                "búsqueda ni los widgets del addon de YouTube, ni los addons que usan sus módulos.\n\n"
                "¿Quieres activarlo ahora?"
            )
        if st == "official":
            msg += "\n\nTu addon de YouTube se guarda y vuelve al desactivar el puente."

        confirm = xbmcgui.Dialog().yesno(
            _TITLE,
            msg,
            nolabel="Cancelar",
            yeslabel="Activar puente",
        )
        if not confirm:
            return False
    return enable(interactive=interactive)
