# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Búsqueda concurrente y agregación de resultados de múltiples plataformas de vídeo."""
import difflib
import json
import re
import sys
import threading
import time
import unicodedata
import urllib.parse
import urllib.request

import xbmc
import xbmcgui
import xbmcplugin

import ui_utils
import yt_search
import odysee_search
import peertube_search
import bitchute_search

_CFG_FILE = 'bt_config.json'
_DEFAULTS = {
    'clean_titles': True, 'extra_variations': False,
    'use_proxy': False, 'proxy_addr': '',
    'src_dm': True, 'src_yt': True, 'src_odysee': True,
    'src_peertube': False, 'src_bitchute': False,
    'rank_accents': True, 'rank_tokens': True, 'rank_episode': True,
    'rank_noise': True, 'filter_short': True, 'min_duration_secs': 60,
    'rank_duration': True, 'noise_cine': True, 'rank_lang_es': True,
    'order_by_quality': True,
}

_BADGE = {
    'DM': '[COLOR blue][DM][/COLOR]',
    'YT': '[COLOR red][YT][/COLOR]',
    'Odysee': '[COLOR violet][Odysee][/COLOR]',
    'PT': '[COLOR orange][PT][/COLOR]',
    'BC': '[COLOR gold][BC][/COLOR]',
}

_SRC_NAMES = {
    'src_dm': 'Dailymotion',
    'src_yt': 'YouTube',
    'src_odysee': 'Odysee',
    'src_peertube': 'PeerTube',
    'src_bitchute': 'BitChute'
}


def _active_sources(cfg):
    return [name for key, name in _SRC_NAMES.items() if cfg.get(key)]


_YT_PLAY = "plugin://plugin.video.espatv/?action=yt_play_video&video_id={0}"
_YT_THUMB = "https://i.ytimg.com/vi/{0}/hqdefault.jpg"

_THREAD_TIMEOUT = 18
_SCORE_FLOOR = 0.20
_MAX_RESULTS = 80

_STOPWORDS = {
    'el', 'la', 'los', 'las', 'un', 'una', 'unos', 'unas', 'de', 'del', 'y', 'o',
    'u', 'a', 'al', 'con', 'por', 'para', 'que', 'se', 'su', 'sus', 'lo', 'le',
    'les', 'en', 'the', 'an', 'of', 'and', 'or', 'to', 'in', 'on', 'for',
}


def _cfg():
    c = ui_utils.load_json(_CFG_FILE)
    if not isinstance(c, dict):
        c = {}
    merged = dict(_DEFAULTS)
    merged.update(c)
    return merged


def _set(key, value):
    c = _cfg()
    c[key] = value
    ui_utils.save_json(_CFG_FILE, c)


_EP_PATTERNS = [
    re.compile(r'\b(\d{1,2})\s*x\s*(\d{1,3})\b', re.IGNORECASE),
    re.compile(r'\bs\s*(\d{1,2})\s*e\s*(\d{1,3})\b', re.IGNORECASE),
    re.compile(r'\bt\s*(\d{1,2})\s*e\s*(\d{1,3})\b', re.IGNORECASE),
]
_LEET = str.maketrans({'a': '4', 'e': '3', 'i': '1', 'o': '0',
                       'A': '4', 'E': '3', 'I': '1', 'O': '0'})


def _sin_stopwords(query):
    palabras = re.findall(r'\w+', query.lower(), re.UNICODE)
    distintivas = [w for w in palabras if w not in _STOPWORDS and len(w) > 1]
    nueva = ' '.join(distintivas)
    return nueva if nueva and nueva != query.lower() else ''


def _variacion_episodio(query):
    for rx in _EP_PATTERNS:
        m = rx.search(query)
        if m:
            base = re.sub(r'\s{2,}', ' ', rx.sub('', query)).strip()
            return f'{base} capitulo {int(m.group(2))}'.strip()
    return ''


def build_variations(query, extra=False):
    query = (query or '').strip()
    variantes = [query, _sin_stopwords(query), _variacion_episodio(query)]
    if extra and query:
        variantes.append(query.translate(_LEET))
        variantes.append(query.replace(' ', ''))
    vistas, out = set(), []
    for v in variantes:
        v = (v or '').strip()
        if v and v.lower() not in vistas:
            vistas.add(v.lower())
            out.append(v)
    return out[:5]


def _dm_query_native(q):
    fields = "id,title,thumbnail_720_url,thumbnail_360_url,thumbnail_url,duration,views_total,owner.screenname,owner.username"
    params = {"search": q, "limit": 30, "language": "es", "fields": fields}
    try:
        params["limit"] = ui_utils.dm_limite_lista(30)
    except Exception:
        params["limit"] = 30
    try:
        resp = ui_utils.dm_api_videos("https://api.dailymotion.com/videos", params, timeout=12)
        if resp and resp.status_code == 200:
            return ui_utils.filtrar_dm_borrados(resp.json().get("list", []))
    except Exception as ex:
        xbmc.log(f"[EspaTV][BT] DM search error: {ex}", xbmc.LOGWARNING)
    return []


def _run_workers(variations, cfg):
    primary = variations[0] if variations else ''
    out = {'DM': [], 'YT': [], 'Odysee': [], 'PT': [], 'BC': []}
    out_lock = threading.Lock()

    def dm_worker():
        if not cfg.get('src_dm'):
            return
        parciales = [None] * len(variations)

        def consulta(i, q):
            try:
                parciales[i] = _dm_query_native(q) or []
            except Exception as ex:
                xbmc.log(f"[EspaTV][BT] DM search ('{q}'): {ex}", xbmc.LOGWARNING)
                parciales[i] = []

        subhilos = [threading.Thread(target=consulta, args=(i, q), daemon=True)
                    for i, q in enumerate(variations)]
        for t in subhilos:
            t.start()
        # Margen de 2 s respecto a _run_workers para volcar los parciales que sí llegaron a tiempo.
        _join_todos(subhilos, max(1, _THREAD_TIMEOUT - 2))

        vistos, dm_items = set(), []
        for lista in parciales:
            for v in (lista or []):
                vid = v.get('id')
                if vid and vid not in vistos:
                    vistos.add(vid)
                    dm_items.append(v)
        with out_lock:
            out['DM'] = dm_items

    def yt_worker():
        if not cfg.get('src_yt'):
            return
        try:
            res = yt_search.fetch_search_results(primary) or []
            with out_lock:
                out['YT'] = res
        except Exception as ex:
            xbmc.log(f"[EspaTV][BT] YT worker: {ex}", xbmc.LOGWARNING)

    def od_worker():
        if not cfg.get('src_odysee'):
            return
        try:
            res = odysee_search.search(primary) or []
            with out_lock:
                out['Odysee'] = res
        except Exception as ex:
            xbmc.log(f"[EspaTV][BT] Odysee worker: {ex}", xbmc.LOGWARNING)

    def pt_worker():
        if not cfg.get('src_peertube'):
            return
        try:
            res = peertube_search.search(primary) or []
            with out_lock:
                out['PT'] = res
        except Exception as ex:
            xbmc.log(f"[EspaTV][BT] PeerTube worker: {ex}", xbmc.LOGWARNING)

    def bc_worker():
        if not cfg.get('src_bitchute'):
            return
        try:
            res = bitchute_search.search(primary) or []
            with out_lock:
                out['BC'] = res
        except Exception as ex:
            xbmc.log(f"[EspaTV][BT] BitChute worker: {ex}", xbmc.LOGWARNING)

    hilos = [threading.Thread(target=w, daemon=True)
             for w in (dm_worker, yt_worker, od_worker, pt_worker, bc_worker)]
    for t in hilos:
        t.start()
    _join_todos(hilos, _THREAD_TIMEOUT)
    with out_lock:
        return {k: list(v) for k, v in out.items()}


def _join_todos(hilos, plazo):
    limite = time.time() + plazo
    for t in hilos:
        t.join(max(0, limite - time.time()))


# Limpieza de títulos

_EMOJI_RX = re.compile(
    "[\U0001F300-\U0001FAFF\U00002600-\U000027BF\U0001F1E6-\U0001F1FF"
    "\U00002B00-\U00002BFF\uFE0F]", flags=re.UNICODE)
_BRACKETS_RX = re.compile(r'[\[\(\{][^\]\)\}]*[\]\)\}]')
_SPAM_RX = re.compile(
    r'\b(HD|FHD|UHD|4K|2K|1080P|720P|480P|COMPLETO|FULL|OFICIAL|ESTRENO|'
    r'IMPACTANTE|EXCLUSIVA|EXCLUSIVO|SUBTITULADO|ONLINE|GRATIS)\b', re.IGNORECASE)
_PARTE_RX = re.compile(r'\bPARTE\s*\d+\s*[/\-]\s*\d+\b', re.IGNORECASE)


def limpiar_titulo_video(titulo):
    if not titulo:
        return titulo
    t = _BRACKETS_RX.sub(' ', titulo)
    t = _EMOJI_RX.sub('', t)
    t = _PARTE_RX.sub('', t)
    t = _SPAM_RX.sub('', t)
    t = re.sub(r'[¡!]{2,}', '', t)
    t = re.sub(r'\s{2,}', ' ', t).strip(' -|·•:–—')
    if t.isupper():
        t = t.title()
    return t or titulo


# Normalización y ranking

_NOISE_WORDS = {'trailer', 'teaser', 'promo', 'avance', 'adelanto', 'resumen',
                'recap', 'preview', 'clip', 'fragmento', 'momentazo', 'momentos'}
_NOISE_CINE = _NOISE_WORDS | {
    'review', 'resena', 'critica', 'reaccion', 'reaction', 'analisis', 'explicacion', 'explained',
    'curiosos', 'curiosidades',
    'escena', 'escenas', 'scene', 'behind', 'making', 'bloopers', 'gameplay', 'walkthrough',
    'lyrics', 'letra', 'cancion', 'soundtrack', 'ost', 'karaoke', 'cover', 'parodia',
    'tutorial', 'unboxing', 'entrevista', 'podcast', 'shorts',
    'remix', 'instrumental', 'musica', 'theme', 'sinfonica', 'orquesta', 'piano',
    'sleep', 'relax', 'study', 'hours', 'horas', 'loop', 'playlist', 'mix', 'asmr',
    'compilation', 'compilacion'}
_LANG_ES_WORDS = {'espanol', 'castellano', 'latino', 'subtitulado', 'doblada', 'doblado'}
_CAP_RX = re.compile(r'\b(?:capitulo|episodio|cap|ep)\s*(\d{1,3})\b')


def _strip_accents(s):
    return ''.join(c for c in unicodedata.normalize('NFKD', s)
                   if not unicodedata.combining(c))


def _norm(s, accents=True):
    s = (s or '').lower()
    if accents:
        s = _strip_accents(s)
    return re.sub(r'\s+', ' ', re.sub(r'[^\w\s]', ' ', s)).strip()


def _episode_nums(norm_text):
    found = set()
    for rx in _EP_PATTERNS:
        for m in rx.finditer(norm_text):
            found.add((int(m.group(1)), int(m.group(2))))
    for m in _CAP_RX.finditer(norm_text):
        found.add((None, int(m.group(1))))
    return found


def _episode_match(qeps, teps):
    return any(qe == te and (qs is None or ts is None or qs == ts)
               for (qs, qe) in qeps for (ts, te) in teps)


def _prep_query(query, accents=True):
    qn = _norm(query, accents)
    qeps = _episode_nums(qn)
    base = qn
    for rx in _EP_PATTERNS:
        base = rx.sub(' ', base)
    base = _CAP_RX.sub(' ', base)
    base = re.sub(r'\s+', ' ', base).strip()
    return (base or qn), qeps


def _duration_fitness(duration, qeps):
    if duration <= 0:
        return -0.10
    mins = duration / 60
    if mins < 8:
        return -0.25
    if mins < 20:
        return -0.05
    if qeps:
        return 0.15 if mins <= 90 else 0.0
    return 0.20 if mins >= 60 else 0.10


def _score(qn_base, qeps, title, duration, opts):
    tn = _norm(title, opts['accents'])
    if not tn:
        return 0.0
    ttokens = set(tn.split())
    base = difflib.SequenceMatcher(None, qn_base, tn).ratio()
    if opts['tokens']:
        qtokens = set(qn_base.split())
        cobertura = len(qtokens & ttokens) / len(qtokens) if qtokens else 0.0
        base = max(base, cobertura)
    bonus = malus = 0.0
    if opts['episode'] and qeps:
        teps = _episode_nums(tn)
        if teps:
            if _episode_match(qeps, teps):
                bonus += 0.15
            else:
                malus += 0.12
    if opts['noise_cine']:
        if ttokens & _NOISE_CINE:
            malus += 0.20
    elif opts['noise'] and (ttokens & _NOISE_WORDS):
        malus += 0.08
    if opts['duration']:
        fit = _duration_fitness(duration, qeps)
        bonus += fit if fit >= 0 else 0.0
        malus += -fit if fit < 0 else 0.0
    if opts['lang_es'] and (ttokens & _LANG_ES_WORDS):
        bonus += 0.08
    return max(0.0, min(1.0, base + bonus) - malus)


def _to_int(v):
    try:
        return int(v or 0)
    except (ValueError, TypeError):
        return 0


def _parse_hms(s):
    if not s:
        return 0
    try:
        secs = 0
        for part in str(s).strip().split(':'):
            secs = secs * 60 + int(part)
        return secs
    except ValueError:
        return 0


def _normalize(raw, qn_base, qeps, clean, opts):
    def titulo(crudo):
        return limpiar_titulo_video(crudo) if clean else crudo

    records = []
    for v in raw.get('DM', []):
        vid = v.get('id')
        if not vid:
            continue
        crudo = v.get('title', 'Video')
        dur = _to_int(v.get('duration'))
        records.append({
            'source': 'DM', 'title': titulo(crudo), 'score': _score(qn_base, qeps, crudo, dur, opts),
            'thumbnail': (v.get('thumbnail_720_url') or v.get('thumbnail_480_url')
                          or v.get('thumbnail_url') or ui_utils.ICON_MAIN),
            'duration': dur,
            'owner': v.get('owner.username') or v.get('owner.screenname') or '',
            'play_id': str(vid),
        })
    for v in raw.get('YT', []):
        vid = v.get('vid')
        if not vid:
            continue
        crudo = v.get('title', 'Video')
        dur = _parse_hms(v.get('duration'))
        records.append({
            'source': 'YT', 'title': titulo(crudo), 'score': _score(qn_base, qeps, crudo, dur, opts),
            'thumbnail': _YT_THUMB.format(vid), 'duration': dur,
            'owner': v.get('channel', ''), 'play_url': _YT_PLAY.format(vid),
            'yt_id': str(vid),
        })
    for v in raw.get('Odysee', []):
        name, claim = v.get('name'), v.get('claim_id')
        if not name or not claim:
            continue
        crudo = v.get('title', 'Video')
        dur = _to_int(v.get('duration'))
        records.append({
            'source': 'Odysee', 'title': titulo(crudo), 'score': _score(qn_base, qeps, crudo, dur, opts),
            'thumbnail': v.get('thumb') or ui_utils.ICON_MAIN,
            'duration': dur,
            'owner': v.get('channel', ''), 'od_name': name, 'od_claim_id': claim,
            'od_sd_hash': v.get('sd_hash', ''), 'od_media_type': v.get('media_type', ''),
        })
    for v in raw.get('PT', []):
        uuid = v.get('uuid')
        if not uuid:
            continue
        crudo = v.get('title', 'Video')
        dur = _to_int(v.get('duration'))
        records.append({
            'source': 'PT', 'title': titulo(crudo), 'score': _score(qn_base, qeps, crudo, dur, opts),
            'thumbnail': v.get('thumb') or ui_utils.ICON_MAIN,
            'duration': dur,
            'owner': v.get('channel', ''), 'pt_uuid': uuid,
        })
    for v in raw.get('BC', []):
        vid = v.get('video_id')
        if not vid:
            continue
        crudo = v.get('title', 'Video')
        dur = _to_int(v.get('duration'))
        records.append({
            'source': 'BC', 'title': titulo(crudo), 'score': _score(qn_base, qeps, crudo, dur, opts),
            'thumbnail': v.get('thumb') or ui_utils.ICON_MAIN,
            'duration': dur,
            'owner': v.get('channel', ''), 'bc_video_id': vid,
        })
    return records


def _dedupe(records, accents):
    kept, norms = [], []
    for r in sorted(records, key=lambda x: x['score'], reverse=True):
        nt = _norm(r['title'], accents)
        if any(prev == nt or difflib.SequenceMatcher(None, prev, nt).ratio() > 0.90
               for prev in norms):
            continue
        kept.append(r)
        norms.append(nt)
    return kept


def aggregate(raw, query, cfg):
    opts = {'accents': cfg['rank_accents'], 'tokens': cfg['rank_tokens'],
            'episode': cfg['rank_episode'], 'noise': cfg['rank_noise'],
            'duration': cfg['rank_duration'], 'noise_cine': cfg['noise_cine'],
            'lang_es': cfg['rank_lang_es']}
    qn_base, qeps = _prep_query(query, opts['accents'])
    records = _normalize(raw, qn_base, qeps, cfg['clean_titles'], opts)
    if cfg['filter_short']:
        thr = _to_int(cfg['min_duration_secs'])
        records = [r for r in records if not (0 < r['duration'] < thr)]
    records = _dedupe(records, opts['accents'])
    records = [r for r in records if r['score'] >= _SCORE_FLOOR]
    if cfg['rank_duration']:
        records.sort(key=lambda x: (x['score'], x['duration']), reverse=True)
    else:
        records.sort(key=lambda x: x['score'], reverse=True)
    if cfg['order_by_quality']:
        return _cap_by_source(records, _MAX_RESULTS)
    return _balance_by_source(records, _MAX_RESULTS)


def _cap_by_source(records, limit, max_frac=0.5):
    cap = max(1, int(limit * max_frac))
    out, overflow, counts = [], [], {}
    for r in records:
        s = r['source']
        if counts.get(s, 0) < cap:
            out.append(r)
            counts[s] = counts.get(s, 0) + 1
        else:
            overflow.append(r)
        if len(out) >= limit:
            return out[:limit]
    if len(out) < limit:
        out.extend(overflow[:limit - len(out)])
    return out[:limit]


def _balance_by_source(records, limit):
    por_fuente = {}
    for r in records:
        por_fuente.setdefault(r['source'], []).append(r)
    out, i = [], 0
    while len(out) < limit:
        ronda = [lst[i] for lst in por_fuente.values() if i < len(lst)]
        if not ronda:
            break
        out.extend(ronda)
        i += 1
    return out[:limit]


# Proxy auxiliar

_PROXY_SRC = "https://free-proxy-list.net/"
_PROXY_RX = re.compile(r'(\d{1,3}(?:\.\d{1,3}){3})</td><td>(\d{2,5})</td>')


def obtener_proxy_valido(url_test="https://www.google.es", timeout=3, max_pruebas=25):
    try:
        req = urllib.request.Request(
            _PROXY_SRC, headers={'User-Agent': ui_utils.HEADERS['User-Agent']})
        with urllib.request.urlopen(req, timeout=10) as resp:
            html = resp.read().decode('utf-8', 'replace')
    except Exception as ex:
        xbmc.log(f"[EspaTV][BT] scrape proxies: {ex}", xbmc.LOGWARNING)
        return None

    candidatos = [f"{ip}:{port}" for ip, port in _PROXY_RX.findall(html)][:max_pruebas]
    if not candidatos:
        return None

    encontrado = {'addr': None}
    hallado = threading.Event()
    lock = threading.Lock()

    def probar(addr):
        if hallado.is_set():
            return
        opener = urllib.request.build_opener(
            urllib.request.ProxyHandler({'http': addr, 'https': addr}))
        try:
            with opener.open(url_test, timeout=timeout) as r:
                if r.getcode() == 200:
                    with lock:
                        if not hallado.is_set():
                            encontrado['addr'] = addr
                            hallado.set()
        except Exception as ex:
            xbmc.log(f"[EspaTV][BT] proxy descartado ({addr}): {ex}", xbmc.LOGDEBUG)

    hilos = [threading.Thread(target=probar, args=(c,), daemon=True) for c in candidatos]
    for t in hilos:
        t.start()
    hallado.wait(timeout * 2)
    return encontrado['addr']


# Ejecución y renderizado

def _strip_color(s):
    return re.sub(r'\[/?[A-Za-z][^\]]*\]', '', s).strip() if s else s


def run(handle, query):
    query = _strip_color((query or '').strip())
    if not query:
        if handle >= 0:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    cfg = _cfg()
    if not _active_sources(cfg):
        xbmcgui.Dialog().ok("Megabuscador",
                            "No hay ninguna plataforma activa.\n\n"
                            "Activa al menos una en 'Plataformas de búsqueda'.")
        if handle >= 0:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    variations = build_variations(query, cfg['extra_variations'])
    proxy_activo = bool(cfg['use_proxy'] and cfg['proxy_addr'])

    bg = xbmcgui.DialogProgressBG()
    bg.create("Megabuscador", f"Buscando '{query}'...")
    try:
        if proxy_activo:
            addr = cfg['proxy_addr']
            urllib.request.install_opener(urllib.request.build_opener(
                urllib.request.ProxyHandler({'http': addr, 'https': addr})))
        bg.update(15, message=" · ".join(_active_sources(cfg)) + "...")
        raw = _run_workers(variations, cfg)
        bg.update(80, message="Ordenando por relevancia...")
        results = aggregate(raw, query, cfg)
    finally:
        if proxy_activo:
            urllib.request.install_opener(None)
        bg.close()

    if not results:
        xbmcgui.Dialog().ok("Megabuscador", f"Sin resultados para:\n[B]{query}[/B]")
        if handle >= 0:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    _render(handle, results)


def _render(handle, results):
    addon = sys.argv[0]
    xbmcplugin.setContent(handle, 'videos')
    for r in results:
        src, titulo = r['source'], r['title']
        thumb = r['thumbnail'] or 'DefaultMusicVideos.png'

        li = xbmcgui.ListItem(label=f"{_BADGE.get(src, '')} {titulo}")
        li.setArt({'icon': 'DefaultMusicVideos.png', 'thumb': thumb,
                   'poster': thumb, 'fanart': thumb})
        plot = ["Fuente: " + src + (f" · {r['owner']}" if r['owner'] else "")]
        if r['duration']:
            plot.append(f"Duración: {r['duration'] // 60}m {r['duration'] % 60}s")
        li.setInfo('video', {'title': titulo, 'plot': "\n".join(plot),
                             'duration': r['duration'], 'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')

        cm = []
        if src == 'DM':
            qv = urllib.parse.quote(r['play_id'])
            qt = urllib.parse.quote(titulo)
            play_url = f"{addon}?action=pv&vid={qv}"
            cm = [
                ("[COLOR lime]Abrir en navegador[/COLOR]",
                 f"RunPlugin({addon}?action=dm_open_browser&url={qv})"),
                ("Descargar Vídeo",
                 f"RunPlugin({addon}?action=download_video&vid={qv}&title={qt})"),
            ]
        elif src == 'YT':
            play_url = r['play_url']
            if r.get('yt_id'):
                qv = urllib.parse.quote(r['yt_id'])
                qt = urllib.parse.quote(titulo)
                play_url = f"{addon}?action=yt_play_video&video_id={qv}&title={qt}"
                cm = [
                    ("Opciones de reproducción",
                     f"Container.Update({addon}?action=felicidad_play&yt_id={qv}&name={qt}&ctype=video)"),
                    ("[COLOR lime]Abrir en navegador[/COLOR]",
                     f"RunPlugin({addon}?action=felicidad_play_exec&yt_id={qv}&name={qt}&method=browser)"),
                ]
        elif src == 'PT':
            play_url = f"{addon}?action=peertube_play&uuid={urllib.parse.quote(r['pt_uuid'])}"
        elif src == 'BC':
            play_url = f"{addon}?action=bitchute_play&video_id={urllib.parse.quote(r['bc_video_id'])}"
        else:
            play_url = odysee_search.plugin_url(
                addon, r['od_name'], r['od_claim_id'],
                r.get('od_sd_hash', ''), r.get('od_media_type', ''))

        if cm:
            li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=handle, url=play_url, listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle)


# Menús y configuración

def _onoff(v):
    return "[COLOR lime]ON[/COLOR]" if v else "[COLOR red]OFF[/COLOR]"


def show_menu(handle):
    ui_utils.visto('megabuscador')
    cfg = _cfg()
    activas = ", ".join(_active_sources(cfg)) or "ninguna"
    ui_utils.add_item(
        action="bt_search", title="[COLOR deepskyblue][B]Buscar ahora[/B][/COLOR]",
        thumbnail=ui_utils.media_icon("busqueda.png"), folder=False,
        plot=f"Abre el teclado y busca a la vez en las plataformas activas ({activas}), "
             "uniendo los resultados ordenados por relevancia con su fuente indicada. "
             "Elige las plataformas en 'Plataformas de búsqueda'.")
    ui_utils.add_item(
        action="bt_toggle", title=f"Limpiar títulos: {_onoff(cfg['clean_titles'])}",
        thumbnail=ui_utils.media_icon("bt_limpiar.png"),
        folder=False, key="clean_titles",
        plot="Quita clickbait de los resultados: emojis, [HD]/1080P/4K, texto entre "
             "corchetes o paréntesis y mayúsculas tipo ¡¡IMPACTANTE!!.")
    ui_utils.add_item(
        action="bt_toggle", title=f"Variaciones extra: {_onoff(cfg['extra_variations'])}",
        thumbnail=ui_utils.media_icon("bt_variaciones.png"),
        folder=False, key="extra_variations",
        plot="Añade mutaciones del título (leet-speak L4 C4s4, sin espacios) a las "
             "búsquedas de Dailymotion. Las variaciones útiles (sin artículos y formato "
             "de capítulos) se aplican siempre.")
    ui_utils.add_item(
        action="bt_toggle",
        title=f"Proxy anti-geobloqueo [COLOR gray](poco fiable)[/COLOR]: {_onoff(cfg['use_proxy'])}",
        thumbnail=ui_utils.media_icon("bt_proxy.png"),
        folder=False, key="use_proxy",
        plot="POCO FIABLE. Enruta SOLO las búsquedas de YouTube/Odysee/PeerTube por un proxy "
             "público. Los proxies gratuitos son lentos e inestables. En la práctica rara vez aporta; "
             "déjalo OFF salvo que lo necesites expresamente.")
    if cfg['use_proxy']:
        ui_utils.add_item(
            action="bt_proxy_find",
            title=f"Buscar proxy ahora (actual: {cfg['proxy_addr'] or 'ninguno'})",
            thumbnail=ui_utils.media_icon("bt_proxy_find.png"),
            folder=False, plot="Rastrea proxies públicos gratuitos y prueba uno que funcione.")
        if cfg['proxy_addr']:
            ui_utils.add_item(action="bt_proxy_clear",
                              title="Quitar proxy guardado",
                              thumbnail=ui_utils.media_icon("bt_proxy_clear.png"),
                              folder=False)
    ui_utils.add_item(
        action="bt_sources_menu", title="Plataformas de búsqueda",
        thumbnail=ui_utils.media_icon("bt_fuentes.png"),
        folder=True, plot=f"Elige en qué plataformas busca el Megabuscador. Activas ahora: {activas}.")
    ui_utils.add_item(
        action="bt_cine_menu", title="Modo cinéfilo",
        thumbnail=ui_utils.media_icon("srch_pelicula.png"),
        folder=True, plot="Afina el orden y el filtrado para destacar el contenido largo y completo "
                          "frente a fragmentos y ruido (duración, idioma y orden). Todo reversible.")
    ui_utils.add_item(
        action="bt_rank_menu", title="Ajustes de ranking",
        thumbnail=ui_utils.media_icon("bt_ranking.png"),
        folder=True, plot="Controla cómo se ordenan los resultados: acentos, coincidencia "
                          "de palabras, episodio, palabras de ruido y filtrado de clips cortos.")
    ui_utils.close_item_list()


def show_sources_menu(handle):
    cfg = _cfg()
    plots = {
        'src_dm': "Dailymotion (búsqueda en español con variaciones).",
        'src_yt': "YouTube (búsqueda directa y reproducción con el plugin de YouTube o motor interno).",
        'src_odysee': "Odysee/LBRY (plataforma descentralizada, reproducción directa).",
        'src_peertube': "PeerTube (red federada SepiaSearch, reproducción directa).",
        'src_bitchute': "BitChute (reproducción directa).",
    }
    iconos = {
        'src_dm': 'dailymotion.png',
        'src_yt': 'youtube.png',
        'src_odysee': 'srch_odysee.png',
        'src_peertube': 'srch_peertube.png',
        'src_bitchute': 'srch_bitchute.png'
    }
    for key, name in _SRC_NAMES.items():
        ui_utils.add_item(
            action="bt_toggle", title=f"{name}: {_onoff(cfg[key])}",
            thumbnail=ui_utils.media_icon(iconos.get(key, "busqueda.png")),
            folder=False, key=key, plot=plots[key])
    ui_utils.close_item_list()


def show_cine_menu(handle):
    cfg = _cfg()
    ui_utils.add_item(
        action="bt_toggle", title=f"Priorizar por duración: {_onoff(cfg['rank_duration'])}",
        thumbnail=ui_utils.media_icon("bt_duracion.png"),
        folder=False, key="rank_duration",
        plot="Sube los resultados largos y completos (+60 min, o 20-60 min) y hunde los fragmentos "
             "muy cortos (-8 min) y los de duración desconocida.")
    ui_utils.add_item(
        action="bt_toggle", title=f"Ignorar fragmentos y ruido: {_onoff(cfg['noise_cine'])}",
        thumbnail=ui_utils.media_icon("bt_ruido.png"),
        folder=False, key="noise_cine",
        plot="Penaliza con fuerza avances, reseñas, reacciones, escenas sueltas, música, gameplay...")
    ui_utils.add_item(
        action="bt_toggle", title=f"Priorizar español: {_onoff(cfg['rank_lang_es'])}",
        thumbnail=ui_utils.media_icon("srch_espanol.png"),
        folder=False, key="rank_lang_es",
        plot="Sube los resultados en castellano/latino (español, castellano, latino, subtitulado, doblada).")
    ui_utils.add_item(
        action="bt_toggle", title=f"Ordenar por calidad: {_onoff(cfg['order_by_quality'])}",
        thumbnail=ui_utils.media_icon("bt_ranking.png"),
        folder=False, key="order_by_quality",
        plot="ON: los mejores resultados primero con tope por fuente. OFF: reparto intercalado round-robin.")
    ui_utils.close_item_list()


def show_rank_menu(handle):
    cfg = _cfg()
    ui_utils.add_item(
        action="bt_toggle", title=f"Normalizar acentos: {_onoff(cfg['rank_accents'])}",
        thumbnail=ui_utils.media_icon("bt_acentos.png"),
        folder=False, key="rank_accents",
        plot="Ignora tildes al comparar ('Aquí' casa con 'aqui').")
    ui_utils.add_item(
        action="bt_toggle", title=f"Coincidencia de palabras: {_onoff(cfg['rank_tokens'])}",
        thumbnail=ui_utils.media_icon("bt_palabras.png"),
        folder=False, key="rank_tokens",
        plot="Puntúa por palabras en común aunque estén en otro orden o con texto extra.")
    ui_utils.add_item(
        action="bt_toggle", title=f"Match de episodio: {_onoff(cfg['rank_episode'])}",
        thumbnail=ui_utils.media_icon("bt_episodio.png"),
        folder=False, key="rank_episode",
        plot="Sube los resultados cuyo capítulo/temporada coincide (1x05 = capitulo 5).")
    ui_utils.add_item(
        action="bt_toggle", title=f"Penalizar ruido: {_onoff(cfg['rank_noise'])}",
        thumbnail=ui_utils.media_icon("bt_ruido.png"),
        folder=False, key="rank_noise",
        plot="Baja un poco los títulos con palabras tipo trailer, promo, resumen, avance...")
    ui_utils.add_item(
        action="bt_toggle", title=f"Filtrar clips cortos: {_onoff(cfg['filter_short'])}",
        thumbnail=ui_utils.media_icon("bt_duracion.png"),
        folder=False, key="filter_short",
        plot="Descarta resultados con duración conocida por debajo del umbral.")
    if cfg['filter_short']:
        ui_utils.add_item(
            action="bt_set_mindur",
            title=f"Duración mínima: {_to_int(cfg['min_duration_secs'])} s",
            thumbnail=ui_utils.media_icon("bt_duracion.png"),
            folder=False, plot="Umbral en segundos para 'Filtrar clips cortos'.")
    ui_utils.close_item_list()


def set_min_duration(handle):
    cfg = _cfg()
    kb = xbmc.Keyboard(str(_to_int(cfg['min_duration_secs'])), 'Duración mínima (segundos)')
    kb.doModal()
    if kb.isConfirmed():
        txt = kb.getText().strip()
        if txt.isdigit():
            _set('min_duration_secs', int(txt))
        else:
            xbmcgui.Dialog().notification("Megabuscador", "Introduce un número de segundos",
                                          xbmcgui.NOTIFICATION_WARNING)
    xbmc.executebuiltin('Container.Refresh')


def prompt_and_run(handle):
    activas = _active_sources(_cfg())
    if not activas:
        xbmcgui.Dialog().ok("Megabuscador",
                            "No hay ninguna plataforma activa.\n\n"
                            "Activa al menos una en 'Plataformas de búsqueda'.")
        if handle >= 0:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    q = (ui_utils.get_text(f'Megabuscador ({" · ".join(activas)})') or '').strip()
    if q:
        xbmc.executebuiltin(f'Container.Update("{sys.argv[0]}?action=bt_run&q={urllib.parse.quote(q)}")')
    elif handle >= 0:
        xbmcplugin.endOfDirectory(handle, succeeded=False)


def toggle(handle, key):
    if isinstance(_DEFAULTS.get(key), bool):
        _set(key, not _cfg().get(key, _DEFAULTS[key]))
    xbmc.executebuiltin('Container.Refresh')


def proxy_find(handle):
    bg = xbmcgui.DialogProgressBG()
    bg.create("Megabuscador", "Buscando proxy disponible...")
    try:
        addr = obtener_proxy_valido()
    finally:
        bg.close()
    if addr:
        _set('proxy_addr', addr)
        xbmcgui.Dialog().notification("Megabuscador", f"Proxy: {addr}",
                                      xbmcgui.NOTIFICATION_INFO)
    else:
        xbmcgui.Dialog().notification("Megabuscador", "No se encontró proxy disponible",
                                      xbmcgui.NOTIFICATION_WARNING)
    xbmc.executebuiltin('Container.Refresh')


def proxy_clear(handle):
    _set('proxy_addr', '')
    xbmc.executebuiltin('Container.Refresh')

