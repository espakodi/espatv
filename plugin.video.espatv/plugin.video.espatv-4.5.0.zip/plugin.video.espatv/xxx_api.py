# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Sección X (+18): capa de red de Eporner, RedTube y Pornhub.

Desacoplada de Kodi para permitir ejecución independiente y pruebas unitarias sin dependencias externas.
La interfaz de usuario reside en `xxx_eporner.py`.

Detalles técnicos de integración con los servicios:

1. Eporner: las claves en `sources.mp4` pueden reportar valores compuestos como "1080p HD".
   La resolución se extrae de `labelShort`, manteniendo un fallback por expresión regular.
2. Cabeceras Referer: el CDN requiere Referer explícito para servir el contenido (RedTube
   exige el del embed y Pornhub el de origen; sin ellos devuelven 410 y 404 respectivamente).
3. URLs firmadas temporales: no son cacheables debido a sus ventanas de expiración y firma por IP:
   - Eporner: parámetros en path con TTL de 270 a 1260 s ligado a la IP pública.
   - RedTube: parámetros de ventana temporal (7200 s) con hash.
   - Pornhub: parámetros de ventana temporal (7200 s) ligados a IP e interfaz.
4. CDN de miniaturas en Pornhub: de los dos hosts presentes en `thumbs[]`, se selecciona
   `pix-fl.phncdn.com` (200 OK) frente a `pix-cdn77.phncdn.com` (403 Forbidden).
"""
import json
import math
import os
import re
import time
import urllib.parse

import requests

from _user_agents import desktop_headers, ACCEPT_JSON, ACCEPT_HTML

API_SEARCH = "https://www.eporner.com/api/v2/video/search/"
RT_API = "https://api.redtube.com/"
PH_API = "https://www.pornhub.com/webmasters/search"

RAIZ_EP = "https://www.eporner.com/"
RAIZ_RT = "https://embed.redtube.com/"
RAIZ_PH = "https://www.pornhub.com/"
EMBED_RT = RAIZ_RT + "?id=%s"
EMBED_PH = RAIZ_PH + "embed/%s"
EMBED_EP = RAIZ_EP + "embed/%s/"

# Cookie oficial de la puerta de edad de Eporner (la que su web pone al confirmar +18). Se manda
# siempre: hoy no hace falta, pero el día que vuelvan a mostrarla el puerta ya está pasado.
COOKIE_EP = "ageverif_accepted=T"

# Los 8 valores que acepta la API de Eporner. Se comprobo que "most-viewed" NO esta entre
# ellos (los reales son latest, top-weekly, top-monthly, most-popular, top-rated, longest,
# shortest y... ninguno mas): se pidio una vez y devolvio la lista del ultimo, no la de mas
# vistos. Se queda fuera de la lista en vez de dejarse como un valor con pinta de bueno.
ORDERS_EP = ("latest", "top-weekly", "top-monthly", "most-popular", "top-rated",
             "longest", "shortest")
THUMBS_EP = ("small", "medium", "big")
# Valores de `gay` que la API de Eporner distingue:
#   0 = oculta el contenido gay (lo que hace la API por defecto).
#   2 = listado de contenido gay casi en exclusiva (91-99% de los títulos).
# El valor 1 no se incluye porque no filtra adecuadamente (31% en latest frente al 91-99% del 2).
# Cualquier valor fuera de estos dos se trata como 0.
GAY_EP = (0, 2)

# Espera entre el reintento de una peticion y el siguiente. Corta a proposito: si la API esta
# limitando, esperar mas solo alarga la espera del usuario.
RETRY_ESPERA = 1.5

PAGE_SIZE_EP = 20
PAGE_SIZE_RT = 20
PAGE_SIZE_PH = 30

TTL_CACHE = 300
MAX_CACHE = 200

_B36 = "0123456789abcdefghijklmnopqrstuvwxyz"
_RE_HASH = re.compile(r"hash\s*[:=]\s*[\"']([\da-fA-F]{32})")
_RE_ALT = re.compile(r"(\d+)\s*[pP]")
# El host del get_media de Pornhub cambia por región (www, es, de...): se busca por camino, no
# por host clavado. La página del embed además trae a veces las fuentes ya dentro, en ese caso
# la misma entrada con la del get_media.
_RE_GETMEDIA = re.compile(r'(https?://[\w.-]+/video/get_media\?s=[^"\']+)')
_RE_VIDEOURL = re.compile(r'"videoUrl"\s*:\s*"(https?://[^"]+)"')


# --------------------------------------------------------------------- HTTP
_cache = {}


def _clave(url, ua, cookies, referer):
    return (url, ua or "", cookies or "", referer or "")


def limpiar_cache():
    """Vacía la caché en memoria de los listados. Los resolves nunca se cachean."""
    _cache.clear()


def _log_puesto():
    """Si la sección tiene los avisos puestos. Por defecto SÍ.

    Se lee el ajuste entero, que son cuatro bytes de un JSON, y solo cuando hay algo que
    avisar: los fallos son raros, así que no merece la pena/cachear nada y meter otra variable
    de módulo que se pueda quedar vieja.

    `xxx_api` no importa `xxx_eporner` (sería circular: la UI importa la API), así que el nombre
    del fichero sale de aquí. Es el mismo valor en los dos sitios y hay un test que lo comprueba.
    """
    try:
        import ui_utils
        datos = ui_utils.load_json("xxx_settings.json", {})
        if isinstance(datos, dict):
            v = datos.get("log_on", True)
            if v in ("no", "No", "0", "false", False):
                return False
        return True
    except Exception:
        # Si no se puede leer, se avisa. Perder el log a silencio seria volver al problema que
        # esto arregla.
        return True


def _aviso(mensaje, *extra):
    """Escribe en el log de Kodi sin romper si `xbmc` no esta, y si la sección lo tiene puesto.

    Este modulo no tenia NI UN `xbmc.log`, y sus 19 `return None` se tragan la causa. En una
    sección donde ya se sabe que RedTube corta el catálogo hacia la página 505, que el CDN de
    miniaturas devuelve 429 y que hay vídeos despublicados, un 403 por rate-limit, un 404 y un
    timeout eran INDISTINGUIBLES desde fuera: el usuario solo veía "no ha contestado".

    El ajuste `log_on` de Ajustes lo calla. Por defecto está puesto.

    No se loguea la URL entera: son de hasta 170 KB y llevan identificadores. Con los tres
    primeros segmentos basta para saber de quién es el fallo.
    """
    if not _log_puesto():
        return
    try:
        import xbmc
        xbmc.log("[EspaTV-X] {0}".format(mensaje), xbmc.LOGWARNING)
    except Exception:
        pass
def http_get(url, timeout=15, referer=None, cache=True, ua=None, cookies=None, accept=None):
    """GET con User-Agent de navegador. Devuelve el texto, o None si algo falla.

    Solo 200 se considera éxito: un 206 o un 302 cuentan como fallo, que es lo que espera el
    resto de la sección. `cache=False` en todo lo que resuelve URLs firmadas.
    """
    ahora = time.time()
    k = _clave(url, ua, cookies, referer)
    if cache and k in _cache:
        ts, texto = _cache[k]
        if ahora - ts < TTL_CACHE:
            return texto
    cabeceras = desktop_headers(accept=accept or ACCEPT_JSON)
    if cookies:
        cabeceras["Cookie"] = cookies
    if referer:
        cabeceras["Referer"] = referer
    corto = "/" + "/".join([s for s in url.split("/")[3:6] if s])[:60]
    try:
        r = requests.get(url, headers=cabeceras, timeout=timeout)
        if r.status_code != 200:
            # Aqui estaba el punto ciego: un 403 por rate-limit, un 404 de video
            # despublicado, un 429 del CDN y un 302 se veian IGUALES desde fuera.
            _aviso("HTTP {0} en {1}".format(r.status_code, corto))
            return None
        texto = r.text
    except (requests.RequestException, ValueError) as exc:
        # La clase de la excepcion es lo que dice si fue DNS, TLS, timeout o conexion
        # rechazada. Sin esto, "no ha contestado" no significa nada.
        _aviso("{0} en {1}".format(type(exc).__name__, corto))
        return None
    if cache:
        if len(_cache) >= MAX_CACHE:
            # Se va la más antigua: en CPython el orden de inserción es el de inserción.
            try:
                del _cache[next(iter(_cache))]
            except (StopIteration, KeyError):
                pass
        _cache[k] = (ahora, texto)
    return texto


def _json(texto):
    if not texto:
        return None
    try:
        return json.loads(texto)
    except ValueError:
        return None


# ------------------------------------------------------------------ helpers
def dur_to_sec(s):
    """'53:27' -> 3207. Tolera int, '12', '1:2:3', '' y None."""
    if s is None:
        return 0
    if isinstance(s, bool):
        return 0
    if isinstance(s, (int, float)):
        try:
            return int(s)
        except (ValueError, OverflowError):
            return 0
    total = 0
    for parte in str(s).split(":"):
        parte = parte.strip()
        if not parte.isdigit():
            continue
        total = total * 60 + int(parte)
    return total


def dur_a_min(seg):
    try:
        seg = int(seg)
    except (TypeError, ValueError, OverflowError):
        # `OverflowError` va aparte porque `int(float("inf"))` la lanza y no es un
        # `ValueError`: es el mismo agujero que se cerro en `_int()` y en los otros dos
        # formateadores, aqui se habia quedado uno.
        seg = 0
    if seg <= 0:
        return ""
    return "{0}:{1:02d}".format(seg // 60, seg % 60)


def norm_rate(valor, escala):
    """Deja la nota en 0-10. `escala` es 5 (Eporner) o 100 (RedTube y Pornhub).

    `nan` e `inf` se rechazan explícitamente, y no por capricho. `json.loads` los acepta como
    literales (`Infinity`, `-Infinity`, `NaN`), así que una API puede mandar cualquiera de los
    tres en la nota. Y sin este filtro pasa lo siguiente:

    · con `nan`: `nan <= 0` es False, y en Python `min(10.0, nan)` devuelve el PRIMER argumento,
      o sea que salía **10.0**: una nota «NaN» se pintaba como perfecta.
    · con `inf`: `min(10.0, inf)` también da 10.0, o sea que un `Infinity` salía como perfecta.
    """
    try:
        v = float(valor)
    except (TypeError, ValueError):
        return 0.0
    if not math.isfinite(v) or v <= 0:
        return 0.0
    if escala == 5:
        v = v * 2.0
    else:
        v = v / 10.0
    return max(0.0, min(10.0, round(v, 1)))


def formatea_vistas(n):
    """78559 -> '78.5K'. A partir de un millón, una cifra y 'M'."""
    try:
        n = int(n)
    except (TypeError, ValueError, OverflowError):
        return ""
    if n <= 0:
        return ""
    if n >= 1000000:
        return "{0:.1f}M".format(n / 1000000.0)
    if n >= 1000:
        return "{0:.1f}K".format(n / 1000.0)
    return str(n)


def fix_thumb(url):
    """Escapa caracteres problemáticos en URLs de imagen (paréntesis y espacios) y restringe a http(s).

    Se mantiene el nombre de archivo original sin alterar '0.jpg' por '1.jpg',
    ya que los endpoints actuales devuelven error HTTP 410 al forzar '1.jpg'.
    """
    if not isinstance(url, str):
        return ""
    url = url.strip()
    if not url.lower().startswith(("http://", "https://")):
        # El esquema se filtra aqui y no en el `setArt`: una caratula puede venir de un JSON
        # importado (copia de seguridad de otro addon) o de una URL escrita a mano, y con
        # `file://`, `smb://` o `plugin://` Kodi leeria un fichero que el usuario no quiere.
        return ""
    # Las URL de RedTube llevan parentesis en el nombre (`(m=a)(mh=b)0.jpg`) y eso rompe el
    # parser de rutas de Kodi. Se escapan parentesis y espacios.
    return url.replace("(", "%28").replace(")", "%29").replace(" ", "%20")


def _int(v, defecto=0):
    """`int()` tolerante. Captura TypeError, ValueError y OverflowError (por si una API envía Infinity)."""
    try:
        return int(v)
    except (TypeError, ValueError, OverflowError):
        return defecto


def pick_quality(candidatos, quality="max"):
    """candidatos: lista de (altura, url). 'max' = la mayor; 'ahorro' = la menor.

    Filtra aquí también lo que no sea http(s): los resolvedores ya lo hacen, pero que la última
    puerta antes de Kodi no dependa de que cada uno se acuerde.
    La altura 0 (el resolvedor no la dice) no gana nunca en 'max', pero sí sirve de último
    recurso en 'ahorro' cuando es lo único que hay.
    """
    cands = [(int(h), u) for h, u in list(candidatos or []) if u and u.startswith("http")]
    if not cands:
        return ""
    cands.sort(key=lambda c: c[0])
    if quality == "ahorro":
        # La altura 0 significa que el resolvedor no indica la resolución.
        # Solo se utiliza en modo 'ahorro' como último recurso si no hay candidatos con altura conocida.
        con_altura = [c for c in cands if c[0] > 0]
        return (con_altura[0] if con_altura else cands[0])[1]
    return cands[-1][1]


# ------------------------------------------------------------- normalizadores
_RE_EMOJIS = re.compile(
    r"["
    r"\U00010000-\U0010ffff"
    r"\u2600-\u27bf"
    r"\u2300-\u23ff"
    r"\u2b00-\u2bff"
    r"\u20d0-\u20ff"
    r"\u2190-\u21ff"
    r"\ufe00-\ufe0f"
    r"\u200d\u200c"
    r"\u3030\u303d\u3297\u3299"
    r"\ud800-\udfff"
    r"\ufffd"
    r"\ue000-\uf8ff"
    r"]+",
    flags=re.UNICODE,
)


def limpiar_emojis(texto):
    """Elimina emojis y caracteres gráficos no representables en Kodi (evita cajas [][] en Estuary)."""
    if texto is None:
        return ""
    texto_str = str(texto)
    if not texto_str:
        return ""
    limpio = _RE_EMOJIS.sub("", texto_str)
    return " ".join(limpio.split())


def _segundos_de_eporner(v):
    """La duración de un vídeo de Eporner, en segundos.

    Eporner manda `length_sec` en segundos y, cuando no lo manda, `length_min` en minutos.
    Un valor con ":" (que ya es una duración formateada) se respeta tal cual.
    """
    if v.get("length_sec"):
        return dur_to_sec(v.get("length_sec"))
    bruto = v.get("length_min")
    if bruto in (None, ""):
        return 0
    if ":" in str(bruto):
        return dur_to_sec(bruto)
    return dur_to_sec(bruto) * 60


def norm_eporner(v):
    """Fila de la API v2 de Eporner al formato de la sección. None si no es reproducible."""
    if not isinstance(v, dict):
        return None
    vid = str(v.get("id") or "").strip()
    raw_titulo = str(v.get("title") or "").strip()
    if not vid or not raw_titulo:
        return None
    titulo = limpiar_emojis(raw_titulo) or "Sin título"
    thumb = v.get("default_thumb")
    if isinstance(thumb, dict):
        thumb = thumb.get("src")
    seg = _segundos_de_eporner(v)
    return {
        "src": "ep",
        "id": vid,
        "title": titulo,
        "thumb": fix_thumb(thumb),
        "length": dur_a_min(seg),
        "length_sec": seg,
        "views": _int(v.get("views")),
        # Eporner puntúa de 0 a 5: sin multiplicar por dos salía con ★0.5.
        "rate": norm_rate(v.get("rate"), 5),
        "embed": v.get("embed") or (EMBED_EP % vid),
        "page": v.get("url") or (RAIZ_EP + "video-" + vid + "/"),
        "added": str(v.get("added") or "")[:10],
        "keywords": [limpiar_emojis(k.strip()) for k in str(v.get("keywords") or "").split(",")
                     if limpiar_emojis(k.strip())][:8],
    }


def norm_redtube(item):
    """La API de RedTube anida cada vídeo en `video`. Sin desempaquetar, la lista sale vacía."""
    if isinstance(item, dict) and isinstance(item.get("video"), dict):
        item = item["video"]
    if not isinstance(item, dict):
        return None
    vid = str(item.get("video_id") or "").strip()
    raw_titulo = str(item.get("title") or "").strip()
    if not vid or not raw_titulo:
        return None
    titulo = limpiar_emojis(raw_titulo) or "Sin título"
    seg = dur_to_sec(item.get("duration"))
    tags = [t.get("tag_name", "") for t in (item.get("tags") or [])
            if isinstance(t, dict) and t.get("tag_name")]
    return {
        "src": "rt",
        "id": vid,
        "title": titulo,
        "thumb": fix_thumb(item.get("default_thumb") or item.get("thumb")),
        "length": dur_a_min(seg),
        "length_sec": seg,
        "views": _int(item.get("views")),
        "rate": norm_rate(item.get("rating"), 100),
        "embed": item.get("embed_url") or (EMBED_RT % vid),
        "page": item.get("url") or (PAGINA_RT + vid),
        "added": str(item.get("publish_date") or "")[:10],
        "keywords": [limpiar_emojis(t.strip()) for t in tags if limpiar_emojis(t.strip())][:8],
    }


# ---------------------------------------------------------------- miniaturas de RedTube
# La API de RedTube devuelve `default_thumb` con la ruta incompleta (sin fecha ni ID intermedio).
# cuatro combinaciones de User-Agent (navegador y el de Kodi) y de Referer (con y sin).
#
# Con una BÚSQUEDA sí viene la ruta entera (`/videos/202109/09/394382961/original/...`) y esa
# responde `200` cruda y escapada. El fallo es de los listados SIN término: Últimos, Más vistos,
# Top semanal y Top mensual, que es justo por donde se entra.
#
# Ni `thumbsize` ni `quality` lo arreglan: seis variantes de parámetro (`thumbsize` medium, big,
# small y `0.jpg`, `quality=480` y ninguna) y las 20 filas siguen devolviendo 1 sola URL. Los otros
# métodos de la API (`getVideo`, `getCategories`, `getRelatedVideos`) no existen: devuelven `code`
# y `message`.
#
# Ojo con lo que SÍ se encuentra en la página y NO es la miniatura: hay un `<img>` de
# `ei-ph.rdtcdn.com/(m=..)(mh=..)<uuid>.jpg` que es el AVATAR del uploader. Se parece mucho a una
# miniatura válida y no lo es. Por eso la única fuente que se usa aquí es la `og:image`, que sí es
# de este vídeo.
# La etiqueta og:image en el <head> proporciona una imagen válida de 1280x720.
# Como el CDN exige cabecera Referer que Kodi no envía por defecto al descargar arte,
# se descarga localmente en disco y se entrega la ruta del archivo local.
#
# Se guarda el archivo en disco evitando peticiones redundantes con URLs firmadas con caducidad.
PAGINA_RT = "https://www.redtube.com/"
_OG_IMAGE_RT = re.compile(r'<meta[^>]+property="og:image"[^>]+content="([^"]+)"', re.I)
_IMAGE_URL_RT = re.compile(r'["\']image_url["\']\s*:\s*["\']([^"\']+)["\']')
_BYTES_CABECERA_RT = 32768
# Tope a la imagen. Hoy son 49 KB; si un día `rs:fit` devolviera otra cosa, no se llena el disco.
_MAX_THUMB_RT = 4 * 1024 * 1024


def thumb_redtube_rota(url):
    """Indica si la URL de miniatura corresponde a la plantilla incompleta de RedTube.

    Identifica URLs vacías que contienen '/videos//' en lugar de la ruta de fecha e id.
    """
    return isinstance(url, str) and "/videos//" in url


def _busca_thumb_redtube(carpeta, vid):
    """Ruta de la miniatura ya descargada de este vídeo, o "" si no está."""
    for ext in (".jpg", ".png"):
        ruta = os.path.join(carpeta, "rt_" + vid + ext)
        try:
            if os.path.isfile(ruta) and os.path.getsize(ruta) > 0:
                return ruta
        except OSError:
            return ""
    return ""


def _lee_og_image_redtube(vid, timeout):
    """La URL de la miniatura de RedTube desde su reproductor embed oficial.

    El subdominio oficial de embed (EMBED_RT) evita bloqueos de conexion y cortes TLS
    en el dominio principal y entrega la miniatura directa en la variable image_url.
    """
    pagina = EMBED_RT % vid
    respuesta = None
    try:
        respuesta = requests.get(pagina, headers=desktop_headers(accept=ACCEPT_HTML),
                                 timeout=timeout, stream=True)
        if respuesta.status_code != 200:
            _aviso("HTTP {0} en el reproductor de RedTube {1}".format(respuesta.status_code, vid))
            return ""
        trozo = b""
        for parte in respuesta.iter_content(4096):
            trozo += parte
            if len(trozo) >= _BYTES_CABECERA_RT:
                break
    except (requests.RequestException, ValueError) as exc:
        _aviso("{0} en el reproductor de RedTube {1}".format(type(exc).__name__, vid))
        return ""
    finally:
        try:
            if respuesta is not None:
                respuesta.close()
        except Exception:
            pass
    texto = trozo.decode("utf-8", "replace")
    m_embed = _IMAGE_URL_RT.search(texto)
    if m_embed:
        return m_embed.group(1).replace("\\/", "/").replace("&amp;", "&")
    m_og = _OG_IMAGE_RT.search(texto)
    return m_og.group(1).replace("&amp;", "&") if m_og else ""


def _descarga_thumb_redtube(vid, carpeta, timeout=15):
    """Deja en `carpeta` la miniatura de este vídeo de RedTube. Devuelve su ruta, o "".

    El `Referer` no es un detalle: sin él el CDN contesta `403` y con él `200`. Es el mismo motivo
    por el que Pornhub tiene su `PH_HOST_BUENO`, pero aquí al revés: allí se elegía entre dos hosts
    de la propia API, y aquí la URL buena no la da la API ni ninguna otra, sale de la página.

    Solo se acepta lo que sea una imagen de verdad (JPEG o PNG por los bytes magos). Un HTML de
    error guardado con extension `.jpg` se lo creeria Kodi hasta que tryase pintarlo.
    """
    og = _lee_og_image_redtube(vid, timeout)
    if not og:
        return ""
    cabeceras = desktop_headers(accept="image/*")
    cabeceras["Referer"] = PAGINA_RT
    respuesta = None
    datos = b""
    try:
        respuesta = requests.get(og, headers=cabeceras, timeout=timeout, stream=True)
        if respuesta.status_code != 200:
            _aviso("HTTP {0} en la miniatura de RedTube {1}".format(respuesta.status_code, vid))
            return ""
        for parte in respuesta.iter_content(65536):
            datos += parte
            if len(datos) > _MAX_THUMB_RT:
                datos = b""
                break
    except (requests.RequestException, ValueError) as exc:
        _aviso("{0} en la miniatura de RedTube {1}".format(type(exc).__name__, vid))
        return ""
    finally:
        try:
            if respuesta is not None:
                respuesta.close()
        except Exception:
            pass
    extension = ""
    if datos[:3] == b"\xff\xd8\xff":
        extension = ".jpg"
    elif datos[:8] == b"\x89PNG\r\n\x1a\n":
        extension = ".png"
    if not extension:
        return ""
    ruta = os.path.join(carpeta, "rt_" + vid + extension)
    if os.path.isfile(ruta) and os.path.getsize(ruta) > 0:
        return ruta
    import tempfile
    temporal = None
    try:
        fd, temporal = tempfile.mkstemp(dir=carpeta, prefix="tmp_rt_{0}_".format(vid), suffix=".parte")
        with os.fdopen(fd, "wb") as fichero:
            fichero.write(datos)
        os.replace(temporal, ruta)
    except OSError as exc:
        if os.path.isfile(ruta) and os.path.getsize(ruta) > 0:
            if temporal and os.path.exists(temporal):
                try:
                    os.remove(temporal)
                except OSError:
                    pass
            return ruta
        if temporal and os.path.exists(temporal):
            try:
                os.remove(temporal)
            except OSError:
                pass
        _aviso("No se pudo guardar la miniatura de RedTube {0}: {1}".format(vid, exc))
        return ""
    return ruta


#: El fallo se apunta en disco y no en memoria: en Kodi cada pulsación es un
#: intérprete nuevo, de modo que un estado en memoria no persiste entre navegaciones.
REINTENTO_THUMB_H = 24

#: Días que se guarda una miniatura de RedTube antes de borrarla sola.
#:
#: Evita crecimiento indefinido de la caché local de imágenes.
DIAS_THUMB_RT = 30
_CORTE_FALLO_OBSOLETO = 1793635000


def _ruta_fallo_thumb_rt(carpeta, vid):
    """La ruta del marcador de «esta miniatura fallo»: ``rt_<vid>.fallo``.

    El nombre sale de `_vid_seguro`, nunca del id tal cual: es un nombre de fichero y un id
    con barras saldría de su carpeta.
    """
    return os.path.join(carpeta, "rt_{0}.fallo".format(vid))


def thumb_rt_fallada(video, carpeta):
    """True si esta miniatura ya falló hace poco y no toca reintentarla.

    El marcador está en disco (`rt_<vid>.fallo`, con la hora dentro), no en memoria: en Kodi
    cada pulsación es un intérprete nuevo, así que lo que se recuerde en un diccionario del
    módulo no llega a la siguiente pulsación.

    Un marcador que no se puede leer (roto, vacío, con la hora del futuro) se trata como **no
    fallado**: es mejor reintentar de más que quedarse sin una miniatura para siempre. Y con la
    caducidad de `REINTENTO_THUMB_H`, reintentar de más es como máximo una vez al día.
    """
    if not carpeta or not isinstance(video, dict):
        return False
    vid = _vid_seguro(video.get("id"))
    if not vid:
        return False
    try:
        with open(_ruta_fallo_thumb_rt(carpeta, vid), "r", encoding="utf-8") as f:
            cuando = float(f.read().strip() or 0)
    except (OSError, ValueError):
        return False
    if cuando < _CORTE_FALLO_OBSOLETO:
        return False
    edad = time.time() - cuando
    return 0 < edad < REINTENTO_THUMB_H * 3600


def apunta_fallo_thumb_rt(video, carpeta):
    """Apunta que esta miniatura ha fallado, para no reintentarla en `REINTENTO_THUMB_H`.

    Devuelve si se ha podido escribir, y **nunca lanza**: es una anotación, y una anotación
    que revienta estorba más que la miniatura que falta.
    """
    if not carpeta or not isinstance(video, dict):
        return False
    vid = _vid_seguro(video.get("id"))
    if not vid:
        return False
    try:
        with open(_ruta_fallo_thumb_rt(carpeta, vid), "w", encoding="utf-8") as f:
            f.write(str(time.time()))
        return True
    except OSError:
        return False


def _limpia_thumbs_viejas(carpeta, dias=DIAS_THUMB_RT):
    """Borra las miniaturas de RedTube de más de `dias`. Devuelve cuántas.

    Se llama al **guardar** una nueva, no al entrar: así el mantenimiento lo paga quien usa la
    sección y no quien solo abre el menú. Y si no se descarga nada, la carpeta no crece y no
    hay nada que limpiar.

    Se limita a los ficheros propios (`rt_`), que en esa carpeta son todos, pero listarla
    antes de filtrar es gratis y evita llevarse por delante algo que no sea suyo.
    """
    if not carpeta:
        return 0
    try:
        limite = time.time() - dias * 86400
        borradas = 0
        for nombre in os.listdir(carpeta):
            if not nombre.startswith("rt_") and not nombre.startswith("tmp_rt_"):
                continue
            ruta = os.path.join(carpeta, nombre)
            try:
                if nombre.startswith("tmp_rt_"):
                    if os.path.getmtime(ruta) < time.time() - 3600:
                        os.remove(ruta)
                    continue
                if nombre.endswith(".fallo"):
                    try:
                        with open(ruta, "r", encoding="utf-8") as f:
                            ts = float(f.read().strip() or 0)
                        if ts < _CORTE_FALLO_OBSOLETO:
                            os.remove(ruta)
                            borradas += 1
                            continue
                    except (OSError, ValueError):
                        pass
                if os.path.getmtime(ruta) < limite:
                    os.remove(ruta)
                    borradas += 1
            except OSError:
                pass
        return borradas
    except OSError:
        return 0


def thumbs_redtube(videos, carpeta, timeout=5, workers=12):
    """Miniaturas de RedTube reparadas de una pantalla entera: ``{id: ruta local}``.

    Solo procesa los elementos con miniatura rota según `thumb_redtube_rota()`.
    Las peticiones se realizan en paralelo con un pool de trabajadores. Las imágenes
    obtenidas se persisten localmente en disco para no repetir descargas en visitas futuras.

    El tiempo de espera corto (5 s) evita retener la interfaz si alguna petición se demora.
    Si una miniatura falla, se anota en disco con `thumb_rt_fallada()` para no reintentarla
    durante 24 h y se recurre a la imagen de la API o icono de la plataforma.
    """
    salida = {}
    pendientes = []
    ya_vistos = set()
    for v in (videos or []):
        if not isinstance(v, dict) or v.get("src") != "rt":
            continue
        vid = _vid_seguro(v.get("id"))
        original = str(v.get("id") or "")
        if not vid or original in ya_vistos:
            continue
        ya_vistos.add(original)
        if not thumb_redtube_rota(v.get("thumb")):
            continue
        guardada = _busca_thumb_redtube(carpeta, vid) if carpeta else ""
        if guardada:
            salida[original] = guardada
        else:
            pendientes.append((original, vid))
    if not pendientes or not carpeta:
        return salida
    try:
        os.makedirs(carpeta, exist_ok=True)
    except OSError as exc:
        _aviso("No se pudo crear la carpeta de miniaturas: {0}".format(exc))
        return salida
    try:
        from concurrent.futures import ThreadPoolExecutor

        def _trabajo(par):
            try:
                return _descarga_thumb_redtube(par[1], carpeta, timeout)
            except Exception as exc:
                _aviso("{0} en la miniatura de RedTube {1}".format(type(exc).__name__, par[1]))
                return ""

        with ThreadPoolExecutor(max_workers=max(1, min(workers, len(pendientes)))) as hilos:
            rutas = list(hilos.map(_trabajo, pendientes))
    except Exception as exc:
        _aviso("No se pudieron reparar las miniaturas de RedTube: {0}".format(exc))
        return salida
    reparadas = 0
    for (original, _), ruta in zip(pendientes, rutas):
        if ruta:
            salida[original] = ruta
            reparadas += 1
    if reparadas:
        # La carpeta se limpia al guardar y no al entrar, delegando el mantenimiento
        # al momento en que se generan nuevas imágenes. Ver `_limpia_thumbs_viejas()`.
        _limpia_thumbs_viejas(carpeta)
        try:
            import xbmc

            xbmc.log("[EspaTV-X] miniaturas de RedTube reparadas: {0}".format(reparadas))
        except Exception:
            pass
    return salida


# Host de miniaturas de Pornhub que permite descarga directa sin cabecera Referer.
PH_HOST_BUENO = "pix-fl.phncdn.com"


def _miniatura_ph(item):
    """Selecciona la miniatura óptima del vídeo dentro de las variantes que envía la API.

    Recorre el arreglo 'thumbs' prefiriendo URLs alojadas en PH_HOST_BUENO, ya que
    otros servidores del CDN rechazan peticiones sin cabecera Referer.
    """
    candidatas = []
    for t in (item.get("thumbs") or []):
        if isinstance(t, dict):
            src = t.get("src") or t.get("url") or ""
            if isinstance(src, str) and src.startswith("http"):
                candidatas.append(src)
    for clave in ("thumb", "default_thumb"):
        v = item.get(clave)
        if isinstance(v, str) and v.startswith("http"):
            candidatas.append(v)
    buena = ""
    cualquiera = ""
    for url in candidatas:
        if PH_HOST_BUENO in url and not buena:
            buena = url
        elif not cualquiera:
            cualquiera = url
    return fix_thumb(buena or cualquiera)


def norm_pornhub(item):
    if not isinstance(item, dict):
        return None
    vid = str(item.get("video_id") or "").strip()
    raw_titulo = str(item.get("title") or "").strip()
    if not vid or not raw_titulo:
        return None
    titulo = limpiar_emojis(raw_titulo) or "Sin título"
    seg = dur_to_sec(item.get("duration"))
    cats = [c.get("category", "") for c in (item.get("categories") or [])
            if isinstance(c, dict) and c.get("category")]
    return {
        "src": "ph",
        "id": vid,
        "title": titulo,
        # Se prefiere `thumb` por consistencia en la respuesta de imágenes.
        "thumb": _miniatura_ph(item),
        "length": dur_a_min(seg),
        "length_sec": seg,
        "views": _int(item.get("views")),
        "rate": norm_rate(item.get("rating"), 100),
        "embed": EMBED_PH % vid,
        "page": item.get("url") or (RAIZ_PH + "view_video.php?viewkey=" + vid),
        "added": str(item.get("publish_date") or "")[:10],
        "keywords": [limpiar_emojis(c.strip()) for c in cats if limpiar_emojis(c.strip())][:8],
        # Segmento temático devuelto por la API (/webmasters/search) para aplicar
        # el filtro de contenido de forma determinista.
        "segment": str(item.get("segment") or "").strip().lower(),
    }


# ------------------------------------------------------------------ Eporner
def search_eporner(query="", page=1, order="latest", per_page=PAGE_SIZE_EP,
                   thumbsize="big", gay=0, lq=0, timeout=15):
    """Listado de la API v2. Devuelve el dict crudo, o None si la API falla.

    `lq` se fija a 0 (el default de la API es 1, "incluir baja calidad") y `thumbsize` y `gay`
    solo existen aquí: RedTube y Pornhub los ignoran.
    """
    if order not in ORDERS_EP:
        order = "latest"
    if thumbsize not in THUMBS_EP:
        thumbsize = "big"
    if gay not in GAY_EP:
        gay = 0
    params = {
        "query": query or "",
        "per_page": max(1, min(1000, _int(per_page, PAGE_SIZE_EP))),
        "page": max(1, _int(page, 1)),
        "order": order,
        "gay": gay,
        "lq": lq,
        "thumbsize": thumbsize,
        "format": "json",
    }
    url = API_SEARCH + "?" + urllib.parse.urlencode(params, quote_via=urllib.parse.quote_plus)
    return _json(http_get(url, timeout=timeout))


def b36(num):
    if not num:
        return "0"
    r = ""
    while num:
        r = _B36[num % 36] + r
        num //= 36
    return r


def calc_hash(page_hash):
    """Transforma 4 bloques de 8 hex a base36 según la lógica del reproductor oficial.

    Devuelve None si el formato es inválido para que resolve_eporner use fuentes alternativas.
    """
    if not isinstance(page_hash, str):
        return None
    h = page_hash.strip()
    if len(h) != 32:
        return None
    out = []
    for i in range(0, 32, 8):
        try:
            out.append(b36(int(h[i:i + 8], 16)))
        except ValueError:
            return None
    return "".join(out)


def _altura_de_eporner(clave, entrada):
    """Altura de una fuente de Eporner. `labelShort` manda; la clave es el respaldo.

    La clave puede venir como "1080p HD", así que no se puede quitar el último carácter a pelo.
    """
    for campo in ("labelShort", "label"):
        val = entrada.get(campo)
        if val:
            m = _RE_ALT.search(str(val))
            if m:
                return int(m.group(1))
    m = _RE_ALT.search(str(clave))
    return int(m.group(1)) if m else 0


class MotivoPermanente(str):
    """Un motivo que NO se arregla esperando: el vídeo no está, o no hay fuente.

    Se comporta como un `str` normal, pero `resolver()` lo reconoce por su tipo en lugar
    de acoplar el reintento a subcadenas en el mensaje de error.
    """


def resolve_eporner(video_id, quality="max", timeout=15):
    """El flujo del player oficial: página -> hash -> /xhr/video -> mejor mp4.

    Devuelve (url, motivo). Sin caché en ningún paso: la URL firmada caduca en 4-21 minutos y
    va atada a la IP de esta petición.

    OJO: el `vid` va por la URL del plugin y aquí se concatenaba CRUDO en `page_url`, en el embed y
    en la ruta del `xhr`. Con `?action=xxx_play&src=ep&vid=../../otra/cosa` se pedía una página
    distinta de la que se cree, y `url_web()`/`embed_de()` (que sí validan) quedaban inconsistentes
    con el resolve. Se pasa por `_vid_seguro()`, que es el mismo filtro que usan: alfanumérico,
    guion y guion bajo, hasta 64. Un id raro se queda sin vídeo, con un motivo, en vez de pedir
    una URL que no es.
    """
    vid = _vid_seguro(video_id)
    if not vid:
        return "", "Sin identificador"
    page_url = RAIZ_EP + "video-" + vid + "/x/"
    pagina = http_get(page_url, timeout=timeout, cache=False, accept=ACCEPT_HTML,
                      cookies=COOKIE_EP)
    m = _RE_HASH.search(pagina or "")
    if not m:
        # Segundo camino: el embed trae el mismo hash. Es la red de seguridad por si la web
        # vuelve a pedir la edad antes de enseñar la página.
        pagina = http_get(EMBED_EP % vid, timeout=timeout, cache=False, accept=ACCEPT_HTML,
                          cookies=COOKIE_EP)
        m = _RE_HASH.search(pagina or "")
    if not m:
        return "", "Eporner no ha devuelto el reproductor. Puede ser que la web esté pidiendo la edad."
    h = calc_hash(m.group(1))
    if not h:
        return "", "Eporner ha devuelto un reproductor que no se entiende."
    xhr = ("{0}xhr/video/{1}?hash={2}&device=generic&domain=www.eporner.com&fallback=false"
           .format(RAIZ_EP, vid, h))
    texto = http_get(xhr, timeout=timeout, cache=False, referer=page_url, cookies=COOKIE_EP)
    data = _json(texto)
    if not isinstance(data, dict):
        return "", "Eporner no ha contestado al reproductor."
    if data.get("available") is False:
        return "", MotivoPermanente(
            "Eporner dice que este vídeo no está disponible: {0}".format(
                data.get("message") or "sin motivo"))
    sources = data.get("sources")
    mp4 = (sources or {}).get("mp4") if isinstance(sources, dict) else None
    if not isinstance(mp4, dict) or not mp4:
        return "", MotivoPermanente("Este vídeo no tiene MP4 disponible.")
    cands = []
    for clave, entrada in mp4.items():
        if not isinstance(entrada, dict):
            continue
        src = entrada.get("src") or ""
        if not src.startswith("http") or src.endswith("na.mp4"):
            continue
        cands.append((_altura_de_eporner(clave, entrada), src))
    url = pick_quality(cands, quality)
    return (url, "") if url else ("", "No queda ninguna fuente de vídeo en este vídeo.")


# ------------------------------------------------------------------ RedTube
def search_redtube(query="", page=1, category="", ordering="", period="", timeout=15):
    """API oficial de RedTube (sin clave). 20 por página, fijo.

    En la API de RedTube `ordering` y `period` solo tienen efecto si la petición
    incluye término de búsqueda en `search`; en listados por categoría la API ignora el orden.

    Mapeo de ordenación: latest→newest, most-popular→mostviewed,
    top-weekly→mostviewed+weekly, top-monthly→mostviewed+monthly.

    Lo que sí filtra siempre es `search`, `category` (por NOMBRE, no por id) y `tags`.
    """
    params = {"data": "redtube.Videos.searchVideos", "output": "json",
              "search": query or "", "page": max(1, _int(page, 1))}
    if ordering:
        params["ordering"] = ordering
    if period:
        params["period"] = period
    if category:
        params["category"] = category
    url = RT_API + "?" + urllib.parse.urlencode(params, quote_via=urllib.parse.quote_plus)
    data = _json(http_get(url, timeout=timeout))
    if not isinstance(data, dict):
        return None
    # Un error de la API de RedTube llega como HTTP 200 con un dict sin `videos` (ej. code 1001).
    # Se devuelve None para que la capa superior distinga error de servidor de una búsqueda vacía.
    videos = data.get("videos")
    if not isinstance(videos, list):
        return None
    return videos


def cats_redtube(timeout=15):
    """Las 111 categorías oficiales.

    OJO: el método lleva la C mayúscula. En minúscula responde {"code":1001,
    "message":"Such method doesn't exist!"}, que es lo que hace pensar que no existen.
    """
    url = (RT_API + "?" + urllib.parse.urlencode(
        {"data": "redtube.Categories.getCategoriesList", "output": "json"},
        quote_via=urllib.parse.quote_plus))
    data = _json(http_get(url, timeout=timeout))
    if not isinstance(data, dict):
        return []
    salida = []
    for c in data.get("categories") or []:
        if isinstance(c, dict) and c.get("category"):
            salida.append(str(c["category"]).strip())
    return [c for c in salida if c]


def resolve_redtube(video_id, quality="max", timeout=15):
    """Embed oficial -> /media/mp4?s= -> mejor mp4 firmado. Devuelve (url, motivo).

    `_vid_seguro()` y no `str().strip()`: el id va por la URL del plugin y aquí se concatena en el
    embed. Ver la nota larga en `resolve_eporner()`.
    """
    vid = _vid_seguro(video_id)
    if not vid:
        return "", "Sin identificador"
    embed_url = EMBED_RT % vid
    pagina = http_get(embed_url, timeout=timeout, cache=False, accept=ACCEPT_HTML)
    m = re.search(r'videoUrl"\s*:\s*"(/media/mp4\?s=[^"\']+)"', (pagina or "").replace("\\/", "/"))
    if not m:
        return "", "RedTube no ha devuelto el reproductor."
    texto = http_get(RAIZ_RT + m.group(1).lstrip("/"), timeout=timeout, cache=False,
                     referer=embed_url)
    items = _json(texto)
    cands = []
    if isinstance(items, list):
        for it in items:
            if not isinstance(it, dict):
                continue
            src = it.get("videoUrl") or ""
            if not src.startswith("http"):
                continue
            # `quality` viene como texto ("480"), no como número.
            cands.append((_int(it.get("height") or it.get("quality")), src))
    url = pick_quality(cands, quality)
    return (url, "") if url else ("", MotivoPermanente("RedTube no tiene ninguna fuente para este vídeo."))


# ----------------------------------------------------------------- Pornhub
def search_pornhub(query="", page=1, timeout=15):
    """Endpoint de búsqueda para webmasters. 30 por página, fijo.

    Solo `search` y `page` sirven: `segment`, `categories`, `order`, `thumbsize` y `per_page` se
    ignoran en silencio. Y `page=0` da 404, de ahí el max(1, ...). Sin caché: son 130-170 KB por
    página y no tiene sentido guardarlos en memoria.
    """
    params = {"search": query or "", "page": max(1, _int(page, 1))}
    url = PH_API + "?" + urllib.parse.urlencode(params, quote_via=urllib.parse.quote_plus)
    # Reintento ante límites de tasa temporales para evitar fallos intermitentes de red.
    for intento in (1, 2):
        data = _json(http_get(url, timeout=timeout, cache=False))
        if isinstance(data, dict):
            videos = data.get("videos")
            if isinstance(videos, list):
                return videos
        elif isinstance(data, list):
            return data
        if intento == 1:
            time.sleep(RETRY_ESPERA)
    return None


def resolve_pornhub(viewkey, quality="max", timeout=15):
    """Embed oficial -> get_media -> mejor mp4 firmado. Devuelve (url, motivo).

    El host del get_media cambia por región (www, es, de...), así que se localiza por camino y
    no por host clavado. Si la página no trae el get_media, se aprovechan las fuentes que ya
    vienen escritas dentro del embed.

    `_vid_seguro()` y no `str().strip()`: el viewkey va por la URL del plugin y aquí se concatena
    en el embed. Ver la nota larga en `resolve_eporner()`.
    """
    vid = _vid_seguro(viewkey)
    if not vid:
        return "", "Sin identificador"
    embed_url = EMBED_PH % vid
    pagina = (http_get(embed_url, timeout=timeout, cache=False, accept=ACCEPT_HTML)
              or "").replace("\\/", "/")
    if not pagina:
        return "", "Pornhub no ha devuelto el reproductor."
    items = None
    m = _RE_GETMEDIA.search(pagina)
    if m:
        maybe = _json(http_get(m.group(1), timeout=timeout, cache=False, referer=embed_url))
        if isinstance(maybe, list):
            items = maybe
    if items is None:
        return _pornhub_inline(pagina, quality)
    cands = []
    for it in items:
        if not isinstance(it, dict):
            continue
        src = it.get("videoUrl") or ""
        if not src.startswith("http"):
            continue
        cands.append((_int(it.get("height") or it.get("quality")), src))
    url = pick_quality(cands, quality)
    return (url, "") if url else ("", MotivoPermanente("Pornhub no tiene ninguna fuente para este vídeo."))


def _pornhub_inline(pagina, quality):
    """Respaldo: las fuentes que el propio embed trae dentro, sin pasar por get_media.

    Las URLs firmadas llevan siempre query (validfrom, hash...), así que hay que mirar la
    extensión antes del '?', o el filtro no encuentra nunca nada.
    """
    cands = []
    for url in _RE_VIDEOURL.findall(pagina):
        if "/video/get_media" in url:
            continue
        ruta = url.split("?", 1)[0]
        if not (ruta.endswith(".mp4") or ".mp4/" in ruta or ruta.endswith(".m3u8")):
            continue
        cands.append((0, url))
    elegido = pick_quality(cands, quality)
    return (elegido, "") if elegido else ("", MotivoPermanente("Pornhub no tiene ninguna fuente para este vídeo."))


# Órdenes de RedTube mapeados a los parámetros esperados por su API webmasters.
ORDENES_RT_API = {"latest": ("newest", ""),
                  "most-popular": ("mostviewed", ""),
                  "top-weekly": ("mostviewed", "weekly"),
                  "top-monthly": ("mostviewed", "monthly")}


# ------------------------------------------------------------------ fachada
def buscar(src, query="", page=1, order="latest", per_page=PAGE_SIZE_EP,
           thumbsize="big", gay=0, category="", timeout=15):
    """Listado unificado por plataforma. Devuelve (lista_normalizada, error_o_None).

    `src` es 'ep', 'rt' o 'ph'. La lista viene vacía y el error vacío cuando no hay resultados;
    el error solo se llena cuando la petición falló de verdad.
    """
    try:
        if src == "ep":
            data = search_eporner(query=query, page=page, order=order, per_page=per_page,
                                  thumbsize=thumbsize, gay=gay, timeout=timeout)
            if not isinstance(data, dict):
                return [], "Eporner no ha contestado. Revisa la conexión."
            # Mismo caso que RedTube: {"error":"Too many requests"} servido como HTTP 200 daba
            # "sin resultados". Un rechazo de la plataforma no es una busqueda esteril.
            videos = data.get("videos")
            if not isinstance(videos, list):
                return [], "Eporner no ha contestado. Revisa la conexión."
            return [n for n in (norm_eporner(v) for v in videos) if n], ""
        if src == "rt":
            ordering, period = ORDENES_RT_API.get(order, ("newest", ""))
            items = search_redtube(query=query, page=page, category=category,
                                   ordering=ordering, period=period, timeout=timeout)
            if items is None:
                return [], "RedTube no ha contestado. Revisa la conexión."
            return [n for n in (norm_redtube(v) for v in items) if n], ""
        if src == "ph":
            items = search_pornhub(query=query, page=page, timeout=timeout)
            if items is None:
                return [], "Pornhub no ha contestado. Revisa la conexión."
            return [n for n in (norm_pornhub(v) for v in items) if n], ""
    except Exception as exc:
        # Con su clase, porque un fallo de programacion en un normalizador se reportaba como
        # "revisa la conexion" con la conexion perfectamente buena. Ya paso una vez con los
        # `nan`, y por eso el except es ancho pero NO mudo.
        _aviso("buscar() fallo con {0}: {1}".format(type(exc).__name__, exc))
        return [], "Algo ha fallado al pedir la lista. Prueba otra vez."
    return [], "Plataforma desconocida."


def resolver(src, video_id, quality="max", timeout=15, reintentar=True):
    """Resuelve el MP4 de un vídeo. Devuelve (url, motivo).

    Reintenta una vez cuando el primer intento falla: la URL firmada va atada a la IP y al
    reloj, así que un fallo puntual por TTL es lo más probable que haya.
    """
    intentos = 2 if reintentar else 1
    motivo = ""
    for _ in range(intentos):
        if src == "ep":
            url, motivo = resolve_eporner(video_id, quality, timeout)
        elif src == "rt":
            url, motivo = resolve_redtube(video_id, quality, timeout)
        elif src == "ph":
            url, motivo = resolve_pornhub(video_id, quality, timeout)
        else:
            return "", "No se de qué plataforma es este vídeo."
        if url:
            return url, ""
        # Reintentar solo vale con un fallo de red. Los `resolve_*` marcan los "esto no lo
        # arregla esperar" (el vídeo no está, o no hay fuente) con `MotivoPermanente`; el resto
        # (HTTP, timeout, HTML que no se entiende) se reintenta una vez.
        if isinstance(motivo, MotivoPermanente):
            break
    return "", motivo or "No se ha podido resolver el vídeo."


def referer_de(src):
    """El Referer que hay que mandar al CDN. No es el mismo en las tres plataformas:
    RedTube da 410 sin el, Pornhub 404, y Eporner da igual. En RedTube es el del embed."""
    if src == "rt":
        return RAIZ_RT
    if src == "ph":
        return RAIZ_PH
    return RAIZ_EP


def _host_de(url):
    """(partes, host) si la URL es una página de una de las tres plataformas, o (None, "").
    El `hostname` es el host real: `https://eporner.com@evil.example/` NO es eporner.com."""
    try:
        partes = urllib.parse.urlsplit(url)
    except ValueError:
        return None, ""
    if partes.scheme not in ("http", "https") or not partes.netloc:
        return None, ""
    if partes.username or partes.password:
        return None, ""
    host = (partes.hostname or "").lower()
    if not any(host == d or host.endswith("." + d) for d in HOSTS_WEB):
        return None, ""
    return partes, host


# Solo los dominios de las tres plataformas. Sin lista blanca, "Abrir en la web" era una
# redireccion abierta: el diálogo dice "Se va a abrir... Eporner" y detrás puede haber
# https://evil.example/ o la IP de la red local. Los subdominios regionales valen
# (es.pornhub.com, de.pornhub.com...).
HOSTS_WEB = ("eporner.com", "redtube.com", "pornhub.com")

# Los ids de las tres plataformas son alfanumericos. El `vid` viaja por la URL del plugin y se
# concatina tal cual en el embed, donde un \r\n, una comilla o una barra vertical rompen el
# builtin StartAndroidActivity de Android y meten saltos de linea en el dialogo de confirmacion.
_RE_ID_SEGURO = re.compile(r"\A[A-Za-z0-9_-]{1,64}\Z")


def _vid_seguro(vid):
    v = str(vid or "").strip()
    return v if _RE_ID_SEGURO.match(v) else ""


# Caracteres que se rechazan en la URL de "Abrir en la web".
#
# Caracteres de control, puntuación conflictiva en intents y separadores de línea
# que pueden romper la invocación del navegador del sistema en Android.
#
# OJO CON LO QUE NO VA AQUI, que es lo que hace el primer intento de ampliarlo y falla:
#   · `?`, `&` y `=` son IMPRESCINDIBLES: `pornhub.com/viewvideo.php?viewkey=abc123` es una URL
#     real de la plataforma, y sin ellos se cae al embed.
#   · `%` tambien: los CDNs de RedTube y Pornhub devuelven rutas con `%20` y `%28`.
#   · `#` es legal en una URL y no aporta nada maliciouso aqui.
# Y los tres entran en un filtro de caracteres sin querer, y el test que comprueba las URLs
# reales es el que lo detecta. Por eso ese test existe.
#
# En Android el destino es `StartAndroidActivity("", ..., "", "{url}")`; rechazar
# caracteres conflictivos previene rupturas de intent o inyecciones de parámetros.
PROHIBIDOS_EN_URL = "\r\n\t\v\f\u2028\u2029\x00 \"[]|\\`';${}<>"
# Secuencias en porcentaje que se decodifican a un caracter de control aguas arriba. Se miran a
# parte porque `%` si tiene que poder pasar (los CDNs lo usan), pero estas tres no: `%0d` y `%0a`
# son un salto de linea y `%00` el final de cadena.
PROHIBIDOS_EN_PORCENTAJE = ("%0d", "%0a", "%00", "%09", "%0b", "%0c", "%08", "%1b")


def _url_limpia(p):
    """True si la URL no lleva nada que se haya de filtrar."""
    if any(c in p for c in PROHIBIDOS_EN_URL):
        return False
    bajo = p.lower()
    return not any(seq in bajo for seq in PROHIBIDOS_EN_PORCENTAJE)


def url_web(src, vid, pagina=""):
    """URL para el botón "Abrir en la web" del menú contextual.

    Se prefiere la **página real** del vídeo, que es la que dan las tres APIs en su campo
    `page`: tiene el título, los comentarios y el reproductor de la propia web. Si no la
    tenemos (un favorito guardado antes de existir este campo, o una lista sin `page`), se cae al
    embed, que también se reproduce y va directo al vídeo.

    La página se valida antes de abrirse nada, porque el valor llega por la URL del plugin,
    o sea de lo que el usuario escriba en un enlace: solo `http`/`https`, sin usuario antes de
    la arroba, host de las tres plataformas, y sin espacios, saltos de línea (en crudo o en
    porcentaje) ni los caracteres que rompen el builtin de Android: son los de
    `PROHIBIDOS_EN_URL` y `PROHIBIDOS_EN_PORCENTAJE`, que se miran aparte porque `%`
    tiene que poder pasar (los CDNs de RedTube y Pornhub devuelven `%20` y `%28`) y
    porque `?`, `&` y `=` son parte de las URLs reales de Pornhub. Sin identificador, o
    con un identificativo que no sea alfanumérico, devuelve "".
    """
    vid = _vid_seguro(vid)
    if not vid:
        return ""
    p = str(pagina or "").strip()
    if p and _url_limpia(p):
        if _host_de(p)[0] is not None:
            return p
    return embed_de(src, vid)


def embed_de(src, video_id):
    """URL del embed de un vídeo. La usa `url_web()` como respaldo cuando no hay página real,
    y el resto del addon usa la URL directo de la API, que es mejor."""
    vid = _vid_seguro(video_id)
    if not vid:
        return ""
    if src == "rt":
        return EMBED_RT % vid
    if src == "ph":
        return EMBED_PH % vid
    return EMBED_EP % vid


NOMBRES = {"ep": "Eporner", "rt": "RedTube", "ph": "Pornhub"}
PREFIJOS = {"ep": "", "rt": "[RedTube] ", "ph": "[Pornhub] "}