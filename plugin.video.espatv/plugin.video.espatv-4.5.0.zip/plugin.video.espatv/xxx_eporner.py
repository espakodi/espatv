# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Sección X (+18): Eporner, RedTube y Pornhub dentro de EspaTV.

UI y almacenamiento. La capa de red reside en `xxx_api.py`, desacoplada de Kodi.

Detalles de diseño e integración:

- Almacenamiento propio (`xxx_settings.json`, `xxx_favs.json`, `xxx_hist.json`): aislado del
  historial y favoritos globales de EspaTV para evitar colisiones de metadatos y búsquedas cruzadas.
- Validación secuencial de acceso: comprobación del PIN configurado y confirmación explícita de +18.
- Sin `setContent`: con contenido neutro el skin muestra la carátula o icono en las filas;
  evita la marca de visto de Estuary para ver la carátula en el propio botón.
"""
import datetime
import hashlib
import hmac
import json
import os
import re
import secrets
import sys
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

import ui_utils
import xxx_api as api
from _user_agents import ua_desktop_pipe_encoded

NOMBRE = "Sección X"
URL_CANAL = "https://t.me/espadaily"
PIN_INICIAL = "9126"
MAX_FALLOS = 3

FICH_AJUSTES = "xxx_settings.json"
FICH_FAVS = "xxx_favs.json"
FICH_HIST = "xxx_hist.json"
MAX_HIST = 100

# El PIN de la sesión y los intentos fallidos se gestionan en memoria (propiedades de ventana).
PROP_UNLOCK = "espatv.xxx_unlock"
PROP_FALLOS = "espatv.xxx_fallos"

# Versión del formato de `xxx_settings.json` para gestionar migraciones de ajustes de versiones previas.
VER_AJUSTES = 2

_AJUSTES = {
    "per_page": 20,
    "thumbsize": "big",
    "order": "latest",
    "gay": 0,
    "quality": "max",
    "timeout": 15,
    "adult_confirm": True,
    "adult_ok": False,
    # Por defecto, una vez por sesión de Kodi (en Ajustes: "al entrar" o "nunca").
    "pin_on": "sesion",
    "v_ajustes": VER_AJUSTES,
    "vista": "wide",
    # Registro de actividad en el log de Kodi.
    "log_on": True,
    "pin_hash": "",
    "pin_salt": "",
    # True si el usuario ha configurado un PIN personalizado en lugar del inicial.
    "pin_propio": False,
}

# Los 9 iconos de dentro de la sección (buscar, categorías, favoritos, historial, ajustes,
# siguiente, y uno por plataforma). Sus nombres tienen que aparecer aquí literal:
# tools/generar_web_iconos.py --check cuenta como "sin usar" los iconos que solo se citan en
# tools/, y falla si pasan del 10 %.
ICO_BUSCAR = "xxx_buscar.png"
ICO_CATEGORIAS = "xxx_categorias.png"
ICO_FAVORITOS = "xxx_favoritos.png"
ICO_HISTORIAL = "xxx_historial.png"
ICO_AJUSTES = "xxx_ajustes.png"
ICO_SIGUIENTE = "xxx_siguiente.png"
ICO_EPORNER = "xxx_eporner.png"
ICO_REDTUBE = "xxx_redtube.png"
ICO_PORNHUB = "xxx_pornhub.png"

# Son búsquedas: la API no tiene endpoint de categorías nativo.
CAT_EPORNER = (
    "Amateur", "Anal", "Asian", "BBW", "BDSM", "Big Tits", "Blonde", "Blowjob",
    "Brunette", "Compilation", "Creampie", "Cumshot", "Ebony", "Fetish", "Gangbang",
    "Hardcore", "Hentai", "Interracial", "Japanese", "Latina", "Lesbian", "Milf",
    "Orgy", "POV", "Public", "Teen", "Threesome", "Vintage",
)

# En Pornhub no hay endpoint de categorías: estos botones son búsquedas predefinidas.
BUSQUEDAS_PH = (
    ("Español", "spanish"),
    ("Latina", "latina"),
    ("Amateur", "amateur"),
    ("Joven", "teen"),
    ("Madre de familia", "milf"),
    ("Anal", "anal"),
    ("Tetas grandes", "big tits"),
    ("Masturbación", "blowjob"),
    ("Lesbian", "lesbian"),
    ("Threesome", "threesome"),
    ("Hentai", "hentai"),
    ("Japonés", "japanese"),
    ("Moreno", "ebony"),
    ("Maduro", "mature"),
    ("Creampie", "creampie"),
    ("POV", "pov"),
)

# Categorías estándar de RedTube (la API completa de 111 está disponible en api.cats_redtube()).
CATS_RT = (
    "Amateur", "Anal", "Asian", "Big Ass", "Big Dick", "Big Tits", "Blonde", "Blowjob",
    "Brunette", "Compilation", "Creampie", "Cumshot", "Ebony", "Fetish", "Gangbang",
    "Group", "Hardcore", "Hentai", "Interracial", "Japanese", "Latina", "Lesbian",
    "Mature", "MILF", "Orgy", "POV", "Redhead", "Teens", "Threesome", "Vintage",
)

# Mapeo de ordenación de RedTube hacia los parámetros de su API.
# La API de RedTube aplica ordenación y periodos cuando la consulta incluye
# un término de búsqueda; se envían para mantener consistencia en la navegación.
ORDENES_RT = (("latest", "Últimos", "newest", None),
              ("most-popular", "Más vistos", "mostviewed", None),
              ("top-weekly", "Top semanal", "mostviewed", "weekly"),
              ("top-monthly", "Top mensual", "mostviewed", "monthly"))

# Categorías de RedTube con temática homosexual en su catálogo.
# El parámetro de contenido gay de ajustes aplica a Eporner; en RedTube se muestra
# un aviso informativo al acceder.
CATS_GAY_RT = ("Bisexual Male", "Bisexual", "Transgender", "Shemale",
               "Solo Male", "Muscle")

ORDENES = (("latest", "Últimos"),
           ("top-weekly", "Top semanal"),
           ("top-monthly", "Top mensual"),
           ("most-popular", "Más vistos"))

# Rangos de configuración de paginación y tiempo de espera
PAGINAS = tuple(range(10, 31))
MINIATURAS = (("small", "Pequeñas"), ("medium", "Medianas"), ("big", "Grandes"))
CALIDADES = (("max", "Máxima"), ("ahorro", "Ahorro de datos"))
TIEMPOS = tuple(range(5, 31))
MODOS_PIN = (("entrar", "Al entrar en la sección"),
             ("sesion", "Una vez por sesión (empieza aquí)"),
             ("nunca", "Nunca"))
# Opciones del filtro: en Eporner gay=0 excluye contenido gay y gay=2 selecciona exclusivamente
# contenido gay. En Pornhub el filtrado se realiza por el campo segment de cada vídeo.
GAY_OPCIONES = ((0, "No (ocultar el contenido gay)"), (2, "Sí, solo contenido gay"))
# Vista de los menús de la sección (carpetas): configurable entre vista ancha (55) o la del skin.
VISTAS = (("wide", "WideList (icono grande)"), ("skin", "La que trae el skin"))
# La 55 de los skins de Kodi por defecto (Estuary y compañía): la de lista ancha, con icono a
# la izquierda y el texto a la derecha. Si el skin del usuario no la tiene, Kodi cae en la suya
# sin romperse.
VIEW_WIDE = 55
ALARMA_VISTA = "espatv_xxx_vista"


def _log(msg, level=None):
    # Ni títulos ni URLs firmadas en el log: solo el motivo de un fallo.
    #
    # Respeta el ajuste 'Avisos en el log de Kodi' (log_on) mediante api._log_puesto()
    # para sincronizar el filtrado de trazas con la capa de API.
    if not api._log_puesto():
        return
    xbmc.log("[EspaTV-XXX] {0}".format(msg), xbmc.LOGDEBUG if level is None else level)


def _notifica(msg, heading=NOMBRE):
    try:
        xbmcgui.Dialog().notification(heading, msg, xbmcgui.NOTIFICATION_INFO, 4000)
    except Exception:
        pass


def _h():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1


def _u(**kw):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kw)


def _ico(nombre):
    return ui_utils.media_icon(nombre) or nombre


def _cierra(handle, succeeded=True):
    """`endOfDirectory` SOLO si hay un handle de verdad.

    Estas acciones llegan de dos maneras: desde un listado (handle >= 0, y entonces cerrar el
    directorio es lo correcto) y desde el menú contextual, que las lanza con `RunPlugin` y por
    tanto con handle -1. Ahí `endOfDirectory(-1)` no hace nada útil y deja un error en el log de
    Kodi.
    """
    try:
        h = int(handle)
    except (TypeError, ValueError):
        return
    if h < 0:
        return
    try:
        xbmcplugin.endOfDirectory(h, succeeded=succeeded)
    except Exception:
        pass


def _no_resuelto(handle):
    """Indica a Kodi que la reproducción no ha salido, tal como lo espera.

    Una fila de esta sección es `IsPlayable`, así que Kodi la abre para reproducir con un
    handle válido. Lo que espera cuando la resolución falla es
    `setResolvedUrl(h, False, ListItem())`: con eso sabe que no hay nada que reproducir y
    vuelve a la lista.

    Con handle -1 (la acción escrita a mano en la URL, o llegada de un `RunPlugin`)
    `setResolvedUrl` rechaza el handle («Invalid handle -1»), así que ahí no se hace nada:
    no hay a quién decírselo. Es el mismo criterio que `_cierra()`.
    """
    try:
        h = int(handle)
    except (TypeError, ValueError):
        return
    if h < 0:
        return
    try:
        xbmcplugin.setResolvedUrl(h, False, listitem=xbmcgui.ListItem())
    except Exception:
        pass


# ------------------------------------------------------------- almacenamiento
def _cfg():
    """Ajustes con los valores por defecto rellenados. Tolerante a JSON roto o no-dict.

    MIGRACIÓN DE `pin_on` (2026-10-04). El ajuste se guardaba en cuanto se entraba una vez, así
    que en toda instalación existente hay un `"pin_on": "entrar"` escrito en disco que sigue
    mandando sobre el valor por defecto del código: cambiar el `_AJUSTES` no arregla nada por
    sí solo. Aquí se distingue "guardado por alguien" de "grabado por el valor de entonces":

    · `_v_ajustes` es un número que se graba con cada guardado. Si el fichero guardado NO lo
      tiene, es un fichero anterior a esta migración, y su `pin_on` se descarta: se usa el
      valor por defecto actual ("sesion", una vez por sesión).
    · Un `pin_on` que alguien haya cambiado DESPUÉS de esta migración se respeta siempre,
      porque su fichero ya lleva `_v_ajustes`.

    Es una migración de una sola vez: al guardar cualquier vez, el fichero queda versionado y
    a partir de ahí manda lo que el usuario elija.
    """
    datos = ui_utils.load_json(FICH_AJUSTES, {})
    if not isinstance(datos, dict):
        datos = {}
    out = dict(_AJUSTES)
    for k, v in _AJUSTES.items():
        if k in datos:
            out[k] = datos[k]

    # Sanea las claves del PIN para evitar excepciones de tipo si el archivo fue modificado.
    for _k in ("pin_hash", "pin_salt"):
        _v = out.get(_k)
        if not (isinstance(_v, str) and _v.isascii()):
            out[_k] = ""
    # Saneamiento de v_ajustes y migración de pin_on si procede de versiones anteriores a VER_AJUSTES.
    _va = datos.get("v_ajustes")
    _va_entero = isinstance(_va, int) and not isinstance(_va, bool) and _va >= 0
    if not _va_entero:
        out["v_ajustes"] = VER_AJUSTES
    if (not _va_entero or _va < VER_AJUSTES) and "pin_on" in datos:
        out["pin_on"] = _AJUSTES["pin_on"]
    # Valores imposibles: cada botón tiene su lista, y aquí se recorta a lo que existe.
    if out["per_page"] not in PAGINAS:
        out["per_page"] = _AJUSTES["per_page"]
    if out["thumbsize"] not in [k for k, _ in MINIATURAS]:
        out["thumbsize"] = _AJUSTES["thumbsize"]
    if out["order"] not in [k for k, _ in ORDENES]:
        out["order"] = _AJUSTES["order"]
    if out["gay"] not in [k for k, _ in GAY_OPCIONES]:
        out["gay"] = _AJUSTES["gay"]
    if out["quality"] not in [k for k, _ in CALIDADES]:
        out["quality"] = _AJUSTES["quality"]
    if out["timeout"] not in TIEMPOS:
        out["timeout"] = _AJUSTES["timeout"]
    if out["pin_on"] not in [k for k, _ in MODOS_PIN]:
        out["pin_on"] = _AJUSTES["pin_on"]
    if out["vista"] not in [k for k, _ in VISTAS]:
        out["vista"] = _AJUSTES["vista"]
    out["per_page"] = int(out["per_page"])
    out["timeout"] = int(out["timeout"])
    out["gay"] = int(out["gay"])
    return out


def _fallos():
    """Intentos fallidos en ESTA sesión. Cero si la propiedad no está o está corrupta."""
    try:
        return int(xbmcgui.Window(10000).getProperty(PROP_FALLOS) or 0)
    except Exception:
        return 0


def _suma_fallo():
    n = _fallos() + 1
    try:
        xbmcgui.Window(10000).setProperty(PROP_FALLOS, str(n))
    except Exception:
        pass
    return n


def _limpia_fallos():
    try:
        xbmcgui.Window(10000).setProperty(PROP_FALLOS, "0")
    except Exception:
        pass


def _guardar_cfg(cfg):
    """Guarda los ajustes y devuelve el resultado booleano de la escritura."""
    return ui_utils.save_json(FICH_AJUSTES, cfg)


def _ruta_lista(fich):
    """La ruta absoluta de un fichero de la sección, o "" si no se puede sacar."""
    try:
        ruta = ui_utils.get_path(fich)
        return ruta if isinstance(ruta, str) else ""
    except Exception:
        return ""


def _carga_lista(fich):
    """El JSON del fichero, o `[]`. Si está roto se aparta, no se pisa.

    `ui_utils.load_json()` devuelve el valor por defecto cuando el JSON no parsea, así que con
    el fichero roto `_leer_lista()` devolvía `[]` y el siguiente guardado escribía la lista
    vacía encima: **todos los favoritos o el historial entero, perdidos sin aviso**. Se aparta
    como `<fichero>.corrupt-<hora>`, que es lo que hace `fuentes_store._lee()` con el almacén
    de servidores, y así queda para que se pueda mirar qué había dentro.

    Un `OSError` **no** es corrupión, y esta es la parte fina: en Windows es lo normal cuando
    otro proceso está reemplazando el fichero en ese instante, y también lo que hace un antivirus
    que lo abre. Apostar por «está roto» renombraba el fichero BUENO y hacía que el guardado
    siguiente escribiera la lista vacía encima. Es la misma distinción que hace
    `fuentes_store._lee()`, y allí está explicada con más detalle.
    """
    ruta = _ruta_lista(fich)
    if not ruta:
        return ui_utils.load_json(fich, [])
    try:
        with open(ruta, "r", encoding="utf-8") as f:
            return json.load(f)
    except FileNotFoundError:
        return []
    except ValueError as e:
        _log("{0} ilegible ({1}), se aparta".format(fich, e), xbmc.LOGWARNING)
        try:
            os.replace(ruta, "{0}.corrupt-{1}".format(ruta, int(time.time())))
        except OSError:
            pass
        _notifica("El fichero {0} estaba dañado: se ha apartado y se empieza de "
                  "cero.".format(fich))
        return []
    except OSError:
        return ui_utils.load_json(fich, [])


def _leer_lista(fich, tope=0):
    """Lee favoritos o historial y deja solo dicts con id, con los tipos que espera el resto.

    Los dos ficheros son MERGEABLES: entran importando un .zip de otra máquina o de otra
    versión del addon, y ahí los tipos pueden ser lo que quiera. Con `title` entero,
    `"\n".join` reventaba con TypeError, y como `favoritos()` e `historial()` pintan las filas
    sin `try`, el directorio se quedaba sin cerrar: pantalla colgada. Con `views` a `inf` (JSON
    lo parsea) reventaba el `_numero`/`formatea_vistas`. Aquí se normaliza una vez.

    Si el JSON está roto, el fichero se aparta en vez de pisarse. Ver
    `_carga_lista()`.
    """
    datos = _carga_lista(fich)
    if not isinstance(datos, list):
        return []
    salida = []
    for d in datos:
        if not isinstance(d, dict) or not d.get("id"):
            continue
        d = dict(d)
        d["id"] = str(d.get("id") or "")
        d["src"] = str(d.get("src") or "")
        d["title"] = _limpiar_emojis(d.get("title") or d["id"]) or str(d["id"])
        d["thumb"] = api.fix_thumb(d.get("thumb"))
        # `length` y `added` solo se guardan si son cadenas. Con `str(...)` a secas, un dict en
        # `length` salia como "Duracion: {'a': 1}" en la etiqueta de la fila.
        d["length"] = d.get("length") if isinstance(d.get("length"), str) else ""
        d["added"] = d.get("added") if isinstance(d.get("added"), str) else ""
        # `page` viaja en las filas para "Abrir en la web": si un JSON importado trae una lista
        # o un número, `_u()` lo urlencodearía raro. Se sanea aquí, como `length` y `added`.
        d["page"] = d.get("page") if isinstance(d.get("page"), str) else ""
        d["views"] = _numero(d.get("views"))
        d["rate"] = _numero(d.get("rate"))
        d["length_sec"] = _numero(d.get("length_sec"))
        if d.get("keywords") and not isinstance(d.get("keywords"), list):
            d["keywords"] = []
        salida.append(d)
    return salida[:tope] if tope else salida


def _guardar_lista(fich, items):
    """Guarda y devuelve si se escribió correctamente."""
    return ui_utils.save_json(fich, items)


def _clave(src, vid):
    return "{0}:{1}".format(src, vid)


def _claves_favoritos():
    """Claves (src:id) guardadas en favoritos para verificación rápida en memoria."""
    return set(_clave(f.get("src", ""), f.get("id", ""))
               for f in _leer_lista(FICH_FAVS) if f.get("id"))


def _pagina(valor):
    """Page de la URL a entero, sin reventar si viene algo raro: si no, el directorio se
    queda sin cerrar y la pantalla queda colgada."""
    try:
        return max(1, int(valor))
    except (TypeError, ValueError):
        return 1


# --------------------------------------------------------------------- PIN
def _hash(pin, salt):
    return hashlib.sha256((str(pin) + str(salt)).encode("utf-8")).hexdigest()


def _es_pin_publico(cfg):
    """True si el PIN que hay ahora mismo sigue siendo el del canal de Telegram."""
    return not bool(cfg.get("pin_propio"))


def _pin_correcto(cfg, tecleado):
    """Comprueba el PIN tecleado contra el configurado o el inicial."""
    tecleado = str(tecleado).strip()
    # `hmac.compare_digest()` con dos `str` lanza TypeError si alguno contiene caracteres
    # no-ASCII. Se rechaza directamente cualquier valor con caracteres no-ASCII para evitar fallos.
    if not tecleado.isascii():
        return False
    if _es_pin_publico(cfg):
        return hmac.compare_digest(tecleado, PIN_INICIAL)
    if not cfg.get("pin_hash"):
        # Si pin_propio está activo pero falta el hash, se recurre por seguridad al PIN inicial.
        return hmac.compare_digest(tecleado, PIN_INICIAL)
    return hmac.compare_digest(_hash(tecleado, cfg.get("pin_salt", "")),
                               cfg.get("pin_hash", ""))


def _pin_aceptable(pin):
    """True si `pin` está compuesto exactamente por 4 dígitos ASCII (0-9).

    Descarta dígitos Unicode de ancho completo u otros alfabetos numéricos
    para asegurar coherencia con la verificación del hash en `_pin_correcto()`.
    """
    return isinstance(pin, str) and len(pin) == 4 and pin.isascii() and pin.isdigit()


def _aviso_pin_publico(cfg):
    """El texto del recordatorio, o "" si el PIN ya es del usuario."""
    if not _es_pin_publico(cfg):
        return ""
    return ("El PIN de esta sección sigue siendo el público del canal de Telegram "
            "[B]t.me/espadaily[/B]. Para cambiarlo por uno propio, ve a "
            "[B]Ajustes · PIN de la sección[/B].")




def _pedir_pin(cfg):
    """Diálogo del PIN. True = puede entrar.

    La explicación se enseña en `_explica_el_pin()`, una vez por sesión, porque
    `Dialog.select()` no admite texto explicativo.

    Los intentos van en el título del `select` y se recalculan en cada vuelta: es el diálogo
    que se queda en pantalla para decidir si seguir intentando.

    Sin etiquetas de color en el título a propósito: `Dialog::select()` pinta la cabecera
    como etiqueta de control y no está claro que interprete el `[COLOR]`. Un «último
    intento» en texto plano se lee seguro; uno con la etiqueta mal puesta, no.
    """
    _explica_el_pin()
    opciones = ["Escribir el PIN", "No lo sé, abrir el canal", "Salir"]
    while True:
        intentos = max(0, MAX_FALLOS - _fallos())
        if intentos > 1:
            titulo = '{0}: {1} intentos'.format(NOMBRE, intentos)
        elif intentos == 1:
            titulo = '{0}: último intento'.format(NOMBRE)
        else:
            titulo = '{0}: sin intentos'.format(NOMBRE)
        sel = xbmcgui.Dialog().select(titulo, opciones)
        if sel < 0 or sel == 2:
            return False
        if sel == 1:
            abrir_canal()
            continue
        # numeric() y no input(INPUT_NUMERIC): en Dialog.cpp esa rama llama a
        # ShowAndGetNumber() e ignora `option` (y 1 es PASSWORD_VERIFY, no ocultar), así que
        # los dígitos se ven. numeric(0..., bHiddenInput=True) sí los enmascara.
        tecleado = xbmcgui.Dialog().numeric(0, NOMBRE + " | PIN", '', True)
        if not tecleado:
            continue
        if _pin_correcto(cfg, tecleado):
            return True
        restantes = MAX_FALLOS - _suma_fallo()
        if restantes <= 0:
            xbmcgui.Dialog().ok(
                NOMBRE,
                "PIN incorrecto. Has agotado los {0} intentos de esta sesión.\n\n"
                "El resto de EspaTV sigue funcionando. Si crees que el PIN es correcto, "
                "compruébalo en el canal de Telegram (t.me/espadaily): en cuanto salgas de la "
                "sección te dejará volver a intentarlo.".format(MAX_FALLOS))
            return False
        xbmcgui.Dialog().ok(
            NOMBRE,
            "PIN incorrecto. " + ("Te queda 1 intento." if restantes == 1
                                  else "Te quedan {0} intentos.".format(restantes)))


def pin_gate(raiz=False):
    """Puerta del PIN. False = no se entra en la sección.

    `raiz=True` solo la llama menu(), y es lo que hace que el modo "al entrar" vuelva a
    preguntar cada vez que se abre la sección. El resto de pantallas (plataforma, listado,
    buscador, ajustes) pasan con el desbloqueo de la sesión: si no lo hay, es que se ha entrado
    por un atajo y se pregunta.
    """
    cfg = _cfg()
    if cfg["pin_on"] == "nunca":
        return True
    desbloqueado = False
    try:
        desbloqueado = xbmcgui.Window(10000).getProperty(PROP_UNLOCK) == "1"
    except Exception:
        pass
    if desbloqueado and not (raiz and cfg["pin_on"] == "entrar"):
        return True
    if _fallos() >= MAX_FALLOS:
        # Si se superan los intentos máximos en la sesión, se ofrece reiniciar el contador y reintentar.
        if not xbmcgui.Dialog().yesno(
                NOMBRE,
                "Has usado los {0} intentos del PIN en esta sesión.\n\n"
                "El PIN está en el canal de Telegram (t.me/espadaily).\n\n"
                "El resto de EspaTV sigue funcionando. ¿Quieres volver a intentarlo?".format(
                    MAX_FALLOS),
                nolabel="Salir", yeslabel="Volver a intentarlo"):
            return False
        _limpia_fallos()
    if not _pedir_pin(cfg):
        return False
    _limpia_fallos()
    try:
        xbmcgui.Window(10000).setProperty(PROP_UNLOCK, "1")
    except Exception:
        pass
    return True


def cambiar_pin():
    """Fija el PIN que elija el usuario. Nunca se guarda en claro, solo su hash con sal.

    No se pide el PIN actual: para llegar a esta pantalla ya se ha validado el acceso.
    """
    # numeric() por lo mismo que en _pedir_pin().
    tecleado = xbmcgui.Dialog().numeric(0, NOMBRE + " | PIN nuevo (4 dígitos)", '', True)
    if not tecleado:
        return
    pin = str(tecleado).strip()
    if not _pin_aceptable(pin):
        xbmcgui.Dialog().ok(NOMBRE, "El PIN tiene que tener 4 dígitos normales, del 0 al 9. "
                                    "Los de ancho completo y los de otras escrituras no valen.")
        return
    otra = xbmcgui.Dialog().numeric(0, NOMBRE + " | Repite el PIN", '', True)
    if str(otra or "").strip() != pin:
        xbmcgui.Dialog().ok(NOMBRE, "El PIN repetido no coincide. No se ha cambiado nada.")
        return
    cfg = _cfg()
    cfg["pin_salt"] = secrets.token_hex(12)
    cfg["pin_hash"] = _hash(pin, cfg["pin_salt"])
    # Al activar pin_propio se deja de utilizar el PIN inicial.
    cfg["pin_propio"] = True
    if not _guardar_cfg(cfg):
        # Si falla la escritura en disco, se notifica explícitamente para no
        # asumir erróneamente que el PIN nuevo quedó registrado.
        xbmcgui.Dialog().ok(NOMBRE, "No se ha podido guardar el PIN nuevo, así que sigue "
                                    "valiendo el anterior. Comprueba que el disco no esté "
                                    "lleno ni el perfil sin permisos, y vuelve a intentarlo.")
        return
    _limpia_fallos()
    try:
        xbmcgui.Window(10000).setProperty(PROP_UNLOCK, "1")
    except Exception:
        pass
    xbmcgui.Dialog().notification(NOMBRE, "PIN cambiado", xbmcgui.NOTIFICATION_INFO, 3000)


# -------------------------------------------------------------------- +18
def adult_gate():
    cfg = _cfg()
    if not cfg["adult_confirm"] or cfg["adult_ok"]:
        return True
    ret = xbmcgui.Dialog().yesno(
        NOMBRE + " | +18",
        "Esta sección contiene material para adultos (+18).\n\n"
        "¿Confirmas que eres mayor de edad y deseas continuar?")
    if not ret:
        xbmcgui.Dialog().notification(NOMBRE, "Hay que confirmar que eres mayor de edad (+18) para entrar.",
                                      xbmcgui.NOTIFICATION_WARNING, 3000)
        return False
    cfg["adult_ok"] = True
    _guardar_cfg(cfg)
    return True


def abrir_canal():
    """Abre el canal de Telegram. Reutiliza el helper del instalador, que ya pregunta y
    cubre el caso de Android."""
    try:
        import espakodi_installer
        espakodi_installer.abrir_url(
            URL_CANAL, NOMBRE,
            "El PIN de esta sección está en el canal de Telegram de EspaKodi.", "Abriendo el canal...")
        return
    except Exception as e:
        _log("no se pudo abrir el canal: {0}".format(e), xbmc.LOGWARNING)
    try:
        import webbrowser
        webbrowser.open(URL_CANAL)
    except Exception:
        xbmcgui.Dialog().ok(NOMBRE, "Abre el canal a mano: {0}".format(URL_CANAL))


# ------------------------------------------------------------------- filas
def _fin(titulo):
    try:
        xbmcplugin.setPluginCategory(_h(), titulo)
    except Exception:
        pass


def _fila_dir(label, params, icono, plot, is_folder=True, contexto=None):
    params = {k: v for k, v in params.items() if v is not None}
    li = xbmcgui.ListItem(label=label)
    art = {"icon": _ico(icono), "thumb": _ico(icono)}
    li.setArt(art)
    try:
        li.setContentLookup(False)
    except Exception:
        pass
    try:
        li.setInfo("video", {"plot": plot})
    except Exception:
        pass
    if contexto:
        try:
            li.addContextMenuItems(contexto)
        except Exception:
            pass
    xbmcplugin.addDirectoryItem(_h(), _u(**params), li, is_folder)


_RE_BBCODE = re.compile(r"[\[\]]")


def _bbcode(texto):
    """Escapa los corchetes para que el texto de la red no se interprete como BBCode.

    Los titulos de estas plataformas traen corchetes, y un `[COLOR]`, un `[/COLOR]` o un `[B]`
    se renderiza de verdad: una fila puede pintarse con una falsa nota, una falsa linea de
    "Descargas:" o un cierre de color que rompe el de la fila entera. En Kodi los escapes son
    `[[]` y `[]]`.

    El orden NO vale: `]` primero y `[` despues tampoco, porque los propios escapes contienen los
    dos caracteres (`[]]` se convierte en `[[]]]`). Se hace en una sola pasada con regex.

    No toca los textos del propio addon, que si quiere BBCode: el boton de la seccion pinta
    `[B][COLOR crimson]Sección X[/COLOR][/B]`.
    """
    return _RE_BBCODE.sub(lambda m: "[[]" if m.group(0) == "[" else "[]]", str(texto or ""))


def _plot_de(v):
    lineas = [_bbcode(v.get("title"))]
    datos = []
    if v.get("length"):
        datos.append("Duración: {0}".format(_bbcode(v.get("length"))))
    vistas = api.formatea_vistas(v.get("views"))
    if vistas:
        datos.append("{0} vistas".format(vistas))
    if v.get("rate"):
        datos.append("Nota: {0}/10".format(_bbcode(v.get("rate"))))
    if v.get("added"):
        datos.append("Subido: {0}".format(_bbcode(v.get("added"))))
    if v.get("src") in ("rt", "ph"):
        datos.append(api.NOMBRES[v["src"]])
    if datos:
        lineas.append(" · ".join(datos))
    if v.get("keywords"):
        etiquetas = [_bbcode(k) for k in list(v.get("keywords"))[:6] if k]
        if etiquetas:
            lineas.append("Etiquetas: " + ", ".join(etiquetas))
    return "\n".join(lineas)


_RE_EMOJIS = api._RE_EMOJIS
_limpiar_emojis = api.limpiar_emojis


def _etiqueta_de(v):
    """Rótulo de la fila: plataforma, título, duración, nota y vistas."""
    pre = api.PREFIJOS.get(v.get("src"), "")
    titulo = _limpiar_emojis(v.get("title")) or "Sin título"
    bits = [pre + _bbcode(titulo)]
    if v.get("length"):
        bits.append("[COLOR grey]{0}[/COLOR]".format(_bbcode(v.get("length"))))
    cola = []
    if v.get("rate"):
        cola.append("★{0}".format(_numero(v.get("rate"), 0)))
    vistas = api.formatea_vistas(v.get("views"))
    if vistas:
        cola.append("{0} vistas".format(vistas))
    if cola:
        bits.append("[COLOR grey]{0}[/COLOR]".format(_bbcode(" · ".join(cola))))
    return " ".join(bits)


def _url_play(v):
    """La URL de reproducción, con todos los parámetros necesarios para el historial.

    `added` preserva la fecha de subida para permitir la ordenación cronológica en favoritos e historial.
    """
    titulo = _limpiar_emojis(v.get("title", "")) or "Sin título"
    return _u(action="xxx_play", src=v.get("src", ""), vid=v.get("id", ""),
              titulo=titulo, thumb=v.get("thumb", ""),
              length=v.get("length", ""), views=str(_numero(v.get("views")) or 0),
              rate=str(_numero(v.get("rate")) or 0),
              added=_fecha_de(v), pagina=v.get("page", ""))


def _numero(valor, defecto=0):
    """Número tolerante: un 'N/A', una lista o un '1.234' no pueden tumbar la sección.

    Ojo con el separador de millares: "1.234" son mil doscientos treinta y cuatro, pero "8.0"
    son ocho coma cero. Solo se quita el punto cuando detrás hay exactamente tres dígitos.
    Devuelve entero cuando el valor lo es, para que las URLs no lleven 'views=1200.0'.

    Valores no finitos ('nan', 'inf') o enteros desbordados devuelven `defecto` para evitar
    excepciones durante el parseo de parámetros de URL o listas importadas.
    """
    if isinstance(valor, bool):
        return defecto
    try:
        if isinstance(valor, (int, float)):
            v = float(valor)
        else:
            s = str(valor or "").strip().replace(" ", "").replace(",", "")
            if "." in s:
                cabeza, _, cola = s.rpartition(".")
                if len(cola) == 3 and cola.isdigit():
                    s = cabeza + cola
            v = float(s)
    except (TypeError, ValueError, OverflowError):
        return defecto
    if v != v or v in (float("inf"), float("-inf")):
        return defecto
    try:
        return int(v) if v == int(v) else v
    except (ValueError, OverflowError):
        return defecto


def _fecha_de(v):
    """La fecha del vídeo en AAAA-MM-DD, o "" si no la hay o no es una fecha válida.

    Cada API la da en un formato distinto y a veces no la da: Eporner devuelve una fecha con
    hora, RedTube y Pornhub `YYYYMMDDHHMMSS` sin separadores. Se normaliza a lo que espera
    Kodi en `premiered`, que es AAAA-MM-DD, y si no encaja se devuelve "" en vez de un texto
    suelto: un string raro en `premiered` hace que el skin pinte la fila con la fecha en
    blanco.

    La comprobación valida tanto el formato como la existencia real en el calendario (ver `_fecha_valida`).
    """
    bruto = str((v or {}).get("added") or "").strip()
    if not bruto:
        return ""
    candidatos = [bruto[:10]]
    # "20260131T120233" o "2026/03/04": los ocho primeros dígitos, por si la fecha viene con
    # separadores raros o pegada a la hora. SOLO si el texto EMPIEZA por dígitos: si no, el
    # recorte encuentra 8 dígitos en medio de una frase cualquiera ("Subido: texto con
    # 20260304 dentro") y fabrica una fecha que no está ahí.
    if bruto[0].isdigit():
        digitos = ""
        for ch in bruto:
            if ch.isdigit():
                digitos += ch
            if len(digitos) == 8:
                break
        if len(digitos) == 8:
            candidatos.append("{0}-{1}-{2}".format(digitos[0:4], digitos[4:6], digitos[6:8]))
    for candidato in candidatos:
        if _fecha_valida(candidato):
            return candidato
    return ""


def _fecha_valida(texto):
    """True si `texto` es AAAA-MM-DD y además existe en el calendario."""
    if not _FECHA_OK.match(texto or ""):
        return False
    try:
        datetime.date(int(texto[0:4]), int(texto[5:7]), int(texto[8:10]))
    except (ValueError, TypeError):
        return False
    return True


_FECHA_OK = re.compile(r"^\d{4}-\d{2}-\d{2}$")


def _fanart_permitido():
    """Si el usuario ha dejado los fondos de imagen prendidos en EspaTV.

    `core_settings.is_fanart_disabled()` devuelve True cuando están apagados, así que
    se devuelve True cuando sí se puede poner fanart. Si la lectura falla, se devuelve False.
    """
    try:
        import core_settings
        return not bool(core_settings.is_fanart_disabled())
    except Exception:
        return False


def _fanart_del_addon():
    """El fanart de este addon, para ponerlo de fondo cuando la fila no tiene caratula."""
    try:
        return xbmcaddon.Addon().getAddonInfo("fanart") or ""
    except Exception:
        return ""


# ------------------------------------------------------------------ miniaturas de RedTube
# Las miniaturas de RedTube se resuelven y descargan en paralelo por pantalla
# para almacenarlas localmente, ya que su CDN requiere Referer y la API no entrega rutas completas.
#
# Esto es una caché más y va con las demás: `cache_clear()` también la vacía.
_DIR_THUMBS_RT = None
_THUMBS_RT = {}

# El logo de cada plataforma, para cuando no hay carátula. Sin esto la fila sale con el icono
# genérico de Kodi. Va como `icon`, NUNCA como `fanart`: de fondo está `_fanart_del_addon()`.
_ICO_POR_PLATAFORMA = {"ep": ICO_EPORNER, "rt": ICO_REDTUBE, "ph": ICO_PORNHUB}


def _dir_thumbs_rt():
    """Carpeta del addon donde se guardan las miniaturas de RedTube. "" si no se puede.

    Exige ruta absoluta para evitar creación accidental de directorios relativos
    en entornos de pruebas o rutas no resueltas.
    """
    global _DIR_THUMBS_RT
    if _DIR_THUMBS_RT is None:
        _DIR_THUMBS_RT = ""
        try:
            import xbmcvfs

            base = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
            if not isinstance(base, str) or not os.path.isabs(base):
                return ""
            carpeta = os.path.join(base, "thumbs_rt")
            if not os.path.isdir(carpeta):
                os.makedirs(carpeta)
            _DIR_THUMBS_RT = carpeta
        except Exception:
            _DIR_THUMBS_RT = ""
    return _DIR_THUMBS_RT


def _thumbs_listados(videos):
    """Las miniaturas reparadas de RedTube de una pantalla entera: ``{id: ruta o ""}``.

    UNA vez por vídeo y por sesión, y no por pantalla. Se resuelve la pantalla entera de una vez
    porque `thumbs_redtube()` ya va en paralelo; si se pidiera fila a fila serían 20 x 1,6 s en
    serie y se notaría como la pantalla tarda.

    Lo que FALLA se apunta como "" a propósito. Sin esto, un vídeo que no se pudo bajar (la red
    cayó, RedTube cambió la página) se volvería a intentar en cada visita a la pantalla, y en el
    peor caso son 20 x 1,6 s colgados cada vez que se abre el menú de RedTube. Es peor un
    recargado que una miniatura que falta.

    Ese apunte va en disco, no en memoria. `_THUMBS_RT` es un diccionario del módulo,
    y en Kodi cada pulsación es un intérprete nuevo (`addon.xml` no lleva
    `reuselanguageinvoker`): **no dura una sesión**, diga lo que diga el párrafo de arriba. Con
    él solo, un vídeo roto se reintentaba en cada visita. El marcador lo escribe
    `api.apunta_fallo_thumb_rt()` en `rt_<id>.fallo` y caduca a las 24 h
    (`api.thumb_rt_fallada()`).
    """
    nuevos = [v for v in (videos or [])
              if isinstance(v, dict) and v.get("src") == "rt"
              and str(v.get("id") or "") not in _THUMBS_RT]
    if not nuevos:
        return _THUMBS_RT
    carpeta = _dir_thumbs_rt()
    if not carpeta:
        return _THUMBS_RT

    # Las miniaturas que fallaron recientemente se saltan y se marcan como vacías
    # para evitar reintentos continuos en la misma pantalla.
    por_intentar = []
    for v in nuevos:
        if api.thumb_rt_fallada(v, carpeta):
            _THUMBS_RT[str(v.get("id") or "")] = ""
            continue
        por_intentar.append(v)
    if not por_intentar:
        return _THUMBS_RT

    try:
        bajadas = api.thumbs_redtube(por_intentar, carpeta)
    except Exception:
        return _THUMBS_RT
    for v in por_intentar:
        ident = str(v.get("id") or "")
        ruta = bajadas.get(ident, "")
        _THUMBS_RT[ident] = ruta
        if not ruta:
            api.apunta_fallo_thumb_rt(v, carpeta)
    return _THUMBS_RT


def _vaciar_thumbs_rt():
    """Borra las miniaturas de RedTube guardadas. Lo llama `cache_clear()`."""
    global _DIR_THUMBS_RT
    carpeta = _dir_thumbs_rt()
    _THUMBS_RT.clear()
    if not carpeta:
        return 0
    borrados = 0
    try:
        for nombre in os.listdir(carpeta):
            if not nombre.startswith("rt_"):
                continue
            try:
                os.remove(os.path.join(carpeta, nombre))
                borrados += 1
            except OSError:
                pass
    except OSError:
        pass
    _DIR_THUMBS_RT = None
    return borrados


def _fila_video(v, contexto_extra=None, en_favoritos=None, fanart=None, thumbs=None, modo_ligero=False):
    src, vid = v.get("src", ""), v.get("id", "")
    li = xbmcgui.ListItem(label=_etiqueta_de(v))
    # Carátula y fanart: skins con vista multimedia muestran la carátula de fondo.
    caratula = v.get("thumb", "")
    # La miniatura local de RedTube tiene prioridad si la API devolvió limitación de tasa (429/410).
    if thumbs:
        local = thumbs.get(str(vid))
        if local:
            caratula = local
    if src == "rt" and api.thumb_redtube_rota(caratula):
        caratula = ""
    icono = caratula
    if not icono:
        nombre_icono = _ICO_POR_PLATAFORMA.get(src, "")
        if nombre_icono:
            icono = _ico(nombre_icono)
    if modo_ligero:
        nombre_icono = _ICO_POR_PLATAFORMA.get(src, "")
        art = {"icon": _ico(nombre_icono) if nombre_icono else ""}
    else:
        art = {"icon": icono, "thumb": icono, "poster": icono}
        if _fanart_permitido() if fanart is None else fanart:
            art["fanart"] = caratula or _fanart_del_addon()
    li.setArt(art)
    try:
        li.setContentLookup(False)
    except Exception:
        pass
    info = {"title": _limpiar_emojis(v.get("title", "")) or "Sin título",
            "plot": _plot_de(v), "mediatype": "video"}
    if src in ("rt", "ph"):
        info["studio"] = api.NOMBRES.get(src, src)
    if v.get("length_sec"):
        info["duration"] = int(_numero(v.get("length_sec")) or 0)
    # Puntuación y fecha de estreno para skins que muestran metadatos detallados.
    nota = _numero(v.get("rate"), 0)
    if nota:
        info["rating"] = float(nota)
    alta = _fecha_de(v)
    if alta:
        info["premiered"] = alta
    try:
        li.setInfo("video", info)
    except Exception:
        pass
    li.setProperty("IsPlayable", "true")
    if en_favoritos is None:
        en_favoritos = _clave(src, vid) in _claves_favoritos()
    # El menú contextual va SIEMPRE en tuplas (rótulo, orden). Una cadena suelta la interpreta
    # Kodi como el nombre de un builtin, así que el botón se pintaba y no hacía nada: Favoritos
    # se quedaba siempre vacío y tres acciones del router no las emitía nadie.
    # "Reproducir" va con PlayMedia, NO con RunPlugin. Con RunPlugin, Kodi invoca el addon con
    # handle -1, y `xbmcplugin.setResolvedUrl(-1...)` lo rechaza ("Invalid handle -1"): el
    # diálogo de progreso se abría y se cerraba, y no sonaba nada. PlayMedia es lo que usa el
    # resto del addon para esto (default.py, pelis_flix.py, fantasia.py, iptv_lists.py...). El
    # resto de entradas del contextual (favoritos, historial, abrir en la web) si son RunPlugin,
    # porque no resuelven nada.
    acciones = [("Reproducir", "PlayMedia({0})".format(_url_play(v)))]
    if en_favoritos:
        acciones.append(("Quitar de favoritos",
                          "RunPlugin({0})".format(_u(action="xxx_fav_del", vid=vid, src=src))))
    else:
        acciones.append(("Añadir a favoritos",
                         "RunPlugin({0})".format(_u(
                             action="xxx_fav_add", src=src, vid=vid,
                             titulo=_limpiar_emojis(v.get("title", "")) or "Sin título",
                             thumb=v.get("thumb", ""),
                             length=v.get("length", ""),
                             views=str(_numero(v.get("views")) or 0),
                             rate=str(_numero(v.get("rate")) or 0),
                             added=_fecha_de(v), pagina=v.get("page", "")))))
    # "Abrir en la web": usa la URL de página si está disponible; en caso contrario recurre al reproductor web/embed.
    acciones.append(("Abrir en la web",
                     "RunPlugin({0})".format(_u(action="xxx_web", src=src, vid=vid,
                                                pagina=v.get("page", "") or ""))))
    if contexto_extra:
        acciones.extend(contexto_extra)
    try:
        li.addContextMenuItems(acciones, replaceItems=False)
    except Exception:
        pass
    xbmcplugin.addDirectoryItem(_h(), _url_play(v), li, False)


def _boton_accion(label, accion, icono, plot, params_extra=None, is_folder=False):
    """Genera un botón de acción en el listado.

    Con `is_folder=False` y sin declararla reproducible, Kodi la ejecuta sin
    abrir una nueva carpeta de navegación (para acciones directas como borrar favoritos,
    aviso legal o cambiar PIN). Las acciones que muestran listados posteriores
    deben especificar `is_folder=True`.
    """
    p = {"action": accion}
    if params_extra:
        p.update(params_extra)
    _fila_dir(label, p, icono, plot, is_folder=is_folder)


PROP_AVISO_PIN = "espatv_xxx_aviso_pin"

#: Indica si la explicación del PIN se ha enseñado ya en esta sesión de Kodi.
PROP_EXPLICA_PIN = "espatv_xxx_explica_pin"


def _explica_el_pin():
    """Informa de la procedencia del PIN en Telegram una vez por sesión."""
    try:
        ventana = xbmcgui.Window(10000)
        if ventana.getProperty(PROP_EXPLICA_PIN) == "1":
            return
        ventana.setProperty(PROP_EXPLICA_PIN, "1")
    except Exception:
        pass
    xbmcgui.Dialog().ok(
        NOMBRE,
        "Esta sección pide un PIN de 4 dígitos.\n\n"
        "Se publica en el canal de Telegram de EspaKodi: [B]t.me/espadaily[/B]\n"
        "Puedes buscar en el canal «Sección X», «+18» o «XXX».\n\n"
        "Te quedan [B]{0}[/B] intentos en esta sesión.".format(
            max(0, MAX_FALLOS - _fallos())))


def _recuerda_cambiar_el_pin():
    """Recuerda UNA VEZ POR SESIÓN que el PIN sigue siendo el público del canal de Telegram."""
    cfg = _cfg()
    texto = _aviso_pin_publico(cfg)
    if not texto or cfg["pin_on"] == "nunca":
        return
    try:
        ventana = xbmcgui.Window(10000)
        if ventana.getProperty(PROP_AVISO_PIN) == "1":
            return
        ventana.setProperty(PROP_AVISO_PIN, "1")
    except Exception:
        pass
    _notifica(texto, heading=NOMBRE + " · aviso")


PROP_AVISO_GAY = "espatv_xxx_aviso_gay"


def _filtra_ph(lista, gay):
    """Aplica el ajuste de contenido sobre una página de Pornhub.

    Devuelve `(lista filtrada, cuántas había antes)`. El segundo número permite
    distinguir una búsqueda sin resultados de una donde el filtro descartó el total.

    `gay=0` descarta elementos con `segment == 'gay'`. `gay=2` mantiene solo esos.
    Si el elemento no incluye el campo `segment`, se conserva para evitar filtrados espurios.
    """
    traidas = len(lista)
    if gay == 0:
        return [v for v in lista if (v.get('segment') or '') != 'gay'], traidas
    if gay == 2:
        return [v for v in lista if (v.get('segment') or '') == 'gay'], traidas
    return lista, traidas


def _avisa_contenido_gay():
    pass


# ------------------------------------------------------------------- menú
def menu():
    """Menú de la sección. Las puertas van antes: PIN y luego +18."""
    if not pin_gate(raiz=True):
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    if not adult_gate():
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    # El punto verde de lo nuevo se apaga al entrar de verdad, no al pulsar la entrada:
    # quien cancela el PIN o el aviso de mayoría de edad no ha visto la sección (ver
    # ui_utils.punto/visto y default._NUEVO_PORT).
    ui_utils.visto('seccion_x')
    _fin(NOMBRE)
    # Sin setContent: con contenido vacío el skin pinta el icono en la fila.
    #
    # El recordatorio del PIN va aquí y no dentro de `pin_gate()` a propósito: `pin_gate()` se
    # llama en 21 acciones y solo en la RAÍZ tiene sentido recordar algo. Además, si está
    # dentro, el aviso saldría también al cambiar el PIN desde el contextual.
    _recuerda_cambiar_el_pin()
    #
    # El orden del menú principal sigue el de referencia: Eporner, RedTube,
    # Pornhub, Buscar por plataforma, Favoritos, Historial y Ajustes.
    _fila_dir("Eporner", {"action": "xxx_menu_plat", "src": "ep"}, ICO_EPORNER,
              "Eporner: los más recientes, los tops y las categorías.")
    _fila_dir("RedTube", {"action": "xxx_menu_plat", "src": "rt"}, ICO_REDTUBE,
              "RedTube: los más recientes, las categorías y el buscador.")
    _fila_dir("Pornhub", {"action": "xxx_menu_plat", "src": "ph"}, ICO_PORNHUB,
              "Pornhub: búsquedas por tema y el buscador. No tiene categorías oficiales.")
    _fila_dir("Buscar por plataforma", {"action": "xxx_search_menu"}, ICO_BUSCAR,
              "Elige en qué plataforma buscar, sin entrar antes en ella.")
    _fila_dir("Favoritos", {"action": "xxx_favs"}, ICO_FAVORITOS,
              "Los vídeos que has guardado desde esta sección.")
    _fila_dir("Historial", {"action": "xxx_hist"}, ICO_HISTORIAL,
              "Lo que has reprodujido en esta sección, hasta 100 entradas.")
    _fila_dir("Ajustes", {"action": "xxx_ajustes"}, ICO_AJUSTES,
              "Ajustes de la sección: resultados por página, calidad, PIN y control parental.")
    _forzar_vista_wide()
    xbmcplugin.endOfDirectory(_h())


def _forzar_vista_wide():
    """Fuerza la vista WideList (55) en los menús de carpetas si está configurado en ajustes.

    Se ejecuta con AlarmClock para asegurar que el contenedor de Kodi esté completamente cargado.
    """
    try:
        if _cfg()["vista"] != "wide":
            return
        xbmc.executebuiltin("CancelAlarm({0},True)".format(ALARMA_VISTA))
        xbmc.executebuiltin("AlarmClock({0},Container.SetViewMode({1}),1,silent)".format(
            ALARMA_VISTA, VIEW_WIDE))
    except Exception as e:
        _log("no se pudo forzar la vista: {0}".format(e), xbmc.LOGWARNING)


def search_menu():
    """Menú global de búsqueda por plataforma."""
    if not _puertas():
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    _fin("{0} · Buscar".format(NOMBRE))
    for src, icono in (("ep", ICO_EPORNER), ("rt", ICO_REDTUBE), ("ph", ICO_PORNHUB)):
        nombre = api.NOMBRES.get(src, src)
        _fila_dir("Buscar en {0}...".format(nombre), {"action": "xxx_buscar", "src": src},
                  icono, "Escribe lo que quieras ver en {0}.".format(nombre))
    _fila_dir("<< Volver al menú de la sección", {"action": "xxx_menu"}, ICO_BUSCAR,
              "Atrás: vuelve al menú con las tres plataformas.")
    _forzar_vista_wide()
    xbmcplugin.endOfDirectory(_h())


def _plot_orden_rt(texto):
    """Lo que hay que saber antes de entrar en una de las cuatro secciones de orden de RedTube."""
    return ("RedTube ordenado por {0}.\n\n".format(texto.lower()) +
            "Aviso: en estas listas sin término de búsqueda, RedTube no hace caso del orden y "
            "salen los mismos vídeos que en «Últimos». "
            "En cuanto escribes algo en el buscador, el orden sí funciona.")


def menu_plataforma(src):
    if not _puertas():
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    nombre = api.NOMBRES.get(src, src)
    _fin("{0} · {1}".format(NOMBRE, nombre))
    if src == "rt":
        _avisa_contenido_gay()
    if src == "ep":
        _boton_accion("Buscar...", "xxx_buscar", ICO_BUSCAR,
                      "Escribe lo que quieras ver en Eporner.", {"src": "ep"},
                      is_folder=True)
        for clave, texto in ORDENES:
            _fila_dir("Eporner: {0}".format(texto),
                      {"action": "xxx_list", "src": "ep", "q": "", "page": 1, "order": clave},
                      ICO_EPORNER, "Listado de Eporner ordenado por {0}.".format(texto.lower()))
        _fila_dir("Eporner: Categorías", {"action": "xxx_cats", "src": "ep"}, ICO_CATEGORIAS,
                  "Categorías de Eporner. Son búsquedas por etiqueta.")
    elif src == "rt":
        for clave, texto, _ordering, _period in ORDENES_RT:
            _fila_dir("RedTube: {0}".format(texto),
                      {"action": "xxx_list", "src": "rt", "q": "", "page": 1, "order": clave},
                      ICO_REDTUBE, _plot_orden_rt(texto))
        _fila_dir("RedTube: Categorías", {"action": "xxx_cats", "src": "rt"}, ICO_CATEGORIAS,
                  "Las {0} categorías de RedTube.".format(len(CATS_RT)))
        _boton_accion("Buscar...", "xxx_buscar", ICO_BUSCAR,
                      "Escribe lo que quieras ver en RedTube.", {"src": "rt"},
                      is_folder=True)
    else:
        _fila_dir("Pornhub: Español", {"action": "xxx_list", "src": "ph", "q": "spanish",
                                       "page": 1},
                  ICO_PORNHUB, "Videos de Pornhub etiquetados en español.")
        _fila_dir("Pornhub: Categorías", {"action": "xxx_cats", "src": "ph"}, ICO_CATEGORIAS,
                  "Categorías y temas populares de Pornhub.")
        _boton_accion("Buscar...", "xxx_buscar", ICO_BUSCAR,
                      "Escribe lo que quieras ver en Pornhub.", {"src": "ph"},
                      is_folder=True)
    _forzar_vista_wide()
    xbmcplugin.endOfDirectory(_h())


# -------------------------------------------------------------- listados
def listado(src, q="", page=1, order=None, upd=""):
    if not _puertas():
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    cfg = _cfg()
    page = _pagina(page)
    if src == "rt":
        _avisa_contenido_gay()
    traidos_ph = 0
    if src == "ph":
        # Pornhub requiere término de búsqueda al no tener categorías nativas (por defecto 'spanish').
        lista, err = api.buscar("ph", query=q or "spanish", page=page, timeout=cfg["timeout"])

        # Filtrado local de contenido para Pornhub según el campo segment de cada vídeo.
        # La paginación se calcula sobre el total devuelto por la API antes del filtrado.
        lista, traidos_ph = _filtra_ph(lista, cfg["gay"])
        tope = api.PAGE_SIZE_PH
    elif src == "rt":
        # Se transmite el orden seleccionado a la API de RedTube.
        lista, err = api.buscar("rt", query=q, page=page, order=order or "latest",
                                timeout=cfg["timeout"])
        tope = api.PAGE_SIZE_RT
    else:
        lista, err = api.buscar("ep", query=q, page=page,
                               order=order or cfg["order"],
                               per_page=cfg["per_page"], thumbsize=cfg["thumbsize"],
                               gay=cfg["gay"], timeout=cfg["timeout"])
        tope = cfg["per_page"]
    nombre = api.NOMBRES.get(src, src)
    titulo = "{0} · {1} · p.{2}".format(NOMBRE, q or nombre, page)
    if order:
        titulo += " · " + str(order)
    _fin(titulo)
    if not lista:
        if page > 1:
            _fila_dir("<< Anterior (página {0})".format(page - 1),
                      {"action": "xxx_list", "src": src, "q": q, "page": page - 1,
                       "order": order, "upd": 1},
                      ICO_SIGUIENTE, "Vuelve a la página anterior.")
        if err:
            motivo = err
            if src == "rt" and page > 500:
                motivo = ("El catálogo de RedTube se acaba hacia la página {0}: esta no ha "
                          "devuelto nada.\n\nSi sales con la página {1}, es el final de la "
                          "lista y no un fallo.".format(page, page - 1))
            _notifica(motivo)
            _fila_dir("Reintentar", {"action": "xxx_list", "src": src, "q": q,
                                     "page": page, "order": order, "upd": 1},
                      ICO_BUSCAR, motivo)
        else:
            _fila_dir("Sin resultados. Probar otra vez",
                      {"action": "xxx_list", "src": src, "q": q, "page": 1,
                       "order": order, "upd": 1},
                      ICO_BUSCAR, "No ha salido ningún vídeo con esa búsqueda.")
            # Si la búsqueda devolvió resultados pero el filtro los descartó todos,
            # se muestra una fila explicativa con el motivo.
            if (src == "ph" and cfg["gay"] in (0, 2) and traidos_ph > len(lista)):
                _fila_dir("Vídeos ocultados por el filtro de contenido",
                          {"action": "xxx_ajustes"}, ICO_BUSCAR,
                          "La búsqueda ha devuelto {0} vídeos que están ocultos por el ajuste «Contenido gay». "
                          "Pulsa para abrir Ajustes.".format(traidos_ph))
        # Acciones para realizar una nueva búsqueda o volver al menú superior.
        _boton_accion("Buscar otra cosa", "xxx_buscar", ICO_BUSCAR,
                      "Escribe otra búsqueda.", {"src": src}, is_folder=True)
        _boton_accion("Volver al menú de la sección", "xxx_menu", ICO_BUSCAR,
                      "Atrás: vuelve al menú con las tres plataformas.",
                      is_folder=True)
        _cierra_listado(upd)
        return
    if err:
        _notifica(err)
    # Los listados de vídeos sí fijan contenido; los menús no (ver cabecera del módulo).
    try:
        pass  # Sin setContent('videos'): contenido neutro para que Estuary pinte la carátula en la fila
    except Exception:
        pass
    fanart = _fanart_permitido()
    favs = _claves_favoritos()
    # Las miniaturas de RedTube se resuelven de la pantalla ENTERA y una sola vez (ver
    # `_thumbs_listados`): fila a fila serían 20 descargas en serie y se notaría como que la
    # pantalla tarda.
    try:
        import core_settings
        modo_ligero = core_settings.is_modo_ligero_active()
    except Exception:
        modo_ligero = False
    thumbs = {} if modo_ligero else _thumbs_listados(lista)
    for v in lista:
        _fila_video(v, en_favoritos=_clave(v.get("src"), v.get("id")) in favs,
                    fanart=fanart, thumbs=thumbs, modo_ligero=modo_ligero)
    # updateListing=True evita bucles en el historial de navegación de Kodi al paginar,
    # reemplazando la entrada actual para que la acción Atrás regrese directamente al menú superior.
    if page > 1:
        _fila_dir("<< Anterior (página {0})".format(page - 1),
                  {"action": "xxx_list", "src": src, "q": q, "page": page - 1,
                   "order": order, "upd": 1},
                  ICO_SIGUIENTE, "Vuelve a la página anterior.")
    # Solo len(lista) >= tope es fiable: total_count de Eporner es un tope de catálogo (100000)
    # y total_pages daría "página 3334 de 3334" con diez vídeos.
    if len(lista) >= tope:
        _fila_dir("Siguiente >> (página {0})".format(page + 1),
                  {"action": "xxx_list", "src": src, "q": q, "page": page + 1,
                   "order": order, "upd": 1},
                  ICO_SIGUIENTE, "Página siguiente.")
    try:
        xbmcplugin.addSortMethod(_h(), xbmcplugin.SORT_METHOD_LABEL)
        xbmcplugin.addSortMethod(_h(), xbmcplugin.SORT_METHOD_DURATION)
        xbmcplugin.addSortMethod(_h(), xbmcplugin.SORT_METHOD_DATE)
    except Exception:
        pass
    _cierra_listado(upd)


def _cierra_listado(upd):
    """Cierra el directorio de un listado de vídeos, respetando `upd`.

    `upd` lo ponen las filas de paginación para reemplazar la vista en lugar de apilar
    niveles en el historial de navegación de Kodi.
    """
    kw = {}
    if str(upd or "").strip() not in ("", "0", "None", "False"):
        kw["updateListing"] = True
    try:
        xbmcplugin.endOfDirectory(_h(), succeeded=True, cacheToDisc=False, **kw)
    except TypeError:
        try:
            xbmcplugin.endOfDirectory(_h(), succeeded=True)
        except Exception:
            pass
    except Exception:
        pass


def categorias(src, upd=""):
    if not _puertas():
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    _fin("{0} · Categorías".format(NOMBRE))
    if src == "ep":
        for cat in CAT_EPORNER:
            _fila_dir(cat, {"action": "xxx_list", "src": "ep", "q": cat, "page": 1},
                      ICO_CATEGORIAS, "Vídeos de Eporner con la etiqueta «{0}».".format(cat))
    elif src == "rt":
        cats = list(CATS_RT)
        _avisa_contenido_gay()
        for cat in cats:
            _fila_dir(cat, {"action": "xxx_list_rt_cat", "cat": cat, "page": 1},
                      ICO_CATEGORIAS,
                      "Vídeos de RedTube de la categoría «{0}».".format(cat))
    else:
        _fila_dir("Buscar en Pornhub...",
                  {"action": "xxx_buscar", "src": "ph"}, ICO_CATEGORIAS,
                  "Pornhub solo permite filtrar por el buscador.", is_folder=True)
        for etiqueta, termino in BUSQUEDAS_PH:
            _fila_dir(etiqueta, {"action": "xxx_list", "src": "ph", "q": termino, "page": 1},
                      ICO_CATEGORIAS, "Buscar «{0}» en Pornhub.".format(termino))
    _forzar_vista_wide()
    _cierra_listado(upd)


def listado_rt_cat(cat, page=1, upd=""):
    if not _puertas():
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    cfg = _cfg()
    page = _pagina(page)
    lista, err = api.buscar("rt", query="", page=page, category=cat, timeout=cfg["timeout"])
    _fin("{0} · RedTube · {1}".format(NOMBRE, _bbcode(cat)))
    if err:
        if page > 500:
            _notifica("El catálogo de RedTube se acaba hacia la página 500: esta no ha devuelto "
                      "nada.\n\nSi sales a una página anterior, es el final de la lista y no un "
                      "fallo.")
        else:
            _notifica(err)
    if not lista:
        if page > 1:
            _fila_dir("<< Anterior (página {0})".format(page - 1),
                      {"action": "xxx_list_rt_cat", "cat": cat, "page": page - 1, "upd": 1},
                      ICO_SIGUIENTE, "Vuelve a la página anterior.")
        _fila_dir("No ha salido nada de «{0}»".format(_bbcode(cat)),
                  {"action": "xxx_cats", "src": "rt", "upd": 1}, ICO_BUSCAR,
                  err or "Prueba con otra categoría.")
        _cierra_listado(upd)
        return
    try:
        pass  # Sin setContent('videos'): contenido neutro para que Estuary pinte la carátula en la fila
    except Exception:
        pass
    fanart = _fanart_permitido()
    favs = _claves_favoritos()
    try:
        import core_settings
        modo_ligero = core_settings.is_modo_ligero_active()
    except Exception:
        modo_ligero = False
    thumbs = {} if modo_ligero else _thumbs_listados(lista)
    for v in lista:
        _fila_video(v, en_favoritos=_clave(v.get("src"), v.get("id")) in favs,
                    fanart=fanart, thumbs=thumbs, modo_ligero=modo_ligero)
    if page > 1:
        _fila_dir("<< Anterior (página {0})".format(page - 1),
                  {"action": "xxx_list_rt_cat", "cat": cat, "page": page - 1, "upd": 1},
                  ICO_SIGUIENTE, "Vuelve a la página anterior.")
    if len(lista) >= api.PAGE_SIZE_RT:
        _fila_dir("Siguiente >> (página {0})".format(page + 1),
                  {"action": "xxx_list_rt_cat", "cat": cat, "page": page + 1, "upd": 1},
                  ICO_SIGUIENTE, "Página siguiente.")
    try:
        xbmcplugin.addSortMethod(_h(), xbmcplugin.SORT_METHOD_LABEL)
        xbmcplugin.addSortMethod(_h(), xbmcplugin.SORT_METHOD_DURATION)
        xbmcplugin.addSortMethod(_h(), xbmcplugin.SORT_METHOD_DATE)
    except Exception:
        pass
    _cierra_listado(upd)


def buscar(src):
    if not pin_gate():
        _cierra(_h(), succeeded=False)
        return
    texto = ui_utils.get_text("Buscar en {0}".format(api.NOMBRES.get(src, src)))
    if not texto or not texto.strip():
        _cierra(_h(), succeeded=False)
        return
    _nav_listado(src, texto.strip(), 1)


def _nav_listado(src, q, page):
    """Navega al listado. Se hace con Container.Update para que Atrás vuelva aquí y no a la
    raíz de la sección."""
    # SIN replace: con replace, "Atras" se lleva al menu de la seccion en lugar de volver al
    # teclado. Es lo que hace iptv_lists.search_prompt, con el comentario al reves.
    xbmc.executebuiltin('Container.Update("{0}")'.format(
        _u(action="xxx_list", src=src, q=q, page=page)))


def _puertas(con_edad=True):
    """Las dos validaciones de la sección en secuencia: PIN de acceso y confirmación +18.

    `con_edad=False` aplica en pantallas auxiliares que no listan contenido adulto directo
    (aviso legal, borrado de caché), donde solo se requiere el PIN de acceso.
    """
    if not pin_gate():
        return False
    if con_edad and not adult_gate():
        return False
    return True


# -------------------------------------------------------------- favoritos
def _ordenes_de_ordenacion():
    """Registra los métodos de ordenación soportados por Kodi en las vistas de la sección."""
    for metodo in ("SORT_METHOD_LABEL", "SORT_METHOD_UNSORTED", "SORT_METHOD_DATE",
                   "SORT_METHOD_VIDEO_YEAR", "SORT_METHOD_DURATION", "SORT_METHOD_TITLE",
                   "SORT_METHOD_TITLE_IGNORE_THE", "SORT_METHOD_FILE"):
        valor = getattr(xbmcplugin, metodo, None)
        if valor is None:
            continue
        try:
            xbmcplugin.addSortMethod(_h(), valor)
        except Exception:
            pass


def favoritos():
    if not _puertas():
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    _fin("{0} · Favoritos".format(NOMBRE))
    items = _leer_lista(FICH_FAVS)
    if not items:
        # `setContent('videos')` va DESPUES de esta rama, no antes: en un contenedor de videos
        # la fila de aviso se pinta con el arte generico del skin (o en blanco en WideList) y
        # se pierde el icono propio. Es lo que ya hace `listado()`.
        _fila_dir("Todavía no has guardado ningún vídeo aquí.", {"action": "xxx_menu_plat",
                                                                 "src": "ep"},
                  ICO_BUSCAR,
                  "Abre una plataforma y usa el menú contextual de cualquier vídeo.\n\n"
                  "Esta lista es propia de la sección y no comparte nada con los "
                  "favoritos de EspaTV.")
        _boton_accion("Volver al menú de la sección", "xxx_menu", ICO_BUSCAR,
                      "Atrás: vuelve al menú con las tres plataformas.",
                      is_folder=True)
    else:
        try:
            pass  # Sin setContent('videos'): contenido neutro para que Estuary pinte la carátula en la fila
        except Exception:
            pass
    fanart = _fanart_permitido()
    # Igual que en los listados: una sola llamada por pantalla. Aqui se nota mas, porque el
    # historial llega a 100 filas y todas pueden ser de RedTube.
    try:
        import core_settings
        modo_ligero = core_settings.is_modo_ligero_active()
    except Exception:
        modo_ligero = False
    thumbs = {} if modo_ligero else _thumbs_listados(items)
    for v in items:
        # "Quitar de favoritos" NO se pasa aqui: _fila_video ya lo pone cuando
        # `en_favoritos=True`, y con las dos cosas salia duplicado en el menu.
        _fila_video(v, en_favoritos=True, contexto_extra=[
            ("Borrar todos los favoritos",
             "RunPlugin({0})".format(_u(action="xxx_favs_clear")))], fanart=fanart, thumbs=thumbs, modo_ligero=modo_ligero)
    if items:
        _boton_accion("Borrar todos los favoritos", "xxx_favs_clear", ICO_FAVORITOS,
                      "Borra la lista de favoritos de esta sección.")
        _ordenes_de_ordenacion()
    xbmcplugin.endOfDirectory(_h())


def _transforma_lista(fich, transforma):
    """Lee, transforma y guarda una lista de la sección **bajo cerrojo**. Devuelve si se escribió.

    Las acciones que escriben favoritos o historial requieren cerrojo para evitar
    condiciones de carrera si se producen pulsaciones rápidas o accesos concurrentes.
    Sigue el mismo patrón que `fuentes_store._escribe_favoritos()`.

    **Un solo sitio para las cuatro**, que es lo que evita que la siguiente se quede sin
    cerrojo: con cuatro `with` repetidos, el que añagan mañana se les olvidará.

    Con el cerrojo ocupado no se escribe. Si no se puede crear (perfil raro, disco lleno) se
    sigue sin él, para no quedarse sin poder guardar favoritos.
    """
    import contextlib
    import iptv_store

    try:
        # `or "."` dos veces: sin ruta, o con un `get_path` que no da directorio, el perfil
        # sería "" y `os.makedirs("")` no crea nada.
        carpeta = os.path.dirname(_ruta_lista(fich) or ".") or "."
        cerrojo = iptv_store.Store(carpeta).lock(fich + ".lock")
    except Exception as e:
        _log("sin cerrojo para {0}: {1}".format(fich, e), xbmc.LOGWARNING)
        cerrojo = None

    if cerrojo is None:
        return transforma()

    # El cerrojo se toma con un `ExitStack` y no con un `with` a secas porque `lock()` es un
    # generador: con el `with`, el `os.makedirs` que hace dentro corre en el `__enter__`, y un
    # fallo ahí se escapaba del `try` de arriba. Con la pila se ve si se pudo entrar y, si no,
    # se sigue sin cerrojo en vez de perder el guardado.
    #
    # Un `LockBusy` que llegue al salir no se captura a propósito: si algo raro pasa ahí, que
    # salga al router y se vea como «este botón no ha funcionado», que es la verdad.
    with contextlib.ExitStack() as pila:
        try:
            pila.enter_context(cerrojo)
        except iptv_store.LockBusy:
            # Ocupado: otra pulsación en este instante. No se escribe, y eso es a
            # propósito: escribir sin el cerrojo es justo el fallo que se arregla.
            _log("otra escritura tiene el cerrojo de {0}".format(fich), xbmc.LOGWARNING)
            return False
        except Exception as e:
            # Sin cerrojo posible se guarda igual (ver docstring).
            _log("sin cerrojo para {0} ({1}), se sigue sin él".format(fich, e),
                 xbmc.LOGWARNING)
        return transforma()


def _guardar_fav(v):
    """Guarda un favorito y devuelve True si la escritura se completó correctamente.

    Lectura y escritura van bajo el mismo cerrojo. Ver `_transforma_lista()`.
    """
    vid = v.get("id", "")
    if not vid:
        return False

    def _haz():
        items = _leer_lista(FICH_FAVS)
        k = _clave(v.get("src", ""), vid)
        items = [f for f in items if _clave(f.get("src", ""), f.get("id", "")) != k]
        items.insert(0, v)
        return _guardar_lista(FICH_FAVS, items)

    if not _transforma_lista(FICH_FAVS, _haz):
        return False
    _notifica("Guardado en favoritos.")
    return True


def _quitar_fav(vid, src=""):
    """Bajo cerrojo, igual que `_guardar_fav()`. Ver `_transforma_lista()`."""

    def _haz():
        items = _leer_lista(FICH_FAVS)
        k = _clave(src, vid)
        quedan = [f for f in items if _clave(f.get("src", ""), f.get("id", "")) != k
                  and not (not src and f.get("id") == vid)]
        return _guardar_lista(FICH_FAVS, quedan)

    if not _transforma_lista(FICH_FAVS, _haz):
        return False
    xbmc.executebuiltin("Container.Refresh")
    return True


def fav_add(src, vid, titulo="", thumb="", length="", views="", rate="", added="", pagina=""):
    if not pin_gate():
        return
    titulo_limpio = _limpiar_emojis(titulo or vid) or vid
    v = {"src": src, "id": vid, "title": titulo_limpio, "thumb": api.fix_thumb(thumb),
         "length": length, "length_sec": api.dur_to_sec(length),
         "views": _numero(views), "rate": _numero(rate),
         # URL de la web del vídeo para la acción contextual.
         "page": pagina if isinstance(pagina, str) else ""}
    fecha = _fecha_de({"added": added})
    if fecha:
        v["added"] = fecha
    if not _guardar_fav(v):
        # Notificar si la persistencia en disco falla para evitar asumir un guardado inexistente.
        xbmcgui.Dialog().ok(NOMBRE, "No se ha podido guardar en favoritos. Comprueba que el "
                                    "disco no esté lleno ni el perfil sin permisos.")
        return
    xbmc.executebuiltin("Container.Refresh")


def fav_del(vid, src=""):
    if not pin_gate():
        return
    # `_quitar_fav()` hace el `Container.Refresh` solo si se ha escrito; aquí no se repite.
    if not _quitar_fav(vid, src):
        _aviso_escritura("los favoritos")


def favs_clear():
    # No se cierra el directorio con endOfDirectory si la acción se ejecutó desde el menú contextual (handle < 0).
    if not pin_gate():
        _cierra(_h(), succeeded=False)
        return
    if not xbmcgui.Dialog().yesno(NOMBRE, "¿Borrar todos los favoritos de esta sección?",
                                  nolabel="Cancelar", yeslabel="Borrar"):
        _cierra(_h(), succeeded=False)
        return
    if not _guardar_lista(FICH_FAVS, []):
        _aviso_escritura("los favoritos")
        return
    xbmc.executebuiltin("Container.Refresh")


# --------------------------------------------------------------- historial
def historial():
    if not _puertas():
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    _fin("{0} · Historial".format(NOMBRE))
    items = _leer_lista(FICH_HIST, tope=MAX_HIST)
    if not items:
        # Igual que en favoritos(): `setContent` despues de la rama vacia, para que la fila de
        # aviso conserve su icono en vez del arte generico del skin.
        _fila_dir("Todavía no has visto nada aquí.", {"action": "xxx_menu_plat", "src": "ep"},
                  ICO_BUSCAR,
                  "Abre una plataforma y reproduce algo.\n\n"
                  "El historial es propio de la sección.")
        _boton_accion("Volver al menú de la sección", "xxx_menu", ICO_BUSCAR,
                      "Atrás: vuelve al menú con las tres plataformas.",
                      is_folder=True)
    else:
        try:
            pass  # Sin setContent('videos'): contenido neutro para que Estuary pinte la carátula en la fila
        except Exception:
            pass
    # Las claves de favoritos se leen UNA vez: _fila_video sin `en_favoritos` las va a buscar
    # él, y con el historial lleno (100 filas) eran 100 lecturas y parseos del mismo JSON.
    fanart = _fanart_permitido()
    favs = _claves_favoritos()
    # Una sola vez para las 100 filas del historial, no una por fila (ver `_thumbs_listados`).
    try:
        import core_settings
        modo_ligero = core_settings.is_modo_ligero_active()
    except Exception:
        modo_ligero = False
    thumbs = {} if modo_ligero else _thumbs_listados(items)
    for v in items:
        _fila_video(v, en_favoritos=_clave(v.get("src"), v.get("id")) in favs,
                    contexto_extra=[
                        ("Quitar del historial", "RunPlugin({0})".format(
                            _u(action="xxx_hist_del", vid=v.get("id", ""),
                               src=v.get("src", "")))),
                        ("Borrar todo el historial",
                         "RunPlugin({0})".format(_u(action="xxx_hist_clear")))],
                    fanart=fanart, thumbs=thumbs, modo_ligero=modo_ligero)
    if items:
        _boton_accion("Borrar todo el historial", "xxx_hist_clear", ICO_HISTORIAL,
                      "Borra el historial de esta sección.")
        _ordenes_de_ordenacion()
    xbmcplugin.endOfDirectory(_h())


def _apuntar_hist(v):
    """Registra un vídeo en el historial bajo cerrojo."""

    def _haz():
        vid = v.get("id", "")
        if not vid:
            # Nada que apuntar, y no es un fallo: no hay que escribir.
            return True
        items = _leer_lista(FICH_HIST)
        # Por src:id y no solo por id: Eporner y RedTube usan ids numericos, asi que reproducir un
        # video de RedTube no puede borrar del historial el de Eporner con el mismo id.
        k = _clave(v.get("src", ""), vid)
        items = [f for f in items if _clave(f.get("src", ""), f.get("id", "")) != k]
        items.insert(0, v)
        return _guardar_lista(FICH_HIST, items[:MAX_HIST])

    _transforma_lista(FICH_HIST, _haz)


def _aviso_escritura(que):
    """Aviso unificado para operaciones de escritura que fallen en disco."""
    xbmcgui.Dialog().ok(NOMBRE, "No se ha podido guardar {0}. Comprueba que el disco no esté "
                                "lleno ni el perfil sin permisos.".format(que))


def hist_del(vid, src=""):
    """Bajo cerrojo, igual que `_guardar_fav()`."""
    if not pin_gate():
        return

    def _haz():
        items = _leer_lista(FICH_HIST)
        k = _clave(src, vid)
        quedan = [f for f in items if _clave(f.get("src", ""), f.get("id", "")) != k
                  and not (not src and f.get("id") == vid)]
        return _guardar_lista(FICH_HIST, quedan)

    if not _transforma_lista(FICH_HIST, _haz):
        _aviso_escritura("el historial")
        return
    xbmc.executebuiltin("Container.Refresh")


def hist_clear():
    if not pin_gate():
        _cierra(_h(), succeeded=False)
        return
    # Y aqui tambien `_cierra()`, no `endOfDirectory` a secas. Esta es la rama que MAS duele
    # porque es la NORMAL: se abre Favoritos o Historial, se pulsa el contexto, "Borrar todo", y
    # se dice que no. Ahi llega por `RunPlugin`, con handle -1, y el `endOfDirectory(-1)` solo
    # deja un "Invalid handle -1" en el log de Kodi. `favs_clear()` ya lo tenia; este se quedo.
    if not xbmcgui.Dialog().yesno(NOMBRE, "¿Borrar todo el historial de esta sección?",
                                  nolabel="Cancelar", yeslabel="Borrar"):
        _cierra(_h(), succeeded=False)
        return
    if not _guardar_lista(FICH_HIST, []):
        _aviso_escritura("el historial")
        return
    xbmc.executebuiltin("Container.Refresh")


# --------------------------------------------------------------- ajustes
# El texto del botón del log va en una constante, para que se lea aquí y no dentro de la tupla,
# donde quedaba en una línea de más de 500 caracteres que era ilegible. Se pega con `+` porque
# una tupla no admite un texto de varias líneas sin liar de paréntesis.
_PLOT_LOG_ON = (
    "Escribe en el log de Kodi cuando ocurre un error de conexión o reproducción en esta sección.\n\n"
    "Con «No» se desactivan estos avisos para mantener el log limpio."
)

OPCIONES = (
    # (clave, etiqueta, valores, es_booleano, plot)
    ("per_page", "Resultados por página", PAGINAS, False,
     "Cuántos vídeos trae Eporner en cada página.\n\n"
     "Solo afecta a Eporner: RedTube siempre trae 20 y Pornhub 30."),
    ("thumbsize", "Tamaño de las miniaturas", MINIATURAS, False,
     "Pequeñas (190 px), medianas o grandes (640 px). Solo Eporner."),
    ("order", "Orden por defecto", ORDENES, False,
     "El orden con el que salen las categorías y las búsquedas de Eporner.\n\n"
     "NO cambia los cuatro botones del menú de Eporner (Últimos, Top semanal, Top mensual, "
     "Más vistos): cada uno lleva su propio orden. Tampoco afecta a RedTube ni a Pornhub."),
    ("gay", "Contenido gay (Eporner y Pornhub)", GAY_OPCIONES, False,
      "Si Eporner y Pornhub dejan entrar el contenido gay en sus listados. «No» lo oculta, "
      "que es lo que la web de Eporner hace por su cuenta; «Sí, solo gay» enseña únicamente "
      "eso y «Sí» lo mezcla.\n\n"
      "Funciona en Eporner y Pornhub. Solo RedTube queda fuera porque no admite el filtro.\n\n"
      "La opción «Sí, solo gay» deja un listado con contenido gay y casi nada más: el "
      "91-99% de los títulos llevan temática gay y no comparte NI UNO de 100 vídeos con la "
      "opción «No».\n\n"
      "Las 30 categorías de RedTube que se muestran son todas «straight»."),

    ("quality", "Calidad del vídeo", CALIDADES, False,
     "Máxima se lleva la mejor fuente disponible; ahorro de datos elige la más pequeña.\n\n"
     "Afecta a las tres plataformas."),
    ("timeout", "Tiempo de espera de la red", TIEMPOS, False,
     "Segundos que se espera a cada plataforma antes de rendirse."),
    ("vista", "Tipo de vista de los menús", VISTAS, False,
     "WideList es la lista ancha de los skins de Kodi: el icono grande a la izquierda y el "
     "texto a la derecha, que es como se ven bien los iconos de esta sección. Con «La que trae el skin» se respeta la que tenga configurada.\n\n"
     "Solo afecta a los menús de carpetas (la raíz, las plataformas, buscar y categorías), no a los listados de vídeos."),
    ("adult_confirm", "Aviso +18 al entrar", ((True, "Sí"), (False, "No")), True,
     "Si está activado, la primera vez que entras te pide confirmar que eres mayor de edad.\n\n"
     "Apagarlo no cambia nada más: el contenido sigue siendo +18."),
    ("pin_on", "Cuándo pedir el PIN", MODOS_PIN, False,
     "«Al entrar» pide el PIN cada vez que abres la sección.\n\n"
     "«Una vez por sesión» solo la primera, hasta que reinicies Kodi.\n\n"
     "«Nunca» no lo pide."),
    ("pin_hash", "PIN de la sección", None, False,
     "Son 4 dígitos. Por defecto se usa el publicado en el canal de "
     "Telegram de EspaKodi (t.me/espadaily), donde puedes buscar «Sección X», «+18» o «XXX».\n\n"
     "Al pulsar esta fila tecleas el PIN nuevo, se te pide repetirlo para confirmar, y a partir "
     "de entonces se usa el tuyo: no vuelve a preguntar el de Telegram y este aviso desaparece.\n\n"
     "Del tuyo solo se guarda la huella, nunca el PIN en claro."),
    ("adult_ok", None, None, False, None),
    ("log_on", "Avisos en el log de Kodi", ((True, "Sí"), (False, "No")), True,
     _PLOT_LOG_ON),
    # Al FINAL a propósito: `xxx_set` va por URL con `?action=xxx_set&i=N` y el N es
    # posicional. Si este se metiera delante, `adult_confirm` (7) y `pin_on` (8) se
    # desplazarían y una URL escrita a mano apagaría una puerta distinta de la que su
    # autor cree. Hay un test que mira que esos dos índices no cambien, y este tiene que
    # quedar después de ellos.
)


def _texto_de(indice, valor):
    """El valor de un ajuste, en palabras."""
    clave, etiqueta, valores, es_bool, _plot = OPCIONES[indice]
    if clave == "pin_hash":
        cfg = _cfg()
        if _es_pin_publico(cfg):
            return "el de Telegram (público) - cambiar"
        return "el tuyo" if valor else "sin configurar"
    if clave in ("per_page", "timeout"):
        return "{0} s".format(valor) if clave == "timeout" else str(valor)
    for v, nombre in (valores or ()):
        if v == valor:
            return nombre
    return str(valor)


def _boton_de_ajuste(cfg, indice):
    """Un botón por ajuste: la etiqueta lleva el valor actual y el plot explica."""
    clave, etiqueta, _valores, _es_bool, plot = OPCIONES[indice]
    if etiqueta is None:
        return
    actual = _texto_de(indice, cfg.get(clave))
    if clave == "pin_hash":
        _boton_accion("{0}: [COLOR green]{1}[/COLOR]".format(etiqueta, actual),
                      "xxx_pin_cambiar", ICO_AJUSTES, plot)
        return
    color = "green" if clave in ("quality", "order") else "grey"
    _fila_dir("{0}: [COLOR {1}]{2}[/COLOR]".format(etiqueta, color, actual),
              {"action": "xxx_set", "i": indice}, ICO_AJUSTES, plot, is_folder=False)


def ajustes():
    """Ajustes de la sección, en botones. Mismo estilo que la sección de Opciones de EspaTV:
    el valor actual va en la etiqueta y el plot explica qué hace."""
    if not _puertas():
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    cfg = _cfg()
    _fin("{0} · Ajustes".format(NOMBRE))
    # También aquí: quien entra en Ajustes a cambiar el PIN se encuentra el aviso justo antes de
    # hacerlo, y quien ya lo ha cambiado no ve nada.
    _recuerda_cambiar_el_pin()
    for i in range(len(OPCIONES)):
        _boton_de_ajuste(cfg, i)
    _boton_accion("Vaciar caché de la sección", "xxx_cache_clear", ICO_AJUSTES,
                  "Olvida las listas que ya se han pedido, para que vuelvan a descargarse.")
    _boton_accion("Aviso legal y DMCA", "xxx_legal", ICO_AJUSTES,
                  "De quién es el contenido y dónde está el aviso de cada plataforma.")
    # Le faltaba, y es la última pantalla de carpetas de la sección sin ella: con la vista del
    # skin, 12 filas con el mismo icono y sin texto al lado.
    _forzar_vista_wide()
    xbmcplugin.endOfDirectory(_h())


def _claves_de(valores):
    """La lista de valores reales de un ajuste.

    Los ajustes con texto llevan pares (clave, rótulo) y los de número llevan el número solo.
    Recorrer los valores tal cual guardaba la tupla entera ("ahorro", "Ahorro de datos") en vez
    de la clave, y `_cfg()` lo tiraba en el siguiente volcado: el botón no hacía nada.
    """
    if not valores:
        return []
    primero = valores[0]
    if isinstance(primero, (list, tuple)):
        return [v[0] for v in valores]
    return list(valores)


def _avanzar(valor, claves, es_bool):
    if es_bool:
        return not valor
    if not claves:
        return valor
    actual = claves.index(valor) if valor in claves else 0
    return claves[(actual + 1) % len(claves)]


def ajuste_set(clave, i):
    """Un ajuste por action: la fila es un botón que va saltando de valor en valor.

    El segundo parámetro se llama `i` porque es el nombre de la clave en la URL, igual que
    `play()` y sus demas. El dispatcher los pasa posicionalmente.

    Pide el PIN, y no por casualidad: `xxx_set` es la acción que escribe en disco los dos
    ajustes que gobiernan las puertas (`pin_on` y `adult_confirm`). Sin puerta, unas pocas
    URLs escritas a mano (`?action=xxx_set&i=7` y `&i=8`) apagaban las dos puertas sin
    preguntar nada, y el estado sobrevive a reiniciar Kodi.

    Los índices son 7 y 8 porque `_AVISOS` cuenta también `adult_ok`, que no sale en pantalla.
    Con la tupla de `OPCIONES` de hoy son: 0 per_page, 1 thumbsize, 2 order, 3 gay, 4 quality,
    5 timeout, 6 vista, 7 adult_confirm, 8 pin_on, 9 pin_hash, 10 adult_ok. Si se añade o quita
    un ajuste delante, este comentario hay que rehacerlo: hay un test que mira que el índice de
    `pin_on` sea el que dice.
    """
    if not pin_gate():
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    cfg = _cfg()
    try:
        real, etiqueta, valores, es_bool, _plot = OPCIONES[int(i)]
    except (TypeError, ValueError, IndexError):
        # `i=abc`, `i=` o `i=99999` desde una URL a mano: el directorio se cierra y no
        # aparece el dialogo de error generico de EspaTV con la pantalla colgada.
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    if int(i) < 0 or etiqueta is None:
        # Los negativos viven en la tupla (Python cuenta hacia atras) y `adult_ok` no se
        # cambia desde aqui: se cambia confirmando el aviso de +18.
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    cfg[real] = _avanzar(cfg.get(real), _claves_de(valores), es_bool)
    if not _guardar_cfg(cfg):
        # Si falla el guardado, se avisa para no repintar la interfaz con un valor no persistido.
        _aviso_escritura("el ajuste")
        return
    # Update en vez de Refresh: el submenú se redibuja y no se queda con la lista anterior.
    xbmc.executebuiltin("Container.Update({0},replace)".format(_u(action="xxx_ajustes")))


def cache_clear():
    # Puerta del PIN, pero no la de la edad: esto no enseña contenido, y pedir las dos sería
    # preguntar dos veces por vaciar una papelera.
    if not _puertas(con_edad=False):
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    api.limpiar_cache()
    # Las miniaturas de RedTube en disco también forman parte de la caché local.
    _vaciar_thumbs_rt()
    _notifica("Caché de la sección vaciada.")
    # Cierra el directorio para evitar bloqueos de resolución en Kodi.
    _cierra(_h())


def legal():
    # Puerta del PIN y no la de la edad: un aviso legal no es contenido adulto.
    if not _puertas(con_edad=False):
        xbmcplugin.endOfDirectory(_h(), succeeded=False)
        return
    xbmcgui.Dialog().ok(
        NOMBRE,
        "Contenido +18. Solo para adultos.\n\n"
        "Todo el contenido pertenece a cada plataforma y a sus usuarios.\n\n"
        "DMCA y contacto:\n"
        "· Eporner: https://www.eporner.com/dmca/\n"
        "· RedTube y Pornhub: en sus propias webs.\n\n"
        "El PIN de acceso se publica en el canal de Telegram de EspaKodi (t.me/espadaily).")
    # Cerrar el directorio, por lo mismo que `cache_clear()`: es un botón y no pinta nada, así
    # que sin esto Kodi se queda sin resolución.
    _cierra(_h())


def abrir_web(src, vid, pagina=""):
    """'Abrir en la web' del menú contextual: la página del vídeo en el navegador del sistema.

    Reutiliza `abrir_url()` de espakodi_installer, que es la vía del proyecto: pregunta antes,
    avisa de "Abriendo la web..." en Android y, si el navegador no abre, muestra la URL para
    copiarla. Si ese módulo no está (no debería), se cae a `webbrowser` y luego al diálogo con
    la URL, que es lo que nunca debe faltar: el usuario tiene que poder llegar al vídeo.

    Pide el PIN y el aviso +18 como el resto de la sección. Con la sesión ya desbloqueada y el
    aviso ya confirmado, ninguna de las dos vuelve a preguntar.
    """
    if not pin_gate():
        return
    if not adult_gate():
        return
    url = api.url_web(src, vid, pagina)
    if not url:
        xbmcgui.Dialog().notification(NOMBRE, "No sé qué vídeo es ese.",
                                      xbmcgui.NOTIFICATION_ERROR, 3000)
        return
    pregunta = ("Se va a abrir en el navegador del sistema: {0}.\n\n"
                "La web enseña su propio reproductor y su publicidad, y ya puede tener la edad "
                "que tenga. Aquí dentro no.".format(api.NOMBRES.get(src, NOMBRE)))
    # El try se limita al import: un fallo de abrir_url (que solicita confirmación al usuario)
    # no debe derivar en aperturas de URL no autorizadas.
    try:
        import espakodi_installer
    except Exception as e:
        _log("espakodi_installer no disponible: {0}".format(e), xbmc.LOGWARNING)
    else:
        espakodi_installer.abrir_url(url, NOMBRE, pregunta, "Abriendo la web...")
        return
    try:
        import webbrowser
        if webbrowser.open(url):
            return
    except Exception as e:
        _log("webbrowser no pudo abrir: {0}".format(e), xbmc.LOGWARNING)
    xbmcgui.Dialog().ok(NOMBRE, "No se pudo abrir el navegador.\n\nAbre a mano:\n{0}".format(url))


# ------------------------------------------------------------- reproducción
def play(src, vid, titulo="", length="", views="", rate="", thumb="", added="", pagina=""):
    """Resuelve y reproduce. La URL firmada se pide en el momento y no se cachea.

    Los nombres de los parámetros coinciden con las claves de la URL para compatibilidad con el dispatcher.
    """
    if not pin_gate():
        _no_resuelto(_h())
        return
    # Validación +18 directa para evitar invocación directa por URL sin pasar por el menú.
    if not adult_gate():
        _no_resuelto(_h())
        return
    cfg = _cfg()
    if not vid:
        xbmcgui.Dialog().notification(NOMBRE, "No sé qué vídeo es ese.",
                                      xbmcgui.NOTIFICATION_ERROR, 3000)
        _no_resuelto(_h())
        return
    titulo_limpio = _limpiar_emojis(titulo or vid) or vid
    entrada_hist = {"src": src, "id": vid, "title": titulo_limpio,
                    "thumb": api.fix_thumb(thumb),
                    "length": length, "length_sec": api.dur_to_sec(length),
                    "views": _numero(views), "rate": _numero(rate),
                    "page": pagina if isinstance(pagina, str) else ""}
    fecha = _fecha_de({"added": added})
    if fecha:
        entrada_hist["added"] = fecha
    url, motivo = "", ""
    try:
        dlg = xbmcgui.DialogProgress()
        dlg.create(NOMBRE, "Buscando el vídeo...")
        try:
            url, motivo = api.resolver(src, vid, quality=cfg["quality"],
                                       timeout=cfg["timeout"])
        except Exception as e:
            _log("resolve {0}: {1}".format(src, e), xbmc.LOGWARNING)
            url, motivo = "", "No se ha podido buscar el vídeo."
        # Si el usuario canceló el diálogo durante la resolución, se descarta el resultado.
        if url:
            try:
                if dlg.iscanceled():
                    url, motivo = "", "Has cancelado."
            except Exception:
                pass
    except Exception as e:
        _log("diálogo de progreso: {0}".format(e), xbmc.LOGWARNING)
        url, motivo = "", ""
    finally:
        try:
            dlg.close()
        except Exception:
            pass

    if not url:
        # Diálogo modal informativo con el motivo de fallo devuelto por el resolver o la red.
        xbmcgui.Dialog().ok(
            NOMBRE,
            (motivo or "No se ha podido reproducir.") +
            "\n\nPuede ser que no tengas conexión, que el vídeo se haya retirado de la web "
            "o que tenga un límite temporal de descargas. Prueba otra vez o elige otro vídeo.")
        _no_resuelto(_h())
        return

    # El vídeo solo se registra en el historial una vez resuelta la URL con éxito.
    try:
        _apuntar_hist(entrada_hist)
    except Exception as e:
        _log("historial {0}: {1}".format(src, e), xbmc.LOGWARNING)

    # El Referer va con quote_plus y el UA con ua_desktop_pipe_encoded: parse_url_with_headers
    # no hace unquote, y el UA de Chrome lleva espacios y paréntesis.
    ref = urllib.parse.quote_plus(api.referer_de(src))
    destino = "{0}|User-Agent={1}&Referer={2}".format(url, ua_desktop_pipe_encoded(), ref)
    li = xbmcgui.ListItem(path=destino)
    li.setInfo("video", {"title": titulo_limpio})
    xbmcplugin.setResolvedUrl(_h(), True, listitem=li)