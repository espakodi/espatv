# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""RTVE Play: directos + catálogo (api.rtve.es y streams ztnr.rtve.es)."""
import base64
import hashlib
import io
import json
import os
import re
import struct
import sys
import time
import urllib.request
from urllib.parse import urlencode, quote

import xbmc
import xbmcgui
import xbmcplugin

try:
    import requests
except ImportError:
    requests = None

import core_settings


_API_BASE = "https://www.rtve.es/api"

_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'resources', 'media')

_RTVE_LIVE_CHANNELS = [
    {
        "name": "La 1",
        "video_id": "1688877",
        "logo": os.path.join(_MEDIA, "rtve_la1.png"),
        "plot": "Canal generalista de RTVE con informativos, series, entretenimiento y deportes.",
    },
    {
        "name": "La 2",
        "video_id": "1688885",
        "logo": os.path.join(_MEDIA, "rtve_la2.png"),
        "plot": "Canal cultural de RTVE con documentales, cine y programas de divulgación.",
    },
    {
        "name": "Canal 24 Horas",
        "video_id": "1694255",
        "logo": os.path.join(_MEDIA, "rtve_24h.png"),
        "plot": "Canal de noticias 24 horas de RTVE.",
    },
    {
        "name": "Teledeporte",
        "video_id": "1712295",
        "logo": os.path.join(_MEDIA, "rtve_teledeporte.png"),
        "plot": "Canal deportivo de RTVE.",
    },
    {
        "name": "Clan TVE",
        "video_id": "5466990",
        "logo": os.path.join(_MEDIA, "rtve_clan.png"),
        "plot": "Canal infantil de RTVE.",
    },
]

# IDs de api.rtve.es/api/tematicas/
_RTVE_CATEGORIES = [
    {"name": "Series", "id": "864", "icon": os.path.join(_MEDIA, 'rtve_series.png')},
    {"name": "Cine", "id": "866", "icon": os.path.join(_MEDIA, 'rtve_cine.png')},
    {"name": "Documentales", "id": "863", "icon": os.path.join(_MEDIA, 'rtve_documentales.png')},
    {"name": "Informativos", "id": "862", "icon": os.path.join(_MEDIA, 'rtve_informativos.png')},
    {"name": "Entretenimiento", "id": "102610", "icon": os.path.join(_MEDIA, 'rtve_entretenimiento.png')},
    {"name": "Deportes", "id": "867", "icon": os.path.join(_MEDIA, 'rtve_deportes.png')},
    {"name": "Infantiles", "id": "865", "icon": os.path.join(_MEDIA, 'rtve_infantiles.png')},
    {"name": "Cultura", "id": "40270", "icon": os.path.join(_MEDIA, 'rtve_cultura.png')},
    {"name": "Música", "id": "102614", "icon": os.path.join(_MEDIA, 'rtve_musica.png')},
    {"name": "Cocina", "id": "102611", "icon": os.path.join(_MEDIA, 'rtve_cocina.png')},
    {"name": "Concursos", "id": "102613", "icon": os.path.join(_MEDIA, 'rtve_concursos.png')},
    {"name": "Humor", "id": "102615", "icon": os.path.join(_MEDIA, 'rtve_humor.png')},
]


def _log(msg):
    xbmc.log("[EspaTV][rtve] {0}".format(msg), xbmc.LOGINFO)


def _log_error(msg):
    xbmc.log("[EspaTV][rtve] ERROR: {0}".format(msg), xbmc.LOGERROR)


def _handle():
    return int(sys.argv[1])


def _u(**kwargs):
    return "{0}?{1}".format(sys.argv[0], urlencode(kwargs))


from _user_agents import UA_DESKTOP

_HEADERS = {
    "User-Agent": UA_DESKTOP,
}


def _fetch_json(url, timeout=15, default_ttl=0):
    cache_file = None
    ttl = core_settings.get_iptv_cache_ttl(default_ttl=default_ttl)
    if ttl > 0:
        cache_dir = core_settings.get_iptv_cache_dir()
        cache_key = hashlib.md5(url.encode("utf-8")).hexdigest()
        cache_file = os.path.join(cache_dir, "rtvecat_" + cache_key + ".json")
        if os.path.exists(cache_file):
            try:
                with open(cache_file, "r", encoding="utf-8") as f:
                    cached = json.load(f)
                if (time.time() - cached.get("ts", 0)) < ttl:
                    return cached.get("content", {})
            except (OSError, ValueError):
                pass

    if requests:
        r = requests.get(url, headers=_HEADERS, timeout=timeout)
        r.raise_for_status()
        data = r.json()
    else:
        req = urllib.request.Request(url, headers=_HEADERS)
        with urllib.request.urlopen(req, timeout=timeout) as resp:
            data = json.loads(resp.read().decode("utf-8"))

    if cache_file:
        try:
            core_settings.atomic_write_json(cache_file, {"ts": time.time(), "url": url, "content": data})
        except OSError:
            pass

    return data


def _get_ztnr_alphabet(alphabet_data):
    alphabet = []
    e = 0
    d = 0
    for char in alphabet_data.decode("iso-8859-1"):
        if d == 0:
            alphabet.append(char)
            d = e = (e + 1) % 4
        else:
            d -= 1
    return alphabet


def _get_ztnr_url(alphabet, url_data):
    url = ""
    f = 0
    e = 3
    b = 1
    for char in url_data.decode("iso-8859-1"):
        if f == 0:
            l = int(char) * 10
            f = 1
        else:
            if e == 0:
                l += int(char)
                if 0 <= l < len(alphabet):
                    url += alphabet[l]
                e = (b + 3) % 4
                f = 0
                b += 1
            else:
                e -= 1
    return url


def _decrypt_ztnr_png(raw_b64):
    try:
        data = base64.b64decode(raw_b64)
    except (ValueError, TypeError):
        return []
    if len(data) < 8:
        return []

    encrypted_data = io.BytesIO(data[8:])
    streams = []
    while True:
        length_data = encrypted_data.read(4)
        if len(length_data) < 4:
            break
        length = struct.unpack("!I", length_data)[0]
        chunk_type = encrypted_data.read(4)
        if chunk_type == b"IEND":
            break
        chunk_bytes = encrypted_data.read(length)
        if chunk_type == b"tEXt":
            filtered = bytes(filter(None, chunk_bytes))
            alphabet_data, _, url_data = filtered.partition(b"#")
            quality_str, _, url_data = url_data.rpartition(b"%%")
            alphabet = _get_ztnr_alphabet(alphabet_data)
            url = _get_ztnr_url(alphabet, url_data)
            if url.startswith(("http://", "https://")):
                streams.append((quality_str.decode("iso-8859-1", errors="ignore"), url))
        encrypted_data.read(4)
    return streams


def _get_ztnr_streams(video_id):
    """Obtiene y desofusca las URLs directas (HLS/MP4) de RTVE sin DRM."""
    vid = str(video_id).strip()
    if not vid:
        return []
    if not vid.isdigit() and "/" in vid:
        parts = [p for p in vid.rstrip("/").split("/") if p.isdigit()]
        if parts:
            vid = parts[-1]

    headers = {
        "User-Agent": _HEADERS["User-Agent"],
        "Referer": "https://www.rtve.es/",
    }
    for manager in ("rtveplayw", "default"):
        url = "http://www.rtve.es/ztnr/movil/thumbnail/{0}/videos/{1}.png?q=v2".format(
            manager, vid
        )
        try:
            req = urllib.request.Request(url, headers=headers)
            with urllib.request.urlopen(req, timeout=10) as resp:
                raw_data = resp.read()
            if not raw_data:
                continue
            streams = _decrypt_ztnr_png(raw_data)
            if streams:
                _log("ZTNR stream obtenido con éxito ({0}) para {1}: {2} streams".format(
                    manager, vid, len(streams)
                ))
                return streams
        except (OSError, ValueError) as e:
            _log("ZTNR intento {0} para {1}: {2}".format(manager, vid, e))
    return []


def _play_direct_stream(stream_url, title="", video_id=""):
    """Reproduce un stream directo (HLS o MP4) resuelto por ZTNR sin DRM."""
    h = _handle()
    _log("Reproduciendo stream directo ZTNR: {0} → {1}".format(title, stream_url))
    try:
        li = xbmcgui.ListItem(path=stream_url)
        if title:
            try:
                info_tag = li.getVideoInfoTag()
                info_tag.setMediaType("video")
                info_tag.setTitle(title)
            except AttributeError:
                li.setInfo("video", {"title": title})

        headers = {
            "User-Agent": _HEADERS["User-Agent"],
            "Referer": "https://www.rtve.es/",
            "Origin": "https://www.rtve.es",
        }
        headers_string = "&".join(
            ["{0}={1}".format(k, quote(v)) for k, v in headers.items()]
        )

        if ".m3u8" in stream_url.lower():
            li.setProperty("inputstream", "inputstream.adaptive")
            li.setProperty("inputstream.adaptive.manifest_type", "hls")
            li.setProperty("inputstream.adaptive.manifest_headers", headers_string)
            li.setProperty("inputstream.adaptive.stream_headers", headers_string)
            li.setMimeType("application/vnd.apple.mpegurl")
        elif ".mp4" in stream_url.lower():
            li.setMimeType("video/mp4")

        li.setContentLookup(False)

        if video_id:
            try:
                sub_url = "https://www.rtve.es/api/videos/{0}/subtitulos.json".format(video_id)
                sub_data = _fetch_json(sub_url)
                sub_items = sub_data.get("page", {}).get("items", [])
                subs = [s["src"] for s in sub_items if s.get("src")]
                if subs:
                    li.setSubtitles(subs)
                    _log("Subtítulos cargados para {0}: {1}".format(video_id, subs))
            except (OSError, ValueError):
                pass

        xbmcplugin.setResolvedUrl(h, True, li)
    except (RuntimeError, OSError) as e:
        _log_error("direct stream play error: {0}".format(e))
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification(
            "RTVE Play", "Error al reproducir",
            xbmcgui.NOTIFICATION_ERROR, 3000)


def _play_drm_stream(video_id, title=""):
    """Reproduce un MPD de RTVE con Widevine vía inputstream.adaptive."""
    h = _handle()
    stream_url = "https://ztnr.rtve.es/ztnr/{0}.mpd".format(video_id)
    _log("DRM play: {0} → {1}".format(title, stream_url))

    license_url = ""
    token = ""
    try:
        token_url = "{0}/token/{1}".format(_API_BASE, video_id)
        token_data = _fetch_json(token_url)
        license_url = token_data.get("widevineURL", "")
        token = token_data.get("token", "")
        _log("Widevine URL: {0}".format(license_url))
    except (OSError, ValueError) as e:
        _log_error("Token error: {0}".format(e))

    headers = {
        "User-Agent": _HEADERS["User-Agent"],
        "Referer": "https://www.rtve.es/",
        "Origin": "https://www.rtve.es",
        "Accept": "*/*",
    }
    headers_string = "&".join(
        ["{0}={1}".format(k, quote(v)) for k, v in headers.items()]
    )

    try:
        li = xbmcgui.ListItem(path=stream_url)
        if title:
            info_tag = li.getVideoInfoTag()
            info_tag.setMediaType("video")
            info_tag.setTitle(title)

        li.setProperty("inputstream", "inputstream.adaptive")
        li.setProperty("inputstream.adaptive.manifest_type", "mpd")
        li.setProperty("inputstream.adaptive.manifest_headers", headers_string)
        li.setProperty("inputstream.adaptive.stream_headers", headers_string)

        if license_url:
            li.setProperty("inputstream.adaptive.license_type",
                           "com.widevine.alpha")
            lic_parts = [
                "User-Agent={0}".format(quote(_HEADERS["User-Agent"])),
                "Origin={0}".format(quote("https://www.rtve.es")),
                "Referer={0}".format(quote("https://www.rtve.es/")),
                "Content-Type={0}".format(quote("application/octet-stream")),
            ]
            if token:
                lic_parts.append("X-AxDRM-Message={0}".format(token))
            lic_headers = "&".join(lic_parts)
            lic_key = "{0}|{1}|R{{SSM}}|R".format(license_url, lic_headers)
            li.setProperty("inputstream.adaptive.license_key", lic_key)

        li.setMimeType("application/dash+xml")
        li.setContentLookup(False)

        li.setProperty("inputstream.adaptive.stream_selection_type", "adaptive")

        xbmcplugin.setResolvedUrl(h, True, li)
        _log("DRM stream iniciado para: {0}".format(title))

    except (RuntimeError, OSError) as e:
        _log_error("DRM play error: {0}".format(e))
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        xbmcgui.Dialog().notification(
            "RTVE Play", "Error al reproducir",
            xbmcgui.NOTIFICATION_ERROR, 3000)


def main_menu():
    h = _handle()

    li = xbmcgui.ListItem(
        label="[B][COLOR red]RTVE en Directo[/COLOR][/B]"
    )
    li.setArt({"icon": os.path.join(_MEDIA, 'rtve_directo.png')})
    li.setInfo("video", {"plot": "Canales de RTVE en directo:\n"
                                 "La 1, La 2, 24h, Teledeporte, Clan"})
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="rtve_live"), listitem=li, isFolder=True
    )

    for cat in _RTVE_CATEGORIES:
        li = xbmcgui.ListItem(label=cat["name"])
        li.setArt({"icon": cat["icon"]})
        li.setInfo("video", {"plot": "Programas de RTVE: {0}".format(
            cat["name"])})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="rtve_category", cat_id=cat["id"],
                   cat_name=cat["name"]),
            listitem=li,
            isFolder=True,
        )

    li = xbmcgui.ListItem(
        label="[COLOR dodgerblue][B]Buscar en RTVE[/B][/COLOR]")
    li.setArt({"icon": os.path.join(_MEDIA, "rtve_buscar.png")})
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="rtve_search"), listitem=li, isFolder=False
    )

    xbmcplugin.endOfDirectory(h, cacheToDisc=True)


def live_channels():
    h = _handle()
    fanart_directo = os.path.join(_MEDIA, "rtve_directo.png")
    for ch in _RTVE_LIVE_CHANNELS:
        li = xbmcgui.ListItem(label="[B]{0}[/B]".format(ch["name"]))
        li.setArt({
            "icon": ch["logo"],
            "thumb": ch["logo"],
            "poster": ch["logo"],
            "fanart": fanart_directo,
        })
        li.setInfo("video", {"title": ch["name"], "plot": ch["plot"]})
        li.setProperty("IsPlayable", "true")
        cm = [("Añadir a Favoritos", "RunPlugin({0})".format(
            _u(action="add_favorite", title=ch["name"],
               fav_url=ch["video_id"], icon=ch["logo"],
               platform="rtve", fav_action="play_rtve_live",
               params=json.dumps({}))
        ))]
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="play_rtve_live", url=ch["video_id"],
                   title=ch["name"]),
            listitem=li,
            isFolder=False,
        )
    xbmcplugin.endOfDirectory(h, cacheToDisc=True)


def play_live(url, title=""):
    streams = _get_ztnr_streams(url)
    if streams:
        chosen_url = None
        for _, u in streams:
            if ".m3u8" in u.lower():
                chosen_url = u
                break
        if not chosen_url:
            chosen_url = streams[0][1]

        # Si el stream HLS entregado por ZTNR trae cifrado Apple FairPlay (_drm.m3u8),
        # sanitizar a la variante limpia sin DRM (_main_dvr.m3u8) emitida en abierto por RTVE.
        if "_drm.m3u8" in chosen_url.lower():
            clean_url = re.sub(r'_drm\.m3u8', '.m3u8', chosen_url, flags=re.IGNORECASE)
            _log("Directo HLS FairPlay detectado; sanitizando a stream limpio sin DRM: {0}".format(clean_url))
            chosen_url = clean_url

        _play_direct_stream(chosen_url, title, url)
        return

    _play_drm_stream(url, title)


def _parent_cat_icon(cat_id, parent_id=""):
    for target in (cat_id, parent_id):
        if target:
            for c in _RTVE_CATEGORIES:
                if str(c.get("id")) == str(target):
                    ico = c.get("icon", "")
                    if ico and os.path.isfile(ico):
                        return ico
    fallback = os.path.join(_MEDIA, "rtve_series.png")
    return fallback if os.path.isfile(fallback) else "DefaultVideo.png"


def category(cat_id, cat_name="", page=1, parent_id=""):
    h = _handle()
    dp = xbmcgui.DialogProgress()
    dp.create("RTVE Play", "Cargando {0}...".format(cat_name or "categoría"))
    try:
        dp.update(20, "Cargando subcategorías...")
        # Intentar hijos (subcarpetas de programas)
        hijos_url = "https://api.rtve.es/api/tematicas/{0}/hijos.json?page={1}".format(
            cat_id, page)
        data = _fetch_json(hijos_url, default_ttl=3600)
        hijos = data.get("page", {}).get("items", [])

        if hijos:
            fallback_img = _parent_cat_icon(cat_id, parent_id)

            def _es_temporada(item):
                uid = str(item.get("uid", ""))
                title = str(item.get("title", "")).lower()
                return uid.startswith("ALC_") or uid.startswith("SEA_") or "temporada" in title

            def _es_taxonomia_pura(item):
                # Categorías abstractas o taxonomías viejas (como 101) no tienen ficha de programa
                if str(cat_id) == "101" or str(parent_id) == "101":
                    return True
                uid = str(item.get("uid", ""))
                return uid.startswith("TAX_")

            _season_img_map = {}
            if not core_settings.is_modo_ligero_active() and any(_es_temporada(it) for it in hijos):
                for cand_id in (cat_id, parent_id):
                    if not cand_id:
                        continue
                    try:
                        temps_url = "https://www.rtve.es/api/programas/{0}/temporadas.json".format(cand_id)
                        temps_data = _fetch_json(temps_url, timeout=6, default_ttl=3600)
                        temps_items = temps_data.get("page", {}).get("items", [])
                        if temps_items:
                            for t in temps_items:
                                t_id = str(t.get("id", ""))
                                t_img = (t.get("image", "") or t.get("imgPoster", "") or
                                         t.get("imgPortada", "") or t.get("thumbnail", "") or "")
                                if t_id and t_img:
                                    _season_img_map[t_id] = t_img
                            break
                    except (OSError, ValueError, KeyError, TypeError):
                        pass

                # Fallback al póster general de la serie
                if _season_img_map and cat_id:
                    try:
                        prog_card = _fetch_json("https://www.rtve.es/api/programas/{0}".format(cat_id), timeout=4, default_ttl=3600)
                        prog_items = prog_card.get("page", {}).get("items") or [{}]
                        if prog_items:
                            p_info = prog_items[0]
                            serie_poster = (p_info.get("imgPoster", "") or p_info.get("imgCol", "") or
                                            p_info.get("thumbnail", "") or "")
                            if serie_poster:
                                fallback_img = serie_poster
                    except (OSError, ValueError, KeyError, TypeError):
                        pass

            def _obtener_metadatos_prog(item):
                item_id = str(item.get("id", ""))
                desc = item.get("shortDescription", item.get("description", "")) or ""
                img = (item.get("imgPoster", "") or item.get("imgCol", "") or
                       item.get("thumbnail", "") or item.get("image", "") or "")
                # Evita 404 en /api/programas/ para temporadas
                if not img and _season_img_map and _es_temporada(item):
                    img = _season_img_map.get(item_id, "")
                if not img and not core_settings.is_modo_ligero_active() and not _es_taxonomia_pura(item) and not _es_temporada(item):
                    try:
                        prog_url = "https://www.rtve.es/api/programas/{0}".format(item_id)
                        prog_data = _fetch_json(prog_url, timeout=6, default_ttl=3600)
                        prog_items = prog_data.get("page", {}).get("items") or [{}]
                        prog_info = prog_items[0] if prog_items else {}
                        img = (prog_info.get("imgPoster", "") or
                               prog_info.get("imgCol", "") or
                               prog_info.get("thumbnail", "") or
                               prog_info.get("imgBackground", "") or "")
                        if not desc:
                            desc = prog_info.get("shortDescription", prog_info.get("description", "")) or ""
                    except (OSError, ValueError, IndexError, KeyError, TypeError):
                        pass
                if not img:
                    img = fallback_img
                return img, desc

            necesitan_red = [
                it for it in hijos
                if not core_settings.is_modo_ligero_active()
                and not _es_taxonomia_pura(it)
                and not _es_temporada(it)  # temporadas ya resueltas con _season_img_map
                and not (it.get("imgPoster") or it.get("thumbnail") or it.get("image"))
            ]

            meta_map = {}
            if len(necesitan_red) > 1:
                dp.update(60, "Procesando {0} programas...".format(len(hijos)))
                import concurrent.futures
                with concurrent.futures.ThreadPoolExecutor(max_workers=4) as executor:
                    fut_to_item = {executor.submit(_obtener_metadatos_prog, it): it for it in necesitan_red}
                    for fut in concurrent.futures.as_completed(fut_to_item):
                        it = fut_to_item[fut]
                        try:
                            meta_map[str(it.get("id", ""))] = fut.result()
                        except Exception:
                            meta_map[str(it.get("id", ""))] = (fallback_img, it.get("shortDescription", ""))

            dp.close()

            for item in hijos:
                item_id = str(item.get("id", ""))
                name = item.get("title", item.get("name", "Sin título"))
                img, desc = meta_map.get(item_id) or _obtener_metadatos_prog(item)

                li = xbmcgui.ListItem(label=name)
                li.setArt({"thumb": img, "icon": img, "poster": img})
                li.setInfo("video", {"title": name, "plot": desc})
                rtve_web_url = "https://www.rtve.es/play/buscador/?query={0}".format(
                    quote(name))
                cm = [
                    ("Buscar en Dailymotion", "Container.Update({0})".format(
                        _u(action="lfr", q=name, ot=""))),
                    ("Ver en RTVE.es", "RunPlugin({0})".format(
                        _u(action="rtve_open_web", url=rtve_web_url, title=name))),
                ]
                li.addContextMenuItems(cm)
                xbmcplugin.addDirectoryItem(
                    handle=h,
                    url=_u(action="rtve_category", cat_id=item_id,
                           cat_name=name, parent_id=cat_id),
                    listitem=li,
                    isFolder=True,
                )

            total_pages = data.get("page", {}).get("totalPages", 1)
            current_page = data.get("page", {}).get("number", 1)

            if current_page > 1:
                li = xbmcgui.ListItem(
                    label="[COLOR yellow]← Página anterior ({0}/{1})[/COLOR]".format(
                        current_page - 1, total_pages))
                li.setArt({"icon": "DefaultFolder.png"})
                xbmcplugin.addDirectoryItem(
                    handle=h,
                    url=_u(action="rtve_category", cat_id=cat_id,
                           cat_name=cat_name, page=current_page - 1,
                           parent_id=parent_id),
                    listitem=li, isFolder=True)

            if current_page < total_pages:
                li = xbmcgui.ListItem(
                    label="[COLOR limegreen]Página siguiente ({0}/{1})[/COLOR]".format(
                        current_page + 1, total_pages))
                li.setArt({"icon": "DefaultFolder.png"})
                xbmcplugin.addDirectoryItem(
                    handle=h,
                    url=_u(action="rtve_category", cat_id=cat_id,
                           cat_name=cat_name, page=current_page + 1,
                           parent_id=parent_id),
                    listitem=li, isFolder=True)

            xbmcplugin.endOfDirectory(h, cacheToDisc=True)
            return

        # Si no hay hijos, intentar vídeos directos
        dp.update(40, "Buscando vídeos...")
        items = []

        # Si tenemos parent_id, usar API de programas/temporadas (series)
        if parent_id:
            try:
                season_url = "https://www.rtve.es/api/programas/{0}/temporadas/{1}/videos.json?page={2}&size=20".format(
                    parent_id, cat_id, page)
                _log("Intentando temporada: {0}".format(season_url))
                data = _fetch_json(season_url, default_ttl=3600)
                items = data.get("page", {}).get("items", [])
            except (OSError, ValueError) as e:
                _log("Temporada API falló: {0}, usando fallback".format(e))
                items = []

        # Fallback: API de tematicas (para categorías sin temporadas)
        if not items:
            videos_url = "https://api.rtve.es/api/tematicas/{0}/videos.json?page={1}".format(
                cat_id, page)
            data = _fetch_json(videos_url, default_ttl=3600)
            items = data.get("page", {}).get("items", [])

        dp.update(70, "Procesando {0} vídeos...".format(len(items)))
        dp.close()

        if not items:
            xbmcgui.Dialog().notification(
                "RTVE Play", "No se encontraron vídeos",
                xbmcgui.NOTIFICATION_INFO, 3000)
            xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
            return

        for item in items:
            _add_video_item(h, item)

        total_pages = data.get("page", {}).get("totalPages", 1)
        current_page = data.get("page", {}).get("number", 1)

        if current_page > 1:
            li = xbmcgui.ListItem(
                label="[COLOR yellow]← Página anterior ({0}/{1})[/COLOR]".format(
                    current_page - 1, total_pages))
            li.setArt({"icon": "DefaultFolder.png"})
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="rtve_category", cat_id=cat_id,
                       cat_name=cat_name, page=current_page - 1,
                       parent_id=parent_id),
                listitem=li, isFolder=True)

        if current_page < total_pages:
            li = xbmcgui.ListItem(
                label="[COLOR limegreen]Página siguiente ({0}/{1})[/COLOR]".format(
                    current_page + 1, total_pages))
            li.setArt({"icon": "DefaultFolder.png"})
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="rtve_category", cat_id=cat_id,
                       cat_name=cat_name, page=current_page + 1,
                       parent_id=parent_id),
                listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(h, cacheToDisc=True)

    except (OSError, ValueError, KeyError) as e:
        dp.close()
        _log_error("category: {0}".format(e))
        xbmcgui.Dialog().ok("RTVE Play", "Error al cargar:\n{0}".format(e))
        try:
            xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        except RuntimeError:
            pass


def _add_video_item(h, item):
    title = item.get("title", item.get("name", "Sin título"))
    desc = item.get("shortDescription", item.get("description", "")) or ""
    thumb = item.get("thumbnail", item.get("imageSEO", "")) or ""
    if not thumb:
        thumb = "DefaultVideo.png"
    try:
        duration = int(item.get("duration", 0) or 0)
    except (ValueError, TypeError):
        duration = 0
    pub_date = item.get("publicationDate", "") or ""
    video_id = str(item.get("id", ""))

    li = xbmcgui.ListItem(label=title)
    if core_settings.is_modo_ligero_active():
        li.setArt({"icon": "DefaultVideo.png"})
    else:
        li.setArt({"thumb": thumb, "icon": thumb, "poster": thumb})

    plot = desc
    if pub_date:
        plot += "\n\nPublicado: {0}".format(pub_date[:10])
    li.setInfo("video", {
        "title": title,
        "plot": plot,
        "duration": duration // 1000 if duration else 0,
    })
    li.setProperty("IsPlayable", "true")

    web_url = item.get("htmlShortUrl", item.get("htmlUrl", "")) or ""
    if not web_url and video_id:
        web_url = "https://www.rtve.es/v/{0}/".format(video_id)
    cm = [
        ("Buscar en Dailymotion", "Container.Update({0})".format(
            _u(action="lfr", q=title, ot=""))),
        ("Ver en RTVE.es", "RunPlugin({0})".format(
            _u(action="rtve_open_web", url=web_url, title=title))),
    ]
    if web_url:
        cm.append(("Copiar URL", "RunPlugin({0})".format(
            _u(action="copy_url", url=web_url))))
    li.addContextMenuItems(cm)

    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="play_rtve_video", video_id=video_id, title=title),
        listitem=li,
        isFolder=False,
    )


def play_video(video_id, title=""):
    streams = _get_ztnr_streams(video_id)
    if streams:
        chosen_url = None
        for _, u in streams:
            if ".m3u8" in u.lower():
                chosen_url = u
                break
        if not chosen_url:
            for _, u in streams:
                if ".mp4" in u.lower():
                    chosen_url = u
                    break
        if not chosen_url:
            chosen_url = streams[0][1]

        _play_direct_stream(chosen_url, title, video_id)
        return

    _play_drm_stream(video_id, title)


def search(query=""):
    h = _handle()
    if not query:
        sel = core_settings.get_search_input_sel("¿Cómo introduces la búsqueda?")
        if sel < 0:
            if h > 0:
                try: xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
                except Exception: pass
            return
        if sel == 1:
            import url_remote
            query = url_remote.receive_text("Buscar en RTVE Play")
            if not query:
                if h > 0:
                    try: xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
                    except Exception: pass
                return
        else:
            kb = xbmc.Keyboard("", "Buscar en RTVE Play")
            kb.doModal()
            if not kb.isConfirmed() or not kb.getText().strip():
                if h > 0:
                    try: xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
                    except Exception: pass
                return
            query = kb.getText().strip()

        target = _u(action="rtve_search", query=query)
        xbmc.executebuiltin("Container.Update({0})".format(target))
        if h > 0:
            try: xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
            except Exception: pass
        return
    dp = xbmcgui.DialogProgress()
    dp.create("RTVE Play", "Buscando '{0}'...".format(query))
    try:
        dp.update(30, "Consultando api.rtve.es...")
        url = ("https://api.rtve.es/api/search/contents"
               "?search={0}&page=1&size=30&context=tve"
               "&type=completo&tipology=video"
               "&isExpanded=true&isChild=true"
               "&useOntology=false").format(quote(query))
        data = _fetch_json(url)
        dp.update(70, "Procesando resultados...")
        dp.close()

        items = data.get("page", {}).get("items", [])
        if not items:
            xbmcgui.Dialog().notification(
                "RTVE Play",
                "Sin resultados para '{0}'".format(query),
                xbmcgui.NOTIFICATION_INFO, 3000)
            xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
            return

        for item in items:
            _add_video_item(h, item)
        xbmcplugin.endOfDirectory(h, cacheToDisc=True)

    except (OSError, ValueError, KeyError) as e:
        dp.close()
        _log_error("search: {0}".format(e))
        xbmcgui.Dialog().ok("RTVE Play",
                            "Error en la búsqueda:\n{0}".format(e))
        try:
            xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        except RuntimeError:
            pass


_FELIX_SLUG = "el-hombre-y-la-tierra"
_FELIX_PROGRAM_TITLE_LC = "el hombre y la tierra"


def _fetch_html(url, timeout=15):
    if requests:
        r = requests.get(url, headers=_HEADERS, timeout=timeout)
        r.raise_for_status()
        return r.text
    import urllib.request as _ureq
    req = _ureq.Request(url, headers=_HEADERS)
    with _ureq.urlopen(req, timeout=timeout) as resp:
        return resp.read().decode("utf-8", errors="ignore")


def _progid_cache_path(slug):
    cache_dir = core_settings.get_iptv_cache_dir()
    return os.path.join(cache_dir, "rtve_progid_" + slug + ".txt")


def _discover_program_id_by_slug(slug):
    """Obtiene el ID de programa RTVE a partir del slug de play-page. Devuelve '' si falla. Cachea en disco."""
    import re as _re
    cache_path = _progid_cache_path(slug)
    try:
        if os.path.exists(cache_path):
            with open(cache_path, "r", encoding="utf-8") as f:
                cached = f.read().strip()
            if cached.isdigit():
                return cached
    except OSError:
        pass

    page_url = "https://www.rtve.es/play/videos/{0}/".format(slug)
    try:
        html = _fetch_html(page_url)
    except (OSError, ValueError) as e:
        _log("discover_program_id ({0}) fetch error: {1}".format(slug, e))
        return ""

    patterns = [
        r'/api/programas/(\d+)/videos',
        r'/api/programas/(\d+)\b',
        r'"programaId"\s*:\s*"?(\d+)"?',
        r'"programa"\s*:\s*\{[^}]*?"id"\s*:\s*"?(\d+)"?',
        r'data-prog(?:rama)?-id=["\'](\d+)["\']',
        r'idAsset["\']?\s*:\s*["\']?(\d+)',
        r'/programas/(\d+)/',
    ]
    for pat in patterns:
        m = _re.search(pat, html)
        if m:
            pid = m.group(1)
            try:
                with open(cache_path, "w", encoding="utf-8") as f:
                    f.write(pid)
            except OSError:
                pass
            _log("discover_program_id ({0}) -> {1} (pat={2})".format(slug, pid, pat))
            return pid
    _log("discover_program_id ({0}): no pattern matched".format(slug))
    return ""


def _is_felix_episode(item):
    pi = item.get("programInfo") or {}
    pi_title = (pi.get("title") or "").strip().lower()
    if pi_title == _FELIX_PROGRAM_TITLE_LC:
        return True
    url = (item.get("htmlUrl") or item.get("htmlShortUrl") or "").lower()
    if "/" + _FELIX_SLUG + "/" in url:
        return True
    return False


def show_felix_rtve(page=1, prog_id=""):
    h = _handle()
    dp = xbmcgui.DialogProgress()
    dp.create("RTVE Play", "El Hombre y la Tierra...")
    try:
        page = int(page)

        prog_id = prog_id or _discover_program_id_by_slug(_FELIX_SLUG)

        items = []
        total_pages = 1
        current_page = page

        if prog_id:
            dp.update(30, "Cargando programa {0}...".format(prog_id))
            try:
                data = _fetch_json(
                    "https://www.rtve.es/api/programas/{0}/videos.json"
                    "?page={1}&size=30".format(prog_id, page), default_ttl=3600
                )
                items = data.get("page", {}).get("items", []) or []
                total_pages = data.get("page", {}).get("totalPages", 1) or 1
                current_page = data.get("page", {}).get("number", page) or page
            except (OSError, ValueError, KeyError) as e:
                _log("felix programas/{0} fallo: {1}".format(prog_id, e))
                items = []

        if not items:
            dp.update(50, "Buscando y filtrando...")
            data = _fetch_json(
                "https://api.rtve.es/api/search/contents"
                "?search={0}&page={1}&size=60&context=tve"
                "&type=completo&tipology=video"
                "&isExpanded=true&isChild=true"
                "&useOntology=false".format(quote("hombre y la tierra"), page)
            )
            all_items = data.get("page", {}).get("items", []) or []
            items = [it for it in all_items if _is_felix_episode(it)]
            total_pages = data.get("page", {}).get("totalPages", 1) or 1
            current_page = data.get("page", {}).get("number", page) or page

        dp.update(85, "Procesando...")
        dp.close()

        if not items:
            xbmcgui.Dialog().notification(
                "RTVE Play", "Sin resultados",
                xbmcgui.NOTIFICATION_INFO, 3000)
            xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
            return

        for item in items:
            _add_video_item(h, item)

        if current_page > 1:
            li = xbmcgui.ListItem(
                label="[COLOR yellow]← Página anterior ({0}/{1})[/COLOR]".format(
                    current_page - 1, total_pages))
            li.setArt({"icon": "DefaultFolder.png"})
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="archive_felix_rtve", page=current_page - 1,
                       prog_id=prog_id),
                listitem=li, isFolder=True)

        if current_page < total_pages:
            li = xbmcgui.ListItem(
                label="[COLOR limegreen]Página siguiente ({0}/{1})[/COLOR]".format(
                    current_page + 1, total_pages))
            li.setArt({"icon": "DefaultFolder.png"})
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="archive_felix_rtve", page=current_page + 1,
                       prog_id=prog_id),
                listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(h, cacheToDisc=True)

    except (OSError, ValueError, KeyError) as e:
        dp.close()
        _log_error("felix_rtve: {0}".format(e))
        xbmcgui.Dialog().ok("RTVE Play", "Error al cargar:\n{0}".format(e))
        try:
            xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        except RuntimeError:
            pass


_PUNSET_SLUG = "redes"
_PUNSET_PROGRAM_TITLE_LC = "redes"


def _is_punset_episode(item):
    pi = item.get("programInfo") or {}
    pi_title = (pi.get("title") or "").strip().lower()
    if pi_title == _PUNSET_PROGRAM_TITLE_LC:
        return True
    url = (item.get("htmlUrl") or item.get("htmlShortUrl") or "").lower()
    if "/" + _PUNSET_SLUG + "/" in url:
        return True
    return False


def show_punset_rtve(page=1, prog_id=""):
    h = _handle()
    dp = xbmcgui.DialogProgress()
    dp.create("RTVE Play", "Redes — Eduard Punset...")
    try:
        page = int(page)

        prog_id = prog_id or _discover_program_id_by_slug(_PUNSET_SLUG)

        items = []
        total_pages = 1
        current_page = page

        if prog_id:
            dp.update(30, "Cargando programa {0}...".format(prog_id))
            try:
                data = _fetch_json(
                    "https://www.rtve.es/api/programas/{0}/videos.json"
                    "?page={1}&size=30".format(prog_id, page), default_ttl=3600
                )
                items = data.get("page", {}).get("items", []) or []
                total_pages = data.get("page", {}).get("totalPages", 1) or 1
                current_page = data.get("page", {}).get("number", page) or page
            except (OSError, ValueError, KeyError) as e:
                _log("punset programas/{0} fallo: {1}".format(prog_id, e))
                items = []

        if not items:
            dp.update(50, "Buscando y filtrando...")
            data = _fetch_json(
                "https://api.rtve.es/api/search/contents"
                "?search={0}&page={1}&size=60&context=tve"
                "&type=completo&tipology=video"
                "&isExpanded=true&isChild=true"
                "&useOntology=false".format(quote("redes punset"), page)
            )
            all_items = data.get("page", {}).get("items", []) or []
            items = [it for it in all_items if _is_punset_episode(it)]
            total_pages = data.get("page", {}).get("totalPages", 1) or 1
            current_page = data.get("page", {}).get("number", page) or page

        dp.update(85, "Procesando...")
        dp.close()

        if not items:
            xbmcgui.Dialog().notification(
                "RTVE Play", "Sin resultados",
                xbmcgui.NOTIFICATION_INFO, 3000)
            xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
            return

        for item in items:
            _add_video_item(h, item)

        if current_page > 1:
            li = xbmcgui.ListItem(
                label="[COLOR yellow]← Página anterior ({0}/{1})[/COLOR]".format(
                    current_page - 1, total_pages))
            li.setArt({"icon": "DefaultFolder.png"})
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="archive_punset_rtve", page=current_page - 1,
                       prog_id=prog_id),
                listitem=li, isFolder=True)

        if current_page < total_pages:
            li = xbmcgui.ListItem(
                label="[COLOR limegreen]Página siguiente ({0}/{1})[/COLOR]".format(
                    current_page + 1, total_pages))
            li.setArt({"icon": "DefaultFolder.png"})
            xbmcplugin.addDirectoryItem(
                handle=h,
                url=_u(action="archive_punset_rtve", page=current_page + 1,
                       prog_id=prog_id),
                listitem=li, isFolder=True)

        xbmcplugin.endOfDirectory(h, cacheToDisc=True)

    except (OSError, ValueError, KeyError) as e:
        dp.close()
        _log_error("punset_rtve: {0}".format(e))
        xbmcgui.Dialog().ok("RTVE Play", "Error al cargar:\n{0}".format(e))
        try:
            xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        except RuntimeError:
            pass


def open_web(url, title=""):
    if not url:
        xbmcgui.Dialog().notification("RTVE Play", "URL no disponible",
                                      xbmcgui.NOTIFICATION_WARNING, 2000)
        return
    _log("Abriendo en navegador: {0}".format(url))
    import webbrowser
    try:
        webbrowser.open(url)
    except (OSError, webbrowser.Error) as e:
        _log_error("open_web: {0}".format(e))
        xbmcgui.Dialog().ok(
            "RTVE Play",
            "No se pudo abrir el navegador.\n\nURL: {0}".format(url))
        return
    xbmcgui.Dialog().notification(
        "RTVE Play",
        "Abriendo {0} en navegador...".format(title or "vídeo"),
        xbmcgui.NOTIFICATION_INFO, 3000)


# Filmoteca y NO-DO delegados en filmoteca.py para retrocompatibilidad
try:
    import filmoteca as _filmoteca_mod
    _FILMOTECA_SECTIONS = _filmoteca_mod._FILMOTECA_SECTIONS
except ImportError:
    _FILMOTECA_SECTIONS = ()


def show_filmoteca_menu():
    import filmoteca
    filmoteca.show_filmoteca_menu()


def show_filmoteca_seccion(query="", name="", page=1):
    import filmoteca
    filmoteca.show_filmoteca_seccion(query, name, page)


def filmoteca_search(query="", page=1):
    import filmoteca
    filmoteca.filmoteca_search(query, page)