# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Biblioteca oficial de vídeo de la NASA (images.nasa.gov).

Documentales, misiones Apolo, filmaciones espaciales y material científico
de dominio público federal estadounidense mediante images-api.nasa.gov.
"""

import json
import os
import sys
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

import core_settings

_BASE_API = "https://images-api.nasa.gov/search"
_MEDIA = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")
def _user_agent():
    try:
        ver = xbmcaddon.Addon().getAddonInfo("version")
        if ver:
            return f"Mozilla/5.0 (Windows NT 10.0; Win64; x64) EspaTV/{ver}"
    except Exception:
        pass
    return "Mozilla/5.0 (Windows NT 10.0; Win64; x64) EspaTV"


def _handle():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return 0


def _u(**params):
    filtered = {k: v for k, v in params.items() if v is not None}
    return "plugin://plugin.video.espatv/?" + urllib.parse.urlencode(filtered)


def _icon(name, fallback="DefaultFolder.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _fetch_json(url, timeout=12):
    clean = urllib.parse.unquote(url)
    encoded_url = urllib.parse.quote(clean, safe=":/=&?~#%")
    req = urllib.request.Request(encoded_url, headers={"User-Agent": _user_agent()})
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8", errors="replace"))


def _pick_best_mp4(urls):
    if not isinstance(urls, list):
        return None
    mp4s = [u for u in urls if isinstance(u, str) and u.lower().endswith(".mp4")]
    if not mp4s:
        return None

    # Prioridad de calidad visual: original > grande > media > cualquier mp4
    for pattern in ("~orig.mp4", "~large.mp4", "~medium.mp4"):
        for u in mp4s:
            if pattern in u.lower():
                return _to_https(u)
    return _to_https(mp4s[0])


def _to_https(url):
    if url.startswith("http://"):
        return "https://" + url[7:]
    return url


def menu():
    h = _handle()
    if h == 0:
        return

    secciones = [
        ("Buscar en la biblioteca de la NASA",
         _u(action="nasa_search"),
         _icon("nasa_search.png", "DefaultAddonsSearch.png"),
         "Buscador interactivo en todo el archivo de vídeo oficial de la NASA.",
         False),
        ("Misiones Apolo y Llegada a la Luna",
         _u(action="nasa_list", query="apollo", title="Misiones Apolo y Llegada a la Luna"),
         _icon("nasa_apolo.png", "DefaultMovies.png"),
         "Filmaciones originales de las misiones Apolo, alunizajes, entrenamientos y conferencias de prensa.",
         True),
        ("Documentales y Archivo Histórico",
         _u(action="nasa_list", query="documentary", title="Documentales y Archivo Histórico"),
         _icon("nasa_documentales.png", "DefaultMovies.png"),
         "Documentales producidos por la NASA sobre la historia aeroespacial, aeronáutica y cosmología.",
         True),
        ("Exploración de Marte (Curiosity, Perseverance)",
         _u(action="nasa_list", query="mars", title="Exploración de Marte"),
         _icon("nasa_marte.png", "DefaultMovies.png"),
         "Grabaciones, recreaciones y misiones de los rovers y sondas marcianas de la NASA.",
         True),
        ("Estación Espacial Internacional (ISS)",
         _u(action="nasa_list", query="international space station", title="Estación Espacial Internacional (ISS)"),
         _icon("nasa_iss.png", "DefaultMovies.png"),
         "Vida a bordo, paseos espaciales (EVA), acoplamientos y operaciones científicas en órbita baja.",
         True),
        ("Telescopios Espaciales (Hubble y Webb)",
         _u(action="nasa_list", query="webb OR hubble", title="Telescopios Espaciales (Hubble y Webb)"),
         _icon("nasa_telescopios.png", "DefaultMovies.png"),
         "Descubrimientos del Universo profundo, galaxias remotas y nebulosas captadas por Hubble y James Webb.",
         True),
        ("Cohetes y Grandes Lanzamientos",
         _u(action="nasa_list", query="launch", title="Cohetes y Lanzamientos"),
         _icon("nasa_cohetes.png", "DefaultMovies.png"),
         "Despegues de cohetes Saturn V, transbordadores espaciales (Space Shuttle) y programa Artemis.",
         True),
        ("La Tierra desde el espacio",
         _u(action="nasa_list", query="earth", title="La Tierra desde el espacio"),
         _icon("nasa_tierra.png", "DefaultMovies.png"),
         "Filmaciones en alta definición de la atmósfera terrestre, auroras boreales y vistas orbitales.",
         True),
    ]

    for label, url, icon, plot, is_folder in secciones:
        li = xbmcgui.ListItem(label=f"[B]{label}[/B]")
        li.setContentLookup(False)
        li.setArt({"icon": icon, "thumb": icon, "poster": icon})
        li.setInfo("video", {"title": label, "plot": plot})
        xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=is_folder)

    xbmcplugin.endOfDirectory(h, cacheToDisc=True)


def search():
    h = _handle()
    kb = xbmcgui.Dialog().input("Buscar en NASA Video Library", type=xbmcgui.INPUT_ALPHANUM)
    q = kb.strip() if kb else ""
    if not q:
        if h > 0:
            try:
                xbmcplugin.endOfDirectory(h, succeeded=False)
            except Exception:
                pass
        return
    target = _u(action="nasa_list", query=q, page=1, title=f"Búsqueda: {q}")
    xbmc.executebuiltin(f"Container.Update({target})")
    if h > 0:
        try:
            xbmcplugin.endOfDirectory(h, succeeded=False)
        except Exception:
            pass


def list_videos(query, page=1, title=""):
    h = _handle()
    if h == 0:
        return

    try:
        page_num = max(1, int(page))
    except (ValueError, TypeError):
        page_num = 1

    # Sin setContent('videos'): en Estuary el contenido de vídeos fuerza ListWatchedIconVar (punto
    # o marca de visto) ocultando ListItem.Icon; con contenido neutro el skin pinta la miniatura en la fila.
    xbmcplugin.setPluginCategory(h, title or "NASA Video Library")

    api_url = f"{_BASE_API}?q={urllib.parse.quote(query)}&media_type=video&page={page_num}"

    try:
        data = _fetch_json(api_url)
    except (urllib.error.URLError, OSError, ValueError) as err:
        xbmc.log(f"[EspaTV-NASA] Error consultando API NASA ({api_url}): {err}", xbmc.LOGERROR)
        xbmcgui.Dialog().notification("EspaTV", "No se pudo conectar con la biblioteca de la NASA", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    collection = data.get("collection", {})
    items = collection.get("items", [])
    metadata = collection.get("metadata", {})
    total_hits = metadata.get("total_hits", 0)

    if not items:
        xbmcgui.Dialog().notification("EspaTV", "No se encontraron vídeos", xbmcgui.NOTIFICATION_INFO)
        xbmcplugin.endOfDirectory(h, cacheToDisc=False)
        return

    has_next = False
    for link in collection.get("links", []):
        if link.get("rel") == "next":
            has_next = True
            break

    for item in items:
        data_list = item.get("data", [])
        if not data_list:
            continue
        info = data_list[0]

        v_title = info.get("title", "Vídeo de la NASA")
        desc = info.get("description", "")
        date_str = info.get("date_created", "")
        coll_url = item.get("href", "")

        year = None
        if date_str and len(date_str) >= 4 and date_str[:4].isdigit():
            year = int(date_str[:4])

        thumb = ""
        sub_url = ""
        for link in item.get("links", []):
            rel = link.get("rel", "")
            href = link.get("href", "")
            if rel in ("preview", "alternate") and link.get("render") == "image":
                if not thumb or "~medium.jpg" in href or "~large.jpg" in href:
                    thumb = _to_https(href)
            elif rel == "captions" or href.lower().endswith(".srt"):
                sub_url = _to_https(href)

        plot_text = desc
        if date_str:
            plot_text = f"Fecha: {date_str[:10]}\n\n{desc}"

        li = xbmcgui.ListItem(label=f"[B]{v_title}[/B]")
        li.setProperty("IsPlayable", "true")
        icon_path = _icon("nasa_main.png") if core_settings.is_modo_ligero_active() else (thumb or _icon("nasa_main.png"))
        li.setArt({
            "icon": icon_path,
            "thumb": icon_path,
            "poster": icon_path,
            "banner": icon_path,
            "fanart": icon_path,
        })

        v_info = {"title": v_title, "plot": plot_text}
        if year:
            v_info["year"] = year
        li.setInfo("video", v_info)

        play_url = _u(action="nasa_play", coll_url=coll_url, title=v_title, sub_url=sub_url)
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    if has_next:
        next_li = xbmcgui.ListItem(label="[B]Página siguiente >>[/B]")
        next_li.setArt({"icon": "DefaultFolder.png", "thumb": "DefaultFolder.png"})
        next_li.setInfo("video", {
            "title": "Página siguiente",
            "plot": f"Página {page_num + 1} de resultados para '{query}' (total: {total_hits} vídeos).",
        })
        next_url = _u(action="nasa_list", query=query, page=page_num + 1, title=title)
        xbmcplugin.addDirectoryItem(handle=h, url=next_url, listitem=next_li, isFolder=True)

    xbmcplugin.endOfDirectory(h, cacheToDisc=True)


def play(coll_url, title="", sub_url=""):
    h = _handle()
    if h == 0:
        return

    if not coll_url:
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return

    try:
        urls = _fetch_json(coll_url)
        best_mp4 = _pick_best_mp4(urls)
    except (urllib.error.URLError, OSError, ValueError) as err:
        xbmc.log(f"[EspaTV-NASA] Error resolviendo stream ({coll_url}): {err}", xbmc.LOGERROR)
        best_mp4 = None

    if not best_mp4:
        xbmcgui.Dialog().notification("EspaTV", "Vídeo de la NASA no disponible", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
        return

    clean_mp4 = urllib.parse.quote(urllib.parse.unquote(best_mp4), safe=":/=&?~#%")
    li = xbmcgui.ListItem(path=clean_mp4)
    li.setProperty("IsPlayable", "true")
    li.setInfo("video", {"title": title or "NASA Video"})
    if sub_url:
        try:
            clean_sub = urllib.parse.quote(urllib.parse.unquote(sub_url), safe=":/=&?~#%")
            li.setSubtitles([clean_sub])
        except Exception:
            # Versiones de Kodi sin soporte para subtítulos remotos
            pass

    xbmcplugin.setResolvedUrl(h, True, li)
