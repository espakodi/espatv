# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Lo que se ve: las categorías de cada sección y los canales de una de ellas.

Habla con el servidor a través de `fuentes_xtream`, que es el único que lo hace, y **no sabe
nada de credenciales**. Ni las recibe: las filas que le llegan son
`{'sid', 'nombre', 'logo', 'grupo', 'num', 'epg', 'radio', 'ext'}` y ya. No es una promesa, es
la forma de que sea imposible filtrarlas desde aquí.

Por lo mismo, **en la fila solo van `fid`, `sid`, `sec` y el título**. Ni la URL del canal, ni
el usuario, ni la clave. La URL se monta en el momento de reproducir, con
`fuentes_xtream.url_de()`, y se usa una vez. Es la diferencia con
`iptv_lists._channel_item`, que sí la mete en la dirección de la
fila, del favorito y de la grabación, y por eso aquí no se reutiliza.

Tres cosas que se hacen aquí y no en el cliente, porque son de pantalla:

- **La fila de "página siguiente"**. El cliente devuelve `(filas, hay_mas)` y esto decide si
  hay un botón más. El bucle se para solo con `MAX_PAGINAS`, porque hay paneles que no
  implementan `limit` y devuelven todo siempre: sin tope, "página siguiente" llevaría a una
  lista idéntica a la anterior para siempre.
- **El nombre de la fuente en la categoría**, solo cuando hay más de un servidor. Con uno solo
  estorba; con tres, sin él no se sabe de quién es cada categoría.
- **`setContent`**, que es lo que decide que Estuary pinte mosaicos y enseñe el icono:
  sin contenido vacío declarado, Estuary no pinta `ListItem.Icon` en las filas de contenido
  de vídeo y los canales salen sin nada.

Lo que **no** está aquí, y por qué: las facetas por país e idioma. Un panel Xtream no las da
(`get_live_categories` no trae país ni idioma, solo `category_id` y `category_name`), y la
sección de motor (`iptv_canales`) sí las tiene porque sus fuentes sí las traen. Poner un
filtro de país sobre un panel que no lo tiene sería un botón que no filtra nada.
"""
import hashlib
import re
import unicodedata
import urllib.parse

import xbmc
import xbmcgui
import xbmcplugin

import ui_utils

_LOG = '[EspaTV/FUENTES]'

_NOMBRE = 'HyperXStream'

_BASE = 'plugin://plugin.video.espatv/'

#: Cuántas páginas se pueden llegar a encadenando "página siguiente".
#:
#: El tope existe por un motivo concreto: hay paneles que no implementan `limit` y devuelven
#: los 18 000 canales en cada llamada, así que `hay_mas` es `True` para siempre y "página
#: siguiente" mostraría la misma lista una y otra vez. Con el tope se para solo, y avisa. Un
#: bucle infinito de páginas es la peor forma de "ir más rápido": parece que funciona y no
#: lleva a ningún sitio.
MAX_PAGINAS = 60

#: Cuántos resultados enseña una búsqueda como máximo. Y avisa cuando los hay, porque un
#: buscador que no dice que ha cortado parece que dice que no hay más.
MAX_BUSQUEDA = 300

#: Secciones y su rótulo, para pintar el título de la pantalla.
TITULO_SECCION = {'live': 'TV y radio en directo', 'vod': 'Películas',
                  'series': 'Series'}

#: TTL de la caché negativa de TMDB: un título que se buscó y no estaba se recuerda
#: siete días.
#:
#: El número es un compromiso, y duele por los dos lados. Corto: se vuelve a buscar lo que no
#: está y se repiten las peticiones, que es justo el fallo que se está arreglando. Largo: una
#: película que TMDB todavía no tiene catalogada se queda sin ficha una semana aunque
#: aparezca mañana. Siete días es donde las dos cosas dejan de doler.
TTL_SIN_FICHA = 7 * 24 * 3600

#: Carpeta de la caché negativa dentro de `fuentes_cache`. No es el `fid` de
#: ninguna fuente: es un título que TMDB no tiene, y eso no es de un servidor sino de
#: TMDB.
#:
#: Una sola para toda la sección a propósito: si TMDB no tiene «Canal Random 4K», no lo tiene
#: venga del servidor que venga, y volver a buscarlo desde otro servidor es la misma
#: petición repetida con otro nombre.
#:
#: Se lleva «Vaciar caché» por delante sin hacer nada especial: `limpiar_cache(None)` borra
#: todas las carpetas de `fuentes_cache`, y esta es una más.
FID_SIN_FICHA = 'tmdb_sin_ficha'

#: Tope de hilos y plazo para pedir las categorías de todas las fuentes a la vez.
#:
#: 6 hilos y no 12 como el análisis: lo normal son dos o tres fuentes. 25 s y no los 90 del
#: análisis porque esto es una pantalla de menú, no una acción con progreso cancelable. Cada
#: petición ya lleva su timeout (`iptv_lists._TIMEOUT`, 20 s de lectura); esto es el margen
#: para que terminen todas.
HILOS_CATEGORIAS = 6
PLAZO_CATEGORIAS = 25


def _log(texto, nivel=xbmc.LOGDEBUG):
    xbmc.log('{0} {1}'.format(_LOG, texto), nivel)


def _u(**params):
    """La dirección de una acción. **Nunca** lleva credenciales: solo ids."""
    return _BASE + '?' + urllib.parse.urlencode(
        {k: v for k, v in params.items() if v not in (None, '')})


def _handle():
    try:
        return int(__import__('sys').argv[1])
    except (IndexError, ValueError):
        return -1


def _icon(nombre):
    return ui_utils.media_icon(nombre) or 'DefaultAddonPVRClient.png'


def _ajuste(clave, defecto=''):
    try:
        import xbmcaddon
        return xbmcaddon.Addon().getSetting(clave) or defecto
    except Exception as e:                              # pragma: no cover
        _log('no se ha podido leer el ajuste {0}: {1}'.format(clave, e))
        return defecto


def _mosaicos():
    """¿Esta sección se pinta en mosaicos?

    El ajuste va **vacío = sí**, porque el comportamiento por defecto tiene
    que ser el bueno: los canales con mosaicos enseñan el logo, que es la mitad de la utilidad de
    un canal de TV. Con "no" se respeta y sale en lista.
    """
    return (_ajuste('fuentes_mosaicos') or 'si').lower() not in ('no', '0', 'false', 'lista')


def _contenido(tipo=None):
    """Declara el tipo de contenido de la pantalla.

    Permite que Estuary muestre los iconos. Se declara antes de pintar elementos porque
    `setContent` posterior a `addDirectoryItem` no siempre llega a tiempo si la skin ya ha
    decidido la disposición visual.
    """
    h = _handle()
    if h < 0:
        return
    # El ajuste de mosaicos se respeta aquí: setContent decide cómo dibuja la skin.
    # Cada tipo de pantalla declara su propio contenido visual en Kodi.
    if tipo == 'vod':
        contenido = 'movies'
    elif tipo == 'series':
        contenido = 'tvshows'
    elif tipo == 'seasons':
        contenido = 'seasons'
    elif tipo == 'episodes':
        contenido = 'episodes'
    else:
        contenido = 'videos' if _mosaicos() else 'files'
    try:
        xbmcplugin.setContent(h, contenido)
    except Exception as e:                              # pragma: no cover
        _log('no se ha podido declarar el contenido: {0}'.format(e))


def _fin(cerrado=True, reemplazar=False):
    """Cierra el directorio. `reemplazar` es `updateListing`: sustituye en vez de apilar.

    `updateListing=True` en la API de Kodi sustituye la pantalla actual en lugar de apilarla,
    lo que permite avanzar en paginación sin acumular historial en navegación hacia atrás.
    """
    h = _handle()
    if h < 0:
        return
    try:
        xbmcplugin.endOfDirectory(h, cerrado, bool(reemplazar), True)
    except Exception as e:                              # pragma: no cover
        _log('no se ha podido cerrar el listado: {0}'.format(e), xbmc.LOGWARNING)


def _aviso(texto, titulo=None):
    """Un aviso al usuario."""
    xbmcgui.Dialog().ok(titulo or _NOMBRE, texto)


def _fuente(fid):
    """La fuente, o `None`. Sin fuente no hay nada que pintar y se dice."""
    import fuentes_store
    return fuentes_store.fuente(fid) if fid else None


def _fuentes_xtream():
    """Las fuentes que son servidores Xtream. Las listas M3U no tienen API de categorías.

    Es una diferencia real que hay que entender: una lista M3U **no tiene categorías del
    servidor**, tiene las que vienen en la propia lista, y de eso se ocupa la pila IPTV del
    proyecto. Aquí solo se ofrecen las Xtream, que es lo que esta pantalla sabe leer.
    """
    import fuentes_store
    return [f for f in fuentes_store.fuentes() if f['tipo'] != 'm3u']


def _fuentes_m3u():
    """Las listas M3U añadidas al addon.

    Permite incluir fuentes M3U en la búsqueda global de servidores. Su navegador
    es `_leer_m3u()`, pero la lista de canales es la misma.
    """
    import fuentes_store
    return [f for f in fuentes_store.fuentes() if f.get('tipo') == 'm3u']


def _de_un_error(e, fuente=None):
    """Un error de red o de cuenta, pintado como toca. Devuelve si hay que pararse.

    `ErrorRed` es "no he podido saberlo": se anota en el log y se sigue, porque hay otras
    fuentes que sí contestan y quitarlas todas por una que está apagada sería peor. `ErrorCuenta`
    es "sé que está mal": si la clave está mal no hay lista que enseñar de esa fuente, así que
    se avisa y esa fuente se deja fuera. Cualquier otra excepción sube, que es la que sabe
    pelarse el router (`fuentes_tv.route()`), que es quien pone el mensaje que dice **qué
    botón** ha fallado.

    `fuente` y el nombre en todas las ramas: con varios servidores, un aviso de «no ha
    respondido» que no dice cuál no sirve. `ErrorCuenta` ya trae el nombre en el mensaje del
    panel; a `ErrorRed` se le añade aquí.

    La rama `ErrorRed` va sin aviso modal a propósito (ya sale en naranja en «Comprobar»); lo
    que se añade es el nombre en el log.
    """
    import fuentes_xtream
    nombre = ''
    if isinstance(fuente, dict):
        nombre = str(fuente.get('nombre') or '')
    if not nombre:
        quien = ''
    else:
        quien = ' ({0})'.format(nombre)
    if isinstance(e, fuentes_xtream.ErrorCuenta):
        # El mensaje del panel ya explica el fallo; el nombre va delante para que se sepa de
        # quién es la cuenta, no solo qué le pasa.
        _aviso(f'{nombre}: {e}' if nombre else str(e))
        return True
    if isinstance(e, fuentes_xtream.ErrorRed):
        _log('no se ha podido contactar con una fuente{0}: {1}'.format(quien, e),
             xbmc.LOGWARNING)
        return True
    raise e


# --- las categorias --------------------------------------------------------

def categorias(fid='', seccion='live', elegir=False):
    """Las categorías de una sección, de UNA fuente o de todas.

    Con `fid`, las de esa fuente. Sin él y con más de una fuente, se abre antes la pantalla
    de selección: «Todos», cada servidor y cada lista M3U.

    Con una sola fuente se entra directamente para evitar pasos redundantes. Con varias,
    se entra en la última que se abrió en esta sección (`fuentes_store.ultimo_servidor()`),
    y arriba va «Cambiar de servidor» para volver a la pantalla de selección (`elegir=True`).

    No se fusionan categorías de fuentes distintas para mantener la navegación limpia por servidor.
    """
    import fuentes_xtream

    if seccion not in fuentes_xtream.SECCIONES:
        seccion = 'live'
    _contenido()

    fuentes = [_fuente(fid)] if fid else _fuentes_xtream()
    fuentes = [f for f in fuentes if f and f['tipo'] != 'm3u']

    # Las listas M3U no tienen categorías de servidor, pero sí canales: en «TV y radio» se
    # ofrecen con su pantalla (`fuentes_m3u`). Se leen de `fuentes_store` porque `_fuentes_xtream()`
    # ya las ha filtrado.
    m3us = []
    if not fid and seccion == 'live':
        import fuentes_store
        m3us = [f for f in fuentes_store.fuentes() if f['tipo'] == 'm3u']

    import fuentes_store
    # «Cambiar de servidor» solo si en ESTA sección hay otra cosa que elegir. Las M3U solo
    # cuentan en directo: en Películas, con un servidor y una lista, la fila volvía al mismo.
    varias = sum(1 for x in fuentes_store.fuentes()
                 if x['tipo'] != 'm3u' or seccion == 'live') > 1
    if not fid and not elegir and len(fuentes) + len(m3us) > 1:
        ultimo = fuentes_store.ultimo_servidor(seccion)
        if ultimo == 'todos' and len(fuentes) > 1:
            categorias_todas(seccion)
            return
        elegida = next((f for f in fuentes if f['id'] == ultimo), None)
        if elegida:
            fid, fuentes, m3us = ultimo, [elegida], []
        elif seccion == 'live':
            elegida_m3u = next((f for f in m3us if f['id'] == ultimo), None)
            if elegida_m3u:
                m3u(elegida_m3u['id'])
                return

    # Con más de una fuente se muestra la pantalla de selección.
    if not fid and len(fuentes) + len(m3us) > 1:
        _elegir_fuente(seccion, fuentes, m3us)
        return

    for f in m3us:
        ui_utils.add_item(
            action='fuentes_m3u', fid=f['id'], folder=True,
            title='[B]{0}[/B]'.format(f.get('nombre') or 'Lista M3U'),
            thumbnail=_icon('carpeta.png'),
            plot='Lista M3U. Se lee tal cual, sin categorías de servidor.')

    if not fuentes:
        if m3us:
            _fin()
            return
        _vacio(seccion, 'No hay ningún servidor Xtream todavía.',
               'Las listas M3U no tienen categorías de servidor: se leen con la lista de '
               'canales del propio EspaTV.')
        return

    # Aquí solo llega una fuente: la del `fid`, o la única que hay. Por eso el título va
    # sin el nombre del servidor (con uno solo estorba), y por eso no hace falta ningún
    # hilo: para una sola petición, montarlo cuesta más que hacerla.
    f = fuentes[0]
    if varias:
        fuentes_store.apunta_ultimo_servidor(seccion, f['id'])
        _fila_cambiar_servidor(seccion, f.get('nombre') or 'Servidor')
    con_datos = []
    try:
        cats = fuentes_xtream.categorias(f, seccion)
        if isinstance(cats, list):
            con_datos.append((f, cats))
    except Exception as e:
        # El directorio tiene que cerrarse igual, o Kodi se queda esperando un listado que no
        # llega. `_de_un_error()` ya ha dicho qué ha pasado (aviso o log).
        _de_un_error(e, f)
        if isinstance(e, fuentes_xtream.ErrorRed):
            # Aquí «Ningún servidor ha dicho que tenga categorías» era mentira: no ha dicho
            # nada. Se dice quién no contesta y se ofrece comprobarlo, como en «Todos».
            ui_utils.add_item(
                action='fuentes_srv_check', fid=f['id'], folder=False,
                title=f"No ha contestado: {f.get('nombre') or 'Servidor'}",
                thumbnail=_icon('xtream_srv_caido.png'),
                plot='Este servidor no ha contestado, así que no hay categorías que enseñar. '
                     'Pulsa para comprobarlo.')
            _fin()
            return
        if isinstance(e, fuentes_xtream.ErrorCuenta):
            # Tras el aviso salía «Ningún servidor ha dicho que tenga categorías», y sí ha
            # dicho algo: que la cuenta no vale. Lo útil es corregirla, no comprobarla.
            ui_utils.add_item(
                action='fuentes_srv_edit', fid=f['id'], folder=False,
                title=f"La cuenta no vale: {f.get('nombre') or 'Servidor'}",
                thumbnail=_icon('xtream_srv_caido.png'),
                plot='El servidor ha rechazado el usuario o la contraseña. '
                     'Pulsa para corregirlos.')
            _fin()
            return

    if not any(cats for _, cats in con_datos):
        _vacio(seccion, 'Ningún servidor ha dicho que tenga categorías en {0}.'
               .format(TITULO_SECCION.get(seccion, seccion)),
               'Puede que la sección esté vacía en esos servidores, o que el panel no las dé.')
        return

    # Solo con categorías: con el servidor caído la pantalla dice quién no contesta y nada más.
    ui_utils.add_item(
        action='fuentes_search_all', fid=f['id'], sec=seccion, folder=True,
        title='Buscar en este servidor', thumbnail=_icon('busqueda.png'),
        plot=f"Busca por nombre solo en {f.get('nombre') or 'este servidor'}.")
    for f, cats in con_datos:
        for c in cats:
            ui_utils.add_item(
                action='fuentes_list', fid=f['id'], cat=c['id'], sec=seccion, folder=True,
                title=str(c['n']), thumbnail=_icon('fuentes_categorias.png'),
                plot='{0}\nDe: {1}'.format(TITULO_SECCION.get(seccion, seccion), f['nombre']))
    _fila_refrescar(que='cats', fid=f['id'], sec=seccion)
    _fin()


def categorias_todas(seccion='live'):
    """Las categorías de todas las fuentes, pedidas en paralelo.

    Permite mostrar en una pantalla las categorías agrupadas. Se consultan
    en paralelo para que el tiempo total dependa solo de la fuente más lenta.
    Si alguna no contesta, se muestra una fila informativa al final.
    """
    import fuentes_xtream

    if seccion not in fuentes_xtream.SECCIONES:
        seccion = 'live'
    _contenido()

    fuentes = [f for f in _fuentes_xtream() if f and f['tipo'] != 'm3u']
    if not fuentes:
        _vacio(seccion, 'No hay ningún servidor Xtream todavía.',
               'Las listas M3U no tienen categorías de servidor: se leen con la lista de '
               'canales del propio EspaTV.')
        return

    import fuentes_store
    fuentes_store.apunta_ultimo_servidor(seccion, 'todos')
    _fila_cambiar_servidor(seccion, 'Todos')
    con_datos, sin_contestar = _categorias_en_paralelo(fuentes, seccion)

    # Con alguno sin contestar no se pinta la pantalla de «ningún servidor ha dicho»: alguno no
    # ha dicho nada, y la fila de abajo dice cuál.
    if not any(cats for _, cats in con_datos) and not sin_contestar:
        _vacio(seccion, 'Ningún servidor ha dicho que tenga categorías en {0}.'
               .format(TITULO_SECCION.get(seccion, seccion)),
               'Puede que la sección esté vacía en esos servidores, o que el panel no las dé.')
        return

    for f, cats in con_datos:
        for c in cats:
            titulo = '{0}  [COLOR gray]({1})[/COLOR]'.format(
                str(c['n']), f.get('nombre') or 'Servidor')
            ui_utils.add_item(
                action='fuentes_list', fid=f['id'], cat=c['id'], sec=seccion, folder=True,
                title=titulo, thumbnail=_icon('fuentes_categorias.png'),
                plot='{0}\nDe: {1}'.format(TITULO_SECCION.get(seccion, seccion),
                                           f.get('nombre') or 'Servidor'))

    if sin_contestar:
        quienes = ', '.join(str(f.get('nombre') or 'Servidor') for f in sin_contestar)
        ui_utils.add_item(
            action='fuentes_check', folder=False,
            title='No han contestado: {0}'.format(quienes),
            thumbnail=_icon('xtream_srv_caido.png'),
            plot='Se ha esperado {0} s y estos servidores no han dicho nada, así que sus '
                 'categorías no salen arriba. Pulsa para comprobarlos.'.format(
                     PLAZO_CATEGORIAS))
    _fin()


def _fila_cambiar_servidor(seccion, actual):
    """La primera fila con varios servidores: volver a elegir sin darle a Atrás. Hace falta
    desde que se entra directo en el último (`fuentes_store.ultimo_servidor()`)."""
    ui_utils.add_item(
        action='fuentes_cats', sec=seccion, elegir='1', folder=True,
        title=f'[B]Cambiar de servidor[/B]  [COLOR gray]({actual})[/COLOR]',
        thumbnail=_icon('xtream_servidores.png'),
        plot='Ver las categorías de otro de tus servidores, o de todos a la vez.')


def _elegir_fuente(seccion, fuentes, m3us):
    """Pantalla intermedia: «Todos» + cada servidor + cada lista M3U.

    Permite elegir entre ver las categorías unificadas de todas las fuentes o entrar
    a un servidor específico. «Todos» solo se muestra con más de un servidor Xtream.
    """
    if len(fuentes) > 1:
        ui_utils.add_item(
            action='fuentes_cats_todos', sec=seccion, folder=True,
            title='[B]Todos[/B]',
            thumbnail=_icon('fuentes_categorias.png'),
            plot='Las categorías de todos tus servidores en una pantalla. Se piden a la vez, '
                 'así que se espera lo que tarde el más lento; si alguno no contesta, se dice '
                 'cuál.')
    for f in fuentes:
        ui_utils.add_item(
            action='fuentes_cats', fid=f['id'], sec=seccion, folder=True,
            title=str(f.get('nombre') or 'Servidor'),
            thumbnail=_icon('xtream_servidores.png'),
            plot='Solo las categorías de este servidor. Abre aunque los demás estén caídos.')
    for f in m3us:
        ui_utils.add_item(
            action='fuentes_m3u', fid=f['id'], folder=True,
            title='[B]{0}[/B]'.format(f.get('nombre') or 'Lista M3U'),
            thumbnail=_icon('carpeta.png'),
            plot='Lista M3U. Se lee tal cual, sin categorías de servidor.')
    _fin()


def _categorias_en_paralelo(fuentes, seccion):
    """`(con_datos, sin_contestar)`: las categorías de todas las fuentes a la vez.

    Pide las categorías de todas las fuentes concurrentemente en paralelo.
    Es el mismo patrón que `fuentes_servidores._analizan_en_paralelo()`, hilos `daemon`,
    una cola, y el plazo comprobado en el bucle de espera, con dos diferencias:

    - Aquí los hilos **solo** piden por red y recogen el resultado. Ni avisan ni miran de
      qué clase es el fallo: `_de_un_error()` abre un diálogo modal, y los diálogos de Kodi
      no se abren desde un hilo. Eso se hace después, en el hilo principal.
    - Aquí **sí** importa saber cuáles fallaron, porque con eso se pinta una fila.

    `sin_contestar` junta las dos formas de no llegar, haber dado error y haberse acabado el
    plazo, porque para la pantalla son lo mismo, y separarlas sería dar información que no
    se tiene.
    """
    import threading
    import time

    try:
        import queue as cola_modulo
    except ImportError:                               # pragma: no cover
        import Queue as cola_modulo

    import fuentes_xtream

    trabajo = cola_modulo.Queue()
    for f in fuentes:
        trabajo.put(f['id'])
    por_id = {f['id']: f for f in fuentes}

    con_datos = []
    errores = []
    cerrojo = threading.Lock()

    def _obrero():
        while True:
            try:
                fid = trabajo.get_nowait()
            except cola_modulo.Empty:
                return
            f = por_id[fid]
            # El `try` es por fuente, no por hilo: una que revienta se queda sin
            # categorías y las demás siguen. Al revés, una excepción sin capturar tumba el
            # hilo y deja trabajo en la cola que nadie va a sacar.
            try:
                cats = fuentes_xtream.categorias(f, seccion)
            except Exception as e:
                with cerrojo:
                    errores.append((f, e))
                continue
            if not isinstance(cats, list):
                # Sin datos no es un error: un panel puede no tener esa sección.
                continue
            with cerrojo:
                con_datos.append((f, cats))

    cuantos = min(HILOS_CATEGORIAS, len(fuentes))
    hilos = [threading.Thread(target=_obrero) for _ in range(cuantos)]
    for h in hilos:
        h.daemon = True
        h.start()

    limite = time.time() + PLAZO_CATEGORIAS
    try:
        while True:
            with cerrojo:
                hechos = len(con_datos) + len(errores)
            # La condición es `hechos`, no `len(con_datos)`: una fuente que falla no deja
            # categorías, y esperar a las que contestan sería esperar a una que no va a
            # llegar nunca.
            if hechos >= len(fuentes):
                break
            if time.time() >= limite:
                _log('las categorías han llegado al plazo de {0}s con {1} de {2}'.format(
                    PLAZO_CATEGORIAS, hechos, len(fuentes)))
                break
            time.sleep(0.05)
    finally:
        # Lo que se devuelve son copias hechas ahora: los hilos pueden seguir dentro
        # (los que se han quedado sin responder), y devolver las listas que siguen tocando
        # sería darle al llamante algo a medio escribir.
        with cerrojo:
            con_datos = list(con_datos)
            errores = list(errores)

    # Los avisos van aquí, en el hilo principal y en el orden de las fuentes.
    for f, e in errores:
        _de_un_error(e, f)

    buenas = set(f['id'] for f, _ in con_datos)
    sin_contestar = [f for f in fuentes if f['id'] not in buenas]
    return con_datos, sin_contestar


def _vacio(seccion, texto, detalle=''):
    """Una pantalla vacía que explica por qué **y qué hacer**, no una en blanco.

    Sin explicación, una sección vacía parece un fallo. La fila es el botón de añadir, así que
    el rótulo tiene que decirlo.

    El `plot` lleva el detalle, que es donde hay sitio para la explicación larga.
    """
    ui_utils.add_item(action='fuentes_srv_add',
                      title='[B]{0}[/B]'.format(texto),
                      thumbnail=_icon('tv.png'), folder=False,
                      plot='{0}\n\n[COLOR gray]Pulsa para añadir uno.[/COLOR]'.format(detalle))
    _log('sección {0} vacía: {1}'.format(seccion, texto), xbmc.LOGINFO)
    _fin()


def _fila_refrescar(**params):
    """La última fila de una lista: pedirla otra vez al servidor aunque la copia valga.

    Con «Hasta que lo refresque yo» es lo único que renueva la caché; con cualquier otro TTL,
    lo que sirve para ver ya lo que el panel acaba de añadir. `params` es lo que `refrescar()`
    necesita para pedir esa misma lista.
    """
    ui_utils.add_item(
        action='fuentes_refrescar', folder=False,
        title='[COLOR gray]Refrescar esta lista[/COLOR]',
        thumbnail=_icon('xtream_refrescar.png'),
        plot='Vuelve a pedir esta lista al servidor aunque la copia guardada siga valiendo.',
        **params)


def refrescar(params):
    """Pide al servidor la lista de una fila «Refrescar» (`forzar=True`) y repinta.

    Es una acción de script y no una carpeta con `forzar=1` en la dirección: así la pantalla que
    queda es la de siempre, y un `Container.Refresh` posterior (marcar un favorito) no vuelve a ir
    a la red. En una categoría renueva **la página que se ve**; si el panel pagina y la categoría
    estaba indexada, las demás páginas siguen saliendo de la copia entera hasta que caduque.
    """
    import fuentes_xtream

    f = _fuente(params.get('fid', ''))
    if not f:
        _aviso('Ese servidor ya no está.')
        return
    que = params.get('que', '')
    try:
        pagina = max(int(params.get('page') or 0), 0)
    except ValueError:
        pagina = 0
    dp = _progreso('Pidiendo la lista al servidor')
    try:
        if que == 'cats':
            fuentes_xtream.categorias(f, params.get('sec', 'live'), dp, forzar=True)
        elif que == 'list':
            fuentes_xtream.listado(f, params.get('sec', 'live'), params.get('cat', ''), pagina,
                                   dp=dp, forzar=True)
        elif que == 'series':
            fuentes_xtream.series(f, params.get('cat', ''), pagina, dp, forzar=True)
        elif que == 'seasons':
            fuentes_xtream.info_serie(f, params.get('serie', ''), dp, forzar=True)
        elif que == 'episodes':
            fuentes_xtream.capitulos(f, params.get('serie', ''),
                                     params.get('temp', '').strip() or None, dp, forzar=True)
        elif que == 'm3u':
            _leer_m3u(f, dp, forzar=True)
        else:
            _log(f'refrescar: no sé refrescar {que!r}', xbmc.LOGWARNING)
            return
    except Exception as e:
        _de_un_error(e, f)
        if isinstance(e, fuentes_xtream.ErrorRed):
            # `_de_un_error()` solo lo apunta en el log; aquí se ha pulsado un botón y hay que
            # decir algo.
            xbmcgui.Dialog().notification(_NOMBRE, 'El servidor no ha contestado. '
                                                   'Sigue la copia guardada.')
        return
    finally:
        _cerrar_progreso(dp)
    xbmc.executebuiltin('Container.Refresh')


# --- las listas M3U --------------------------------------------------------

def m3u(fid):
    """Los canales de una lista M3U, de lectura.

    Una M3U **no tiene API de categorías de servidor**: tiene lo que viene dentro del propio
    fichero, y el proyecto ya sabe interpretarlo (`iptv_parse.parse_any`). Por eso esta
    pantalla existe y no es un adorno: sin ella, la fila de una lista M3U llevaría a "editar
    host y contraseña", que no tiene sentido ninguno porque una M3U no tiene host ni
    contraseña. Solo tiene una dirección.

    Se parsea con `iptv_parse` sin reimplementar lógica adicional. Es de lectura: una M3U en
    esta sección no tiene PVR, ni grabación, ni favoritos del addon, funciones que gestiona la
    pila IPTV con la lista importada. El `plot` lo dice, y hay una fila que la importa.

    Las categorías se leen del grupo que trae cada canal (`group-title`), que es lo que la
    propia lista declara.
    """
    f = _fuente(fid)
    if not f or f['tipo'] != 'm3u':
        _aviso('Esa fuente no es una lista M3U.')
        _fin(False)
        return
    _contenido()

    dp = _progreso('Leyendo la lista')
    try:
        filas = _leer_m3u(f, dp)
    except Exception as e:
        _de_un_error(e, f)
        _fin(False)
        return
    finally:
        _cerrar_progreso(dp)

    if not filas:
        ui_utils.add_item(
            action='fuentes_srv_edit', fid=fid,
            title='[B]No se ha podido leer la lista[/B]',
            thumbnail=_icon('tv.png'), folder=False,
            plot='El servidor no ha contestado, o el fichero no es una lista M3U. El detalle '
                 'esta en el log de Kodi.')
        _fin()
        return

    import fuentes_store
    varias = len(fuentes_store.fuentes()) > 1
    if varias:
        fuentes_store.apunta_ultimo_servidor('live', fid)
        _fila_cambiar_servidor('live', f.get('nombre') or 'Lista M3U')

    grupos = {}
    for ch in filas:
        grupos.setdefault(ch.get('group') or '', []).append(ch)

    for grupo, canales in sorted(grupos.items(), key=lambda kv: kv[0].lower()):
        ui_utils.add_item(
            action='fuentes_list', fid=fid, cat='', sec='m3u', g=grupo, folder=True,
            title=grupo or 'Sin categoría',
            thumbnail=_icon('fuentes_categorias.png'),
            plot='{0} canales.'.format(len(canales)))
    _fila_refrescar(que='m3u', fid=fid)
    _fin()


def _sid_de(fila):
    """El identificador estable de un canal de una lista M3U.

    **No es la posición ni el índice.** La lista se puede refrescar, y si un canal se
    cae del principio todos los de detrás cambian de número: el favorito, «Lo más
    usado» y el historial apuntarían entonces a otro canal, que es peor que no
    apuntar a ninguno.

    Se calcula de la URL **saneada** y el nombre, que es lo que de verdad identifica
    al canal. Así sobrevive a un refresco y a un reordenado de la lista, y no
    depende de dónde esté colocado. Doce dígitos de sha1: no colisiona en una lista
    y cabe en un `plugin://` y en la clave de favorito.

    La URL saneada y no la original a propósito: el `sid` viaja en el `plugin://`,
    que Kodi escribe en el historial de la tele, así que no puede llevar dentro la
    contraseña ni un derivado de ella.
    """
    base = '{0}|{1}'.format(fila.get('url_limpia') or fila.get('url') or '',
                            fila.get('name') or fila.get('nombre') or '')
    return hashlib.sha1(base.encode('utf-8')).hexdigest()[:12]


def _canales_de_parseo(resultado):
    """Los canales de lo que devuelve `iptv_parse.parse_any()`, **sin la URL con clave**.

    `parse_any()` devuelve un dict con la clave `channels`.

    Se excluye la URL con credenciales en claro por seguridad: el `fid` y el índice
    bastan para reproducir en diferido con `fuentes_play`.
    """
    crudos = resultado.get('channels') if isinstance(resultado, dict) else resultado
    if not isinstance(crudos, list):
        return []
    # El saneador del cliente para eliminar credenciales de la query si las hubiera.
    import fuentes_xtream
    out = []
    for c in crudos:
        if not isinstance(c, dict):
            continue
        fila = {k: v for k, v in c.items() if k not in ('url', 'direct_source')}
        # Dos URLs: una M3U de panel puede traer el canal con credenciales en la ruta.
        # - url: la original para reproducir el stream.
        # - url_limpia: la saneada que se muestra en la interfaz y en el historial.
        original = str(c.get('url') or '')
        fila['url'] = original
        fila['url_limpia'] = fuentes_xtream._sin_credenciales(original)
        # El `sid` se calcula según los atributos de la fila para identificarla de forma estable.
        fila['sid'] = _sid_de(fila)
        out.append(fila)
    return out


def _leer_m3u(f, dp=None, forzar=False, red=True):
    """Descarga y parsea una M3U, con caché. Devuelve la lista de canales.

    Va por `iptv_lists._download()` con `lan_ok=True`, porque una lista también puede estar en la
    red local, que es lo que `_download` bloquea por defecto
    (`iptv_lists._download()`).

    Con `red=False` solo mira la copia guardada y devuelve `None` si no la hay: es lo que deja a
    quien llama abrir un progreso solo cuando de verdad va a descargar.
    """
    import fuentes_xtream
    import fuentes_store
    import iptv_lists
    import iptv_parse as P

    guardado = None if forzar else fuentes_store.cache_leer(f['id'], 'm3u',
                                                            fuentes_xtream.ttl_de())
    # Una caché vacía es de una descarga que salió mal (login, corte); se vuelve a pedir.
    if isinstance(guardado, list) and guardado:
        # Las cachés antiguas guardaban las filas sin `sid`: se calcula aquí con la URL
        # saneada y el nombre, que sí traen, en vez de esperar al refresco.
        return [x if (isinstance(x, dict) and x.get('sid'))
                else dict(x, sid=_sid_de(x))
                for x in guardado if isinstance(x, dict)]
    if not red:
        return None
    crudo =iptv_lists._download(f['url'], False, dp, limit=iptv_lists._MAX_DOWNLOAD,
                                  lan_ok=True, timeout=iptv_lists._TIMEOUT)
    resultado = P.parse_any(P.decode(crudo), f['url'])
    filas = _canales_de_parseo(resultado)

    # Lo que va a la caché es la fila entera, con la URL original.
    # Se guarda la fila completa con la URL original para poder reproducir desde la caché.
    # Está en la misma carpeta que `mis_fuentes.json` y evita volver a descargar la lista
    # completa en cada cambio de canal.
    # seguridad meten los dos en el mismo grupo (`storage_manager.py:111`). Volver a
    # descargar la lista en cada cambio de canal son segundos de espera por canal.
    # Sigue prohibido que la credencial llegue al `plugin://`, al `plot`, al
    # título o al log: la fila va con `fid` y `sid`, y la URL solo la ve
    # `_reproducir_m3u()`.
    if filas:
        fuentes_store.cache_escribir(f['id'], 'm3u', filas)
    return filas


# --- el listado ------------------------------------------------------------

def listado(fid, seccion='live', categoria='', pagina=0, grupo=''):
    """Una página de canales de una categoría.

    Cada fila lleva `fid`, `sid`, `sec` y el título, y **nada más**. La URL no, porque lleva el
    usuario y la clave dentro del camino y esta fila acaba en el historial de Kodi, en el
    favorito y en la grabación.

    Al final va la fila de "página siguiente" si el cliente dice que hay más, y con el tope de
    `MAX_PAGINAS` para que un panel que no implemente `limit` no produzca un bucle infinito.
    Cuando se llega al tope se dice, en vez de dejar de paginar sin explicación.

    `grupo` es lo que usa la lista M3U: ahi las "categorías" son los `group-title` del fichero,
    que no tienen identificador, y el filtro va por nombre. Con Xtream no se usa, porque ahi si
    hay `category_id`.
    """
    import fuentes_xtream

    f = _fuente(fid)
    if not f:
        _aviso('Ese servidor ya no está.')
        _fin(False)
        return
    if seccion == 'm3u' or f['tipo'] == 'm3u':
        return _listado_m3u(f, grupo)
    if seccion == 'series':
        # Las filas de categoría llegan aquí en todas las secciones. Las series no son canales:
        # traen `series_id` y no `stream_id`, y `fuentes_xtream.listado()` las descartaba todas
        # y guardaba ese vacío con la misma clave de caché que usa `series()`.
        return series(fid, categoria, pagina)
    if seccion not in fuentes_xtream.SECCIONES:
        seccion = 'live'
    _contenido('vod' if seccion == 'vod' else None)

    pagina = max(int(pagina or 0), 0)
    if pagina >= MAX_PAGINAS:
        _aviso('Se ha llegado a la página {0}, que es el tope de esta sección.\n\n'
               'Si la lista está más llena de lo que debería, probablemente el servidor no está '
               'respetando el número de canales por página.'.format(pagina))
        _fin()
        return

    dp = _progreso('Cargando canales')
    try:
        filas, hay_mas = fuentes_xtream.listado(f, seccion, categoria, pagina, dp=dp)
    except Exception as e:
        _de_un_error(e, f)
        _fin(False)
        return
    finally:
        _cerrar_progreso(dp)

    if not filas:
        if pagina == 0:
            ui_utils.add_item(
                action='fuentes_srv_edit', fid=fid,
                title='[B]Esta categoría no tiene canales[/B]',
                thumbnail=_icon('xtream_volver.png'), folder=False,
                plot='El servidor ha dicho que esta categoría existe, pero no ha devuelto '
                     'ningún canal. O está vacía, o el panel no responde bien.')
            _fin()
        else:
            # Página vacía: en Kodi una lista vacía y una que ha fallado se ven igual, así que se
            # dice qué página era y se ofrece volver a la anterior.
            ui_utils.add_item(
                action='fuentes_list', fid=fid, sec=seccion, cat=categoria, g=grupo,
                page=pagina - 1, folder=True,
                title='[B]No hay más en esta categoría[/B]',
                thumbnail=_icon('xtream_fin_cat.png'),
                plot='La página {0} no ha devuelto ningún canal. Puede ser el final de la '
                     'categoría, o que el servidor no esté respetando el número de canales '
                     'por página.'.format(pagina + 1))
            _fin(reemplazar=True)
        return

    import fuentes_xtream as _XT
    # El idioma se calcula antes de limpiar el título y se guarda en la fila como
    # 'es_espanol'. Esto permite retirar etiquetas como '[ES]' de la vista sin alterar
    # el filtrado ni la ordenación por idioma posterior.
    #
    # Asimismo, 'nombre_limpio' se precalcula aquí para que _now_map() disponga de
    # los alias normalizados antes de asociar la programación de la guía.
    import iptv_parse as _P
    for _fila in filas:
        if 'es_espanol' not in _fila:
            _fila['es_espanol'] = _XT.lang_es(_fila.get('nombre'))
        if _fila.get('nombre_original') is None:
            _fila['nombre_original'] = _fila.get('nombre')
        if _fila.get('nombre_limpio') is None:
            _fila['nombre_limpio'] = _P.limpiar_titulo(_fila.get('nombre'))

    # Los favoritos se leen una vez para toda la página.
    marcados = _favoritos_de(f['id'], seccion)
    # La guía se pide una vez para toda la página.
    ahora = {}
    if seccion == 'live':
        ahora = _now_map(filas, _guia_de(f))
    # TMDB, para cine y series. Solo de caché, y lo que falte se pide en segundo plano.
    fichas = {}
    if seccion in ('vod', 'series'):
        fichas = _tmdb_de(filas, seccion)
        _enriquece_en_segundo_plano([f for f in filas if f['sid'] not in fichas], seccion)
    # Priorización y filtrado de idioma dentro de la página actual.
    #
    # Las dos cosas se hacen aquí, antes del bucle, y solo a las `filas` de esta página. No se
    # pueden hacer sobre el canal entero, y conviene decir por qué: la lista viene paginada del
    # panel (`start` y `limit`), así que en la página 1 no se sabe nada de la 5. Ordenar o filtrar
    # «los españoles primero» sobre el todo daría un resultado que depende de cuántas páginas se
    # hayan cargado, y eso no es una función sino un accidente.
    #
    # El que sí funciona entero es `solo_espanol`, porque quitar no depende de lo que haya
    # más adelante: una página sin español sale más corta, y si no sale de ninguna se ve el
    # aviso de «no hay canales», que ya existe.
    #
    # Y `espanol_primero` está puesto a `true` por defecto porque no esconde contenido: solo
    # cambia el orden dentro de la página priorizando canales en español. Lo que sí filtra es
    # `solo_espanol`, que viene desactivado (`false`) de inicio.

    _solo_es = _XT._ajuste('fuentes_solo_espanol').lower() in ('true', '1', 'yes', 'si')
    if _solo_es:
        filas = [x for x in filas if x['es_espanol']]
    elif _XT._ajuste('fuentes_espanol_primero').lower() in ('true', '1', 'yes', 'si'):
        # Orden estable: entre los españoles se respeta el orden del panel, que es el del
        # servidor y no el alfabético. `sorted` de Python es estable, asi que con la clave sola
        # ya sale: no hace falta un indice que rompa la igualdad.
        filas = sorted(filas, key=lambda x: (0 if x['es_espanol'] else 1))

    for fila in filas:
        _canal(f, fila, seccion, marcados, ahora, fichas.get(fila['sid']))

    if hay_mas:
        ui_utils.add_item(
            action='fuentes_list', fid=fid, cat=categoria, sec=seccion,
            page=pagina + 1, folder=True,
            title='[B]Página {0}[/B]'.format(pagina + 2),
            thumbnail=_icon('fuentes_siguiente.png'),
            plot='Ver los siguientes {0} canales.'.format(len(filas)))
    _fila_refrescar(que='list', fid=fid, sec=seccion, cat=categoria, page=pagina)
    _fin(reemplazar=pagina > 0)


def _listado_m3u(f, grupo=''):
    """Los canales de un grupo de una lista M3U.

    **Van todos de golpe y sin paginar**, y es a propósito: el fichero ya está entero en
    memoria (descargado una vez y cacheado) y el filtrado es una comparación de cadenas. Poner
    una "página siguiente" aquí sería una fila que no aporta nada: el coste ya está pagado y
    filtrar 5 000 canales por `group` es instantáneo.

    La fila no lleva ninguna URL: va con `fid` y `sid` para que la URL se resuelva
    en el momento de reproducir, evitando almacenar credenciales en el historial.
    """
    _contenido()
    dp = _progreso('Leyendo la lista')
    try:
        canales = _leer_m3u(f, dp)
    except Exception as e:
        _de_un_error(e, f)
        _fin(False)
        return
    finally:
        _cerrar_progreso(dp)

    if grupo:
        canales = [c for c in canales if (c.get('group') or '') == grupo]
    if not canales:
        ui_utils.add_item(action='fuentes_m3u', fid=f['id'],
                          title='[B]Esta categoría no tiene canales[/B]',
                          thumbnail=_icon('xtream_volver.png'), folder=True,
                          plot='La lista se ha leído bien, pero no hay ningún canal en este '
                               'grupo. Vuelve a la lista y elige otro.')
        _fin()
        return

    # Los favoritos se leen una vez para comparar en memoria.
    import fuentes_store
    favs = set((x['fid'], x['sid'], x['seccion']) for x in fuentes_store.favoritos())

    for ch in canales:
        nombre = ch.get('name') or 'Sin nombre'
        sid = ch.get('sid') or _sid_de(ch)
        marcado = (str(f['id']), str(sid), 'm3u') in favs
        # `_contexto_canal()` trabaja con las claves de una fila Xtream (`nombre`,
        # `logo`), y las de una M3U son otras (`name`, `logo`). Se le pasa lo que
        # espera, sin tocar la fila del canal.
        contexto = _contexto_canal(f, {'sid': sid, 'nombre': nombre,
                                       'logo': ch.get('logo') or ''},
                                   'm3u', marcado)
        ui_utils.add_item(
            action='fuentes_play', fid=f['id'], sid=sid, sec='m3u', title=nombre,
            thumbnail=ch.get('logo') or _icon('directo.png'),
            folder=False, plot=_plot_m3u_de(ch), context=contexto)
    _fin()


def _plot_m3u_de(ch):
    partes = []
    if ch.get('group'):
        partes.append('Grupo: {0}'.format(ch['group']))
    if ch.get('radio'):
        partes.append('[COLOR yellow]Emisora de radio[/COLOR]')
    return '\n'.join(partes)


def _favoritos_de(fid, seccion):
    """Los sid de una fuente y seccion que ya estan en favoritos. **Una sola lectura**.

    Devuelve un set, que es lo que hace la comprobacion del interior de la fila sea una
    pertenencia y no una lectura de fichero. Y devuelve el conjunto **completo**, no el de la
    seccion, porque el filtro lo hace quien lo llama: asi el mismo conjunto sirve para las tres
    secciones y no hay que leer tres veces.
    """
    import fuentes_store
    try:
        return {str(x['sid']) for x in fuentes_store.favoritos()
                if str(x['fid']) == str(fid) and x.get('seccion', 'live') == seccion}
    except Exception:
        # Un fichero de favoritos ilegible no puede tumbar un listado de canales: se muestra
        # sin la marca y ya esta. Perder la marca es molesto; perder la pantalla es inservible.
        return set()


def _canal(f, fila, seccion, marcados=None, ahora=None, tmdb=None):
    """Una fila de canal. Ni la URL, ni el usuario, ni la clave.

    `marcados` es el conjunto de `sid` que ya están en favoritos, leído en lote
    para toda la pantalla.

    `tmdb` es la ficha de TMDB si está disponible en caché. Si no está en caché,
    se muestra con los datos proporcionados por el panel.
    """
    import fuentes_store

    ahora = ahora or {}

    # El nombre que se pinta es el `nombre_limpio` que puso `listado()` en el paso 2.
    #
    # Aqui no se limpia nada, y es a proposito. El paso 2 vive en `listado()`, que es por
    # donde pasan todas las filas: alli se calcula `es_espanol` del nombre con etiquetas y
    # despues se guarda el nombre limpio. Si se limpiara aqui, `_canal()` tendria su propia
    # copia de la logica, y cualquier arreglo en un sitio se quedaria sin hacer en el otro.
    #
    # La salida elegante es el nombre del panel: si alguna vez se pinta una fila que no ha
    # pasado por `listado()`, se ve con sus etiquetas, que es lo que hacia antes, y no una
    # excepcion.
    nombre = fila.get('nombre_limpio') or fila.get('nombre') or ''
    if fila.get('num'):
        nombre = '[COLOR gray]{0}[/COLOR] {1}'.format(fila['num'], nombre)
    sid = str(fila['sid'])
    if marcados is None:
        marcado = fuentes_store.es_favorito(f['id'], sid, seccion)
    else:
        marcado = sid in marcados
    contexto = _contexto_canal(f, fila, seccion, marcado, ahora.get(fila['sid']))

    if tmdb:
        li = _li_con_tmdb(tmdb, nombre)
        if li is not None:
            # Con la ficha de TMDB, el `plot` es el suyo y el icono es su poster: lo que la base de
            # datos sabe del título es mejor que lo que dijo el panel. El `thumb` del panel se queda
            # como respaldo si no hay poster.
            ui_utils.add_item(
                action='fuentes_play', fid=f['id'], sid=fila['sid'], sec=seccion, title=nombre,
                thumbnail=fila.get('poster') or fila['logo'] or _icon('directo.png'),
                folder=False, li=li, context=contexto)
            return

    ui_utils.add_item(
        action='fuentes_play', fid=f['id'], sid=fila['sid'], sec=seccion, title=nombre,
        thumbnail=fila.get('poster') or fila['logo'] or _icon('directo.png'),
        folder=False,
        plot=_plot_de(fila, ahora.get(fila['sid'])),
        context=contexto)


def _tmdb_de(filas, seccion):
    """Los metadatos de TMDB para estas filas, **solo de la caché**. `{}` si no hay clave.

    Se reutiliza `metadata_enricher` entero: su caché en SQLite, su límite de concurrencia, su
    deduplicación de peticiones iguales y su límite de peticiones. Escribir otra cosa aquí sería
    tener dos clientes de TMDB en el mismo addon, con dos cachés y dos límites.

    **Nunca se pide nada a la red en esta función.** Enseñar una lista no puede ponerse a
    descargar cien fichas mientras se espera: serían cien peticiones y un 429. Lo que sí
    se hace, en segundo plano, es `_enriquece_en_segundo_plano()`.

    Y si no hay clave de API se sale antes de mirar nada: sin clave, `enrich()` devuelve vacío
    siempre y avisar en el log por cada fila sería ruido.
    """
    if not _hay_clave_tmdb():
        return {}
    try:
        import metadata_enricher as me
    except Exception as e:                              # pragma: no cover
        _log('no se ha podido cargar metadata_enricher: {0}'.format(e))
        return {}
    tipo = 'movie' if seccion == 'vod' else 'show'
    salida = {}
    for fila in filas:
        # Se usa `nombre_limpio` para omitir etiquetas al consultar TMDB.
        titulo = _titulo_tmdb(fila)
        if not titulo:
            continue
        try:
            meta = me.enrich(title=titulo, year=fila.get('year') or None,
                             media_type=tipo, use_cache_only=True)
        except Exception as e:
            _log('TMDB: {0}'.format(e))
            continue
        if meta:
            salida[fila['sid']] = meta
    return salida


def _hay_clave_tmdb():
    """True si hay clave de API puesta. Sin ella, TMDB no devuelve nada."""
    try:
        import core_settings
        return bool(core_settings.get_tmdb_api_key())
    except Exception:                                   # pragma: no cover
        return False


def _titulo_tmdb(fila):
    """El título con el que buscar en TMDB: `nombre_limpio`, no `nombre`.

    Las filas llegan con etiquetas (`Canal [ES] 4K (2019)`) y `nombre_limpio` ya las
    tiene quitadas (las pone `listado()` en el paso 2). Buscando con `nombre` se busca la
    etiqueta incluida y TMDB no encuentra nada.

    La fila ya tiene el nombre limpio, así que usarlo no cuesta nada. Y si no lo tiene
    (una fila que no ha pasado por `listado()`), se cae en `nombre`.
    """
    return (fila.get('nombre_limpio') or fila.get('nombre') or '').strip()


def _clave_sin_ficha(titulo, tipo):
    """La clave de caché de un título que TMDB no tiene.

    Es un hash porque el título es texto libre y la clave es un **nombre de fichero**
    (`fuentes_store._CLAVE_RE`: solo letras, dígitos y guion). El tipo va delante para que
    una película y una serie con el mismo título no se confundan: son dos fichas distintas.
    """
    import hashlib
    return 'no_{0}_{1}'.format(tipo[0],
                               hashlib.sha1(titulo.encode('utf-8')).hexdigest()[:12])


def _ya_sin_ficha(titulo, tipo):
    """True si este título se buscó en TMDB, no estaba, y aún no ha caducado.

    `metadata_enricher` no guarda lo que no encuentra, así que se anota localmente
    para no relanzar búsquedas repetidas en segundo plano por títulos sin ficha.

    Un fallo leyendo la caché devuelve `False`: es mejor buscar de más que quedarse sin
    fichas por una caché ilegible.
    """
    import fuentes_store
    try:
        return fuentes_store.cache_leer(FID_SIN_FICHA, _clave_sin_ficha(titulo, tipo),
                                        TTL_SIN_FICHA) is not None
    except Exception as e:
        _log('caché negativa de TMDB: {0}'.format(e))
        return False


def _apunta_sin_ficha(titulo, tipo):
    """Apunta que este título no está en TMDB, para no volver a buscarlo en siete días."""
    import fuentes_store
    try:
        fuentes_store.cache_escribir(FID_SIN_FICHA, _clave_sin_ficha(titulo, tipo),
                                     {'titulo': titulo, 'tipo': tipo, 'cuando': 1})
    except Exception as e:
        _log('no se ha podido apuntar la ficha que falta: {0}'.format(e))


def _ruta_contenedor():
    """La ruta del contenedor que Kodi tiene abierto ahora mismo.

    Se guarda antes de lanzar el hilo de TMDB y se compara al terminar: si la pantalla ya no
    es la misma, refrescarla sacaría al usuario de donde está.

    Un `getInfoLabel` que falla devuelve cadena vacía, que es un valor válido para comparar:
    dos vacíos son «la misma».
    """
    try:
        return xbmc.getInfoLabel('Container.FolderPath')
    except Exception:                                   # pragma: no cover
        return ''


def _enriquece_en_segundo_plano(filas, seccion):
    """Pide a TMDB las fichas que faltan, en un hilo aparte, y refresca cuando estén.

    Es **el** motivo por el que esto no da un 429: las peticiones salen después de pintar la
    pantalla, en un hilo `daemon` con dos workers, y en cuanto hay algo nuevo se refresca el
    contenedor para que aparezca. Se ve la lista con lo que daba el panel en el primer
    instante, y la información va llegando sola.

    1. Se busca con `nombre_limpio` y no con `nombre`: la fila trae etiquetas (`[ES]`, `4K`,
       `(2019)`) y buscar con ellas bajaba muchísimo el acierto.
    2. Los títulos que TMDB **no** tiene se apuntan (`_apunta_sin_ficha()`) y se saltan si ya
       están (`_ya_sin_ficha()`). Sin eso, cada visita a la misma página relanzaba las mismas
       búsquedas.
    3. El refresco va **solo si la pantalla sigue siendo la que lanzó el hilo**; si no,
       refrescaría lo que haya abierto en ese momento, aunque sea otra sección u otro addon.
    """
    tipo = 'movie' if seccion == 'vod' else 'show'
    pendientes = []
    for f in filas:
        if f.get('tmdb_id'):
            continue
        titulo = _titulo_tmdb(f)
        if not titulo:
            continue
        if _ya_sin_ficha(titulo, tipo):
            continue
        pendientes.append((f, titulo))
    if not pendientes or not _hay_clave_tmdb():
        return

    # Guarda la ruta del contenedor actual para no refrescar una pantalla distinta.
    ruta = _ruta_contenedor()

    def _va():
        try:
            import metadata_enricher as me
            items = [{'tmdb_id': None, 'imdb_id': '', 'title': titulo,
                      'year': f.get('year') or None, 'media_type': tipo}
                     for f, titulo in pendientes]
            # `batch_enrich` devuelve los resultados en el mismo orden que los items, así
            # que se pueden emparejar para saber de qué título es cada uno.
            resultados = me.batch_enrich(items, max_workers=2)
            if any(resultados) and xbmc.getInfoLabel('Container.FolderPath') == ruta:
                xbmc.executebuiltin('Container.Refresh')
            for (_f, titulo), meta in zip(pendientes, resultados):
                if not meta:
                    _apunta_sin_ficha(titulo, tipo)
        except Exception as e:
            _log('TMDB en segundo plano: {0}'.format(e))

    import threading
    hilo = threading.Thread(target=_va, daemon=True)
    hilo.start()


def _li_con_tmdb(meta, etiqueta):
    """Un `ListItem` con los metadatos de TMDB, o `None` si no se pudo hacer.

    Devuelve el `ListItem` **listo para `ui_utils.add_item(li=...)`**, que es la costura que hace
    falta para esto: `add_item()` construye el suyo con cuatro campos, y año, nota, reparto,
    director y duración no están entre ellos.
    """
    try:
        import xbmcgui
        import metadata_enricher as me
    except Exception:                                   # pragma: no cover
        return None
    try:
        # La misma etiqueta que la fila sin ficha: la limpia, sin `[ES] [1080p]`.
        li = xbmcgui.ListItem(label=etiqueta)
        me.apply_to_listitem(li, meta)
        return li
    except Exception as e:                              # pragma: no cover
        _log('no se ha podido aplicar la ficha de TMDB: {0}'.format(e))
        return None


def _contexto_canal(f, fila, seccion, marcado, ahora=None):
    """El menú contextual de un canal.

    El rótulo cambia según esté ya en favoritos o no, porque "Añadir a favoritos" sobre algo que
    ya está es un botón que no hace nada visible. Y la orden lleva **solo `fid`, `sid` y `sec`**:
    nada de URL, que en Xtream lleva el usuario y la clave dentro del camino.

    Solo se ofrece añadir a favoritos en lo que se puede reproducir desde la sección. Una serie
    no: su fila no es un canal, es una carpeta, y el favorito de una serie es de otra pantalla.

    La orden lleva `nombre`, `logo` y `ext` ademas de `fid`, `sid` y `sec`: sin ellos el
    favorito se guardaba sin nombre y la pantalla de Favoritos caia en "Canal 1234" para
    siempre. **Sigue sin ir la URL**, que es lo que no puede viajar en un `RunPlugin`.

    Y "Ver el programa de ahora" **solo aparece si hay programa**. Ponerlo siempre sería un botón
    que en la mayoría de las filas lleva a "Sin programación disponible", que es un botón que no
    hace nada.
    """
    # «de EspaTV»: Kodi en español añade su propio «Añadir a favoritos» a este menú.
    etiqueta = ('Quitar de favoritos de EspaTV' if marcado
                else 'Añadir a favoritos de EspaTV')
    orden = 'RunPlugin({0})'.format(_u(action='fuentes_fav_toggle', fid=f['id'],
                                       sid=fila['sid'], sec=seccion,
                                       quitar='1' if marcado else '',
                                       nombre=fila.get('nombre') or '',
                                       logo=fila.get('logo') or '',
                                       ext=fila.get('ext') or ''))
    cm = [(etiqueta, orden)]
    if ahora:
        # El título y la descripción viajan en la orden. No la URL de la guía: esa lleva el
        # usuario y la clave de un panel Xtream en la query, y esto acaba en el historial de Kodi.
        cm.append(('Ver el programa de ahora',
                   'RunPlugin({0})'.format(_u(action='fuentes_guia_programa',
                                              fid=f['id'], sid=fila['sid'],
                                              sec=seccion,
                                              titulo=ahora[0] or '',
                                              desc=(ahora[3] or '')[:400]))))
    if seccion in ('live',):
        # Container.Update abre un directorio navegable para mostrar resultados de búsqueda.
        cm.append(('Buscar este nombre',
                   'Container.Update("{0}")'.format(_u(action='fuentes_search_all',
                                                       texto=fila['nombre'],
                                                       sec=seccion))))
    return cm


def ver_programa(params):
    """Abre el programa de ahora de un canal, en el visor de texto de la guía.

    Reutiliza `epg_texto.epg_texto_programa()` en vez de escribir un visor propio,
    ya que está probado con acentos y con saltos de línea.

    **No vuelve a preguntar nada**: lo que hay aquí es el título y la descripción que la guía ya
    tenía, y volver a pedirla sería una descarga para enseñar lo que ya se sabe.
    """
    titulo = (params.get('titulo') or '').strip()
    desc = (params.get('desc') or '').strip()
    if not titulo and not desc:
        _aviso('De ese programa no sé nada más.',
               'La guía solo trae el título y la descripción de lo que se emite ahora.')
        return
    import epg_texto
    epg_texto.epg_texto_programa(titulo, desc)


def _guia_de(f):
    """La guia de una fuente, sin credenciales a la vista ni excepciones.

    Envuelve a `fuentes_xtream.guia_de()` para que la vista no tenga que importar el
    cliente, y traga el error entero: una fuente sin guia se muestra sin «Ahora», que es
    exactamente lo que se busca.
    """
    try:
        import fuentes_xtream
        return fuentes_xtream.guia_de(f)
    except Exception as e:                              # pragma: no cover
        _log('no se ha podido construir la dirección de la guía: {0}'.format(
            fuentes_xtream._sin_credenciales(e)))
        return ''


def _alias_de_guia(fila):
    """Los nombres por los que una fila puede casar con la guía, en orden de prioridad.

    Son tres y el orden importa, porque `now_playing()` se queda con el primero que encuentra:

    1. El `tvg-id`, identificador principal del canal.
    2. El nombre tal como lo envió el panel (con etiquetas como `[ES]`).
    3. El nombre limpio, sin etiquetas.

    Permite emparejar tanto si la guía viene con el nombre limpio como si incluye la etiqueta.
    Sin duplicados ni cadenas vacías.
    """
    salida = []
    for nombre in (fila.get('epg') or fila.get('tvg_id') or '',
                  fila.get('nombre') or '',
                  fila.get('nombre_limpio') or ''):
        nombre = str(nombre or '').strip()
        if nombre and nombre not in salida:
            salida.append(nombre)
    return salida


def _now_map(filas, guia=''):
    """{posición: programa} de lo que se emite ahora. No realiza descargas de red.

    Consulta únicamente la caché local existente para evitar descargas pesadas
    al abrir la sección. Solo se ejecuta si alguna fila contiene identificador EPG.
    Cualquier fallo de lectura devuelve un mapa vacío de forma silenciosa.
    """
    # Cada fila pasa con todos sus alias posibles (tvg-id, nombre panel y limpio).
    claves = [(f.get('epg') or f.get('tvg_id') or '', _alias_de_guia(f))
              for f in filas]
    if not any(c[0] for c in claves):
        return {}
    try:
        import epg_texto
        encontrados = epg_texto.now_playing(claves, download=False, url=guia) or {}
    except Exception as e:
        # El `import` va dentro del `except`, y no antes: el cliente ya esta cargado en
        # cualquier caso, y aqui solo hace falta cuando algo falla.
        #
        # Y el saneado no es un lujo: el error de una guia viene con la direccion dentro, y la
        # direccion de un Xtream lleva el usuario y la clave en la query. Sin esto, la clave
        # acababa en `kodi.log`.
        try:
            import fuentes_xtream
            motivo = fuentes_xtream._sin_credenciales(e)
        except Exception:                              # pragma: no cover
            motivo = 'sin motivo conocido'
        _log('no se ha podido leer la guía: {0}'.format(motivo))
        return {}
    # `now_playing` devuelve las claves por posición en `claves`, y las filas se buscan
    # por `sid`. Sin esta traducción el «Ahora» no sale en ninguna, y el sintoma es que la
    # función está escrita, el botón existe y en pantalla no aparece nada.
    return {str(filas[pos]['sid']): prog
            for pos, prog in encontrados.items()
            if isinstance(pos, int) and 0 <= pos < len(filas)}

def _plot_de(fila, ahora=''):
    """El texto de la fila: qué es y de dónde viene, sin nada de más.

    La radio se dice **en el título del `plot`**, porque una emisora y un canal se distinguen por
    el icono y eso no se ve bien en un panel estrecho.
    """
    partes = []
    # «Ahora» va primero. Es lo primero que se lee de una fila y lo único que cambia
    # con el momento: el resto de líneas (categoría, EPG) son de la lista y son siempre las
    # mismas.
    if ahora:
        titulo, desde, hasta, desc = ahora
        momento = ''
        if hasta:
            momento = ('[COLOR gray] hasta las {0}[/COLOR]'.format(hasta))
        partes.append('[COLOR lime]Ahora: {0}[/COLOR]{1}'.format(titulo, momento))
        if desc:
            partes.append('[COLOR gray]{0}[/COLOR]'.format(desc))
    if fila.get('radio'):
        partes.append('[COLOR yellow]Emisora de radio[/COLOR]')
    # Ficha del contenido según los metadatos recibidos del panel.
    if fila.get('plot'):
        partes.append(fila['plot'])
    detalles = []
    if fila.get('year'):
        detalles.append(fila['year'])
    if fila.get('duracion'):
        detalles.append('{0} min'.format(fila['duracion']))
    if fila.get('rating'):
        detalles.append('nota {0}'.format(fila['rating']))
    if detalles:
        partes.append('  ·  '.join(detalles))
    if fila.get('generos'):
        partes.append(', '.join(fila['generos'][:4]))
    if fila.get('grupo'):
        partes.append('[COLOR gray]Categoría: {0}[/COLOR]'.format(fila['grupo']))
    if fila.get('epg'):
        partes.append('[COLOR gray]EPG: {0}[/COLOR]'.format(fila['epg']))
    return '\n'.join(partes)


def _progreso(que):
    """Un `DialogProgress`, o `None` si no se puede abrir.

    Si `create()` falla se devuelve `None` y la carga continúa sin indicador de progreso.
    """
    dp = xbmcgui.DialogProgress()
    try:
        dp.create(que, '')
    except Exception:                                   # pragma: no cover
        return None
    return dp


def _cerrar_progreso(dp):
    """Se cierra siempre. Un `DialogProgress` sin cerrar deja la ventana colgada."""
    if dp is None:
        return
    try:
        dp.close()
    except Exception:                                   # pragma: no cover
        pass


# --- series ----------------------------------------------------------------

def series(fid, categoria='', pagina=0):
    """Una página de series de una categoría. Como `listado()`, pero de series.

    La fila lleva `fid` y `sid` (el `series_id`) y **nada más**. Ni la URL, ni el usuario, ni
    la clave: entrar en una serie es `get_series_info` con ese id, y la URL del capítulo se
    monta al reproducir.
    """
    import fuentes_xtream

    f = _fuente(fid)
    if not f:
        _aviso('Ese servidor ya no está.')
        _fin(False)
        return
    _contenido('series')

    pagina = max(int(pagina or 0), 0)
    if pagina >= MAX_PAGINAS:
        _aviso('Se ha llegado a la página {0}, que es el tope.'.format(pagina))
        _fin()
        return

    dp = _progreso('Cargando series')
    try:
        filas, hay_mas = fuentes_xtream.series(f, categoria, pagina, dp=dp)
    except Exception as e:
        _de_un_error(e, f)
        _fin(False)
        return
    finally:
        _cerrar_progreso(dp)

    if not filas:
        if pagina == 0:
            ui_utils.add_item(
                action='fuentes_srv_edit', fid=fid,
                title='[B]Esta categoría no tiene series[/B]',
                thumbnail=_icon('cat_series.png'), folder=False,
                plot='El servidor ha dicho que la categoría existe pero no ha devuelto ninguna serie.')
            _fin()
            return
        # Si se avanza de página y no devuelve filas, se notifica el fin de la categoría.
        ui_utils.add_item(
            action='fuentes_series', fid=fid, cat=categoria, page=pagina - 1, folder=True,
            title='[B]No hay más en esta categoría[/B]',
            thumbnail=_icon('xtream_fin_cat.png'),
            plot='La página {0} no ha devuelto ninguna serie. Puede ser el final de la '
                 'categoría, o que el servidor no esté respetando el número de series por '
                 'página.'.format(pagina + 1))
        _fin(reemplazar=True)
        return

    for fila in filas:
        ui_utils.add_item(
            action='fuentes_seasons', fid=fid, serie=fila['id'], folder=True,
            title=fila['nombre'], thumbnail=fila['logo'] or _icon('cat_series.png'),
            plot=fila['plot'])

    if hay_mas:
        ui_utils.add_item(
            action='fuentes_series', fid=fid, cat=categoria, page=pagina + 1, folder=True,
            title='[B]Página {0}[/B]'.format(pagina + 2), thumbnail=_icon('fuentes_siguiente.png'),
            plot='Ver las siguientes series.')
    _fila_refrescar(que='series', fid=fid, cat=categoria, page=pagina)
    _fin(reemplazar=pagina > 0)


def temporadas(fid, serie):
    """Las temporadas de una serie, y al final todos los capítulos.

    Las dos cosas en la misma pantalla porque en la práctica es lo que se usa: se entra en la
    serie y se elige temporada, o se elige "todos" para ver los capítulos del final. Meter los
    capítulos de todas las temporadas detrás de un paso más sería un paso de más.

    El número de capitulos de cada temporada viene de `seasons` (`episode_count`), que es lo
    único fiable: contarlos uno a uno obliga a pedir `get_series_info`, que trae los
    capitulos enteros.
    """
    import fuentes_xtream

    f = _fuente(fid)
    if not f:
        _aviso('Ese servidor ya no está.')
        _fin(False)
        return
    _contenido('seasons')

    dp = _progreso('Cargando la serie')
    try:
        info = fuentes_xtream.info_serie(f, serie, dp)
    except Exception as e:
        _de_un_error(e, f)
        _fin(False)
        return
    finally:
        _cerrar_progreso(dp)

    for t in info.get('temporadas') or []:
        numero = t.get('numero')
        cuenta = t.get('capitulos')
        titulo = 'Temporada {0}'.format(numero)
        if t.get('nombre') and t['nombre'] != titulo:
            titulo = '{0}: {1}'.format(titulo, t['nombre'])
        if cuenta:
            titulo = '{0}  [COLOR gray]({1} cap.)[/COLOR]'.format(titulo, cuenta)
        ui_utils.add_item(
            action='fuentes_episodes', fid=fid, serie=serie, temp=str(numero), folder=True,
            title=titulo, thumbnail=info.get('logo') or _icon('cat_series.png'),
            plot='Los capítulos de la temporada {0}.'.format(numero))

    ui_utils.add_item(
        action='fuentes_episodes', fid=fid, serie=serie, folder=True,
        title='[B]Todos los capítulos[/B]', thumbnail=_icon('cat_series.png'),
        plot='Todos los capítulos de la serie, de la temporada más antigua a la más nueva.')

    if not info.get('temporadas'):
        _log('la serie {0} no ha declarado temporadas'.format(serie), xbmc.LOGINFO)
    _fila_refrescar(que='seasons', fid=fid, serie=serie)
    _fin()


def episodios(fid, serie, temporada=''):
    """Los capítulos de una temporada, o de toda la serie si no se dice cuál.

    El título lleva el número de capítulo **y** la temporada cuando se piden todos, que es lo
    que hace falta para no perder el hilo en una serie de diez temporadas.
    """
    import fuentes_xtream

    f = _fuente(fid)
    if not f:
        _aviso('Ese servidor ya no está.')
        _fin(False)
        return
    _contenido('episodes')

    num = temporada.strip() if temporada.strip() else None
    dp = _progreso('Cargando capítulos')
    try:
        filas = fuentes_xtream.capitulos(f, serie, num, dp)
    except Exception as e:
        _de_un_error(e, f)
        _fin(False)
        return
    finally:
        _cerrar_progreso(dp)

    if not filas:
        ui_utils.add_item(
            action='fuentes_seasons', fid=fid, serie=serie,
            title='[B]No hay capítulos[/B]', thumbnail=_icon('cat_series.png'), folder=True,
            plot='El servidor no ha devuelto ningún capítulo para esa temporada.')
        _fin()
        return

    con_temporadas = num is None
    for fila in filas:
        titulo = fila['nombre']
        if con_temporadas and fila.get('num') is not None:
            etiqueta = 'T{0} · E{1}'.format(fila.get('temporada') or 0, fila['num'])
        elif fila.get('num') is not None:
            etiqueta = 'Episodio {0}'.format(fila['num'])
        else:
            etiqueta = ''
        if etiqueta:
            titulo = '[COLOR gray]{0}[/COLOR] {1}'.format(etiqueta, titulo)
        ui_utils.add_item(
            action='fuentes_play', fid=fid, sid=fila['sid'], sec='series',
            ext=fila.get('ext') or '', title=titulo,
            thumbnail=fila['logo'] or _icon('cat_series.png'), folder=False)
    _fila_refrescar(que='episodes', fid=fid, serie=serie, temp=temporada)
    _fin()


# --- la busqueda ------------------------------------------------------------

def bajar_guia(params):
    """Descarga la guía de una fuente. **A propósito**, porque no se descarga sola.

    Existe por una razón concreta: `_now_map()` no descarga nunca, y sin este botón la línea
    «Ahora» de las filas no aparecería **jamás**. Abrir una lista de canales no puede
    COMER una guía de decenas de megabytes porque sí; esto es darle al botón.

    Se escribe en la caché de guías de `epg_texto`, que nombra el fichero con el hash de la
    dirección y **no guarda la dirección**: por eso una guía de un panel Xtream no deja la
    clave en el disco. De eso ya se preocupó el que lo escribió.

    Cancelar no es un error: no avisa de nada, porque no pasó nada.
    """
    import epg_texto
    import fuentes_xtream
    import fuentes_store

    f = fuentes_store.fuente(params.get('fid'))
    if not f:
        _aviso('Ese servidor ya no está.')
        return
    guia = _guia_de(f)
    if not guia:
        _aviso('Esta fuente no tiene dirección de guía.\n\n'
               'Un servidor Xtream siempre la tiene. Una lista M3U solo si trae '
               'url-tvg en la cabecera.')
        return

    dp = _progreso('Descargando la guía de {0}...'.format(f['nombre'] or 'la lista'))

    def progreso(leido, total):
        mb = '{0:.1f} MB'.format(leido / 1048576.0)
        if total:
            mb += ' de {0:.1f} MB'.format(total / 1048576.0)
            pc = min(99, leido * 100 // total)
        else:
            pc = 0
        if dp is not None:
            dp.update(pc, 'Descargando la guía...\n' + mb)
        return dp is None or not dp.iscanceled()

    try:
        encontrado = epg_texto.now_playing([], download=True, url=guia,
                                         progreso=progreso)
    except epg_texto.DescargaCancelada:
        return
    except epg_texto.GuiaDemasiadoGrande:
        _aviso('La guía de esta fuente es demasiado grande y no se puede cargar.')
        return
    except Exception as e:                              # pragma: no cover
        _log('no se ha podido descargar la guía: {0}'.format(
            fuentes_xtream._sin_credenciales(e)))
        _aviso('No se ha podido descargar la guía. Prueba más tarde.')
        return
    finally:
        _cerrar_progreso(dp)

    if encontrado is False:
        _aviso('La guía de esta fuente es demasiado grande y no se puede cargar.')
        return
    xbmc.executebuiltin('Container.Refresh')
    _aviso('Guía descargada. Ya sale lo que echan en cada canal.')


def _en_paralelo(trabajos, funcion, dp, rotulo):
    """`funcion(*t)` para cada `t` de `trabajos`, con `HILOS_CATEGORIAS` hilos. Devuelve
    `(hechos, fallos)`: listas de `(t, resultado)` y de `(t, excepción)`.

    Es el patrón de `_categorias_en_paralelo()` sin su plazo de 25 s: aquí son cientos de
    peticiones y quien manda es el botón de cancelar del `dp`. Cancelar deja de repartir
    trabajo, pero se espera a que acaben las peticiones en vuelo (cada una con su tiempo de
    espera de red), para no volver con hilos escribiendo todavía en la caché. Los hilos no
    abren diálogos: eso se hace después, en el hilo principal.
    """
    import queue
    import threading
    import time

    cola = queue.Queue()
    for t in trabajos:
        cola.put(t)
    hechos, fallos = [], []
    cerrojo = threading.Lock()
    parar = threading.Event()

    def _obrero():
        while not parar.is_set():
            try:
                t = cola.get_nowait()
            except queue.Empty:
                return
            try:
                r = funcion(*t)
            except Exception as e:
                with cerrojo:
                    fallos.append((t, e))
                continue
            with cerrojo:
                hechos.append((t, r))

    hilos = [threading.Thread(target=_obrero, daemon=True)
             for _ in range(min(HILOS_CATEGORIAS, len(trabajos)))]
    for h in hilos:
        h.start()
    total = len(trabajos)
    while any(h.is_alive() for h in hilos):
        if dp is not None:
            if dp.iscanceled():
                parar.set()
            with cerrojo:
                n = len(hechos) + len(fallos)
            texto = 'Cancelando...' if parar.is_set() else f'{rotulo}\n{n} de {total}'
            dp.update(n * 100 // total, texto)
        time.sleep(0.2)
    return hechos, fallos


def indexar(fid='', texto='', seccion=''):
    """Baja enteras las categorías de los servidores Xtream para que el buscador las encuentre.

    El buscador no va a la red (`buscar_todo()`), y con un panel que pagina solo encuentra lo que
    se ha abierto. Esto lo rellena: las categorías de las tres secciones y, de cada una, la lista
    entera (`fuentes_xtream.lista_entera()`). Al suponer múltiples peticiones de red y
    almacenamiento en disco, se ejecuta mediante un botón dedicado con barra de progreso.

    Con `texto`, viene de la pantalla de «No hay nada con...» y al terminar se repite esa
    búsqueda.
    """
    import fuentes_xtream

    fuentes = [_fuente(fid)] if fid else _fuentes_xtream()
    fuentes = [f for f in fuentes if f and f.get('tipo') != 'm3u']
    if not fuentes:
        _aviso('No hay ningún servidor Xtream que indexar. Las listas M3U ya se buscan enteras.')
        return

    dp = _progreso(f'Indexando {_NOMBRE}')
    try:
        secs = [seccion] if seccion in fuentes_xtream.SECCIONES else list(fuentes_xtream.SECCIONES)
        cats, fallos = _en_paralelo([(f, s) for f in fuentes for s in secs],
                                    fuentes_xtream.categorias, dp, 'Leyendo las categorías')
        cancelado = dp is not None and dp.iscanceled()
        trabajos = [(f, sec, c['id'], c.get('n') or '')
                    for (f, sec), lista in cats if isinstance(lista, list)
                    for c in lista if isinstance(c, dict) and c.get('id') not in (None, '')]
        hechos = []
        if not cancelado and trabajos:
            hechos, mas_fallos = _en_paralelo(trabajos, fuentes_xtream.lista_entera, dp,
                                              'Bajando las categorías')
            fallos += mas_fallos
            cancelado = dp is not None and dp.iscanceled()
    finally:
        _cerrar_progreso(dp)

    for t, e in fallos:
        _log(f"indexar: {t[0].get('nombre') or t[0]['id']} / {t[1]}: "
             f"{fuentes_xtream._sin_credenciales(e)}", xbmc.LOGWARNING)
    total = sum(n for _, n in hechos if isinstance(n, int))
    if cancelado:
        _aviso(f'Indexado a medias: {total} entradas. Lo que se ha bajado ya se puede buscar.')
    elif fallos:
        quienes = sorted({str(t[0].get('nombre') or 'Servidor') for t, _ in fallos})
        _aviso(f'{total} entradas listas para buscar.\n\n'
               f'No se ha podido leer todo de: {", ".join(quienes)}. '
               'Si un servidor no contesta, compruébalo desde su menú.')
    else:
        xbmcgui.Dialog().notification(_NOMBRE, f'{total} entradas listas para buscar.')
    if texto:
        xbmc.executebuiltin(
            f'Container.Update({_u(action="fuentes_search_all", texto=texto, sec=seccion, fid=fid)}'
            ',replace)')

def _relevancia(clave, nombre, sinopsis=''):
    """10 si el nombre empieza por `clave`, 5 si la contiene, 1 si la sinopsis tiene una palabra
    que empieza por ella, 0 si nada. `clave` viene ya pasada por `ui_utils.norm`.

    La sinopsis va con palabra entera por delante y desde cuatro letras: con «contiene» a secas,
    buscar «sol» traía cada película con «solo» o «soldado» en el argumento y llenaba el tope de
    `MAX_BUSQUEDA` con ruido.
    """
    n = ui_utils.norm(str(nombre or ''))
    if clave in n:
        return 10 if n.startswith(clave) else 5
    if len(clave) >= 4 and sinopsis and re.search(
            r'(?<!\w)' + re.escape(clave), ui_utils.norm(str(sinopsis))):
        return 1
    return 0


def buscar_todo(params_texto='', seccion='', fid=''):
    """Busca un canal, una película o una serie en **todos** los servidores.

    Y aquí está lo que hay que saber antes de usarla: **Xtream no tiene API de búsqueda**. No hay
    `action=search`. La única forma sería traer los canales y filtrar en local.

    Por eso **no** se bajan las 18 000 entradas al buscar: se recorre **lo que ya está en
    caché**, que es lo que se ha abierto alguna vez o lo que ha bajado `indexar()`. Y si no hay
    nada, se dice y se ofrece indexar, que es lo que llena la caché entera. Sin decir por qué no hay
    resultados, el botón parecería roto.

    El filtro es "el texto está en el nombre", sin tildes ni mayúsculas (`ui_utils.norm`), que
    es lo que espera quien busca "telediario" y quiere encontrar "Telediario". Los espacios sí
    cuentan: "la1" no encuentra "La 1".

    Con muchos resultados se cortan. No hay un tope a saco: hay un tope, `MAX_BUSQUEDA`,
    y se **avisa** de que se ha cortado, porque un buscador que miente sobre lo que ha encontrado
    es peor que uno que no encuentra.
    """
    _contenido()
    # Con `fid`, «Buscar en este servidor»: lo mismo, solo en esa fuente.
    xtreams = [f for f in _fuentes_xtream() if not fid or f['id'] == fid]
    m3us = [f for f in _fuentes_m3u() if not fid or f['id'] == fid]
    solo = (xtreams + m3us)[0].get('nombre') if fid and xtreams + m3us else ''
    texto = params_texto or ui_utils.get_text(
        f'Buscar en {solo}' if solo else 'Buscar en todos tus servidores')
    # Si se cancela la entrada de texto se llama a _fin() (endOfDirectory) para que Kodi no quede esperando.
    if not texto:
        _fin()
        return
    clave = ui_utils.norm(texto)
    if not clave:
        _fin()
        return

    import fuentes_xtream

    # 1. Búsqueda en las categorías ya guardadas en la caché, sin peticiones de red
    categorias_encontradas = []
    for f in xtreams:
        for sec in ('live', 'vod', 'series'):
            for c in fuentes_xtream.categorias_cacheadas(f, sec):
                if not isinstance(c, dict):
                    continue
                nombre_c = str(c.get('n') or c.get('nombre') or '')
                if clave in ui_utils.norm(nombre_c):
                    categorias_encontradas.append((f, c, sec))

    # 2. Canales, películas y series de lo cacheado
    encontrados = []
    for f in xtreams:
        for sec in ('live', 'vod', 'series'):
            for fila in _filas_de(f['id'], sec):
                prio = _relevancia(clave, fila.get('nombre'), fila.get('plot'))
                if prio:
                    encontrados.append((prio, f, fila, sec))

    # 3. Listas M3U (se buscan siempre enteras). Primero las que ya están guardadas, y el
    # progreso solo si hay que bajar alguna: sin él, una lista caducada dejaba la pantalla
    # quieta hasta 20 s por lista sin decir nada.
    caidas = []
    leidas = []

    def _lee(f, **kw):
        """`True` si se ha leído (o no había copia y se pide con `red=False`)."""
        try:
            filas_m3u = _leer_m3u(f, **kw)
        except Exception as e:
            _log(f"buscar: no se ha podido leer la lista {f.get('nombre') or f['id']}: "
                 f"{fuentes_xtream._sin_credenciales(e)}", xbmc.LOGWARNING)
            caidas.append(f.get('nombre') or 'Lista M3U')
            return True
        if filas_m3u is None:
            return False
        leidas.append((f, filas_m3u))
        return True

    por_bajar = [f for f in m3us if not _lee(f, red=False)]
    if por_bajar:
        dp = _progreso('Leyendo tus listas M3U')
        try:
            for f in por_bajar:
                if dp is not None:
                    if dp.iscanceled():
                        caidas.append(f.get('nombre') or 'Lista M3U')
                        continue
                    dp.update(0, str(f.get('nombre') or 'Lista M3U'))
                if not _lee(f, dp=dp):
                    leidas.append((f, []))
        finally:
            _cerrar_progreso(dp)
    for f, filas_m3u in leidas:
        for fila_m3u in filas_m3u:
            nombre = str(fila_m3u.get('name') or fila_m3u.get('nombre') or '')
            prio = _relevancia(clave, nombre)
            if prio:
                fila = dict(fila_m3u, nombre=nombre)
                fila.setdefault('sid', _sid_de(fila_m3u))
                encontrados.append((prio, f, fila, 'm3u'))

    # Ordenar por relevancia
    encontrados.sort(key=lambda t: t[0], reverse=True)
    items_canales = [(f, fila, sec) for _prio, f, fila, sec in encontrados]

    # Deduplicar preservando el orden de relevancia
    vistos = set()
    unicos = []
    for f, fila, sec in items_canales:
        sid = str(fila.get('sid') or fila.get('id') or '')
        clave_item = (f['id'], sid, sec)
        if clave_item in vistos:
            continue
        vistos.add(clave_item)
        unicos.append((f, fila, sec))
    items_canales = unicos

    def _dice_las_caidas():
        """La última fila: qué listas no se han podido mirar. Pulsarla busca otra vez."""
        if caidas:
            ui_utils.add_item(
                action='fuentes_search_all', sec=seccion, texto=texto, fid=fid, folder=True,
                title=f"No se ha podido leer: {', '.join(caidas)}",
                thumbnail=_icon('xtream_srv_caido.png'),
                plot='Estas listas M3U no se han podido descargar, así que no se ha buscado en '
                     'ellas. Pulsa para buscar otra vez.')

    if not items_canales and not categorias_encontradas:
        # Vuelve a la sección desde la que se buscó; desde la raíz, a la TV.
        # `seccion` y no `sec`: los `for sec in` de arriba la pisarían.
        volver = (seccion or '').strip() or 'live'
        ui_utils.add_item(
            action='fuentes_cats', sec=volver, fid=fid if xtreams else '', folder=True,
            title='[B]No hay nada con "{0}"[/B]'.format(texto),
            thumbnail=_icon('busqueda.png'),
            plot='Se busca en las listas M3U enteras y, de tus servidores Xtream, en lo que '
                 'ya se ha bajado: las categorías que hayas abierto o indexado. Pulsa para '
                 'ver las categorías.')
        if xtreams:
            solo_nombre = (xtreams[0].get('nombre') or 'este servidor') if fid and len(xtreams) == 1 else 'mis servidores'
            ui_utils.add_item(
                action='fuentes_indexar', texto=texto, sec=seccion, fid=fid, folder=False,
                title=f'Indexar {solo_nombre} para buscar en todo',
                thumbnail=_icon('xtream_indexar.png'),
                plot='Baja enteras las categorías de tus servidores Xtream para que el buscador '
                     'las encuentre. Con un servidor grande son unos minutos y unos megas de '
                     'disco; se puede cancelar y lo bajado se queda. Al terminar se repite esta '
                     'búsqueda.')
        _dice_las_caidas()
        _fin()
        return

    # Categorías encontradas al inicio (hasta 20)
    for f, c, sec in categorias_encontradas[:20]:
        nombre_c = c.get('n') or c.get('nombre') or 'Categoría'
        es_serie = sec == 'series'
        accion_cat = 'fuentes_series' if es_serie else 'fuentes_list'
        srv_rotulo = f"  [COLOR gray]({f.get('nombre') or 'Servidor'})[/COLOR]" if len(xtreams) > 1 else ''
        ui_utils.add_item(
            action=accion_cat, fid=f['id'], cat=c['id'], sec=sec, folder=True,
            title=f'[B][Categoría] {nombre_c}[/B]{srv_rotulo}',
            thumbnail=_icon('cat_series.png' if es_serie else 'fuentes_categorias.png'),
            plot=f"Categoría en {f.get('nombre') or 'Servidor'}\nPulsa para ver los contenidos de esta categoría.")

    cortado = len(items_canales) > MAX_BUSQUEDA
    if cortado:
        items_canales = items_canales[:MAX_BUSQUEDA]

    for f, fila, sec in items_canales:
        es_serie = sec == 'series'
        sid = fila.get('sid') or fila.get('id') or ''
        de_serie = {'serie': sid} if es_serie else {}
        que_es = {'vod': 'Película', 'series': 'Serie'}.get(sec, 'Canal')
        plot_fila = fila.get('plot') or fila.get('sinopsis') or ''
        plot_desc = f"{que_es}\nDe: {f['nombre']}" + (f"\n\n{plot_fila}" if plot_fila else "")
        ui_utils.add_item(
            action='fuentes_seasons' if es_serie else 'fuentes_play',
            fid=f['id'], sid=sid, sec=sec, folder=es_serie,
            ext=fila.get('ext') or '',
            title=fila.get('nombre') or sid,
            thumbnail=fila.get('logo') or _icon('directo.png' if not es_serie
                                               else 'cat_series.png'),
            plot=plot_desc,
            **de_serie)

    if cortado:
        # Con el texto y la sección, para concretar sin volver a escribirlo todo.
        ui_utils.add_item(
            action='fuentes_search_all', sec=seccion, fid=fid, folder=True,
            texto=texto,
            title='[COLOR gray]… y más[/COLOR]',
            thumbnail=_icon('busqueda.png'),
            plot='Demasiados resultados (más de {0}). Concreta el término de búsqueda.'.format(
                MAX_BUSQUEDA))
    _dice_las_caidas()
    _fin()


def sin_facetas(seccion='live'):
    """Que no hay facetas, y que sí hay algo: las categorías del servidor.

    Xtream **no da país ni idioma**. `get_live_categories` devuelve `category_id` y
    `category_name`, y nada más. El proyecto tiene facetas (`iptv_lists._facet_icon`,
    `iptv_parse.ENGINE_FACETS`), pero son de la sección de motor, cuyas fuentes sí las traen.

    Un botón de filtro que no filtra es peor que no tenerlo, así que en vez de fingir se explica
    qué hay y se ofrece ir a las categorías, que es el equivalente real.
    """
    _contenido()
    _log('facetas: Xtream no las da', xbmc.LOGINFO)
    ui_utils.add_item(
        action='fuentes_cats', sec=seccion, folder=True,
        title='Los servidores Xtream no dan filtros por país ni idioma',
        thumbnail=_icon('fuentes_categorias.png'),
        plot='Tus servidores mandan sus canales agrupados en categorías, y con esas se '
             'entra. Los filtros por país e idioma están en la sección "Canales", que usa '
             'otras fuentes con esos datos dentro.')
    _fin()


# --- favoritos, mas usados e historial --------------------------------------

def _servidores_si_hay_varios():
    """`{fid: nombre}` de las fuentes si hay más de una, o `{}` si hay una sola.

    Si hay más de un servidor, indica de cuál procede cada elemento en el plot
    para distinguir canales con el mismo nombre entre paneles.
    """
    import fuentes_store

    nombres = {f['id']: f.get('nombre') or f.get('servidor') or ''
               for f in fuentes_store.fuentes()}
    return nombres if len(nombres) > 1 else {}


def _de_que_servidor(servidores, fid):
    servidor = servidores.get(fid)
    return '[COLOR gray]De: {0}[/COLOR]'.format(servidor) if servidor else ''


def favoritos():
    """Los favoritos de la sección.

    Cada fila lleva `fid`, `sid` y `sec`, y **nada más**. El favorito se guarda sin URL: la URL
    de un canal lleva el usuario y la clave dentro del camino, y un fichero de favoritos es
    justo el sitio donde eso no debe estar escrito aunque el addon no lo llegue a mostrar.
    """
    import fuentes_store

    _contenido()
    lista = fuentes_store.favoritos()
    if not lista:
        ui_utils.add_item(
            action='fuentes_cats', sec='live', folder=True,
            title='[B]Todavía no hay favoritos[/B]', thumbnail=_icon('xtream_fav_vacio.png'),
            # Los favoritos de esta sección se guardan en fuentes_favoritos.json y se muestran aquí.
            plot='En la lista de canales, el menú contextual de cada uno tiene "Añadir a '
                 'favoritos". Lo que añadas sale aquí.')
        _fin()
        return

    servidores = _servidores_si_hay_varios()
    for f in lista:
        titulo = f['nombre'] or ('Canal {0}'.format(f['sid']))
        ui_utils.add_item(
            action='fuentes_play', fid=f['fid'], sid=f['sid'], sec=f['seccion'],
            ext=f['ext'], title=titulo, plot=_de_que_servidor(servidores, f['fid']),
            thumbnail=f['logo'] or _icon('directo.png'), folder=False,
            # refrescar=1 para actualizar la pantalla tras quitar un favorito desde aquí.
            context=(('Quitar de favoritos',
                      'RunPlugin({0})'.format(_u(action='fuentes_fav_toggle', fid=f['fid'],
                                                sid=f['sid'], sec=f['seccion'], quitar='1',
                                                refrescar='1'))),))
    _fin()


def alternar_favorito(params):
    """Añade o quita un favorito. Es la acción de `RunPlugin` del menú contextual.

    Va con `fid`, `sid` y `sec` a pelo, **nunca con la URL**: la orden acaba en el historial de
    Kodi y en los cinco `RunPlugin` de `default.py`, y una URL de canal lleva la clave dentro.

    Es una acción de script, así que **no cierra el directorio**: el router ya lo cerró antes de
    llamarla. Con `quitar=1` quita, y si no lo quita: alternar es lo que espera un botón que se
    llama "favorito", y un parámetro explícito es para cuando toca quitar sin alternar.
    """
    import fuentes_store

    fid = (params.get('fid') or '').strip()
    sid = (params.get('sid') or '').strip()
    seccion = (params.get('sec') or 'live').strip() or 'live'
    quitar = str(params.get('quitar') or '').strip() in ('1', 'si', 'true')
    refrescar = str(params.get('refrescar') or '').strip() in ('1', 'si', 'true')

    if not (fid and sid):
        _log('alternar_favorito sin fid o sin sid', xbmc.LOGWARNING)
        return
    # Quitar un favorito debe funcionar siempre, incluso si el servidor ya fue eliminado.
    if not quitar and not _fuente(fid):
        _log('alternar_favorito: la fuente ya no esta', xbmc.LOGWARNING)
        return

    if quitar or fuentes_store.es_favorito(fid, sid, seccion):
        if not fuentes_store.favorito_quitar(fid, sid, seccion):
            xbmcgui.Dialog().notification(
                _NOMBRE, 'No se ha podido quitar de favoritos. Prueba otra vez.',
                xbmcgui.NOTIFICATION_WARNING)
            return
        # Desde Favoritos (`refrescar=1`) se refresca para que desaparezca la fila quitada. Desde
        # la lista de canales no, porque refrescar ahí pierde la posición en cada favorito quitado.
        if refrescar:
            xbmc.executebuiltin('Container.Refresh')
        else:
            xbmcgui.Dialog().notification(_NOMBRE, 'Quitado de favoritos.')
        return
    # El nombre, el logo y la extension vienen en la orden (`_contexto_canal` los manda). Sin ellos
    # el favorito se guardaba sin nombre y la pantalla caia en "Canal 1234" para siempre. No
    # viene la URL, que es lo que no puede viajar en un `RunPlugin`.
    if fuentes_store.favorito_poner(fid, sid, seccion,
                                    nombre=params.get('nombre') or '',
                                    logo=params.get('logo') or '',
                                    ext=params.get('ext') or ''):
        xbmcgui.Dialog().notification(_NOMBRE, 'Añadido a favoritos.')
    else:
        xbmcgui.Dialog().notification(
            _NOMBRE, 'No se ha podido añadir a favoritos. Prueba otra vez.',
            xbmcgui.NOTIFICATION_WARNING)


# --- agrupar copias del mismo canal -----------------------------------
#
# Un panel Xtream da el mismo canal en varias calidades y repuestos, «(FHD) M+ LALIGA»,
# «(HD) M+ LALIGA», y a veces «(FHD REPUESTO)», cada uno con su `stream_id`. Para el contador
# de uso son canales distintos, así que ver diez veces «M+ LALIGA» alternando calidad no da
# diez en ninguna fila: da cinco y cinco. Y como esta pantalla enseña «lo que más pongo», eso es
# justo lo que no puede pasar. Para juntarlas hace falta una clave que ignore lo que no
# distingue un canal de una copia suya.

#: La etiqueta de color de Kodi con su contenido. `_canal()` pone delante del nombre el
#: número de variante así: `[COLOR gray]3[/COLOR] ES: (FHD) M+ LALIGA`. Se quita entera, la
#: etiqueta y el `3`, y no solo la etiqueta: quitando la etiqueta a secas queda un `3` suelto
#: delante, y entonces dos copias del mismo canal no se juntan.
#:
#: El interior es `.*?` *vago* a propósito: la etiqueta puede encerrar algo con corchetes
#: (`[COLOR gray]3 ES: [ES][/COLOR] …`) y con `[^\[]*` el prefijo no casaba, dejando el `3`
#: metido en la clave. Con lo vago se come hasta el primer `[/COLOR]`, que es su cierre.
_PREFIJO_COLOR = re.compile(
    r'^\s*\[COLOR[^\]]*\].*?\[/COLOR\]\s*', re.IGNORECASE | re.DOTALL)

#: Las etiquetas de estilo que quedan por dentro del nombre (`[B]`, `[I]`, `[COLOR …]`),
#: de apertura y de cierre. Se quitan sin su contenido: no numeran nada, solo dan formato.
#: Las dos formas de `COLOR` valen en Kodi (`[COLOR gray]` y `[COLOR=gray]`), así que el
#: patrón acepta las dos; la barra es opcional (`/`), que si se pone obligatoria solo
#: quita los cierres y `[B]La 1[/B]` se quedaba en `[B]La 1` —así estuvo una tanda y por eso
#: la barra lleva este comentario.
_COLOR = re.compile(r'\[/?(?:COLOR(?:=[^\]]*)?|[BI])(?=[\s\]])[^\]]*\]', re.IGNORECASE)

#: La calidad y las copias entre paréntesis: `(FHD)`, `(HD)`, `(4K)`, `(REPUESTO2)`… Es la
#: forma que usan los paneles de verdad. `limpiar_titulo()` no sirve para esto: a propósito
#: solo quita etiquetas entre corchetes y deja la calidad de fuera tal cual.
_PARENTESIS = re.compile(r'\(([^()]*)\)')

#: Palabras que, solas dentro de un paréntesis, dicen «esto es una copia del mismo canal».
_CALIDAD = frozenset({
    '4K', 'UHD', '2160P', '1440P', '1080P', '720P', '576P', '480P', '360P', 'SD', 'FHD',
    'FULLHD', 'FULL', 'HD', 'HQ', 'HDTV', 'SDTV', 'HDR', 'HDR10', 'DV', 'DOLBY', 'ATMOS',
    'HEVC', 'H265', 'H264', 'X265', 'X264', 'AAC', 'AC3', 'EAC3', 'DTS', 'MPEG2', 'MPEG4',
    'VIP', 'PREMIUM', 'BACKUP', 'ALT', 'ALTERNO',
})

#: Y las copias con número: `REPUESTO`, `REPUESTO2`, `REP1`.
_COPIA = re.compile(r'^REP(?:UESTO)?\d*$')

#: Los códigos de país o idioma general con los que empiezan algunos paneles («`ES: `»).
#: Lista cerrada a propósito: quitar cualquier cosa de dos letras seguida de dos puntos se
#: llevaría por delante el principio de un título de verdad («`Up: Una aventura de altura`»).
#: Solo prefijos de país o idioma general: SUB: y DUB: corresponden a versiones
#: subtituladas o dobladas y no deben fusionarse como el mismo canal.
_PAISES = frozenset({
    'ES', 'ESP', 'ESPANA', 'EN', 'ING', 'ENG', 'UK', 'US', 'USA', 'FR', 'FRA', 'ITA', 'DE',
    'DEU', 'PT', 'POR', 'NL', 'RU', 'PL', 'AR', 'MX', 'CO', 'CL', 'PE', 'LAT', 'LATAM',
})


def _sin_color(texto):
    """El nombre sin el marcado de Kodi. Es lo que se enseña: el `3` del `[COLOR gray]3[/COLOR]`
    es el número de variante de la lista, y con el contador delante salía «10x 3 ES: …»."""
    return _COLOR.sub('', _PREFIJO_COLOR.sub('', str(texto or ''))).strip()


def _plano(texto):
    """Sin acentos, en mayúsculas: la forma en la que se comparan dos nombres."""
    sin_tildes = unicodedata.normalize('NFKD', str(texto or ''))
    return ''.join(c for c in sin_tildes if not unicodedata.combining(c)).upper()


def _sin_calidad(texto):
    """Los paréntesis de calidad y de copia, fuera. **Solo esos.**

    Se quita un paréntesis cuando **todas** sus palabras son de calidad o de copia: `(FHD)` y
    `(HD REPUESTO2)` se van; `(2020)` y `(Director's Cut)` se quedan. Es la diferencia entre
    juntar dos copias del mismo canal y juntar dos títulos distintos.
    """
    def _quiza(m):
        palabras = [p for p in re.split(r'[^0-9A-Za-z]+', m.group(1)) if p]
        if not palabras:
            return ''
        for palabra in palabras:
            plano = _plano(palabra)
            if plano not in _CALIDAD and not _COPIA.match(plano):
                return m.group(0)
        return ''
    return _PARENTESIS.sub(_quiza, texto)


def _sin_pais(texto):
    """El prefijo de país o idioma, fuera: «`ES: `». Si no es de la lista, se queda."""
    m = re.match(r'^\s*([^\s:]{1,9})\s*:\s*', texto)
    if m and _plano(m.group(1)) in _PAISES:
        return texto[m.end():]
    return texto


def _clave_canal(nombre):
    """La clave con la que «Lo más usado» junta las copias del mismo canal.

    De `[COLOR gray]3[/COLOR] ES: (FHD) M+ LALIGA` sale `M+ LALIGA`, y de
    `[COLOR gray]1[/COLOR] ES: (HD) M+ LALIGA` sale lo mismo: las dos filas son el mismo canal.
    De `M+ LALIGA TV 2` y `M+ LALIGA TV BAR` salen claves distintas, que es lo que tiene que
    pasar: son dos canales que solo se parecen en el nombre.

    Conservadora: solo quita el marcado de Kodi, el prefijo de país o idioma, la
    calidad entre paréntesis, los acentos y las mayúsculas. Todo lo demás se conserva,
    incluidos marcadores de capítulo (ej. S01E03). Ante la duda no se agrupa para no mezclar
    canales distintos (ej. DISNEY CHANNEL y DISNEY CHANNEL HD).
    """
    texto = _sin_calidad(_sin_pais(_sin_color(nombre)))
    return ' '.join(_plano(texto).split())


def mas_usados(seccion=''):
    """Lo más reproducido, de mayor a menor frecuencia. Solo elementos recurrentes.

    Utiliza el contador de reproducciones de fuentes_store. Requiere más de una
    reproducción para diferenciar esta vista del Historial cronológico reciente.

    El filtro se aplica sobre el grupo agrupado para contemplar reproducciones
    del mismo contenido en distintas calidades.
    """
    import fuentes_store

    _contenido()
    # Las filas de un servidor que ya no existe no se pintan: al pulsarlas solo dicen «Ese
    # servidor ya no está», y esta pantalla no tiene menú para quitarlas. Se esconden y no se
    # borran, porque si se reimporta esa fuente con su `id` vuelven a valer.
    vivas = {f['id'] for f in fuentes_store.fuentes()}
    todas = fuentes_store.uso_top(seccion or None, fuentes_store.USO_MAX)
    de_vivos = [fila for fila in todas if fuentes_store.partir_uso(fila[1])[0] in vivas]

    # El índice se lee una sola vez, y por fuente Y sección: la clave es `fid|sec`. Con solo
    # el `fid`, la primera sección que se pintaba dejaba su índice puesto y la fila de otra
    # sección salía con el nombre y el logo de aquella (medido: una película de `vod` y un canal
    # de `live` con el mismo `sid` enseñaban el mismo nombre).
    indices = {}

    def _indice(fid, sec):
        clave = '{0}|{1}'.format(fid, sec)
        if clave not in indices:
            indices[clave] = _indice_de(fid, sec)
        return indices[clave]

    # Las copias del mismo canal se agrupan en el mismo servidor y sección:
    # visto en varias calidades, se contabiliza de forma unificada.
    grupos = {}
    for cuenta, clave, cuando, guardado in de_vivos:
        fid, sid, sec = fuentes_store.partir_uso(clave)
        if not fid:
            continue
        # El nombre guardado tiene prioridad sobre el de caché: es el que se vio al reproducir.
        # es el unico que existe para un capitulo: en la cache de series estan las series, no los
        # capitulos.
        nombre = guardado or _nombre_de(_indice(fid, sec), sid)
        # Y la clave, si sale vacía, es el `sid`. Dos entradas sin nombre no se juntan: una
        # clave vacía fundiría canales que no tienen nada que ver.
        clave_grupo = _clave_canal(nombre) or 'sid:{0}'.format(sid)
        grupo = grupos.setdefault((fid, sec, clave_grupo),
                                  {'total': 0, 'mejor': None})
        grupo['total'] += cuenta
        anterior = grupo['mejor']
        if (anterior is None or cuenta > anterior[0]
                or (cuenta == anterior[0] and cuando > anterior[1])):
            # La copia que se reproduce es la más usada; a igualdad, la vista más recientemente.
            grupo['mejor'] = (cuenta, cuando, clave, sid, nombre)

    # El filtro, ya sobre grupos. «Se repite» es el grupo con total >= 2: dos vistas del mismo
    # canal en calidades distintas son dos vistas, y eso es exactamente lo que hay que enseñar.
    # Y el tope de cien es de grupos, no de entradas: recortando entradas antes de agrupar, el
    # `Nx` de un grupo podía quedarse corto y el número de pantalla no era la cuenta de verdad.
    #
    # Se ordena antes de limitar a 100 para priorizar los grupos con mayor número total de reproducciones.
    repetidos = [g for g in grupos.values() if g['total'] > 1]
    repetidos.sort(key=lambda g: (-g['total'], -g['mejor'][1]))
    con_repetidos = repetidos[:100]
    if not con_repetidos:
        _sin_historial(seccion or 'live', bool(todas),
                       'En cuanto reproduzcas algo, lo más visto sale aquí.',
                       nada_repetido=bool(de_vivos))
        return

    servidores = _servidores_si_hay_varios()
    for grupo in con_repetidos:
        _cuenta, _cuando, clave, sid, nombre = grupo['mejor']
        fid, _sid, sec = fuentes_store.partir_uso(clave)
        # `nombre` aparte del rótulo: `reproducir()` guarda lo que le llega, y con el rótulo
        # cada reproducción desde aquí añadía otro «3x» al nombre («4x 3x La 1»). Y con el
        # marcado de color fuera: el `3` del `[COLOR gray]3[/COLOR]` es el número de variante
        # de la lista, y con el contador delante salía «10x 3 ES: …», dos números seguidos que
        # no dicen nada.
        visible = _sin_color(nombre) or nombre
        ui_utils.add_item(
            action='fuentes_play', fid=fid, sid=sid, sec=sec, folder=False,
            title='[COLOR gray]{0}x[/COLOR] {1}'.format(grupo['total'], visible),
            nombre=visible,
            plot=_de_que_servidor(servidores, fid),
            thumbnail=_logo_de(_indice(fid, sec), sid) or _icon('directo.png'))
    # Si hay más elementos repetidos, una fila final indica cuántos quedan fuera
    # y permite enlazar con el historial completo.
    if len(repetidos) > len(con_repetidos):
        ui_utils.add_item(
            action='fuentes_hist', folder=True,
            title='[COLOR gray]… y {0} más[/COLOR]'.format(
                len(repetidos) - len(con_repetidos)),
            thumbnail=_icon('xtream_fin_cat.png'),
            plot='Esta pantalla enseña 100, y hay {0} más que también se repiten. Si dos '
                 'canales están empatados, va primero el que viste más reciente.\n\n'
                 'Pulsa para el Historial, que enseña lo último de todo (no el resto de esta '
                 'lista).'.format(len(repetidos) - len(con_repetidos)))
    _fin()


def historial():
    """Lo reproducido más recientemente.

    Y aquí está la diferencia con "más usados": este sale por **fecha**, no por número. Lo más
    usado puede ser algo que viste hace meses, que es justo lo que no se busca cuando se abre
    "historial".

    **Y aquí sí sale lo visto una sola vez**, que es la otra mitad de la diferencia: «Lo más
    usado» se queda solo con lo repetido, y el sitio donde buscar «lo último que puse» es
    este, aunque sea la primera vez.
    """
    import fuentes_store

    _contenido()
    # Sin las filas de servidores que ya no existen, igual que en `mas_usados()`.
    vivas = {f['id'] for f in fuentes_store.fuentes()}
    todas = fuentes_store.uso_recientes(fuentes_store.USO_MAX)
    filas = [fila for fila in todas if fuentes_store.partir_uso(fila[1])[0] in vivas][:50]
    if not filas:
        _sin_historial('live', bool(todas),
                       'En cuanto reproduzcas algo, sale aquí lo último que viste.')
        return

    indices = {}

    def _indice(fid, sec):
        """Un indice por fuente **y sección**, construido **una vez** (5.4)."""
        clave = '{0}|{1}'.format(fid, sec)
        if clave not in indices:
            indices[clave] = _indice_de(fid, sec)
        return indices[clave]

    import time
    ahora = int(time.time())
    servidores = _servidores_si_hay_varios()
    for cuando, clave, guardado in filas:
        fid, sid, sec = fuentes_store.partir_uso(clave)
        if not fid:
            continue
        # El nombre guardado primero: es el que se vio al reproducir, y el unico que hay para
        # un capitulo.
        nombre = guardado or _nombre_de(_indice(fid, sec), sid)
        titulo = '{0}  [COLOR gray]({1})[/COLOR]'.format(nombre, _hace(ahora - cuando))
        # Igual que en `mas_usados()`: el rótulo lleva «(hace 5 min)» y no puede acabar guardado.
        ui_utils.add_item(
            action='fuentes_play', fid=fid, sid=sid, sec=sec, folder=False, title=titulo,
            nombre=nombre, plot=_de_que_servidor(servidores, fid),
            thumbnail=_logo_de(_indice(fid, sec), sid) or _icon('directo.png'))
    _fin()


def _sin_historial(seccion, de_borrados, plot, nada_repetido=False):
    """La fila de «no hay nada» del historial y de «Lo más usado».

    Son **tres** casos y cada uno dice una verdad distinta:

    - `nada_repetido`: hay reproducciones, pero todas de una sola vez, así que «Lo más usado» no
      tiene qué enseñar. Sin este caso la pantalla diría «Todavía no hay historial», que es
      mentira: al Historial sí que se ha ido.
    - `de_borrados`: el historial no está vacío, pero todo lo que hay es de servidores borrados,
      que no se pintan. «Todavía no hay historial» sería mentira igual.
    - vacío: todavía no se ha reproducido nada.

    **El `plot` que se pasa solo manda en el tercer caso.** En los otros dos hay algo más
    concreto que decir (por qué no repites nada, o qué pasa con los servidores borrados).
    """
    if nada_repetido:
        titulo = '[B]Todavía no repites nada[/B]'
        plot = ('Aquí aparecen los contenidos reproducidos de forma habitual. '
                'En cuanto reproduzcas un canal o vídeo varias veces, aparecerá aquí.\n\n'
                'Para consultar las reproducciones recientes, entra en Historial.')
    elif de_borrados:
        titulo = '[B]Solo hay historial de servidores borrados[/B]'
        plot = ('Los registros corresponden a servidores eliminados. Si vuelves a importar '
                'la fuente, se recuperará su historial.')
    else:
        titulo = '[B]Todavía no hay historial[/B]'
    ui_utils.add_item(action='fuentes_cats', sec=seccion, folder=True, title=titulo,
                      thumbnail=_icon('xtream_hist_vacio.png'), plot=plot)
    _fin()


def _hace(segundos):
    """Hace cuánto, en palabras. A partir de un minuto, porque "hace 45 s" no dice nada."""
    if segundos < 60:
        return 'ahora'
    if segundos < 3600:
        return 'hace {0} min'.format(segundos // 60)
    if segundos < 86400:
        return 'hace {0} h'.format(segundos // 3600)
    if segundos < 172800:
        return 'ayer'
    if segundos < 2592000:
        return 'hace {0} dias'.format(segundos // 86400)
    return 'hace {0} meses'.format(segundos // 2592000)


def _filas_de(fid, sec):
    """Las filas cacheadas de una fuente y sección, o `[]`.

    Se leen **de la caché y no del servidor**: "favoritos" y "más usados" son listas de lo que ya
    se ha visto, y para mostrarlas no hace falta volver a preguntar. Si no está en caché, se
    dice que aún no se ha leído esa sección, en vez de disparar una petición de 18 000 canales
    por abrir una lista de favoritos.
    """
    return _cache_de_visor(fid, sec) or []


def _indice_de(fid, sec):
    """Genera `{sid: (nombre, logo)}` de lo cacheado, leído una vez para toda la vista.

    Construye el índice de una sola vez para resolver rápidamente nombres y logotipos
    al listar elementos como «más usados» o historial.
    """
    indice = {}
    for fila in _filas_de(fid, sec):
        sid = fila.get('sid')
        if sid is None:
            continue
        indice[str(sid)] = (fila.get('nombre') or '', fila.get('logo') or '')
    return indice


def _nombre_de(indice, sid):
    """El nombre de un canal de un índice, o su id, que es feo pero no miente."""
    return indice.get(str(sid), ('', ''))[0] or str(sid)


def _logo_de(indice, sid):
    return indice.get(str(sid), ('', ''))[1]


def _cache_de_visor(fid, sec):
    """Lo que hay cacheado de una sección, releyendo el fichero de caché.

    Va a los ficheros y no al almacén porque `fuentes_store` no tiene un "dame lo cacheado de
    esta clave": el visor lee lo que hay, y si no hay, no inventa.
    """
    import json
    import os
    import fuentes_store
    carpeta = os.path.join(fuentes_store.perfil(), 'fuentes_cache', fid)
    if not os.path.isdir(carpeta):
        return []
    prefijo = 'list_{0}_'.format(sec if sec in ('live', 'vod', 'series') else 'live')
    mejor = []
    # La misma fila puede estar en dos ficheros: la página de 100 que se abrió a mano y la
    # categoría entera de «Indexar» (o la de antes de editar el servidor, que lleva otra huella).
    # Sin esto cada canal salía dos veces en la búsqueda. Las series van por `id`, no por `sid`.
    vistos = set()
    for nombre in os.listdir(carpeta):
        if not nombre.startswith(prefijo) or not nombre.endswith('.json'):
            continue
        try:
            with open(os.path.join(carpeta, nombre), 'r', encoding='utf-8') as f:
                crudo = json.load(f)
        except (OSError, ValueError):
            continue
        datos = crudo.get('datos') if isinstance(crudo, dict) else crudo
        # Las dos formas. La cache de un listado es `{'v': 2, 'filas': [...], 'mas': bool}`
        # desde que se dejo de cachear la respuesta cruda del panel (que lleva la contrasena
        # dentro). El lector tiene que aceptar las dos: si solo aceptara la lista, devolveria
        # 0 filas para todo y el "Mas usado", el "Historial" y la busqueda se quedarian
        # vacios sin decir por que.
        if isinstance(datos, dict):
            filas = datos.get('filas')
        else:
            filas = datos
        if not isinstance(filas, list):
            continue
        for d in filas:
            if not isinstance(d, dict):
                continue
            ident = d.get('sid') or d.get('id')
            if ident is not None:
                if str(ident) in vistos:
                    continue
                vistos.add(str(ident))
            mejor.append(d)
    return mejor


def _extension_de_fila(fid, seccion, sid):
    """La extensión de una fila de la caché, o cadena vacía si no está.

    Las filas cacheadas ya vienen normalizadas por `fuentes_xtream._fila_de()`, que
    guarda `container_extension` como `ext`. Si la fila no está en la caché
    (servidor sin cargar, caché caducada) quien llama sigue su camino: no es motivo
    para no reproducir.
    """
    try:
        for x in _filas_de(fid, seccion):
            if str(x.get('sid')) == str(sid):
                return str(x.get('ext') or '')
    except OSError as e:
        _log(f'sin extensión de la caché: {e}', xbmc.LOGWARNING)
    return ''


# --- reproducir ------------------------------------------------------------

def _reproducir_m3u(f, sid, titulo):
    """Reproduce un canal de una lista M3U.

    La URL se toma directamente de la fila tal como vino en la lista M3U.
    Se busca por `sid` en la caché local donde se guarda la fila completa.
    reproducir desde la caché era imposible por construcción: no hay nada que quite
    del `except` de `reproducir()`, es que el dato no existía.

    El `ua` es el de la fila si la lista lo trae, y el del ajuste si no. El `ref` se
    envía sin cabeceras falsificadas.

    Tampoco cierra el directorio: `fuentes_play` es acción de script y el router ya
    lo cerró.
    """
    import fuentes_xtream
    import iptv_lists
    import fuentes_store

    try:
        canales = _leer_m3u(f)
    except Exception as e:
        _aviso('No se ha podido leer la lista.\n\n{0}'.format(
            fuentes_xtream._sin_credenciales(e)))
        return

    fila = next((x for x in canales if str(x.get('sid')) == str(sid)), None)
    if not fila or not fila.get('url'):
        # «Ya no está» y no «no se puede»: si la lista se ha refrescado y el canal se
        # ha caído, eso es exactamente lo que ha pasado, y el mensaje tiene que
        # decirlo: no es un fallo del addon.
        _aviso('Ese canal ya no está en la lista.')
        return

    iptv_lists.play({'url': fila['url'],
                    'title': titulo or fila.get('name') or '',
                    'ua': fila.get('ua') or fuentes_xtream._user_agent(),
                    'ref': fila.get('ref') or ''}, mode='list')

    # La sección es `m3u`, agrupada con las listas M3U en «Lo más usado».
    fuentes_store.uso_sumar('{0}|{1}|m3u'.format(f['id'], sid), nombre=titulo)


def reproducir(fid, sid, seccion='live', titulo='', ext=''):
    """Reproduce un canal. Aquí, y solo aquí, se monta la URL con las credenciales.

    Va por `iptv_lists.play()`, no por `ui_utils.play_resolved()`, por dos cosas que importan:
    `play()` entiende los enlaces con cabeceras en formato pipe, desenvuelve una URL de radio y
    comprueba el DRM, y es el camino que ya usan todas las listas
    del addon. Lo que **no** se le pasa es una dirección: se le pasan los valores, y la
    dirección se ha montado en la línea de arriba.

    El User-Agent es el de `fuentes_ua` si está puesto, y el del proyecto si no.

    **No cierra el directorio**, y es a propósito: `fuentes_play` está en
    `fuentes_tv._SCRIPT_ACTIONS`, así que el router ya lo cerró antes de llamarla
    (`fuentes_tv.route()`). Cerrarlo otra vez es un `endOfDirectory` sobre un handle
    ya cerrado, que en Kodi avisa por el log y deja la pantalla esperando. Es el mismo
    motivo por el que `fuentes_servidores` no cierra en sus acciones de script.
    """
    import fuentes_xtream
    import iptv_lists
    import fuentes_store

    f = _fuente(fid)
    if not f:
        _aviso('Ese servidor ya no está.')
        return

    # Una lista M3U no es un panel: la URL del canal está en la propia fila.
    if f.get('tipo') == 'm3u':
        _reproducir_m3u(f, sid, titulo)
        return

    # Sin esto, una película .mkv abierta desde el Historial o desde «Lo más usado»
    # sale como .mp4: esas dos pantallas no mandan `ext` y `url_de()` pone mp4 por
    # defecto. Solo películas: los capítulos se piden por serie y no están en la
    # caché de la sección, así que ahí no hay fila que mirar.
    if not ext and seccion == 'vod':
        ext = _extension_de_fila(fid, seccion, sid)

    try:
        url = fuentes_xtream.url_de(f, seccion, sid, extension=ext or None)
    except Exception as e:
        _aviso('No se ha podido preparar eso.\n\n{0}'.format(
            fuentes_xtream._sin_credenciales(e)))
        return

    # `extra` se deja vacio a propósito: `_props()` lo pasa por `json.loads` y espera una
    # lista (`iptv_lists.load_epg()`). Poner ahi un texto no da error, da una lista
    # vacia, y parece que se ha pasado algo cuando no se ha pasado nada.
    iptv_lists.play({'url': url, 'title': titulo, 'ua': fuentes_xtream._user_agent()},
                    mode='list')
    # Se cuenta después de reproducir. La clave es fid|sid|seccion para permitir
    # filtrado por sección en uso_top().
    fuentes_store.uso_sumar('{0}|{1}|{2}'.format(f['id'], sid, seccion), nombre=titulo)