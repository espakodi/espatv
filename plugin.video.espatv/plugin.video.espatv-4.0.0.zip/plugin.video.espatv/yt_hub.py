# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Hub de YouTube para EspaTV."""

import json
import os
import sys
import urllib.parse

try:
    import xbmc
    import xbmcgui
    import xbmcplugin
except ImportError:
    xbmc = None
    xbmcgui = None
    xbmcplugin = None

import yt_innertube
import yt_playlists
import yt_resolver
import yt_storage
import youtube_bridge

try:
    from ui_utils import media_icon
except ImportError:
    def media_icon(name):
        return ""

try:
    import yt_watched_tracker
except ImportError:
    yt_watched_tracker = None


_YT_LIVE_CHANNELS = {
    "Noticias 24h": [
        {"name": "RTVE 24h", "yt_id": "UC7QZIf0dta-XPXsp9Hv4dTw"},
        {"name": "euronews en español", "yt_id": "UCyoGb3SMlTlB8CLGVH4c8Rw"},
        {"name": "France 24 Español", "yt_id": "UCUdOoVWuWmgo1wByzcsyKDQ"},
        {"name": "DW Español", "yt_id": "UCT4Jg8h03dD0iN3Pb5L0PMA"},
        {"name": "TVG - Galicia Noticias", "yt_id": "UCz46p3cffUXUSGUtcnw_Ouw"},
        {"name": "El País", "yt_id": "UCU_vF9kWn_5N_H1lZ_VzY_g"},
    ],
    "Música y Relax": [
        {"name": "Lo-fi Girl", "yt_id": "UCSJ4gkVC6NrvII8umztf0Ow"},
        {"name": "Steezy Beats", "yt_id": "UCwNw0w-CorPkMNy5vRxatZg"},
        {"name": "Chillhop Music", "yt_id": "UCOxqgCwgOqC2lMqC5PYz_Dg"},
    ],
    "Naturaleza y Relax": [
        {"name": "Explore Live Nature Cams", "yt_id": "UC-2KSeUU5SMCX6XLRD-AEvw"},
        {"name": "Africam Wildlife", "yt_id": "UCuoNAKa3P0QR1Lw9QdpmoVg"},
    ],
    "Espacio y Ciencia": [
        {"name": "NASA - Live Stream & ISS", "yt_id": "UCLA_DiR1FfKNvjuUpBHmylQ"},
        {"name": "NASASpaceflight Live", "yt_id": "UCSUu1lih2RifWkKtDOJdsBA"},
    ],
    "Cámaras del Mundo": [
        {"name": "EarthCam Live", "yt_id": "UC6qrG3W8SMK0jior2olka3g"},
        {"name": "earthTV", "yt_id": "UCRuyAVeVd7oUwh0LWmxxBBQ"},
        {"name": "Shibuya Crossing (Tokio)", "yt_id": "UCoQBJMzcwmXrRSHBFAlTsIw"},
    ],
}


def _u(**params):
    filtered = {k: v for k, v in params.items() if v is not None}
    return "plugin://plugin.video.espatv/?" + urllib.parse.urlencode(filtered)


def _watched_set():
    if yt_watched_tracker:
        try:
            return yt_watched_tracker.load()
        except (OSError, ValueError):
            return set()
    return set()


def _video_context_menu(vid, title, channel="", channel_id="", duration="", thumb="", is_watched=False, extra_first=None):
    ctx = []
    if extra_first:
        ctx.extend(extra_first)
    ctx.append((
        "Añadir a Ver más tarde",
        f"RunPlugin({_u(action='yt_watch_later_add', video_id=vid, title=title, channel=channel, channel_id=channel_id, duration=duration)})",
    ))
    fav_icon = thumb or f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg"
    fav_params = json.dumps({"yt_id": vid, "name": title, "ctype": "video", "burl": ""})
    ctx.append((
        "Añadir a Mis Favoritos (EspaTV)",
        f"RunPlugin({_u(action='add_favorite', title=title, fav_url=f'yt_{vid}', icon=fav_icon, platform='youtube', fav_action='felicidad_play', params=fav_params)})",
    ))
    ctx.append(("Solo audio", f"RunPlugin({_u(action='yt_play_audio', video_id=vid, title=title)})"))
    ctx.append(("Vídeos relacionados (Radio)", f"Container.Update({_u(action='yt_related', video_id=vid, title=title)})"))
    if channel_id:
        ctx.append(("Ir al canal", f"Container.Update({_u(action='yt_channel_view', channel_id=channel_id, channel_name=channel)})"))
    ctx.append(("Añadir a cola de reproducción", f"RunPlugin({_u(action='yt_queue_add', video_id=vid, title=title)})"))
    toggle_lbl = "Desmarcar como visto" if is_watched else "Marcar como visto"
    ctx.append((toggle_lbl, f"RunPlugin({_u(action='yt_toggle_watched', yt_id=vid)})"))
    ctx.append((
        "Opciones de reproducción (App / Navegador / yt-dlp)",
        f"Container.Update({_u(action='felicidad_play', yt_id=vid, name=title, ctype='video')})",
    ))
    return ctx


_LIVE_ICONS = {
    "Noticias 24h": "yt_live_news.png",
    "Música y Relax": "yt_live_music.png",
    "Naturaleza y Relax": "yt_live_nature.png",
    "Espacio y Ciencia": "yt_live_space.png",
    "Cámaras del Mundo": "yt_live_webcams.png",
}


def live_menu():
    h = int(sys.argv[1])
    for cat_name, channels in _YT_LIVE_CHANNELS.items():
        icon_file = _LIVE_ICONS.get(cat_name, "yt_hub_live.png")
        icon = media_icon(icon_file) or "DefaultAddonPVRClient.png"
        li = xbmcgui.ListItem(label=f"[B]{cat_name}[/B] [COLOR gray]({len(channels)})[/COLOR]")
        li.setArt({"icon": icon, "thumb": icon, "poster": icon, "banner": icon})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="youtube_live_list", cat=cat_name), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def live_list(cat_name):
    h = int(sys.argv[1])
    channels = _YT_LIVE_CHANNELS.get(cat_name, [])
    if not channels:
        xbmcplugin.endOfDirectory(h)
        return
    for ch in channels:
        name = ch.get("name", "Canal")
        yt_id = ch.get("yt_id", "")
        li = xbmcgui.ListItem(label=f"[B]{name}[/B]")
        li.setArt({"icon": "DefaultAddonPVRClient.png", "thumb": "DefaultAddonPVRClient.png"})
        li.setInfo("video", {"title": name, "plot": f"YouTube Live: {name}\nPulsa para ver en directo."})
        li.setProperty("IsPlayable", "true")
        ctx = []
        if yt_id.startswith("UC"):
            ctx.append(("Ver canal completo", f"Container.Update({_u(action='yt_channel_view', channel_id=yt_id, channel_name=name)})"))
            ctx.append(("Suscribirse al canal", f"RunPlugin({_u(action='yt_sub_add', channel_id=yt_id, name=name)})"))
        if ctx:
            li.addContextMenuItems(ctx)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="play_youtube_live", yt_id=yt_id, title=name), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def play_live(yt_id, title=""):
    live_vid = yt_id
    if yt_id.startswith("UC") and len(yt_id) == 24:
        live_vid = yt_innertube.get_channel_live_video_id(yt_id)
        if not live_vid:
            h = int(sys.argv[1]) if len(sys.argv) > 1 else -1
            if h >= 0:
                xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem())
            xbmcgui.Dialog().notification("EspaTV", f"No hay directo activo para {title or 'este canal'}", xbmcgui.NOTIFICATION_WARNING)
            return
    yt_resolver.play_video(live_vid, title=title, use_resolved_url=True)


def bridge_menu():
    youtube_bridge.show_info_and_toggle()


def hub_menu():
    h = int(sys.argv[1])

    bridge_on = youtube_bridge.is_active()
    bridge_label = "Puente de YouTube para otros addons"
    bridge_plot = (
        "Los addons y skins que abren vídeos de YouTube con el addon de YouTube pasan a "
        "reproducirlos con EspaTV, sin claves ni cuotas de API. Útil porque ese addon da "
        "muchos errores y cortes últimamente.\n\n"
        f"Estado: {youtube_bridge.get_status_label()}."
    )

    entries = [
        ("Buscar en YouTube", "yt_search", media_icon("yt_hub_search.png") or "DefaultAddonsSearch.png", "Busca vídeos, canales y playlists, con sugerencias mientras escribes.", False),
        ("Novedades de suscripciones", "yt_subs_feed", media_icon("yt_hub_feed.png") or "DefaultFolderBack.png", "Los últimos vídeos de tus canales suscritos, del más reciente al más antiguo.", True),
        ("Mis Canales suscritos", "yt_subs_list", media_icon("yt_hub_channels.png") or "DefaultActor.png", "Los canales que sigues, guardados en EspaTV sin cuenta de Google.", True),
        ("Ver más tarde", "yt_watch_later_menu", media_icon("yt_hub_watch_later.png") or "DefaultVideoPlaylists.png", "Vídeos pendientes de ver guardados localmente.", True),
        ((f"Playlists de YouTube ({len(yt_playlists._load_yt_playlists())})" if yt_playlists._load_yt_playlists() else "Playlists de YouTube"), "yt_playlists_menu", media_icon("DefaultVideoPlaylists.png") or "DefaultVideoPlaylists.png", "Gestiona tus playlists de YouTube.\nPega la URL de una playlist y accede a ella desde aquí.\nPuedes pegar desde el mando o desde tu móvil/PC.", True),
        ("Emisiones en directo (24/7)", "youtube_live_menu", media_icon("yt_hub_live.png") or "DefaultAddonPVRClient.png", "Canales de televisión y música en vivo.", True),
        ("Colecciones EspaTV", "yt_collections_menu", media_icon("yt_hub_collections.png") or "DefaultFolder.png", "Cocina Española, Educación, Arte y Verano.", True),
        ("Radio y Música continua", "yt_radio_menu", media_icon("yt_hub_radio.png") or "DefaultMusicSongs.png", "Genera una lista continua de canciones relacionadas con opción de solo audio.", False),
        ("Historial de vídeos vistos", "yt_watched_menu", media_icon("yt_hub_history.png") or "DefaultAddonRepository.png", "Vídeos reproducidos recientemente.", True),
        ("Importar suscripciones (Google Takeout)", "yt_sub_import", media_icon("yt_hub_import.png") or "DefaultAddSource.png", "Importa tus suscripciones desde archivo CSV o JSON.", False),
        (bridge_label, "yt_bridge_menu", media_icon("yt_hub_bridge.png") or "DefaultAddonService.png", bridge_plot, False),
        ("Ajustes de YouTube", "yt_settings_menu", media_icon("yt_hub_settings.png") or "DefaultAddonService.png", "Configura resolución preferida, SponsorBlock, subtítulos y caché.", False),
    ]

    for label, action, icon, plot, is_folder in entries:
        state = ""
        if action == "yt_bridge_menu":
            # Hexadecimal: los nombres green/yellow no existen en todos los skins y salen blancos
            state = " [COLOR FF4ADE80]Activado[/COLOR]" if bridge_on else " [COLOR FFF87171]Desactivado[/COLOR]"
        li = xbmcgui.ListItem(label=f"[B]{label}{state}[/B]")
        li.setArt({"icon": icon, "thumb": icon, "poster": icon, "banner": icon})
        li.setInfo("video", {"title": label, "plot": plot})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action), listitem=li, isFolder=is_folder)

    xbmcplugin.endOfDirectory(h)


def collections_menu():
    h = int(sys.argv[1])
    collections = [
        ("Cocina Española", "cocina_menu", media_icon("yt_col_cocina.png") or "DefaultAddonVideo.png", "Canales y recetas tradicionales de la gastronomía española.", {}),
        ("Educación y Divulgación", "educacion_menu", media_icon("yt_col_educacion.png") or "DefaultAddonProgram.png", "Canales de ciencia, historia, divulgación y tecnología.", {}),
        ("Arte y Museos", "arte_museos_menu", media_icon("yt_col_arte.png") or "DefaultPicture.png", "Canales de museos, arte y visitas virtuales.", {}),
        ("Verano y Nostalgia", "felicidad_menu", media_icon("yt_col_verano.png") or "DefaultVideoPlaylists.png", "Canales y listas de música, recuerdos y descanso.", {}),
        ("Vídeos Virales España", "spanish_section", media_icon("yt_col_virales.png") or "DefaultAddonVideo.png", "Vídeos patrimonio inmaterial del humor y la cultura de internet en España.", {"section": "museo_meme"}),
    ]
    for label, action, icon, plot, params in collections:
        li = xbmcgui.ListItem(label=f"[B]{label}[/B]")
        li.setArt({"icon": icon, "thumb": icon, "poster": icon, "banner": icon})
        li.setInfo("video", {"title": label, "plot": plot})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action=action, **params), listitem=li, isFolder=True)
    xbmcplugin.endOfDirectory(h)


def radio_menu():
    kb = xbmc.Keyboard("", "Introduce artista o canción para iniciar la Radio")
    kb.doModal()
    if not kb.isConfirmed():
        return
    query = kb.getText().strip()
    if not query:
        return
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Buscando temas para la radio...")
    try:
        items, _ = yt_innertube.search(query)
        videos = [it for it in items if it.get("type") == "video" and it.get("vid")]
    except (OSError, ValueError) as exc:
        if xbmc:
            xbmc.log(f"[EspaTV/yt_hub] Error buscando para radio: {exc}", xbmc.LOGWARNING)
        videos = []
    if not videos:
        dp.close()
        xbmcgui.Dialog().notification("EspaTV", "No se encontraron vídeos", xbmcgui.NOTIFICATION_WARNING)
        return
    seed_vid = videos[0]["vid"]
    seed_title = videos[0].get("title", seed_vid)
    dp.update(50, f"Generando lista de radio desde: {seed_title[:30]}...")
    related = yt_innertube.related_videos(seed_vid)
    dp.close()

    all_tracks = [videos[0]] + [r for r in related if r.get("vid") and r.get("vid") != seed_vid]
    opts = ["Reproducir con vídeo", "Modo solo audio (pantalla apagada/música)"]
    sel = xbmcgui.Dialog().select("Radio YouTube: " + query, opts)
    if sel < 0:
        return
    audio_only = (sel == 1)
    action_name = "yt_play_audio" if audio_only else "yt_play_video"

    pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    pl.clear()
    for tr in all_tracks:
        v_id = tr.get("vid")
        v_title = tr.get("title", v_id)
        if v_id:
            thumb = f"https://i.ytimg.com/vi/{v_id}/hqdefault.jpg"
            li = xbmcgui.ListItem(label=v_title)
            li.setArt({"icon": "DefaultMusicSongs.png", "thumb": thumb})
            li.setProperty("IsPlayable", "true")
            pl.add(_u(action=action_name, video_id=v_id, title=v_title), li)
    if pl.size() > 0:
        xbmcgui.Dialog().notification("EspaTV", f"Iniciando Radio ({pl.size()} temas)...", xbmcgui.NOTIFICATION_INFO, 2500)
        xbmc.Player().play(pl)


def channel_view(channel_id, channel_name=""):
    h = int(sys.argv[1]) if len(sys.argv) > 1 else -1
    if not channel_id:
        if h >= 0:
            xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    is_sub = yt_storage.is_subscribed(channel_id)
    title = channel_name or "Canal de YouTube"

    sub_label = "[COLOR orange][B]Desuscribirse de este canal[/B][/COLOR]" if is_sub else "[COLOR limegreen][B]Suscribirse a este canal[/B][/COLOR]"
    sub_action = "yt_sub_remove" if is_sub else "yt_sub_add"
    sub_icon = media_icon("yt_sub_remove.png" if is_sub else "yt_sub_add.png") or "DefaultActor.png"
    li_sub = xbmcgui.ListItem(label=sub_label)
    li_sub.setArt({"icon": sub_icon, "thumb": sub_icon})
    li_sub.setInfo("video", {"title": sub_label, "plot": "Gestiona la suscripción local a este canal."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action=sub_action, channel_id=channel_id, name=title), listitem=li_sub, isFolder=False)

    _tab_icons = {
        "videos": "yt_tab_videos.png",
        "streams": "yt_tab_live.png",
        "shorts": "yt_tab_videos.png",
        "playlists": "yt_tab_playlists.png",
        "search": "yt_tab_search.png",
    }
    tabs = [
        ("Vídeos", "videos", "Últimos vídeos subidos por el canal."),
        ("Directos", "streams", "Emisiones en directo actuales y anteriores."),
        ("Shorts", "shorts", "Vídeos cortos (Shorts)."),
        ("Playlists", "playlists", "Listas de reproducción del canal."),
    ]
    for tab_name, tab_id, tab_plot in tabs:
        tab_icon = media_icon(_tab_icons.get(tab_id, "DefaultFolder.png")) or "DefaultFolder.png"
        li = xbmcgui.ListItem(label=f"[B]{tab_name}[/B]")
        li.setArt({"icon": tab_icon, "thumb": tab_icon})
        li.setInfo("video", {"title": f"{title} - {tab_name}", "plot": tab_plot})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="yt_channel_tab", channel_id=channel_id, channel_name=title, tab=tab_id), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)


def channel_tab(channel_id, channel_name="", tab="videos", continuation=""):
    h = int(sys.argv[1]) if len(sys.argv) > 1 else -1
    if not channel_id:
        if h >= 0:
            xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", f"Cargando {tab} de {channel_name or 'canal'}...")
    try:
        items, next_cont = yt_innertube.browse_channel(channel_id, tab=tab, continuation=continuation)
        dp.close()
    except (OSError, ValueError) as exc:
        dp.close()
        if xbmc:
            xbmc.log(f"[EspaTV/yt] Error cargando pestaña {tab}: {exc}", xbmc.LOGERROR)
        items, next_cont = [], ""

    if not items:
        li = xbmcgui.ListItem(label="[COLOR grey]No se encontraron elementos en esta sección[/COLOR]")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    watched_ids = _watched_set()

    for it in items:
        itype = it.get("type", "video")
        if itype == "video":
            vid = it.get("vid", "")
            title = it.get("title", "Vídeo")
            dur = it.get("duration", "")
            views = it.get("views", "")
            published = it.get("published", "")
            thumb = it.get("thumb") or f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg"
            is_watched = vid in watched_ids
            lbl = f"[COLOR limegreen][Visto][/COLOR] {title}" if is_watched else title

            li = xbmcgui.ListItem(label=lbl)
            li.setArt({"icon": thumb, "thumb": thumb, "poster": thumb, "fanart": thumb})
            li.setProperty("IsPlayable", "true")
            plot_parts = []
            if channel_name:
                plot_parts.append(f"Canal: {channel_name}")
            if dur:
                plot_parts.append(f"Duración: {dur}")
            if views:
                plot_parts.append(f"Vistas: {views}")
            if published:
                plot_parts.append(f"Publicado: {published}")
            plot = "\n".join(plot_parts) if plot_parts else title
            info_dict = {"title": title, "plot": plot, "studio": channel_name}
            if is_watched:
                info_dict["playcount"] = 1
            li.setInfo("video", info_dict)

            ctx = _video_context_menu(
                vid=vid,
                title=title,
                channel=channel_name,
                channel_id=channel_id,
                duration=dur,
                thumb=thumb,
                is_watched=is_watched,
            )
            li.addContextMenuItems(ctx)

            play_url = _u(action="yt_play_video", video_id=vid, title=title)
            xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)
        elif itype == "playlist":
            pid = it.get("playlist_id", "")
            title = it.get("title", pid)
            li = xbmcgui.ListItem(label=f"{title} [COLOR skyblue](playlist)[/COLOR]")
            thumb = it.get("thumb") or "DefaultVideoPlaylists.png"
            li.setArt({"icon": thumb, "thumb": thumb})
            li.setInfo("video", {"title": title, "plot": f"Playlist: {title}"})
            play_url = _u(action="yt_playlist_open", list_id=pid, name=title)
            xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=True)

    if next_cont:
        li_next = xbmcgui.ListItem(label="[COLOR yellow][B]Página siguiente >>[/B][/COLOR]")
        icon_next = media_icon("yt_page_next.png") or "DefaultFolderBack.png"
        li_next.setArt({"icon": icon_next, "thumb": icon_next})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="yt_channel_tab", channel_id=channel_id, channel_name=channel_name, tab=tab, continuation=next_cont),
            listitem=li_next,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(h)


def related_view(video_id, title=""):
    h = int(sys.argv[1]) if len(sys.argv) > 1 else -1
    if not video_id:
        if h >= 0:
            xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Buscando vídeos relacionados...")
    try:
        items = yt_innertube.related_videos(video_id)
        dp.close()
    except (OSError, ValueError) as exc:
        dp.close()
        if xbmc:
            xbmc.log(f"[EspaTV/yt] Error en relacionados: {exc}", xbmc.LOGERROR)
        items = []

    if not items:
        xbmcgui.Dialog().notification("EspaTV", "No se encontraron vídeos relacionados", xbmcgui.NOTIFICATION_INFO)
        if h >= 0:
            xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    watched_ids = _watched_set()

    for it in items:
        vid = it.get("vid", "")
        it_title = it.get("title", "Vídeo")
        channel = it.get("channel", "")
        channel_id = it.get("channel_id", "")
        dur = it.get("duration", "")
        thumb = f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg"
        is_watched = vid in watched_ids
        lbl = f"[COLOR limegreen][Visto][/COLOR] {it_title}" if is_watched else it_title

        li = xbmcgui.ListItem(label=lbl)
        li.setArt({"icon": thumb, "thumb": thumb, "poster": thumb, "fanart": thumb})
        li.setProperty("IsPlayable", "true")
        plot = f"Canal: {channel}\nDuración: {dur}" if channel else it_title
        info_dict = {"title": it_title, "plot": plot, "studio": channel}
        if is_watched:
            info_dict["playcount"] = 1
        li.setInfo("video", info_dict)

        ctx = _video_context_menu(
            vid=vid,
            title=it_title,
            channel=channel,
            channel_id=channel_id,
            duration=dur,
            thumb=thumb,
            is_watched=is_watched,
        )
        li.addContextMenuItems(ctx)

        play_url = _u(action="yt_play_video", video_id=vid, title=it_title)
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def subs_feed():
    h = int(sys.argv[1])
    subs = yt_storage.get_subscriptions()
    if not subs:
        li = xbmcgui.ListItem(label="[COLOR yellow]No tienes canales suscritos[/COLOR]")
        li.setInfo("video", {"plot": "Suscríbete a canales desde la búsqueda o importa tu archivo de Google Takeout."})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        li_imp = xbmcgui.ListItem(label="[COLOR limegreen][B]Importar desde Google Takeout (CSV o JSON)[/B][/COLOR]")
        icon_imp = media_icon("yt_hub_import.png") or "DefaultAddSource.png"
        li_imp.setArt({"icon": icon_imp, "thumb": icon_imp})
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="yt_sub_import"), listitem=li_imp, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", f"Actualizando novedades de {len(subs)} canales...")
    try:
        videos = yt_innertube.fetch_subscriptions_feed(subs)
        dp.close()
    except (OSError, ValueError) as exc:
        dp.close()
        if xbmc:
            xbmc.log(f"[EspaTV/yt] Error en feed: {exc}", xbmc.LOGERROR)
        videos = []

    if not videos:
        li = xbmcgui.ListItem(label="[COLOR grey]No hay vídeos recientes en tus suscripciones[/COLOR]")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    watched_ids = _watched_set()

    for v in videos:
        vid = v.get("vid", "")
        title = v.get("title", "Vídeo")
        author = v.get("channel", "")
        cid = v.get("channel_id", "")
        pub = v.get("published", "")
        pub_date = pub.split("T")[0] if "T" in pub else pub
        thumb = f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg"
        is_watched = vid in watched_ids

        prefix = "[COLOR limegreen][Visto][/COLOR] " if is_watched else ""
        label = f"{prefix}[COLOR lightskyblue]{author}[/COLOR]: {title}"
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": thumb, "thumb": thumb, "poster": thumb, "fanart": thumb})
        li.setProperty("IsPlayable", "true")
        info_dict = {"title": title, "plot": f"Canal: {author}\nPublicado: {pub_date}", "studio": author}
        if is_watched:
            info_dict["playcount"] = 1
        li.setInfo("video", info_dict)

        ctx = _video_context_menu(
            vid=vid,
            title=title,
            channel=author,
            channel_id=cid,
            duration="",
            thumb=thumb,
            is_watched=is_watched,
        )
        li.addContextMenuItems(ctx)

        play_url = _u(action="yt_play_video", video_id=vid, title=title)
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def subs_list():
    h = int(sys.argv[1])
    subs = yt_storage.get_subscriptions()

    li_add = xbmcgui.ListItem(label="[COLOR limegreen][B]Añadir canal por @handle o URL[/B][/COLOR]")
    icon_sub_add = media_icon("yt_sub_add.png") or "DefaultAddSource.png"
    li_add.setArt({"icon": icon_sub_add, "thumb": icon_sub_add, "poster": icon_sub_add, "banner": icon_sub_add})
    li_add.setInfo("video", {"plot": "Introduce el handle (ej: @rtve) o enlace del canal para suscribirte."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="yt_sub_add_dialog"), listitem=li_add, isFolder=False)

    li_imp = xbmcgui.ListItem(label="[COLOR lightskyblue][B]Importar suscripciones (Google Takeout)[/B][/COLOR]")
    icon_imp = media_icon("yt_hub_import.png") or "DefaultNetwork.png"
    li_imp.setArt({"icon": icon_imp, "thumb": icon_imp, "poster": icon_imp, "banner": icon_imp})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="yt_sub_import"), listitem=li_imp, isFolder=False)

    for ch in subs:
        cid = ch.get("channel_id", "")
        name = ch.get("name", cid)
        thumb = ch.get("thumb") or "DefaultActor.png"

        li = xbmcgui.ListItem(label=name)
        li.setArt({"icon": thumb, "thumb": thumb, "poster": thumb, "banner": thumb})
        li.setInfo("video", {"title": name, "plot": f"Canal de YouTube: {name}"})

        fav_params = json.dumps({"yt_id": cid, "name": name, "ctype": "channel", "burl": ""})
        ctx = [
            ("Desuscribirse", f"RunPlugin({_u(action='yt_sub_remove', channel_id=cid)})"),
            (
                "Añadir a Mis Favoritos",
                f"RunPlugin({_u(action='add_favorite', title=name, fav_url=f'yt_ch_{cid}', icon=thumb, platform='youtube', fav_action='felicidad_play', params=fav_params)})",
            ),
        ]
        li.addContextMenuItems(ctx)

        play_url = _u(action="yt_channel_view", channel_id=cid, channel_name=name)
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)


def sub_add(channel_id, name="", thumb=""):
    if not channel_id:
        return
    ok = yt_storage.add_subscription(channel_id, name=name, thumb=thumb)
    if ok:
        xbmcgui.Dialog().notification("EspaTV", f"Suscrito a: {name or channel_id}", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")
    else:
        xbmcgui.Dialog().notification("EspaTV", "Ya estabas suscrito a este canal", xbmcgui.NOTIFICATION_WARNING, 2000)


def sub_remove(channel_id):
    if not channel_id:
        return
    if yt_storage.remove_subscription(channel_id):
        xbmcgui.Dialog().notification("EspaTV", "Suscripción eliminada", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")


def sub_add_dialog():
    opts = ["Escribir con teclado", "Enviar desde móvil/PC"]
    sel = xbmcgui.Dialog().select("Añadir canal de YouTube", opts)
    if sel < 0:
        return
    if sel == 1:
        import url_remote
        text = url_remote.receive_text("Añadir canal de YouTube (@handle o URL)")
    else:
        kb = xbmc.Keyboard("", "Introduce @handle, URL o ID del canal")
        kb.doModal()
        if not kb.isConfirmed():
            return
        text = kb.getText()
    if not text or not text.strip():
        return
    text = text.strip()
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Buscando canal...")
    info = yt_innertube.resolve_channel_info(text)
    dp.close()
    if not info or not info.get("channel_id"):
        xbmcgui.Dialog().ok("EspaTV", f"No se pudo encontrar ningún canal con: {text}")
        return
    sub_add(info["channel_id"], name=info.get("name") or text, thumb=info.get("thumb", ""))


def sub_import():
    path = xbmcgui.Dialog().browse(1, "Selecciona subscriptions.csv o .json", "files", ".csv|.json")
    if not path:
        return
    count = yt_storage.import_takeout(path)
    if count > 0:
        xbmcgui.Dialog().ok("EspaTV", f"Se han importado {count} canales correctamente.")
        xbmc.executebuiltin("Container.Refresh")
    else:
        xbmcgui.Dialog().ok("EspaTV", "No se encontraron canales válidos en el archivo seleccionado.")


def watch_later_menu():
    h = int(sys.argv[1])
    items = yt_storage.get_watch_later()

    if not items:
        li = xbmcgui.ListItem(label="[COLOR grey]No tienes vídeos en Ver más tarde[/COLOR]")
        li.setInfo("video", {"plot": "Añade vídeos usando el menú contextual 'Añadir a Ver más tarde'."})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    watched_ids = _watched_set()

    li_play = xbmcgui.ListItem(label="[COLOR limegreen][B]Reproducir todo[/B][/COLOR]")
    icon_wl_play = media_icon("yt_wl_play_all.png") or "DefaultFolderBack.png"
    li_play.setArt({"icon": icon_wl_play, "thumb": icon_wl_play, "poster": icon_wl_play, "banner": icon_wl_play})
    li_play.setInfo("video", {"plot": "Reproduce secuencialmente todos los vídeos guardados en Ver más tarde."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="yt_watch_later_play_all"), listitem=li_play, isFolder=False)

    li_cin = xbmcgui.ListItem(label="[COLOR FF38BDF8][B]Modo Cine[/B][/COLOR]")
    icon_wl_cin = media_icon("yt_cinema_mode.png") or "DefaultFolderBack.png"
    li_cin.setArt({"icon": icon_wl_cin, "thumb": icon_wl_cin, "poster": icon_wl_cin, "banner": icon_wl_cin})
    li_cin.setInfo("video", {"plot": "Abre el Modo Cine con todos los vídeos guardados en Ver más tarde."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="yt_watch_later_cinema"), listitem=li_cin, isFolder=False)

    li_clear = xbmcgui.ListItem(label="[COLOR orange][B]Vaciar lista de Ver más tarde...[/B][/COLOR]")
    icon_wl_clear = media_icon("yt_wl_clear.png") or "DefaultFolderBack.png"
    li_clear.setArt({"icon": icon_wl_clear, "thumb": icon_wl_clear, "poster": icon_wl_clear, "banner": icon_wl_clear})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="yt_watch_later_clear"), listitem=li_clear, isFolder=False)

    for it in items:
        vid = it.get("video_id") or it.get("vid", "")
        title = it.get("title", "Vídeo")
        channel = it.get("channel", "")
        channel_id = it.get("channel_id", "")
        dur = it.get("duration", "")
        thumb = it.get("thumb") or f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg"
        is_watched = vid in watched_ids
        lbl = f"[COLOR limegreen][Visto][/COLOR] {title}" if is_watched else title

        li = xbmcgui.ListItem(label=lbl)
        li.setArt({"icon": thumb, "thumb": thumb, "poster": thumb, "fanart": thumb})
        li.setProperty("IsPlayable", "true")
        plot = f"Canal: {channel}\nDuración: {dur}" if channel else title
        info_dict = {"title": title, "plot": plot, "studio": channel}
        if is_watched:
            info_dict["playcount"] = 1
        li.setInfo("video", info_dict)

        ctx = _video_context_menu(
            vid=vid,
            title=title,
            channel=channel,
            channel_id=channel_id,
            duration=dur,
            thumb=thumb,
            is_watched=is_watched,
            extra_first=[("Eliminar de Ver más tarde", f"RunPlugin({_u(action='yt_watch_later_remove', video_id=vid)})")],
        )
        li.addContextMenuItems(ctx)

        play_url = _u(action="yt_play_video", video_id=vid, title=title)
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def watch_later_add(video_id, title="", channel="", duration="", channel_id=""):
    if not video_id:
        return
    ok = yt_storage.add_watch_later(video_id, title=title, channel=channel, duration=duration, channel_id=channel_id)
    if ok:
        xbmcgui.Dialog().notification("EspaTV", "Añadido a Ver más tarde", xbmcgui.NOTIFICATION_INFO, 2000)
    else:
        xbmcgui.Dialog().notification("EspaTV", "Ya estaba en Ver más tarde", xbmcgui.NOTIFICATION_WARNING, 2000)


def watch_later_remove(video_id):
    if not video_id:
        return
    if yt_storage.remove_watch_later(video_id):
        xbmcgui.Dialog().notification("EspaTV", "Eliminado de Ver más tarde", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("Container.Refresh")


def watch_later_play_all():
    items = yt_storage.get_watch_later()
    if not items:
        xbmcgui.Dialog().notification("EspaTV", "No hay vídeos en Ver más tarde", xbmcgui.NOTIFICATION_WARNING)
        return
    pl = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
    pl.clear()
    for it in items:
        vid = it.get("video_id") or it.get("vid")
        title = it.get("title", vid)
        if vid:
            thumb = it.get("thumb") or f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg"
            li = xbmcgui.ListItem(label=title)
            li.setArt({"icon": "DefaultVideo.png", "thumb": thumb})
            li.setProperty("IsPlayable", "true")
            pl.add(_u(action="yt_play_video", video_id=vid, title=title), li)
    if pl.size() > 0:
        xbmcgui.Dialog().notification("EspaTV", f"Reproduciendo {pl.size()} vídeos...", xbmcgui.NOTIFICATION_INFO, 2500)
        xbmc.Player().play(pl)


def watch_later_cinema():
    items = yt_storage.get_watch_later()
    if not items:
        xbmcgui.Dialog().notification("EspaTV", "No hay vídeos en Ver más tarde", xbmcgui.NOTIFICATION_WARNING)
        return
    cinema_items = [
        {
            "name": it.get("title", ""),
            "yt_id": it.get("video_id") or it.get("vid"),
            "type": "video",
            "channel": it.get("channel", ""),
            "duration": str(it.get("duration", "")),
            "views": "",
            "desc": "",
            "url": "",
        }
        for it in items if (it.get("video_id") or it.get("vid"))
    ]
    import default
    default._run_cinema(cinema_items, "Ver más tarde")


def watch_later_clear():
    if xbmcgui.Dialog().yesno("Confirmar", "¿Vaciar toda la lista de Ver más tarde?"):
        yt_storage.clear_watch_later()
        xbmcgui.Dialog().notification("EspaTV", "Lista vaciada", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")


def watched_clear():
    if xbmcgui.Dialog().yesno("Confirmar", "¿Borrar el historial de vídeos vistos en YouTube?"):
        yt_storage.clear_watched()
        xbmcgui.Dialog().notification("EspaTV", "Historial borrado", xbmcgui.NOTIFICATION_INFO)
        xbmc.executebuiltin("Container.Refresh")


def watched_menu():
    h = int(sys.argv[1])
    items = yt_storage.get_watched()

    if not items:
        li = xbmcgui.ListItem(label="[COLOR grey]No hay historial de vídeos vistos en YouTube[/COLOR]")
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return


    li_clear = xbmcgui.ListItem(label="[COLOR orange][B]Borrar historial de vídeos vistos...[/B][/COLOR]")
    icon_hist_clear = media_icon("yt_hist_clear.png") or "DefaultFolderBack.png"
    li_clear.setArt({"icon": icon_hist_clear, "thumb": icon_hist_clear, "poster": icon_hist_clear, "banner": icon_hist_clear})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="yt_watched_clear"), listitem=li_clear, isFolder=False)

    for it in items:
        vid = it.get("video_id") or it.get("vid", "")
        title = it.get("title") or vid
        channel = it.get("channel", "")
        thumb = it.get("thumb") or f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg"

        li = xbmcgui.ListItem(label=title)
        li.setArt({"icon": thumb, "thumb": thumb, "poster": thumb, "fanart": thumb})
        li.setProperty("IsPlayable", "true")
        li.setInfo("video", {"title": title, "plot": f"Visto: {title}", "studio": channel, "playcount": 1})

        ctx = _video_context_menu(
            vid=vid,
            title=title,
            channel=channel,
            thumb=thumb,
            is_watched=True,
        )
        li.addContextMenuItems(ctx)

        play_url = _u(action="yt_play_video", video_id=vid, title=title)
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def clear_cache():
    cdir = yt_innertube._get_cache_dir()
    count = 0
    if os.path.exists(cdir):
        for f in os.listdir(cdir):
            fp = os.path.join(cdir, f)
            try:
                if os.path.isfile(fp):
                    os.remove(fp)
                    count += 1
            except OSError as exc:
                if xbmc:
                    xbmc.log(f"[EspaTV/yt_hub] Error borrando caché {fp}: {exc}", xbmc.LOGWARNING)
    xbmcgui.Dialog().notification("EspaTV", f"Caché vaciada ({count} archivos)", xbmcgui.NOTIFICATION_INFO)


def settings_menu():
    settings = yt_storage.get_settings()

    res_options = ["Auto (Mejor disponible)", "1080p", "720p", "480p", "360p"]
    cur_res = settings.get("max_resolution", "1080p")
    cur_idx = 1
    for i, r in enumerate(res_options):
        if r.lower().startswith(cur_res.lower()):
            cur_idx = i
            break

    options = [
        f"Resolución máxima preferida: [COLOR yellow]{res_options[cur_idx]}[/COLOR]",
        f"SponsorBlock (saltar patrocinios): [COLOR yellow]{'Activado' if settings.get('sponsorblock', False) else 'Desactivado'}[/COLOR]",
        f"Subtítulos en español automáticos: [COLOR yellow]{'Activado' if settings.get('subtitles', True) else 'Desactivado'}[/COLOR]",
        "[COLOR orange]Vaciar caché de YouTube (búsquedas y canales)[/COLOR]",
    ]
    sel = xbmcgui.Dialog().select("Ajustes de YouTube en EspaTV", options)
    if sel == 0:
        r_sel = xbmcgui.Dialog().select("Resolución máxima", res_options)
        if r_sel >= 0:
            val = "auto" if r_sel == 0 else res_options[r_sel].replace("p", "") + "p"
            settings["max_resolution"] = val
            yt_storage.save_settings(settings)
            xbmcgui.Dialog().notification("EspaTV", f"Resolución guardada: {res_options[r_sel]}", xbmcgui.NOTIFICATION_INFO)
    elif sel == 1:
        settings["sponsorblock"] = not settings.get("sponsorblock", False)
        yt_storage.save_settings(settings)
        st = "activado" if settings["sponsorblock"] else "desactivado"
        xbmcgui.Dialog().notification("EspaTV", f"SponsorBlock {st}", xbmcgui.NOTIFICATION_INFO)
    elif sel == 2:
        settings["subtitles"] = not settings.get("subtitles", True)
        yt_storage.save_settings(settings)
        st = "activados" if settings["subtitles"] else "desactivados"
        xbmcgui.Dialog().notification("EspaTV", f"Subtítulos {st}", xbmcgui.NOTIFICATION_INFO)
    elif sel == 3:
        clear_cache()
