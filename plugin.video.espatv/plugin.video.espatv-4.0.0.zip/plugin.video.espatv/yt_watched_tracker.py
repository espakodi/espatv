# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Seguimiento de vídeos de YouTube marcados como vistos."""
import json
import os
import threading

import xbmc
import xbmcgui

import core_settings

try:
    import yt_storage
except ImportError:
    yt_storage = None

_LOCK = threading.RLock()
_FILE = os.path.join(core_settings._PROFILE_PATH, "watched_yt.json")


def load():
    with _LOCK:
        if not os.path.exists(_FILE):
            return set()
        try:
            with open(_FILE, "r", encoding="utf-8") as f:
                data = json.load(f)
            return set(data) if isinstance(data, list) else set()
        except (OSError, ValueError):
            return set()


def save(ids):
    with _LOCK:
        try:
            core_settings.atomic_write_json(_FILE, list(ids))
        except OSError as exc:
            xbmc.log(f"[EspaTV/yt_watched] Error guardando {_FILE}: {exc}", xbmc.LOGWARNING)


def mark_watched(yt_id, title="", channel="", duration=0):
    if not yt_id:
        return
    with _LOCK:
        ids = load()
        if yt_id not in ids:
            ids.add(yt_id)
            save(ids)
        if yt_storage:
            try:
                yt_storage.add_watched(yt_id, title=title, channel=channel, duration=duration)
            except (OSError, ValueError) as exc:
                xbmc.log(f"[EspaTV/yt_watched] Error sincronizando yt_storage: {exc}", xbmc.LOGWARNING)


def toggle(yt_id):
    if not yt_id:
        return
    with _LOCK:
        ids = load()
        if yt_id in ids:
            ids.discard(yt_id)
            if yt_storage:
                try:
                    data = yt_storage._load_json(yt_storage._WATCHED_FILE, [])
                    if isinstance(data, list):
                        new_data = [it for it in data if (it.get("video_id") or it.get("vid")) != yt_id]
                        if len(new_data) != len(data):
                            yt_storage._save_json(yt_storage._WATCHED_FILE, new_data)
                except (OSError, ValueError) as exc:
                    xbmc.log(f"[EspaTV/yt_watched] Error desmarcando en yt_storage: {exc}", xbmc.LOGWARNING)
            xbmcgui.Dialog().notification("EspaTV", "Desmarcado como visto", xbmcgui.NOTIFICATION_INFO, 1500)
        else:
            ids.add(yt_id)
            if yt_storage:
                try:
                    yt_storage.add_watched(yt_id)
                except (OSError, ValueError) as exc:
                    xbmc.log(f"[EspaTV/yt_watched] Error marcando en yt_storage: {exc}", xbmc.LOGWARNING)
            xbmcgui.Dialog().notification("EspaTV", "Marcado como visto", xbmcgui.NOTIFICATION_INFO, 1500)
        save(ids)
    xbmc.executebuiltin("Container.Refresh")
