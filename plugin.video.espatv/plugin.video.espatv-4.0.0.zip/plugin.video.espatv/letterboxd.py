# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Letterboxd: listas curadas de películas para descubrimiento."""
import html as _html
import json
import os
import re
import ssl
import sys
import threading
import time
import urllib.parse

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings

from _user_agents import desktop_headers as _dh, ACCEPT_HTML

_TTL = 24 * 3600

_LISTS = [
    ("Letterboxd Top 500",      "https://letterboxd.com/official/list/letterboxds-top-500-films/"),
    ("IMDb Top 250",            "https://letterboxd.com/dave/list/imdb-top-250/"),
    ("1001 películas que ver",  "https://letterboxd.com/peterstanley/list/1001-movies-you-must-see-before-you-die/"),
]

_HEADERS = _dh(accept=ACCEPT_HTML, referer="https://letterboxd.com/")


class _Tls13Adapter(requests.adapters.HTTPAdapter):
    # Cloudflare reta el fingerprint TLS 1.2 del Python de Kodi con un 403; con
    # TLS 1.3 el handshake pasa. Mismo bloqueo de capa TLS que FilmAffinity.
    def init_poolmanager(self, *args, **kwargs):
        ctx = ssl.create_default_context()
        ctx.minimum_version = ssl.TLSVersion.TLSv1_3
        kwargs["ssl_context"] = ctx
        return super().init_poolmanager(*args, **kwargs)


# Letterboxd enseña 100 películas por página; la lista más larga, la de 1001, son 11.
_MAX_PAGINAS = 11


def _es_de_letterboxd(url):
    # `list_url` llega en la URL del plugin, que puede venir de un favorito o de JSON-RPC.
    try:
        partes = urllib.parse.urlparse(url)
        return partes.scheme == 'https' and partes.hostname in ('letterboxd.com',
                                                                'www.letterboxd.com')
    except ValueError:
        return False


def _descarga_lista(list_url):
    """(películas, completa): todas las páginas de la lista, con la misma sesión.

    Si una página falla, o llega sin películas (el reto de Cloudflare contesta 200), se
    devuelve lo que ya había con `completa=False`: mejor 200 de 250 que ninguna, pero eso no
    se puede guardar 24 h como si fuera la lista."""
    films = []
    vistos = set()
    with requests.Session() as s:
        s.mount("https://", _Tls13Adapter())
        for n in range(1, _MAX_PAGINAS + 1):
            url = list_url if n == 1 else f"{list_url.rstrip('/')}/page/{n}/"
            try:
                r = s.get(url, headers=_HEADERS, timeout=15)
            except requests.RequestException as e:
                xbmc.log(f"[EspaTV-LB] list request error (página {n}): {e}", xbmc.LOGERROR)
                return films, False
            xbmc.log(f"[EspaTV-LB] list fetch {url[:70]} -> {r.status_code}", xbmc.LOGINFO)
            if r.status_code != 200:
                xbmc.log(f"[EspaTV-LB] list HTTP {r.status_code}", xbmc.LOGWARNING)
                return films, False
            pagina = _parse_list_html(r.text)
            if not pagina:
                xbmc.log(f"[EspaTV-LB] página {n} sin películas", xbmc.LOGWARNING)
                return films, False
            for f in pagina:
                if f['title'].lower() not in vistos:
                    vistos.add(f['title'].lower())
                    films.append(f)
            if f"/page/{n + 1}/" not in r.text:
                break
    return films, True


def _u(**kwargs):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kwargs)

def _handle():
    return int(sys.argv[1])


def _cache_path():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    return os.path.join(profile, 'espatv_letterboxd_cache.json')


def _load_cache():
    try:
        p = _cache_path()
        if not os.path.exists(p):
            return {}
        with open(p, 'r', encoding='utf-8') as fh:
            data = json.load(fh)
        return data if isinstance(data, dict) else {}
    except (OSError, ValueError):
        return {}


def _save_cache(data):
    # tmp ÚNICO por hilo: dos escrituras concurrentes con el mismo .tmp se pisaban y
    # dejaban el JSON corrupto ("Extra data"), lo que vaciaba toda la caché al leerla.
    try:
        p = _cache_path()
        os.makedirs(os.path.dirname(p), exist_ok=True)
        tmp = f'{p}.{threading.get_ident()}.tmp'
        with open(tmp, 'w', encoding='utf-8') as fh:
            json.dump(data, fh, ensure_ascii=False)
        os.replace(tmp, p)
    except OSError as e:
        xbmc.log("[EspaTV-LB] cache save: {0}".format(e), xbmc.LOGWARNING)


def _parse_list_html(html_text):
    """Extrae pares {title, year} de una página de lista de Letterboxd.

    Cada película es un poster con data-item-name="Título (AAAA)".
    """
    films = []
    seen = set()
    for raw in re.findall(r'data-item-name="([^"]+)"', html_text):
        name = _html.unescape(raw).strip()
        m = re.match(r'^(.*?)\s*\((\d{4})\)\s*$', name)
        if m:
            title, year = m.group(1).strip(), m.group(2)
        else:
            title, year = name, ''

        key = title.lower()
        if title and key not in seen:
            seen.add(key)
            films.append({'title': title, 'year': year})

    return films


def _fetch_list(list_key, list_url):
    if not _es_de_letterboxd(list_url):
        xbmc.log(f"[EspaTV-LB] lista fuera de letterboxd.com, no se pide: {list_url[:60]}",
                 xbmc.LOGWARNING)
        return []
    cache = _load_cache()
    entry = cache.get(list_key, {})
    if entry and (time.time() - entry.get('ts', 0)) < _TTL:
        return entry['films']

    films, completa = _descarga_lista(list_url)
    caducadas = entry.get('films') or []

    if films and completa:
        cache[list_key] = {'ts': time.time(), 'films': films}
        _save_cache(cache)
    elif len(caducadas) > len(films):
        xbmc.log(f"[EspaTV-LB] usando caché caducada para '{list_key}'", xbmc.LOGWARNING)
        return caducadas

    return films


def show_menu():
    h = _handle()
    for label, url in _LISTS:
        li = xbmcgui.ListItem(label=label)
        li.setArt({'icon': 'DefaultVideoPlaylists.png'})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='letterboxd_list', list_key=label, list_url=url),
            listitem=li,
            isFolder=True,
        )
    xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.remember_list_position())


def _trigger_bg_enrich(items):
    import metadata_enricher as me

    def _fetch():
        try:
            results = me.batch_enrich(items, max_workers=2)
            # Solo refrescar si el usuario sigue en esta sección (el fetch tarda y
            # para entonces puede haber navegado a otra pantalla).
            if any(results) and 'action=letterboxd_list' in (xbmc.getInfoLabel('Container.FolderPath') or ''):
                xbmc.executebuiltin("Container.Refresh")
        except Exception as e:
            xbmc.log("[EspaTV-LB] bg enrich: {0}".format(e), xbmc.LOGWARNING)

    threading.Thread(target=_fetch, daemon=True).start()


def show_list(list_key, list_url):
    import metadata_enricher as me

    h = _handle()
    films = _fetch_list(list_key, list_url)
    if not films:
        xbmcgui.Dialog().notification(
            "EspaTV",
            "No se pudo cargar la lista de Letterboxd",
            xbmcgui.NOTIFICATION_ERROR,
        )
        xbmcplugin.endOfDirectory(h, succeeded=False, cacheToDisc=False)
        return

    af = xbmcaddon.Addon().getAddonInfo('fanart')

    # Sin setContent: Estuary pinta la carátula en la fila en vez de la marca de visto.

    enrich_items = [
        {'title': f['title'], 'year': int(f['year']) if f.get('year', '').isdigit() else None,
         'media_type': 'movie'}
        for f in films
    ]
    metas = me.batch_enrich(enrich_items, use_cache_only=True)

    _media = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')
    _icon = lambda n: os.path.join(_media, n)

    if any(metas):
        li = xbmcgui.ListItem(label="Borrar metadatos de esta lista")
        li.setArt({'icon': _icon('adv_borrar.png')})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='letterboxd_clear_meta', list_key=list_key, list_url=list_url),
            listitem=li,
            isFolder=False,
        )
    else:
        li = xbmcgui.ListItem(label="Descargar metadatos completos (actores, director...)")
        li.setArt({'icon': _icon('adv_cache.png')})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action='letterboxd_cache_meta', list_key=list_key, list_url=list_url),
            listitem=li,
            isFolder=False,
        )

    missing = []
    for f, meta, item in zip(films, metas, enrich_items):
        year_int = int(f['year']) if f.get('year', '').isdigit() else 0
        label = "{0} ({1})".format(f['title'], year_int) if year_int else f['title']
        li = xbmcgui.ListItem(label=label)

        if meta:
            me.apply_to_listitem(li, meta, addon_fanart=af)
            poster = meta.get('poster', '')
        else:
            li.setArt({'icon': 'DefaultVideo.png'})
            li.setInfo('video', {'title': f['title'], 'year': year_int, 'mediatype': 'movie'})
            poster = ''
            missing.append(item)

        tmdb_id = (meta.get('ids') or {}).get('tmdb', '') if meta else ''
        cm = [
            ("¿Dónde ver en España?", "RunPlugin({0})".format(
                _u(action='show_watch_providers', title=f['title'], tmdb_id=tmdb_id))),
            ("Buscar en más fuentes", "RunPlugin({0})".format(
                _u(action='search_movie_multi', q=f['title'], tmdb_id=tmdb_id, media_type='movie'))),
            ("Copiar título", "RunPlugin({0})".format(
                _u(action='copy_title', title=f['title']))),
        ]
        li.addContextMenuItems(cm)
        li.setProperty('IsPlayable', 'false')
        url = _u(action='search_alt_prompt', q=f['title'], ot=poster, mode='movie', tmdb_id=tmdb_id)
        xbmcplugin.addDirectoryItem(handle=h, url=url, listitem=li, isFolder=False)

    if missing:
        _trigger_bg_enrich(missing)

    xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.remember_list_position())


def clear_list_meta(list_key, list_url):
    import metadata_enricher as me

    films = _fetch_list(list_key, list_url)
    items = [
        {'title': f['title'],
         'year': int(f['year']) if f.get('year', '').isdigit() else None,
         'media_type': 'movie'}
        for f in films
    ]
    me.delete_items(items)
    xbmcgui.Dialog().notification("EspaTV", "Metadatos de lista eliminados", xbmcgui.NOTIFICATION_INFO)
    xbmc.executebuiltin("Container.Refresh")


def cache_list_meta(list_key, list_url):
    import metadata_enricher as me

    films = _fetch_list(list_key, list_url)
    if not films:
        xbmcgui.Dialog().notification("EspaTV", "No hay películas para descargar", xbmcgui.NOTIFICATION_ERROR)
        return

    items = [
        {'title': f['title'],
         'year': int(f['year']) if f.get('year', '').isdigit() else None,
         'media_type': 'movie'}
        for f in films
    ]
    pDialog = xbmcgui.DialogProgress()
    pDialog.create("EspaTV", "Descargando metadatos Letterboxd...")
    try:
        count = me.batch_fetch_with_progress(items, pDialog)
    finally:
        pDialog.close()

    xbmcgui.Dialog().notification(
        "EspaTV", "Metadatos guardados: {0}/{1}".format(count, len(items)), xbmcgui.NOTIFICATION_INFO,
    )
    xbmc.executebuiltin("Container.Refresh")
