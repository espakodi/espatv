# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Copias de seguridad, restauración e importación/exportación de datos."""
import io
import json
import os
import sys
import time
import urllib.parse
import zipfile

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _leer_bytes(path):
    """Lee un fichero que eligió el usuario. Con xbmcvfs funciona también en carpetas
    de red (smb://, nfs://), donde open() no llega."""
    try:
        with xbmcvfs.File(path, 'rb') as fh:
            return fh.readBytes(fh.size())
    except (OSError, RuntimeError) as e:
        xbmc.log("[EspaTV/backups] No se pudo leer {0}: {1}".format(path, e), xbmc.LOGWARNING)
        return None


def _escribir_bytes(path, data):
    try:
        with xbmcvfs.File(path, 'wb') as fh:
            escrito = fh.write(data)
    except (OSError, RuntimeError) as e:
        xbmc.log("[EspaTV/backups] No se pudo escribir {0}: {1}".format(path, e), xbmc.LOGWARNING)
        return False
    if escrito:
        return True
    # write() no lanza: con el disco lleno o la red caída devuelve False y deja el fichero a
    # medias, que luego no se podría restaurar.
    xbmc.log(f"[EspaTV/backups] No se pudo escribir {path} entero", xbmc.LOGWARNING)
    xbmcvfs.delete(path)
    return False


def _en_carpeta(elegida, nombre, extensiones):
    """Dónde guardar `nombre` dentro de lo que ha devuelto `browse(3)`.

    `browse(3)` solo deja elegir carpetas, pero `os.path.isdir()` no ve las de red (smb://,
    nfs://): con una de esas se guardaba dentro un fichero llamado `.json` o `.zip`.
    """
    if elegida.lower().endswith(extensiones):
        return elegida
    return os.path.join(elegida, nombre)


def _fusionar_json(dest_path, zf, fz):
    """Fusiona el fichero del backup con el actual. Si algo falla (JSON roto, tipos que
    no encajan), deja el actual intacto y devuelve False: nunca cae a sustituir, porque
    eso borraría los datos del usuario. Escribe en atómico."""
    try:
        with open(dest_path, 'r', encoding='utf-8') as fh:
            current = json.load(fh)
        with zf.open(fz) as zfile:
            backup = json.load(zfile)
        if isinstance(current, list) and isinstance(backup, list):
            merged = current + [x for x in backup if x not in current]
        elif isinstance(current, dict) and isinstance(backup, dict):
            merged = dict(current)
            merged.update(backup)
        else:
            xbmc.log("[EspaTV/backups] {0}: no se puede fusionar (tipos distintos)".format(fz),
                     xbmc.LOGWARNING)
            return False
        return core_settings.atomic_write_json(dest_path, merged, ensure_ascii=False)
    except (OSError, ValueError, KeyError) as e:
        xbmc.log("[EspaTV/backups] {0}: fallo al fusionar: {1}".format(fz, e), xbmc.LOGERROR)
        return False


def _sustituir(zf, fz, carpeta):
    """Pone la entrada `fz` del zip en `carpeta` sin tocar el fichero actual hasta tener el
    nuevo entero y comprobado.

    `zf.extract` abría el destino en 'wb' antes de leer un byte: con una entrada dañada (el
    CRC se comprueba al acabar de leer) el JSON quedaba vacío o a medias,
    `_load_json` lo leía como el valor por defecto y el siguiente guardado lo pisaba."""
    contenido = json.loads(zf.read(fz).decode('utf-8'))
    if not core_settings.atomic_write_json(os.path.join(carpeta, fz), contenido,
                                           ensure_ascii=False):
        raise OSError(f"no se pudo escribir {fz}")


def _get_backup_dir():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    d = os.path.join(p, 'backups')
    if not os.path.exists(d): os.makedirs(d)
    return d


def import_backup():
    f = xbmcgui.Dialog().browse(1, 'Seleccionar Backup', 'files', '.zip', False, False, '')
    if not f: return

    file_labels = {
        'settings.json': 'Configuración General',
        'favorites.json': 'Favoritos',
        'search_history.json': 'Historial de Búsquedas DM',
        'yt_search_history.json': 'Historial de Búsquedas YouTube',
        'custom_categories.json': 'Categorías',
        'dm_settings.json': 'Ajustes Dailymotion',
        'watch_history.json': 'Historial de Visionado',
        'custom_iptv.json': 'Listas IPTV (antiguas)',
        'custom_iptv_lists.json': 'Listas de canales',
        'url_history.json': 'Historial de URLs',
        'url_bookmarks.json': 'Marcadores de URLs',
        'saved_playlists.json': 'Playlists DM Guardadas',
        'yt_playlists.json': 'Playlists YouTube Guardadas',
        'downloads_history.json': 'Historial de Descargas',
        'trakt_settings.json': 'Configuración Trakt',
        'xxx_settings.json': 'Ajustes de la Sección X (+18)',
        'xxx_favs.json': 'Favoritos de la Sección X',
        'xxx_hist.json': 'Historial de la Sección X',
    }
    # xxx_settings.json NO es "mergeable": lleva el hash del PIN y al fusionar se pisaría el
    # del perfil que importa, y con él el PIN que la persona tiene puesto.
    mergeable = ['favorites.json', 'search_history.json', 'yt_search_history.json',
                 'watch_history.json', 'url_history.json', 'url_bookmarks.json',
                 'saved_playlists.json', 'yt_playlists.json', 'downloads_history.json',
                 'xxx_favs.json', 'xxx_hist.json']
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))

    datos = _leer_bytes(f)
    if datos is None:
        xbmcgui.Dialog().ok("Error", "No se pudo leer el archivo seleccionado.")
        return

    try:
        with zipfile.ZipFile(io.BytesIO(datos), 'r') as zf:
            available = zf.namelist()
        known = [fz for fz in available if fz in file_labels]
        if 'custom_iptv_lists.json' in known and 'custom_iptv.json' in known:
            # Las antiguas pasaron a las nuevas al guardar la primera vez: ya están dentro.
            known.remove('custom_iptv.json')

        cache_files = [fz for fz in available if fz.startswith("cat_cache_") and fz.endswith(".json")]
        if cache_files:
            known.append('__cache__')
            file_labels['__cache__'] = 'Caché de Categorías ({0})'.format(len(cache_files))

        if not known:
            xbmcgui.Dialog().ok("EspaTV", "Este archivo no contiene datos reconocidos.")
            return

        options = [file_labels.get(fz, fz) for fz in known]
        selected = xbmcgui.Dialog().multiselect("¿Qué deseas importar?", options,
                                                preselect=list(range(len(options))))
        if not selected: return

        files_to_restore = [known[i] for i in selected]
        restored = 0
        fallos = []
        with zipfile.ZipFile(io.BytesIO(datos), 'r') as zf:
            for fz in files_to_restore:
                try:
                    if fz in ('custom_iptv_lists.json', 'custom_iptv.json'):
                        # Pasan por la suite de listas: con las listas nuevas ya creadas, un
                        # custom_iptv.json copiado al perfil no se leería nunca.
                        import iptv_lists
                        if iptv_lists.restore_from_backup(zf, fz):
                            restored += 1
                        continue
                    if fz == '__cache__':
                        for cf in cache_files:
                            _sustituir(zf, cf, p)
                            restored += 1
                        continue
                    dest_path = os.path.join(p, fz)
                    if fz in mergeable and os.path.exists(dest_path):
                        choice = xbmcgui.Dialog().select(file_labels[fz],
                            ["Sustituir (borrar actual)", "Añadir (fusionar con actual)", "Omitir"])
                        if choice == 2 or choice == -1:
                            continue
                        if choice == 1:
                            # "Añadir": si la fusión falla, se deja el actual como estaba.
                            if _fusionar_json(dest_path, zf, fz):
                                restored += 1
                            else:
                                fallos.append(file_labels[fz])
                            continue
                    resolved = os.path.realpath(os.path.join(p, fz))
                    if not resolved.startswith(os.path.realpath(p)):
                        continue
                    _sustituir(zf, fz, p)
                    restored += 1
                except (OSError, ValueError, zipfile.BadZipFile, KeyError) as e:
                    fallos.append(file_labels.get(fz, fz))
                    xbmc.log("[EspaTV/backups] Entrada {0} descartada: {1}".format(fz, e),
                             xbmc.LOGWARNING)

        msg = "Se restauraron {0} elementos.".format(restored)
        if fallos:
            msg += "\n\nNo se pudieron restaurar (se dejaron como estaban):\n" + ", ".join(fallos)
        xbmcgui.Dialog().ok("Importación Completa", msg)
        xbmc.executebuiltin("Container.Refresh")

    except (OSError, ValueError, zipfile.BadZipFile) as e:
        xbmcgui.Dialog().ok("Error", "Fallo al importar:\n{0}".format(e))


def export_favorites():
    favs = core_settings.get_favorites()
    if not favs:
        xbmcgui.Dialog().notification("EspaTV", "No hay favoritos para exportar", xbmcgui.NOTIFICATION_INFO)
        return

    ts = time.strftime("%Y%m%d_%H%M")
    default_name = "EspaTV_favoritos_{0}.json".format(ts)

    # Sin texto por defecto: al cancelar, Kodi devuelve ese texto y se guardaba en una ruta
    # relativa.
    d = xbmcgui.Dialog().browse(3, 'Guardar Favoritos', 'files', '', False, False, '')
    if not d: return
    d = _en_carpeta(d, default_name, ".json")

    datos = json.dumps(favs, ensure_ascii=False, indent=2).encode('utf-8')
    if _escribir_bytes(d, datos):
        xbmcgui.Dialog().ok("Exportar Favoritos", "Guardado correctamente:\n{0}\n\nElementos: {1}".format(os.path.basename(d), len(favs)))
    else:
        xbmcgui.Dialog().ok("Error", "No se pudo guardar en:\n{0}".format(d))


def import_favorites():
    f = xbmcgui.Dialog().browse(1, 'Seleccionar archivo de favoritos', 'files', '.json', False, False, '')
    if not f: return

    datos = _leer_bytes(f)
    if datos is None:
        xbmcgui.Dialog().ok("Error", "No se pudo leer el archivo seleccionado.")
        return

    try:
        new_favs = json.loads(datos.decode('utf-8'))

        if not isinstance(new_favs, list):
            xbmcgui.Dialog().ok("Error", "El archivo no es una lista válida de favoritos.")
            return

        if new_favs and not (isinstance(new_favs[0], dict) and 'url' in new_favs[0]):
            xbmcgui.Dialog().ok("Error", "El formato del JSON no parece ser de favoritos de EspaTV.")
            return

        opts = ["Fusionar (Añadir nuevos)", "Reemplazar lista completa"]
        sel = xbmcgui.Dialog().select("¿Cómo importar?", opts)
        if sel < 0: return

        if sel == 0:
            added = 0
            for item in new_favs:
                # Entrada dañada o incompleta: se descarta, no aborta la importación.
                if not (isinstance(item, dict) and item.get('title') and item.get('url')):
                    continue
                if core_settings.add_favorite(item.get('title'), item.get('url'),
                                              item.get('icon', ''), item.get('platform', ''),
                                              item.get('action', ''), item.get('params')):
                    added += 1
            xbmcgui.Dialog().notification("EspaTV", "{0} favoritos añadidos".format(added), xbmcgui.NOTIFICATION_INFO)
        else:
            profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
            fav_file = os.path.join(profile, 'favorites.json')
            # Atómico: es el fichero de datos, no una exportación que se pueda repetir.
            if core_settings.atomic_write_json(fav_file, new_favs, ensure_ascii=False):
                xbmcgui.Dialog().notification("EspaTV", "Lista reemplazada", xbmcgui.NOTIFICATION_INFO)
            else:
                xbmcgui.Dialog().ok("Error", "No se pudo guardar la lista de favoritos.")

        xbmc.executebuiltin("Container.Refresh")

    except (OSError, ValueError, TypeError, KeyError) as e:
        xbmcgui.Dialog().ok("Error", str(e))


def create_full():
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(profile): os.makedirs(profile)

    groups = [
        ("Favoritos", ['favorites.json']),
        ("Categorías", ['custom_categories.json']),
        ("Historial de Búsquedas DM", ['search_history.json']),
        ("Historial de Búsquedas YouTube", ['yt_search_history.json']),
        ("Historial de Visionado", ['watch_history.json']),
        ("Historial de URLs", ['url_history.json', 'url_bookmarks.json']),
        ("Playlists DM Guardadas", ['saved_playlists.json']),
        ("Playlists YouTube Guardadas", ['yt_playlists.json']),
        ("Historial de Descargas", ['downloads_history.json']),
        ("Configuración General", ['settings.json']),
        ("Ajustes Dailymotion", ['dm_settings.json']),
        ("Configuración Trakt", ['trakt_settings.json']),
        ("Sección X (+18)", ['xxx_settings.json', 'xxx_favs.json', 'xxx_hist.json']),
        # La copia guarda las listas con su usuario y su clave, porque sin ellos no se pueden
        # restaurar; se avisa aquí, que es donde se puede desmarcar.
        ("Listas de canales (con las contraseñas que lleven)", '__iptv__'),
    ]

    available_groups = []
    available_labels = []
    for label, files in groups:
        if files == '__cache__':
            has = any(f.startswith("cat_cache_") and f.endswith(".json") for f in os.listdir(profile))
        elif files == '__iptv__':
            import iptv_lists
            has = bool(iptv_lists.backup_files())
        else:
            has = any(os.path.exists(os.path.join(profile, f)) for f in files)
        if has:
            available_groups.append((label, files))
            available_labels.append(label)

    if not available_labels:
        xbmcgui.Dialog().ok("Backup", "No se encontraron datos que respaldar.\n\nEl perfil del addon aún no tiene archivos guardados.")
        return

    selected = xbmcgui.Dialog().multiselect("¿Qué incluir en el backup?", available_labels,
                                            preselect=list(range(len(available_labels))))
    if not selected:
        return

    ts = time.strftime("%Y%m%d_%H%M%S")
    default_name = "EspaTV_backup_{0}.zip".format(ts)
    loc_opts = ["Guardar en carpeta del addon (por defecto)", "Elegir ubicación"]
    loc_sel = xbmcgui.Dialog().select("¿Dónde guardar?", loc_opts)
    if loc_sel < 0:
        return
    if loc_sel == 1:
        d = xbmcgui.Dialog().browse(3, 'Guardar Backup', 'files', '', False, False, '')
        if not d:
            return
        target = _en_carpeta(d, default_name, ".zip")
    else:
        bdir = _get_backup_dir()
        target = os.path.join(bdir, default_name)

    dp = xbmcgui.DialogProgress()
    dp.create("Backup", "Creando copia de seguridad...")
    try:
        added = []
        chosen = [available_groups[i] for i in selected]

        dp.update(20, "Empaquetando datos...")
        # Se empaqueta en memoria y se vuelca con xbmcvfs: así vale también si el
        # usuario eligió una carpeta de red (smb://, nfs://).
        buf = io.BytesIO()
        with zipfile.ZipFile(buf, 'w', zipfile.ZIP_DEFLATED) as zf:
            for label, files in chosen:
                if files == '__cache__':
                    for cf in os.listdir(profile):
                        if cf.startswith("cat_cache_") and cf.endswith(".json"):
                            cfp = os.path.join(profile, cf)
                            if os.path.exists(cfp):
                                zf.write(cfp, cf)
                                added.append(cf)
                elif files == '__iptv__':
                    # Las listas del usuario (JSON + lo pegado) entran en la copia; las copias
                    # descargadas de cada fuente no, porque se vuelven a bajar solas.
                    import iptv_lists
                    for fp, arcname in iptv_lists.backup_files():
                        zf.write(fp, arcname)
                        added.append(arcname)
                else:
                    for bf in files:
                        fp = os.path.join(profile, bf)
                        if os.path.exists(fp):
                            zf.write(fp, bf)
                            added.append(bf)

        dp.update(80, "Verificando integridad...")
        if not added:
            dp.close()
            xbmcgui.Dialog().ok("Backup", "No se guardó ningún archivo.")
            return

        datos_zip = buf.getvalue()
        with zipfile.ZipFile(io.BytesIO(datos_zip), 'r') as zf:
            bad = zf.testzip()
        if not _escribir_bytes(target, datos_zip):
            dp.close()
            xbmcgui.Dialog().ok("Error", "No se pudo guardar la copia en:\n{0}".format(target))
            return
        dp.close()

        size_kb = len(datos_zip) / 1024
        msg = "Backup creado correctamente.\n\n"
        msg += "Archivos: {0}\n".format(len(added))
        msg += "Tamaño: {0:.1f} KB\n\n".format(size_kb)
        msg += "Guardado en:\n{0}".format(target)
        if bad:
            msg += "\n\n[COLOR yellow]Advertencia: algunos archivos pueden estar dañados.[/COLOR]"
        xbmcgui.Dialog().ok("Backup Completo", msg)
        xbmc.executebuiltin("Container.Refresh")
    except (OSError, zipfile.BadZipFile) as e:
        dp.close()
        xbmcgui.Dialog().ok("Error", str(e))


def list_backups():
    h = int(sys.argv[1])
    bdir = _get_backup_dir()
    try:
        files = sorted([f for f in os.listdir(bdir) if f.endswith('.zip')], reverse=True)
    except OSError:
        files = []
    if not files:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay copias de seguridad[/COLOR]")
        li.setArt({'icon': 'DefaultIconInfo.png'})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
    for f in files:
        li = xbmcgui.ListItem(label=f)
        li.setArt({'icon': 'DefaultAddonRepository.png'})
        cm = [("Eliminar backup", "RunPlugin({0})".format(_u(action="delete_single_backup", file=f)))]
        li.addContextMenuItems(cm)
        xbmcplugin.addDirectoryItem(handle=h, url=_u(action="restore_backup_selective", file=f), listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(h)


def restore_selective(fname):
    source = os.path.join(_get_backup_dir(), fname)
    profile = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    file_labels = {
        'settings.json': 'Configuración General',
        'favorites.json': 'Favoritos',
        'search_history.json': 'Historial de Búsquedas DM',
        'yt_search_history.json': 'Historial de Búsquedas YouTube',
        'custom_categories.json': 'Categorías',
        'dm_settings.json': 'Ajustes Dailymotion',
        'watch_history.json': 'Historial de Visionado',
        'custom_iptv.json': 'Listas IPTV (antiguas)',
        'custom_iptv_lists.json': 'Listas de canales',
        'url_history.json': 'Historial de URLs',
        'url_bookmarks.json': 'Marcadores de URLs',
        'saved_playlists.json': 'Playlists DM Guardadas',
        'yt_playlists.json': 'Playlists YouTube Guardadas',
        'downloads_history.json': 'Historial de Descargas',
        'trakt_settings.json': 'Configuración Trakt',
        'xxx_settings.json': 'Ajustes de la Sección X (+18)',
        'xxx_favs.json': 'Favoritos de la Sección X',
        'xxx_hist.json': 'Historial de la Sección X',
    }
    # xxx_settings.json NO es "mergeable": lleva el hash del PIN y al fusionar se pisaría el
    # del perfil que importa, y con él el PIN que la persona tiene puesto.
    mergeable = ['favorites.json', 'search_history.json', 'yt_search_history.json',
                 'watch_history.json', 'url_history.json', 'url_bookmarks.json',
                 'saved_playlists.json', 'yt_playlists.json', 'downloads_history.json',
                 'xxx_favs.json', 'xxx_hist.json']
    try:
        with zipfile.ZipFile(source, 'r') as zf:
            available = zf.namelist()
        known = [f for f in available if f in file_labels]
        if 'custom_iptv_lists.json' in known and 'custom_iptv.json' in known:
            # Las antiguas pasaron a las nuevas al guardar la primera vez: ya están dentro.
            known.remove('custom_iptv.json')

        cache_files = [f for f in available if f.startswith("cat_cache_") and f.endswith(".json")]
        if cache_files:
            known.append('__cache__')
            file_labels['__cache__'] = 'Caché de Categorías ({0})'.format(len(cache_files))

        if not known:
            xbmcgui.Dialog().ok("EspaTV", "Este backup no contiene datos reconocidos."); return
        options = [file_labels.get(f, f) for f in known]
        selected = xbmcgui.Dialog().multiselect("¿Qué quieres restaurar?", options)
        if not selected: return
        files_to_restore = [known[i] for i in selected]
        fallos = []
        with zipfile.ZipFile(source, 'r') as zf:
            for fz in files_to_restore:
                try:
                    if fz in ('custom_iptv_lists.json', 'custom_iptv.json'):
                        # Pasan por la suite de listas: con las listas nuevas ya creadas, un
                        # custom_iptv.json copiado al perfil no se leería nunca.
                        import iptv_lists
                        iptv_lists.restore_from_backup(zf, fz)
                        continue
                    if fz == '__cache__':
                        for cf in cache_files:
                            _sustituir(zf, cf, profile)
                        continue
                    dest_path = os.path.join(profile, fz)
                    if fz in mergeable and os.path.exists(dest_path):
                        choice = xbmcgui.Dialog().select(file_labels[fz], ["Sustituir (borrar actual)", "Añadir (fusionar con actual)", "Omitir"])
                        if choice == 2 or choice == -1:
                            continue
                        if choice == 1:
                            # "Añadir": si la fusión falla, se deja el actual como estaba.
                            if not _fusionar_json(dest_path, zf, fz):
                                fallos.append(file_labels[fz])
                            continue
                    resolved = os.path.realpath(os.path.join(profile, fz))
                    if not resolved.startswith(os.path.realpath(profile)):
                        continue
                    _sustituir(zf, fz, profile)
                except (OSError, ValueError, zipfile.BadZipFile, KeyError) as e:
                    fallos.append(file_labels.get(fz, fz))
                    xbmc.log("[EspaTV/backups] Entrada {0} descartada: {1}".format(fz, e),
                             xbmc.LOGWARNING)
        if fallos:
            xbmcgui.Dialog().ok(
                "Restauración completada",
                "No se pudieron restaurar (se dejaron como estaban):\n" + ", ".join(fallos))
        else:
            xbmcgui.Dialog().notification("EspaTV", "Restauración completada",
                                          xbmcgui.NOTIFICATION_INFO)
    except (OSError, zipfile.BadZipFile, ValueError) as e:
        xbmcgui.Dialog().ok("Error", "Fallo en restauración: {0}".format(e))


def delete_single(fname):
    path = os.path.join(_get_backup_dir(), fname)
    if xbmcgui.Dialog().yesno("EspaTV", "¿Eliminar '{0}'?".format(fname)):
        try:
            os.remove(path)
            xbmcgui.Dialog().notification("EspaTV", "Backup eliminado", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
        except OSError as e:
            xbmcgui.Dialog().ok("Error", str(e))


def export_favorites_txt():
    favs = core_settings.get_favorites()
    if not favs:
        xbmcgui.Dialog().notification("EspaTV", "No hay favoritos para exportar", xbmcgui.NOTIFICATION_WARNING)
        return

    d = xbmcgui.Dialog().browse(3, 'Seleccionar carpeta destino', 'files')
    if not d: return

    dest = os.path.join(d, 'favoritos_EspaTV.txt')
    lineas = ["Favoritos EspaTV -- {0}".format(time.strftime('%d/%m/%Y %H:%M')),
              "Total: {0} favoritos".format(len(favs)),
              "=" * 50, ""]
    for fav in favs:
        lineas.append(fav.get('title', 'Sin titulo'))
        if fav.get('url'):
            lineas.append("  URL: {0}".format(fav['url']))
        if fav.get('action'):
            lineas.append("  Tipo: {0}".format(fav['action']))
        lineas.append("")
    datos = ("\n".join(lineas) + "\n").encode('utf-8')
    if _escribir_bytes(dest, datos):
        xbmcgui.Dialog().notification("EspaTV", "Exportados {0} favoritos a TXT".format(len(favs)))
    else:
        xbmcgui.Dialog().ok("Error", "No se pudo exportar a:\n{0}".format(dest))


def menu():
    h = int(sys.argv[1])
    _mp = os.path.join(xbmcaddon.Addon().getAddonInfo('path'), 'resources', 'media')

    def _ico(name, fallback='DefaultAddonService.png'):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    li = xbmcgui.ListItem(label="[COLOR limegreen][B]Crear Backup[/B][/COLOR]")
    li.setArt({'icon': _ico('bkp_crear.png')})
    li.setInfo('video', {'plot': "Crea una copia ZIP de tus datos.\nPuedes elegir qué incluir y dónde guardarla."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="create_backup_full"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Restaurar / Ver Backups")
    li.setArt({'icon': _ico('bkp_restaurar.png')})
    li.setInfo('video', {'plot': "Lista los backups creados. Permite restaurar selectivamente."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="list_backups"), listitem=li, isFolder=True)

    li = xbmcgui.ListItem(label="Importar Backup externo")
    li.setArt({'icon': _ico('bkp_importar.png')})
    li.setInfo('video', {'plot': "Importa un archivo ZIP desde cualquier ubicación.\nPuedes elegir qué datos restaurar.\nÚtil para backups compartidos o de otro dispositivo."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="import_backup"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="Exportar Favoritos a TXT")
    li.setArt({'icon': _ico('bkp_exportar_txt.png')})
    li.setInfo('video', {'plot': "Genera un archivo de texto plano con la lista de favoritos."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="export_favs_txt"), listitem=li, isFolder=False)

    xbmcplugin.endOfDirectory(h)
