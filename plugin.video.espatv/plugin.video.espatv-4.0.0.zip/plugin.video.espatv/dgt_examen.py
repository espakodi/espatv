# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Tests DGT: practicar el examen teórico del carnet de conducir en España.

Permite realizar tests con el banco oficial de preguntas de la revista de la DGT.
Las preguntas funcionan de forma autónoma en modo texto y admiten soporte fotográfico
opcional bajo demanda. El banco local viaja empaquetado en resources/data/dgt_examen.json
y puede actualizarse en el perfil del addon.
"""
import datetime
import html
import json
import os
import random
import re
import sys
import threading
import urllib.parse
import xml.etree.ElementTree as ET

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings
from _user_agents import UA_DESKTOP

_LOG_TAG = "[EspaTV-DGT-TESTS]"
_ADDON = xbmcaddon.Addon()
_ADDON_PATH = os.path.dirname(os.path.abspath(__file__))
_PROFILE_DIR = xbmcvfs.translatePath(_ADDON.getAddonInfo("profile"))
_MEDIA = os.path.join(_ADDON_PATH, "resources", "media")
_DATOS_FILE = os.path.join(_ADDON_PATH, "resources", "data", "dgt_examen.json")
_CACHE_FILE = os.path.join(_PROFILE_DIR, "dgt_examen.json")
_PERFIL_FILE = os.path.join(_PROFILE_DIR, "dgt_examen_perfil.json")
_TIMEOUT = 25

# El examen real del permiso B (común a todos): 30 preguntas, y se aprueba con
# hasta 3 fallos.
PREGUNTAS_EXAMEN = 30
MAX_FALLOS = 3

_LETRAS = ("A", "B", "C")

# La interface avisa en cada respuesta (verde/rojo) o no dice nada hasta el final.
MODO_APRENDIZAJE = "aprendizaje"
MODO_EXAMEN = "examen"

# Bloques para elegir por época. Cada uno lleva los prefijos de "fecha" (YYYY-MM)
# que le tocan, porque "2023-2024" no se puede buscar con un solo prefijo.
_EPOCAS = (
    ("2026 (más recientes)", ("2026",)),
    ("2025", ("2025",)),
    ("2023-2024", ("2023-", "2024-")),
    ("2020-2022", ("2020-", "2021-", "2022-")),
    ("2017-2019", ("2017-", "2018-", "2019-")),
    ("2014-2016", ("2014-", "2015-", "2016-")),
)


# Extracción desde la revista de la DGT para la opción «Actualizar preguntas».
_URL_TEST = "https://revista.dgt.es/es/test/Test-num-{0}.shtml"
_CABECERAS = {"User-Agent": UA_DESKTOP, "Accept-Language": "es-ES,es;q=0.9"}

_RE_NUMERO = re.compile(r"^\s*\d+\s*[.)]\s*")
_RE_BASURA = re.compile(r"<(script|style)\b[^>]*>.*?</\1\s*>", re.IGNORECASE | re.DOTALL)
_RE_TAGS = re.compile(r"<[^>]+>")
_RE_ARTICULO = re.compile(r'<article\s+class="test(?:\s+ultimo)?\s*">(.*?)</article>', re.DOTALL)
_RE_PREGUNTA = re.compile(r'<h4\s+class="tit_not">(.*?)</h4>', re.DOTALL)
_RE_OPCION = re.compile(
    r'<span\s+class="opcion">\s*([A-Z])\.?\s*</span>\s*([^<]*?)\s*</li>', re.DOTALL
)
_RE_CORRECTA = re.compile(
    r"Respuesta\s+correcta</strong>\s*<span\s+class=\"opcion\">\s*([A-Z])\.?\s*</span>",
    re.IGNORECASE,
)
_RE_MES = re.compile(r'<h3\s+class="tit_general">([^<]*)</h3>')
_RE_IMG = re.compile(r'<img\s+src="([^"]+)"', re.IGNORECASE)

# Referencias a elementos visuales de la foto (señales de la imagen, colores concretos, etc.).
_DEPENDE_DE_IMAGEN = re.compile(
    r"(esta\s+(se|señ|senal|marca|marc)|estas\s+(se|señ|senal|marc)as?"
    r"|las\s+(se|señ|senal)es\s+del|(se|señ|senal)es\s+del\s+panel"
    r"|del\s+panel"
    r"|la\s+imag|en\s+la\s+imag|las\s+imag"
    r"|la\s+fotograf|en\s+la\s+foto|de\s+la\s+foto|a\s+la\s+fotograf"
    r"|lo\s+que\s+se\s+observ|se\s+observa\s+en|observa\s+(la|el|a)"
    r"|veh[íi]culo\s+que\s+se\s+(observ|ve)|veh[íi]culo\s+de\s+la\s+(foto|imagen)"
    r"|veh[íi]culo\s+(verde|blanco|rojo|gris|negro|azul|marr[óo]n|de\s+la\s+izquierda|de\s+la\s+derecha)"
    r"|la\s+escena|el\s+dibuj|la\s+ilustrac|la\s+ilustraci"
    r"|a\s+la\s+vista\s+de|a\s+partir\s+de\s+esta"
    r"|con\s+esta\s+se|representad|va\s+pintad|lleva\s+pintad|pintad[oa]\s+en"
    r"|estas\s+marcas\s+viales)",
    re.IGNORECASE,
)

# Rango publicado. Si la DGT cuelga más, se amplía aquí y en la herramienta.
_MIN_TEST = 224
_MAX_TEST = 278

# Formato del banco. El JSON del perfil solo se usa si su versión es igual o mayor:
# sin esto, una actualización que trae el banco nuevo quedaría clavada en el viejo que
# dejó «Actualizar preguntas» en el perfil, sin imágenes y sin las preguntas que las
# necesitan, hasta que alguien borrara el perfil a mano.
_VERSION_BANCO = 2


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log("{0} {1}".format(_LOG_TAG, msg), level)


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _ri_icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback


def _limpia(texto):
    t = _RE_TAGS.sub(" ", _RE_BASURA.sub(" ", texto or ""))
    t = html.unescape(t).replace("\xa0", " ")
    # Solo espacios por los lados. Antes se recortaba tambien ";:.,-" y se comia
    # el punto final de todas las opciones ("...velocidad muy reducida" en vez de
    # "...velocidad muy reducida."), que es texto de la DGT que no hay que tocar.
    return re.sub(r"\s+", " ", t).strip()


def _mes_a_iso(titulo):
    if not titulo:
        return ""
    t = titulo.lower()
    anio = re.search(r"(20\d{2}|19\d{2})", t)
    anio = anio.group(1) if anio else ""
    meses = (
        ("enero", "01"), ("febrero", "02"), ("marzo", "03"), ("abril", "04"),
        ("mayo", "05"), ("junio", "06"), ("julio", "07"), ("agosto", "08"),
        ("septiembre", "09"), ("setiembre", "09"), ("octubre", "10"),
        ("noviembre", "11"), ("diciembre", "12"),
    )
    for nombre, num in meses:
        if nombre in t:
            return "{0}-{1}".format(anio, num) if anio else num
    return anio


# Banco de preguntas
def _es_valida(pregunta):
    """Una pregunta sirve si se puede leer y tiene 3 opciones y una correcta."""
    if not isinstance(pregunta, dict):
        return False
    texto = pregunta.get("pregunta")
    opciones = pregunta.get("opciones")
    correcta = pregunta.get("correcta")
    if not isinstance(texto, str) or not texto.strip():
        return False
    if not isinstance(opciones, list) or len(opciones) != 3:
        return False
    if any(not isinstance(o, str) or not o.strip() for o in opciones):
        return False
    if not isinstance(correcta, int) or isinstance(correcta, bool) or correcta not in (0, 1, 2):
        return False
    # Marca de si hace falta la foto. Si no hay ruta de imagen, es imposible que
    # haga falta: se autocorrige en vez de dejar una pregunta que no se puede
    # responder en ningún caso.
    if pregunta.get("necesita_imagen") and not pregunta.get("img"):
        return False
    return True


def _lee_json(ruta):
    try:
        with open(ruta, "r", encoding="utf-8") as fh:
            return json.load(fh)
    except (OSError, ValueError):
        return None


def _cargar_banco():
    """Devuelve (info, preguntas).

    Manda el fichero del perfil (puesto por "Actualizar preguntas"), pero solo si su
    versión es igual o mayor que la de este addon. Si está roto o es más antiguo, se
    usa el que viene con el addon: un fichero roto o viejo nunca deja la sección
    vacía ni sin imágenes.
    """
    for ruta, etiqueta in ((_CACHE_FILE, "perfil"), (_DATOS_FILE, "addon")):
        dato = _lee_json(ruta)
        if not isinstance(dato, dict):
            if etiqueta == "perfil":
                continue
            return {}, []
        # El perfil manda solo si no es más antiguo que el incluido. Sin esto, una
        # actualización que trae el banco nuevo quedaría clavada en el viejo.
        version = dato.get("version", 0)
        if not isinstance(version, int) or isinstance(version, bool):
            version = 0
        if etiqueta == "perfil" and version < _VERSION_BANCO:
            _log("Banco del perfil en versión {0}, se usa el incluido ({1})".format(
                version, _VERSION_BANCO))
            continue
        preguntas = [p for p in (dato.get("preguntas") or []) if _es_valida(p)]
        if not preguntas:
            if etiqueta == "perfil":
                continue
            return {}, []
        info = {
            "fuente": dato.get("fuente", "DGT · Revista Tráfico y Seguridad Vial"),
            "fuente_url": dato.get("fuente_url", "https://revista.dgt.es/es/test/"),
            "descargado": dato.get("descargado", ""),
            "version": version,
            "total": len(preguntas),
            "origen": etiqueta,
        }
        return info, preguntas
    _log("No hay banco de preguntas utilizable", xbmc.LOGERROR)
    return {}, []


def _filtra_por_epoca(preguntas, prefijos):
    """prefijos: tupla de prefijos de fecha (o None para no filtrar)."""
    if not prefijos:
        return list(preguntas)
    return [p for p in preguntas
            if str(p.get("fecha", "")).startswith(tuple(prefijos))]


def _imagenes_permitidas():
    """La descarga de imágenes, que es el permiso para usarlas.

    Apagado de serie. Con él apagado, las preguntas que no se pueden responder sin la
    foto se quedan fuera de los tests: presentarlas sería imposible acertarlas.
    """
    try:
        return _ADDON.getSetting("dgt_imagenes") == "true"
    except Exception:
        return False


def _modo():
    """El modo del test: aprender o examinarse.

    No se pregunta cada vez: queda recordado y se cambia desde el menú de la sección
    con una pulsación.
    """
    try:
        valor = (_ADDON.getSetting("dgt_modo") or "").strip().lower()
    except Exception:
        return MODO_APRENDIZAJE
    return MODO_EXAMEN if valor in ("examen", "1") else MODO_APRENDIZAJE


def dgt_test_modo():
    """Alterna el modo y lo deja guardado para los siguientes tests."""
    h = _handle()
    actual = _modo()
    nuevo = MODO_EXAMEN if actual == MODO_APRENDIZAJE else MODO_APRENDIZAJE
    try:
        # settings.xml define labelenum: values="Corregir al momento|Examen"
        _ADDON.setSetting("dgt_modo", "Examen" if nuevo == MODO_EXAMEN else "Corregir al momento")
    except Exception as exc:
        _log("No se pudo guardar el modo: {0}".format(exc), xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("EspaTV", "No se pudo cambiar el modo",
                                      xbmcgui.NOTIFICATION_WARNING, 2500)
        _fin(h, succeeded=False)
        return
    xbmcgui.Dialog().notification(
        "EspaTV",
        "Modo: {0}".format("Examen" if nuevo == MODO_EXAMEN else "Corregir al momento"),
        xbmcgui.NOTIFICATION_INFO, 2000)
    xbmc.executebuiltin("Container.Update({0},replace)".format(_u(action="dgt_examen_menu")))
    _fin(h, succeeded=False)


def dgt_test_imagenes_toggle():
    """Activa o desactiva las fotos, de un toque y desde la propia sección.

    El ajuste existe tambien en los ajustes de Kodi del addon («Tests DGT»), pero
    llegar hasta ahi son tres niveles. El addon ya hace esto con otros ajustes (ver
    «Al abrir EspaTV» en Opciones → Avanzado, que dice «lo mismo esta en los ajustes»),
    asi que aqui va igual: un boton al lado y el ajuste detras para quien lo busque.

    Ojo con el nombre: NO se llama `dgt_test_imagenes`. Esa es la que se baja TODAS
    las fotos de golpe, y tener las dos con el mismo nombre hacia que ganara la
    última definida y el botón de aquí hiciera una descarga de 71 MB sin avisar.
    """
    h = _handle()
    activas = _imagenes_permitidas()
    nuevo = "false" if activas else "true"
    try:
        _ADDON.setSetting("dgt_imagenes", nuevo)
    except Exception as exc:
        _log("No se pudo guardar el ajuste de imagenes: {0}".format(exc), xbmc.LOGWARNING)
        xbmcgui.Dialog().notification("EspaTV", "No se pudo cambiar el ajuste",
                                      xbmcgui.NOTIFICATION_WARNING, 2500)
        _fin(h, succeeded=False)
        return

    if activas:
        xbmcgui.Dialog().ok(
            "Imágenes desactivadas",
            "Las fotos ya no se muestran ni se descargan.\n\n"
            "Las {0} preguntas que no se pueden responder sin foto vuelven a quedarse "
            "fuera de los tests. Las que ya hayas descargado se quedan en el perfil, "
            "así que si las reactivas no hay que bajarlas de nuevo.".format(_n_necesitan_foto()))
    else:
        xbmcgui.Dialog().ok(
            "Imágenes activadas",
            "A partir de ahora, cada vez que una pregunta tenga foto se baja sola la "
            "primera vez que la ves y se guarda en el perfil del addon.\n\n"
            "No hace falta que te las bajes todas: un test de 30 preguntas baja unos "
            "3 MB. Si prefieres tenerlas todas de golpe, usa «Descargar imágenes».\n\n"
            "Además entran en los tests las {0} preguntas que no se pueden responder "
            "sin foto.".format(_n_necesitan_foto()))
    xbmc.executebuiltin("Container.Update({0},replace)".format(_u(action="dgt_examen_menu")))
    _fin(h, succeeded=False)


def _n_necesitan_foto():
    """Cuántas preguntas hay ahora mismo marcadas como que necesitan foto."""
    _info, preguntas = _cargar_banco()
    return sum(1 for p in preguntas if p.get("necesita_imagen"))


def _peso_imagenes():
    """Cuántas fotos hay descargadas y cuánto ocupan. Devuelve (n, bytes)."""
    carpeta = os.path.join(_PROFILE_DIR, _DIR_IMAGENES)
    n = 0
    total = 0
    try:
        for nombre in os.listdir(carpeta):
            ruta = os.path.join(carpeta, nombre)
            if os.path.isfile(ruta):
                n += 1
                total += os.path.getsize(ruta)
    except OSError:
        pass
    return n, total


def _fmt_peso(b):
    """El tamaño en KB o MB, para las etiquetas."""
    if b >= 1024 * 1024:
        return "{0:.1f} MB".format(b / 1024.0 / 1024.0)
    return "{0:.0f} KB".format(b / 1024.0)


def dgt_test_borrar_imagenes():
    """Borra las fotos descargadas para recuperar el espacio.

    Borra FICHERO A FICHERO, nombrados uno a uno con su ruta absoluta, y solo dentro de
    la carpeta que crea el addon. Nada de comodines ni de borrar la carpeta a lo bruto:
    si alguna vez hubiera algo ahí dentro que no fuera nuestro, no se lo lleva por
    delante. La carpeta se quita al final, y solo si ha quedado vacía.

    No se toca ni el banco de preguntas, ni el progreso, ni las falladas: eso vive en
    otros ficheros del perfil. Y si las imágenes están activadas, se volverán a bajar
    solas cuando hagan falta.
    """
    h = _handle()
    n, total = _peso_imagenes()
    if n == 0:
        xbmcgui.Dialog().ok("Imágenes descargadas",
                            "No hay ninguna foto descargada.\n\nNada que borrar.")
        _fin(h, succeeded=False)
        return

    if not xbmcgui.Dialog().yesno(
            "Borrar imágenes descargadas",
            "Se van a borrar las [B]{0}[/B] fotos descargadas ({1}).\n\n"
            "No se toca nada más: ni el banco de preguntas, ni tu progreso, ni las "
            "preguntas que tienes pendientes de repasar.\n\n"
            "Si las imágenes están activadas, se volverán a bajar solas cuando haga "
            "falta.".format(n, _fmt_peso(total))):
        _fin(h, succeeded=False)
        return

    carpeta = os.path.join(_PROFILE_DIR, _DIR_IMAGENES)
    liberado = 0
    borradas = 0
    try:
        nombres = [f for f in os.listdir(carpeta)
                   if os.path.isfile(os.path.join(carpeta, f))]
    except OSError as exc:
        _log("No se pudo leer {0}: {1}".format(carpeta, exc), xbmc.LOGWARNING)
        nombres = []

    for nombre in nombres:
        ruta = os.path.join(carpeta, nombre)
        try:
            peso = os.path.getsize(ruta)
            os.remove(ruta)
            liberado += peso
            borradas += 1
        except OSError as exc:
            _log("No se pudo borrar {0}: {1}".format(nombre, exc), xbmc.LOGWARNING)

    # La carpeta, solo si se ha quedado vacía.
    try:
        if not os.listdir(carpeta):
            os.rmdir(carpeta)
    except OSError:
        pass

    if borradas:
        xbmcgui.Dialog().notification(
            "EspaTV", "Borradas {0} fotos, {1} liberados".format(borradas, _fmt_peso(liberado)),
            xbmcgui.NOTIFICATION_INFO, 3000)
    else:
        xbmcgui.Dialog().ok("Imágenes descargadas",
                            "No se pudo borrar ninguna. Mira el log si sigue pasando.")
    xbmc.executebuiltin("Container.Update({0},replace)".format(_u(action="dgt_examen_menu")))
    _fin(h, succeeded=False)


def _preguntas_usables(preguntas):
    """Las que se pueden contestar con lo que se va a mostrar.

    Si las imágenes están apagadas, se caen las `necesita_imagen`. Encendidas, se
    quedan todas: al abrir la ventana se comprueba que la imagen de esa pregunta en
    concreto esté descargada, y si no lo está se salta con un aviso.
    """
    if _imagenes_permitidas():
        return list(preguntas)
    return [p for p in preguntas if not p.get("necesita_imagen")]


# Progreso y estadísticas
def _leer_perfil():
    dato = _lee_json(_PERFIL_FILE)
    if not isinstance(dato, dict):
        return {"tests": 0, "aciertos": 0, "fallos": 0, "falladas": []}
    falladas = dato.get("falladas")
    if not isinstance(falladas, list):
        falladas = []
    return {
        "tests": dato.get("tests", 0) if isinstance(dato.get("tests"), int) else 0,
        "aciertos": dato.get("aciertos", 0) if isinstance(dato.get("aciertos"), int) else 0,
        "fallos": dato.get("fallos", 0) if isinstance(dato.get("fallos"), int) else 0,
        "falladas": [p for p in falladas if _es_valida(p)],
    }


def _guardar_perfil(perfil):
    try:
        os.makedirs(_PROFILE_DIR, exist_ok=True)
        return core_settings.atomic_write_json(_PERFIL_FILE, perfil, ensure_ascii=False)
    except OSError as exc:
        _log("No se pudo guardar el perfil: {0}".format(exc), xbmc.LOGWARNING)
        return False


# Menú
def _fin(h, **kw):
    """Cierra el directorio, pero solo si hay uno que cerrar.

    Los botones que lanzan un diálogo van con isFolder=False (handle -1).
    Llamar a endOfDirectory con -1 no aplica.

    Pero "Test de examen" también se alcanza desde "Elegir época", que SÍ es
    carpeta, y en ese caso hay que cerrarla. Por eso se mira el handle en vez de
    no llamarla nunca: es el mismo código para los dos caminos.
    """
    if isinstance(h, int) and h >= 0:
        xbmcplugin.endOfDirectory(h, **kw)


def _handle():
    """El handle de esta llamada, o -1 si no viene o no es un número.

    Había siete sitios con `int(sys.argv[1])` a pelo: si `argv[1]` falta o trae basura,
    revienta con IndexError/ValueError antes de pintar nada. Con handle -1 no se pinta,
    que es justo lo que se quiere para los botones de script.
    """
    try:
        return int(sys.argv[1])
    except (IndexError, TypeError, ValueError):
        return -1


def dgt_examen_menu():
    # El punto verde de lo nuevo se apaga aquí, al entrar (ver ui_utils.punto/visto y
    # default._NUEVO_PORT), como hacen live_tv_menu y nombres.menu con el suyo.
    import ui_utils
    ui_utils.visto('dgt_examen')
    h = _handle()
    info, preguntas = _cargar_banco()

    if not preguntas:
        li = xbmcgui.ListItem(
            label="[COLOR red]No hay banco de preguntas disponible[/COLOR]"
        )
        li.setProperty("IsPlayable", "false")
        li.setInfo("video", {
            "plot": ("No se encuentra el banco de preguntas de la DGT que viene con el addon.\n"
                     "Reinstala EspaTV para recuperarlo.")
        })
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        _fin(h)
        return

    perfil = _leer_perfil()
    total = len(preguntas)
    usables = _preguntas_usables(preguntas)
    con_imagen = total - len(usables)
    origen = "del addon" if info["origen"] == "addon" else "actualizadas desde la DGT"
    when = info["descargado"] or "sin fecha"

    li = xbmcgui.ListItem(
        label="[COLOR gold][B]Test de examen[/B][/COLOR]  [COLOR limegreen]({0} preguntas)[/COLOR]".format(
            min(PREGUNTAS_EXAMEN, len(usables)))
    )
    li.setArt({"icon": _ri_icon("dgt_hacer_test.png")})
    li.setInfo("video", {
        "title": "Test de examen",
        "plot": ("Examen teórico del permiso B: {0} preguntas al azar "
                 "con un máximo de {1} fallos permitidos.\n\n"
                 "Banco: {2} preguntas registradas, {3} disponibles ahora ({4}).\n"
                 "Fecha del banco: {5}.{6}".format(
                     min(PREGUNTAS_EXAMEN, len(usables)), MAX_FALLOS, total,
                     len(usables), origen, when,
                     "\n\nHay {0} preguntas que necesitan una foto para responderse y "
                     "están fuera hasta activar las imágenes en Ajustes.".format(
                         con_imagen) if con_imagen else "")),
    })
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="dgt_test_examen", filtro=""), listitem=li, isFolder=False
    )

    li = xbmcgui.ListItem(label="[B]Elegir época[/B]")
    li.setArt({"icon": _ri_icon("dgt_epocas.png")})
    li.setInfo("video", {
        "title": "Elegir época",
        "plot": "Tests de la DGT organizados por años.",
    })
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="dgt_test_epocas"), listitem=li, isFolder=True
    )

    n_falladas = len(perfil["falladas"])
    li = xbmcgui.ListItem(
        label=("[B]Repasar falladas[/B]  [COLOR tomato]({0})[/COLOR]"
               .format(n_falladas)) if n_falladas
               else "[B]Repasar falladas[/B]  [COLOR gold](ninguna)[/COLOR]"
    )
    li.setArt({"icon": _ri_icon("dgt_repasar.png")})
    li.setInfo("video", {
        "title": "Repasar falladas",
        "plot": ("Las preguntas que has fallado vuelven aquí hasta que las aciertes.\n\n"
                 "Pendientes: {0}.".format(n_falladas)),
    })
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="dgt_test_repasar"), listitem=li, isFolder=False
    )

    hechos = perfil["tests"]
    tot_resp = perfil["aciertos"] + perfil["fallos"]
    pct = (perfil["aciertos"] * 100.0 / tot_resp) if tot_resp else 0.0
    li = xbmcgui.ListItem(
        label="[B]Mis estadísticas[/B]" + (
            "  [COLOR limegreen]({0} %)[/COLOR]".format(int(round(pct))) if tot_resp else "")
    )
    li.setArt({"icon": _ri_icon("dgt_stats.png")})
    li.setInfo("video", {
        "title": "Mis estadísticas",
        "plot": ("Tests completados: {0}\nRespuestas acertadas: {1}\nRespuestas falladas: {2}\n"
                 "Acierto: {3:.0f} %\nFalladas pendientes: {4}".format(
                     hechos, perfil["aciertos"], perfil["fallos"], pct, n_falladas)),
    })
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="dgt_test_stats"), listitem=li, isFolder=False
    )

    # Las fotos, solo con el permiso activado: sin él el botón no sale.
    if _imagenes_permitidas():
        n_img = len([p for p in preguntas if p.get("img")
                     and not _imagen_local(p["img"])])
        li = xbmcgui.ListItem(
            label=("[COLOR aqua][ Descargar imágenes ][/COLOR]"
                   + ("  [COLOR gold]({0} sin bajar)[/COLOR]".format(n_img) if n_img else ""))
        )
        li.setArt({"icon": _ri_icon("dgt_imagenes_descargar.png", "descargas.png")})
        li.setInfo("video", {
            "title": "Descargar imágenes",
            "plot": ("Descarga el paquete completo de fotos de las preguntas (71 MB) "
                     "para disponer de ellas sin conexión a internet.\n\n"
                     "Durante el test cada foto se descarga automáticamente al mostrarse."),
        })
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="dgt_test_imagenes"), listitem=li, isFolder=False
        )

    # Borrarlas, para recuperar el espacio. Siempre visible: la etiqueta dice si hay
    # algo que borrar, así que se ve que la opción existe aunque no haga falta.
    n_fotos, peso_fotos = _peso_imagenes()
    li = xbmcgui.ListItem(
        label=("[COLOR orange][B]Borrar imágenes descargadas[/B][/COLOR]"
               "  [COLOR limegreen]({0}, {1})[/COLOR]".format(n_fotos, _fmt_peso(peso_fotos))
               if n_fotos else
               "[COLOR orange][B]Borrar imágenes descargadas[/B][/COLOR]"
               "  [COLOR gold](ninguna)[/COLOR]")
    )
    li.setArt({"icon": _ri_icon("dgt_imagenes_borrar.png", "DefaultAddonNone.png")})
    li.setInfo("video", {
        "title": "Borrar imágenes descargadas",
        "plot": ("Libera el espacio en disco de las fotos descargadas ({0} fotos, {1}).\n\n"
                 "El banco de preguntas, las estadísticas y las preguntas falladas "
                 "se conservan intactos.".format(n_fotos, _fmt_peso(peso_fotos))),
    })
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="dgt_test_borrar_imagenes"), listitem=li, isFolder=False
    )

    # Las fotos, conmutable desde aquí. El ajuste existe también en los ajustes de
    # Kodi del addon («Tests DGT»), pero llegar hasta ahí son tres niveles y no se
    # encontraba: el addon ya hace esto con otros ajustes (ver «Al abrir EspaTV» en
    # Opciones → Avanzado, que dice «lo mismo está en los ajustes»), así que aquí igual.
    imagenes = _imagenes_permitidas()
    li = xbmcgui.ListItem(
        label=("[B]Imágenes:[/B] [COLOR limegreen]activadas[/COLOR]" if imagenes
               else "[B]Imágenes:[/B] [COLOR gold]desactivadas[/COLOR]")
    )
    li.setArt({"icon": _ri_icon("dgt_imagenes.png")})
    li.setInfo("video", {
        "title": "Imágenes de la DGT",
        "plot": ("Estado actual: {0}.\n\n".format(
                     "activadas (se muestran y descargan automáticamente)" if imagenes
                     else "desactivadas") +
                 ("Cada foto se descarga al visualizar su pregunta y se conserva en el perfil.\n"
                  "Selecciona esta opción para desactivarlas." if imagenes else
                  "Al activarlas se visualizan las imágenes y entran en los tests "
                  "las {0} preguntas que llevan foto y no se pueden responder sin ella.\n"
                  "Se descargan individualmente según se necesitan.\n"
                  "Selecciona esta opción para activarlas.".format(con_imagen))),
    })
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="dgt_test_imagenes_toggle"), listitem=li, isFolder=False
    )

    # El modo, conmutable desde aquí: una pulsación en vez de haberlo de ir a buscar a
    # Ajustes. La etiqueta dice en cuál se está, para que nunca haya duda.
    modo = _modo()
    li = xbmcgui.ListItem(
        label=("[B]Modo:[/B] [COLOR limegreen]corregir al momento[/COLOR]"
               if modo == MODO_APRENDIZAJE
               else "[B]Modo:[/B] [COLOR limegreen]examen[/COLOR]")
    )
    li.setArt({"icon": _ri_icon("dgt_modo.png")})
    li.setInfo("video", {
        "title": "Modo del test",
        "plot": ("Modo actual: {0}.\n\n".format(modo) +
                 ("Corrección inmediata en cada pregunta (verde o rojo) con la solución visible.\n"
                  "Selecciona para alternar a modo examen (corrección al finalizar)."
                  if modo == MODO_APRENDIZAJE else
                  "Evaluación continua sin corrección hasta entregar el examen.\n"
                  "Selecciona para alternar a modo aprendizaje (corrección pregunta a pregunta).")),
    })
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="dgt_test_modo"), listitem=li, isFolder=False
    )

    li = xbmcgui.ListItem(label="[COLOR aqua][ Actualizar preguntas ][/COLOR]")
    li.setArt({"icon": _ri_icon("adv_refrescar.png")})
    li.setInfo("video", {
        "title": "Actualizar preguntas",
        "plot": ("Descarga los tests más recientes de la revista oficial de la DGT "
                 "y actualiza el banco guardado en el perfil del addon."),
    })
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="dgt_test_refresh"), listitem=li, isFolder=False
    )

    li = xbmcgui.ListItem(label="[COLOR grey][ Fuente de las preguntas ][/COLOR]")
    li.setArt({"icon": _ri_icon("cat_boe.png")})
    li.setInfo("video", {
        "title": "Fuente de las preguntas",
        "plot": ("{0}\n{1}\n\nPreguntas en el banco: {2}\nFecha del banco: {3}".format(
            info["fuente"], info["fuente_url"], total, when)),
    })
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="dgt_test_fuente"), listitem=li, isFolder=False
    )

    xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.remember_list_position())


def dgt_test_epocas():
    h = _handle()
    _info, preguntas = _cargar_banco()
    if not preguntas:
        xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    for etiqueta, prefijos in _EPOCAS:
        n = len(_filtra_por_epoca(preguntas, prefijos))
        if not n:
            continue
        li = xbmcgui.ListItem(
            label="[B]{0}[/B]  [COLOR gray]({1} preguntas)[/COLOR]".format(etiqueta, n)
        )
        li.setArt({"icon": _ri_icon("dgt_examen.png")})
        li.setInfo("video", {"title": etiqueta, "plot": "{0} preguntas de {1}.".format(n, etiqueta)})
        li.setProperty("IsPlayable", "false")
        xbmcplugin.addDirectoryItem(
            handle=h, url=_u(action="dgt_test_examen", filtro=etiqueta),
            listitem=li, isFolder=False
        )

    li = xbmcgui.ListItem(label="[B]Todo el banco[/B]  [COLOR gray]({0})[/COLOR]".format(len(preguntas)))
    li.setArt({"icon": _ri_icon("dgt_examen.png")})
    li.setInfo("video", {"title": "Todo el banco", "plot": "Preguntas de todos los años."})
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(
        handle=h, url=_u(action="dgt_test_examen", filtro=""), listitem=li, isFolder=False
    )

    xbmcplugin.endOfDirectory(h, cacheToDisc=core_settings.remember_list_position())


# El test
def _texto_pregunta(pregunta):
    lineas = [pregunta["pregunta"], ""]
    for idx, opcion in enumerate(pregunta["opciones"]):
        lineas.append("{0})  {1}".format(_LETRAS[idx], opcion))
    return "\n".join(lineas)


def _elegir(preguntas, cuantas):
    """Elige sin repetir. Si hay pocas, las da todas (en otro orden)."""
    if len(preguntas) <= cuantas:
        return random.sample(preguntas, len(preguntas))
    return random.sample(preguntas, cuantas)


def _prefijos_de_etiqueta(etiqueta):
    """La etiqueta que viaja en la URL, de vuelta a sus prefijos de fecha."""
    for nombre, prefijos in _EPOCAS:
        if nombre == etiqueta:
            return prefijos
    return ()


def dgt_test_examen(filtro=""):
    h = _handle()
    _info, preguntas = _cargar_banco()
    if not preguntas:
        _fin(h, succeeded=False)
        return

    prefijos = _prefijos_de_etiqueta(filtro) if filtro else ()
    if prefijos:
        preguntas = _filtra_por_epoca(preguntas, prefijos)

    # Con las imágenes apagadas se caen las que no se pueden responder sin foto.
    preguntas = _preguntas_usables(preguntas)
    if not preguntas:
        xbmcgui.Dialog().notification(
            "EspaTV", "No hay preguntas utilizables en esa época",
            xbmcgui.NOTIFICATION_INFO, 2500)
        _fin(h, succeeded=False)
        return

    elegidas = _elegir(preguntas, PREGUNTAS_EXAMEN)
    _examen(h, elegidas, "Test de examen")


def dgt_test_repasar():
    h = _handle()
    perfil = _leer_perfil()
    pendientes = _preguntas_usables(perfil["falladas"])
    if not pendientes:
        if perfil["falladas"]:
            # Hay falladas guardadas, pero ninguna se puede responder con las
            # imágenes apagadas: que lo sepa, no que se quede con la pantalla vacía.
            xbmcgui.Dialog().ok(
                "Repasar falladas",
                "Tienes preguntas pendientes, pero hacen falta las imágenes para "
                "responderlas y están desactivadas.\n\n"
                "Actívalas en Ajustes → Tests DGT para poder repasarlas."
            )
        else:
            xbmcgui.Dialog().ok(
                "Repasar falladas",
                "No tienes ninguna pregunta pendiente.\n\n"
                "Cuando falles una en un test, se queda guardada aquí hasta que la aciertes."
            )
        _fin(h, succeeded=False)
        return

    elegidas = _elegir(pendientes, PREGUNTAS_EXAMEN)
    _examen(h, elegidas, "Repasar falladas")


def _examen(h, preguntas, titulo):
    """Pasa las preguntas: ventana custom si se puede, diálogos si no.

    El orden es el importante. NO es un `try/except` alrededor de `doModal()`: si
    `onInit` revienta, Kodi lo registra y no lo propaga a Python, y el modal se queda
    en blanco sin que el código pueda hacer nada. Por eso se comprueba **antes** de
    abrir (`_ventana_disponible`), y si aún así la ventana se muere sin decir nada
    (`resultado is None`), se termina con los diálogos desde donde se quedó.
    """
    if _ventana_disponible():
        _examen_ventana(h, preguntas, titulo)
    else:
        _examen_dialogos(h, preguntas, titulo)


def _examen_dialogos(h, preguntas, titulo, modo=None):
    """El flujo de siempre: dos diálogos por pregunta en modo aprendizaje, o continuo en modo examen.

    Se queda como respaldo de la ventana custom y como camino para cuando la ventana
    no se puede abrir.
    """
    if modo is None:
        modo = _modo()
    dialog = xbmcgui.Dialog()
    total = len(preguntas)
    aciertos = 0
    fallos = 0
    errores = []
    acertadas = []
    cortado = False

    for num, pregunta in enumerate(preguntas, 1):
        encabezado = ("{0} · {1} de {2}".format(titulo, num, total) if modo == MODO_EXAMEN
                      else "{0} · {1} de {2} (Aciertos: {3}, Fallos: {4})".format(
                          titulo, num, total, aciertos, fallos))
        dialog.ok(encabezado, _texto_pregunta(pregunta))

        opciones = ["{0})  {1}".format(_LETRAS[i], pregunta["opciones"][i])
                    for i in range(3)]
        sel = dialog.select("Tu respuesta", opciones)
        if sel == -1:
            cortado = True
            break

        if sel == pregunta["correcta"]:
            aciertos += 1
            acertadas.append(pregunta)
        else:
            fallos += 1
            errores.append(pregunta)
            if modo == MODO_APRENDIZAJE:
                correcta = pregunta["correcta"]
                dialog.ok(
                    "Incorrecto",
                    "La respuesta correcta es:\n\n"
                    "{0})  {1}".format(_LETRAS[correcta], pregunta["opciones"][correcta])
                )

    _guardar_resultado(preguntas, errores, cortado, acertadas=acertadas)

    if cortado:
        dialog.notification("EspaTV", "Test cancelado, progreso guardado",
                             xbmcgui.NOTIFICATION_INFO, 2500)
        _fin(h, succeeded=False)
        xbmc.executebuiltin("Container.Refresh")
        return

    _mostrar_resultado(dialog, titulo, aciertos, fallos, errores)
    _fin(h, cacheToDisc=core_settings.remember_list_position())
    xbmc.executebuiltin("Container.Refresh")


# Ventana personalizada
#: Los controles que la clase necesita. `_ventana_disponible()` los busca en el XML.
_IDS_VENTANA = {"100", "10", "30", "201", "202", "203", "210", "211", "220"}
_RUTA_SKIN = os.path.join("resources", "skins", "Default", "1080i", "dgt_test.xml")


def _ventana_disponible():
    """Si la ventana custom se puede abrir. Se comprueba ANTES de intentarlo.

    Un `try/except` alrededor de `doModal()` no serviría de nada: si `onInit`
    revienta, Kodi lo anota en el log y no lo propaga a Python, así que el modal
    quedaría en blanco y el código no se enteraría. Comprobando antes, un XML que no
    parsea o al que le falta un control cae al flujo de diálogos en vez de dejar la
    sección muerta.

    Y también es un test: se puede comprobar en la suite, sin Kodi.
    """
    ruta = os.path.join(_ADDON_PATH, *_RUTA_SKIN.split(os.sep))
    if not os.path.isfile(ruta):
        _log("No está {0}: se usan diálogos".format(_RUTA_SKIN), xbmc.LOGWARNING)
        return False
    try:
        with open(ruta, "r", encoding="utf-8") as fh:
            raiz = ET.fromstring(fh.read())
    except (ET.ParseError, OSError, UnicodeDecodeError) as exc:
        _log("dgt_test.xml no parsea ({0}): se usan diálogos".format(exc), xbmc.LOGWARNING)
        return False
    ids = {c.get("id") for c in raiz.iter("control") if c.get("id")}
    if not _IDS_VENTANA <= ids:
        _log("A dgt_test.xml le faltan controles: {0}".format(
            sorted(_IDS_VENTANA - ids)), xbmc.LOGWARNING)
        return False
    return True


class _VentanaTest(xbmcgui.WindowXMLDialog):
    """La pantalla del test: enunciado, foto y las tres opciones juntas.

    Los colores no se tocan desde Python. Cada opción lleva tres pastillas
    superpuestas (normal, verde, roja) y cada una tiene su `visible` en el XML sobre
    las propiedades `m_estado` / `m_correcta` / `m_elegida`. Es más XML, pero es
    determinista: no depende de que Kodi acepte un color por `$INFO`, que no es seguro.
    """

    def __init__(self, xml, ruta_addon, skin, res,
                 preguntas=None, modo=MODO_APRENDIZAJE, titulo="Test de examen"):
        super().__init__(xml, ruta_addon, skin, res)
        self._preguntas = list(preguntas or [])
        self._modo = modo
        self._titulo = titulo
        self._idx = 0
        self._respondida = False
        self._aciertos = 0
        self._fallos = 0
        self._errores = []
        self._acertadas = []
        self._closing = False
        # (aciertos, fallos, errores, completo). None mientras no se haya cerrado.
        self.resultado = None

    # -- pintar ------------------------------------------------------------
    def onInit(self):
        self._mostrar()
        self._lanzar_hilo_imagen()

    def _mostrar(self):
        p = self._preguntas[self._idx]
        if self._modo == MODO_EXAMEN:
            self.setProperty(
                "m_contador",
                "Pregunta {0} de {1}".format(self._idx + 1, len(self._preguntas)))
            self.setProperty("m_modo", "examen")
        else:
            self.setProperty(
                "m_contador",
                "Pregunta {0} de {1}  ·  Aciertos {2}  ·  Fallos {3}".format(
                    self._idx + 1, len(self._preguntas), self._aciertos, self._fallos))
            self.setProperty("m_modo", "aprendizaje")
        self.setProperty("m_pregunta", p["pregunta"])
        for i in range(3):
            self.setProperty("m_opcion_{0}".format(i), p["opciones"][i])
        self.setProperty("m_correcta", str(p["correcta"]))
        # Se limpia el estado: si no, la pregunta anterior seguiría marcada.
        self.setProperty("m_estado", "")
        self.setProperty("m_elegida", "")
        self.setProperty("m_bien", "")
        self.setProperty("m_mal", "")
        # La foto se quita en el hilo principal, que es donde es seguro tocar
        # propiedades; si no, se vería la de la pregunta anterior un instante.
        self.setProperty("m_imagen", "")
        self.setProperty(
            "m_ayuda",
            "Elige una opción con OK." if not self._respondida
            else "Pulsa Siguiente para continuar.")

    def _lanzar_hilo_imagen(self):
        """Baja la foto de la pregunta actual en segundo plano, si toca."""
        if not _imagenes_permitidas():
            return
        idx = self._idx
        img = self._preguntas[idx].get("img") or ""
        if not img:
            return
        threading.Thread(target=self._hilo_imagen, args=(idx, img),
                         daemon=True).start()

    def _hilo_imagen(self, idx, img):
        """Reglas de hilo, copiadas de pelis_grid.py.

        `setProperty()` SÍ es seguro desde un hilo; `getControl()` y
        `getListItem()` NO. Aquí solo se tocan propiedades, y todo va dentro de
        `try/except` porque la ventana puede cerrarse mientras se baja la foto.
        """
        monitor = xbmc.Monitor()
        ruta = _una_imagen(img)
        if self._closing or monitor.abortRequested() or self._idx != idx:
            return
        try:
            self.setProperty("m_imagen", ruta)
        except Exception as exc:
            xbmc.log("{0} foto sin ventana: {1}".format(_LOG_TAG, exc),
                     xbmc.LOGWARNING)

    # -- responder ---------------------------------------------------------
    def _responder(self, elegida):
        """Marca la respuesta. En modo aprendizaje, corrige al momento.

        La guarda está aquí y no solo en `onClick`: así, aunque algún día se llame a
        este método desde otro sitio, un doble toque en la cruceta no contará dos
        respuestas.
        """
        if self._respondida:
            return
        p = self._preguntas[self._idx]
        self._respondida = True
        self.setProperty("m_elegida", str(elegida))
        self.setProperty("m_ayuda", "Pulsa Siguiente para continuar.")

        if elegida == p["correcta"]:
            self._aciertos += 1
            self._acertadas.append(p)
            if self._modo == MODO_APRENDIZAJE:
                self.setProperty("m_estado", "respondida")
                # Sin símbolo raro: U+2713 no está en la fuente de Kodi y sale un
                # cuadrado vacío. El texto y el color bastan.
                self.setProperty("m_bien", "Correcto")
                self.setProperty("m_mal", "")
            else:
                self.setProperty("m_estado", "respondida_examen")
                self.setProperty("m_bien", "")
                self.setProperty("m_mal", "")
        else:
            self._fallos += 1
            self._errores.append(p)
            if self._modo == MODO_APRENDIZAJE:
                self.setProperty("m_estado", "respondida")
                self.setProperty(
                    "m_mal",
                    "La respuesta correcta es la {0})".format(
                        _LETRAS[p["correcta"]]))
                self.setProperty("m_bien", "")
            else:
                self.setProperty("m_estado", "respondida_examen")
                self.setProperty("m_bien", "")
                self.setProperty("m_mal", "")

        # El foco salta a Siguiente: se ve la corrección y se avanza con OK, sin
        # tener que buscar el botón.
        try:
            self.setFocus(220)
        except Exception:
            pass

    def _siguiente(self):
        self._idx += 1
        self._respondida = False
        if self._idx >= len(self._preguntas):
            self.resultado = (self._aciertos, self._fallos, self._errores, True)
            self._closing = True
            self.close()
            return
        self._mostrar()
        self._lanzar_hilo_imagen()

    # -- eventos -----------------------------------------------------------
    def onClick(self, controlId):
        if controlId == 100:
            self.resultado = (self._aciertos, self._fallos, self._errores, False)
            self._closing = True
            self.close()
        elif controlId in (201, 202, 203) and not self._respondida:
            self._responder(controlId - 201)
        elif controlId == 220 and self._respondida:
            self._siguiente()

    def onAction(self, action):
        aid = action.getId()
        if aid in (xbmcgui.ACTION_PREVIOUS_MENU, xbmcgui.ACTION_NAV_BACK):
            # Atrás guarda lo hecho hasta entonces, como el flujo de diálogos.
            self.resultado = (self._aciertos, self._fallos, self._errores, False)
            self._closing = True
            self.close()


def _examen_ventana(h, preguntas, titulo):
    win = _VentanaTest("dgt_test.xml", _ADDON_PATH, "Default", "1080i",
                       preguntas=preguntas, modo=_modo(), titulo=titulo)
    res = None
    idx = 0
    acertadas = []
    try:
        win.doModal()
        res = win.resultado
        idx = win._idx
        acertadas = list(win._acertadas)
    except Exception as exc:
        _log("La ventana del test falló ({0}): se usan diálogos".format(exc),
             xbmc.LOGERROR)
        res = None
    del win

    if res is None:
        # La ventana se cerró sin decir nada. No debería pasar (se comprueba antes),
        # pero si pasa, se termina con los diálogos desde donde se quedó.
        _log("La ventana se cerró sin resultado: se termina con diálogos",
             xbmc.LOGWARNING)
        _examen_dialogos(h, preguntas[min(idx, len(preguntas)):], titulo, modo=_modo())
        return

    aciertos, fallos, errores, completo = res
    _guardar_resultado(preguntas, errores, not completo, acertadas=acertadas)

    if not completo:
        xbmcgui.Dialog().notification("EspaTV", "Test cancelado, progreso guardado",
                                      xbmcgui.NOTIFICATION_INFO, 2500)
        _fin(h, succeeded=False)
        xbmc.executebuiltin("Container.Refresh")
        return

    _mostrar_resultado(xbmcgui.Dialog(), titulo, aciertos, fallos, errores)
    _fin(h, cacheToDisc=core_settings.remember_list_position())
    xbmc.executebuiltin("Container.Refresh")


def _clave(pregunta):
    return pregunta.get("id") or pregunta.get("pregunta") or ""


def _guardar_resultado(preguntas, errores, cortado, acertadas=None):
    """Suma al perfil lo de este test. Las falladas se acumulan y las acertadas se
    quitan de las pendientes: así "Repasar falladas" se vacía solo."""
    perfil = _leer_perfil()
    if not cortado:
        perfil["tests"] = perfil.get("tests", 0) + 1

    if acertadas is None:
        acertadas = [p for p in preguntas if _clave(p) not in {_clave(e) for e in errores}]

    perfil["aciertos"] = perfil.get("aciertos", 0) + len(acertadas)
    perfil["fallos"] = perfil.get("fallos", 0) + len(errores)

    pendientes = {_clave(p): p for p in perfil.get("falladas", []) if _clave(p)}
    for p in errores:
        c = _clave(p)
        if c:
            pendientes[c] = p
    for p in acertadas:
        c = _clave(p)
        if c:
            pendientes.pop(c, None)

    perfil["falladas"] = list(pendientes.values())
    _guardar_perfil(perfil)


def _mostrar_resultado(dialog, titulo, aciertos, fallos, errores):
    aprobado = fallos <= MAX_FALLOS
    lineas = [
        "Preguntas: {0}".format(aciertos + fallos),
        "Aciertos: {0}".format(aciertos),
        "Fallos: {0}".format(fallos),
        "",
        ("APTO, {0} fallos como máximo".format(MAX_FALLOS)) if aprobado
        else ("NO APTO, pasabas de {0} fallos".format(MAX_FALLOS)),
    ]
    if errores:
        lineas.append("")
        lineas.append("Preguntas falladas:")
        for p in errores[:10]:
            correcta = p["correcta"]
            lineas.append("· {0}".format(p["pregunta"]))
            lineas.append("   → {0})  {1}".format(_LETRAS[correcta], p["opciones"][correcta]))
        if len(errores) > 10:
            lineas.append("   … y {0} más".format(len(errores) - 10))
    dialog.ok(titulo + ", resultado", "\n".join(lineas))


def dgt_test_stats():
    h = _handle()
    perfil = _leer_perfil()
    dialog = xbmcgui.Dialog()
    tot = perfil["aciertos"] + perfil["fallos"]
    pct = (perfil["aciertos"] * 100.0 / tot) if tot else 0.0
    lineas = [
        "Tests terminados: {0}".format(perfil["tests"]),
        "Respuestas acertadas: {0}".format(perfil["aciertos"]),
        "Respuestas falladas: {0}".format(perfil["fallos"]),
        "Acierto: {0:.0f} %".format(pct),
        "Pendientes de repasar: {0}".format(len(perfil["falladas"])),
    ]
    dialog.ok("Mis estadísticas", "\n".join(lineas))
    _fin(h, succeeded=False)


def dgt_test_fuente():
    h = _handle()
    info, preguntas = _cargar_banco()
    dialog = xbmcgui.Dialog()
    dialog.ok(
        "Fuente de las preguntas",
        "{0}\n{1}\n\n"
        "Preguntas en el banco: {2}\n"
        "Fecha del banco: {3}\n"
        "Origen: {4}\n\n"
        "Las preguntas son de la DGT y se reproducen tal cual, sin modificar su "
        "enunciado ni sus respuestas.".format(
            info.get("fuente", "DGT"), info.get("fuente_url", ""),
            info.get("total", len(preguntas)), info.get("descargado", "—"),
            "banco incluido en el addon" if info.get("origen") == "addon"
            else "descargado desde la DGT")
    )
    _fin(h, succeeded=False)


def dgt_test_refresh():
    h = _handle()
    dialog = xbmcgui.Dialog()
    dialog.notification("EspaTV", "Descargando tests de la DGT…",
                        xbmcgui.NOTIFICATION_INFO, 2500)

    nuevas, motivo, con_imagen = _descargar_banco(_MIN_TEST, _MAX_TEST, dialog)

    if motivo == CANCELADA:
        dialog.ok(
            "Descarga cancelada",
            "No se ha cambiado nada.\n\n"
            "Las preguntas que ya están en el addon siguen ahí, y puedes volver a "
            "intentarlo cuando quieras."
        )
        _fin(h, succeeded=False)
        return

    if motivo == VACIA:
        dialog.ok(
            "No se pudo actualizar",
            "La DGT no ha devuelto preguntas válidas.\n\n"
            "El banco que viene con el addon sigue intacto, así que puedes seguir "
            "haciendo tests."
        )
        _fin(h, succeeded=False)
        return

    guardado = core_settings.atomic_write_json(_CACHE_FILE, {
        "fuente": "DGT · Revista Tráfico y Seguridad Vial",
        "fuente_url": "https://revista.dgt.es/es/test/",
        "descargado": datetime.date.today().isoformat(),
        "rango_tests": [_MIN_TEST, _MAX_TEST],
        "version": _VERSION_BANCO,
        "preguntas": nuevas,
    }, ensure_ascii=False)

    if not guardado:
        dialog.ok("No se pudo guardar", "La descarga fue bien, pero no se pudo escribir "
                                        "en el perfil del addon.")
        _fin(h, succeeded=False)
        return

    dialog.ok(
        "Preguntas actualizadas",
        "Descargados {0} tests.\n\n"
        "Preguntas nuevas: {1}\n"
        "De ellas, {2} necesitan una foto para responderse.\n\n"
        "Se guardan en el perfil del addon y mandan sobre el banco incluido.".format(
            _MAX_TEST - _MIN_TEST + 1, len(nuevas), con_imagen)
    )
    xbmc.executebuiltin("Container.Update({0},replace)".format(_u(action="dgt_examen_menu")))
    _fin(h, succeeded=False)


# Descarga para actualización de preguntas
def _get(url):
    try:
        r = requests.get(url, headers=_CABECERAS, timeout=_TIMEOUT)
        if r.status_code == 404:
            return None
        r.raise_for_status()
        return r.text
    except requests.RequestException as exc:
        _log("Fallo descargando {0}: {1}".format(url, type(exc).__name__), xbmc.LOGWARNING)
        return None


def _parse_test(pagina, numero):
    """Extrae las preguntas de un test de la revista de la DGT."""
    if not pagina or '<article class="test' not in pagina:
        return []
    fecha = _mes_a_iso(_RE_MES.search(pagina).group(1) if _RE_MES.search(pagina) else "")
    preguntas = []
    for bloque in _RE_ARTICULO.findall(pagina):
        img = ""
        m_img = _RE_IMG.search(bloque)
        if m_img:
            # La ruta se guarda tal cual: el patrón cambia por época y no se puede
            # deducir; las rutas no contienen espacios ni caracteres no-ASCII.
            img = m_img.group(1).strip()

        m_preg = _RE_PREGUNTA.search(bloque)
        if not m_preg:
            continue
        enunciado = _limpia(_RE_NUMERO.sub("", _limpia(m_preg.group(1))))
        if not enunciado:
            continue
        opciones = [_limpia(t) for _letra, t in _RE_OPCION.findall(bloque)]
        if len(opciones) != 3:
            continue
        m_corr = _RE_CORRECTA.search(bloque)
        if not m_corr:
            continue
        try:
            correcta = _LETRAS.index(m_corr.group(1).upper())
        except ValueError:
            continue
        preguntas.append({
            "id": "{0}-{1}".format(numero, len(preguntas) + 1),
            "test": numero,
            "fecha": fecha,
            "pregunta": enunciado,
            "opciones": opciones,
            "correcta": correcta,
            "img": img,
            "necesita_imagen": bool(_DEPENDE_DE_IMAGEN.search(enunciado)),
        })
    return preguntas


#: Cómo terminó una descarga. Antes devolvía la lista vacía en los tres casos y el que
#: cancelaba se llevaba el mensaje de «No se pudo actualizar», que es falso y descoloca.
COMPLETA = "completa"
CANCELADA = "cancelada"
VACIA = "vacia"


def _descargar_banco(min_test, max_test, dialog=None):
    """Baja los tests del rango y devuelve (preguntas, motivo, con_imagen).

    El desduplicado se aplica a todas las preguntas para mantener la coherencia
    en el recuento independientemente de si llevan imagen o solo texto.
    """
    progreso = None
    if dialog is not None:
        progreso = xbmcgui.DialogProgress()
        progreso.create("EspaTV", "Descargando tests de la DGT…")
    try:
        banco = []
        vistos = set()
        con_imagen = 0
        rango = list(range(min_test, max_test + 1))
        for i, numero in enumerate(rango, 1):
            if progreso is not None:
                if progreso.iscanceled():
                    return [], CANCELADA, con_imagen
                progreso.update(int(i * 100.0 / len(rango)),
                                "Test {0} de {1}".format(numero, max_test))
            pagina = _get(_URL_TEST.format(numero))
            if pagina is None:
                continue
            for p in _parse_test(pagina, numero):
                clave = re.sub(r"[^a-z0-9]+", " ", p["pregunta"].lower()).strip()
                if clave in vistos:
                    continue
                vistos.add(clave)
                if p["necesita_imagen"]:
                    con_imagen += 1
                banco.append(p)
    finally:
        if progreso is not None:
            progreso.close()
    if not banco:
        return [], VACIA, con_imagen
    return banco, COMPLETA, con_imagen


# Imágenes
_DIR_IMAGENES = "dgt_imagenes"
_URL_BASE = "https://revista.dgt.es"
# Firmas de los formatos que va a guardar la DGT. Si el cuerpo no empieza por una
# de estas, es una página de error disfrazada de .jpg y no se guarda: un PNG o JPG
# corrupto se ve como imagen rota en pantalla.
_FIRMAS = (b"\xff\xd8\xff", b"\x89PNG\r\n\x1a\n")


def _dir_imagenes():
    ruta = os.path.join(_PROFILE_DIR, _DIR_IMAGENES)
    try:
        os.makedirs(ruta, exist_ok=True)
    except OSError as exc:
        _log("No se pudo crear {0}: {1}".format(ruta, exc), xbmc.LOGWARNING)
    return ruta


def _ruta_imagen(img):
    """Dónde se guarda una imagen.

    El nombre es el hash de la URL y no el `id` de la pregunta ni el nombre original
    de la DGT: así, si la DGT repite la misma foto en dos preguntas, se baja UNA vez;
    y el nombre no depende de que el patrón de la época sea raro.
    """
    if not img:
        return ""
    import hashlib
    clave = hashlib.sha1(img.encode("utf-8")).hexdigest()[:16]
    ext = ".png" if img.lower().endswith(".png") else ".jpg"
    return os.path.join(_dir_imagenes(), clave + ext)


def _imagen_local(img):
    """La ruta de la foto de una pregunta si está descargada, o "".

    También comprueba que el fichero tenga algo dentro: uno de cero bytes, colado por
    un corte de escritura, se vería roto.
    """
    ruta = _ruta_imagen(img)
    if ruta and os.path.isfile(ruta) and os.path.getsize(ruta) > 0:
        return ruta
    return ""


def _bajar_imagen(img):
    """Baja una imagen y la guarda. Devuelve la ruta local, o "" si no ha podido.

    Lo que se comprueba, en orden: que venga una ruta, que el HTTP sea 200, que el
    cuerpo no vaya vacío, que empiece por la firma JPEG o PNG, y que la escritura sea
    atómica. Si algo falla no se guarda NADA, para que no quede un fichero a medias
    que después se dé por bueno.
    """
    if not img:
        return ""
    ruta = _imagen_local(img)
    if ruta:
        return ruta

    url = img if img.startswith("http") else _URL_BASE + img
    try:
        r = requests.get(url, headers=_CABECERAS, timeout=_TIMEOUT)
        if r.status_code != 200:
            _log("Imagen {0}: HTTP {1}".format(img, r.status_code), xbmc.LOGDEBUG)
            return ""
        cuerpo = r.content
        if not cuerpo:
            _log("Imagen {0}: cuerpo vacío".format(img), xbmc.LOGDEBUG)
            return ""
        if not cuerpo.startswith(_FIRMAS):
            _log("Imagen {0}: no es JPEG ni PNG".format(img), xbmc.LOGDEBUG)
            return ""
        ruta = _ruta_imagen(img)
        tmp = "{0}.{1}.tmp".format(ruta, os.getpid())
        with open(tmp, "wb") as fh:
            fh.write(cuerpo)
        os.replace(tmp, ruta)
        return ruta
    except requests.RequestException as exc:
        _log("Imagen {0}: {1}".format(img, type(exc).__name__), xbmc.LOGDEBUG)
        return ""
    except OSError as exc:
        _log("Imagen {0} no se pudo guardar: {1}".format(img, exc), xbmc.LOGWARNING)
        return ""


def _una_imagen(img):
    """La imagen de una pregunta: la que ya está, o bajarla ahora.

    La llama el hilo de fondo de la ventana del test.
    """
    ruta = _imagen_local(img)
    if ruta or not _imagenes_permitidas():
        return ruta
    return _bajar_imagen(img)


def dgt_test_imagenes():
    """Se baja todas las fotos. Con aviso del peso, progreso y cancelación."""
    h = _handle()
    dialog = xbmcgui.Dialog()
    _info, preguntas = _cargar_banco()
    if not preguntas:
        _fin(h, succeeded=False)
        return

    pendientes = [p["img"] for p in preguntas
                  if p.get("img") and not _imagen_local(p["img"])]
    if not pendientes:
        dialog.ok("Imágenes",
                  "Ya están todas descargadas.\n\nNada que bajar.")
        _fin(h, succeeded=False)
        return

    # Estimación de peso basada en ~96,6 KB de media por imagen (~71 MB total).
    # Se avisa antes de iniciar la descarga.
    if not dialog.yesno(
            "Descargar imágenes",
            "Vas a bajar {0} fotos de la DGT.\n\n"
            "Pesan unos {1} MB. Se quedan en el perfil del addon, así que no engordan "
            "lo que se instala.\n\n"
            "¿Seguir?".format(len(pendientes),
                              max(1, int(len(pendientes) * 96.6 / 1024)))):
        _fin(h, succeeded=False)
        return

    progreso = xbmcgui.DialogProgress()
    progreso.create("EspaTV", "Descargando imágenes de la DGT…")
    bien = 0
    cortado = False
    try:
        for i, img in enumerate(pendientes, 1):
            if progreso.iscanceled():
                cortado = True
                break
            progreso.update(int(i * 100.0 / len(pendientes)),
                            "Imagen {0} de {1}".format(i, len(pendientes)))
            if _bajar_imagen(img):
                bien += 1
    finally:
        progreso.close()

    if bien == len(pendientes):
        dialog.ok("Imágenes", "Descargadas las {0}.".format(bien))
    else:
        dialog.ok(
            "Imágenes",
            "Descargadas {0} de {1}.\n\n"
            "Las que faltan se bajarán solas cuando hagan falta, o puedes volver a "
            "probarlo.{2}".format(
                bien, len(pendientes),
                "\n\nHas cancelado antes de terminar." if cortado else ""))
    _fin(h, succeeded=False)
