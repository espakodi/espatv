# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Storage manager: auditoría y limpieza de cachés del addon.

Útil sobre todo en dispositivos limitados (Firestick, TV Box) donde el
acumulado de cachés del addon puede notarse con el tiempo. Garantiza que
los datos del usuario (favoritos, historial, biblioteca, descargas) NUNCA
se tocan: solo se limpia lo que se puede regenerar.
"""

import os
import re
import sys
import shutil
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_LOG     = "[EspaTV-STORAGE]"
_PROFILE = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
_MEDIA   = os.path.join(os.path.dirname(os.path.abspath(__file__)), "resources", "media")


def _icon(name, fallback="DefaultIconInfo.png"):
    p = os.path.join(_MEDIA, name)
    return p if os.path.isfile(p) else fallback

# Registro de cachés
# Cada entrada: clave, label, [archivos], [carpetas], [regex_dinamicos]
# Solo aparece en el menú lo que pesa > 0 bytes.

_CACHES = [
    ("epg",          "Programación TV (EPG en texto)",   ["epg_texto_cache.json"], [], []),
    ("gasolineras",  "Gasolineras",                       ["gasolineras_cache.json"], [], []),
    ("efemerides",   "Efemérides",                        ["efemerides_cache.json"], [], []),
    ("boe",          "BOE",                               ["boe_cache.json"], [], []),
    ("sepe",         "SEPE",                              ["sepe_cache.json"], [], []),
    ("dgt",          "Tráfico DGT",                       ["dgt_incidencias.json", "dgt_camaras.json"], [], []),
    ("dgt_examen",    "Tests DGT (banco descargado)",       ["dgt_examen.json", "dgt_examen_perfil.json"], [], []),
    ("dgt_examen_img", "Tests DGT (imágenes)",               [], ["dgt_imagenes"], []),
    ("alquiler",     "Alquiler",                          ["alquiler_cache.json"], [], []),
    ("embalses",     "Embalses",                          ["embalses_cache.json"], [], []),
    ("aire",         "Calidad del aire / Polen",          ["aire_cache.json", "polen_cache.json"], [], []),
    ("bolsa",        "Bolsa (IBEX, S&P 500, Cripto)",     ["ibex_cache.json", "ibex_web_cache.json", "sp500_cache.json", "crypto_cache.json"], [], []),
    ("luz",          "Precio de la luz",                  ["precio_luz_cache.json"], [], []),
    ("horoscopo",    "Horóscopo",                         ["horoscopo_cache.json"], [], []),
    ("agenda",       "Agenda cultural",                   ["agenda_cultural_cache.json"], ["agenda_cache"], []),
    ("librivox",     "Audiolibros",                       [], ["librivox_cache"], []),
    ("galeria",      "Galería de arte",                   [], ["galeria_cache"], []),
    ("nombres",      "Significado de los nombres",        [], ["nombres_cache"], []),
    ("musica",       "Música",                            [], ["musica_cache"], []),
    ("cine",         "Metadatos de cine (Cinemeta/FA/SC/TMDb)",
                     ["espatv_cinemeta_cache.json", "espatv_fa_cache.json",
                      "espatv_sc_cache.json", "espatv_tmdb_lists_cache.json"], [], []),
    ("archive",      "Archive.org",                       ["espatv_archive_cache.json"], [], []),
    ("flix",         "Flix / Modo Cine",                  ["espatv_flix_cache.json"], [], []),
    ("oscar",        "Óscars (películas)",                ["espatv_oscar_movies_cache.json"], [], []),
    ("iptv",         "Caché IPTV",                        [], ["iptv_cache", "iptv_source_cache"], []),
    # El nombre viene de fuentes_tv._NOMBRE. Estas tablas se construyen al importar el
    # modulo, y desde ahi no se puede importar un modulo de UI sin crear un ciclo.
    ("fuentes",      "Cache de HyperXStream",             [], ["fuentes_cache"], []),
    ("trakt_thumbs",    "Trakt · miniaturas",                [], [], [r"^trakt_thumbs_\d+\.json$"]),
    ("trakt_tops",      "Trakt · tops y descubrimiento",
                        ["espatv_trakt_tops_cache.json", "espatv_trakt_discovery_cache.json"], [], []),
    ("streaming_tops",  "Tops de plataformas de streaming",
                        ["espatv_streaming_tops_cache.json"], [], []),
    ("calendario_series", "Calendario de emisión de series",
                        ["espatv_calendario_series.json"], [], []),
    ("anime_tops",      "Tops de anime (AniList / MAL)",
                        ["espatv_anime_cache.json"], [], []),
    ("mdblist",         "MDbList",
                        ["espatv_mdblist_cache.json"], [], []),
    ("letterboxd",      "Letterboxd",
                        ["espatv_letterboxd_cache.json"], [], []),
    ("clasif",          "Clasificaciones deportivas",
                     ["clasif_champions.json", "clasif_laliga.json",
                      "clasif_segunda.json", "clasif_euroliga.json"], [], []),
    ("scores_live",  "Marcadores en directo",
                     ["scores_champions.json", "scores_laliga.json", "scores_segunda.json"], [], []),
    ("scores_old",   "Snapshots de partidos (por fecha)", [], [],
                     [r"^scores_(?:laliga|segunda|champions|euroliga)_\d{8}\.json$"]),
    ("loteria",      "Lotería (HTML cacheado)",          ["loteria_20m.html"], [], []),
    ("transporte",   "Horarios de Transporte (GTFS y cachés de metro)",
                     ["gtfs_metro_malaga.zip", "metro_madrid_cache.json",
                      "metrovalencia_cache.json", "metro_barcelona_cache.json"], [], []),
    # El messages_cache.json de los avisos. Se regenera solo en la siguiente apertura, asi que
    # borrarlo solo cuesta un aviso mas de espera (messages_state.json, el contador de veces, si
    # que es _PROTECTED y no se toca: es estado del usuario, no una cache).
    ("avisos",       "Avisos (messages.json)",           ["messages_cache.json"], [], []), ("yt_cache", "YouTube (catálogo y búsquedas)", [], ["yt_cache"], []),
]

# Limpieza silenciosa al iniciar (retención en días)

_DATED_PATTERNS = [
    (re.compile(r"^scores_(?:laliga|segunda|champions|euroliga)_\d{8}\.json$"), 14),
]

# Datos del usuario (protegidos)

_USER_DATA = [
    ("Biblioteca enriquecida (metadata)", ["espatv_metadata.db"], []),
    ("Favoritos / Historial / Marcadores",
     ["favorites.json", "movie_favorites.json", "watch_history.json", "watched_yt.json", "yt_watched_history.json",
      "url_bookmarks.json", "url_history.json", "acestream_history.json"], []),
    ("Descargas",                  ["downloads_history.json"], []),
    ("Búsquedas guardadas",        ["search_history.json", "yt_search_history.json"], []),
    ("Listas y playlists",         ["yt_playlists.json", "yt_subscriptions.json", "yt_watch_later.json", "yt_settings.json", "saved_playlists.json", "custom_iptv.json", "custom_iptv_lists.json", "tv_autonomicas.json", "custom_press_feeds.json", "custom_podcasts.json"], ["iptv_lists"]),
    ("HyperXStream - servidores y listas",  ["mis_fuentes.json", "fuentes_uso.json", "fuentes_favoritos.json", "fuentes_ultimo.json"], ["fuentes_cache"]),
    ("Atajos '¿Dónde buscar?'",   ["search_shortcuts.json", "search_shortcuts_order.json", "search_dialog_layout.json"], []),
    ("Trakt · sesión",             ["trakt_settings.json"], []),
    ("Sección X (+18)",          ["xxx_settings.json", "xxx_favs.json", "xxx_hist.json"], []),
    ("MDbList · configuración",    ["mdblist_settings.json"], []),
    ("MAL · configuración",        ["mal_settings.json"], []),
    ("Componente yt-dlp (resolución de vídeo)", [], ["packages"]),
]

# Lista de archivos protegidos contra borrado

_PROTECTED = {
    "espatv_metadata.db",
    "favorites.json", "movie_favorites.json", "watch_history.json", "watched_yt.json", "yt_watched_history.json",
    "url_bookmarks.json", "url_history.json",
    "downloads_history.json",
    "search_history.json", "yt_search_history.json",
    "yt_playlists.json", "yt_playlists.json.bak", "yt_subscriptions.json", "yt_watch_later.json", "yt_settings.json",  # backup automático del usuario
    "saved_playlists.json",
    "custom_iptv.json", "custom_iptv_lists.json", "iptv_lists", "tv_autonomicas.json",
    "custom_press_feeds.json", "custom_podcasts.json",
    # HyperXStream (nombre en fuentes_tv._NOMBRE): servidores con sus
    # credenciales dentro
    "mis_fuentes.json", "fuentes_uso.json", "fuentes_favoritos.json", "fuentes_ultimo.json",
    "custom_categories.json",
    "trakt_settings.json", "dm_settings.json",
    "tmdb_settings.json", "mdblist_settings.json", "mal_settings.json",
    "easter_eggs_found.json", "egg_count.txt",  # progreso del usuario
    "et.jpg",
    "stats.json", "status_check.json", "messages_state.json",
    "aemet_locations.json",
    # Settings de Kodi en el perfil del addon: no tocar nunca
    "settings.xml",
    "search_shortcuts.json", "search_shortcuts_order.json", "search_dialog_layout.json",
    "acestream_history.json",
    "advanced_search_state.json", "min_duration.json", "priority_state.json",
    # Estado mínimo que no merece tocarse
    "alquiler_state.json", "gasolineras_state.json", "iptv_cache_settings.json",
    "espadaily_integration_state.json",
    # Estados de transporte: contienen estaciones guardadas y claves de API
    "metro_madrid_state.json", "metro_malaga_state.json",
    "metrovalencia_state.json", "metro_barcelona_state.json",
    # Sección X (+18): el hash del PIN vive aquí. Si se purga, se vuelve a pedir.
    "xxx_settings.json", "xxx_favs.json", "xxx_hist.json",
}


# Utilidades

def _path(name):
    return os.path.join(_PROFILE, name)


def _size_of(path):
    if not os.path.exists(path):
        return 0
    if os.path.isdir(path):
        total = 0
        for root, _, files in os.walk(path):
            for f in files:
                try:
                    total += os.path.getsize(os.path.join(root, f))
                except OSError:
                    pass
        return total
    try:
        return os.path.getsize(path)
    except OSError:
        return 0


def _delete_path(path):
    """Borra un archivo o carpeta. Devuelve los bytes liberados (0 si falló)."""
    name = os.path.basename(path)
    if name in _PROTECTED:
        xbmc.log("{} BLOQUEADO borrado de archivo protegido: {}".format(_LOG, name), xbmc.LOGWARNING)
        return 0
    sz = _size_of(path)
    try:
        if os.path.isdir(path):
            shutil.rmtree(path, ignore_errors=True)
            return sz if not os.path.exists(path) else 0
        if os.path.exists(path):
            os.remove(path)
            return sz
    except OSError as e:
        xbmc.log("{} Error borrando {}: {}".format(_LOG, path, e), xbmc.LOGWARNING)
    return 0


def fmt_size(b):
    if b < 1024:
        return "{} B".format(b)
    if b < 1024 * 1024:
        return "{:.1f} KB".format(b / 1024.0)
    return "{:.2f} MB".format(b / 1024.0 / 1024.0)


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


# Cálculo de uso de disco

def _list_profile():
    try:
        return os.listdir(_PROFILE)
    except OSError:
        return []


def _resolver_paths(files, dirs, regex_list, profile_entries):
    """Devuelve la lista de rutas existentes para una entrada de caché."""
    rutas = []
    for f in files:
        p = _path(f)
        if os.path.exists(p):
            rutas.append(p)
    for d in dirs:
        p = _path(d)
        if os.path.exists(p):
            rutas.append(p)
    if regex_list:
        compiled = [re.compile(rx) for rx in regex_list]
        for entry in profile_entries:
            if any(c.match(entry) for c in compiled):
                rutas.append(_path(entry))
    return rutas


def auditar_cache():
    """[(key, label, bytes, rutas), ...] solo categorías con bytes > 0."""
    entries = _list_profile()
    out = []
    for key, label, files, dirs, regex_list in _CACHES:
        rutas = _resolver_paths(files, dirs, regex_list, entries)
        total = sum(_size_of(p) for p in rutas)
        if total > 0:
            out.append((key, label, total, rutas))
    return out


def auditar_user_data():
    """[(label, bytes), ...] de las categorías de datos del usuario con bytes > 0."""
    out = []
    for label, files, dirs in _USER_DATA:
        total = 0
        for f in files:
            total += _size_of(_path(f))
        for d in dirs:
            total += _size_of(_path(d))
        if total > 0:
            out.append((label, total))
    return out


# Auto-limpieza silenciosa al arrancar

def limpiar_dated():
    """Borra archivos con fecha en el nombre que excedan su retención.

    Pensado para llamar desde default.py al iniciar el plugin. No imprime
    nada al usuario y nunca lanza excepciones que rompan el arranque.
    """
    try:
        now = time.time()
        n, bytes_ = 0, 0
        for entry in _list_profile():
            for pat, dias in _DATED_PATTERNS:
                if not pat.match(entry):
                    continue
                full = _path(entry)
                try:
                    mtime = os.path.getmtime(full)
                except OSError:
                    continue
                if (now - mtime) > dias * 86400:
                    sz = _size_of(full)
                    if _delete_path(full):
                        n += 1
                        bytes_ += sz
                break
        if n > 0:
            xbmc.log("{} Auto-limpieza: {} archivos antiguos, {} liberados".format(
                _LOG, n, fmt_size(bytes_)), xbmc.LOGINFO)
    except Exception as e:
        # Nunca dejar que esto rompa el arranque.
        xbmc.log("{} limpiar_dated() ignorando excepción: {}".format(_LOG, e), xbmc.LOGWARNING)


# Acciones de borrado

def _borrar_rutas(rutas):
    return sum(_delete_path(p) for p in rutas)


def purgar_todas():
    """Borra todas las cachés conocidas (_CACHES) sin diálogos. Devuelve bytes liberados.

    Es la base compartida por el botón 'Borrar TODAS' del menú y por el limpiador
    de Ajustes avanzados: ambos borran solo lo listado en _CACHES (whitelist), nunca
    config ni datos del usuario.
    """
    entries = _list_profile()
    return sum(
        _borrar_rutas(_resolver_paths(files, dirs, regex_list, entries))
        for _key, _label, files, dirs, regex_list in _CACHES
    )


def borrar_categoria(key):
    """Borra una categoría concreta tras confirmación del usuario."""
    entry = next((c for c in _CACHES if c[0] == key), None)
    if entry is None:
        return
    _, label, files, dirs, regex_list = entry
    rutas = _resolver_paths(files, dirs, regex_list, _list_profile())
    total = sum(_size_of(p) for p in rutas)

    if total == 0:
        xbmcgui.Dialog().notification("EspaTV", "Esta caché ya está vacía",
                                      xbmcgui.NOTIFICATION_INFO, 2000)
        return

    if not xbmcgui.Dialog().yesno(
        "Borrar caché",
        "{}\n\nSe liberarán [B]{}[/B].\n\nLos datos se volverán a descargar la próxima vez que abras esta sección.".format(
            label, fmt_size(total),
        ),
    ):
        return

    liberado = _borrar_rutas(rutas)
    xbmcgui.Dialog().notification(
        "EspaTV", "Liberados {}".format(fmt_size(liberado)),
        xbmcgui.NOTIFICATION_INFO, 3000,
    )
    xbmc.executebuiltin("Container.Refresh")


def borrar_todas():
    """Borra TODAS las cachés conocidas tras confirmación."""
    audit = auditar_cache()
    total = sum(b for _, _, b, _ in audit)

    if total == 0:
        xbmcgui.Dialog().notification("EspaTV", "No hay cachés que borrar",
                                      xbmcgui.NOTIFICATION_INFO, 2000)
        return

    if not xbmcgui.Dialog().yesno(
        "Borrar TODAS las cachés",
        "Se borrarán todas las cachés del addon ([B]{}[/B] en total).\n\n"
        "[COLOR lightgreen]Tus favoritos, historial, biblioteca, descargas y configuraciones de servicios (Trakt, MDbList, MAL) NO se tocan.[/COLOR]\n\n"
        "¿Continuar?".format(fmt_size(total)),
    ):
        return

    liberado = purgar_todas()

    xbmcgui.Dialog().notification(
        "EspaTV", "Liberados {}".format(fmt_size(liberado)),
        xbmcgui.NOTIFICATION_INFO, 3500,
    )
    xbmc.executebuiltin("Container.Refresh")


def borrar_metadata():
    """Vacía la biblioteca enriquecida (espatv_metadata.db) tras confirmación.

    Caso especial fuera de _CACHES: rehidratarla cuesta cientos de llamadas a
    TMDB, así que 'Borrar TODAS' no la toca; solo se vacía aquí de forma
    deliberada. Se delega en metadata_enricher.clear_all(), que vacía la tabla y
    compacta el archivo (no se borra el .db: estaría bloqueado y dejaría sidecars).
    """
    path = _path("espatv_metadata.db")
    antes = _size_of(path)

    if antes == 0:
        xbmcgui.Dialog().notification("EspaTV", "La biblioteca ya está vacía",
                                      xbmcgui.NOTIFICATION_INFO, 2000)
        return

    if not xbmcgui.Dialog().yesno(
        "Vaciar biblioteca enriquecida",
        "Se vaciarán los metadatos de TMDB cacheados ([B]{}[/B]).\n\n"
        "[COLOR orange]Se reconstruyen solos con el uso, pero la primera vez que ojees "
        "cada lista volverán a pedirse a TMDB (irá algo más lento ese rato).[/COLOR]\n\n"
        "¿Continuar?".format(fmt_size(antes)),
    ):
        return

    import metadata_enricher
    # El VACUUM reescribe el archivo (segundos en una DB de varios MB): indicador
    # en segundo plano para que no parezca un cuelgue, sobre todo en TV Box.
    prog = xbmcgui.DialogProgressBG()
    prog.create("EspaTV", "Vaciando biblioteca enriquecida...")
    try:
        metadata_enricher.clear_all()
    finally:
        prog.close()

    liberado = max(0, antes - _size_of(path))
    xbmcgui.Dialog().notification(
        "EspaTV", "Liberados {}".format(fmt_size(liberado)),
        xbmcgui.NOTIFICATION_INFO, 3000,
    )
    xbmc.executebuiltin("Container.Refresh")


# Menú

_USER_DATA_PLOTS = {
    "Biblioteca enriquecida (metadata)":
        "Caché unificada de metadatos de TMDB (espatv_metadata.db) compartida por "
        "todas las listas del addon: películas y series de favoritos, historial, "
        "listas IPTV, búsquedas, etc.\n\n"
        "Cada entrada guarda: título y título original, año, sinopsis, géneros, "
        "valoración y votos, duración, director, reparto principal y URLs de "
        "póster y fanart. Por eso, al ojearla, se ve toda la ficha sin volver "
        "a llamar a TMDB.\n\n"
        "Vida útil: las entradas caducan a los 30 días (se ignoran al leer y "
        "se sobrescriben cuando vuelven a hacer falta). Es decir, se purga "
        "sola con el uso normal del addon.\n\n"
        "No se borra con 'Borrar TODAS' porque rehidratarla cuesta cientos de "
        "llamadas a TMDB. Si necesitas el espacio, usa el botón naranja "
        "'Vaciar biblioteca enriquecida' de más abajo.",
    "Favoritos / Historial / Marcadores":
        "Tus favoritos, historial de visualización (TV, YouTube, AceStream) y URLs "
        "guardadas/marcadas.\n\n"
        "No se borra desde aquí. Para limpiar, ve a la sección correspondiente "
        "del addon (Favoritos, Historial, URLs, AceStream).",
    "Descargas":
        "Registro de descargas realizadas con el addon.\n\n"
        "No se borra desde aquí. Gestiónalo desde la sección de Descargas.",
    "Búsquedas guardadas":
        "Historial de búsquedas dentro del addon y de YouTube.\n\n"
        "No se borra desde aquí. Bórralo desde el propio buscador.",
    "Listas y playlists":
        "Tus playlists de YouTube guardadas, listas IPTV y "
        "canales autonómicos.\n\n"
        "No se borra desde aquí. Edítalo desde la sección correspondiente.",
    "Trakt · sesión":
        "Token y configuración de tu sesión de Trakt.\n\n"
        "No se borra desde aquí. Cierra sesión desde los ajustes de Trakt "
        "del addon si quieres eliminarlo.",
    "Atajos '¿Dónde buscar?'":
        "Atajos personalizados que has creado en la ventana '¿Dónde buscar?': "
        "addons, URLs manuales y favoritos, con su orden guardado.\n\n"
        "No se borra desde aquí. Edítalos desde Ajustes avanzados → "
        "Atajos '¿Dónde buscar?'.",
    "MDbList · configuración":
        "Tu API key de MDbList.\n\n"
        "No se borra desde aquí. Si quieres desconectar MDbList, "
        "borra la clave desde la propia sección de MDbList.",
    "MAL · configuración":
        "Tu client ID de MyAnimeList (MAL).\n\n"
        "No se borra desde aquí. Si quieres desconectar MAL, "
        "borra el client ID desde la sección de Anime.",
    "Componente yt-dlp (resolución de vídeo)":
        "Librería que resuelve enlaces de YouTube y otras webs. Se descarga "
        "sola la primera vez que hace falta (~13 MB desde PyPI) y se reutiliza.\n\n"
        "No se borra desde aquí porque volver a bajarla cuesta una descarga "
        "completa. Si de verdad necesitas el espacio, elimina la carpeta "
        "'packages' del perfil del addon: se descargará de nuevo al usar una "
        "función que la requiera.",
}

_USER_DATA_PLOT_DEFAULT = (
    "Esta categoría contiene datos personales del usuario y NO se borra "
    "desde el gestor de cachés.\n"
    "Para borrarlos, ve a la sección correspondiente del addon."
)

_USER_DATA_ICONS = {
    "Biblioteca enriquecida (metadata)": "cat_filmoteca.png",
    "Favoritos / Historial / Marcadores": "favoritos.png",
    "Descargas": "descargas.png",
    "Búsquedas guardadas": "srch_titulo.png",
    "Listas y playlists": "dm_listas.png",
    "HyperXStream - servidores y listas": "servidores_xtream.png",
    "Atajos '¿Dónde buscar?'": "adv_busqueda_atajos.png",
    "Trakt · sesión": "top_trakt_real.png",
    "Sección X (+18)": "xxx.png",
    "MDbList · configuración": "top_mdblist.png",
    "MAL · configuración": "top_anilist.png",
    "Componente yt-dlp (resolución de vídeo)": "adv_ytdlp.png",
}


def _user_data_icon(label):
    name = _USER_DATA_ICONS.get(label, "adv_almacenamiento.png")
    return _icon(name)


def _user_data_plot(label):
    return _USER_DATA_PLOTS.get(label, _USER_DATA_PLOT_DEFAULT)



_CACHE_ICONS = {
    "epg": "cat_epg_texto.png",
    "gasolineras": "cat_gasolineras.png",
    "efemerides": "cat_efemerides.png",
    "boe": "cat_boe.png",
    "sepe": "cat_sepe.png",
    "dgt": "dgt_coche.png",
    "dgt_examen": "dgt_examen.png",
    "dgt_examen_img": "dgt_imagenes.png",
    "alquiler": "cat_alquiler.png",
    "embalses": "cat_embalses.png",
    "aire": "cat_aire.png",
    "bolsa": "cat_ibex.png",
    "luz": "cat_luz.png",
    "horoscopo": "cat_horoscopo.png",
    "agenda": "cat_agenda_cultural.png",
    "librivox": "cat_audiolibros.png",
    "galeria": "cat_galeria_arte.png",
    "nombres": "cat_nombres.png",
    "musica": "cat_musica.png",
    "cine": "cat_cine.png",
    "archive": "archive.png",
    "flix": "modo_grid.png",
    "oscar": "oscar.png",
    "iptv": "tv.png",
    "fuentes": "servidores_xtream.png",
    "trakt_thumbs": "top_trakt_real.png",
    "trakt_tops": "top_trakt_real.png",
    "streaming_tops": "top_streaming.png",
    "calendario_series": "top_series_air.png",
    "anime_tops": "top_anime.png",
    "mdblist": "top_mdblist.png",
    "letterboxd": "cat_filmaffinity.png",
    "clasif": "agenda_clasificaciones.png",
    "scores_live": "agenda_clasificaciones.png",
    "scores_old": "agenda_clasificaciones.png",
    "loteria": "cat_loteria.png",
    "transporte": "cat_transporte.png",
    "avisos": "info_aviso.png",
    "yt_cache": "youtube.png",
}


def _cache_icon(key):
    name = _CACHE_ICONS.get(key, "adv_almacenamiento.png")
    return _icon(name)


def _add_item(h, label, url, plot=None, icon="DefaultIconInfo.png", folder=False):
    li = xbmcgui.ListItem(label=label)
    li.setArt({"icon": icon, "thumb": icon, "poster": icon})
    if plot:
        li.setInfo("video", {"plot": plot})
    li.setProperty("IsPlayable", "false")
    xbmcplugin.addDirectoryItem(handle=h, url=url or "", listitem=li, isFolder=folder)


def info_almacenamiento():
    """Diálogo de texto que explica qué se borra y qué no."""
    SEP = "─" * 44
    lines = [
        "GESTIÓN DE CACHÉS DEL ADDON",
        SEP,
        "",
        "Este addon guarda dos tipos de información en tu",
        "dispositivo:",
        "",
        "  1) CACHÉS, datos descargados de internet que",
        "     se pueden volver a bajar (programación TV,",
        "     gasolineras, BOE, datos del INE, etc.).",
        "",
        "  2) DATOS DEL USUARIO, favoritos, historial,",
        "     biblioteca enriquecida, descargas, sesión",
        "     de Trakt, etc. Solo existen aquí.",
        "",
        SEP,
        "QUÉ SE PUEDE BORRAR DESDE AQUÍ",
        SEP,
        "",
        "Solo las cachés del grupo (1). Al volver a abrir",
        "la sección correspondiente del addon, los datos",
        "se descargan otra vez. No pierdes nada.",
        "",
        SEP,
        "QUÉ NO SE TOCA NUNCA",
        SEP,
        "",
        "  • Favoritos (favorites.json)",
        "  • Historial de visualización (TV, YouTube, AceStream)",
        "  • Biblioteca enriquecida (espatv_metadata.db)",
        "  • Marcadores y URLs guardadas",
        "  • Listas IPTV",
        "  • Búsquedas guardadas",
        "  • Atajos personalizados '¿Dónde buscar?'",
        "  • Sesión de Trakt / MDbList / MAL",
        "  • Descargas (carpeta del usuario)",
        "  • Grabaciones TDT (carpeta del usuario)",
        "",
        "Estos datos solo se borran desde su sección",
        "correspondiente dentro del addon.",
        "",
        SEP,
        "AUTO-LIMPIEZA",
        SEP,
        "",
        "Al arrancar el addon se borran automáticamente",
        "los snapshots de partidos con más de 14 días.",
        "Es silencioso y no afecta a marcadores en directo.",
        "",
        SEP,
        "DISPOSITIVOS LIMITADOS (Firestick, TV Box)",
        SEP,
        "",
        "Si notas que el addon ocupa demasiado espacio,",
        "abre el menú de cachés y pulsa \"Borrar TODAS\".",
        "Es seguro y reversible (los datos se vuelven a",
        "descargar al uso).",
    ]
    xbmcgui.Dialog().textviewer(
        "Gestión de cachés · ayuda",
        "\n".join(lines),
    )


def menu_almacenamiento():
    """Submenú principal: muestra el uso por categoría y permite borrar."""
    h = int(sys.argv[1])

    cache = sorted(auditar_cache(), key=lambda x: -x[2])
    user  = sorted(auditar_user_data(), key=lambda x: -x[1])

    total_cache = sum(b for _, _, b, _ in cache)
    total_user  = sum(b for _, b in user)
    total_all   = total_cache + total_user

    icon_cache  = _icon("adv_almacenamiento.png")
    icon_borrar = _icon("adv_borrar.png")

    _add_item(
        h,
        "[B][COLOR aqua]Uso del addon: {}[/COLOR][/B]    [COLOR grey]({} en cachés)[/COLOR]".format(
            fmt_size(total_all), fmt_size(total_cache)
        ),
        url="",
        plot="Resumen del espacio que ocupa el addon en este dispositivo.\n"
             "El menú muestra solo lo borrable. Tus datos personales aparecen al final pero no se pueden borrar desde aquí.",
        icon=icon_cache,
    )

    if cache:
        _add_item(
            h,
            "[COLOR yellow]── CACHÉS (se pueden borrar sin perder datos) ──[/COLOR]",
            url="",
            icon=_icon("separador.png"),
        )
        for key, label, b, _rutas in cache:
            _add_item(
                h,
                "  {0}    [COLOR grey]{1}[/COLOR]".format(label, fmt_size(b)),
                url=_u(action="storage_clear_category", key=key),
                plot="Pulsa para borrar esta caché ({}).\n\n"
                     "Los datos se volverán a descargar la próxima vez "
                     "que abras la sección correspondiente.".format(fmt_size(b)),
                icon=_cache_icon(key),
            )

        _add_item(
            h,
            "[B][COLOR red][ Borrar TODAS las cachés ({}) ][/COLOR][/B]".format(fmt_size(total_cache)),
            url=_u(action="storage_clear_all"),
            plot="Borra todas las cachés del addon. Tus favoritos, historial, biblioteca y sesión de Trakt NO se tocan.",
            icon=icon_borrar,
        )
    else:
        _add_item(
            h,
            "[COLOR lightgreen]No hay cachés que borrar[/COLOR]",
            url="",
            icon=icon_cache,
        )

    if user:
        _add_item(
            h,
            "[COLOR yellow]── DATOS Y COMPONENTES (no se borran desde aquí) ──[/COLOR]",
            url="",
            icon=_icon("adv_seguridad.png"),
        )
        for label, b in user:
            _add_item(
                h,
                "  {0}    [COLOR grey]{1}[/COLOR]".format(label, fmt_size(b)),
                url="",
                plot=_user_data_plot(label),
                icon=_user_data_icon(label),
            )

    meta_size = _size_of(_path("espatv_metadata.db"))
    if meta_size > 0:
        _add_item(
            h,
            "[COLOR orange]Vaciar biblioteca enriquecida (metadata) ({})[/COLOR]".format(fmt_size(meta_size)),
            url=_u(action="storage_clear_metadata"),
            plot="Vacía los metadatos de TMDB cacheados (espatv_metadata.db) y "
                 "compacta el archivo para liberar el espacio.\n\n"
                 "Se reconstruyen solos con el uso, así que solo vacíala si necesitas "
                 "el espacio: la primera vez que ojees cada lista irá algo más lento.",
            icon=icon_borrar,
        )

    _add_item(
        h,
        "[COLOR grey]¿Qué se borra y qué no?[/COLOR]",
        url=_u(action="storage_info"),
        plot="Explica qué cachés se pueden borrar y qué datos del usuario nunca se tocan.",
        icon=_icon("adv_anti_errores.png"),
    )

    xbmcplugin.endOfDirectory(h)
