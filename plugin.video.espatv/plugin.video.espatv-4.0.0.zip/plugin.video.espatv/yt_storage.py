# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Almacenamiento local de suscripciones, Ver más tarde, historial y ajustes de YouTube."""

import csv
import io
import json
import os
import re
import threading
import time

try:
    import xbmc
    import xbmcaddon
    import xbmcvfs
except ImportError:
    xbmc = None
    xbmcaddon = None
    xbmcvfs = None

import core_settings

_LOCK = threading.RLock()

_SUBS_FILE = "yt_subscriptions.json"
_WATCH_LATER_FILE = "yt_watch_later.json"
_WATCHED_FILE = "yt_watched_history.json"
_SETTINGS_FILE = "yt_settings.json"


def _log(msg, level=None):
    if xbmc:
        lvl = level if level is not None else getattr(xbmc, "LOGWARNING", 3)
        xbmc.log(f"[EspaTV/yt_storage] {msg}", lvl)


def _get_profile_dir():
    p = ""
    if xbmcvfs and xbmcaddon:
        try:
            p = xbmcvfs.translatePath(xbmcaddon.Addon(core_settings.ADDON_ID).getAddonInfo("profile"))
        except (RuntimeError, AttributeError):
            p = ""
    if not p or p.startswith("special://"):
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tmp")
    if not os.path.exists(p):
        try:
            os.makedirs(p, exist_ok=True)
        except OSError:
            pass
    return p


def _get_subs_path():
    return os.path.join(_get_profile_dir(), _SUBS_FILE)


def _get_watch_later_path():
    return os.path.join(_get_profile_dir(), _WATCH_LATER_FILE)


def _get_watched_path():
    return os.path.join(_get_profile_dir(), _WATCHED_FILE)


def _get_settings_path():
    return os.path.join(_get_profile_dir(), _SETTINGS_FILE)


def _load_json(filename, default_val):
    path = os.path.join(_get_profile_dir(), filename)
    with _LOCK:
        if not os.path.exists(path):
            return default_val
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data if isinstance(data, type(default_val)) else default_val
        except (OSError, ValueError) as exc:
            _log(f"Error leyendo {filename}: {exc}")
            return default_val


def _save_json(filename, data):
    path = os.path.join(_get_profile_dir(), filename)
    with _LOCK:
        try:
            core_settings.atomic_write_json(path, data)
            return True
        except OSError as exc:
            _log(f"Error guardando {filename}: {exc}")
            return False


def _load_json_list(path):
    with _LOCK:
        if not os.path.exists(path):
            return []
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data if isinstance(data, list) else []
        except (OSError, ValueError) as exc:
            _log(f"Error leyendo lista {path}: {exc}")
            return []


def _load_json_dict(path):
    with _LOCK:
        if not os.path.exists(path):
            return {}
        try:
            with open(path, "r", encoding="utf-8") as f:
                data = json.load(f)
                return data if isinstance(data, dict) else {}
        except (OSError, ValueError) as exc:
            _log(f"Error leyendo dict {path}: {exc}")
            return {}


def list_subscriptions():
    with _LOCK:
        subs = _load_json_list(_get_subs_path())
        subs.sort(key=lambda x: x.get("name", "").lower())
        return subs


get_subscriptions = list_subscriptions


def is_subscribed(channel_id):
    if not channel_id:
        return False
    with _LOCK:
        subs = _load_json_list(_get_subs_path())
        return any(s.get("channel_id") == channel_id for s in subs)


def add_subscription(channel_id, name, thumb=""):
    if not channel_id:
        return False
    with _LOCK:
        subs = _load_json_list(_get_subs_path())
        if any(s.get("channel_id") == channel_id for s in subs):
            return False
        subs.append({
            "channel_id": channel_id,
            "name": name or channel_id,
            "thumb": thumb or "",
            "added_at": int(time.time()),
        })
        core_settings.atomic_write_json(_get_subs_path(), subs)
        return True


def remove_subscription(channel_id):
    if not channel_id:
        return False
    with _LOCK:
        subs = _load_json_list(_get_subs_path())
        filtered = [s for s in subs if s.get("channel_id") != channel_id]
        if len(filtered) != len(subs):
            core_settings.atomic_write_json(_get_subs_path(), filtered)
            return True
        return False


def _read_text_file(file_path):
    if not file_path:
        return None
    if os.path.isfile(file_path):
        try:
            with open(file_path, "r", encoding="utf-8-sig", errors="replace") as f:
                return f.read()
        except OSError as exc:
            _log(f"Error abriendo archivo {file_path}: {exc}")
            return None
    if xbmcvfs:
        try:
            translated = xbmcvfs.translatePath(file_path)
            if translated and os.path.isfile(translated):
                with open(translated, "r", encoding="utf-8-sig", errors="replace") as f:
                    return f.read()
            vf = xbmcvfs.File(file_path)
            try:
                raw = vf.read()
            finally:
                vf.close()
            if isinstance(raw, bytes):
                return raw.decode("utf-8-sig", errors="replace")
            if isinstance(raw, str):
                return raw.lstrip("\ufeff")
        except (OSError, RuntimeError, AttributeError) as exc:
            _log(f"Error leyendo VFS {file_path}: {exc}")
    return None


def import_subscriptions(file_path):
    content = _read_text_file(file_path)
    if not content:
        return 0

    with _LOCK:
        added = 0
        subs = _load_json_list(_get_subs_path())
        existing_ids = {s.get("channel_id") for s in subs if s.get("channel_id")}
        low_path = file_path.lower()

        if low_path.endswith(".csv"):
            try:
                reader = csv.reader(io.StringIO(content))
                header = next(reader, None)
                id_idx = 0
                title_idx = 2
                if header:
                    for i, col in enumerate(header):
                        low = col.lower().strip()
                        if "channel id" in low or "canal" in low or "id." in low:
                            id_idx = i
                        elif "title" in low or "nombre" in low or "título" in low or "titulo" in low:
                            title_idx = i
                for row in reader:
                    if not row:
                        continue
                    cid = row[id_idx].strip() if len(row) > id_idx else ""
                    if not (cid and cid.startswith("UC") and len(cid) == 24):
                        for col in row:
                            m = re.search(r"(UC[A-Za-z0-9_-]{22})", col)
                            if m:
                                cid = m.group(1)
                                break
                    title = row[title_idx].strip() if len(row) > title_idx else cid
                    if cid and cid.startswith("UC") and cid not in existing_ids:
                        subs.append({
                            "channel_id": cid,
                            "name": title or cid,
                            "thumb": "",
                            "added_at": int(time.time()),
                        })
                        existing_ids.add(cid)
                        added += 1
            except csv.Error as exc:
                _log(f"Error CSV Takeout: {exc}")
                return 0

        elif low_path.endswith(".json"):
            try:
                data = json.loads(content)
                items = data if isinstance(data, list) else data.get("subscriptions", [])
                for it in items:
                    if not isinstance(it, dict):
                        continue
                    snippet = it.get("snippet", {}) if isinstance(it.get("snippet"), dict) else {}
                    res_id = snippet.get("resourceId", {}) if isinstance(snippet.get("resourceId"), dict) else {}
                    cid = (
                        it.get("channel_id")
                        or it.get("channelId")
                        or res_id.get("channelId")
                        or it.get("id", "")
                    )
                    title = it.get("name") or it.get("title") or snippet.get("title") or cid
                    if not (cid and isinstance(cid, str) and cid.startswith("UC") and len(cid) == 24):
                        url = it.get("url") or it.get("channelUrl") or ""
                        m = re.search(r"(UC[A-Za-z0-9_-]{22})", str(url))
                        if m:
                            cid = m.group(1)
                    if cid and isinstance(cid, str) and cid.startswith("UC") and cid not in existing_ids:
                        subs.append({
                            "channel_id": cid,
                            "name": title or cid,
                            "thumb": it.get("thumb", ""),
                            "added_at": int(time.time()),
                        })
                        existing_ids.add(cid)
                        added += 1
            except ValueError as exc:
                _log(f"Error JSON Takeout: {exc}")
                return 0

        if added > 0:
            core_settings.atomic_write_json(_get_subs_path(), subs)

        return added


import_takeout = import_subscriptions


def list_watch_later():
    return _load_json_list(_get_watch_later_path())


get_watch_later = list_watch_later


def add_watch_later(item_or_vid, title="", channel="", duration="", thumb="", channel_id=""):
    if isinstance(item_or_vid, dict):
        vid = item_or_vid.get("vid") or item_or_vid.get("yt_id") or item_or_vid.get("video_id")
        title = item_or_vid.get("title") or item_or_vid.get("name") or vid
        channel = item_or_vid.get("channel", "")
        channel_id = item_or_vid.get("channel_id", "")
        duration = item_or_vid.get("duration", "")
        thumb = item_or_vid.get("thumb") or (f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg" if vid else "")
    else:
        vid = item_or_vid
        title = title or vid
        thumb = thumb or (f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg" if vid else "")

    if not vid:
        return False

    with _LOCK:
        items = _load_json_list(_get_watch_later_path())
        if any((it.get("vid") or it.get("yt_id") or it.get("video_id")) == vid for it in items):
            return False

        clean = {
            "video_id": vid,
            "vid": vid,
            "title": title,
            "channel": channel,
            "channel_id": channel_id,
            "duration": duration,
            "thumb": thumb,
            "added_at": int(time.time()),
        }
        items.insert(0, clean)
        core_settings.atomic_write_json(_get_watch_later_path(), items)
        return True


def remove_watch_later(vid):
    if not vid:
        return False
    with _LOCK:
        items = _load_json_list(_get_watch_later_path())
        filtered = [it for it in items if (it.get("vid") or it.get("yt_id") or it.get("video_id")) != vid]
        if len(filtered) != len(items):
            core_settings.atomic_write_json(_get_watch_later_path(), filtered)
            return True
        return False


def clear_watch_later():
    with _LOCK:
        core_settings.atomic_write_json(_get_watch_later_path(), [])


def add_watched(video_id, title="", thumb="", duration=0, channel=""):
    if not video_id:
        return
    with _LOCK:
        items = _load_json_list(_get_watched_path())
        prev = next((it for it in items if (it.get("video_id") or it.get("vid")) == video_id), {})
        items = [it for it in items if (it.get("video_id") or it.get("vid")) != video_id]
        items.insert(0, {
            "video_id": video_id,
            "vid": video_id,
            "title": title or prev.get("title") or video_id,
            "channel": channel or prev.get("channel", ""),
            "thumb": thumb or prev.get("thumb") or f"https://i.ytimg.com/vi/{video_id}/hqdefault.jpg",
            "duration": duration or prev.get("duration", 0),
            "watched_at": int(time.time()),
        })
        core_settings.atomic_write_json(_get_watched_path(), items[:100])


def get_watched():
    return _load_json_list(_get_watched_path())


def clear_watched():
    with _LOCK:
        core_settings.atomic_write_json(_get_watched_path(), [])
        watched_set_path = os.path.join(_get_profile_dir(), "watched_yt.json")
        if os.path.exists(watched_set_path):
            try:
                core_settings.atomic_write_json(watched_set_path, [])
            except OSError as exc:
                _log(f"Error limpiando watched_yt.json: {exc}")


_DEFAULT_SETTINGS = {
    "max_resolution": "1080p",
    "subtitles": True,
    "sponsorblock": False,
}


def get_settings():
    with _LOCK:
        data = _load_json_dict(_get_settings_path())
        res = dict(_DEFAULT_SETTINGS)
        res.update(data)
        return res


def save_settings(settings_dict):
    if isinstance(settings_dict, dict):
        with _LOCK:
            core_settings.atomic_write_json(_get_settings_path(), settings_dict)


def set_setting(key, value):
    with _LOCK:
        data = get_settings()
        data[key] = value
        core_settings.atomic_write_json(_get_settings_path(), data)
