# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Búsqueda y resolución de stream en PeerTube."""
import hashlib
import json
import os
import sys
import threading
import time
import urllib.parse
import urllib.request
import urllib.error

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

_API_SEARCH = "https://peertube.tv/api/v1/search/videos"
_API_VIDEO = "https://peertube.tv/api/v1/videos/{uuid}"
_BASE_URL = "https://peertube.tv"

_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Accept": "application/json",
    "Accept-Language": "es-ES,es;q=0.9,en;q=0.8",
}

_CACHE_DIR = xbmcvfs.translatePath(
    "special://userdata/addon_data/plugin.video.espatv/search_cache/")
_CACHE_TTL = 3600  # segundos


def _cache_get(key):
    path = os.path.join(_CACHE_DIR, key + ".json")
    try:
        if time.time() - os.path.getmtime(path) > _CACHE_TTL:
            return None
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def _cache_set(key, data):
    try:
        os.makedirs(_CACHE_DIR, exist_ok=True)
        tmp = os.path.join(_CACHE_DIR, f"{key}.{os.getpid()}_{threading.get_ident()}.tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(tmp, os.path.join(_CACHE_DIR, key + ".json"))
    except OSError:
        pass


def _get_json(url, timeout=15):
    req = urllib.request.Request(url, headers=_HEADERS)
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8", errors="replace"))


def _fmt_duration(secs):
    if not isinstance(secs, int) or secs <= 0:
        return ""
    h, rem = divmod(secs, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def _thumb(v):
    for t in v.get("thumbnails") or []:
        if isinstance(t, dict) and t.get("fileUrl"):
            return t["fileUrl"]
    path = v.get("thumbnailPath")
    return _BASE_URL + path if path else ""


def _parse_video(v):
    if not isinstance(v, dict):
        return None
    uuid = v.get("uuid")
    name = v.get("name")
    if not uuid or not name:
        return None
    if v.get("isLive"):
        return None
    chan = v.get("channel") or {}
    acc = v.get("account") or {}
    return {
        "uuid": uuid,
        "title": name,
        "channel": chan.get("displayName", ""),
        "host": acc.get("host", ""),
        "thumb": _thumb(v),
        "duration": v.get("duration") or 0,
        "description": v.get("truncatedDescription") or v.get("description") or "",
    }


def search(query, count=30):
    query = (query or "").strip()
    if not query:
        return []
    key = "peertube_" + hashlib.md5(query.lower().encode()).hexdigest()[:16]
    cached = _cache_get(key)
    if cached is not None:
        return cached
    params = urllib.parse.urlencode(
        {"search": query, "count": count, "sort": "-match", "nsfw": "false"})
    data = _get_json(f"{_API_SEARCH}?{params}")
    items = data.get("data") if isinstance(data, dict) else None
    results = [p for p in (_parse_video(v) for v in (items or [])) if p]
    _cache_set(key, results)
    return results


def resolve_stream(uuid):
    """Devuelve (url, kind) donde kind es 'mp4' (progresivo directo) o 'hls'."""
    if not uuid:
        return "", ""
    data = _get_json(_API_VIDEO.format(uuid=urllib.parse.quote(uuid)))

    files = [f for f in (data.get("files") or [])
             if isinstance(f, dict) and f.get("fileUrl")]
    if files:
        best = max(files, key=lambda f: (f.get("resolution") or {}).get("id", 0))
        return best["fileUrl"], "mp4"

    for sp in data.get("streamingPlaylists") or []:
        if isinstance(sp, dict) and sp.get("playlistUrl"):
            return _best_hls_url(sp["playlistUrl"]), "hls"
    return "", ""


def _probe(url, timeout=8):
    try:
        req = urllib.request.Request(url, headers={"User-Agent": _HEADERS["User-Agent"]})
        with urllib.request.urlopen(req, timeout=timeout) as r:
            return r.status == 200
    except Exception:
        return False


def _best_hls_url(url):
    # Algunas instancias concatenan baseUrl sin '/' y devuelven 'streaming-playlistshls/'
    # (404), y otras con almacenamiento S3 usan ese mismo prefijo sin barra como clave real.
    if "streaming-playlists/hls/" in url:
        alt = url.replace("streaming-playlists/hls/", "streaming-playlistshls/")
    elif "streaming-playlistshls/" in url:
        alt = url.replace("streaming-playlistshls/", "streaming-playlists/hls/")
    else:
        return url
    if _probe(url):
        return url
    if _probe(alt):
        return alt
    return url


def play_item(handle, uuid):
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Resolviendo stream de PeerTube...")
    try:
        stream_url, kind = resolve_stream(uuid)
        dp.close()
    except (urllib.error.URLError, OSError, ValueError) as e:
        dp.close()
        xbmc.log(f"[EspaTV] Error resolviendo PeerTube: {e}", xbmc.LOGERROR)
        if handle >= 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok("EspaTV", f"Error al resolver el stream:\n{e}")
        return

    if not stream_url:
        if handle >= 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok("EspaTV", "No se pudo obtener la URL de reproducción de PeerTube.")
        return

    if kind == "hls" and not _has_inputstream_adaptive():
        if handle >= 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok("EspaTV",
            "Este vídeo solo está disponible en formato HLS y requiere "
            "'InputStream Adaptive', que no está instalado o está deshabilitado en Kodi.\n\n"
            "Actívalo desde el repositorio oficial para reproducirlo.")
        return

    xbmc.log(f"[EspaTV] PeerTube stream ({kind}): {stream_url}", xbmc.LOGINFO)
    li = xbmcgui.ListItem(path=stream_url)
    if kind == "hls":
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstreamaddon', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        li.setProperty('inputstream.adaptive.stream_headers',
                       'User-Agent=' + _HEADERS["User-Agent"])
        li.setMimeType('application/x-mpegURL')
        li.setContentLookup(False)
    if handle >= 0:
        xbmcplugin.setResolvedUrl(handle, True, li)
    else:
        xbmc.Player().play(li.getPath(), li)


def _has_inputstream_adaptive():
    try:
        xbmcaddon.Addon('inputstream.adaptive')
        return True
    except Exception:
        return False


def render_results(handle, query):
    query = (query or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", f"Buscando en PeerTube: {query}...")
    try:
        results = search(query)
        dp.close()
    except (urllib.error.URLError, OSError, ValueError) as e:
        dp.close()
        xbmc.log(f"[EspaTV] Error buscando en PeerTube: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("EspaTV", f"Error al buscar en PeerTube:\n{e}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if not results:
        xbmcgui.Dialog().ok("EspaTV", f"No se encontraron resultados para:\n{query}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    addon_url = sys.argv[0]
    xbmcplugin.setContent(handle, 'videos')
    for r in results:
        play_url = addon_url + '?' + urllib.parse.urlencode(
            {'action': 'peertube_play', 'uuid': r['uuid']})
        thumb = r["thumb"] or "DefaultMusicVideos.png"

        li = xbmcgui.ListItem(label=r["title"])
        li.setArt({'icon': 'DefaultMusicVideos.png', 'thumb': thumb,
                   'poster': thumb, 'fanart': thumb})
        plot_lines = []
        if r.get("channel"):
            plot_lines.append(f"Canal: {r['channel']}")
        if r.get("host"):
            plot_lines.append(f"Instancia: {r['host']}")
        dur = _fmt_duration(r.get("duration", 0))
        if dur:
            plot_lines.append(f"Duración: {dur}")
        if r.get("description"):
            plot_lines.append(r["description"][:200])
        li.setInfo('video', {'plot': "\n".join(plot_lines) or r["title"],
                             'title': r["title"], 'duration': r.get("duration", 0),
                             'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')
        xbmcplugin.addDirectoryItem(handle=handle, url=play_url,
                                    listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle)

