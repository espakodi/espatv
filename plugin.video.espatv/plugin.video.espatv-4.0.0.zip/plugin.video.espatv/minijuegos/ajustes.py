# -*- coding: utf-8 -*-
# EspaTV, Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Los ajustes de los minijuegos como botones, dentro de Configuración.

Son ajustes nativos de Kodi, así que este menú y la pestaña Minijuegos de los ajustes del addon
leen y cambian lo mismo.
"""
import xbmc
import xbmcaddon
import xbmcgui

import ui_utils
from minijuegos import lista

_PIE = 'Lo mismo está en la pestaña Minijuegos de los ajustes del addon.'
_NUNCA = '2'
# Los que solo cuentan con los mandos en pantalla: con "Nunca" no se enseñan
_DE_LOS_MANDOS = ('juegos_sensibilidad_tactil', 'juegos_mandos_grandes',
                  'juegos_disparo_automatico')

# (ajuste nativo, rótulo, opciones o None si es sí/no, explicación)
_AJUSTES = (
    ('juegos_separadores', 'Minijuego al pulsar un separador', None,
     'Los separadores de los menús esconden un easter egg. Al pulsar uno se ofrece uno de los '
     'catorce minijuegos al azar. Apágalo si los pulsas sin querer.'),
    ('juegos_dificultad', 'Dificultad', ('Normal', 'Difícil', 'Experto', 'Demencial'),
     'Solo Normal deja los juegos exactamente como han sido siempre. Los niveles duros aceleran, '
     'dan menos vidas o dejan menos hueco, cada juego a su manera; 2048, Memoria y Solitario no '
     'cambian. Cada nivel guarda su propio récord, así que una marca de Experto no compite con '
     'una de Normal.'),
    ('juegos_mandos_tactiles', 'Mandos en pantalla', ('Automático', 'Siempre', 'Nunca'),
     'Dibuja una cruceta y un botón de acción sobre el juego para poder jugar con los dedos. En '
     'automático salen en móviles y tabletas; en un ordenador con pantalla táctil salen la '
     'primera vez que deslizas el dedo.'),
    ('juegos_sensibilidad_tactil', 'Sensibilidad de los mandos', ('Lenta', 'Normal', 'Rápida'),
     'A qué velocidad se repite una flecha mantenida en los mandos en pantalla. No cambia el '
     'teclado ni el mando, que repiten por su cuenta.'),
    ('juegos_mandos_grandes', 'Mandos extragrandes', None,
     'Agranda la cruceta y el botón de acción, para pantallas pequeñas o si te cuesta acertar. '
     'Crecen hacia el centro y se quedan anclados en su esquina. También se cambia desde la '
     'rueda dentada sin salir de la partida.'),
    ('juegos_disparo_automatico', 'Las naves disparan solas con los dedos', None,
     'En Invaders y Galaga. Kodi no dice dónde está el segundo dedo, así que pulsar la cruceta y '
     'el botón a la vez no se puede detectar, y sin esto habría que elegir entre moverse o '
     'disparar. Con teclado y mando no cambia nada.'),
    ('juegos_mostrar_rendimiento', 'Contador de rendimiento', None,
     'Enseña cuatro números arriba a la izquierda mientras juegas: los pasos por segundo que da '
     'el juego y los que pedía, lo que tarda un paso, los fotogramas por segundo de Kodi y '
     'cuántas veces ha recogido basura Python. También se apuntan en rendimiento.log, en la '
     'carpeta minijuegos de los datos del addon, y ese fichero se borra en la primera partida '
     'con el contador apagado.'),
)


def _indice(valor, opciones):
    try:
        indice = int(valor)
    except ValueError:
        return 0
    return indice if 0 <= indice < len(opciones) else 0


def menu():
    ui_utils.visto('minijuegos')
    addon = xbmcaddon.Addon()
    icono = ui_utils.media_icon('adv_minijuegos.png')
    sin_mandos = addon.getSetting('juegos_mandos_tactiles') == _NUNCA
    for clave, rotulo, opciones, explicacion in _AJUSTES:
        if clave in _DE_LOS_MANDOS:
            if sin_mandos:
                continue
            rotulo = f'   {rotulo}'
        valor = addon.getSetting(clave)
        if opciones:
            estado = f'[COLOR green]{opciones[_indice(valor, opciones)]}[/COLOR]'
            pulsar = 'Pulsa para elegir.'
        else:
            estado = '[COLOR green]SÍ[/COLOR]' if valor == 'true' else '[COLOR gray]NO[/COLOR]'
            pulsar = 'Pulsa para cambiar.'
        ui_utils.add_item(action='minijuegos_ajuste', url=clave, title=f'{rotulo}: {estado}',
                          thumbnail=icono, folder=False,
                          plot=f'{explicacion}\n\n{_PIE}\n\n[I]{pulsar}[/I]')
    ui_utils.add_item(action='minijuegos_borrar_record', title='Borrar un récord',
                      thumbnail=icono, folder=False,
                      plot='Abre la lista de juegos con marca guardada, para borrar el que elijas '
                           f'o todos.\n\n{_PIE}')
    ui_utils.add_item(action='minijuegos_acceso_directo', title='Acceso directo a minijuegos',
                      thumbnail=icono, folder=False,
                      plot='Acceso directo a los 14 minijuegos clásicos.\n\n'
                           'Requiere el código secreto de 4 cifras publicado en Telegram '
                           '(t.me/espadaily) en el anuncio de la versión que los introdujo en EspaTV (v3.0.0), '
                           f'para no arruinar la sorpresa del easter egg en los menús.\n\n{_PIE}')
    ui_utils.close_item_list()


def cambiar(clave):
    ajuste = next((a for a in _AJUSTES if a[0] == clave), None)
    if ajuste is None:
        return
    _clave, rotulo, opciones, _explicacion = ajuste
    addon = xbmcaddon.Addon()
    if opciones:
        elegido = xbmcgui.Dialog().select(rotulo, list(opciones),
                                          preselect=_indice(addon.getSetting(clave), opciones))
        if elegido < 0:
            return
        addon.setSetting(clave, str(elegido))
        nuevo = opciones[elegido]
    else:
        activo = addon.getSetting(clave) != 'true'
        addon.setSetting(clave, 'true' if activo else 'false')
        nuevo = 'SÍ' if activo else 'NO'
    xbmcgui.Dialog().notification(lista.TITULO, f'{rotulo}: {nuevo}')
    xbmc.executebuiltin('Container.Refresh')


def acceso_directo():
    dialogo = xbmcgui.Dialog()
    seguro = dialogo.yesno(
        "Acceso directo a minijuegos",
        "Al abrir los minijuegos desde aquí se pierde la gracia del easter egg oculto en los separadores de los menús.\n\n"
        "Para desbloquear el acceso directo necesitas el código de 4 cifras que acompaña al anuncio en Telegram (t.me/espadaily) de la versión que los introdujo en EspaTV (v3.0.0).\n\n"
        "¿Quieres continuar e introducir el código?",
        nolabel="Cancelar",
        yeslabel="Continuar"
    )
    if not seguro:
        return

    codigo = dialogo.input("Introduce el código secreto (4 cifras):", type=xbmcgui.INPUT_NUMERIC)
    if codigo != "0451":
        dialogo.notification("EspaTV", "Código incorrecto. Búscalo en t.me/espadaily", xbmcgui.NOTIFICATION_WARNING, 3500)
        return

    nombres = ["Partida al azar"] + [j.nombre for j in lista.JUEGOS]
    elegido = dialogo.select("Selecciona un minijuego", nombres)
    if elegido < 0:
        return
    if elegido == 0:
        import random
        juego = random.choice(lista.JUEGOS)
        lista.abrir(juego.id)
    else:
        juego = lista.JUEGOS[elegido - 1]
        lista.abrir(juego.id)

