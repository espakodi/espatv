# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Búsqueda y resolución de stream en BitChute."""
import hashlib
import html
import json
import os
import re
import sys
import threading
import time
import unicodedata
import urllib.parse
import urllib.request
import urllib.error

import xbmc
import xbmcgui
import xbmcplugin
import xbmcvfs

_API_SEARCH = "https://api.bitchute.com/api/beta/search/videos"
_API_MEDIA = "https://api.bitchute.com/api/beta/video/media"

_HEADERS = {
    "User-Agent": "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 "
                  "(KHTML, like Gecko) Chrome/123.0.0.0 Safari/537.36",
    "Accept": "application/json",
    "Content-Type": "application/json",
    "Referer": "https://www.bitchute.com/",
}

_CACHE_DIR = xbmcvfs.translatePath(
    "special://userdata/addon_data/plugin.video.espatv/search_cache/")
_CACHE_TTL = 3600  # segundos

_TAG_RX = re.compile(r"<[^>]+>")

_STOPWORDS = {
    "los", "las", "una", "unos", "unas", "con", "por", "para", "que", "del",
    "como", "este", "esta", "esto", "esos", "esas", "sus", "mas", "muy", "sin",
    "son", "the", "and", "for", "you", "that", "this", "with", "from", "what",
}


def _cache_get(key):
    path = os.path.join(_CACHE_DIR, key + ".json")
    try:
        if time.time() - os.path.getmtime(path) > _CACHE_TTL:
            return None
        with open(path, encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return None


def _cache_set(key, data):
    try:
        os.makedirs(_CACHE_DIR, exist_ok=True)
        tmp = os.path.join(_CACHE_DIR, f"{key}.{os.getpid()}_{threading.get_ident()}.tmp")
        with open(tmp, "w", encoding="utf-8") as f:
            json.dump(data, f)
        os.replace(tmp, os.path.join(_CACHE_DIR, key + ".json"))
    except OSError:
        pass


def _post_json(url, payload, timeout=15):
    body = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=body, headers=_HEADERS, method="POST")
    with urllib.request.urlopen(req, timeout=timeout) as resp:
        return json.loads(resp.read().decode("utf-8", errors="replace"))


def _norm(s):
    s = (s or "").lower()
    return "".join(c for c in unicodedata.normalize("NFKD", s)
                   if not unicodedata.combining(c))


def _strip_html(s):
    return _TAG_RX.sub(" ", s or "").strip()


def _parse_dur(s):
    if not s:
        return 0
    try:
        secs = 0
        for part in str(s).strip().split(":"):
            secs = secs * 60 + int(part)
        return secs
    except ValueError:
        return 0


def _fmt_duration(secs):
    if not isinstance(secs, int) or secs <= 0:
        return ""
    h, rem = divmod(secs, 3600)
    m, s = divmod(rem, 60)
    return f"{h}:{m:02d}:{s:02d}" if h else f"{m}:{s:02d}"


def _filter_relevant(query, results):
    # Cuando una búsqueda en español no tiene coincidencias, BitChute devuelve vídeos
    # recientes en inglés sin relación con la consulta.
    tokens = [t for t in _norm(query).split() if len(t) > 2 and t not in _STOPWORDS]
    if not tokens:
        return results
    out = []
    for r in results:
        texto = _norm(f"{r['title']} {r['channel']} {r['description']}")
        if any(t in texto for t in tokens):
            out.append(r)
    return out


def search(query):
    query = (query or "").strip()
    if not query:
        return []
    key = "bitchute_" + hashlib.md5(query.lower().encode()).hexdigest()[:16]
    cached = _cache_get(key)
    if cached is not None:
        return cached

    payload = {"query": query, "sensitivity_id": "normal", "sort": "new", "offset": 0}
    try:
        data = _post_json(_API_SEARCH, payload)
    except Exception as ex:
        xbmc.log(f"[EspaTV] BitChute search failed: {ex}", xbmc.LOGWARNING)
        return []
    items = data.get("videos") if isinstance(data, dict) else None
    results = []
    for v in (items or []):
        vid = v.get("video_id")
        if not vid:
            continue
        ch = v.get("channel")
        channel = ch.get("channel_name", "") if isinstance(ch, dict) else ""
        results.append({
            "video_id": vid,
            "title": html.unescape(v.get("video_name", "") or ""),
            "channel": html.unescape(channel),
            "thumb": v.get("thumbnail_url", ""),
            "duration": _parse_dur(v.get("duration", "")),
            "description": html.unescape(_strip_html(v.get("description", ""))),
        })
    results = _filter_relevant(query, results)
    _cache_set(key, results)
    return results


def resolve_stream(video_id):
    if not video_id:
        return ""
    try:
        data = _post_json(_API_MEDIA, {"video_id": video_id})
    except urllib.error.HTTPError as e:
        if e.code == 404:
            return ""
        raise
    return data.get("media_url", "") if isinstance(data, dict) else ""


def play_item(handle, video_id):
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Resolviendo stream de BitChute...")
    try:
        stream_url = resolve_stream(video_id)
        dp.close()
    except (urllib.error.URLError, OSError, ValueError) as e:
        dp.close()
        xbmc.log(f"[EspaTV] Error resolviendo BitChute: {e}", xbmc.LOGERROR)
        if handle >= 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok("EspaTV", f"Error al resolver el stream:\n{e}")
        return

    if not stream_url:
        if handle >= 0:
            xbmcplugin.setResolvedUrl(handle, False, xbmcgui.ListItem())
        xbmcgui.Dialog().ok("EspaTV", "No se pudo obtener la URL de reproducción de BitChute.")
        return

    xbmc.log(f"[EspaTV] BitChute stream: {stream_url}", xbmc.LOGINFO)
    li = xbmcgui.ListItem(path=stream_url)
    if stream_url.lower().split("?")[0].endswith(".m3u8"):
        li.setProperty('inputstream', 'inputstream.adaptive')
        li.setProperty('inputstreamaddon', 'inputstream.adaptive')
        li.setProperty('inputstream.adaptive.manifest_type', 'hls')
        li.setContentLookup(False)
    if handle >= 0:
        xbmcplugin.setResolvedUrl(handle, True, li)
    else:
        xbmc.Player().play(li.getPath(), li)


def render_results(handle, query):
    query = (query or "").strip()
    if not query:
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", f"Buscando en BitChute: {query}...")
    try:
        results = search(query)
        dp.close()
    except (urllib.error.URLError, OSError, ValueError) as e:
        dp.close()
        xbmc.log(f"[EspaTV] Error buscando en BitChute: {e}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("EspaTV", f"Error al buscar en BitChute:\n{e}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    if not results:
        xbmcgui.Dialog().ok("EspaTV", f"No se encontraron resultados para:\n{query}")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return

    addon_url = sys.argv[0]
    xbmcplugin.setContent(handle, 'videos')
    for r in results:
        play_url = addon_url + '?' + urllib.parse.urlencode(
            {'action': 'bitchute_play', 'video_id': r['video_id']})
        thumb = r["thumb"] or "DefaultMusicVideos.png"

        li = xbmcgui.ListItem(label=r["title"])
        li.setArt({'icon': 'DefaultMusicVideos.png', 'thumb': thumb,
                   'poster': thumb, 'fanart': thumb})
        plot_lines = []
        if r.get("channel"):
            plot_lines.append(f"Canal: {r['channel']}")
        dur = _fmt_duration(r.get("duration", 0))
        if dur:
            plot_lines.append(f"Duración: {dur}")
        if r.get("description"):
            plot_lines.append(r["description"][:300])
        li.setInfo('video', {'plot': "\n".join(plot_lines) or r["title"],
                             'title': r["title"], 'duration': r.get("duration", 0),
                             'mediatype': 'video'})
        li.setProperty('IsPlayable', 'true')

        xbmcplugin.addDirectoryItem(handle=handle, url=play_url,
                                    listitem=li, isFolder=False)
    xbmcplugin.endOfDirectory(handle)

