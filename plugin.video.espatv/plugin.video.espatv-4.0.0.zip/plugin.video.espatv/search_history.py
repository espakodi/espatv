# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Historial de búsquedas de Dailymotion y YouTube."""
import json
import os
import sys
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _get_history_file():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))
    if not os.path.exists(p):
        os.makedirs(p, exist_ok=True)
    return os.path.join(p, 'search_history.json')


def load():
    f = _get_history_file()
    if not os.path.exists(f):
        return []
    try:
        with open(f, 'r', encoding='utf-8') as o:
            datos = json.load(o)
    except (OSError, ValueError) as e:
        xbmc.log("[EspaTV] Error loading history: {0}".format(e), xbmc.LOGERROR)
        return []
    # Un JSON válido de otra forma (una copia editada a mano) tumbaba el menú sin cerrarlo.
    return [q for q in datos if isinstance(q, str)] if isinstance(datos, list) else []


def add(q):
    q = q.strip()
    if not q:
        return
    h = load()
    if q in h:
        h.remove(q)
    h.insert(0, q)
    h = h[:50]
    core_settings.atomic_write_json(_get_history_file(), h)


def menu(skip_end=False):
    import yt_search as _yts
    addon = xbmcaddon.Addon()
    _mp = os.path.join(addon.getAddonInfo('path'), 'resources', 'media')
    def _ico(name, fallback):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    li_cat = xbmcgui.ListItem(label="[B][Categorías / Carpetas][/B]")
    _cat_art = _ico('catalogo.png', 'DefaultAddonService.png')
    li_cat.setArt({'icon': _cat_art, 'thumb': _cat_art, 'poster': _cat_art})
    li_cat.setInfo('video', {'plot': "Accede a tus carpetas y categorías personalizadas."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="cat_menu"), listitem=li_cat, isFolder=True)

    _dm_art = _ico('dailymotion.png', 'DefaultFolder.png')
    h_dm = load()
    dm_plot = "Historial de términos buscados en Dailymotion."
    if h_dm:
        dm_plot += " ({0} búsquedas guardadas)".format(len(h_dm))
    li_dm = xbmcgui.ListItem(label="[B]Historial de búsqueda Dailymotion[/B]")
    li_dm.setArt({'icon': _dm_art, 'thumb': _dm_art, 'poster': _dm_art})
    li_dm.setInfo('video', {'plot': dm_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_history_dm"), listitem=li_dm, isFolder=True)

    _yt_art = _ico('youtube.png', 'DefaultMusicVideos.png')
    h_yt = _yts.load_yt_history()
    yt_plot = "Historial de términos buscados en YouTube."
    if h_yt:
        yt_plot += " ({0} búsquedas guardadas)".format(len(h_yt))
    li_yt = xbmcgui.ListItem(label="[B]Historial de búsqueda YouTube[/B]")
    li_yt.setArt({'icon': _yt_art, 'thumb': _yt_art, 'poster': _yt_art})
    li_yt.setInfo('video', {'plot': yt_plot})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url=_u(action="search_history_yt"), listitem=li_yt, isFolder=True)

    _info_art = _ico('info.png', 'DefaultIconInfo.png')
    li_nota = xbmcgui.ListItem(label="[COLOR blue][I]Nota: Puedes borrar elementos individuales con clic derecho[/I][/COLOR]")
    li_nota.setArt({'icon': _info_art, 'thumb': _info_art, 'poster': _info_art})
    li_nota.setInfo('video', {'plot': "Tanto en el historial de visionado como en las búsquedas de Dailymotion o YouTube puedes usar el menú contextual o clic derecho sobre cualquier elemento para borrarlo individualmente."})
    xbmcplugin.addDirectoryItem(handle=int(sys.argv[1]), url="", listitem=li_nota, isFolder=False)

    if not skip_end:
        xbmcplugin.endOfDirectory(int(sys.argv[1]))


def menu_dm():
    h = load()
    addon = xbmcaddon.Addon()
    icon = addon.getAddonInfo('icon')
    _mp = os.path.join(addon.getAddonInfo('path'), 'resources', 'media')
    def _ico(name, fallback):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    handle_id = int(sys.argv[1])
    _borrar_ico = _ico('adv_borrar.png', 'DefaultIconError.png')
    _info_ico = _ico('info.png', 'DefaultIconInfo.png')
    _search_ico = _ico('busqueda.png', 'DefaultFolder.png')

    if not h:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay historial de búsqueda en Dailymotion[/COLOR]")
        li.setArt({'icon': _info_ico, 'thumb': _info_ico, 'poster': _info_ico})
        li.setInfo('video', {'plot': "No hay términos guardados en el historial de búsqueda de Dailymotion."})
        xbmcplugin.addDirectoryItem(handle=handle_id, url="", listitem=li, isFolder=False)
    else:
        li_del = xbmcgui.ListItem(label="[COLOR red][B]Borrar historial de búsqueda Dailymotion...[/B][/COLOR]")
        li_del.setArt({'icon': _borrar_ico, 'thumb': _borrar_ico, 'poster': _borrar_ico})
        li_del.setInfo('video', {'plot': "Gestiona o vacía las {0} búsquedas guardadas de Dailymotion.".format(len(h))})
        xbmcplugin.addDirectoryItem(handle=handle_id, url=_u(action="clear_history"), listitem=li_del, isFolder=False)

        for q in h:
            li = xbmcgui.ListItem(label="[COLOR lime][DM][/COLOR] {0}".format(q))
            li.setArt({'icon': _search_ico, 'thumb': _search_ico, 'poster': _search_ico})
            li.setInfo('video', {'plot': "Buscar en Dailymotion: {0}".format(q)})
            try:
                cm = [
                    ("Editar y buscar", "RunPlugin({0})".format(_u(action='edit_and_search', q=q, ot=icon))),
                    ("Añadir a Categoría...", "RunPlugin({0})".format(_u(action='cat_add_item_dialog', q=q))),
                    ("Eliminar de este historial", "RunPlugin({0})".format(_u(action='remove_history_item', q=q)))
                ]
                fav_params = json.dumps({'q': q, 'ot': icon})
                cm.append(("Añadir a Mis Favoritos", "RunPlugin({0})".format(_u(action='add_favorite', title=q, fav_url='lfr_' + q, icon=icon, platform='search', fav_action='lfr', params=fav_params))))
                cm.append(("Buscar en webs de torrent", "RunPlugin({0})".format(_u(action='elementum_search', q=q))))
                li.addContextMenuItems(cm)
            except (TypeError, ValueError) as e:
                xbmc.log("[EspaTV] Error adding CM to history item: {0}".format(e), xbmc.LOGERROR)
            target_url = _u(action="lfr", q=q, ot=icon, nh=1)
            xbmcplugin.addDirectoryItem(handle=handle_id, url=target_url, listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(handle_id)


def menu_yt():
    import yt_search as _yts
    addon = xbmcaddon.Addon()
    _mp = os.path.join(addon.getAddonInfo('path'), 'resources', 'media')
    def _ico(name, fallback):
        p = os.path.join(_mp, name)
        return p if os.path.isfile(p) else fallback

    handle_id = int(sys.argv[1])
    yt_h = _yts.load_yt_history()
    _borrar_ico = _ico('adv_borrar.png', 'DefaultIconError.png')
    _info_ico = _ico('info.png', 'DefaultIconInfo.png')
    _search_ico = _ico('busqueda.png', 'DefaultMusicVideos.png')

    if not yt_h:
        li = xbmcgui.ListItem(label="[COLOR gray]No hay historial de búsqueda en YouTube[/COLOR]")
        li.setArt({'icon': _info_ico, 'thumb': _info_ico, 'poster': _info_ico})
        li.setInfo('video', {'plot': "No hay términos guardados en el historial de búsqueda de YouTube."})
        xbmcplugin.addDirectoryItem(handle=handle_id, url="", listitem=li, isFolder=False)
    else:
        li_del = xbmcgui.ListItem(label="[COLOR red][B]Borrar historial de búsqueda YouTube...[/B][/COLOR]")
        li_del.setArt({'icon': _borrar_ico, 'thumb': _borrar_ico, 'poster': _borrar_ico})
        li_del.setInfo('video', {'plot': "Gestiona o vacía las {0} búsquedas guardadas de YouTube.".format(len(yt_h))})
        xbmcplugin.addDirectoryItem(handle=handle_id, url=_u(action="clear_yt_history"), listitem=li_del, isFolder=False)

        for q in yt_h:
            li = xbmcgui.ListItem(label="[COLOR red][YT][/COLOR] {0}".format(q))
            li.setArt({'icon': _search_ico, 'thumb': _search_ico, 'poster': _search_ico})
            li.setInfo('video', {'plot': "Buscar en YouTube: {0}".format(q)})
            cm = [
                ("Eliminar de este historial", "RunPlugin({0})".format(_u(action="remove_yt_history_item", q=q))),
                ("Editar y buscar", "RunPlugin({0})".format(_u(action="yt_edit_and_search", q=q))),
                ("Buscar en webs de torrent", "RunPlugin({0})".format(_u(action="elementum_search", q=q)))
            ]
            li.addContextMenuItems(cm)
            xbmcplugin.addDirectoryItem(handle=handle_id, url=_u(action="yt_search_results", query=q), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(handle_id)


def clear():
    h = load()
    if not h:
        return
    opts = ["Borrar TODO el historial", "Elegir elementos a borrar", "[COLOR red]Cancelar[/COLOR]"]
    sel = xbmcgui.Dialog().select("Limpiar Historial de Búsquedas Dailymotion", opts)
    if sel == 0:
        if xbmcgui.Dialog().yesno("Confirmar", "¿Estás seguro de que quieres vaciar TODO el historial de búsqueda de Dailymotion?"):
            core_settings.atomic_write_json(_get_history_file(), [])
            xbmcgui.Dialog().notification("EspaTV", "Historial Dailymotion vaciado", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
    elif sel == 1:
        chosen = xbmcgui.Dialog().multiselect("Marca las búsquedas a eliminar", h)
        if chosen:
            new_h = [item for i, item in enumerate(h) if i not in chosen]
            core_settings.atomic_write_json(_get_history_file(), new_h)
            xbmc.executebuiltin("Container.Refresh")


def remove(q):
    h = load()
    if q in h:
        h.remove(q)
        core_settings.atomic_write_json(_get_history_file(), h)
    xbmc.executebuiltin("Container.Refresh")
