# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Punto de entrada del puente YouTube hacia EspaTV.
Captura llamadas dirigidas a plugin.video.youtube y las despacha al resolver de EspaTV.
"""

import os
import re
import sys
import urllib.parse

try:
    import xbmc
    import xbmcgui
    import xbmcplugin
    import xbmcvfs
except ImportError:
    xbmc = None
    xbmcgui = None
    xbmcplugin = None
    xbmcvfs = None

_ID = r"[0-9A-Za-z_-]{11}"
_ID_RE = re.compile(rf"^{_ID}$")
_PATH_ID_RE = re.compile(rf"/play/({_ID})(?![0-9A-Za-z_-])")
_URL_ID_RE = re.compile(
    rf"(?:(?<![0-9A-Za-z_])v=|youtu\.be/|/vi/|/shorts/|/live/|/embed/)({_ID})(?![0-9A-Za-z_-])"
)


def extract_video_id(args):
    """Extrae el ID de video de YouTube a partir de los argumentos de invocacion de Kodi.

    Solo reconoce rutas /play/<id>, los parametros video_id/videoid/v y una URL de YouTube
    dentro de url/uri. Cualquier otra llamada (listados, busquedas, playlists) devuelve "".
    """
    for arg in args:
        path, _, qs = arg.partition("?")
        m = _PATH_ID_RE.search(path)
        if m:
            return m.group(1)

        params = urllib.parse.parse_qs(qs)
        for key in ("video_id", "videoid", "v"):
            for cand in params.get(key, ()):
                cand = cand.strip()
                if _ID_RE.match(cand):
                    return cand
        for key in ("url", "uri"):
            for value in params.get(key, ()):
                m = _URL_ID_RE.search(value)
                if m:
                    return m.group(1)
    return ""


def _is_root_call(args):
    path = args[0] if args else ""
    query = args[2] if len(args) > 2 else ""
    return path.rstrip("/") == "plugin://plugin.video.youtube" and not query.strip("?")


def _root_menu(h):
    """Lo que se ve al abrir el addon a mano: el puente no navega YouTube, así que se explica
    y se ofrecen las dos salidas."""
    plot = ("Este addon es el puente de EspaTV: reproduce los vídeos de YouTube que abren otros "
            "addons y skins, pero no navega, no busca ni inicia sesión.")
    media = "special://home/addons/plugin.video.espatv/resources/media/"
    items = (
        ("Abrir YouTube en EspaTV", "plugin://plugin.video.espatv/?action=yt_hub_menu", True,
         media + "youtube.png"),
        ("Desactivar el puente y volver a tu addon de YouTube",
         "plugin://plugin.video.espatv/?action=yt_bridge_toggle", False,
         media + "bkp_restaurar.png"),
    )
    for label, url, is_folder, icon in items:
        li = xbmcgui.ListItem(label=label)
        li.setArt({"icon": icon, "thumb": icon, "poster": icon})
        li.setInfo("video", {"plot": plot})
        xbmcplugin.addDirectoryItem(h, url, li, isFolder=is_folder)
    xbmcplugin.endOfDirectory(h, cacheToDisc=False)


def main():
    h = -1
    if len(sys.argv) > 1:
        try:
            h = int(sys.argv[1])
        except (ValueError, TypeError):
            h = -1

    video_id = extract_video_id(sys.argv)

    if not video_id:
        if h >= 0 and xbmcplugin and _is_root_call(sys.argv):
            _root_menu(h)
            return
        if xbmc:
            xbmc.log(f"[Puente YouTube] Invocación sin video_id reconocible: {sys.argv}", xbmc.LOGWARNING)
        # Con handle no se avisa en pantalla porque los widgets de las skins repiten estas llamadas
        if h >= 0 and xbmcplugin:
            xbmcplugin.endOfDirectory(h, succeeded=False)
        elif xbmcgui:
            xbmcgui.Dialog().notification("Puente YouTube", "El puente solo reproduce vídeos",
                                          xbmcgui.NOTIFICATION_WARNING)
        return

    espatv_addon_path = ""
    if xbmcvfs:
        espatv_addon_path = xbmcvfs.translatePath("special://home/addons/plugin.video.espatv")
    if not espatv_addon_path or not os.path.isdir(espatv_addon_path):
        appdata = os.environ.get("APPDATA", "")
        if appdata:
            cand = os.path.join(appdata, "Kodi", "addons", "plugin.video.espatv")
            if os.path.isdir(cand):
                espatv_addon_path = cand

    # Al final: EspaTV tiene modulos con nombres genericos que no deben tapar los de otros addons
    if espatv_addon_path and espatv_addon_path not in sys.path:
        sys.path.append(espatv_addon_path)

    try:
        import yt_resolver
    except Exception as exc:  # cualquier fallo al importar debe cerrar el handle, no solo ImportError
        if xbmc:
            xbmc.log(f"[Puente YouTube] Error importando yt_resolver desde {espatv_addon_path}: {exc}", xbmc.LOGERROR)
        if h >= 0 and xbmcplugin:
            xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem(label=video_id))
        elif xbmcgui:
            xbmcgui.Dialog().notification("Puente YouTube", "EspaTV no está disponible", xbmcgui.NOTIFICATION_ERROR)
        return

    # play_video ya cierra el handle (resuelto o fallido); aqui solo se cubre que lance una excepcion
    try:
        yt_resolver.play_video(
            video_id,
            title="",
            audio_only=False,
            use_resolved_url=(h >= 0),
            allow_addon_fallback=False,
        )
    except Exception as exc:  # play_video toca red, disco y Kodi; un fallo no debe dejar el handle abierto
        if xbmc:
            xbmc.log(f"[Puente YouTube] Error no controlado en play_video: {exc}", xbmc.LOGERROR)
        if h >= 0 and xbmcplugin:
            try:
                xbmcplugin.setResolvedUrl(h, False, xbmcgui.ListItem(label=video_id))
            except (RuntimeError, TypeError):
                pass


if __name__ == "__main__":
    main()
