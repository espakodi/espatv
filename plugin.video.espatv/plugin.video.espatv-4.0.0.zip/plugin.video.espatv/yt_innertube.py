# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Cliente ligero InnerTube para búsqueda, navegación de canales, playlists y feed RSS."""

import concurrent.futures
import gzip
import hashlib
import json
import os
import re
import time
import urllib.error
import urllib.parse
import urllib.request
import xml.etree.ElementTree as ET

try:
    import xbmc
    import xbmcaddon
    import xbmcvfs
except ImportError:
    xbmc = None
    xbmcaddon = None
    xbmcvfs = None

from _user_agents import desktop_headers as _dh
import core_settings


_TIMEOUT = 12
_ATOM_NS = {
    "atom": "http://www.w3.org/2005/Atom",
    "yt": "http://www.youtube.com/xml/schemas/2015",
    "media": "http://search.yahoo.com/mrss/",
}


def _log(msg, level=None):
    if xbmc:
        lvl = level if level is not None else getattr(xbmc, "LOGWARNING", 3)
        xbmc.log(f"[EspaTV/yt_innertube] {msg}", lvl)


def _get_cache_dir():
    base = ""
    if xbmcvfs and xbmcaddon:
        try:
            base = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
        except (RuntimeError, AttributeError):
            base = ""
    if not base or base.startswith("special://"):
        base = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tmp")
    p = os.path.join(base, "yt_cache")
    if not os.path.exists(p):
        try:
            os.makedirs(p, exist_ok=True)
        except OSError:
            pass
    return p


def _read_cache(key, ttl):
    if ttl <= 0:
        return None
    cpath = os.path.join(_get_cache_dir(), f"{key}.json")
    if not os.path.isfile(cpath):
        return None
    try:
        with open(cpath, "r", encoding="utf-8") as f:
            entry = json.load(f)
            if (time.time() - entry.get("ts", 0)) < ttl:
                return entry.get("data")
    except (OSError, ValueError) as exc:
        _log(f"Error leyendo caché {key}: {exc}")
    return None


def _write_cache(key, data):
    cpath = os.path.join(_get_cache_dir(), f"{key}.json")
    try:
        core_settings.atomic_write_json(cpath, {"ts": int(time.time()), "data": data})
    except (OSError, ValueError) as exc:
        _log(f"Error escribiendo caché {key}: {exc}")


_EMOJI_RE = re.compile(r"[\U00010000-\U0010ffff\u2600-\u27bf\ud83c-\ud83e]", flags=re.UNICODE)


def _clean_text(s):
    if not s:
        return ""
    s = _EMOJI_RE.sub("", str(s))
    return " ".join(s.split()).strip()


def _extract_text(obj):
    if not obj:
        return ""
    text = ""
    if isinstance(obj, str):
        text = obj
    elif isinstance(obj, dict):
        if "simpleText" in obj:
            text = obj["simpleText"]
        elif "runs" in obj and isinstance(obj["runs"], list):
            text = "".join(r.get("text", "") for r in obj["runs"] if isinstance(r, dict))
        elif "content" in obj:
            text = str(obj["content"])
    return _clean_text(text)


def _extract_thumb_url(obj, default=""):
    if not isinstance(obj, dict):
        return default
    thumbs = obj.get("thumbnails") or obj.get("sources")
    if not thumbs and isinstance(obj.get("thumbnail"), dict):
        thumbs = obj["thumbnail"].get("thumbnails")
    if not thumbs and isinstance(obj.get(" thumbnails"), list):
        thumbs = obj[" thumbnails"]
    if isinstance(thumbs, list) and thumbs:
        url = thumbs[-1].get("url", "")
        if url.startswith("//"):
            url = "https:" + url
        return url or default
    return default


def _parse_lockup(lvm):
    if not isinstance(lvm, dict):
        return None
    content_type = lvm.get("contentType", "")
    content_id = lvm.get("contentId", "")

    tap_cmd = (
        lvm.get("commandContext", {})
        .get("onTap", {})
        .get("innertubeCommand", {})
    )
    watch_ep = tap_cmd.get("watchEndpoint", {})
    browse_ep = tap_cmd.get("browseEndpoint", {})

    meta = lvm.get("metadata", {}).get("lockupMetadataViewModel", {})
    title = meta.get("title", {}).get("content", "")
    if not title:
        title = lvm.get("rendererContext", {}).get("accessibilityContext", {}).get("label", "")
    title = _clean_text(title)

    img_model = (
        lvm.get("contentImage", {})
        .get("collectionThumbnailViewModel", {})
        .get("primaryThumbnail", {})
        .get("thumbnailViewModel", {})
        .get("image", {})
    ) or (
        lvm.get("contentImage", {})
        .get("thumbnailViewModel", {})
        .get("image", {})
    )
    lockup_thumb = _extract_thumb_url(img_model, "")

    if content_type == "LOCKUP_CONTENT_TYPE_PLAYLIST" or (content_id and (content_id.startswith("PL") or content_id.startswith("VL"))):
        pid = content_id or watch_ep.get("playlistId", "") or browse_ep.get("browseId", "")
        if pid:
            return {
                "type": "playlist",
                "playlist_id": pid,
                "title": title or pid,
                "count": "",
                "thumb": lockup_thumb or "DefaultVideoPlaylists.png",
            }

    vid = content_id or watch_ep.get("videoId", "")
    if vid and len(vid) == 11:
        duration = ""
        is_live = False
        overlays = lvm.get("contentImage", {}).get("thumbnailViewModel", {}).get("overlays", [])
        for ov in overlays:
            bottom = ov.get("thumbnailBottomOverlayViewModel", {})
            for badge in bottom.get("badges", []):
                t_badge = badge.get("thumbnailBadgeViewModel", {})
                b_style = t_badge.get("badgeStyle", "")
                b_text = t_badge.get("text", "")
                if "LIVE" in b_style or b_text in ("DIRECTO", "EN DIRECTO", "LIVE"):
                    is_live = True
                    duration = "Directo"
                elif b_text and not duration:
                    duration = _clean_text(b_text)

        meta_lines = []
        for row in meta.get("metadataRows", []):
            for part in row.get("metadataParts", []):
                t = _clean_text(part.get("text", {}).get("content", ""))
                if t:
                    meta_lines.append(t)
        views = meta_lines[0] if len(meta_lines) > 0 else ""
        published = meta_lines[1] if len(meta_lines) > 1 else ""
        channel = ""
        if len(meta_lines) > 2:
            channel = meta_lines[0]
            views = meta_lines[1]
            published = meta_lines[2]

        return {
            "type": "video",
            "vid": vid,
            "title": title or "Vídeo",
            "channel": channel,
            "channel_id": "",
            "duration": duration,
            "views": views,
            "published": published,
            "is_live": is_live,
            "thumb": f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg",
        }
    return None


def _post_innertube(endpoint, payload, ttl=0):
    cache_key = None
    if ttl > 0:
        payload_str = json.dumps(payload, sort_keys=True)
        cache_key = hashlib.md5(f"{endpoint}|{payload_str}".encode("utf-8")).hexdigest()
        cached = _read_cache(cache_key, ttl)
        if cached is not None:
            return cached

    url = f"https://www.youtube.com/youtubei/v1/{endpoint}?prettyPrint=false"
    headers = _dh(accept="application/json")
    headers["Content-Type"] = "application/json"
    headers["Accept-Encoding"] = "gzip"

    data = json.dumps(payload).encode("utf-8")
    req = urllib.request.Request(url, data=data, headers=headers)
    try:
        with urllib.request.urlopen(req, timeout=_TIMEOUT) as resp:
            raw = resp.read()
            if (
                resp.info().get("Content-Encoding") == "gzip"
                or (len(raw) >= 2 and raw[:2] == b"\x1f\x8b")
            ):
                raw = gzip.decompress(raw)
            parsed = json.loads(raw.decode("utf-8", errors="replace"))
            if cache_key and parsed:
                _write_cache(cache_key, parsed)
            return parsed
    except (urllib.error.URLError, ValueError, OSError) as exc:
        _log(f"Error en {endpoint}: {exc}")
        return None


def _base_context():
    return {
        "client": {
            "clientName": "WEB",
            "clientVersion": "2.20260115.01.00",
            "hl": "es",
            "gl": "ES",
        }
    }


def search(query, sp="", continuation="", ttl=600):
    payload = {"context": _base_context()}
    if continuation:
        payload["continuation"] = continuation
    else:
        payload["query"] = query
        if sp:
            payload["params"] = urllib.parse.unquote(sp)

    data = _post_innertube("search", payload, ttl=ttl if not continuation else 0)
    if not data:
        return [], ""

    results = []
    next_token = ""

    def _walk(obj):
        nonlocal next_token
        if isinstance(obj, dict):
            if "videoRenderer" in obj:
                vr = obj["videoRenderer"]
                vid = vr.get("videoId", "")
                if vid and len(vid) == 11 and not any(r.get("vid") == vid for r in results):
                    title = _extract_text(vr.get("title"))
                    channel = _extract_text(vr.get("ownerText") or vr.get("longBylineText") or vr.get("shortBylineText"))
                    channel_id = ""
                    owner_runs = (vr.get("ownerText") or vr.get("longBylineText") or {}).get("runs", [])
                    if owner_runs:
                        channel_id = (
                            owner_runs[0]
                            .get("navigationEndpoint", {})
                            .get("browseEndpoint", {})
                            .get("browseId", "")
                        )
                    duration = _extract_text(vr.get("lengthText"))
                    views = _extract_text(vr.get("viewCountText") or vr.get("shortViewCountText"))
                    published = _extract_text(vr.get("publishedTimeText"))
                    results.append({
                        "type": "video",
                        "vid": vid,
                        "title": title or "Vídeo",
                        "channel": channel,
                        "channel_id": channel_id,
                        "duration": duration,
                        "views": views,
                        "published": published,
                        "thumb": f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg",
                    })
            elif "channelRenderer" in obj:
                cr = obj["channelRenderer"]
                cid = cr.get("channelId", "")
                if cid and not any(r.get("channel_id") == cid for r in results):
                    title = _extract_text(cr.get("title"))
                    subs = _extract_text(cr.get("subscriberCountText") or cr.get("videoCountText"))
                    desc = _extract_text(cr.get("descriptionSnippet"))
                    thumb = _extract_thumb_url(cr, "DefaultActor.png")
                    results.append({
                        "type": "channel",
                        "channel_id": cid,
                        "title": title or cid,
                        "subs": subs,
                        "desc": desc,
                        "thumb": thumb,
                    })
            elif "playlistRenderer" in obj:
                pr = obj["playlistRenderer"]
                pid = pr.get("playlistId", "")
                if pid and not any(r.get("playlist_id") == pid for r in results):
                    title = _extract_text(pr.get("title"))
                    count = _extract_text(pr.get("videoCountText") or pr.get("itemCount"))
                    pl_thumb = _extract_thumb_url(pr, "")
                    if not pl_thumb and isinstance(pr.get("thumbnails"), list) and pr["thumbnails"]:
                        pl_thumb = _extract_thumb_url(pr["thumbnails"][0], "")
                    results.append({
                        "type": "playlist",
                        "playlist_id": pid,
                        "title": title or pid,
                        "count": count,
                        "thumb": pl_thumb or "DefaultVideoPlaylists.png",
                    })
            elif "lockupViewModel" in obj:
                item = _parse_lockup(obj["lockupViewModel"])
                if item and not any(
                    (r.get("vid") and r.get("vid") == item.get("vid"))
                    or (r.get("playlist_id") and r.get("playlist_id") == item.get("playlist_id"))
                    for r in results
                ):
                    results.append(item)
            elif "continuationItemRenderer" in obj:
                ep = obj["continuationItemRenderer"].get("continuationEndpoint", {})
                token = ep.get("continuationCommand", {}).get("token", "")
                if token:
                    next_token = token

            for v in obj.values():
                _walk(v)
        elif isinstance(obj, list):
            for it in obj:
                _walk(it)

    _walk(data)
    return results, next_token


def browse_channel(channel_id, tab="videos", continuation="", ttl=900):
    payload = {"context": _base_context()}
    if continuation:
        payload["continuation"] = continuation
    else:
        payload["browseId"] = channel_id
        tab_params = {
            "videos": "EgZ2aWRlb3PyBgQKAjoA",
            "streams": "EgdzdHJlYW1z8gYECgJ6AA==",
            "shorts": "EgZzaG9ydHPyBgUKA5oBAA==",
            "playlists": "EglwbGF5bGlzdHPyBgQKAkIA",
        }
        if tab in tab_params:
            payload["params"] = tab_params[tab]

    data = _post_innertube("browse", payload, ttl=ttl if not continuation else 0)
    if not data:
        return [], ""

    results = []
    next_token = ""

    def _walk(obj):
        nonlocal next_token
        if isinstance(obj, dict):
            if "videoRenderer" in obj or "gridVideoRenderer" in obj:
                vr = obj.get("videoRenderer") or obj.get("gridVideoRenderer")
                vid = vr.get("videoId", "")
                if vid and len(vid) == 11 and not any(r.get("vid") == vid for r in results):
                    title = _extract_text(vr.get("title"))
                    duration = _extract_text(vr.get("lengthText"))
                    is_live = False
                    if not duration:
                        for ov in vr.get("thumbnailOverlays", []):
                            t_ov = ov.get("thumbnailOverlayTimeStatusRenderer", {})
                            style = t_ov.get("style", "")
                            txt = _extract_text(t_ov.get("text"))
                            if style == "LIVE" or txt in ("DIRECTO", "EN DIRECTO", "LIVE"):
                                is_live = True
                                duration = "Directo"
                            elif txt and not duration:
                                duration = txt
                    for badge in vr.get("badges", []):
                        b_rend = badge.get("metadataBadgeRenderer", {})
                        if b_rend.get("style") == "BADGE_STYLE_TYPE_LIVE_NOW":
                            is_live = True
                            duration = "Directo"
                    views = _extract_text(vr.get("viewCountText") or vr.get("shortViewCountText"))
                    published = _extract_text(vr.get("publishedTimeText"))
                    results.append({
                        "type": "video",
                        "vid": vid,
                        "title": title or "Vídeo",
                        "duration": duration,
                        "views": views,
                        "published": published,
                        "is_live": is_live,
                        "thumb": f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg",
                    })
            elif "reelItemRenderer" in obj:
                rr = obj["reelItemRenderer"]
                vid = rr.get("videoId", "")
                if vid and not any(r.get("vid") == vid for r in results):
                    title = _extract_text(rr.get("headline"))
                    results.append({
                        "type": "video",
                        "vid": vid,
                        "title": title or "Short",
                        "duration": "Short",
                        "views": "",
                        "published": "",
                        "thumb": f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg",
                    })
            elif "playlistRenderer" in obj or "gridPlaylistRenderer" in obj:
                pr = obj.get("playlistRenderer") or obj.get("gridPlaylistRenderer")
                pid = pr.get("playlistId", "")
                if pid and not any(r.get("playlist_id") == pid for r in results):
                    title = _extract_text(pr.get("title"))
                    count = _extract_text(pr.get("videoCountText") or pr.get("itemCount"))
                    pl_thumb = _extract_thumb_url(pr, "")
                    if not pl_thumb and isinstance(pr.get("thumbnails"), list) and pr["thumbnails"]:
                        pl_thumb = _extract_thumb_url(pr["thumbnails"][0], "")
                    results.append({
                        "type": "playlist",
                        "playlist_id": pid,
                        "title": title or pid,
                        "count": count,
                        "thumb": pl_thumb or "DefaultVideoPlaylists.png",
                    })
            elif "lockupViewModel" in obj:
                item = _parse_lockup(obj["lockupViewModel"])
                if item and not any(
                    (r.get("vid") and r.get("vid") == item.get("vid"))
                    or (r.get("playlist_id") and r.get("playlist_id") == item.get("playlist_id"))
                    for r in results
                ):
                    results.append(item)
            elif "continuationItemRenderer" in obj:
                ep = obj["continuationItemRenderer"].get("continuationEndpoint", {})
                token = ep.get("continuationCommand", {}).get("token", "")
                if token:
                    next_token = token

            for v in obj.values():
                _walk(v)
        elif isinstance(obj, list):
            for it in obj:
                _walk(it)

    _walk(data)
    return results, next_token


def get_channel_live_video_id(channel_id):
    items, _ = browse_channel(channel_id, tab="streams", ttl=180)
    for it in items:
        if it.get("is_live"):
            return it.get("vid")
    if items and items[0].get("vid"):
        return items[0].get("vid")
    return None


def browse_playlist(list_id, continuation="", ttl=900):
    payload = {"context": _base_context()}
    if continuation:
        payload["continuation"] = continuation
    else:
        bid = list_id if list_id.startswith("VL") else f"VL{list_id}"
        payload["browseId"] = bid

    data = _post_innertube("browse", payload, ttl=ttl if not continuation else 0)
    if not data:
        return [], "", ""

    results = []
    next_token = ""
    pl_title = ""

    pl_title = _clean_text(data.get("metadata", {}).get("playlistMetadataRenderer", {}).get("title", ""))
    if not pl_title:
        header = data.get("header", {})
        pl_header = header.get("playlistHeaderRenderer") or header.get("pageHeaderRenderer")
        if pl_header:
            pl_title = _extract_text(pl_header.get("title") or pl_header.get("pageTitle"))

    def _walk(obj):
        nonlocal next_token, pl_title
        if isinstance(obj, dict):
            if "playlistVideoRenderer" in obj:
                vr = obj["playlistVideoRenderer"]
                vid = vr.get("videoId", "")
                if vid and len(vid) == 11 and not any(r.get("vid") == vid for r in results):
                    title = _extract_text(vr.get("title"))
                    channel = _extract_text(vr.get("shortBylineText"))
                    channel_id = ""
                    byline_runs = vr.get("shortBylineText", {}).get("runs", [])
                    if byline_runs:
                        channel_id = (
                            byline_runs[0]
                            .get("navigationEndpoint", {})
                            .get("browseEndpoint", {})
                            .get("browseId", "")
                        )
                    duration = _extract_text(vr.get("lengthText"))
                    results.append({
                        "type": "video",
                        "vid": vid,
                        "title": title or vid,
                        "channel": channel,
                        "channel_id": channel_id,
                        "duration": duration,
                        "thumb": f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg",
                    })
            elif "lockupViewModel" in obj:
                item = _parse_lockup(obj["lockupViewModel"])
                if item and item.get("vid") and not any(r.get("vid") == item["vid"] for r in results):
                    results.append(item)
            elif "continuationItemRenderer" in obj:
                ep = obj["continuationItemRenderer"].get("continuationEndpoint", {})
                token = ep.get("continuationCommand", {}).get("token", "")
                if token:
                    next_token = token

            for v in obj.values():
                _walk(v)
        elif isinstance(obj, list):
            for it in obj:
                _walk(it)

    _walk(data)
    return results, next_token, pl_title


def related_videos(video_id, ttl=900):
    payload = {
        "context": _base_context(),
        "videoId": video_id,
    }
    data = _post_innertube("next", payload, ttl=ttl)
    if not data:
        return []

    results = []

    def _walk(obj):
        if isinstance(obj, dict):
            if "compactVideoRenderer" in obj:
                vr = obj["compactVideoRenderer"]
                vid = vr.get("videoId", "")
                if vid and len(vid) == 11 and not any(r["vid"] == vid for r in results):
                    title = _extract_text(vr.get("title"))
                    channel = _extract_text(vr.get("shortBylineText") or vr.get("longBylineText"))
                    channel_id = ""
                    byline_runs = (vr.get("shortBylineText") or vr.get("longBylineText") or {}).get("runs", [])
                    if byline_runs:
                        channel_id = (
                            byline_runs[0]
                            .get("navigationEndpoint", {})
                            .get("browseEndpoint", {})
                            .get("browseId", "")
                        )
                    duration = _extract_text(vr.get("lengthText"))
                    results.append({
                        "type": "video",
                        "vid": vid,
                        "title": title or "Vídeo",
                        "channel": channel,
                        "channel_id": channel_id,
                        "duration": duration,
                        "thumb": f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg",
                    })
            elif "lockupViewModel" in obj:
                item = _parse_lockup(obj["lockupViewModel"])
                if item and item.get("vid") and not any(r["vid"] == item["vid"] for r in results):
                    results.append(item)
            for v in obj.values():
                _walk(v)
        elif isinstance(obj, list):
            for it in obj:
                _walk(it)

    _walk(data)
    return results


def suggest_queries(prefix):
    if not prefix:
        return []
    encoded = urllib.parse.quote_plus(prefix)
    url = f"https://suggestqueries-clients6.youtube.com/complete/search?client=youtube&hl=es&gl=ES&ds=yt&q={encoded}"
    req = urllib.request.Request(url, headers={"User-Agent": "Mozilla/5.0"})
    try:
        with urllib.request.urlopen(req, timeout=4) as resp:
            raw = resp.read().decode("utf-8", errors="replace")
            m = re.search(r"\((\[.*\])\)", raw)
            if m:
                arr = json.loads(m.group(1))
                if len(arr) > 1 and isinstance(arr[1], list):
                    return [_clean_text(item[0]) for item in arr[1] if isinstance(item, list) and item]
    except (urllib.error.URLError, ValueError, OSError) as exc:
        _log(f"Error en autocompletado: {exc}")
    return []


def resolve_channel_info(url_or_handle):
    if not url_or_handle:
        return None
    text = url_or_handle.strip()

    direct_cid = None
    if text.startswith("UC") and len(text) == 24:
        direct_cid = text
    else:
        m_cid = re.search(r"channel/(UC[A-Za-z0-9_-]{22})", text)
        if m_cid:
            direct_cid = m_cid.group(1)

    query = direct_cid
    if not query:
        m = re.search(r"youtube\.com/(?:c/|user/)?@?([\w\-\.]+)", text)
        query = m.group(1) if m else text
        if query.startswith("@"):
            query = query[1:]

    items, _ = search(query, sp="EgIQAg==")
    for it in items:
        if it.get("type") == "channel" and it.get("channel_id"):
            if not direct_cid or it["channel_id"] == direct_cid:
                return {
                    "channel_id": it["channel_id"],
                    "name": it.get("title") or it["channel_id"],
                    "thumb": it.get("thumb", ""),
                }

    if direct_cid:
        return {"channel_id": direct_cid, "name": direct_cid, "thumb": ""}
    return None


def resolve_channel_id(url_or_handle):
    info = resolve_channel_info(url_or_handle)
    return info["channel_id"] if info else None


def _fetch_single_channel_feed(channel_dict):
    cid = channel_dict.get("channel_id", "")
    ch_name = _clean_text(channel_dict.get("name", ""))
    if not cid:
        return []
    url = f"https://www.youtube.com/feeds/videos.xml?channel_id={cid}"
    req = urllib.request.Request(url, headers={"User-Agent": "EspaTV-RSS"})
    try:
        with urllib.request.urlopen(req, timeout=8) as resp:
            xml_text = resp.read().decode("utf-8", errors="replace")
            root = ET.fromstring(xml_text)
            videos = []
            for entry in root.findall("atom:entry", _ATOM_NS):
                vid_elem = entry.find("yt:videoId", _ATOM_NS)
                title_elem = entry.find("atom:title", _ATOM_NS)
                pub_elem = entry.find("atom:published", _ATOM_NS)
                author_elem = entry.find("atom:author/atom:name", _ATOM_NS)

                vid = vid_elem.text.strip() if (vid_elem is not None and vid_elem.text) else ""
                title = _clean_text(title_elem.text) if (title_elem is not None and title_elem.text) else ""
                published = pub_elem.text.strip() if (pub_elem is not None and pub_elem.text) else ""
                author = _clean_text(author_elem.text) if (author_elem is not None and author_elem.text) else ch_name

                if vid:
                    videos.append({
                        "type": "video",
                        "vid": vid,
                        "title": title or "Vídeo",
                        "channel": author or ch_name,
                        "channel_id": cid,
                        "published": published,
                        "thumb": f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg",
                    })
            return videos
    except (urllib.error.URLError, ET.ParseError, OSError) as exc:
        _log(f"Error RSS en canal {cid}: {exc}")
        return []


def fetch_subscriptions_feed(channels_list, max_workers=8):
    if not channels_list:
        return []

    all_videos = []
    seen = set()
    with concurrent.futures.ThreadPoolExecutor(max_workers=max_workers) as executor:
        futures = [executor.submit(_fetch_single_channel_feed, ch) for ch in channels_list]
        for f in concurrent.futures.as_completed(futures):
            try:
                res = f.result()
                if res:
                    for v in res:
                        vid = v.get("vid")
                        if vid and vid not in seen:
                            seen.add(vid)
                            all_videos.append(v)
            except (urllib.error.URLError, ET.ParseError, OSError, RuntimeError) as exc:
                _log(f"Excepción en worker RSS: {exc}")

    # Ordenar por fecha de publicación descendente (ISO-8601 UTC ordena lexicográficamente)
    all_videos.sort(key=lambda v: v.get("published", ""), reverse=True)
    return all_videos
