# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Dispatcher de handlers adicionales: evita inflar la cascada elif de default.py."""
import xbmc


def dispatch(action, params):
    """Handler de actions extra con imports perezosos. False si no reconocido."""
    try:
        if action == "submenu_astronomia":
            import astronomia; astronomia.menu()

        elif action == "fases_menu":
            import fases_luna; fases_luna.fases_menu()

        elif action == "calendario_astro_menu":
            import calendario_astro; calendario_astro.calendario_menu()

        elif action == "embalses_menu":
            import embalses; embalses.embalses_menu()

        elif action == "embalses_cuenca":
            import embalses; embalses.embalses_cuenca(params.get("cuenca_nombre", ""))

        elif action == "embalses_refresh":
            import embalses; embalses.embalses_refresh()

        elif action == "embalses_ranking":
            import embalses; embalses.embalses_ranking(params.get("tipo", "vacios"))

        elif action == "aire_menu":
            import aire; aire.aire_menu()

        elif action == "aire_ciudad":
            import aire; aire.aire_ciudad(params.get("ciudad", "madrid"))

        elif action == "aire_estacion":
            import aire; aire.aire_estacion(params.get("uid", ""), params.get("nombre", ""), params.get("ciudad", "madrid"))

        elif action == "aire_refresh":
            import aire; aire.aire_refresh(params.get("ciudad", "madrid"))

        elif action == "aire_estacion_refresh":
            import aire; aire.aire_estacion_refresh(params.get("uid", ""), params.get("nombre", ""), params.get("ciudad", "madrid"))

        elif action == "polen_menu":
            import polen; polen.polen_menu()

        elif action == "polen_provincia":
            import polen; polen.polen_provincia(params.get("provincia", ""))

        elif action == "polen_ccaa":
            import polen; polen.polen_ccaa(params.get("ccaa", ""))

        elif action == "festivos_menu":
            import festivos; festivos.festivos_menu()

        elif action == "festivos_zona":
            import festivos; festivos.festivos_zona(params.get("zona", "ES"))

        elif action == "boe_menu":
            import boe; boe.boe_menu()

        elif action == "boe_feed":
            import boe; boe.boe_feed(params.get("feed_url", ""), params.get("feed_label", "BOE"))

        elif action == "boe_view":
            import boe; boe.boe_view(params.get("title", ""), params.get("plot", ""))

        elif action == "boe_refresh":
            import boe; boe.boe_refresh(params.get("feed_url", ""), params.get("feed_label", "BOE"))

        elif action == "sepe_menu":
            import sepe; sepe.sepe_menu()

        elif action == "sepe_feed":
            import sepe; sepe.sepe_feed(params.get("feed_url", ""), params.get("feed_label", "SEPE"))

        elif action == "sepe_view":
            import sepe; sepe.sepe_view(params.get("title", ""), params.get("plot", ""))

        elif action == "sepe_refresh":
            import sepe; sepe.sepe_refresh(params.get("feed_url", ""), params.get("feed_label", "SEPE"))

        elif action == "gasolineras_menu":
            import gasolineras; gasolineras.gasolineras_menu()

        elif action == "gasolineras_lista":
            import gasolineras; gasolineras.gasolineras_lista(
                params.get("prov_id", "28"),
                params.get("prov_name", "Madrid"),
                params.get("field", "Precio Gasolina 95 E5"),
                params.get("fuel_label", "Gasolina 95"),
            )

        elif action == "gasolineras_refresh":
            import gasolineras; gasolineras.gasolineras_refresh(
                params.get("prov_id", "28"),
                params.get("prov_name", "Madrid"),
                params.get("field", "Precio Gasolina 95 E5"),
                params.get("fuel_label", "Gasolina 95"),
            )

        elif action == "gasolineras_change_prov":
            import gasolineras; gasolineras.gasolineras_change_prov()

        elif action == "storage_menu":
            import storage_manager; storage_manager.menu_almacenamiento()

        elif action == "storage_info":
            import storage_manager; storage_manager.info_almacenamiento()

        elif action == "storage_clear_all":
            import storage_manager; storage_manager.borrar_todas()

        elif action == "storage_clear_category":
            import storage_manager; storage_manager.borrar_categoria(params.get("key", ""))

        elif action == "storage_clear_metadata":
            import storage_manager; storage_manager.borrar_metadata()

        elif action == "alquiler_menu":
            import alquiler; alquiler.alquiler_menu()

        elif action == "alquiler_info":
            import alquiler; alquiler.alquiler_info()

        elif action == "alquiler_detalle":
            import alquiler; alquiler.alquiler_detalle(params.get("prov", ""))

        elif action == "alquiler_refresh":
            import alquiler; alquiler.alquiler_refresh()

        elif action == "galeria_menu":
            import galeria_arte; galeria_arte.galeria_menu()

        elif action == "galeria_artistas_es":
            import galeria_arte; galeria_arte.galeria_artistas_es()

        elif action == "galeria_colecciones":
            import galeria_arte; galeria_arte.galeria_colecciones()

        elif action == "galeria_buscar":
            import galeria_arte; galeria_arte.galeria_buscar()

        elif action == "galeria_lista":
            import galeria_arte; galeria_arte.galeria_lista(params.get("query", ""), params.get("titulo", ""))

        elif action == "galeria_destacadas":
            import galeria_arte; galeria_arte.galeria_destacadas()

        elif action == "galeria_obra_view":
            import galeria_arte; galeria_arte.galeria_obra_view(
                params.get("title", ""), params.get("plot", ""), params.get("img", "")
            )

        elif action == "himnos_menu":
            import himnos; himnos.himnos_menu()

        elif action == "himnos_internacionales_menu":
            import himnos; himnos.himnos_internacionales_menu()

        elif action == "play_himno_internacional":
            import himnos; himnos.play_himno_internacional(
                params.get("nombre", ""), params.get("url", "")
            )

        elif action in ("play_himno", "play_himno_pais"):
            import himnos; himnos.play_himno(params.get("pais", "ES"))


        elif action == "musica_libre_menu":
            import musica_libre; musica_libre.musica_libre_menu()

        elif action == "musica_archive_menu":
            import musica_libre; musica_libre.archive_menu()

        elif action == "musica_archive_lista":
            import musica_libre; musica_libre.archive_lista(
                params.get("query", "music"),
                params.get("sort", "downloads"),
                params.get("titulo", ""),
            )

        elif action == "musica_archive_play":
            import musica_libre; musica_libre.archive_play(
                params.get("identifier", ""),
                params.get("titulo", ""),
            )

        elif action == "musica_radio_menu":
            import musica_libre; musica_libre.radio_menu()

        elif action == "musica_radio_lista":
            import musica_libre; musica_libre.radio_lista(
                params.get("country", ""),
                params.get("tag", ""),
                params.get("titulo", ""),
            )

        elif action == "musica_radio_play":
            import musica_libre; musica_libre.radio_play(
                params.get("url", ""),
                params.get("nombre", ""),
            )

        elif action == "horoscopo_menu":
            import horoscopo; horoscopo.horoscopo_menu()

        elif action == "horoscopo_signo":
            import horoscopo; horoscopo.horoscopo_signo(
                params.get("signo_nombre", ""),
                params.get("signo_key", "aries"),
            )

        elif action == "agenda_cultural_menu":
            import agenda_cultural; agenda_cultural.agenda_menu()

        elif action == "agenda_cultural_noticias":
            import agenda_cultural; agenda_cultural.agenda_cultural_noticias(
                params.get("feed_url", ""), params.get("feed_label", "Noticias de Cultura")
            )

        elif action == "agenda_cultural_fiesta":
            import agenda_cultural; agenda_cultural.agenda_cultural_fiesta(
                params.get("title", ""), params.get("plot", "")
            )

        elif action == "epg_texto_menu":
            import epg_texto; epg_texto.epg_texto_menu()

        elif action == "epg_texto_canal":
            import epg_texto; epg_texto.epg_texto_canal(
                params.get("ch_id", ""), params.get("ch_name", "")
            )

        elif action == "epg_texto_programa":
            import epg_texto; epg_texto.epg_texto_programa(
                params.get("title", ""), params.get("plot", "")
            )

        elif action == "epg_texto_grupo":
            import epg_texto; epg_texto.epg_texto_grupo(params.get("grupo", "Nacionales TDT"))

        elif action == "epg_texto_refresh":
            import epg_texto; epg_texto.epg_texto_refresh()

        elif action == "dgt_camaras_menu":
            import dgt; dgt.dgt_camaras_menu()

        elif action == "dgt_camara_view":
            import dgt; dgt.dgt_camara_view(
                params.get("url", ""), params.get("titulo", "Cámara DGT")
            )

        # ---------- Tests DGT (examen teórico; las fotos son opcionales) ----------
        elif action == "dgt_examen_menu":
            import dgt_examen; dgt_examen.dgt_examen_menu()

        elif action == "dgt_test_examen":
            import dgt_examen; dgt_examen.dgt_test_examen(params.get("filtro", ""))

        elif action == "dgt_test_epocas":
            import dgt_examen; dgt_examen.dgt_test_epocas()

        elif action == "dgt_test_repasar":
            import dgt_examen; dgt_examen.dgt_test_repasar()

        elif action == "dgt_test_stats":
            import dgt_examen; dgt_examen.dgt_test_stats()

        elif action == "dgt_test_modo":
            import dgt_examen; dgt_examen.dgt_test_modo()

        elif action == "dgt_test_imagenes_toggle":
            import dgt_examen; dgt_examen.dgt_test_imagenes_toggle()

        elif action == "dgt_test_borrar_imagenes":
            import dgt_examen; dgt_examen.dgt_test_borrar_imagenes()

        elif action == "dgt_test_refresh":
            import dgt_examen; dgt_examen.dgt_test_refresh()

        elif action == "dgt_test_imagenes":
            import dgt_examen; dgt_examen.dgt_test_imagenes()

        elif action == "dgt_test_fuente":
            import dgt_examen; dgt_examen.dgt_test_fuente()

        elif action == "reloj_mundial_menu":
            import reloj_mundial; reloj_mundial.reloj_mundial_menu()

        # ---------- Diccionario de nombres (Wikipedia + Wiktionary, en vivo) ----------
        elif action == "nombres_menu":
            import nombres; nombres.menu()

        elif action == "nombres_buscar":
            import nombres; nombres.buscar()

        elif action == "nombres_resultados":
            # Ninguna fila la enlaza: buscar() llama a resultados() directamente,
            # porque al final solo queda pintar la lista en la ventana ya abierta.
            # Se mantiene como accion por si se invoca desde un favorito o desde
            # un Container.Refresh, y para que el dispatcher no tenga un agujero.
            import nombres; nombres.resultados(params.get("q", ""))

        elif action == "nombres_ver":
            import nombres; nombres.ver(params.get("nombre", ""))

        elif action == "nombres_espana":
            import nombres; nombres.espana()

        elif action == "nombres_indice":
            import nombres; nombres.indice()

        elif action == "nombres_lista":
            import nombres; nombres.lista(params.get("letra", ""))

        elif action == "nombres_enlaces":
            import nombres; nombres.enlaces()

        elif action == "bso_menu":
            import bso; bso.bso_menu()

        elif action == "bso_tracks":
            import bso; bso.bso_tracks(params.get("movie_id", ""))

        elif action == "bso_play":
            import bso; bso.bso_play(
                params.get("nombre", ""), params.get("src", ""), params.get("movie", "")
            )

        elif action == "bso_libre_menu":
            import musica_libre; musica_libre.bso_libre_menu()

        elif action == "bso_libre_lista":
            import musica_libre; musica_libre.bso_libre_lista(
                params.get("query", ""), params.get("sort", "downloads"),
                params.get("titulo", ""), params.get("lic", "")
            )

        elif action == "submenu_transporte":
            import transporte; transporte.menu()

        elif action == "metro_madrid_menu":
            import metro_madrid; metro_madrid.metro_madrid_menu()

        elif action == "metro_madrid_cambiar":
            import metro_madrid; metro_madrid.metro_madrid_cambiar()

        elif action == "metro_madrid_trenes":
            import metro_madrid; metro_madrid.metro_madrid_trenes(
                params.get("cod_stop", "4_12"),
                params.get("estacion_name", ""),
            )

        elif action == "metro_madrid_refresh":
            import metro_madrid; metro_madrid.metro_madrid_refresh(
                params.get("cod_stop", "4_12"),
                params.get("estacion_name", ""),
            )

        elif action == "metro_barcelona_menu":
            import metro_barcelona; metro_barcelona.metro_barcelona_menu()

        elif action == "metro_barcelona_config":
            import metro_barcelona; metro_barcelona.metro_barcelona_config()

        elif action == "metro_barcelona_cambiar":
            import metro_barcelona; metro_barcelona.metro_barcelona_cambiar()

        elif action == "metro_barcelona_trenes":
            import metro_barcelona; metro_barcelona.metro_barcelona_trenes(
                params.get("codi_estacio", ""),
                params.get("estacion_name", ""),
            )

        elif action == "metro_barcelona_refresh":
            import metro_barcelona; metro_barcelona.metro_barcelona_refresh(
                params.get("codi_estacio", ""),
                params.get("estacion_name", ""),
            )

        elif action == "metro_valencia_menu":
            import metro_valencia; metro_valencia.metro_valencia_menu()

        elif action == "metro_valencia_cambiar_origen":
            import metro_valencia; metro_valencia.metro_valencia_cambiar_origen()

        elif action == "metro_valencia_cambiar_destino":
            import metro_valencia; metro_valencia.metro_valencia_cambiar_destino()

        elif action == "metro_valencia_trenes":
            import metro_valencia; metro_valencia.metro_valencia_trenes(
                params.get("origen_id", "16"),
                params.get("destino_id", "15"),
                params.get("origen_name", ""),
                params.get("destino_name", ""),
            )

        elif action == "metro_valencia_refresh":
            import metro_valencia; metro_valencia.metro_valencia_refresh(
                params.get("origen_id", "16"),
                params.get("destino_id", "15"),
                params.get("origen_name", ""),
                params.get("destino_name", ""),
            )

        elif action == "metro_malaga_menu":
            import metro_malaga; metro_malaga.metro_malaga_menu()

        elif action == "metro_malaga_cambiar":
            import metro_malaga; metro_malaga.metro_malaga_cambiar()

        elif action == "metro_malaga_horario":
            import metro_malaga; metro_malaga.metro_malaga_horario(
                params.get("stop_id", ""), params.get("stop_name", "")
            )

        elif action == "metro_malaga_refresh":
            import metro_malaga; metro_malaga.metro_malaga_refresh(
                params.get("stop_id", ""), params.get("stop_name", "")
            )

        elif action == "api_consulta_pelis":
            import espatv_api; espatv_api.render_directory(params)

        # ---------- Sección X (+18): Eporner, RedTube y Pornhub ----------
        elif action == "xxx_menu":
            import xxx_eporner; xxx_eporner.menu()

        elif action == "xxx_menu_plat":
            import xxx_eporner; xxx_eporner.menu_plataforma(params.get("src", "ep"))

        elif action == "xxx_search_menu":
            import xxx_eporner; xxx_eporner.search_menu()

        elif action == "xxx_list":
            import xxx_eporner; xxx_eporner.listado(
                params.get("src", "ep"), params.get("q", ""),
                params.get("page", 1), params.get("order"), params.get("upd", ""))

        elif action == "xxx_list_rt_cat":
            import xxx_eporner; xxx_eporner.listado_rt_cat(
                params.get("cat", ""), params.get("page", 1), params.get("upd", ""))

        elif action == "xxx_cats":
            # El `upd` se pasa porque la fila "No ha salido nada de «X»" de las categorias de
            # RedTube lo lleva, y `categorias()` lo usa para cerrar con `updateListing=True`.
            # Sin pasarlo aquí, el `upd` viajaba en la URL sin ser leído por la función.
            import xxx_eporner
            xxx_eporner.categorias(params.get("src", "ep"), params.get("upd", ""))

        elif action == "xxx_buscar":
            import xxx_eporner; xxx_eporner.buscar(params.get("src", "ep"))

        elif action == "xxx_play":
            import xxx_eporner; xxx_eporner.play(
                params.get("src", "ep"), params.get("vid", ""),
                params.get("titulo", ""), params.get("length", ""),
                params.get("views", ""), params.get("rate", ""),
                params.get("thumb", ""), params.get("added", ""),
                params.get("pagina", ""))

        elif action == "xxx_favs":
            import xxx_eporner; xxx_eporner.favoritos()

        elif action == "xxx_fav_add":
            import xxx_eporner; xxx_eporner.fav_add(
                params.get("src", "ep"), params.get("vid", ""), params.get("titulo", ""),
                params.get("thumb", ""), params.get("length", ""),
                params.get("views", ""), params.get("rate", ""),
                params.get("added", ""), params.get("pagina", ""))

        elif action == "xxx_fav_del":
            import xxx_eporner; xxx_eporner.fav_del(
                params.get("vid", ""), params.get("src", ""))

        elif action == "xxx_favs_clear":
            import xxx_eporner; xxx_eporner.favs_clear()

        elif action == "xxx_hist":
            import xxx_eporner; xxx_eporner.historial()

        elif action == "xxx_hist_del":
            import xxx_eporner; xxx_eporner.hist_del(
                params.get("vid", ""), params.get("src", ""))

        elif action == "xxx_hist_clear":
            import xxx_eporner; xxx_eporner.hist_clear()

        elif action == "xxx_ajustes":
            import xxx_eporner; xxx_eporner.ajustes()

        elif action == "xxx_set":
            import xxx_eporner; xxx_eporner.ajuste_set(
                params.get("clave", ""), params.get("i", 0))

        elif action == "xxx_pin_cambiar":
            import xxx_eporner; xxx_eporner.cambiar_pin()

        elif action == "xxx_cache_clear":
            import xxx_eporner; xxx_eporner.cache_clear()

        elif action == "xxx_legal":
            import xxx_eporner; xxx_eporner.legal()

        elif action == "xxx_web":
            import xxx_eporner; xxx_eporner.abrir_web(
                params.get("src", "ep"), params.get("vid", ""),
                params.get("pagina", ""))

        elif action and action.startswith("debrid_test_"):
            import debrid_sources
            return debrid_sources.dispatch(action, params)

        else:
            return False  # No reconocido → seguir con la cascada elif de default.py

        return True

    except Exception as e:
        xbmc.log("[EspaTV-EXTRAS] Error dispatch action={0}: {1}".format(action, e), xbmc.LOGERROR)
        raise
