# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Búsqueda de vídeos, canales y listas en YouTube mediante InnerTube JSON."""

import json
import os
import re
import sys
import urllib.error
import urllib.parse
import urllib.request

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

from _user_agents import ACCEPT_HTML
from _user_agents import desktop_headers as _dh
import core_settings
import yt_innertube

try:
    from ui_utils import media_icon
except ImportError:
    def media_icon(name):
        return ""

try:
    import yt_watched_tracker
except ImportError:
    yt_watched_tracker = None


_YT_SP_DURATION = [
    ("Cualquier duración", ""),
    ("Cortos (< 4 min)", "EgIYAQ=="),
    ("Medios (4-20 min)", "EgIYAw=="),
    ("Largos (> 20 min)", "EgIYAg=="),
]
_YT_SP_DATE = [
    ("Cualquier fecha", ""),
    ("Última hora", "EgIIAQ=="),
    ("Hoy", "EgIIAg=="),
    ("Esta semana", "EgIIAw=="),
    ("Este mes", "EgIIBA=="),
    ("Este año", "EgIIBQ=="),
]
_YT_SP_SORT = [
    ("Relevancia", ""),
    ("Fecha de subida", "CAISAhAB"),
    ("Número de visitas", "CAMSAhAB"),
    ("Valoración", "CAESAhAB"),
]


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)


def _get_yt_history_file():
    p = ""
    try:
        p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
    except (RuntimeError, AttributeError):
        p = ""
    if not p or p.startswith("special://"):
        p = os.path.join(os.path.dirname(os.path.abspath(__file__)), "tmp")
    if not os.path.exists(p):
        try:
            os.makedirs(p, exist_ok=True)
        except OSError:
            pass
    return os.path.join(p, "yt_search_history.json")


def load_yt_history():
    f = _get_yt_history_file()
    if not os.path.exists(f):
        return []
    try:
        with open(f, "r", encoding="utf-8") as fh:
            datos = json.load(fh)
    except (ValueError, OSError):
        return []
    return [q for q in datos if isinstance(q, str)] if isinstance(datos, list) else []


def _add_yt_to_history(q):
    q = q.strip()
    if not q:
        return
    hist = load_yt_history()
    if q in hist:
        hist.remove(q)
    hist.insert(0, q)
    hist = hist[:30]
    try:
        core_settings.atomic_write_json(_get_yt_history_file(), hist)
    except OSError as exc:
        xbmc.log(f"[EspaTV/yt_search] Error guardando historial: {exc}", xbmc.LOGWARNING)


def remove_yt_history_item(q):
    if not q:
        return
    yh = load_yt_history()
    yh = [x for x in yh if x != q]
    try:
        core_settings.atomic_write_json(_get_yt_history_file(), yh)
    except OSError as exc:
        xbmc.log(f"[EspaTV/yt_search] Error borrando elemento historial: {exc}", xbmc.LOGWARNING)
    xbmc.executebuiltin("Container.Refresh")


def clear_yt_history():
    yh = load_yt_history()
    if not yh:
        return
    opts = ["Borrar TODO el historial", "Elegir elementos a borrar", "[COLOR red]Cancelar[/COLOR]"]
    sel = xbmcgui.Dialog().select("Limpiar Historial de Búsquedas YouTube", opts)
    if sel == 0:
        if xbmcgui.Dialog().yesno("Confirmar", "¿Estás seguro de que quieres vaciar TODO el historial de búsqueda de YouTube?"):
            try:
                core_settings.atomic_write_json(_get_yt_history_file(), [])
            except OSError as exc:
                xbmc.log(f"[EspaTV/yt_search] Error limpiando historial: {exc}", xbmc.LOGWARNING)
            xbmcgui.Dialog().notification("EspaTV", "Historial YouTube borrado", xbmcgui.NOTIFICATION_INFO)
            xbmc.executebuiltin("Container.Refresh")
    elif sel == 1:
        chosen = xbmcgui.Dialog().multiselect("Marca las búsquedas a eliminar", yh)
        if chosen:
            new_yh = [item for i, item in enumerate(yh) if i not in chosen]
            try:
                core_settings.atomic_write_json(_get_yt_history_file(), new_yh)
            except OSError as exc:
                xbmc.log(f"[EspaTV/yt_search] Error guardando historial: {exc}", xbmc.LOGWARNING)
            xbmc.executebuiltin("Container.Refresh")


def _yt_parse_initial_data(html):
    m = re.search(r"var ytInitialData\s*=\s*(\{.*?\});\s*</script>", html)
    if not m:
        return None
    try:
        return json.loads(m.group(1))
    except (ValueError, TypeError):
        return None


def _yt_extract_videos(data):
    results = []
    try:
        sections = data["contents"]["twoColumnSearchResultsRenderer"]["primaryContents"]["sectionListRenderer"]["contents"]
    except (KeyError, TypeError):
        return results
    for section in sections:
        isr = section.get("itemSectionRenderer")
        if not isr:
            continue
        for item in isr.get("contents", []):
            vr = item.get("videoRenderer")
            if not vr:
                continue
            vid = vr.get("videoId", "")
            if not vid:
                continue
            title = ""
            runs = vr.get("title", {}).get("runs", [])
            if runs:
                title = runs[0].get("text", "")
            dur = vr.get("lengthText", {}).get("simpleText", "")
            channel = ""
            channel_id = ""
            chan_runs = vr.get("ownerText", {}).get("runs", [])
            if chan_runs:
                channel = chan_runs[0].get("text", "")
                channel_id = (
                    chan_runs[0]
                    .get("navigationEndpoint", {})
                    .get("browseEndpoint", {})
                    .get("browseId", "")
                )
            views = vr.get("viewCountText", {}).get("simpleText", "")
            if not views:
                views = vr.get("shortViewCountText", {}).get("simpleText", "")
            published = vr.get("publishedTimeText", {}).get("simpleText", "")
            results.append({
                "type": "video",
                "vid": vid,
                "title": title or "Video",
                "duration": dur,
                "channel": channel,
                "channel_id": channel_id,
                "views": views,
                "published": published,
            })
    return results


def _yt_fallback_parse(html):
    results = []
    seen = set()
    pattern = re.compile(r'"videoRenderer":\{"videoId":"([^"]{11})".*?"title":\{"runs":\[\{"text":"([^"]+)"\}')
    for m in pattern.finditer(html):
        vid, title = m.group(1), m.group(2)
        if vid not in seen:
            seen.add(vid)
            results.append({"type": "video", "vid": vid, "title": title, "duration": "", "channel": "", "channel_id": "", "views": ""})
        if len(results) >= 20:
            break
    return results


def fetch_search_results(query, sp="", continuation="", return_token=False):
    items, next_tok = yt_innertube.search(query, sp=sp, continuation=continuation)
    videos = [it for it in items if it.get("type") == "video"]
    if not videos and not continuation:
        try:
            encoded = urllib.parse.quote_plus(query)
            url = f"https://www.youtube.com/results?search_query={encoded}"
            if sp:
                url += f"&sp={urllib.parse.quote(sp, safe='')}"
            req = urllib.request.Request(url, headers=_dh(accept=ACCEPT_HTML))
            with urllib.request.urlopen(req, timeout=12) as resp:
                html = resp.read().decode("utf-8", errors="replace")
            data = _yt_parse_initial_data(html)
            videos = _yt_extract_videos(data) if data else _yt_fallback_parse(html)
        except (urllib.error.URLError, OSError, ValueError) as exc:
            xbmc.log(f"[EspaTV] Fallback HTML búsqueda falló: {exc}", xbmc.LOGWARNING)
    if return_token:
        return videos, next_tok
    return videos


def search_results(query, sp="", continuation=""):
    h = int(sys.argv[1]) if len(sys.argv) > 1 else -1
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", f"Buscando en YouTube: {query}...")
    try:
        items, next_continuation = yt_innertube.search(query, sp=sp, continuation=continuation)
        if not items and not continuation:
            items = fetch_search_results(query, sp=sp)
        dp.close()
    except (urllib.error.URLError, OSError, ValueError) as exc:
        dp.close()
        xbmc.log(f"[EspaTV] Error buscando en YouTube: {exc}", xbmc.LOGERROR)
        xbmcgui.Dialog().ok("EspaTV", f"Error al buscar en YouTube:\n{exc}")
        if h >= 0:
            xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    if not items:
        xbmcgui.Dialog().ok("EspaTV", f"No se encontraron resultados para:\n{query}")
        if h >= 0:
            xbmcplugin.endOfDirectory(h, succeeded=False)
        return

    # Sin setContent("videos"): en Estuary el contenido de videos fuerza ListWatchedIconVar (punto
    # o marca de visto) ocultando ListItem.Icon; con contenido neutro el skin pinta la miniatura propia en la fila.
    watched_ids = set()
    if yt_watched_tracker:
        try:
            watched_ids = yt_watched_tracker.load()
        except (OSError, ValueError):
            watched_ids = set()
    if not continuation and any(it.get("type") == "video" for it in items):
        li_cinema = xbmcgui.ListItem(label="[COLOR FF38BDF8][B]Modo Cine[/B][/COLOR]")
        icon_cin = media_icon("yt_cinema_mode.png") or "DefaultMovies.png"
        li_cinema.setArt({"icon": icon_cin, "thumb": icon_cin, "poster": icon_cin, "banner": icon_cin})
        li_cinema.setInfo("video", {"title": "Modo Cine", "plot": "Navega los resultados con miniaturas grandes y fondo dinámico."})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="yt_search_cinema", query=query, sp=sp),
            listitem=li_cinema,
            isFolder=False,
        )

    for it in items:
        itype = it.get("type", "video")

        if itype == "video":
            vid = it.get("vid", "")
            title = it.get("title", "Vídeo")
            channel = it.get("channel", "")
            channel_id = it.get("channel_id", "")
            dur = it.get("duration", "")
            views = it.get("views", "")
            published = it.get("published", "")
            thumb = it.get("thumb") or f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg"
            is_watched = vid in watched_ids
            lbl = f"[COLOR limegreen][Visto][/COLOR] {title}" if is_watched else title

            li = xbmcgui.ListItem(label=lbl)
            li.setArt({"icon": thumb, "thumb": thumb, "poster": thumb, "fanart": thumb})
            li.setProperty("IsPlayable", "true")

            plot_lines = []
            if channel:
                plot_lines.append(f"Canal: {channel}")
            if dur:
                plot_lines.append(f"Duración: {dur}")
            if views:
                plot_lines.append(f"Vistas: {views}")
            if published:
                plot_lines.append(f"Subido: {published}")
            plot = "\n".join(plot_lines) if plot_lines else title
            info_dict = {"plot": plot, "title": title, "studio": channel}
            if is_watched:
                info_dict["playcount"] = 1
            li.setInfo("video", info_dict)

            fav_params = json.dumps({"yt_id": vid, "name": title, "ctype": "video", "burl": ""})
            ctx = [
                ("Añadir a Ver más tarde", f"RunPlugin({_u(action='yt_watch_later_add', video_id=vid, title=title, channel=channel, channel_id=channel_id, duration=dur)})"),
                ("Añadir a Mis Favoritos (EspaTV)", f"RunPlugin({_u(action='add_favorite', title=title, fav_url=f'yt_{vid}', icon=thumb, platform='youtube', fav_action='felicidad_play', params=fav_params)})"),
                ("Solo audio", f"RunPlugin({_u(action='yt_play_audio', video_id=vid, title=title)})"),
                ("Vídeos relacionados (Radio)", f"Container.Update({_u(action='yt_related', video_id=vid, title=title)})"),
            ]
            if channel_id:
                ctx.append(("Ir al canal", f"Container.Update({_u(action='yt_channel_view', channel_id=channel_id, channel_name=channel)})"))
            ctx.append(("Añadir a cola de reproducción", f"RunPlugin({_u(action='yt_queue_add', video_id=vid, title=title)})"))
            toggle_lbl = "Desmarcar como visto" if is_watched else "Marcar como visto"
            ctx.append((toggle_lbl, f"RunPlugin({_u(action='yt_toggle_watched', yt_id=vid)})"))
            ctx.append(("Opciones de reproducción (App / Navegador / yt-dlp)", f"Container.Update({_u(action='felicidad_play', yt_id=vid, name=title, ctype='video')})"))
            li.addContextMenuItems(ctx)

            play_url = _u(action="yt_play_video", video_id=vid, title=title)
            xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

        elif itype == "channel":
            cid = it.get("channel_id", "")
            title = it.get("title", cid)
            subs = it.get("subs", "")
            thumb = it.get("thumb") or "DefaultActor.png"
            label = f"{title} [COLOR lightskyblue](canal)[/COLOR]"
            if subs:
                label += f" [COLOR limegreen]({subs})[/COLOR]"

            li = xbmcgui.ListItem(label=label)
            li.setArt({"icon": thumb, "thumb": thumb})
            desc = it.get("desc", "")
            li.setInfo("video", {"title": title, "plot": desc or "Canal de YouTube"})

            ctx = [
                ("Suscribirse", f"RunPlugin({_u(action='yt_sub_add', channel_id=cid, name=title, thumb=thumb)})"),
            ]
            li.addContextMenuItems(ctx)

            play_url = _u(action="yt_channel_view", channel_id=cid, channel_name=title)
            xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=True)

        elif itype == "playlist":
            pid = it.get("playlist_id", "")
            title = it.get("title", pid)
            count = it.get("count", "")
            thumb = it.get("thumb") or "DefaultVideoPlaylists.png"
            label = f"{title} [COLOR skyblue](playlist)[/COLOR]"
            if count:
                label += f" [COLOR limegreen]({count})[/COLOR]"

            li = xbmcgui.ListItem(label=label)
            li.setArt({"icon": thumb, "thumb": thumb})
            li.setInfo("video", {"title": title, "plot": f"Playlist de YouTube: {title}"})

            play_url = _u(action="yt_playlist_open", list_id=pid, name=title)
            xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=True)
    if next_continuation:
        li_next = xbmcgui.ListItem(label="[COLOR yellow][B]Página siguiente >>[/B][/COLOR]")
        icon_next = media_icon("yt_page_next.png") or "DefaultFolderBack.png"
        li_next.setArt({"icon": icon_next, "thumb": icon_next, "poster": icon_next, "banner": icon_next})
        li_next.setInfo("video", {"plot": "Carga los siguientes resultados de esta búsqueda."})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="yt_search_results", query=query, sp=sp, continuation=next_continuation),
            listitem=li_next,
            isFolder=True,
        )
    li_search = xbmcgui.ListItem(label="[COLOR yellow][B]Buscar otra cosa en YouTube...[/B][/COLOR]")
    icon_search = media_icon("yt_hub_search.png") or "DefaultAddonsSearch.png"
    li_search.setArt({"icon": icon_search, "thumb": icon_search, "poster": icon_search, "banner": icon_search})
    li_search.setInfo("video", {"plot": "Inicia una nueva búsqueda en YouTube."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="yt_search"), listitem=li_search, isFolder=False)

    xbmcplugin.endOfDirectory(h)


def channel_search():
    h = int(sys.argv[1]) if len(sys.argv) > 1 else -1

    def _cancel_dir():
        if h >= 0:
            try:
                xbmcplugin.endOfDirectory(h, succeeded=True)
            except Exception:
                pass

    kb = xbmc.Keyboard("", "Nombre del canal de YouTube")
    kb.doModal()
    if not kb.isConfirmed():
        _cancel_dir()
        return
    q = kb.getText().strip()
    if not q:
        _cancel_dir()
        return

    _add_yt_to_history(q)
    target_url = _u(action="yt_search_results", query=q, sp="EgIQAg==")
    xbmc.executebuiltin(f"Container.Update({target_url})")
    _cancel_dir()


def search():
    h = int(sys.argv[1]) if len(sys.argv) > 1 else -1

    def _cancel_dir():
        if h >= 0:
            try:
                xbmcplugin.endOfDirectory(h, succeeded=True)
            except Exception:
                pass

    base_opts = [
        "Búsqueda normal",
        "Sugerencias de búsqueda (Autocompletar)",
        "Buscar con filtros",
        "Buscar canal de YouTube",
        "Buscar playlists de YouTube",
        "Buscar directos en vivo",
        "Escribir desde móvil/PC",
    ]
    hist = load_yt_history()
    opts = list(base_opts)
    for h_item in hist:
        opts.append(f"[COLOR gray][Historial][/COLOR] {h_item}")
    if hist:
        opts.append("[COLOR orange]Borrar historial de búsqueda de YouTube...[/COLOR]")

    sel = xbmcgui.Dialog().select("Búsqueda en YouTube", opts)
    if sel < 0:
        _cancel_dir()
        return

    if hist and sel == len(opts) - 1:
        clear_yt_history()
        _cancel_dir()
        return

    if sel >= len(base_opts):
        q = hist[sel - len(base_opts)]
        _add_yt_to_history(q)
        target_url = _u(action="yt_search_results", query=q)
        xbmc.executebuiltin(f"Container.Update({target_url})")
        _cancel_dir()
        return

    if sel == 3:
        channel_search()
        return

    if sel == 6:
        import url_remote
        q = url_remote.receive_text("Buscar en YouTube")
        if not q:
            _cancel_dir()
            return
        q = q.strip()
    elif sel == 1:
        kb = xbmc.Keyboard("", "Escribe el inicio de tu búsqueda (Autocompletar)")
        kb.doModal()
        if not kb.isConfirmed():
            _cancel_dir()
            return
        prefix = kb.getText().strip()
        if not prefix:
            _cancel_dir()
            return
        suggestions = yt_innertube.suggest_queries(prefix)
        if suggestions:
            sug_opts = [f"[B]{prefix}[/B] (buscar tal cual)"] + suggestions
            s_idx = xbmcgui.Dialog().select("Sugerencias de YouTube", sug_opts)
            if s_idx < 0:
                _cancel_dir()
                return
            q = prefix if s_idx == 0 else suggestions[s_idx - 1]
        else:
            q = prefix
    else:
        kb = xbmc.Keyboard("", "Buscar en YouTube")
        kb.doModal()
        if not kb.isConfirmed():
            _cancel_dir()
            return
        q = kb.getText().strip()
        if not q:
            _cancel_dir()
            return

    sp = ""
    if sel == 4:
        sp = "EgIQAw=="
    elif sel == 5:
        sp = "EgJAAQ=="
    elif sel == 2:
        f_types = ["Por duración", "Por fecha de subida", "Por orden", "Solo directos en vivo"]
        f_sel = xbmcgui.Dialog().select("Seleccionar tipo de filtro", f_types)
        if f_sel == 0:
            dur_labels = [x[0] for x in _YT_SP_DURATION]
            d = xbmcgui.Dialog().select("Filtrar por duración", dur_labels)
            if d > 0:
                sp = _YT_SP_DURATION[d][1]
        elif f_sel == 1:
            date_labels = [x[0] for x in _YT_SP_DATE]
            dt = xbmcgui.Dialog().select("Filtrar por fecha", date_labels)
            if dt > 0:
                sp = _YT_SP_DATE[dt][1]
        elif f_sel == 2:
            sort_labels = [x[0] for x in _YT_SP_SORT]
            s = xbmcgui.Dialog().select("Ordenar por", sort_labels)
            if s > 0:
                sp = _YT_SP_SORT[s][1]
        elif f_sel == 3:
            sp = "EgJAAQ=="

    _add_yt_to_history(q)
    target_url = _u(action="yt_search_results", query=q, sp=sp)
    xbmc.executebuiltin(f"Container.Update({target_url})")
    _cancel_dir()
