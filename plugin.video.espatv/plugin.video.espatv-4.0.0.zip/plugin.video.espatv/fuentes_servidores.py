# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Los servidores y listas añadidos: darlos de alta, comprobarlos y ordenarlos.

Este es el módulo que hace que la sección deje de estar muerta: sin él, la pantalla raíz se
pinta pero no hay ningún botón accionable.

Cuatro reglas que no hay que romper aquí:

- **Ninguna URL con credenciales en un `plugin://`.** Ni en la fila, ni en el favorito, ni
  en el `RunPlugin`. Todas las acciones van con `fid` y ya está: son 12 hex. Una URL con
  usuario y clave dentro acabaría en el historial de Kodi y en los cinco `RunPlugin` de
  los menús contextuales de `default.py`.
- **El User-Agent es el del proyecto, y configurable.** Nunca uno falsificado. Vacío por
  defecto (`fuentes_ua`).
- **Los servidores pueden estar en la red local**, así que toda la red va con
  `lan_ok=True`. `_download` bloquea la red local por defecto y
  aquí eso sería un fallo, no una protección: es *su* servidor.
- **La red solo cuando hace falta.** Añadir no comprueba: guarda y ya. Comprobar es una
  acción aparte, explícita. Pinchar "añadir" y esperar a un panel que no contesta es la peor
  forma de dar de alta algo.

La comprobación de la cuenta delega en `fuentes_xtream.py` para centralizar la comunicación
con `player_api.php`.

Excepciones: las de `fuentes_store` no llegan aquí (el router las ve), y las de red sí, pero
**no son de este módulo**: son `fuentes_xtream.ErrorRed` y `fuentes_xtream.ErrorCuenta`. Aquí
no se definen otra vez, y es a propósito. Tener dos juegos con el mismo nombre y distinto
identidad hace que un `except ErrorRed` de este sitio no capture el del cliente, y el fallo sale
como "error inesperado" en la pantalla en vez de como "no se ha podido contactar", que es la
diferencia que importa.
"""
import re
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui

import ui_utils

_LOG = '[EspaTV/FUENTES]'

_NOMBRE = 'HyperXStream'

_BASE = 'plugin://plugin.video.espatv/'

#: Conexiones simultáneas para el análisis en paralelo.
HILOS_ANALISIS = 12

#: Tiempo máximo de espera en segundos antes de consolidar los resultados.
PLAZO_ANALISIS = 90

#: Segundos que la etiqueta `[Libre 1/3]` / `[Lleno 3/3]` del análisis sigue en el rótulo del
#: servidor. Una hora es ya generosa para un dato que cambia cada vez que alguien abre un canal.
VIGENCIA_CONEXIONES = 3600


def _log(texto, nivel=xbmc.LOGDEBUG):
    xbmc.log('{0} {1}'.format(_LOG, texto), nivel)


def _u(**params):
    """La dirección de una acción. **Nunca** lleva credenciales: solo ids."""
    return _BASE + '?' + urllib.parse.urlencode(
        {k: v for k, v in params.items() if v not in (None, '')})


def _icon(nombre):
    return ui_utils.media_icon(nombre) or 'DefaultAddonPVRClient.png'


def _u_nombre():
    return _NOMBRE


def _ajuste(clave, defecto=''):
    """Un ajuste de `settings.xml`, leído sin escribir nada.

    Leer un ajuste y no encontrarlo **no es un error**: es el estado por defecto. Y el de
    todos los de la sección es "no hay nada puesto".
    """
    try:
        valor = xbmcaddon.Addon().getSetting(clave)
    except Exception as e:                              # pragma: no cover
        _log('no se ha podido leer el ajuste {0}: {1}'.format(clave, e))
        return defecto
    return valor or defecto


# --- la red ---------------------------------------------------------------

class _UrlMala(ValueError):
    """La direccion tecleada no puede ser una URL. Se avisa antes de descargar nada."""


def _valida_url(url):
    """Lo unico que puede fallar al teclear una URL a mano.

    `iptv_parse` no tiene un `validar_url`: sus funciones son `normalize_server`,
    `parse_xtream_url`, `clean_name` y `parse_any`, y ninguna de las cuatro sirve para esto.
    Asi que se comprueba lo basico y se dice por que:

      * que tenga esquema http o https (si no, se le anade antes)
      * que tenga host, que es lo que se cuela cuando se pega media linea
      * que no tenga espacios, que rompen el `urlencode` al montar la peticion

    Nada de red, nada de esquema raro, nada de mas. Es una comprobacion de tecleo, no un
    validador.

    Control de doble esquema: evita que esquemas combinados como `http://ftp://x`
    pasen la validación tras anteponer el protocolo.

    Lo que **no** se comprueba es que el host tenga un punto, aunque sea tentador: un
    `'http://abc'` es media linea pegada, pero un nombre sin punto tambien es lo normal en
    una red de casa (`http://nas:8080`) y una IP (`http://192.168.1.10`). Aqui se comprueba
    que se pueda *interpretar*, no que sea publica.
    """
    if not url.lower().startswith(('http://', 'https://')):
        raise _UrlMala('La direccion tiene que empezar por http:// o https://.')
    if ' ' in url:
        raise _UrlMala('La direccion no puede tener espacios.')
    if re.match(r'(?i)https?://[a-z][a-z0-9+.-]*://', url):
        # `http://ftp://x`: el esquema pegado detras del esquema. Se pilla antes del
        # `urlsplit`, que de eso no se queja de nada. Solo al principio: un `://` en la
        # query (`get.php?url=http://...`) es parte de una M3U normal.
        raise _UrlMala('La direccion tiene dos esquemas: sobra uno.')
    try:
        partes = urllib.parse.urlsplit(url)
    except ValueError as e:
        # Captura puertos no numéricos (ej. 'http://::::') donde urlsplit lanza ValueError.
        raise _UrlMala('La direccion no se entiende: {0}.'.format(e)) from e
    if not partes.netloc or not partes.hostname:
        raise _UrlMala('Falta el nombre del servidor.')
    return url


def _normaliza(servidor):
    import iptv_parse as P
    return P.normalize_server(servidor)


def _pide(host, usuario, clave, inseguro=False, dp=None):
    """Llama a `player_api.php` y devuelve el dict de respuesta.

    Delega en `fuentes_xtream.pedir()`, construyendo el diccionario con host, usuario
    y clave para realizar la comprobación.
    """
    import fuentes_xtream
    return fuentes_xtream.pedir({'servidor': host, 'usuario': usuario, 'clave': clave,
                                 'inseguro': inseguro}, '', dp)


# La línea de «Comprobar» y «Analizar» cuando falla el certificado. Es fija porque quien la
# recibe la compara para ofrecer conectar sin verificarlo (`_ofrece_sin_verificar`).
_CERTIFICADO_MALO = 'NO: El certificado HTTPS de este servidor no es válido.'


def _marca_certificado(f):
    """Lo que se añade al nombre de una fila que no verifica el certificado.

    Solo en https: los servidores http:// que se dieron de alta contestando «No» a la pregunta
    vieja del cifrado tienen `inseguro` puesto, y ahí no significa nada.
    """
    if f.get('inseguro') and str(f.get('servidor') or '').lower().startswith('https://'):
        return '  [COLOR yellow](certificado sin verificar)[/COLOR]'
    return ''


def _ofrece_sin_verificar(f):
    """Pregunta si conectar sin verificar el certificado y, si se acepta, lo guarda.

    Devuelve la fuente con `inseguro` puesto, o `None` si no se acepta o no se ha podido
    guardar. Va en el hilo principal y con el progreso cerrado: es un diálogo modal.
    """
    import fuentes_store
    if not _pregunta_si(
            'El certificado HTTPS de «{0}» no es válido (caducado o autofirmado).\n\n'
            '¿Conectar igualmente sin comprobarlo?'.format(f.get('nombre') or f.get('servidor'))):
        return None
    if not fuentes_store.editar(f['id'], inseguro=True):
        _aviso('No se ha podido guardar el cambio. Mira el log de Kodi para el detalle.')
        return None
    return dict(f, inseguro=True)


def _lee_cuenta(datos):
    """La cuenta a partir de un `user_info` ya recibido, sin volver a preguntar al servidor.

    Delega en `fuentes_xtream.lee_cuenta()`, que es donde está la interpretación. Aquí no se
    vuelve a preguntar porque al comprobar un servidor se ha consultado `user_info` **una
    vez** y pedirlo otra vez para interpretarlo sería tirar una petición a la basura. Lo que
    no puede ser es que la interpretación tenga dos versiones, y por eso las dos pantallas
    pasan por el mismo sitio.
    """
    import fuentes_xtream
    return fuentes_xtream.lee_cuenta(datos)


def _estado_de(datos):
    """Un texto corto para pintar en la fila, sin credenciales ni nada."""
    import fuentes_xtream
    try:
        cuenta = fuentes_xtream.lee_cuenta(datos)
    except fuentes_xtream.ErrorCuenta:
        return 'el panel no responde como Xtream'
    partes = [cuenta['estado'] or 'sin estado']
    if cuenta['caduca']:
        import time
        partes.append('caduca el {0}'.format(
            time.strftime('%d/%m/%Y', time.localtime(cuenta['caduca']))))
    if cuenta['conexiones'] is not None:
        if cuenta.get('actual') is not None:
            partes.append('{0}/{1} conexiones'.format(cuenta['actual'], cuenta['conexiones']))
        else:
            partes.append('{0} conexiones'.format(cuenta['conexiones']))
    else:
        partes.append('conexiones sin decir')
    return ', '.join(partes)


# --- el menu ---------------------------------------------------------------

def _opciones(f, pos, total):
    """Lo que se le puede hacer a una fuente: rótulo, acción y explicación.

    **Es la única lista que hay**, y a propósito. De aquí salen las dos caras de lo mismo: el
    menú contextual de la fila (`_contexto()`) y la pantalla del Editor (`editor_de()`). El
    Editor existe porque estas acciones estaban **solo** en el menú contextual, y quien no sabe
    que ese menú existe no las encuentra nunca; escribir la lista dos veces acabaría con dos
    listas discrepando, que es el mismo motivo por el que cada fichero de esta sección tiene un
    `_fin()` y no dos versiones.

    El orden va de lo que se usa a menudo a lo que se usa una vez: comprobar y analizar están
    arriba porque son las dos cosas que se hacen cuando algo va mal, y borrar está abajo del
    todo porque es la única irreversible. Mover (`Subir`/`Bajar`) sale solo con más de una
    fuente, y solo si hay algo arriba o abajo.

    Las acciones van **con el `fid` y nada más**: ni la contraseña, ni el usuario, ni la URL.
    Esto acaba en el historial de Kodi y en los `RunPlugin` de `default.py`.
    """
    # Los textos dependen del tipo. El Editor abrió estas opciones al menú contextual, y la
    # paridad se hizo literal: una lista M3U salía con el plot de panel Xtream («si la cuenta
    # vale, cuándo caduca»), que describe una acción que no es la que ocurre. `_opciones()` ya
    # recibe la fuente, así que no hacía falta ninguna otra vuelta.
    _es_m3u = (f.get('tipo') or '') == 'm3u'
    opciones = [
        {'rotulo': 'Comprobar', 'accion': 'fuentes_srv_check',
         'icono': 'xtream_reintentar.png',
         'plot': ('Pregunta a la lista si responde y qué trae. Es rápido; la ficha la guarda '
                  '"Analizar".' if _es_m3u else
                  'Pregunta al servidor si la cuenta vale, cuándo caduca y cuántas conexiones '
                  'tiene abiertas. Es rápido; la ficha que alimenta los filtros la guarda '
                  '"Analizar".')},
        {'rotulo': 'Analizar', 'accion': 'fuentes_srv_scan',
         'icono': 'xtream_analizar.png',
         'plot': ('Descarga la lista entera, la entiende y guarda su ficha: cuántos canales '
                  'trae y en qué grupos. Hace varias peticiones y tarda más que "Comprobar".'
                  if _es_m3u else
                  'Pregunta al servidor por la cuenta y por cuántas categorías de TV, cine y '
                  'series tiene, y lo guarda en su ficha, que es lo que usa "Filtrar y ordenar". '
                  'Hace varias peticiones y tarda más que "Comprobar".')},
        # La guía no es solo de Xtream: una lista M3U la tiene si trae `url-tvg` en su cabecera
        # (`fuentes_xtream.guia_de()`), así que la fila se ofrece en los dos casos y el plot dice
        # de qué depende. Lo de quitarla para M3U fue error mío: dejaba a una lista con guía sin
        # forma de bajarla.
        {'rotulo': 'Descargar la guía', 'accion': 'fuentes_guia_bajar',
         'icono': 'info_guia.png',
         'plot': ('Descarga la guía de programación (EPG) si la lista trae url-tvg en su '
                  'cabecera. Si no lo trae, esta fila te lo dice. No se descarga sola; hay que '
                  'pedirla aquí.' if _es_m3u else
                  'Descarga la guía de programación (EPG) de este servidor. No se descarga '
                  'sola; hay que pedirla aquí.')},
    ]
    if total > 1:
        if pos > 0:
            opciones.append(
                {'rotulo': 'Subir', 'accion': 'fuentes_srv_up',
                 'icono': 'xtream_orden.png',
                 'plot': 'Sube este servidor un puesto en la lista.'})
        if pos < (total - 1):
            opciones.append(
                {'rotulo': 'Bajar', 'accion': 'fuentes_srv_down',
                 'icono': 'xtream_orden.png',
                 'plot': 'Baja este servidor un puesto en la lista.'})
    opciones += [
        {'rotulo': 'Editar', 'accion': 'fuentes_srv_edit',
         'icono': 'opciones.png',
         'plot': 'Cambia la dirección, el usuario o la contraseña. Lo que '
                 'no se escriba se queda como está.'},
        {'rotulo': 'Renombrar', 'accion': 'fuentes_srv_rename',
         'icono': 'xtream_servidores.png',
         'plot': 'Le cambia el nombre que ves en las listas. No toca la dirección ni la cuenta.'},
        {'rotulo': 'Borrar', 'accion': 'fuentes_srv_del',
         'icono': 'adv_borrar.png',
         'plot': 'Borra la fuente, su caché y sus favoritos e historial. No se puede '
                 'deshacer; antes se pide confirmación.'},
    ]
    return opciones


def _contexto(f, pos, total):
    """Las entradas del menú contextual de una fuente.

    Es una **lista de tuplas** `(rótulo, orden)`, que es lo que espera
    `ui_utils.menu_contextual` -> `ListItem.addContextMenuItems` y lo
    que ya hace `iptv_lists._list_context` (`iptv_lists.py:~930`). Pasar otra cosa, como una
    tupla suelta, pinta una entrada de menú literalmente llamada "menu_srv" con el `fid` como
    orden: en pantalla sale un rótulo sin sentido y al pulsarlo no pasa nada.

    Las opciones salen de `_opciones()`, que es la que pinta también el Editor: una sola lista
    para las dos pantallas. Todas las órdenes son `RunPlugin` con **solo el `fid`**. Ni la
    contraseña, ni el usuario, ni la URL: esto acaba en el historial de Kodi y en los `RunPlugin`
    de `default.py`.
    """
    return [(opcion['rotulo'], 'RunPlugin({0})'.format(
                _u(action=opcion['accion'], fid=f['id'])))
            for opcion in _opciones(f, pos, total)]


def menu():
    """La lista de lo que hay añadido.

    La fila abre el contenido del servidor, mientras que la edición se gestiona
    desde el menú contextual.
    """
    import fuentes_store

    fuentes = fuentes_store.fuentes()
    # Con la lista vacía el menú sigue igual: los dos botones de añadir del final tienen que
    # salir, y son justo los que más falta hacen cuando no hay ninguno. No hay aquí un «añade tu
    # primer servidor» aparte: sería un tercer botón de lo mismo en la misma pantalla.

    total = len(fuentes)
    for pos, f in enumerate(fuentes):
        if f['tipo'] == 'm3u':
            clase = 'Lista M3U'
            accion = 'fuentes_m3u'
        else:
            clase = 'Servidor Xtream'
            accion = 'fuentes_cats'
        nombre = f['nombre'] + _marca_certificado(f)
        ficha = f.get('analisis') or {}
        # Las conexiones en uso cambian de un minuto a otro: un «Libre 1/3» de ayer en el
        # rótulo se lee como de ahora. Pasada la hora solo queda en «Filtrar y ordenar», que
        # dice de cuándo es.
        reciente = time.time() - _entero_de(ficha.get('cuando')) < VIGENCIA_CONEXIONES
        if ficha.get('ok') and reciente:
            h = ficha.get('hueco')
            c_act = ficha.get('conex_act')
            c_max = ficha.get('conex_max')
            if c_max and c_act is not None:
                c_lbl = '{0}/{1}'.format(c_act, c_max)
            elif c_max:
                c_lbl = '{0} máx'.format(c_max)
            else:
                c_lbl = ''
            if h is False:
                nombre += '  [COLOR orange][Lleno{0}][/COLOR]'.format(' ' + c_lbl if c_lbl else '')
            elif h is True and c_lbl:
                nombre += '  [COLOR lime][Libre {0}][/COLOR]'.format(c_lbl)
        import fuentes_xtream
        ui_utils.add_item(
            action=accion, fid=f['id'], sec='live', title=nombre,
            thumbnail=_icon('carpeta.png' if f['tipo'] == 'm3u' else 'xtream_servidores.png'), folder=True,
            # Una M3U puede llevar ?username=U&password=P en la URL, y ese plot
            # se ve en la tele. `_sin_credenciales` ya tapa las tres formas.
            plot='{0}\n{1}: {2}'.format(clase, 'Servidor' if f['tipo'] != 'm3u' else 'URL',
                                      fuentes_xtream._sin_credenciales(f['servidor'] or f['url'])),
            context=_contexto(f, pos, total))

    # Botones de consulta cuando hay más de una fuente.
    if len(fuentes) > 1:
        ui_utils.add_item(
            action='fuentes_scan_filtros', folder=True,
            title='Filtrar y ordenar servidores',
            thumbnail=_icon('xtream_filtros.png'),
            plot='Comprobación global de servidores y ordenación por disponibilidad, idioma o catálogo.')
        ui_utils.add_item(
            action='fuentes_mas_usr', folder=True,
            title='Lo más usado por servidor',
            thumbnail=_icon('xtream_top_usado.png'),
            plot='Estadísticas de reproducción por cuenta para evaluar rendimiento.')
    ui_utils.add_item(
        action='fuentes_srv_add', folder=False,
        title='Añadir un servidor',
        thumbnail=_icon('servidores_xtream.png'),
        plot='Pega el enlace completo de tu panel (http://servidor:puerto/get.php?username=X&password=Y) '
             'o introduce servidor, usuario y contraseña por separado. '
             'No se conecta a nada al guardar; comprobar que contesta es otra acción.')
    ui_utils.add_item(
        action='fuentes_srv_add', tipo='m3u', folder=False,
        title='Añadir una lista M3U',
        thumbnail=_icon('xtream_anadir_m3u.png'),
        plot='Dirección web directa de la lista remota (.m3u o .m3u8).')
    # Editor de servidores: reúne las acciones de cada servidor para que sean accesibles directamente.
    if fuentes:
        ui_utils.add_item(
            action='fuentes_editor', folder=True,
            title='[B]Editor de servidores[/B]',
            thumbnail=_icon('opciones.png'),
            plot='Gestión individual de cada fuente: comprobar, analizar, editar, renombrar '
                 'y borrar. La guía EPG se descarga solo si el servidor la tiene, y reordenar '
                 'solo si hay más de una fuente.')
    ui_utils.close_item_list()


def mas_usado_por_fuente():
    """Cuantas veces se ha reproducido desde cada servidor, de mas a menos.

    Es la pantalla que **no** tenia el sitio a un lado, y la que ya tienen los datos:
    `fuentes_store.uso_por_fuente()` suma los canales de cada
    servidor. Aqui solo se pinta, que es lo que faltaba.

    Y es **otra cosa** que `fuentes_vistas.mas_usados()`, que ordena canales sueltos. Esta
    suma por servidor; aquella cuenta cada canal por separado. No es la misma pantalla con
    otro nombre: una dice que canales ves mas y la otra dice que cuenta aguanta mejor.

    **La fila lleva `fid` y nada mas.** La url de un panel Xtream lleva el usuario y la clave
    dentro del camino, y lo que se manda en un `plugin://` lo escribe Kodi en su historial y
    sale en el log. El servidor se busca en el almacen al pulsar.

    Una fuente que no sale es que no se ha reproducido nada de ella, que **no** es lo mismo
    que cero veces: no se inventan filas de cero para rellenar.
    """
    import fuentes_store

    cuentas = fuentes_store.uso_por_fuente()
    nombres = {str(f['id']): (f.get('nombre') or f['id']) for f in fuentes_store.fuentes()}

    # Las que no estan en el almacen se quedan fuera: son cuentas de una fuente que ya no
    # existe, y una fila que lleva a un servidor que no esta no puede hacer nada.
    filas = sorted(((v, k) for k, v in cuentas.items() if k in nombres),
                   reverse=True)

    if not filas:
        ui_utils.add_item(
            action='fuentes_servidores', folder=True,
            title='[B]Todavía no hay nada reproducido[/B]',
            thumbnail=_icon('xtream_top_usado.png'),
            plot='Cuando reproduzcas algo desde aquí, verás qué servidor usas más.')
        ui_utils.close_item_list()
        return

    total = sum(v for v, _k in filas)
    for veces, fid in filas:
        share = int(round(100.0 * veces / total)) if total else 0
        ui_utils.add_item(
            action='fuentes_cats', fid=fid, sec='live', folder=True,
            title='{0}  [COLOR gray]({1} veces, {2}% del total)[/COLOR]'.format(
                nombres[fid], veces, share),
            thumbnail=_icon('xtream_servidores.png'),
            plot='De este servidor has reproducido {0} veces, un {1}% de todo lo que has '
                 'reproducido desde aquí. Pulsa para ver sus categorías.'.format(veces, share))
    ui_utils.close_item_list()


# --- el editor visible ------------------------------------------------------

def editor():
    """Opciones de gestión de cada servidor accesibles directamente."""
    import fuentes_store

    fuentes = fuentes_store.fuentes()
    if not fuentes:
        ui_utils.add_item(
            action='fuentes_srv_add', folder=False,
            title='[B]No hay ninguna fuente que configurar[/B]',
            thumbnail=_icon('servidores_xtream.png'),
            plot='Añade un servidor Xtream o una lista M3U y sus opciones saldrán aquí.')
        ui_utils.close_item_list()
        return

    if len(fuentes) == 1:
        editor_de(fuentes[0]['id'])
        return

    for f in fuentes:
        es_m3u = f.get('tipo') == 'm3u'
        ui_utils.add_item(
            action='fuentes_editor', fid=f['id'], folder=True,
            title=f.get('nombre') or 'Servidor',
            thumbnail=_icon('carpeta.png' if es_m3u else 'xtream_servidores.png'),
            plot='{0}. Elige esta para ver sus opciones: comprobar, analizar, editar, renombrar '
                 'y borrar.'.format('Lista M3U' if es_m3u else 'Servidor Xtream'))
    ui_utils.close_item_list()


def editor_de(fid):
    """Las opciones de **una** fuente, como filas de verdad.

    Son exactamente las mismas que su menú contextual, con el mismo orden y las mismas
    acciones: salen de `_opciones()`, que es la única lista. Aquí no se hace nada nuevo; lo
    único que cambia es que se ve.

    `pos` y `total` salen de la lista de fuentes porque «Subir» y «Bajar» dependen de dónde
    esté: `_opciones()` los pide para no ofrecer mover lo que no se puede mover.
    """
    import fuentes_store

    fuentes = fuentes_store.fuentes()
    f = next((x for x in fuentes if x['id'] == fid), None)
    if not f:
        # Mismo criterio que `editar()` y `borrar()`: se avisa.
        _no_esta()
        ui_utils.close_item_list()
        return
    pos = [x['id'] for x in fuentes].index(fid)
    ui_utils.add_item(
        action='fuentes_servidores', folder=True,
        title='[COLOR gray]‹ Volver a la lista de fuentes[/COLOR]',
        thumbnail=_icon('xtream_volver.png'),
        plot='Vuelve a "Servidores y listas", donde están todas.')
    for opcion in _opciones(f, pos, len(fuentes)):
        ui_utils.add_item(
            action=opcion['accion'], fid=fid, folder=False,
            title=opcion['rotulo'], thumbnail=_icon(opcion['icono']),
            plot=opcion['plot'])
    ui_utils.close_item_list()


# --- altas ----------------------------------------------------------------

def _aviso(texto, titulo=None):
    """Un aviso al usuario.

    **Dos argumentos, no uno.** La firma real de `Dialog.ok()` es
    `ok(heading, line1, line2="", line3="")` y los dos primeros son obligatorios, como en
    todo el addon. Con un solo
    argumento sale un `TypeError` y **no se ve ningun aviso**, que es justo cuando mas hace
    falta verlo. El titulo se pone aqui una vez para que no se cuele ninguno sin el.
    """
    xbmcgui.Dialog().ok(titulo or _NOMBRE, texto)


def _pregunta(titulo, defecto=''):
    """Una pregunta de texto, con el valor actual puesto de salida.

    La firma real es `input(heading, defaultt="", type=INPUT_ALPHANUM, option=ALPHANUM,
    autoclose=0)`. El **texto por defecto va en el segundo argumento**, no en el tercero: en
    Python eso no revienta, porque todo lo demas tiene valor por defecto, asi que
    `input(titulo, '', defecto)` se guarda y no dice nada... hasta que se abre el dialogo y el
    campo sale **vacio**. Editar un servidor, entonces, no teaching nada de lo que hay ahora.

    Sin tipo de entrada a proposito, igual que hace el proyecto entero
    (`iptv_lists.add_list()`). `xbmcgui.INPUT_ALPHANUM` no es de `input()` sino de `xbmc`.
    """
    valor = xbmcgui.Dialog().input(titulo, defecto)
    return (valor or '').strip()


def _pregunta_clave(titulo):
    """Una contraseña: se escribe escondida, y sin valor por defecto.

    La máscara va en `option=`, **con nombre**, no en el tercer argumento posicional. Puesta
    en el tercero, `option` se queda en su valor por defecto y la contraseña se ve en claro
    mientras se teclea, que es justo lo que no puede hacer una caja de contrasenas.
    """
    valor = xbmcgui.Dialog().input(titulo, '', option=xbmcgui.ALPHANUM_HIDE_INPUT)
    return (valor or '').strip()


def _pregunta_si(pregunta):
    """Confirmación de sí o no con Dialog().yesno(heading, line1)."""
    return xbmcgui.Dialog().yesno(_NOMBRE, pregunta)


def _segundo_plano(accion):
    """Un `DialogProgress`, o `None` si no se puede abrir.

    Se cierra en el `finally` de quien lo usa (`_cierra`) para evitar que la ventana
    quede colgada. Si `create()` falla, devuelve `None` y la comprobación continúa.
    """
    dp = xbmcgui.DialogProgress()
    try:
        dp.create(accion, '')
    except Exception:                                   # pragma: no cover
        return None
    return dp


def _cierra(dp):
    if dp is None:
        return
    try:
        dp.close()
    except Exception:                                   # pragma: no cover
        pass


def _refresca(aviso=None):
    """Vuelve a pintar la lista de fuentes y avisa si se le pasa un texto.

    Al invocarse desde menú contextual (handle -1), Kodi no refresca la vista
    automáticamente y requiere Container.Refresh explícito.

    **No realimentan la acción en bucle.** Las cinco están en `fuentes_tv._SCRIPT_ACTIONS`,
    que pre-cierra el directorio cuando la acción se ha abierto como carpeta, un atajo, un
    widget, un favorito. Es el mismo motivo por el que `mover()` puede refrescar sin más
    (`fuentes_tv.route()`).

    El aviso corto es para editar y renombrar, que no tenían ninguno: son cambios que no
    se notan en el momento y sin él parecía que no había pasado nada.
    """
    if aviso:
        xbmcgui.Dialog().notification('EspaTV', aviso)
    xbmc.executebuiltin('Container.Refresh')


def anadir(tipo=None):
    """Punto de entrada de alta desde el menú: ofrece teclado de Kodi o móvil/PC."""
    tipo_efectivo = tipo or 'xtream'
    titulo = 'Añadir lista M3U' if tipo_efectivo == 'm3u' else 'Añadir servidor Xtream'
    sel = xbmcgui.Dialog().select(titulo, [
        'Teclado de Kodi',
        'Escribir desde el móvil o PC',
    ])
    if sel < 0:
        return
    if sel == 1:
        import fuentes_remoto
        fuentes_remoto.importar_web(tipo_efectivo)
        return
    if tipo_efectivo == 'm3u':
        anadir_lista()
    else:
        anadir_servidor()


def anadir_servidor():
    """Alta de un servidor Xtream. Pregunta host, usuario y contraseña, y guarda.

    **No comprueba nada por red.** Comprobar es una acción aparte y explícita. Pinchar
    "añadir" y esperar a un panel que no contesta es la peor forma de dar de alta algo.
    """
    import fuentes_store

    servidor = _pregunta('Dirección del panel (ejemplo: servidor:número de puerto)')
    if not servidor:
        return
    # Con el enlace completo del panel (`get.php?username=...&password=...`) se saltan las dos
    # preguntas siguientes.
    import iptv_parse as P
    raw = servidor.strip()
    usuario, clave = '', ''
    xtream = P.parse_xtream_url(raw if re.match(r'(?i)https?://', raw) else 'http://' + raw)
    if xtream:
        servidor, usuario, clave = xtream
    try:
        servidor = _normaliza(servidor)
    except Exception as e:
        _aviso('No se ha podido entender el servidor.\n\n{0}'.format(e))
        return
    # `_normaliza` normaliza (añade protocolo por defecto y recorta espacios),
    # mientras que `_valida_url` comprueba sintaxis básica de host y caracteres.
    try:
        _valida_url(servidor)
    except _UrlMala as e:
        _aviso('Esa dirección no vale.\n\n{0}\n\n'
               'Tiene que ser la dirección de tu panel, completa: '
               'servidor:número de puerto'.format(e))
        return

    if not usuario:
        usuario = _pregunta('Usuario')
        if not usuario:
            return
    if not clave:
        clave = _pregunta_clave('Contraseña')
        if not clave:
            return

    # Si el certificado HTTPS falla (autofirmado o caducado), «Comprobar»
    # permite reintentar sin verificar certificados TLS.
    import fuentes_xtream
    # El nombre va al título de la fila y al `plugin://`: sin el `usuario:clave@` que se
    # haya pegado en la dirección.
    visible = fuentes_xtream._sin_credenciales(servidor)
    nombre = _pregunta('Nombre para reconocerlo', visible)
    # El formato de stream se lee del ajuste global en el momento de reproducir.
    fid = fuentes_store.anadir({
        'nombre': nombre or visible, 'tipo': 'xtream', 'servidor': servidor,
        'usuario': usuario, 'clave': clave, 'inseguro': False,
    })
    if not fid:
        _aviso(
            'No se ha podido guardar el servidor.\n\n'
            'O bien ya había uno igual, o bien el disco está lleno o el archivo no se puede '
            'escribir. Mira el log de Kodi para el detalle.')
        return
    _refresca('Servidor guardado. Ya puedes comprobarlo.')


def anadir_lista():
    """Alta de una lista M3U: una URL y poco más.

    No necesita `iptv_parse`: el alta no toca la red, así que no hay nada que interpretarse
    todavía. La lista se entiende cuando se compruebe, que es una acción aparte.
    """
    import fuentes_store

    url = _pregunta('Dirección de la lista M3U')
    if not url:
        return
    # Se valida antes de anteponer el esquema para no camuflar esquemas no soportados.
    if not url.lower().startswith(('http://', 'https://')):
        con_esquema = 'http://' + url
        try:
            _valida_url(con_esquema)
            url = con_esquema
        except _UrlMala:
            pass                       # se deja tal cual: el mensaje bueno sale abajo
    try:
        _valida_url(url)
    except _UrlMala as e:
        _aviso('Esa dirección no vale.\n\n{0}'.format(e))
        return

    # El defecto del nombre no puede ser la URL. En una lista de panel la
    # credencial va dentro de ella (`get.php?username=U&password=P`), y el
    # nombre acaba en el titulo de la fila y dentro del `plugin://` -
    # `ui_utils.add_item` lo mete ahi-, que Kodi guarda en el historial de
    # la tele. Se ofrece el anfitrion: se reconoce y no lleva nada. Y si se deja
    # el nombre en blanco, se cae en el anfitrion, no en la URL entera.
    #
    # El `netloc` lleva el `usuario:clave@` si se ha pegado en la dirección: se corta por la
    # última `@`, como `urllib3`. `_valida_url` ya ha exigido que haya servidor.
    anfitrion = urllib.parse.urlsplit(url).netloc.rpartition('@')[2]
    nombre = _pregunta('Nombre para reconocerla', anfitrion)
    # El formato no aplica a M3U: la extensión de cada canal la define la lista.
    fid = fuentes_store.anadir({
        'nombre': nombre or anfitrion, 'tipo': 'm3u', 'url': url,
        'servidor': '',
    })
    if not fid:
        _aviso(
            'No se ha podido guardar la lista.\n\n'
            'O bien ya había una igual, o bien el disco está lleno. Mira el log para el detalle.')
        return
    _refresca('Lista guardada.')


# --- editar, renombrar, borrar, ordenar -------------------------------------

def _no_esta():
    """El `fid` es de una fila que ya no esta. Se dice siempre.

    Mismo criterio que `editar()`: si uno avisa y el otro no, con una fila ya borrada desde
    otro sitio el botón no haría nada y parecería roto.
    """
    _aviso('Ese servidor ya no está.')


def editar(fid):
    """Cambia lo que haya que cambiar. Cada pregunta trae el valor actual de defecto."""
    import fuentes_store

    f = fuentes_store.fuente(fid)
    if not f:
        _no_esta()
        return

    if f['tipo'] == 'm3u':
        # Validación previa de URL para listas M3U al editar.
        url = _pregunta('Dirección de la lista M3U', f['url'])
        if url:
            # Validar antes de añadir esquema por defecto para evitar esquemas duplicados.
            if not url.lower().startswith(('http://', 'https://')):
                con_esquema = 'http://' + url
                try:
                    _valida_url(con_esquema)
                    url = con_esquema
                except _UrlMala:
                    # No vale ni con el esquema puesto: se deja tal cual, para que
                    # `_valida_url` dé el mensaje bueno (el de los esquemas o el del
                    # host), y no uno que hable de un esquema que se acaba de añadir.
                    pass
            try:
                _valida_url(url)
            except _UrlMala as e:
                _aviso('Esa dirección no vale.\n\n{0}\n\n'
                       'Tiene que ser la dirección de la lista, completa.'.format(e))
                return
            # `fuentes_store.editar()` borra la caché cuando cambia la URL.
            fuentes_store.editar(fid, url=url, servidor='')
            _refresca('Lista guardada.')
        return

    servidor = _pregunta('Servidor', f['servidor'])
    if not servidor:
        return
    usuario = _pregunta('Usuario', f['usuario'])
    clave = _pregunta_clave('Contraseña (déjala vacía si no cambia)') or f['clave']

    # Validación de la dirección del servidor tras normalizar.
    try:
        servidor = _normaliza(servidor)
        _valida_url(servidor)
    except _UrlMala as e:
        _aviso('Esa dirección no vale.\n\n{0}\n\n'
               'No se ha guardado ningún cambio.'.format(e))
        return
    except Exception as e:
        _aviso('No se ha podido entender el servidor.\n\n{0}'.format(e))
        return
    if not usuario:
        _aviso('El usuario no puede quedar vacío.\n\n'
               'Sin usuario no hay forma de entrar en el panel.')
        return
    campos = {'servidor': servidor, 'usuario': usuario, 'clave': clave}
    # Verificar el certificado solo tiene sentido en https: con http:// `inseguro` no hace
    # nada, y se quita para que la fila no diga «certificado sin verificar». El valor actual
    # va en el texto porque `yesno()` no admite una respuesta por defecto.
    if servidor.lower().startswith('https://'):
        ahora = 'NO se verifica' if f.get('inseguro') else 'se verifica'
        campos['inseguro'] = not _pregunta_si(
            '¿Verificar el certificado HTTPS de este servidor?\n\n'
            f'Ahora mismo {ahora}. Di «No» solo si su certificado está caducado o es '
            'autofirmado y no conecta de otra forma.')
    else:
        campos['inseguro'] = False
    # Confirmación explícita para guardar los cambios modificados.
    if not _pregunta_si('¿Guardar los cambios?'):
        return
    fuentes_store.editar(fid, **campos)
    # Aviso corto: con la confirmación de por medio no queda claro si se guardó.
    _refresca('Cambios guardados.')


def renombrar(fid):
    """Solo el nombre. Es lo único que se cambia sin tocar la red."""
    import fuentes_store

    f = fuentes_store.fuente(fid)
    if not f:
        _no_esta()
        return
    nombre = _pregunta('Nombre para reconocerlo', f['nombre'])
    if nombre:
        fuentes_store.editar(fid, nombre=nombre)
        _refresca('Nombre cambiado.')


def borrar(fid):
    """Borra la fuente, su caché y lo que solo existe por ella. Previa confirmación."""
    import fuentes_store

    f = fuentes_store.fuente(fid)
    if not f:
        _no_esta()
        return
    # Se cuentan antes favoritos e historial: el aviso tiene que decir cuántos se van.
    favs, hist = fuentes_store.cuenta_de_la_fuente(fid)
    # Sin líneas en blanco: el texto del `yesno` de Estuary deja 4 líneas y, con ellas, la
    # pregunta se iba por arriba con el desplazamiento automático.
    fuera = ('La lista original no se toca.' if f.get('tipo') == 'm3u'
             else 'Los canales del servidor no se tocan.')
    texto = f'¿Borrar "{f["nombre"]}"?\nSe borra también su caché guardada. {fuera}'
    if favs or hist:
        partes = []
        if favs:
            partes.append(f'{favs} favorito(s)')
        if hist:
            partes.append(f'{hist} del historial')
        texto += f'\nY se van con él {" y ".join(partes)}.'
    if not _pregunta_si(texto):
        return
    if not fuentes_store.borrar(fid):
        _aviso('No se ha podido borrar.\n\nMira el log de Kodi para el detalle.')
        return
    if favs or hist:
        fuentes_store.olvidar_fuente(fid)
        # Se vuelve a contar en vez de comparar con lo que devuelve: lo que importa es si queda
        # alguno, y la cifra de la confirmación pudo cambiar mientras se leía. Solo se miran los
        # favoritos, porque las filas de historial de un servidor borrado ya no se pintan.
        quedan = fuentes_store.cuenta_de_la_fuente(fid)[0]
        if quedan:
            _aviso(f'Borrado, pero no se han podido quitar {quedan} de sus favoritos.\n\n'
                   'Se quitan desde Favoritos, con «Quitar de favoritos».')
            _refresca()
            return
    _refresca('Borrado.')


def mover(fid, delta):
    """Sube o baja una posición. No toca la red y no puede fallar en silencio."""
    import fuentes_store

    if not fuentes_store.mover(fid, delta):
        # False es "no ha cambiado" (ya está en el extremo) o "no se ha podido guardar".
        # No se puede distinguir desde aquí, así que no se dice nada: la lista ya está bien.
        return
    xbmc.executebuiltin('Container.Refresh')


# --- comprobar y analizar --------------------------------------------------

def comprobar(solo=None):
    """Contacta con los servidores y dice qué pasa con cada uno.

    Es la acción que **sí** va a la red, y es explícita: el usuario la pide. Con `solo` se
    limita a una fuente; si no, a todas.
    """
    import fuentes_store

    fuentes = [f for f in fuentes_store.fuentes()
               if solo is None or f['id'] == solo]
    if not fuentes:
        # Sin `solo` es que no hay nada guardado y no hay nada que decir. Con `solo` es que el
        # `fid` vino de una fila que ya no existe, y eso si se avisa: es el mismo criterio
        # que `editar()` y `borrar()`, que dicen "ese servidor ya no está" en vez de callarse.
        if solo is not None:
            _no_esta()
        return
    if solo is None and not _pregunta_si(
            f'¿Comprobar todos los servidores guardados?\n\nEso es {len(fuentes)} conexión(es) '
            'a la red.'):
        return

    dp = _segundo_plano('Comprobando servidores')
    resultados = []
    try:
        for i, f in enumerate(fuentes):
            if dp is not None:
                # dp.update() requiere un porcentaje de 0 a 100.
                dp.update(int((i + 1) * 100 // max(len(fuentes), 1)),
                          '{0} de {1}'.format(i + 1, len(fuentes)))
                # Y el botón de cancelar, que no se miraba: se pulsaba y la comprobación
                # seguía. Lo que ya se ha comprobado sí se pinta, que es el mismo criterio
                # que `analizar()` con su plazo: un resultado parcial vale.
                try:
                    if dp.iscanceled():
                        break
                except Exception:                     # pragma: no cover
                    pass
            resultados.append((f, _comprueba_uno(f, dp)))
    finally:
        _cierra(dp)

    # Con el progreso ya cerrado, que la pregunta es modal.
    for i, (f, linea) in enumerate(resultados):
        if linea == _CERTIFICADO_MALO:
            nueva = _ofrece_sin_verificar(f)
            if nueva:
                resultados[i] = (nueva, _comprueba_uno(nueva, None))

    _pintan_resultados('Comprobación', resultados)


def _comprueba_uno(f, dp):
    """Contacta con una fuente y devuelve la línea que se va a pintar."""
    import fuentes_store
    import fuentes_xtream
    if f['tipo'] == 'm3u':
        return _comprueba_m3u(f, dp)
    try:
        datos = _pide(f['servidor'], f['usuario'], f['clave'], f['inseguro'], dp)
    except fuentes_xtream.ErrorCertificado:
        return _CERTIFICADO_MALO
    except fuentes_xtream.ErrorCuenta as e:
        return 'NO: {0}'.format(e)
    except fuentes_xtream.ErrorRed as e:
        return 'No se ha podido contactar: {0}'.format(e)
    except Exception as e:                             # pragma: no cover
        # Y aqui tambien: el comodin es justo por donde se escapan las cosas
        # raras, y el mensaje de `requests` lleva la URL con la credencial.
        return 'Error inesperado: {0}'.format(
            fuentes_xtream._sin_credenciales(e))

    # _lee_cuenta() dentro del try para capturar ErrorCuenta si las credenciales son incorrectas.
    try:
        cuenta = _lee_cuenta(datos)
    except fuentes_xtream.ErrorCuenta as e:
        return 'NO: {0}'.format(e)
    except Exception as e:
        # Una respuesta rara (`user_info` que no es un dict) no es una credencial mala: es
        # otra cosa, y decir "contraseña incorrecta" cuando el panel ha contestado una
        # tontería manda a cambiar algo que no es el problema.
        return 'El servidor ha contestado algo que no se entiende: {0}'.format(
            fuentes_xtream._sin_credenciales(e))

    try:
        fuentes_store.editar(f['id'], cuenta=cuenta)
    except Exception as e:                             # pragma: no cover
        # Guardar la ficha es una mejora, no el resultado. Si falla, el "OK" sigue siendo
        # cierto y no tiene por qué convertirse en un error: el siguiente comprobar lo
        # vuelva a preguntar.
        _log('no se ha podido guardar la cuenta de {0}: {1}'.format(
            f.get('nombre') or f.get('id'), e))
    return 'OK: {0}'.format(_estado_de(datos))


def _comprueba_m3u(f, dp):
    """Una lista M3U se comprueba descargándola y contando lo que trae.

    `lan_ok=True` porque puede estar en la red local, que es lo que
    `_download` bloquea por defecto.
    """
    import iptv_lists
    import iptv_parse as P
    # Hace falta para sanear, no para hablar con el panel: el
    # mensaje de error de una descarga lleva la credencial dentro.
    import fuentes_xtream

    try:
        crudo = iptv_lists._download(f['url'], False, dp, limit=iptv_lists._MAX_DOWNLOAD,
                                     lan_ok=True, timeout=iptv_lists._TIMEOUT)
    except P.ListError as e:
        # Saneado, siempre. El mensaje de `requests` lleva la URL entera, y en
        # una M3U de panel la credencial va en ella. Esto se pinta en la tele.
        return 'No se ha podido descargar: {0}'.format(
            fuentes_xtream._sin_credenciales(e))
    except iptv_lists._NeedsInsecure:
        return 'NO: El certificado HTTPS de esta lista no es válido.'
    except Exception as e:                             # pragma: no cover
        # Y aqui tambien: el comodin es justo por donde se escapan las cosas
        # raras, y el mensaje de `requests` lleva la URL con la credencial.
        return 'Error inesperado: {0}'.format(
            fuentes_xtream._sin_credenciales(e))
    try:
        resultado = P.parse_any(P.decode(crudo), f['url'])
    except Exception as e:
        return 'La lista se descarga pero no se entiende: {0}'.format(e)
    # `parse_any()` devuelve un dict con la clave `channels`.
    canales = resultado.get('channels') if isinstance(resultado, dict) else resultado
    if not isinstance(canales, list):
        return 'La lista se descarga pero no se entiende: no trae una lista de canales'
    return 'OK: {0} canal(es)'.format(len(canales))


PROP_ANALIZANDO = 'espatv_fuentes_analizando'


def _marca_analizando():
    """Apunta que hay un analisis en marcha, con la hora.

    Es una propiedad de `Window(10000)`: en Kodi cada pulsación es un intérprete
    nuevo (`addon.xml` no lleva `reuselanguageinvoker`), asi que una variable del modulo no
    sobrevive a la siguiente y la marca no valdria de nada.

    Sin ella, nada impide pulsar «Analizar» otra vez mientras corre el primero: son doce
    conexiones mas contra los mismos paneles, que es justo lo que `_se_puede_analizar()`
    avisa que corta la reproduccion. Y el resultado es el mismo que ya se esta calculando.
    """
    try:
        xbmcgui.Window(10000).setProperty(PROP_ANALIZANDO, str(int(time.time())))
    except Exception:
        pass


def _ya_se_esta_analizando():
    """True si hay un analisis de menos de `PLAZO_ANALISIS + 10` s.

    El margen de 10 s es por el arranque y el cierre: el plazo mide lo que tarda el bucle de
    espera, y entre que se pulsa y se pone la marca (y entre que acaba y se quita) pasa un
    rato. Sin margen, un analisis que va justo dejaria pulsar otro rozando el final.

    Un valor que no es un numero se trata como «no hay nada»: es mejor poder analizar que
    quedarse sin poder por una propiedad corrupta.
    """
    try:
        cuando = int(xbmcgui.Window(10000).getProperty(PROP_ANALIZANDO) or 0)
    except Exception:
        return False
    if cuando <= 0:
        return False
    return (time.time() - cuando) < (PLAZO_ANALISIS + 10)


def _desmarca_analizando():
    """Quita la marca. En un `finally`, que es lo que hace que se quite siempre.

    Una marca que se queda puesta bloquea el analisis hasta que pase el plazo: «Analizar»
    diría «ya se está analizando» sin nada corriendo.
    """
    try:
        xbmcgui.Window(10000).setProperty(PROP_ANALIZANDO, '')
    except Exception:
        pass


def analizar(solo=None):
    """Analiza las fuentes a la vez y guarda una ficha por fuente.

    Es la accion que **manda a la red** a lo grande, y por eso va en hilos:

    - **En paralelo, no en fila.** Con ocho fuentes, en serie son ocho esperas de red seguidas. En
      paralelo es la mas lenta de las ocho. No es una mejora de estilo: es la diferencia entre un
      minuto y ocho segundos.
    - **Doce como mucho** (`HILOS_ANALISIS`), porque un panel doméstico aguanta cuatro o cinco
      conexiones simultaneas. Pasarse no es mas rapido, es mas errores de "timeout".
    - **Con plazo** (`PLAZO_ANALISIS`) y **guardando lo que haya** al llegar o al cancelar. Un
      analisis parcial vale: con doce fuentes y una que se cuelga, las otras once ya estan
      guardadas.
    - **Avisando antes si se esta viendo algo**, porque esto abre doce conexiones y puede cortar
      lo que se ve. Una pregunta, no un detalle.
    - Control de ejecución concurrente: se registra en `Window(10000)` para no lanzar
      análisis duplicados mientras haya uno en curso.

    Y lo que decide: **el guardado es del hilo principal y al final**. Los hilos solo piden datos y
    devuelven dicts; escribir `mis_fuentes.json` desde doce sitios a la vez es la via directa a
    perder fuentes.
    """
    if _ya_se_esta_analizando():
        _aviso('Ya se está analizando.\n\n'
               'Espera a que acabe el que hay en marcha. Analizar abre muchas conexiones a la '
               'vez, y hacerlo dos veces seguidas es el doble de carga para los mismos datos.')
        return
    # La marca se pone antes de las preguntas y se quita en un `finally`: si se pusiera
    # después y se respondiera «no», se quedaría puesta hasta que venza el plazo.
    _marca_analizando()
    try:
        import fuentes_store

        fuentes = [f for f in fuentes_store.fuentes() if solo is None or f['id'] == solo]
        if not fuentes:
            if solo is not None:
                _no_esta()
            return

        if solo is None:
            if not _pregunta_si(
                    '¿Analizar {0} servidor(es) a la vez?\n\nEso son {0} conexión(es) abiertas a la '
                    'vez. Tarda menos que una a una.'.format(len(fuentes))):
                return
            if not _se_puede_analizar():
                return

        fichas = _analizan_en_paralelo(fuentes)

        # Fuera de los hilos, que la pregunta es modal y no puede salir doce veces a la vez.
        for f in fuentes:
            ficha = fichas.get(f['id'])
            if ficha is not None and ficha.get('resumen') == _CERTIFICADO_MALO:
                nueva = _ofrece_sin_verificar(f)
                if nueva:
                    fichas[f['id']] = _escanea_uno(nueva)

        hechos = 0
        results = []
        for f in fuentes:
            ficha = fichas.get(f['id'])
            if ficha is None:
                # No ha llegado: el plazo o el cancelar. Se dice cuál, y no se calla. Un
                # diálogo que omite al servidor que no ha contestado parece que los demás han
                # ido todos bien, y no es cierto: es la misma razón por la que `comprobar()`
                # pinta lo que ya se ha comprobado al cancelar.
                results.append((f, 'No ha llegado: se ha acabado el plazo o se ha cancelado'))
                continue
            results.append((f, ficha['resumen']))
            if f.get('tipo') == 'xtream':
                ficha['servidor'] = f.get('servidor') or ''
            if fuentes_store.analisis_guardar(f['id'], ficha):
                hechos += 1

        # Acaba como `comprobar()`, con una línea y un color por servidor; el recuento va en
        # la última línea.
        _pintan_resultados('An\u00e1lisis', results)
        if hechos != len(results):
            xbmcgui.Dialog().notification(
                'EspaTV', 'Analizadas {0} de {1} fuente(s).'.format(hechos, len(results)))


    finally:
        _desmarca_analizando()


def _escanea_uno(f, dp=None):
    """La ficha de una fuente. **Nunca lanza.**

    Los campos son los que el filtro y el orden necesitan:

    - `ok`: si la credencial vale. Sin esto no se puede decir "solo los que funcionan".
    - `n_cats`: cuántas categorías de TV, cine y series tiene. Es lo que se usa para ordenar, y
      **es un sustituto**, no el número de canales: contarlos exige bajarlos todos, lo que
      tardaría más de un minuto. Con
      `get_*_categories` sale la misma señal por una centésima parte de los bytes, y a cambio un
      servidor con una sola categoría y 5.000 canales sale mal clasificado. Se acepta, y **se dice
      en la etiqueta del botón**, que es lo que hace que la orden siga siendo honesta.
    - `caduca`: el `exp_date` de la cuenta, en segundos. `0` significa "no lo dice", que no es lo
      mismo que "caduca ya": ordenar por caducidad deja al final a los que no lo dicen.
    - `hueco`: conexiones libres, o `None` si no se ha podido saber.
    - `resumen`: el texto que ya pintaba `comprobar()`. Se reutiliza en vez de duplicar el
      formato, que si no habría que cambiar en dos sitios.

    Y **nada de esto escribe en disco**: el análisis corre en doce hilos y escribir
    `mis_fuentes.json` desde varios a la vez es la vía directa a perder fuentes. Quien guarda es
    `analizar()`, y solo cuando ya no hay ningún hilo corriendo.
    """
    import fuentes_xtream

    ficha = {'resumen': '', 'ok': False, 'n_cats': {'live': 0, 'vod': 0, 'series': 0},
             'caduca': 0, 'hueco': None, 'langs': [], 'tipo': f.get('tipo') or ''}

    if f.get('tipo') == 'm3u':
        # Una M3U no tiene cuenta ni categorías: se comprueba descargándola, que es lo único que
        # se puede hacer, y no se inventan ceros que luego salen en un filtro como si fueran
        # un dato.
        ficha['resumen'] = _comprueba_m3u(f, dp)
        ficha['ok'] = ficha['resumen'].startswith('OK')
        return ficha

    try:
        datos = _pide(f['servidor'], f['usuario'], f['clave'], f.get('inseguro'), dp)
    except Exception as e:
        # Se traga el error entero, también el de una excepción inesperada: el análisis de ocho
        # fuentes no puede caer porque la tercera ha petado.
        try:
            motivo = fuentes_xtream._sin_credenciales(e)
        except Exception:                              # pragma: no cover
            motivo = 'sin motivo conocido'
        if isinstance(e, fuentes_xtream.ErrorCertificado):
            ficha['resumen'] = _CERTIFICADO_MALO
        elif isinstance(e, fuentes_xtream.ErrorCuenta):
            ficha['resumen'] = 'NO: {0}'.format(motivo)
        elif isinstance(e, fuentes_xtream.ErrorRed):
            ficha['resumen'] = 'No se ha podido contactar: {0}'.format(motivo)
        else:                                         # pragma: no cover
            ficha['resumen'] = 'Error inesperado: {0}'.format(motivo)
        return ficha

    try:
        cuenta = _lee_cuenta(datos)
    except Exception as e:
        ficha['resumen'] = 'NO: {0}'.format(
            fuentes_xtream._sin_credenciales(e))
        return ficha

    ficha['ok'] = True
    ficha['caduca'] = _entero_de(cuenta.get('caduca'))
    ficha['hueco'] = _hueco_de(cuenta)
    ficha['conex_max'] = _entero_de(cuenta.get('conexiones'))
    ficha['conex_act'] = _entero_de(cuenta.get('actual')) if cuenta.get('actual') is not None else None
    ficha['resumen'] = 'OK: {0}'.format(_estado_de(datos))

    # Las categorías van fuera del `try` de la cuenta a propósito: que la cuenta sea válida y
    # que el panel mande las categorías son dos cosas distintas. Un panel que no las manda deja
    # la ficha a cero y el resto de datos sigue valiendo, que es lo que se quiere: la fuente
    # funciona, y no saber cuántas categorías tiene no la hace mala.
    for seccion in ('live', 'vod', 'series'):
        try:
            cats = fuentes_xtream.categorias(f, seccion)
            ficha['n_cats'][seccion] = len(cats or [])
            if seccion == 'live':
                ficha['langs'] = _langs_de(cats)
        except Exception as e:
            _log('{0}: no se han podido leer las categorías de {1}: {2}'.format(
                f.get('nombre') or f.get('id'), seccion,
                fuentes_xtream._sin_credenciales(e)))
    return ficha


def _entero_de(valor):
    """Un entero, o `0` si lo que llega no lo es. Nunca lanza.

    `exp_date` viene como número, como texto y a veces como `"no soy un numero"`. Un `int()` a
    pelo tumba la ficha entera por un campo que solo ordena una lista.
    """
    try:
        n = int(str(valor).strip())
    except (TypeError, ValueError, AttributeError):
        return 0
    return n if n > 0 else 0


def _hueco_de(cuenta):
    """Conexiones libres: `True`, `False`, o `None` si no se sabe.

    Los tres, no dos, y el tercero es el que importa: un panel que dice el tope pero no el uso
    **no es un servidor lleno**, es un servidor del que no sabemos. Bloquearlo sería tirar una
    fuente que funciona, y el filtro se llama "solo con hueco libre": lo que no se sabe no es que
    no haya hueco.
    """
    maximo = cuenta.get('conexiones')
    actual = cuenta.get('actual')
    if maximo in (None, '', 0, '0'):
        return None
    try:
        return int(actual) < int(maximo)
    except (TypeError, ValueError):
        # Hay tope y no se sabe el uso: no se bloquea.
        return None


# --- los filtros y las ordenaciones -------------------------------------------
#
# Nueve, y no nueve filtros: cuatro son filtros y cinco son órdenes. Se mezclan en la misma
# pantalla porque es lo que hace falta tomar una decisión ("¿cuál uso?") y son el mismo tipo de
# decisión. Pero la diferencia importa y por eso cada uno lleva su tipo:
#
# - `filtros`: quitan fuentes. Digues lo que digues, siempre te quedan algunas.
# - `orden`: no quitan nada, las reordenan. Si no hubiera ninguna, volverían todas.
#
# Y una cuarta cosa que no es un filtro ni una orden: `hueco` es un filtro de tres estados
# (`True`, `False`, `None`), y "no lo sé" tiene que ser una respuesta distinta de "no hay hueco".

#: Los cuatro filtros, con el rótulo y lo que dejan fuera.
_FILTROS = (
    ('all', 'Todos'),
    ('ok', 'Solo los que funcionan'),
    ('libre', 'Solo con hueco libre'),
    ('es', 'Solo con español'),
)

#: Las cinco órdenes. La etiqueta dice qué se ordena y por qué, no "Ordenar por": con quince
#: servidores, "Ordenar: más categorías de cine" dice qué se gana y "Ordenar" no dice nada.
_ORDENES = (
    ('tv', 'Más categorías de TV', 'n_cats', 'live'),
    ('vod', 'Más categorías de cine', 'n_cats', 'vod'),
    ('series', 'Más categorías de series', 'n_cats', 'series'),
    ('exp', 'Caducan más tarde', 'caduca', None),
    ('usados', 'Los que más usas', 'uso', None),
)


def _pasa_el_filtro(ficha, cual):
    """True si la ficha pasa el filtro. **Nunca lanza.**

    Cada filtro se define por lo que **quita**, no por lo que tiene que tener, para que un dato
    que falta no la haga pasar por accidente. Un `if ficha.get('ok')` deja pasar a quien no se ha
    analizado nunca, que es justo lo contrario de "solo los que funcionan".
    """
    if not isinstance(ficha, dict) or not ficha:
        # Sin ficha no ha analizado: no puede affirmar que funciona.
        return cual == 'all'
    if cual == 'all':
        return True
    if cual == 'ok':
        return bool(ficha.get('ok'))
    if cual == 'libre':
        # `hueco` es True (queda), False (no queda) o None (no informado).
        # Lo desconocido no bloquea: se permite el paso si no es explícitamente False.
        #
        # `is not False` y no "es verdadero": se queda lo que dice que sí y lo que no
        # dice nada. Se va lo que dice que no queda.
        return bool(ficha.get('ok')) and ficha.get('hueco') is not False
    if cual == 'es':
        # Comprobar específicamente variantes de español en los idiomas detectados.
        return any(str(x).upper() in _IDIOMAS_ES for x in (ficha.get('langs') or []))
    return True


#: Los códigos que cuentan como español. Se buscan igual que `_CODIGOS_IDIOMA`: como palabras
#: enteras, y con las variantes largas que es lo que pone un panel ("Latino", "LatAm").
_IDIOMAS_ES = ('ESP', 'SPA', 'LATINO', 'LATAM', 'LAT', 'ES')


def _cantidad(valor):
    """Un entero de lo que venga, o `0`. **Nunca lanza**, ni con `"muchos"` dentro.

    La ficha la escribe este mismo módulo, pero `mis_fuentes.json` puede estar
    a medio escribir, y una orden no puede tumbar una pantalla por un campo que solo ordena.
    """
    try:
        return int(valor or 0)
    except (TypeError, ValueError):
        return 0


def _clave_de_orden(f, tipo, seccion, usos):
    """La clave por la que se ordena. **A menor, mejor**.

    Se recibe la **fuente** y se leen dos sitios distintos a propósito: el `id` de la fuente (que
    es la clave del fichero de uso) y los datos de su ficha (que es lo que cuenta categorías y
    caducidad). Se reciben en la misma llamada porque mezclar los dos dicts dentro de la función
    es donde se mezcla uno por otro: `f.get('caduca')` sobre la fuente da `None` siempre y la
    orden se queda sin hacer nada, en silencio.

    Y lo que no se sabe se traduce a `0`, que es lo que queda **al final** en una orden
    descendente, porque las claves de verdad son negativas. Eso es lo que hace que
    `caduca == 0` no salga primero: `0` no es "caduca ya", es "no lo dice", y una orden que pone
    delante lo que no ha dicho nada hace elegir el servidor más dudoso.
    """
    ficha = f.get('analisis') or {}
    if tipo == 'uso':
        return -_cantidad(usos.get(f.get('id')))
    if tipo == 'caduca':
        caducidad = _cantidad(ficha.get('caduca'))
        return -caducidad if caducidad else 0
    if tipo == 'n_cats':
        return -_cantidad((ficha.get('n_cats') or {}).get(seccion))
    return 0


def _ordenan(fuentes, cual, usos):
    """Las fuentes ordenadas por `cual`. Devuelve **todas**: una orden no quita ninguna.

    Se ordena por la **fuente** y no por la ficha, porque la clave de uso va por `fid` y la ficha
    no lo lleva: son datos de dos sitios distintos y el `fid` vive en la fuente.

    Las que no tienen ficha se quedan **al final**, en su orden original, y no en medio: un
    servidor sin analizar no es el primero ni el último, es "no lo sé". Y el desempate es por
    nombre, para que la pantalla no cambie de orden entre dos pulsaciones.
    """
    con_ficha = [f for f in fuentes if (f.get('analisis') or {})]
    sin_ficha = [f for f in fuentes if not (f.get('analisis') or {})]
    tipo = seccion = None
    for nombre, _rotulo, t, s in _ORDENES:
        if nombre == cual:
            tipo, seccion = t, s
            break
    if tipo is None:
        return list(fuentes)
    con_ficha.sort(key=lambda f: (_clave_de_orden(f, tipo, seccion, usos),
                                  str(f.get('nombre') or '')))
    return con_ficha + sin_ficha


def filtros():
    """La pantalla de qué mostrar: cuatro filtros y cinco órdenes, con los recuentos a la vista.

    Los recuentos van en la propia etiqueta porque **un filtro sin el número es un filtro a
    ciegas**: "solo los que funcionan" con 0 al lado es información, y con 2 al lado es mejor
    información.

    Y cuando **nunca se ha analizado**, no se cuentan los filtros: mostrarlos con ceros haría
    creer que hay 0 servidores que funcionan, que es mentira; lo que no se sabe es cuántos
    funcionan. En ese caso solo sale el botón de analizar.
    """
    import fuentes_store

    fuentes = fuentes_store.fuentes()
    if not fuentes:
        ui_utils.add_item(
            action='fuentes_srv_add', title='[B]Añade tu primer servidor[/B]',
            folder=True, thumbnail=_icon('servidores_xtream.png'),
            plot='No incluye servidores de serie. Pega tu enlace Xtream o lista M3U '
                 '(ej: http://servidor:puerto/get.php?username=X&password=Y), o introduce servidor, '
                 'usuario y clave por separado. También puedes enviarlos desde el móvil o PC.')
        ui_utils.close_item_list()
        return

    fichas = [f.get('analisis') or {} for f in fuentes]
    sin_analizar = not any(fichas)

    ui_utils.add_item(
        action='fuentes_scan', folder=False,
        title='Analizar {0} servidor(es) a la vez'.format(len(fuentes)),
        thumbnail=_icon('xtream_analizar.png'),
        plot='Comprueba los que funcionan, cuántos tienen, cuándo caducan y si queda hueco. '
             'Se pregunta antes y, si estás viendo algo, también.')
    # «Comprobar» se expone en la interfaz junto a «Analizar» (ver HUERFANAS_DECLARADAS).
    # A diferencia de analizar() (en paralelo, persiste la ficha y alimenta filtros),
    # comprobar() va en serie, no persiste y diagnostica el fallo individual de cada servidor.
    ui_utils.add_item(
        action='fuentes_check', folder=False,
        title='Comprobar {0} servidor(es) uno a uno'.format(len(fuentes)),
        thumbnail=_icon('adv_anti_errores.png'),
        plot='Va uno a uno y dice qué le pasa a cada servidor: si no entra, si la contraseña '
             'no vale o si no queda hueco. No guarda nada, solo informa. Se pregunta antes.')
    if not sin_analizar:
        # Con _pasa_el_filtro(), el mismo criterio que la vista: con una condición propia por
        # recuento, la etiqueta podría decir 3 y la pantalla salir vacía.
        cuantos = dict((nombre, sum(1 for x in fichas if _pasa_el_filtro(x, nombre)))
                       for nombre, _r in _FILTROS)
        # Antigüedad por filtro: la del más viejo de los que enseña ese filtro, no la de toda la
        # lista, para que la fecha hable de los mismos servidores que el número.
        antiguedades = {}
        for nombre, _r in _FILTROS:
            los_de_este = [x for x in fichas if _pasa_el_filtro(x, nombre)]
            mas_viejo = min((int(x['cuando']) for x in los_de_este
                             if isinstance(x, dict) and x.get('cuando')), default=0)
            antiguedades[nombre] = (_antiguedad(int(time.time()) - mas_viejo)
                                    if mas_viejo else '')
        for nombre, rotulo in _FILTROS:
            titulo = '{0}  [COLOR gray]({1})[/COLOR]'.format(rotulo, cuantos[nombre])
            if antiguedades[nombre]:
                titulo += '  [COLOR gray]({0})[/COLOR]'.format(antiguedades[nombre])
            if nombre == 'es':
                ic_flt = 'xtream_cat_es.png'
            elif nombre == 'all':
                ic_flt = 'xtream_cat_todas.png'
            else:
                ic_flt = 'xtream_filtros.png'
            ui_utils.add_item(
                action='fuentes_scan_filtro', flt=nombre, folder=True,
                title=titulo,
                thumbnail=_icon(ic_flt),
                plot=('Todas tus fuentes, sin quitar ninguna'
                      if nombre == 'all'
                      else 'De entre las que ya están analizadas'))
        for nombre, rotulo, _tipo, _sec in _ORDENES:
            ui_utils.add_item(
                action='fuentes_scan_filtro', flt=nombre, folder=True,
                title=rotulo, thumbnail=_icon('xtream_orden.png'),
                plot=('Reordena los servidores. No quita ninguno, y los que no se han analizado '
                      'se quedan al final.'))
    ui_utils.close_item_list()


def _explica_el_vacio(cual):
    """Pantalla informativa cuando un filtro no devuelve resultados."""
    import fuentes_store

    fuentes = fuentes_store.fuentes()
    if not fuentes:
        ui_utils.add_item(
            action='fuentes_srv_add', folder=False,
            title='[B]No hay ningún servidor[/B]',
            thumbnail=_icon('xtream_srv_vacio.png'),
            plot='Añade uno y desde aquí podrás filtrar, comprobar y ordenar.\n\n'
                 'Si tenías servidores y ya no están, la copia de seguridad está en '
                 'Ajustes del addon.')
        ui_utils.close_item_list()
        return True

    if cual in [n for n, _r in _FILTROS] and cual != 'all':
        sin_analizar = [f for f in fuentes if not f.get('analisis')]
        quedan = [f for f in fuentes if _pasa_el_filtro(f.get('analisis') or {}, cual)]
        if quedan:
            return False
        rotulo = dict((n, r) for n, r in _FILTROS).get(cual, cual)
        ui_utils.add_item(
            action='fuentes_scan', folder=False,
            title='[B]Ninguno pasa "{0}"[/B]'.format(rotulo),
            thumbnail=_icon('xtream_filtro_vacio.png'),
            plot=('Ninguno de tus {0} servidor(es) cumple este filtro.'.format(len(fuentes))
                  + ('\n\nLos que no se han analizado no tienen datos para filtrarlos: pulsa '
                     '"Analizar" para que cada uno tenga su ficha.' if sin_analizar else '')))
        if sin_analizar:
            ui_utils.add_item(
                action='fuentes_scan', folder=False,
                title='[B]Analizar {0} servidor(es)[/B]'.format(len(sin_analizar)),
                thumbnail=_icon('adv_anti_errores.png'),
                plot='Comprueba estado de conexión, caducidad y catálogo disponible.')
        else:
            ui_utils.add_item(
                action='fuentes_srv_add', folder=False,
                title='[B]Añadir otro servidor[/B]',
                thumbnail=_icon('xtream_srv_vacio.png'),
                plot='Ya están todos analizados y ninguno cumple este filtro.')
        ui_utils.close_item_list()
        return True

    return False


def aplicar_filtro(params):
    """Los servidores que pasan el filtro, o todos ordenados como se pida.

    Un filtro que se queda **sin nada** se dice, en vez de pintar una pantalla vacía que parece un
    fallo. Y se dice cuál era: "no hay ninguno con hueco libre" y "no hay ninguno con español" son
    cosas distintas, y sin el nombre del filtro no hay manera de saber cuál se pulsó.
    """
    import fuentes_store

    cual = params.get('flt') or 'all'
    fuentes = fuentes_store.fuentes()
    if not fuentes:
        _explica_el_vacio(cual)
        return

    usos = {}
    if cual == 'usados':
        try:
            usos = fuentes_store.uso_por_fuente()
        except Exception:                             # pragma: no cover
            usos = {}

    if cual in [n for n, _r in _FILTROS]:
        quedan = [f for f in fuentes if _pasa_el_filtro(f.get('analisis') or {}, cual)]
        if not quedan and cual != 'all':
            _explica_el_vacio(cual)
            return
        fuentes = quedan
    else:
        fuentes = _ordenan(fuentes, cual, usos)

    _pinta_servidores(fuentes)
    ui_utils.close_item_list()


def _pinta_servidores(fuentes):
    """Las fuentes en una lista, con su ficha en el `plot` si la tienen.

    El `plot` enseña lo que el análisis averiguó, porque un filtro que ordena por "más categorías
    de cine" sin decir cuántas son es un filtro a ciegas: se ve el orden, pero no el motivo.

    **Esta lista no lleva título propio** (4.10). Antes se armaba uno con el rótulo del
    filtro y el número de servidores, y se pasaba aquí como `como=`… que el cuerpo nunca
    usaba. O sea que el título **se calculaba y no se pintaba**: el código de abajo no lo usaba
    para nada, y lo que se ve es el título de la carpeta, el de Kodi.

    **No se ha arreglado**, y es a propósito. `ui_utils` no tiene ninguna forma de poner
    título a un directorio, así que arreglarlo era escribir esa pieza primero, y eso ya
    es una funcionalidad nueva. Lo que se ha hecho es quitar el cable muerto y dejarlo
    escrito, para que nadie busque un título que no existe ni lo dé por perdido.
    """
    import fuentes_xtream
    for f in fuentes:
        if f.get('tipo') == 'm3u':
            clase, accion = 'Lista M3U', 'fuentes_m3u'
        else:
            clase, accion = 'Servidor Xtream', 'fuentes_cats'
        nombre = (f.get('nombre') or '') + _marca_certificado(f)
        # Saneada: en una M3U de panel la credencial va dentro de la URL.
        donde = fuentes_xtream._sin_credenciales(f.get('servidor') or f.get('url') or '?')
        lineas = [clase, 'Servidor: {0}'.format(donde)]
        for extra in _lineas_de_ficha(f.get('analisis') or {}):
            lineas.append(extra)
        ui_utils.add_item(
            action=accion, fid=f['id'], sec='live', title=nombre,
            thumbnail=_icon('carpeta.png' if f.get('tipo') == 'm3u' else 'xtream_servidores.png'), folder=True,
            plot=chr(10).join(lineas),
            context=_contexto(f, 0, 1))


def _plural(numero, singular, plural):
    """«1 mes» y «2 meses», que en español el uno no lleva plural."""
    return singular if numero == 1 else plural


def _antiguedad(segundos):
    """Cuanto tiempo ha pasado, en palabras: «hace 3 días», «hace 2 h» (6.4).

    **Redondeado a la unidad por encima, no a la anterior.** Hace 25 horas son «hace 2 días» y no
    «hace 1 día», porque «1 día» hace pensar que los datos son de ayer cuando en realidad son
    de anteayer. Un dato viejo puede parecer viejo de más; uno nuevo, nuevo de menos, que es la
    mentira que esta función existe para no decir.

    Un `ts` del futuro (un reloj que va atrás) **no dice nada** en vez de decir «hace -1 h».

    **Las tildes van con `chr()`** porque el editor de esta sesión se las come, y una palabra
    mal escrita en la pantalla de la tele no es un detalle. Lo mismo los plurales: `_plural()`
    porque «1 meses» y «1 anos» se leen fatal, y solo se ven probando los cortes.
    """
    try:
        segundos = int(segundos)
    except (TypeError, ValueError):
        return ''
    if segundos < 0:
        return ''
    if segundos < 120:
        return 'hace un momento'
    if segundos < 7200:
        return 'hace {0} min'.format(int(segundos / 60))
    if segundos < 172800:
        return 'hace {0} h'.format(int(segundos / 3600))
    if segundos < 2592000:
        return 'hace {0} {1}'.format(int(segundos / 86400),
                                    _plural(int(segundos / 86400), 'd{0}a'.format(chr(0x00ED)),
                                            'd{0}as'.format(chr(0x00ED))))
    if segundos < 31536000:
        return 'hace {0} {1}'.format(int(segundos / 2592000),
                                    _plural(int(segundos / 2592000), 'mes', 'meses'))
    return 'hace {0} {1}'.format(int(segundos / 31536000),
                                _plural(int(segundos / 31536000), 'a{0}o'.format(chr(0x00F1)),
                                        'a{0}os'.format(chr(0x00F1))))


def _lineas_de_ficha(ficha):
    """Lo que se sabe de una fuente, en texto. Vacío si nunca se ha analizado.

    Sin analyze: **no se escribe nada**, ni un "sin analizar" en cada fila. La lista de servidores
    ya se lee bien, y llenarla de "sin analizar" es ruido que hide una fila que sí tiene datos.

    **La lánea de cuando va la primera** (6.4), y en gris, porque es la que decide si el resto se
    lee: un «Queda hueco» de hace dos meses no es un dato, es un recuerdo. Primera y no ultima
    porque al final ya se ha leido todo lo de arriba como si fuera de ahora.

    """
    if not ficha:
        return []
    salida = []
    if ficha.get('cuando'):
        salida.append('[COLOR gray]({0})[/COLOR]'.format(
            _antiguedad(int(time.time()) - int(ficha['cuando']))))
    if ficha.get('resumen'):
        salida.append('[COLOR {0}]{1}[/COLOR]'.format(_color_de(ficha['resumen']),
                                                       ficha['resumen']))
    cats = ficha.get('n_cats') or {}
    if any(cats.values()):
        salida.append('Categorías: {0} de TV, {1} de cine, {2} de series'.format(
            cats.get('live', 0), cats.get('vod', 0), cats.get('series', 0)))
    caducidad = ficha.get('caduca') or 0
    if caducidad:
        salida.append('Caduca: {0}'.format(_fecha_de(caducidad)))
    hueco = ficha.get('hueco')
    c_act = ficha.get('conex_act')
    c_max = ficha.get('conex_max')
    c_txt = '{0}/{1} conex'.format(c_act, c_max) if (c_max and c_act is not None) else ('{0} conex máx'.format(c_max) if c_max else '')
    if hueco is True:
        salida.append('[COLOR lime]Queda hueco{0}[/COLOR]'.format(' ({0})'.format(c_txt) if c_txt else ''))
    elif hueco is False:
        salida.append('[COLOR orange]Sin hueco{0}[/COLOR]'.format(': {0} ocupadas'.format(c_txt) if c_txt else ': todas las conexiones ocupadas'))
    elif c_txt:
        salida.append('[COLOR gray]Conexiones: {0}[/COLOR]'.format(c_txt))
    if ficha.get('langs'):
        salida.append('Idiomas: {0}'.format(', '.join(ficha['langs'])))
    return salida


def _fecha_de(caducidad):
    """La caducidad en texto, en **hora local**, o un aviso si no se puede leer.

    Local y no UTC a propósito: `exp_date` es un instante UTC, y lo que interesa es "me caduca el
    día 3", no "me caduca a las 23:00 del día 2 en el huso de otra persona".

    Un `0` es que el panel no lo dice, y eso no se pinta como fecha: quien llama ya lo ha
    comprobado, y una fecha de 1970 sería una mentira visible.
    """
    import datetime
    try:
        momento = datetime.datetime.fromtimestamp(int(caducidad))
    except (TypeError, ValueError, OverflowError, OSError):
        return 'una fecha que no se entiende'
    return momento.strftime('%d/%m/%Y')


#: Los códigos de idioma de una categoría, en mayúsculas y como palabras sueltas. De tres
#: letras porque son los que pone un panel Xtream en el nombre de la categoría; añadir los de dos
#: (`EU`, `AR`) hace que casi todo case con algo y el filtro deja de servir.
#:
#: Y las variantes largas están porque los paneles escriben esas: `LATINO` y `LATAM` son lo
#: más habitual en una categoría de América, y si solo se busca `LAT` no las ve nadie. Se
#: comparan como palabras enteras, así que `LATINO` casa con `LATINO` y no con `LAT` ni con `PES`.
_CODIGOS_IDIOMA = ('ESP', 'SPA', 'LATINO', 'LATAM', 'LAT', 'ES', 'EN', 'ENG', 'PT', 'POR',
                  'BRA', 'FR', 'FRA', 'DE', 'DEU', 'GER', 'IT', 'ITA', 'NL', 'AR', 'RU',
                  'TR', 'PL', 'RO', 'GR', 'EL', 'SV', 'DA', 'NO', 'FI', 'CS', 'HU', 'UK')


def _langs_de(cats):
    """Los códigos de idioma que salen de los **nombres** de las categorías.

    Es lo único de donde se puede sacar: `player_api.php` no manda el idioma de un canal, sino el
    nombre de la categoría, y los paneles lo ponen ahí (`ES`, `Esp`, `LATINO`).

    Se buscan como **palabras sueltas** y en mayúsculas, no como subcadena: `"Latino"` no lleva
    `ES` pero `"PES"` sí lleva `ES`, y `LatAm` es `LatAm` y no `Latino`. Con seis como tope,
    porque es un filtro y no un informe.
    """
    import re
    salida = []
    for c in (cats or []):
        nombre = c.get('n') if isinstance(c, dict) else str(c or '')
        trozos = set(re.sub(r'[^A-Z0-9]+', ' ', str(nombre or '').upper()).split())
        for codigo in _CODIGOS_IDIOMA:
            if codigo in trozos and codigo not in salida:
                salida.append(codigo)
    return salida[:6]


def _se_puede_analizar():
    """False si se está viendo algo y no se quiere seguir. True si no hay nada viendo.

    El análisis abre doce conexiones y **puede cortar la reproducción**. Preguntar antes es lo
    mínimo para no romperle una película sin avisar.
    """
    try:
        import xbmc
        p = xbmc.Player()
        viendo = bool(p.isPlayingVideo() or p.isPlaying())
    except Exception:
        return True
    if not viendo:
        return True
    return bool(xbmcgui.Dialog().yesno(
        _NOMBRE,
        'Estás reproduciendo una emisión.\nEl análisis abre varias conexiones a la vez y puede cortar lo '
        'que se escucha o ve.\n¿Seguir igualmente?'))


def _analizan_en_paralelo(fuentes):
    """{fid: ficha} de todas las fuentes, con doce hilos a la vez. **Nunca lanza.**

    Los hilos son `daemon` a propósito: si Kodi cierra el addon a mitad, no se quedan colgados
    ocupando el proceso. Y el plazo se comprueba **en el bucle de progreso**, no con un
    `join(timeout)`: `join` con plazo deja al hilo escribiendo cuando se devuelve, y aquí quien
    escribe es el proceso principal.

    Lo que hay **después** del bucle es otra cosa y no es el plazo: es una **espera con tope** para
    que ningún hilo siga dentro cuando se vuelve. Ese tope es **uno para todos los `join`**, no
    uno por hilo (5.7), y lo que se devuelve es **una copia** hecha bajo el cerrojo, no el dict
    que los hilos siguen tocando. Las dos cosas están explicadas donde están, que es donde se
    nota el porqué.

    El progreso pone «cancelar para usar lo que haya» en vez de un «cancelando...» que no acaba
    nunca: lo que hay **es** el resultado, y decirlo es lo que hace que cancelar tenga sentido.
    """
    import threading
    import time

    try:
        import queue as cola_modulo
    except ImportError:                               # pragma: no cover
        import Queue as cola_modulo

    trabajo = cola_modulo.Queue()
    for f in fuentes:
        trabajo.put(f['id'])
    por_id = {f['id']: f for f in fuentes}

    fichas = {}
    terminados = []
    cerrojo = threading.Lock()

    def _obrero():
        while True:
            try:
                fid = trabajo.get_nowait()
            except cola_modulo.Empty:
                return
            # El `try` es por fuente, no por hilo: una que revienta se queda sin ficha y las
            # demás siguen. Al revés, una excepción sin capturar tumba el hilo y el análisis se
            # queda cojeando sin avisar.
            ficha = None
            try:
                ficha = _escanea_uno(por_id[fid])
            except Exception as e:
                _log('analizando {0}: {1}'.format(fid, e))
            with cerrojo:
                if isinstance(ficha, dict):
                    fichas[fid] = ficha
                # Contar como terminado también en caso de fallo para no agotar el plazo innecesariamente.
                terminados.append(fid)

    cuantos = min(HILOS_ANALISIS, max(len(fuentes), 1))
    hilos = [threading.Thread(target=_obrero) for _ in range(cuantos)]
    for h in hilos:
        h.daemon = True
        h.start()

    dp = _segundo_plano('Analizando servidores')
    limite = time.time() + PLAZO_ANALISIS
    try:
        while True:
            with cerrojo:
                hechos = len(fichas)
                pendientes = len(terminados)
            if dp is not None:
                dp.update(
                    int(hechos * 100 // max(len(fuentes), 1)),
                    '{0} de {1} · cancelar para usar lo que haya'.format(hechos, len(fuentes)))
            # La condición es `pendientes`, no `hechos`: una fuente que falla no deja ficha,
            # y esperar a `hechos` sería esperar a una que no va a llegar nunca.
            if pendientes >= len(fuentes):
                break
            if time.time() >= limite:
                _log('el análisis ha llegado al plazo de {0}s con {1} de {2}'.format(
                    PLAZO_ANALISIS, hechos, len(fuentes)))
                break
            try:
                if dp is not None and dp.iscanceled():
                    break
            except Exception:                         # pragma: no cover
                pass
            time.sleep(0.2)
    finally:
        _cierra(dp)

# Se espera a los hilos, con un tope. Sin esto se volvería con hilos escribiendo en `fichas`
    # mientras el hilo principal ya está guardando.

    # Plazo global de 1 s para todos los hilos, evitando esperas acumuladas al cancelar.
    fin = time.time() + 1.0
    for h in hilos:
        h.join(timeout=max(0.0, fin - time.time()))

    # Copia protegida por cerrojo para aislar el dict de posibles hilos aún activos.
    with cerrojo:
        return dict(fichas)


#: A partir de cuántos resultados el diálogo usa textviewer en vez de ok por espacio.
MAX_OK_RESULTADOS = 4


def _pintan_resultados(titulo, resultados):
    """Los resultados, en un diálogo con todos a la vista.

    Un `select` obliga a ir uno por uno; con dos o tres servidores, un `ok` con todo es más
    útil y no hay que recordar cuál había que marcar.

    El `titulo` va en el `heading` del diálogo (`_aviso` lo pone), así que **no** se repite
    como primera línea del cuerpo: sale dos veces, arriba del todo, y parece un fallo.

    A partir de `MAX_OK_RESULTADOS`, `textviewer`: `Dialog().ok()` no hace scroll y recorta la
    lista, y `textviewer` además deja seleccionar y copiar el texto.
    """
    lineas = []
    for f, texto in resultados:
        lineas.append('[COLOR {0}]{1}[/COLOR]\n[COLOR gray]{2}[/COLOR]'.format(
            _color_de(texto), f['nombre'], texto))
    cuerpo = '\n'.join(lineas)
    if len(resultados) > MAX_OK_RESULTADOS:
        xbmcgui.Dialog().textviewer(titulo, cuerpo)
        return
    _aviso(cuerpo, titulo)


#: Los tres colores, y lo que significa cada uno en pantalla. Con esto se decide si un servidor
#: va o no, así que no son estética: "naranja" quiere decir "no he podido saber", y "rojo" quiere decir "sé que está
#: mal". Confundirlos hace que un servidor apagado parezca uno con la contraseña mala.
_COLOR_OK = 'lime'
_COLOR_NO_SE_SABE = 'orange'
_COLOR_MAL = 'red'


def _color_de(texto):
    """El color de una línea de resultado, según lo que empieza por decir.

    Tres casos, no dos, y el tercero es el que se colaba: una lista que se descarga pero que
    no se entiende **no** es un problema de red, así que va en rojo, no en naranja. Y
    "No se ha podido contactar" **sí** es de red, y por lo que se ofrece volver a intentarlo
    después, así que va en naranja y no en rojo: rojo suena a cuenta mala.

    El botón de reintentar existe y es el **«Comprobar» del menú contextual** de la fila del
    servidor, no un botón de la pantalla de resultados (4.6 decía que no existía ninguno de los
    dos; el que hay está en la segunda parte). Se deja dicho porque esta función pinta las
    líneas de resultado y quien lee esto busca el botón ahí, y no está.
    """
    if texto.startswith('OK'):
        return _COLOR_OK
    if texto.startswith('No se ha podido contactar') or texto.startswith('No se ha podido descargar'):
        return _COLOR_NO_SE_SABE
    return _COLOR_MAL
