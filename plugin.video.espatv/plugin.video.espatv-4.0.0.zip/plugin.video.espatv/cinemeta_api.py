# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Búsqueda y metadatos de Cinemeta (Stremio): IDs de IMDb y episodios con su numeración.

Sin dependencias de Kodi. El módulo `cinemeta.py` del addon es otra cosa (el Top).
"""
import datetime
import json
import socket
import urllib.error
import urllib.parse
import urllib.request

BASE_URL = "https://v3-cinemeta.strem.io"
_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36"
_TIMEOUT = 10


class CinemetaError(Exception):
    """Cinemeta no responde o devuelve algo ilegible."""


def _get(path):
    request = urllib.request.Request(
        BASE_URL + path, headers={"User-Agent": _USER_AGENT, "Accept": "application/json"}
    )
    # /meta responde con un 307 a cinemeta-live; urllib lo sigue solo.
    try:
        with urllib.request.urlopen(request, timeout=_TIMEOUT) as response:
            body = response.read().decode("utf-8", "replace")
        data = json.loads(body or "{}")
    except (urllib.error.URLError, socket.timeout, OSError) as e:
        raise CinemetaError(str(e))
    except ValueError:
        raise CinemetaError("respuesta no válida")
    if not isinstance(data, dict):
        raise CinemetaError("respuesta no válida")
    return data


def _imdb_of(meta):
    imdb_id = str(meta.get("imdb_id") or meta.get("id") or "")
    return imdb_id if imdb_id.startswith("tt") else ""


def search(kind, query, limit=20):
    """kind 'movie' o 'series'. Falla con CinemetaError (con algunos textos Cinemeta da 504)."""
    query = str(query or "").strip()
    if not query:
        return []
    data = _get(f"/catalog/{kind}/top/search={urllib.parse.quote(query, safe='')}.json")
    out = []
    for meta in data.get("metas") or []:
        imdb_id = _imdb_of(meta)
        if imdb_id:
            out.append({
                "imdb_id": imdb_id,
                "title": meta.get("name") or "",
                "year": meta.get("releaseInfo") or "",
                "poster": meta.get("poster") or "",
            })
    return out[:limit]


def _meta_raw(kind, imdb_id):
    data = _get(f"/meta/{kind}/{imdb_id}.json")
    meta = data.get("meta")
    return meta if isinstance(meta, dict) and meta else None


def _summary(meta):
    return {
        "imdb_id": _imdb_of(meta),
        "title": meta.get("name") or "",
        "year": str(meta.get("releaseInfo") or meta.get("year") or ""),
        "poster": meta.get("poster") or "",
        "description": meta.get("description") or "",
        "moviedb_id": meta.get("moviedb_id"),
    }


def meta(kind, imdb_id):
    """Ficha del título o None si Cinemeta no lo conoce con ese tipo."""
    raw = _meta_raw(kind, imdb_id)
    return _summary(raw) if raw else None


def seasons(imdb_id, today=None):
    """[(temporada, [episodio, ...])] con los especiales (temporada 0) al final.

    Cada episodio: {episode, title, released, aired, overview, thumbnail}. ``aired`` es falso
    si no tiene fecha o es futura. Devuelve [] si Cinemeta no conoce la serie.
    """
    raw = _meta_raw("series", imdb_id)
    if not raw:
        return []
    today = today or datetime.date.today().isoformat()
    by_season = {}
    for video in raw.get("videos") or []:
        try:
            season, episode = int(video["season"]), int(video["episode"])
        except (KeyError, TypeError, ValueError):
            continue
        released = str(video.get("released") or "")
        by_season.setdefault(season, []).append({
            "episode": episode,
            "title": video.get("title") or video.get("name") or "",
            "released": released[:10],
            "aired": bool(released) and released[:10] <= today,
            "overview": video.get("overview") or "",
            "thumbnail": video.get("thumbnail") or "",
        })
    order = sorted(by_season, key=lambda s: (s == 0, s))
    return [(s, sorted(by_season[s], key=lambda e: e["episode"])) for s in order]
