# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Dónde viven los servidores y listas de HyperXStream, y su caché.

Un servidor Xtream es una cosa distinta de una lista de canales: lleva credenciales, una
ficha de análisis y una cuenta atrás. Por eso NO va en `custom_iptv_lists.json`, que es de
las listas del usuario y cuya lista blanca de `kind` (iptv_store.KINDS) la comparten la copia
de seguridad y el PVR. Aquí hay un fichero propio, `mis_fuentes.json`, y una caché propia.

Reglas del módulo:
- **Sin tope de fuentes.** El tope blando, si lo hay, es de la
  importación de un archivo, y es de `fuentes_remoto`, no de aquí.
- **`conexiones` puede ser None.** Un panel que no dice cuántas conexiones tiene no es lo
  mismo que un panel con cinco: el filtro de "hueco libre" trata lo desconocido como
  **no bloqueante**, porque es lo que evita que un análisis le ruine lo que está viendo.
- **Nada de red y nada de UI**, para que se pueda probar sin mockear nada.
"""

import hashlib
import json
import os
import re
import shutil
import time

import xbmc
import xbmcaddon
import xbmcvfs

import iptv_store

_LOG = '[EspaTV/FUENTES]'

ESTADO = 'mis_fuentes.json'
USO = 'fuentes_uso.json'
FAVORITOS = 'fuentes_favoritos.json'
#: Tope del registro de borrados (huellas de fuentes eliminadas manualmente).
_BORRADAS_MAX = 200
#: `{sección: fid}` del último servidor abierto, para entrar directo.
#: No es `uso_recientes()`, que es lo último reproducido.
ULTIMO = 'fuentes_ultimo.json'
#: Un id son 12 hex, igual que en `iptv_store._ID_RE`, que existe
#: justo para esto. No es estetico: el id se concatena en `_cache_dir()`, y con un `id` de
#: `..` esa ruta es el perfil entero de Kodi, donde `limpiar_cache()` hace `os.walk` y
#: borra `settings.xml`, `favorites.json` y todo lo demas.
_ID_RE = re.compile(r'[0-9a-f]{12}')

#: Una clave de cache es un nombre de fichero. Sin sanear,
#: cache_escribir(fid, '../../x') escribe fuera de su carpeta.
#:
#: Y tiene un tope de longitud, que son 48 caracteres porque es lo que produce
#: fuentes_xtream._clave_cache(): 24 legibles + un guion + 12 de hash, con margen.
#:
#: Antes el tope eran 40 y el generador llegaba a 120. Con una clave de mas de 40 no se
#: guardaba nada y se leia None siempre, porque cache_escribir se traga el
#: ValueError a proposito (una cache no debe tirar la pantalla). El efecto era el peor
#: posible: la cache no fallaba, parecia que no funcionara, y el aviso que si habia iba al
#: log con un texto de «clave no valida».
#:
#: Y el limite tiene que estar escrito aqui y junto al generador. Si uno de los dos
#: cambia y el otro no, el fallo vuelve a ser silencioso, que es de donde vino.
_CLAVE_RE = re.compile(r'[A-Za-z0-9_-]{1,48}')

CACHE_DIR = 'fuentes_cache'
LOCK = ESTADO + '.lock'
LOCK_FAV = FAVORITOS + '.lock'

#: Cuánto se guarda un fichero de caché ya caducado antes de borrarlo.
#:
#: Pasado el TTL, `cache_leer()` ya no lo lee, así que esto solo decide cuánto ocupa en disco.
#: Tiene que quedar por encima del TTL máximo: si fuera menor, se borraría caché todavía
#: válida (lo comprueba un test). Ocho días: uno más que `fuentes_xtream.TTL_MAX`. Con
#: «Hasta que lo refresque yo» nada caduca y `limpiar_huerfanos()` no borra por edad.
#:
#: No se llama sola: solo la usa «Borrar caché», que antes llama a `limpiar_cache()`.
VIEJO_S = 8 * 24 * 3600
#: Cuántas entradas de "lo más usado" se guardan como mucho.
USO_MAX = 2000


class StoreIlegible(Exception):
    """El estado existe pero no se ha podido LEER, por un motivo que no es su contenido.

    Es distinto de "esta vacio" y de "esta roto". Se lanza solo por un `OSError`, nunca por
    JSON invalido, y sirve para que `guardar()` no escriba nada encima de un fichero que
    seguro que esta bien: en Windows, un `OSError` al leer es lo normal cuando otro proceso
    esta escribiendo.
    """


#: Lo que puede salir al tomar el cerrojo de un fichero y leerlo antes de escribir. En los tres
#: casos se renuncia a guardar: perder un favorito o una suma es mejor que pisar el fichero.
_NO_SE_PUEDE_ESCRIBIR = (StoreIlegible, iptv_store.LockBusy, iptv_store.StoreError)


def _log(texto, nivel=xbmc.LOGDEBUG):
    xbmc.log('{0} {1}'.format(_LOG, texto), nivel)


def perfil():
    return xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo('profile'))


def _ruta(nombre):
    return os.path.join(perfil(), nombre)


def _store():
    """El almacén de listas, solo para su cerrojo entre procesos, que es público."""
    return iptv_store.Store(perfil())


# --- estado ---

def _vacio():
    return {'rev': 0, 'fuentes': [], 'borradas': []}


def _normaliza(fuente):
    """Una fuente con todos sus campos y del tipo que toca, aunque venga a medias."""
    if not isinstance(fuente, dict):
        return None
    fid = str(fuente.get('id') or '').lower()
    if not _ID_RE.fullmatch(fid):
        # Un id que no es un id. No se "corrige" ni se descarta el resto de la fuente: se
        # descarta la fuente, porque un id que apunta fuera de nuestra carpeta no es una
        # fuente, es un camino.
        return None
    tipo = fuente.get('tipo')
    if tipo not in ('xtream', 'm3u'):
        tipo = 'xtream' if fuente.get('servidor') else 'm3u'
    cuenta = fuente.get('cuenta') if isinstance(fuente.get('cuenta'), dict) else {}
    try:
        orden = int(fuente.get('orden') or 0)
    except (TypeError, ValueError):
        orden = 0
    # conexiones a propósito sin valor por defecto: None significa "el panel no lo dice"
    conexiones = cuenta.get('conexiones')
    if conexiones is not None:
        try:
            conexiones = int(conexiones)
        except (TypeError, ValueError):
            conexiones = None
    caducidad = cuenta.get('caduca')
    if caducidad is not None:
        try:
            caducidad = int(caducidad)
        except (TypeError, ValueError):
            caducidad = 0
    return {
        'id': fid,
        'nombre': (str(fuente.get('nombre') or '').strip() or fid),
        'tipo': tipo,
        'servidor': str(fuente.get('servidor') or ''),
        'usuario': str(fuente.get('usuario') or ''),
        'clave': str(fuente.get('clave') or ''),
        'url': str(fuente.get('url') or ''),
        # Cadena vacia, no 'm3u8'. `_extension_elegida('')` devuelve '' y eso
        # significa "no has elegido", que es lo que hace que decida la cuenta
        # (`fuentes_xtream.url_de()`). Con 'm3u8' escrito aqui, una fuente
        # recien anadida -o importada de un texto, que no lleva el campo- quedaba
        # forzada a m3u8 para siempre y la cuenta no se llegaba a consultar.
        'formato': str(fuente.get('formato') or ''),
        'epg': str(fuente.get('epg') or ''),
        'inseguro': bool(fuente.get('inseguro')),
        'cuenta': {
            'estado': str(cuenta.get('estado') or ''),
            'caduca': caducidad or 0,
            'conexiones': conexiones,
        },
        'analisis': fuente.get('analisis') if isinstance(fuente.get('analisis'), dict) else None,
        'orden': orden,
    }


def _lee():
    """El estado de disco, o el vacío. Un JSON ilegible se aparta, no se machaca."""
    ruta = _ruta(ESTADO)
    try:
        with open(ruta, 'r', encoding='utf-8') as f:
            datos = json.load(f)
    except FileNotFoundError:
        return _vacio()
    except ValueError as e:
        # Solo esto es corrupcion: se aparta para que quede y se empieza de cero.
        _log('estado ilegible ({0}), se aparta'.format(e), xbmc.LOGWARNING)
        try:
            os.replace(ruta, f'{ruta}.corrupt-{time.time_ns()}')
        except OSError as e2:
            # Si no se ha podido apartar, sigue ahí: devolver el vacío haría que el guardado
            # siguiente escribiera encima.
            raise StoreIlegible(str(e2)) from e2
        return _vacio()
    except OSError as e:
        # No es corrupción: en Windows un OSError al leer es normal si otro proceso (o un
        # antivirus) está reemplazando el fichero. Renombrarlo a `.corrupt-` haría que el
        # siguiente guardado escribiera la lista vacía encima. Se propaga para que `guardar()`
        # no escriba nada, como `iptv_store.Store._read()`.
        raise StoreIlegible(str(e)) from e
    if not isinstance(datos, dict):
        return _vacio()
    crudo = datos.get('fuentes')
    fuentes = [_normaliza(x) for x in crudo] if isinstance(crudo, list) else []
    vistos = set()
    sin_repetir = []
    for f in fuentes:
        if f and f['id'] not in vistos:
            vistos.add(f['id'])
            sin_repetir.append(f)
    try:
        rev = int(datos.get('rev') or 0)
    except (TypeError, ValueError):
        rev = 0
    return {'rev': rev, 'fuentes': sin_repetir, 'borradas': _borradas_de(datos)}


def _no_esta_borrada(datos, *huellas):
    """Si una fuente se vuelve a dar de alta, deja de constar en el registro de borradas."""
    if not huellas or not isinstance(datos, dict):
        return
    previas = datos.get('borradas')
    if not previas:
        return
    datos['borradas'] = [h for h in previas if h not in huellas]


def _borradas_de(datos):
    """El registro de borrados del estado, ya limpio. No revienta si está a mano."""
    crudo = datos.get('borradas')
    if not isinstance(crudo, list):
        return []
    return [str(h) for h in crudo if isinstance(h, str) and h][:_BORRADAS_MAX]


def borradas():
    """Las huellas de fuentes eliminadas manualmente para evitar recreación en sincronización."""
    return set(_lee()['borradas'])


def estado():
    return _lee()


def _orden_visual(lista):
    """La unica regla de orden de la seccion.

    Un solo sitio para la regla del puesto: con `(orden, nombre)` en un lado y
    `(orden, nombre.lower())` en otro, dos fuentes de orden 0 como `Zeta` y `alfa` se ordenan
    distinto y `mover()` mueve la equivocada.
    """
    return sorted(range(len(lista)),
                  key=lambda i: (lista[i]['orden'], lista[i]['nombre'].lower(), i))


def fuentes():
    lista = _lee()['fuentes']
    return [lista[i] for i in _orden_visual(lista)]


def fuente(fid):
    for f in _lee()['fuentes']:
        if f['id'] == fid:
            return f
    return None


def huella(tipo, servidor, usuario):
    """Identidad de una fuente para deduplicar, **sin** la clave dentro del hash."""
    base = '|'.join((tipo or '', (servidor or '').lower().rstrip('/'),
                     (usuario or '').lower()))
    return hashlib.sha1(base.encode('utf-8')).hexdigest()[:12]


def guardar(mutador):
    """Aplica mutador(fuentes) sobre lo que hay en disco ahora mismo y lo guarda.

    Es la única vía de escritura: lee y escribe dentro del mismo cerrojo, y sube `rev`.
    mutador recibe la lista y devuelve lo que interese.
    """
def guardar(mutador, con_estado=False):
    """Aplica mutador(fuentes) sobre lo que hay en disco ahora mismo y lo guarda.

    Es la única vía de escritura: lee y escribe dentro del mismo cerrojo, y sube `rev`.
    mutador recibe la lista y devuelve lo que interese.

    `con_estado=True` le pasa además el estado entero, para lo que hay que escribir fuera de
    la lista de fuentes (hoy, el registro de borrados de `borrar()`). Se hace así y no con una
    segunda escritura para que el registro y el borrado caigan **en el mismo cerrojo**: si no,
    un corte entre las dos dejaría la fuente desaparecida sin su huella apuntada, que es
    justo lo que el registro existe para evitar.

    Así como así, o ::

        def muta(lista, datos): ...
    """
    ruta = _ruta(ESTADO)
    try:
        with _store().lock(LOCK):
            try:
                os.makedirs(perfil(), exist_ok=True)
            except OSError as e:
                _log('no se ha podido preparar el perfil: {0}'.format(e), xbmc.LOGERROR)
                return None

            try:
                datos = _lee()
            except StoreIlegible as e:
                # El estado existe y no se ha podido leer por algo ajeno a su contenido: no se
                # escribe nada, o se pisarían los servidores. Igual que `iptv_store`.
                _log('el estado no se ha podido leer, no se escribe nada: {0}'.format(e),
                     xbmc.LOGERROR)
                return None

            if con_estado:
                resultado = mutador(datos['fuentes'], datos)
            else:
                resultado = mutador(datos['fuentes'])
            cuerpo = {'rev': datos['rev'] + 1,
                      'fuentes': [f for f in datos['fuentes'] if f]}
            # El registro de borrados solo se escribe cuando hay algo: un fichero sin él es
            # igual de válido, y así el estado de quien nunca borró nada no cambia de forma.
            if datos.get('borradas'):
                cuerpo['borradas'] = [h for h in datos['borradas']
                                      if isinstance(h, str)][-_BORRADAS_MAX:]
            import core_settings
            # `durable=True`: asegura persistencia en disco de las fuentes y el registro de borrados.
            if not core_settings.atomic_write_json(ruta, cuerpo, durable=True):
                _log('no se ha podido guardar el estado', xbmc.LOGERROR)
                return None
            return resultado
    except iptv_store.LockBusy:
        _log('otra escritura tiene el cerrojo', xbmc.LOGWARNING)
        return None
    except iptv_store.StoreError as e:
        _log('no se ha podido escribir el estado: {0}'.format(e), xbmc.LOGERROR)
        return None


def anadir(datos):
    """Añade una fuente y devuelve su id, o `''` si no se ha podido.

    `''` significa una de tres cosas, y no se distinguen: que ya había una fuente igual, que
    el id ya existía, o que el guardado falló (cerrojo ocupado, disco lleno, o el estado no
    se pudo leer). El llamante que necesite distinguirlo tiene que mirar `fuentes()`.

    Sin tope de cuántas.
    """
    # El id se genera antes de normalizar, porque _normaliza lo exige.
    datos = dict(datos)
    datos['id'] = datos.get('id') or iptv_store.new_id()
    fuente_nueva = _normaliza(datos)
    if not fuente_nueva:
        return ''
    huella_nueva = huella(fuente_nueva['tipo'],
                          fuente_nueva['servidor'] or fuente_nueva['url'],
                          fuente_nueva['usuario'])

    def muta(lista, datos):
        for f in lista:
            if f['id'] == fuente_nueva['id']:
                return ''
            if huella(f['tipo'], f['servidor'] or f['url'], f['usuario']) == huella_nueva:
                return ''
        fuente_nueva['orden'] = max([f['orden'] for f in lista] or [-1]) + 1
        lista.append(fuente_nueva)
        _no_esta_borrada(datos, huella_nueva)
        return fuente_nueva['id']

    return guardar(muta, con_estado=True) or ''


def anadir_varios(lista_de_datos):
    """Añade muchas fuentes de una vez y devuelve las fuentes añadidas.

    **Existe por una medida, no por gusto:** dar de alta N fuentes con `anadir()` una por uno
    hacía N guardados del estado, cada uno leyendo y escribiendo el JSON entero con el cerrojo
    puesto. Medido en el addon (400 fuentes, disco local): **12,2 s de una en una frente a
    0,01 s en un solo guardado**, 2171 veces, y crece con el cuadrado porque el fichero se
    reescribe N veces siendo cada vez más grande. Con una configuración remota grande (una
    importación, o una suscripción que trae 300 servidores) la pantalla se quedaba colgada
    dentro de `Container.Refresh`.

    Las mismas reglas que `anadir()`, una sola vez y para todas:
    - lo que no es un dict, o no normaliza, se descarta;
    - la misma cuenta (misma huella) ya en la lista **o dentro del propio lote** se añade una
      vez;
    - el `orden` se reparte en el orden de llegada.

    **Y la distinción que importa al llamante**: devuelve la lista de lo añadido, que **puede
    estar vacía** cuando todo lo que venía ya estaba (`[]` = «se ha guardado y no había nada
    que añadir», que es el caso normal de reimportar tu propia copia), o **`None` cuando el
    guardado ha fallado de verdad** (cerrojo ocupado, disco lleno, estado ilegible). Confundir
    las dos cosas hacía que reimportar una copia propia dijera «no se ha podido guardar».
    """
    if not lista_de_datos:
        return []
    preparadas = []
    for datos in lista_de_datos:
        if not isinstance(datos, dict):
            continue
        datos = dict(datos)
        datos['id'] = datos.get('id') or iptv_store.new_id()
        fuente_nueva = _normaliza(datos)
        if fuente_nueva:
            preparadas.append(fuente_nueva)
    if not preparadas:
        return []

    def muta(lista, datos):
        huellas = set(huella(f['tipo'], f['servidor'] or f['url'], f['usuario'])
                      for f in lista)
        ids = set(f['id'] for f in lista)
        siguientes = max([f['orden'] for f in lista] or [-1]) + 1
        anadidas = []
        puestas = set()
        for fuente_nueva in preparadas:
            if fuente_nueva['id'] in ids:
                continue
            h = huella(fuente_nueva['tipo'], fuente_nueva['servidor'] or fuente_nueva['url'],
                       fuente_nueva['usuario'])
            if h in huellas:            # ya estaba, o la trae el propio lote dos veces
                continue
            huellas.add(h)
            ids.add(fuente_nueva['id'])
            fuente_nueva['orden'] = siguientes
            siguientes += 1
            lista.append(fuente_nueva)
            anadidas.append(fuente_nueva)
            puestas.add(h)
        _no_esta_borrada(datos, *puestas)
        return anadidas

    # `None` si guardar() falla; lista (incluso vacía si ya existían) si tiene éxito.
    return guardar(muta, con_estado=True)


def editar(fid, **campos):
    """Cambia lo que se le pase y **solo** eso.

    `cuenta` se mezcla campo a campo y no se sustituye entero: `editar(fid, cuenta={'estado':
    'activo'})` no puede borrar `conexiones` ni `caduca`. Con un `dict(f, **campos)` normal,
    `_normaliza` reconstruye `cuenta` desde cero y los otros dos campos se van a blanco. Y
    `conexiones` volviendo a `None` significa "el panel no lo dice", o sea **no bloqueante**:
    el filtro de hueco libre dejaría de proteger justo después de comprobar el panel.

    Modificar la `url` de una lista M3U invalida su caché local para no servir
    los canales de la dirección anterior durante el TTL restante.
    """
    def muta(lista):
        for i, f in enumerate(lista):
            if f['id'] != fid:
                continue
            nuevo = dict(f, **campos)
            if 'cuenta' in campos and isinstance(campos['cuenta'], dict):
                nuevo['cuenta'] = dict(f.get('cuenta') or {}, **campos['cuenta'])
            # Si ha cambiado la URL de una lista M3U, su caché ya no vale: su clave es `'m3u'` a
            # secas (`_huella_de()` da `''`), así que no cambia nunca.
            #
            # Se borra después de guardar: `muta` corre dentro del cerrojo de escritura y borrar
            # antes dejaría los datos cambiados con la caché apuntando a la lista nueva.
            if (nuevo.get('tipo') == 'm3u' and 'url' in campos
                    and f.get('url') != nuevo.get('url')):
                cambiada.append(fid)
            lista[i] = _normaliza(nuevo)
            return True
        return False

    cambiada = []
    if not guardar(muta):
        return False
    for fid_vieja in cambiada:
        _borra_cache(fid_vieja)
    return True


def borrar(fid):
    """Borra una fuente y apunta su huella en el registro de borrados para evitar recreación."""
    def muta(lista, datos):
        for i, f in enumerate(lista):
            if f['id'] != fid:
                continue
            h = huella(f['tipo'], f['servidor'] or f['url'], f['usuario'])
            if h:
                previas = _borradas_de(datos)
                if h not in previas:
                    datos['borradas'] = (previas + [h])[-_BORRADAS_MAX:]
            del lista[i]
            _borra_cache(fid)
            return True
        return False

    return bool(guardar(muta, con_estado=True))


def _caza_de_la_fuente(fid):
    """`(favoritos, claves_de_uso)` de una fuente. **No escribe nada.**

    Se parte en tres sitios si no: la confirmación necesita las cifras antes de borrar, y el
    borrado necesita la lista. Con el predicado en un sitio no pueden discrepar.
    """
    fid = str(fid or '')
    if not fid:
        return ([], [])
    favs = [f for f in _lee_favoritos_crudo()
            if isinstance(f, dict) and str(f.get('fid') or '') == fid]
    uso = [c for c in _lee_uso() if partir_uso(c)[0] == fid]
    return (favs, uso)


def cuenta_de_la_fuente(fid):
    """`(favoritos, historial)` de una fuente, para poder decirlo antes de borrarla."""
    favs, uso = _caza_de_la_fuente(fid)
    return (len(favs), len(uso))


def olvidar_fuente(fid):
    """Quita los favoritos y el historial de una fuente. Devuelve `(favoritos, uso)` borrados.

    Limpia los favoritos e historial asociados a una fuente eliminada para evitar
    entradas huérfanas en la interfaz.

    Los dos ficheros se procesan por separado y cada uno con su propio cerrojo.
    """
    favs, uso = _caza_de_la_fuente(fid)
    quitados = [0, 0]

    if favs:
        try:
            with _store().lock(LOCK_FAV):
                if _quita_favoritos_de(_caza_de_la_fuente(fid)[0]):
                    quitados[0] = len(favs)
        except _NO_SE_PUEDE_ESCRIBIR as e:
            _log(f'no se han quitado los favoritos de la fuente borrada: {e!r}', xbmc.LOGWARNING)
    if uso:
        try:
            datos = _lee_uso(estricto=True)
        except StoreIlegible as e:
            _log(f'no se ha quitado el historial de la fuente borrada: {e!r}', xbmc.LOGWARNING)
        else:
            for clave in uso:
                datos.pop(clave, None)
            if _escribe_uso(datos):
                quitados[1] = len(uso)

    return tuple(quitados)


def _quita_favoritos_de(favs):
    """Borra del fichero de favoritos las entradas dadas. Con el cerrojo ya tomado."""
    if not favs:
        return False
    import core_settings
    claves = {_clave_fav(f.get('fid'), f.get('sid'), f.get('seccion')) for f in favs}
    actual = _lee_favoritos_crudo(estricto=True)
    lista = [f for f in actual
             if not (isinstance(f, dict) and _clave_fav(f.get('fid'), f.get('sid'),
                                                        f.get('seccion')) in claves)]
    if len(lista) == len(actual):
        return False
    if not core_settings.atomic_write_json(_ruta(FAVORITOS), lista):
        _log('no se han podido quitar los favoritos de una fuente borrada', xbmc.LOGWARNING)
        return False
    return True


def mover(fid, delta):
    """Sube o baja una fuente **una posicion**, y devuelve si ha cambiado algo.

    Se reordena la lista y se renumera en vez de intercambiar los valores de `orden`: con dos
    fuentes empatadas (`_normaliza` pone 0) el intercambio no haría nada y devolvería `True`.
    """
    def muta(lista):
        orden = _orden_visual(lista)
        puesto = next((p for p, i in enumerate(orden) if lista[i]['id'] == fid), None)
        if puesto is None:
            return False
        nuevo = min(max(puesto + delta, 0), len(orden) - 1)
        if nuevo == puesto:
            return False
        reordenada = [lista[i] for i in orden]
        reordenada.insert(nuevo, reordenada.pop(puesto))
        # Se vuelve a numerar: `orden` pasa a ser la posicion, sin empates posibles.
        for posicion, fuente in enumerate(reordenada):
            fuente['orden'] = posicion
        lista[:] = reordenada
        return True

    return bool(guardar(muta))


# --- análisis ---

def analisis(fid):
    f = fuente(fid)
    return dict(f['analisis']) if f and isinstance(f.get('analisis'), dict) else {}


def analisis_guardar(fid, datos):
    """Guarda la ficha del analisis, con **la hora** (6.4).

    `cuando` va aqui y no en `analizar()` a proposito: el guardado es el unico punto por el que
    pasan todas las fichas, y ponerlo en el que llama significaria que un guardado desde otro
    sitio (o desde `analizar(solo=...)`) se quedaria sin fecha. Un campo que a veces esta y a
    veces no es peor que un campo que no esta.

    Guarda la marca temporal ('cuando') junto al resto de datos del análisis para
    poder determinar la frescura del estado de la fuente en pantalla.
    """
    ficha = dict(datos)
    ficha['cuando'] = int(time.time())
    return editar(fid, analisis=ficha)


# --- caché de listas ---

def _cache_dir(fid):
    return os.path.join(perfil(), CACHE_DIR, fid)


def _cache_path(fid, clave):
    """La clave es un **nombre de fichero**: se sanea, no se concatena.

    Sin sanear, `cache_escribir(fid, '../../settings')` sale de su carpeta y machaca otro
    fichero del perfil. Las claves que usa el modulo (`cats_live`, `vod_1`...) son las dos
    cosas: solo letras, digitos y guion.
    """
    if not _CLAVE_RE.fullmatch(str(clave)):
        raise ValueError('clave de cache no valida: {0!r}'.format(clave))
    return os.path.join(_cache_dir(fid), '{0}.json'.format(clave))


def cache_leer(fid, clave, ttl_s):
    """Los datos cacheados, o None si no están o caducaron."""
    if not ttl_s:
        return None
    try:
        with open(_cache_path(fid, clave), 'r', encoding='utf-8') as f:
            envoltura = json.load(f)
    except (OSError, ValueError):
        return None
    if not isinstance(envoltura, dict):
        return None
    try:
        edad = time.time() - int(envoltura.get('ts') or 0)
    except (TypeError, ValueError):
        return None
    # Una edad negativa se considera caducada: protege contra desajustes de reloj,
    # timestamps del futuro o cajas sin RTC que arranquen en 1970.
    if edad < 0 or edad > ttl_s:
        return None
    return envoltura.get('datos')


def cache_escribir(fid, clave, datos):
    """Guarda los datos cacheados. Devuelve si se ha podido, y **nunca lanza**.

    Se traga tambien el `ValueError` de una clave no valida, porque el contrato de este
    modulo es "devuelve un booleano": una llamada de la pantalla que reventase porque alguien
    pidió una clave rara la dejaría a medias, y la caché es justo lo que puede fallar sin
    consecuencias.
    """
    try:
        destino = _cache_path(fid, clave)
    except ValueError as e:
        _log(str(e), xbmc.LOGWARNING)
        return False
    carpeta = _cache_dir(fid)
    try:
        os.makedirs(carpeta, exist_ok=True)
    except OSError as e:
        _log('no se ha podido crear la caché: {0}'.format(e), xbmc.LOGWARNING)
        return False
    import core_settings
    return core_settings.atomic_write_json(destino,
                                           {'ts': int(time.time()), 'datos': datos})


def _borra_cache(fid):
    carpeta = _cache_dir(fid)
    for nombre in os.listdir(carpeta) if os.path.isdir(carpeta) else ():
        try:
            os.remove(os.path.join(carpeta, nombre))
        except OSError:
            pass
    try:
        os.rmdir(carpeta)
    except OSError:
        pass


def limpiar_cache(fid=None):
    """Borra la caché de una fuente o de todas. Devuelve los bytes liberados.

    Un `fid` que **no tiene forma de id** (vacío, o con caracteres raros) **no borra nada** y
    devuelve cero. No es un detalle de estilo: un `fid` vacío es lo que llega de un favorito o de
    un widget que apunta a una fuente borrada, y «borra la caché de todo el perfil» no es lo que
    significa eso.

    El test que cubría esto **afirmaba el bug**: se llamaba
    `test_limpiar_cache_con_id_vacio_no_borra_todas` y acababa en `assertIsNone(...)`, con el texto
    del fallo diciendo «un id vacío no puede borrar la cache de todo». Verde, y afirmando lo
    contrario de lo que hacía el código.
    """
    base = os.path.join(perfil(), CACHE_DIR)
    if fid is None:
        carpetas = [os.path.join(base, n) for n in _hijos(base)]
    elif _es_id(fid):
        carpetas = [_cache_dir(fid)]
    else:
        return 0
    liberados = 0
    for carpeta in carpetas:
        for raiz, _dirs, ficheros in os.walk(carpeta) if os.path.isdir(carpeta) else ():
            for nombre in ficheros:
                ruta = os.path.join(raiz, nombre)
                try:
                    liberados += os.path.getsize(ruta)
                    os.remove(ruta)
                except OSError:
                    pass
    return liberados


def limpiar_huerfanos(min_age=3600):
    """Carpetas de caché de fuentes que ya no están, y ficheros muy viejos. Devuelve cuántos."""
    import fuentes_xtream
    base = os.path.join(perfil(), CACHE_DIR)
    vivos = {f['id'] for f in fuentes()}
    ahora = time.time()
    plazo = max(VIEJO_S, fuentes_xtream.ttl_de())
    borrados = 0
    for nombre in _hijos(base):
        ruta = os.path.join(base, nombre)
        if nombre not in vivos:
            try:
                if ahora - os.path.getmtime(ruta) < min_age:
                    continue
            except OSError:
                pass
            if _borrar_arbol(ruta):
                borrados += 1
            continue
        # `os.path.join(ruta, hijo)`, y no `hijo` a pelo.
        #
        # `_hijos()` devuelve nombres, no rutas, y `os.path.getmtime('x.json')` se resuelve
        # contra el directorio de trabajo, no contra la carpeta de la caché. O sea que:
        #
        # - en el caso normal, `getmtime` lanza `OSError`, lo traga el `except` de abajo, y el
        #   fichero no se borra nunca. La limpieza de una fuente que sigue existiendo no
        #   limpiaba nada, y en silencio. No era «se queda un año»: era «se queda siempre», y el
        #   `return borrados` era cero sin que nadie supiera por qué.
        # - y en el caso raro de que en el directorio de trabajo hubiera un fichero con ese
        #   nombre, se miraba ese y se borraba ese. Es decir que limpiar la caché podía
        #   borrar un fichero de la carpeta desde donde se arrancó Kodi.
        #
        # El otro salto, el de `nombre not in vivos`, sí usaba `os.path.join(base, nombre)`, y por
        # eso funcionaba: las carpetas huérfanas se borraban. Por eso la mitad de la función
        # llevaba años haciendo su trabajo y la otra ninguna, y no se nota si solo pruebas con
        # fuentes que ya no existen.
        for hijo in _hijos(ruta):
            completa = os.path.join(ruta, hijo)
            try:
                if ahora - os.path.getmtime(completa) <= plazo:
                    continue
                os.remove(completa)
                borrados += 1
            except OSError:
                pass
    return borrados


# --- "lo más usado" ---

def _lee_json_aparte(nombre, tipo, estricto=False):
    """Un JSON suelto del perfil, o `tipo()` vacío. Lo corrupto se aparta, no se machaca.

    El mismo trato que `_lee()`. Antes el historial y los favoritos devolvían el vacío con el
    fichero roto **y lo dejaban donde estaba**, así que la siguiente reproducción o el siguiente
    favorito escribían encima una lista de uno: se perdía todo lo anterior sin aviso. Ahora el
    roto (o el que no es del tipo que toca) se renombra a `.corrupt-<hora>` y queda en disco.

    Un `OSError` no es corrupción: en Windows es lo normal mientras otro proceso reemplaza el
    fichero. Quien solo pinta recibe el vacío; quien va a escribir pide `estricto` y recibe
    `StoreIlegible`, para no guardar encima de un fichero que seguramente está bien.
    """
    ruta = _ruta(nombre)
    try:
        with open(ruta, 'r', encoding='utf-8') as f:
            datos = json.load(f)
    except FileNotFoundError:
        return tipo()
    except ValueError:
        datos = None
    except OSError as e:
        if estricto:
            raise StoreIlegible(str(e)) from e
        _log(f'{nombre} no se ha podido leer: {e}', xbmc.LOGWARNING)
        return tipo()
    if isinstance(datos, tipo):
        return datos
    _log(f'{nombre} ilegible, se aparta', xbmc.LOGWARNING)
    try:
        os.replace(ruta, f'{ruta}.corrupt-{int(time.time())}')
    except OSError as e:
        # Si no se ha podido apartar, el roto sigue ahí y escribir ahora lo pisaría.
        if estricto:
            raise StoreIlegible(str(e)) from e
    return tipo()


def ultimo_servidor(seccion):
    """El último servidor abierto en una sección: un `fid`, `'todos'` o cadena vacía."""
    return str(_lee_json_aparte(ULTIMO, dict).get(seccion) or '')


def apunta_ultimo_servidor(seccion, fid):
    """Lo apunta para entrar directo la próxima vez. Sin cerrojo: si dos escrituras se pisan
    gana la última, y para un atajo de navegación eso es exactamente lo que se quiere."""
    datos = _lee_json_aparte(ULTIMO, dict)
    if datos.get(seccion) == fid:
        return
    datos[seccion] = fid
    import core_settings
    try:
        os.makedirs(perfil(), exist_ok=True)
    except OSError as e:
        _log(f'no se ha podido apuntar el último servidor: {e}', xbmc.LOGWARNING)
        return
    core_settings.atomic_write_json(_ruta(ULTIMO), datos)


def _lee_uso(estricto=False):
    """El fichero de uso (contadores e historial). Sin `estricto`, nunca lanza."""
    return _lee_json_aparte(USO, dict, estricto)


def _escribe_uso(datos):
    """Escribe el fichero de uso **tomando el cerrojo**, que se suelta al salir del `with`.

    Sin cerrojo, dos procesos que escriben a la vez se pisan el fichero. El cerrojo es el mismo
    de `mis_fuentes.json` pero con otro nombre, que es justo para lo que sirve tener un cerrojo
    por fichero.
    """
    os.makedirs(perfil(), exist_ok=True)
    import core_settings
    try:
        with _store().lock(USO + '.lock'):
            return core_settings.atomic_write_json(_ruta(USO), datos)
    except iptv_store.LockBusy:
        # Perder una memorizacion no es un problema: la proxima vez se vuelve a guardar.
        _log('no se ha podido guardar el fichero de uso, esta ocupado', xbmc.LOGWARNING)
        return False
    except iptv_store.StoreError as e:
        _log('no se ha podido escribir el fichero de uso: {0}'.format(e), xbmc.LOGERROR)
        return False


def uso_sumar(clave, nombre=''):
    """Suma una reproducción. Se llama **después** de reproducir, nunca antes.

    `nombre` es el título que se ha visto en pantalla, y se guarda **con la cuenta** (5.5).

    Antes el historial y «más usados» tenían que buscar el nombre en la caché de canales cada vez
    que pintaban una fila. Para una serie eso **no funcionaba nunca**: la fila de serie viene con
    clave `id` y el visor buscaba `sid`, así que salía `Canal 8123` en vez del nombre. Y para un
    capítulo es peor: en la caché de series están los ids de las **series**, no de los capítulos,
    así que aunque la clave estuviera bien no habría nada que encontrar.

    Guardando el título **en el momento en que se sabe**, que es al reproducir, no un rato
    después cuando se abre el historial, las dos pantallas dejan de depender de la caché para
    esto, y salen bien aunque la caché no esté, que es justo cuando se mira el historial: la
    caché caduca, y el historial es de lo que se mira tarde.

    Y no es una credencial: es el título de un canal, que ya está en pantalla.

    La lectura se mantiene fuera del cerrojo: el cerrojo se toma dentro de `_escribe_uso()`.
    Los dos llamantes (`reproducir()` y `_reproducir_m3u()`) se ejecutan secuencialmente en el
    hilo principal tras cada reproducción. Evita anidar cerrojos de ficheros no reentrantes
    que provocarían `LockBusy`.
    """
    try:
        datos = _lee_uso(estricto=True)
    except StoreIlegible as e:
        _log(f'no se suma la reproduccion, el fichero de uso no se ha podido leer: {e}',
             xbmc.LOGWARNING)
        return False
    ahora = int(time.time())
    entrada = datos.get(clave)
    if isinstance(entrada, dict):
        # Protegido como en `uso_top`: un `{"n": "x"}` a mano no puede tumbar la reproduccion.
        try:
            cuenta = int(entrada.get('n') or 0) + 1
        except (TypeError, ValueError):
            cuenta = 1
        # El nombre no se pierde al sumar: si esta vez no nos lo han pasado, se conserva el
        # que habia. Perderlo seria tirar el dato justo en la segunda reproduccion.
        guardado = str(entrada.get('nombre') or '').strip()
        entrada = {'n': cuenta, 't': ahora,
                   'nombre': str(nombre or '').strip() or guardado}
    else:
        entrada = {'n': 1, 't': ahora, 'nombre': str(nombre or '').strip()}
    datos[clave] = entrada
    if len(datos) > USO_MAX:
        datos = dict(sorted(datos.items(),
                            key=lambda kv: -(kv[1].get('t') if isinstance(kv[1], dict) else 0))
                    [:USO_MAX])
    return _escribe_uso(datos)


# --- favoritos de la seccion ------------------------------------------------
#
# Van aqui y no en `core_settings` a proposito. Los de `core_settings` son los del addon entero
# (Debrid, listas, acciones) y se guardan en `mis_favoritos.json` con su `platform` y su `action`.
# Un canal de esta seccion no es eso: se identifica por `fid` + `sid` + seccion, y su `url` es la
# de la pantalla, no una direccion de canal. Meterlo ahi lo mezclaria con lo demas y para quitarlo
# habria que adivinar cual era.

#: Tope de favoritos. Es un tope blando en el sentido de que al llegar no se avisa: se
#: olvidan los mas antiguos, que son los que menos se van a buscar. Un tope duro que avise en
#: cada reproduccion seria una pantalla de error por no tener memoria.
FAV_MAX = 500


def _clave_fav(fid, sid, seccion):
    return '{0}|{1}|{2}'.format(fid, seccion, sid)


def _lee_favoritos_crudo(estricto=False):
    """El fichero de favoritos, o una lista vacía. Sin `estricto`, nunca lanza.

    Un fichero feo no puede tumbar la pantalla de favoritos, que es de las pocas que se abren
    sin querer; pero tampoco se puede machacar (ver `_lee_json_aparte`).
    """
    return _lee_json_aparte(FAVORITOS, list, estricto)


def favoritos():
    """Los favoritos de la seccion, del más reciente al más viejo.

    Cada entrada es `{'fid', 'sid', 'seccion', 'nombre', 'logo', 'ext'}`. **Sin `url`**: la
    URL de un canal lleva las credenciales dentro del camino y aquí no tiene que estar
    escrita en ningun sitio, ni siquiera en un fichero que solo lee el addon.
    """
    out = []
    for f in _lee_favoritos_crudo():
        if not (isinstance(f, dict) and f.get('fid') and f.get('sid')):
            continue
        out.append({'fid': str(f['fid']), 'sid': str(f['sid']),
                    'seccion': str(f.get('seccion') or 'live'),
                    'nombre': str(f.get('nombre') or ''), 'logo': str(f.get('logo') or ''),
                    'ext': str(f.get('ext') or '')})
    return out


def es_favorito(fid, sid, seccion='live'):
    """Si está en favoritos. Para pintar la marca en la fila del canal."""
    clave = _clave_fav(fid, sid, seccion)
    return any(_clave_fav(f['fid'], f['sid'], f['seccion']) == clave for f in favoritos())


def favorito_poner(fid, sid, seccion='live', nombre='', logo='', ext=''):
    """Añade un favorito, o lo mueve a arriba si ya estaba. Devuelve si lo ha guardado.

    "Lo mueve a arriba" es lo que espera cualquiera que añade otra vez lo que ya tenía: si se
    queda donde estaba, añadir dos veces no cambiaría nada en pantalla y parecería que no
    funciona.

    Con el cerrojo ocupado (dos pulsaciones seguidas) devuelve False y no lanza: el `LockBusy`
    llegaría al router y saldría «HyperXStream: error en fuentes_fav_toggle», sin más.
    """
    import core_settings
    clave = _clave_fav(fid, sid, seccion)
    try:
        with _store().lock(LOCK_FAV):
            lista = [f for f in _lee_favoritos_crudo(estricto=True) if isinstance(f, dict)
                     and _clave_fav(f.get('fid'), f.get('sid'), f.get('seccion')) != clave]
            lista.insert(0, {'fid': str(fid), 'sid': str(sid), 'seccion': str(seccion or 'live'),
                             'nombre': str(nombre or ''), 'logo': str(logo or ''),
                             'ext': str(ext or '')})
            if len(lista) > FAV_MAX:
                lista = lista[:FAV_MAX]
            if not core_settings.atomic_write_json(_ruta(FAVORITOS), lista):
                _log('no se ha podido guardar el favorito', xbmc.LOGERROR)
                return False
    except _NO_SE_PUEDE_ESCRIBIR as e:
        _log(f'no se ha podido guardar el favorito: {e!r}', xbmc.LOGWARNING)
        return False
    return True


def favorito_quitar(fid, sid, seccion='live'):
    """Quita un favorito. Devuelve False solo si no se ha podido escribir.

    Si no estaba, devuelve True: lo que se pedía es que no esté, y una segunda pulsación o una
    pantalla que iba por detrás no son un fallo del que avisar.
    """
    import core_settings
    clave = _clave_fav(fid, sid, seccion)
    try:
        with _store().lock(LOCK_FAV):
            lista = _lee_favoritos_crudo(estricto=True)
            nueva = [f for f in lista if isinstance(f, dict)
                     and _clave_fav(f.get('fid'), f.get('sid'), f.get('seccion')) != clave]
            if len(nueva) == len(lista):
                return True
            if not core_settings.atomic_write_json(_ruta(FAVORITOS), nueva):
                return False
    except _NO_SE_PUEDE_ESCRIBIR as e:
        _log(f'no se ha podido quitar el favorito: {e!r}', xbmc.LOGWARNING)
        return False
    return True


def uso_recientes(limite=50):
    """Lo reproducido más recientemente, de más reciente a más viejo.

    `uso_top` ordena por veces y `uso_recientes` por fecha, y no son lo mismo: lo más usado
    puede ser algo que viste hace meses, que es justo lo que no quieres cuando buscas "qué
    estaba viendo". El almacén guarda los dos datos (`n` y `t`) desde el principio, así que
    esto no añade nada que no estuviera ya escrito.

    Sale de `_lee_uso()` con la `t` de cada entrada, que es la última vez que se reprodujo, no
    la primera: `uso_sumar` la sobrescribe en cada suma.
    """
    filas = []
    for clave, entrada in _lee_uso().items():
        if not isinstance(entrada, dict):
            continue
        try:
            filas.append((int(entrada.get('t') or 0), clave, str(entrada.get('nombre') or '')))
        except (TypeError, ValueError):
            continue
    filas.sort(key=lambda f: (-f[0], f[1]))
    return filas[:limite]


def partir_uso(clave):
    """
    (fid, sid, seccion) de una clave de uso, o la tupla vacía si no lo es.

    La clave es "fid|sid|seccion", que es lo que espera
    `uso_top(seccion=...)` para filtrar por sección (`uso_top` hace
    `endswith("|live")`). Se parte aquí y no en cada vista porque
    partirla a mano en tres sitios es tres sitios donde se equivoca uno.
    """
    partes = str(clave or '').split('|')
    if len(partes) != 3 or not all(partes[:2]):
        return ('', '', '')
    return (partes[0], partes[1], partes[2])


def uso_top(seccion=None, limite=100):
    """Lo más usado, de más a menos. `seccion` filtra por la parte final de la clave."""
    filas = []
    for clave, entrada in _lee_uso().items():
        if not isinstance(entrada, dict):
            continue
        if seccion and not clave.endswith('|{0}'.format(seccion)):
            continue
        try:
            filas.append((int(entrada.get('n') or 0), clave, int(entrada.get('t') or 0),
                          str(entrada.get('nombre') or '')))
        except (TypeError, ValueError):
            continue
    filas.sort(key=lambda f: (-f[0], -f[2], f[1]))
    return filas[:limite]


def uso_por_fuente():
    """`{fid: veces}` de lo reproducido desde cada fuente. Nunca lanza.

    La clave de uso es `fid|sid|seccion`, y por eso esto **no** es `uso_top()`: aquel ordena
    canales y cuenta cada canal por separado, y lo que se quiere para ordenar los servidores es
    sumar todos los canales de cada uno.

    Una fuente que no aparece es que no se ha reproducido nada de ella, que no es lo mismo que
    cero veces: se devuelve lo que hay y quien lo use decide qué hacer con la que falta.
    """
    salida = {}
    for clave, entrada in _lee_uso().items():
        if not isinstance(entrada, dict):
            continue
        fid = partir_uso(clave)[0]
        if not fid:
            continue
        try:
            veces = int(entrada.get('n') or 0)
        except (TypeError, ValueError):
            continue
        salida[fid] = salida.get(fid, 0) + veces
    return salida


# ---Ayudas de disco ---

def _es_id(valor):
    """True si el valor tiene **forma** de id del almacen.

    12 caracteres en hexadecimal, que es lo que `anadir()` genera (`uuid4().hex[:12]`). No es
    una comprobacion de contenido: es una de forma, que es lo que se necesita para decidir si
    un `fid` que viene de fuera es un id o un texto cualquiera.

    Y sale de un solo sitio, porque el mismo criterio se usa para **descartar** ids raros al
    leer el estado y para **no borrar** con un id que no lo es. Si divergieran, se podria
    guardar una fuente con un id raro y luego no borrar su cache, o al reves.

    Validación con fullmatch sin strip para evitar que valores con rutas relativas
    o sufijos adicionales apunten fuera de la carpeta de caché.

    Va igual que `_normaliza()`, que es el otro sitio donde se decide esto:
    son las dos mitades del mismo criterio.
    """
    return bool(_ID_RE.fullmatch(str(valor or '').lower()))

def _hijos(carpeta):
    try:
        return os.listdir(carpeta)
    except OSError:
        return []


def _borrar_arbol(carpeta):
    try:
        shutil.rmtree(carpeta)
        return True
    except OSError:
        return False
