# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
# Instalación de addons del ecosistema EspaKodi.
import io
import json
import os
import re
import sys
import urllib.parse
import xml.etree.ElementTree as ET
import zipfile

import requests
import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import list_screen

EK_REPO_POLL_TIMEOUT_S  = 20
EK_PROXY_POLL_TIMEOUT_S = 25  # repository.elementumorg levanta su proxy local a su ritmo
EK_ADDON_POLL_TIMEOUT_S = 60
EK_POLL_INTERVAL_MS     = 500
EK_INDICE_PASO_MS       = 2000  # preguntar qué ofrecen los repos es más caro que mirar un addon
EK_MAX_REPO_ZIP_BYTES   = 50 * 1024 * 1024
EK_MAX_ADDON_ZIP_BYTES  = 200 * 1024 * 1024
EK_MAX_UNZIP_BYTES      = 400 * 1024 * 1024  # lo que un zip puede descomprimir antes de pasar
EK_ZIP_TIMEOUT_S        = 30

EK_ELEMENTUM_REPO = "repository.elementumorg"
EK_REPO_OFICIAL = "repository.xbmc.org"

# La skin pide xbmc.gui 5.17.0, que es el de Kodi 21. En un Kodi anterior Kodi rechaza la
# instalación con un error que no explica nada, así que se comprueba antes de bajarse el repo.
EK_SKIN_KODI_MINIMO = 21

EK_OWN_ADDON_ID = "plugin.video.espatv"

# Definición de metadatos de addons de EspaKodi (addon_id, repo_id, zip_url, source_url, name, plot, fallback_icon)

EK_ADDONS = [
    (
        "plugin.video.espatv",
        "repository.espatv",
        "https://raw.githubusercontent.com/espakodi/espatv/main/repository.espatv-1.0.0.zip",
        "https://espakodi.github.io/espatv/",
        "EspaTV",
        "TDT, RTVE a la carta, búsqueda en YouTube y Dailymotion, catálogo de vídeos, radio, podcasts, reproducción de enlaces, noticias, meteorología, agenda deportiva y mucho más.",
        "directo.png",
    ),
    (
        "plugin.video.espadaily",
        "repository.espadaily",
        "https://fullstackcurso.github.io/espadaily/repository.espadaily-1.0.2.zip",
        "https://fullstackcurso.github.io/espadaily/",
        "EspaDaily",
        "Explora los catálogos de la televisión española y busca vídeos públicos en internet que coincidan.",
        "busqueda.png",
    ),
    (
        "plugin.video.atresdaily",
        "repository.atresdaily",
        "https://espatv.github.io/atresdaily/repository.atresdaily-1.0.1.zip",
        "https://espatv.github.io/atresdaily/",
        "AtresDaily",
        "Directos y catálogo a la carta de A3Player, con búsqueda.",
        "play_generic.png",
    ),
    (
        "plugin.program.loiolog",
        "repository.loiolog",
        "https://raw.githubusercontent.com/loioloio/loiolog/main/repository.loiolog-1.0.0.zip",
        "https://loioloio.github.io/loiolog/",
        "LoioLog",
        "Visualiza y busca en el log de Kodi con un visor de colores por severidad. Filtra por addon, texto o expresiones regulares. Exporta a TXT o JSON, comparte el log subiendo a internet o ábrelo en el móvil desde tu red local. Consulta estadísticas del log, compara errores entre sesiones y gestiona los logs anteriores.",
        "adv_log.png",
    ),
    (
        "plugin.program.flowfavmanager",
        "repository.flowfavmanager",
        "https://loioloio.github.io/flowfav/repository.flowfavmanager-1.0.0.zip",
        "https://loioloio.github.io/flowfav/",
        "Flow FavManager",
        "Organiza los favoritos de Kodi por secciones y cambia su aspecto y lo que hace cada uno. Trae editor, perfiles y copias de seguridad.",
        "favoritos.png",
    ),
    (
        "plugin.video.streamninja",
        "repository.streamninja",
        "https://raw.githubusercontent.com/fullstackcurso/estreamninja/main/repository.streamninja-1.0.0.zip",
        "https://fullstackcurso.github.io/estreamninja/",
        "StreamNinja",
        "Recepción y reproducción de enlaces de vídeo (YouTube, Dailymotion, AceStream y torrents) enviados desde la red local u otros addons.",
        "url.png",
    ),
    (
        "plugin.video.topzilla",
        "repository.topzilla",
        "https://raw.githubusercontent.com/espatv/topzilla/main/repository.topzilla-1.0.0.zip",
        "https://espatv.github.io/topzilla/",
        "TopZilla",
        "Rankings, fichas y vídeos de películas y series. Puedes buscarlas, filtrarlas y guardarlas en tu biblioteca de Kodi.",
        "busqueda.png",
    ),
    (
        "plugin.program.loiolink",
        "repository.loiolink",
        "https://loiolo.io/repository.loiolink-1.0.0.zip",
        "https://loiolo.io/",
        "loiolink",
        "Controla Kodi desde el navegador del móvil o del PC: mando a distancia, tu colección, streaming al móvil, envío de enlaces y favoritos.",
        "info.png",
    ),
    (
        "plugin.program.ekgames",
        "repository.ekgames",
        "https://espatv.github.io/ekgames/repository.ekgames-1.0.0.zip",
        "https://espatv.github.io/ekgames/",
        "EKGames",
        "Catorce minijuegos clásicos para echar una partida sin salir de Kodi: Snake, 2048, Tetris, Buscaminas, Memoria, Solitario, Flappy, Pong, Invaders, Burbujas, Frogger, Galaga, Asteroids y Pac-Man.\nSe juegan con el mando a distancia, con un mando de juego, con el teclado o con los dedos, guardan su récord y tienen cuatro niveles de dificultad.\nIncluye además Gamesek entero, sin instalar nada más: emuladores por sistema, tus carpetas de juegos, juegos libres que se descargan solos y el Modo Juego a pantalla completa.",
        "ek_juegos.png",
    ),
    (
        "plugin.program.gamesek",
        "repository.gamesek",
        "https://espakodi.github.io/gamesek/repository.gamesek-1.0.0.zip",
        "https://espakodi.github.io/gamesek/",
        "Gamesek",
        "Juegos y emuladores para Kodi, en español. Trae catorce clásicos que se abren al momento, sin descargar nada y sin emulador, y otros tantos que se descargan e instalan solos.\nTambién puedes importar tus juegos, enviarlos desde el móvil por la red de casa o pedirle que los busque por tus discos. El Modo Juego lo enseña todo a pantalla completa.",
        "ek_juegos.png",
    ),
    (
        "skin.retrostuary",
        "repository.retrostuary",
        "https://espakodi.github.io/retrostuary/repository.retrostuary-1.0.0.zip",
        "https://espakodi.github.io/retrostuary/",
        "Retrostuary",
        "El aspecto de Windows 95 para Kodi, hecho sobre Estuary. Se instala desde aquí y se "
        "actualiza solo.",
        "adv_skin.png",
    ),
    (
        "skin.ekskin",
        "repository.ekskin",
        "https://espakodi.github.io/ekskin/repository.ekskin-1.0.0.zip",
        "https://espakodi.github.io/ekskin/",
        "EKSkin",
        "Skin de EspaKodi con temas que imitan sistemas operativos, desde Windows 95 hasta Windows 11, "
        "Linux y Apple, y una interfaz pensada para facilitar la navegación entre addons. "
        "Se instala desde aquí y se actualiza sola.",
        "adv_skin.png",
    ),
]

# Dependencias y motores: piezas que otros addons necesitan por debajo. Se instalan bajo demanda y
# salen en su bloque de la ventana de EspaKodi Addons, pero no en la lista clásica, que es solo el
# ecosistema.
# (repo_id, zip_url, source_url, nombre, plot, icono)
EK_EXTRA = {
    "script.module.horus": (
        "repository.ekhorus",
        "https://espakodi.github.io/EKHorus/repository.ekhorus-1.0.0.zip",
        "https://espakodi.github.io/EKHorus/",
        "EKHorus",
        "Reproductor AceStream para Kodi: abre enlaces, magnets y torrents. EspaTV lo usa cuando un "
        "enlace AceStream no se puede abrir de otra manera.",
        "directo.png",
    ),
    "script.module.youtube.dl": (
        EK_REPO_OFICIAL,
        "",
        "https://github.com/xbmc/repo-scripts",
        "youtube-dl",
        "Módulo youtube-dl/yt-dlp para Kodi: resuelve la URL reproducible de cientos de webs de "
        "vídeo. Lo usan otros addons del ecosistema como motor de extracción, no tiene interfaz "
        "propia.\n\nSe instala desde el repositorio oficial de Kodi.",
        "adv_ytdlp.png",
    ),
    "plugin.video.elementum": (
        EK_ELEMENTUM_REPO,
        "https://github.com/ElementumOrg/repository.elementumorg/releases/download/v0.0.7/repository.elementumorg-0.0.7.zip",
        "https://github.com/elgatito/plugin.video.elementum",
        "Elementum",
        'Motor de reproducción de torrents y enlaces magnet para Kodi. EspaTV lo usa para '
        'los torrents. Se instala desde aquí con su repositorio, sin añadir ninguna fuente.',
        "p2p.png",
    ),
    "inputstream.adaptive": (
        EK_REPO_OFICIAL,
        "",
        "https://github.com/xbmc/inputstream.adaptive",
        "InputStream Adaptive",
        "Reproductor de emisiones adaptativas (HLS y DASH, también con DRM). EspaTV puede "
        "usarlo en los directos .m3u8 si se activa en sus ajustes.",
        "adv_motor_tdt.png",
    ),
    "script.module.resolveurl": (
        "repository.resolveurl",
        "",
        "https://github.com/Gujal00/ResolveURL",
        "ResolveURL",
        "Módulo de resolución de enlaces para servidores de vídeo externos.",
        # url.png no, que es el de StreamNinja y las dos filas salen en la misma ventana
        "url_clipboard.png",
    ),
}

# Cómo se instala cada dependencia. Lo que no está en la tabla usa el modo "repo" de siempre:
# bajar el zip de su repositorio y pedirle a Kodi que instale el addon desde él.
EK_MODO = {
    "script.module.youtube.dl": "official",
    "inputstream.adaptive": "official",
    "script.module.resolveurl": "official",
    "plugin.video.elementum": "proxy",
}


def _ek_extra_entry(addon_id):
    """Fila (addon_id, repo_id, zip_url, source_url, nombre, plot, icono) para una dependencia de
    EK_EXTRA, con la misma forma que las de EK_ADDONS, para reutilizar el instalador."""
    e = EK_EXTRA.get(addon_id)
    if not e:
        return None
    return (addon_id,) + tuple(e)


def _ek_addon_is_installed(addon_id):
    try:
        xbmcaddon.Addon(addon_id)
        return True
    except Exception:
        return False


def _ek_addon_dir_present(addon_id):
    addon_dir = xbmcvfs.translatePath("special://home/addons/{0}/".format(addon_id))
    return os.path.isdir(addon_dir) and os.path.isfile(os.path.join(addon_dir, "addon.xml"))


def _ek_jsonrpc(method, params=None):
    req = {"jsonrpc": "2.0", "id": 1, "method": method}
    if params is not None:
        req["params"] = params
    try:
        return json.loads(xbmc.executeJSONRPC(json.dumps(req)))
    except Exception:
        return {}


def _ek_addon_is_known(addon_id):
    resp = _ek_jsonrpc("Addons.GetAddonDetails", {"addonid": addon_id, "properties": ["enabled"]})
    return "result" in resp and "addon" in resp.get("result", {})


def _ek_addon_is_enabled(addon_id):
    """Instalado y encendido, que no es lo mismo: System.HasAddon() sigue siendo cierto con el
    addon desactivado. La ventana necesita distinguir los dos, porque un módulo apagado tiene que
    salir como "Deshabilitado" y poder encenderse, no como instalado y ya está."""
    return bool(xbmc.getCondVisibility("System.AddonIsEnabled({0})".format(addon_id)))


def _ek_addon_available_in_repos(addon_id):
    """Lo que ofrecen los repositorios y no está instalado. En Elementum, que el addon aparezca
    aquí significa que el proxy local de su repositorio ya está contestando.

    Sin `properties`: solo hace falta el identificador, y en un Kodi con repositorios grandes la
    respuesta sin propiedades pesa mucho menos que con el nombre de cada addon."""
    resp = _ek_jsonrpc("Addons.GetAddons", {"installed": False})
    resultado = resp.get("result") if isinstance(resp, dict) else None
    addons = resultado.get("addons") if isinstance(resultado, dict) else None
    if not isinstance(addons, list):
        return False
    return any(isinstance(a, dict) and a.get("addonid") == addon_id for a in addons)


def _ek_extraer_zip(zip_path, addons_dir=None):
    """Descomprime un zip de addon o de repositorio en addons/, sin dejar que se salga de ahí.

    Un zip con rutas tipo ../../ saldría de addons/. Cada ruta se resuelve y se compara con el
    directorio real: la comparación lleva la barra del final añadida a mano, porque
    os.path.realpath() quita la que venga, y sin ella una carpeta hermana como ../addons_x/
    pasaría el filtro por empezar igual que addons."""
    addons_dir = addons_dir or xbmcvfs.translatePath("special://home/addons/")
    addons_dir_real = os.path.realpath(addons_dir)
    prefijo = addons_dir_real if addons_dir_real.endswith(os.sep) else addons_dir_real + os.sep
    with zipfile.ZipFile(zip_path, "r") as zf:
        descomprimido = 0
        for info in zf.infolist():
            resolved = os.path.realpath(os.path.join(addons_dir, info.filename))
            if resolved != addons_dir_real and not resolved.startswith(prefijo):
                raise RuntimeError("ZIP contiene ruta sospechosa: {0}".format(info.filename))
            # Un zip pequeño puede descomprimirse en gigas (zip bomb), y eso se comprueba con lo que
            # el zip declara antes de escribir un solo byte.
            descomprimido += info.file_size
            if descomprimido > EK_MAX_UNZIP_BYTES:
                raise RuntimeError("El ZIP descomprime más de {0} MB".format(
                    EK_MAX_UNZIP_BYTES // (1024 * 1024)))
        # Antes de escribir nada se comprueba que todo el zip está bien. Descomprimir a ciegas deja
        # ficheros a medias encima del addon que ya estaba: si la segunda de tres entradas está
        # corrupta, el addon deja de arrancar y hay que reinstalarlo.
        corrupto = zf.testzip()
        if corrupto is not None:
            # RuntimeError y no Exception: install_helpers lo usa y sus llamantes capturan
            # (OSError, BadZipFile, RuntimeError).
            raise RuntimeError("El ZIP está corrupto ({0})".format(corrupto))
        zf.extractall(addons_dir)


def _ek_enable_addon_jsonrpc(addon_id):
    resp = _ek_jsonrpc("Addons.SetAddonEnabled", {"addonid": addon_id, "enabled": True})
    return resp.get("result") == "OK"


def _ek_try_recover_addon(addon_id):
    """Enciende un addon que ya está en el aparato, sin preguntar.

    Con JSON-RPC (SetAddonEnabled), no con el builtin EnableAddon, que pregunta sí/no cada vez
    (así una sola operación no acaba preguntando dos veces por el mismo addon)."""
    if _ek_addon_is_installed(addon_id):
        return True
    if not _ek_addon_is_known(addon_id) and not _ek_addon_dir_present(addon_id):
        return False
    if not _ek_addon_is_known(addon_id):
        xbmc.executebuiltin("UpdateLocalAddons()")
        xbmc.sleep(1500)
    _ek_enable_addon_jsonrpc(addon_id)
    for _ in range(20):
        if _ek_addon_is_installed(addon_id):
            return True
        xbmc.sleep(EK_POLL_INTERVAL_MS)
    return _ek_addon_is_installed(addon_id)


def reactivar(addon_id):
    """Enciende sin preguntar un addon que ya está en el aparato. True si queda encendido;
    False si no está instalado o Kodi no lo enciende. Lo usa ui_utils.addon_listo."""
    try:
        return _ek_try_recover_addon(addon_id)
    except (OSError, RuntimeError) as e:
        xbmc.log("[EspaTV] No se pudo reactivar {0}: {1}".format(addon_id, e), xbmc.LOGWARNING)
        return False


def _ek_addon_status_label(addon_id):
    try:
        xbmcaddon.Addon(addon_id)
        return "[COLOR lime]Instalado[/COLOR]"
    except Exception:
        pass
    if _ek_addon_is_known(addon_id):
        return "[COLOR orange]Deshabilitado[/COLOR]"
    return "[COLOR gray]No instalado[/COLOR]"


def _ek_addon_icon(addon_id, fallback=None):
    try:
        ad = xbmcaddon.Addon(addon_id)
        path = ad.getAddonInfo("path")
        for name in ("icon.png", "icon.jpg"):
            p = os.path.join(path, name)
            if os.path.exists(p):
                return p
    except Exception:
        pass
    media_dir = os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "resources", "media")
    return fallback or os.path.join(media_dir, "play_generic.png")


def _addon_fanart():
    # Mismo criterio que el menú principal (default.py:1614 y :2038): sin fanart si está
    # desactivado, el propio si hay uno, y si no el del addon.
    import core_settings
    if core_settings.is_fanart_disabled():
        return ''
    return core_settings.get_custom_fanart() or xbmcaddon.Addon().getAddonInfo("fanart")


def _ek_get_repo_datadir(repo_id):
    repo_xml = xbmcvfs.translatePath("special://home/addons/{0}/addon.xml".format(repo_id))
    if not os.path.isfile(repo_xml):
        return None
    try:
        with open(repo_xml, "r", encoding="utf-8") as f:
            content = f.read()
        m = re.search(r"<datadir[^>]*>\s*([^<\s]+)\s*</datadir>", content)
        if m:
            url = m.group(1).strip()
            if not url.endswith("/"):
                url += "/"
            return url
    except Exception as e:
        xbmc.log("[EspaTV] No se pudo leer datadir del repo {0}: {1}".format(repo_id, e), xbmc.LOGWARNING)
    return None


def _ek_find_addon_version_in_index(addons_xml_text, addon_id):
    try:
        m = re.search(
            r'<addon[^>]*\bid="' + re.escape(addon_id) + r'"[^>]*\bversion="([^"]+)"',
            addons_xml_text
        )
        if m:
            return m.group(1)
        m = re.search(
            r'<addon[^>]*\bversion="([^"]+)"[^>]*\bid="' + re.escape(addon_id) + r'"',
            addons_xml_text
        )
        if m:
            return m.group(1)
    except Exception:
        pass
    return None


def _ek_dependencias_listas(addons_xml, addon_id, version):
    """True si todo lo que necesita esa versión del addon ya está registrado en Kodi.

    EnableAddon solo escribe una línea en el log por una dependencia que falta y enciende el
    addon igual, así que sin esto el plan B dejaría un addon "instalado" que falla al abrirlo.
    Un índice que no se puede leer no para la instalación."""
    try:
        raiz = ET.fromstring(addons_xml)
    except ET.ParseError as e:
        xbmc.log("[EspaTV] No se pudo leer el índice para comprobar dependencias: {0}".format(e), xbmc.LOGWARNING)
        return True
    for addon in raiz.findall("addon"):
        if addon.get("id") != addon_id or addon.get("version") != version:
            continue
        for importa in addon.findall("requires/import"):
            necesita = importa.get("addon") or ""
            if not necesita or importa.get("optional") == "true":
                continue
            if not _ek_addon_is_known(necesita):
                xbmc.log("[EspaTV] Falta la dependencia {0} de {1}".format(necesita, addon_id), xbmc.LOGWARNING)
                return False
    return True


def _ek_install_addon_zip_directly(addon_id, repo_id, friendly_name):
    try:
        datadir = _ek_get_repo_datadir(repo_id)
        if not datadir:
            xbmc.log("[EspaTV] Fallback ({0}): no se pudo obtener datadir de {1}".format(friendly_name, repo_id), xbmc.LOGWARNING)
            return False
        try:
            r = requests.get(datadir + "addons.xml", timeout=20)
            if r.status_code != 200:
                return False
            addons_xml = r.text
        except Exception:
            return False
        version = _ek_find_addon_version_in_index(addons_xml, addon_id)
        if not version or not _ek_dependencias_listas(addons_xml, addon_id, version):
            return False
        addon_zip_url = "{0}{1}/{1}-{2}.zip".format(datadir, addon_id, version)
        try:
            zip_path = _ek_bajar_zip(addon_zip_url, "{0}-{1}".format(addon_id, version),
                                     EK_MAX_ADDON_ZIP_BYTES, timeout=60)
        except Exception as e:
            xbmc.log("[EspaTV] Fallback ({0}): no se pudo bajar el zip: {1}".format(friendly_name, e),
                     xbmc.LOGWARNING)
            return False
        try:
            _ek_extraer_zip(zip_path)
        finally:
            try:
                os.remove(zip_path)
            except OSError:
                pass
        xbmc.executebuiltin("UpdateLocalAddons()")
        xbmc.sleep(1500)
        xbmc.executebuiltin("EnableAddon({0})".format(addon_id))
        xbmc.sleep(1500)
        for _ in range(20):
            if _ek_addon_is_installed(addon_id):
                return True
            xbmc.executebuiltin("EnableAddon({0})".format(addon_id))
            xbmc.sleep(EK_POLL_INTERVAL_MS)
        return _ek_try_recover_addon(addon_id) or _ek_addon_is_installed(addon_id)
    except Exception as e:
        xbmc.log("[EspaTV] Fallback excepción: {0}".format(e), xbmc.LOGERROR)
        return False


_EK_ZIP_SEQ = 0


def _ek_zip_demasiado(max_bytes):
    return "Tamaño sospechoso: más de {0} MB".format(max_bytes // (1024 * 1024))


def _ek_bajar_zip(url, nombre, max_bytes, timeout=EK_ZIP_TIMEOUT_S):
    """Descarga un zip a temporal y devuelve dónde está. Lanza si no llega uno de tamaño razonable.

    Se lee por trozos y se corta en cuanto se pasa del tope, para que un servidor que sirva otra
    cosa no pueda agotar la memoria antes de que llegue el guardia. El nombre lleva un número
    porque dos descargas a la vez no pueden escribir en el mismo temporal."""
    global _EK_ZIP_SEQ
    r = requests.get(url, timeout=timeout, stream=True)
    try:
        if r.status_code != 200:
            raise Exception("Error HTTP {0}".format(r.status_code))
        # Lo que el servidor dice que pesa se comprueba antes de leer, que es gratis. isdecimal()
        # y no isdigit(), porque "²".isdigit() es True e int("²") revienta.
        largo = (r.headers.get("Content-Length") or "").strip()
        if largo.isdecimal() and int(largo) > max_bytes:
            raise Exception(_ek_zip_demasiado(max_bytes))
        datos = bytearray()
        for trozo in r.iter_content(64 * 1024):
            datos.extend(trozo)
            if len(datos) > max_bytes:
                raise Exception(_ek_zip_demasiado(max_bytes))
    finally:
        r.close()
    if len(datos) < 4 or datos[:2] != b"PK":
        raise Exception("El archivo descargado no es un ZIP válido")
    # "PK" solo no dice nada: un zip corrupto o cortado también empieza así. is_zipfile mira el
    # directorio del final, que es lo mínimo para saber si hay algo que abrir.
    if not zipfile.is_zipfile(io.BytesIO(bytes(datos))):
        raise Exception("El archivo descargado no es un ZIP válido")
    _EK_ZIP_SEQ += 1
    # El pid va en el nombre porque special://temp/ es compartido: dos ventanas de Kodi (o dos
    # addons) bajando a la vez el mismo repositorio se escribirían el mismo fichero.
    zip_path = os.path.join(xbmcvfs.translatePath("special://temp/"),
                            "{0}-{1}-{2}.zip".format(nombre, os.getpid(), _EK_ZIP_SEQ))
    with open(zip_path, "wb") as f:
        f.write(datos)
    return zip_path


class _Cancelado(Exception):
    """Cancelar en un diálogo, o Kodi cerrándose. De ninguno de los dos hay nada que decir."""


def _ek_esperar_repo(repo_id, dp):
    """Espera a que Kodi registre el repositorio recién extraído. Lanza si no o si se cancela."""
    repo_iters = (EK_REPO_POLL_TIMEOUT_S * 1000) // EK_POLL_INTERVAL_MS
    for i in range(repo_iters):
        if dp.iscanceled():
            raise _Cancelado()
        if _ek_addon_is_installed(repo_id):
            return True
        try:
            xbmcaddon.Addon(repo_id)
            return True
        except Exception:
            # Kodi a veces registra el repo deshabilitado: reintentamos habilitarlo en algunas vueltas.
            if i in (4, 12, 24):
                xbmc.executebuiltin("EnableAddon({0})".format(repo_id))
        xbmc.sleep(EK_POLL_INTERVAL_MS)
    raise Exception("Kodi no registró el repositorio tras {0}s".format(EK_REPO_POLL_TIMEOUT_S))


def _ek_pedir_a_kodi(addon_id, friendly_name):
    """Le pasa la instalación a Kodi, que pregunta él mismo, y espera a que acabe. True si lo dejó
    instalado. Nunca ejecutebuiltin(..., True): el builtin con espera retiene el GIL de Kodi y todo
    su Python se para hasta que acaba, así que un repositorio que sirve sus zips desde Python no
    podría hacerlo."""
    xbmcgui.Dialog().notification("EspaTV", "Instalando {0}...".format(friendly_name), xbmcgui.NOTIFICATION_INFO, 4000)
    xbmc.executebuiltin("InstallAddon({0})".format(addon_id))
    bg = xbmcgui.DialogProgressBG()
    bg.create("EspaTV", "Esperando instalación de {0}...".format(friendly_name))
    addon_iters = (EK_ADDON_POLL_TIMEOUT_S * 1000) // EK_POLL_INTERVAL_MS
    try:
        for i in range(addon_iters):
            if _ek_addon_is_installed(addon_id):
                return True
            xbmc.sleep(EK_POLL_INTERVAL_MS)
            pct = min(int((i + 1) * 100 / addon_iters), 99)
            bg.update(pct, "EspaTV", "Esperando instalación de {0}...".format(friendly_name))
    finally:
        bg.close()
    # Puede haber quedado instalado pero apagado, que en un addon sin menú da igual: se enciende.
    return _ek_try_recover_addon(addon_id)


def _ek_esperar_indice(addon_id, dp=None, plazo=EK_ADDON_POLL_TIMEOUT_S):
    """Si algún repositorio ofrece ya el addon. False si no aparece en el plazo; _Cancelado si el
    usuario Cancela, que no es un fallo y no se dice nada.

    Antes de recargar se mira una vez sin pedirle nada a nadie: UpdateAddonRepos() pregunta a todos
    los repos del aparato, y uno que a su vez contesta a otro sitio gasta parte de las peticiones
    por hora que su servidor da a una dirección antes de cortarla. Después se mira cada dos
    segundos, que es lo que tarda un índice en traer lo nuevo y no abusar de la pregunta."""
    if _ek_addon_available_in_repos(addon_id):
        return True
    xbmc.executebuiltin("UpdateAddonRepos()")
    esperas = max((plazo * 1000) // EK_INDICE_PASO_MS, 1)
    for _ in range(esperas):
        if dp is not None and dp.iscanceled():
            raise _Cancelado()
        xbmc.sleep(EK_INDICE_PASO_MS)
        if _ek_addon_available_in_repos(addon_id):
            return True
    return False


def _ek_instalado(friendly_name):
    xbmcgui.Dialog().notification("EspaTV", "{0} instalado correctamente".format(friendly_name), xbmcgui.NOTIFICATION_INFO, 4000)
    xbmc.executebuiltin("Container.Refresh")


def _ek_error_instalacion(friendly_name, err):
    xbmc.log("[EspaTV] Error instalando {0}: {1}".format(friendly_name, err), xbmc.LOGERROR)
    xbmcgui.Dialog().ok(
        "Error de instalación",
        "No se pudo instalar {0} automáticamente.\n\nError: {1}\n\n"
        "Puede que necesites activar Orígenes desconocidos en Ajustes.".format(friendly_name, err)
    )


def _ek_falta_su_repo(friendly_name, source_url):
    xbmcgui.Dialog().ok(
        "EspaTV",
        "{0} se instala desde su propio repositorio, que ya trae la app EspaKodi.\n\n"
        "En otro Kodi puedes añadirlo desde su página:\n{1}".format(friendly_name, source_url)
    )


def _ek_activar_repo_sin_preguntar(repo_id):
    """Enciende el repositorio por JSON-RPC y no por el builtin EnableAddon, que pregunta sí/no
    cada vez: el usuario ya ha dicho que sí una vez y no tiene por qué ver dos diálogos."""
    xbmc.executebuiltin("UpdateLocalAddons()")
    xbmc.sleep(1500)
    return _ek_enable_addon_jsonrpc(repo_id)


def _ek_kodi_no_instalo(friendly_name, donde):
    """Kodi no lo instaló. Puede que el usuario le haya dicho que no, así que el texto no culpa a
    nadie y solo dice dónde mirar por si fue otra cosa."""
    xbmcgui.Dialog().ok(
        "EspaTV",
        "Kodi no ha instalado {0}.\n\nSi no fuiste tú quien le dijo que no, comprueba que {1} está "
        "habilitado\n(Addons - Mis addons - Repositorios) e inténtalo de nuevo.".format(friendly_name, donde)
    )


def _ek_install_official(addon_id, repo_id, source_url, friendly_name):
    """De un repositorio que ya está en el aparato: el oficial de Kodi, o el de ResolveURL dentro
    de la app EspaKodi. No se baja nada, solo se refresca el índice y se le pide a Kodi."""
    if _ek_addon_is_enabled(addon_id):
        xbmcgui.Dialog().notification("EspaTV", "{0} ya está instalado".format(friendly_name), xbmcgui.NOTIFICATION_INFO, 3000)
        return True
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Instalando {0}...".format(friendly_name))
    try:
        # No todo lo "oficial" viene del repo de Kodi: ResolveURL viene del suyo, que puede no estar.
        if repo_id != EK_REPO_OFICIAL and not _ek_addon_is_enabled(repo_id):
            if not (_ek_addon_is_known(repo_id) or _ek_addon_dir_present(repo_id)):
                dp.close()
                _ek_falta_su_repo(friendly_name, source_url)
                return False
            dp.update(20, "Activando el repositorio...")
            _ek_activar_repo_sin_preguntar(repo_id)

        dp.update(40, "Actualizando índice del repositorio...")
        # Se cierra antes de la instalación nativa para evitar colisiones de interfaz.
        ofrecido = _ek_esperar_indice(addon_id, dp)
        dp.close()
        if (ofrecido and _ek_pedir_a_kodi(addon_id, friendly_name)) or _ek_try_recover_addon(addon_id):
            _ek_instalado(friendly_name)
            return True
        _ek_kodi_no_instalo(
            friendly_name,
            "el repositorio oficial de Kodi" if repo_id == EK_REPO_OFICIAL
            else "su repositorio, {0},".format(repo_id))
        return False
    except _Cancelado:
        # El usuario pulsó Cancelar: no falló nada y no hay nada que decir.
        return False
    except Exception as e:
        _ek_error_instalacion(friendly_name, e)
        return False
    finally:
        try:
            dp.close()
        except Exception:
            pass


def _ek_install_proxy(addon_id, repo_id, repo_zip_url, friendly_name):
    """De un repositorio con servicio propio, como el de Elementum, que publica sus addons desde
    un proxy local: se baja su zip, se enciende y se espera a que el proxy responda."""
    if _ek_addon_is_enabled(addon_id):
        xbmcgui.Dialog().notification("EspaTV", "{0} ya está instalado".format(friendly_name), xbmcgui.NOTIFICATION_INFO, 3000)
        return True
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Preparando {0}...".format(friendly_name))
    zip_path = None
    try:
        # El repo en su sitio. Si el usuario ya lo tiene, no se toca: el suyo puede ser más nuevo
        # o llevar sus propios ajustes.
        if not _ek_addon_dir_present(repo_id):
            dp.update(10, "Descargando el repositorio de {0}...".format(friendly_name))
            zip_path = _ek_bajar_zip(repo_zip_url, repo_id, EK_MAX_REPO_ZIP_BYTES)
            dp.update(25, "Instalando el repositorio de {0}...".format(friendly_name))
            _ek_extraer_zip(zip_path)

        dp.update(40, "Activando el repositorio...")
        xbmc.executebuiltin("UpdateLocalAddons()")
        _ek_esperar_repo(repo_id, dp)

        if not _ek_addon_available_in_repos(addon_id):
            # Kodi registra un repositorio dejado en addons/ pero no arranca su servicio hasta que
            # se reinicia o lo ve activarse. Apagarlo y encenderlo lo arranca al momento. Como
            # eso apaga el repositorio del usuario, si al final no se puede volver a encender hay
            # que decirlo, o se le deja el repositorio apagado sin avisar.
            _ek_jsonrpc("Addons.SetAddonEnabled", {"addonid": repo_id, "enabled": False})
            xbmc.sleep(1000)
            if not _ek_enable_addon_jsonrpc(repo_id):
                xbmc.log("[EspaTV] No se pudo volver a encender {0}".format(repo_id), xbmc.LOGWARNING)
                dp.close()
                xbmcgui.Dialog().ok(
                    "EspaTV",
                    "El repositorio de {0} se quedó apagado y no se ha podido volver a encender.\n\n"
                    "Enciéndelo en Addons - Mis addons - Repositorios y vuelve a pulsar {1}.".format(
                        repo_id, friendly_name)
                )
                return False

        dp.update(60, "Esperando al repositorio de {0}...".format(friendly_name))
        proxy_listo = _ek_esperar_indice(addon_id, dp, EK_PROXY_POLL_TIMEOUT_S)
        dp.close()

        # Si el proxy no llegó a publicar el addon, lo arregla reiniciar Kodi.
        if not proxy_listo:
            xbmcgui.Dialog().ok(
                "EspaTV",
                "El repositorio de {0} se instaló, pero su servicio aún no responde.\n\n"
                "Reinicia Kodi y vuelve a pulsar {0} para completar la instalación.".format(friendly_name)
            )
            return False

        if _ek_pedir_a_kodi(addon_id, friendly_name) or _ek_try_recover_addon(addon_id):
            _ek_instalado(friendly_name)
            return True
        xbmcgui.Dialog().ok(
            "EspaTV",
            "Kodi no ha completado la instalación de {0}.\n\n"
            "Reinicia Kodi e inténtalo de nuevo, o instálalo desde\n"
            "Addons - Instalar desde repositorio - {0}.".format(friendly_name)
        )
        return False
    except _Cancelado:
        return False
    except Exception as e:
        _ek_error_instalacion(friendly_name, e)
        return False
    finally:
        try:
            dp.close()
        except Exception:
            pass
        if zip_path and os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except OSError:
                pass


def _ek_dispatch_install(entry):
    """Instala la fila del catálogo con la que toque: repo, official o proxy."""
    addon_id, repo_id, zip_url, source_url, nombre = entry[0], entry[1], entry[2], entry[3], entry[4]
    modo = EK_MODO.get(addon_id, "repo")
    if modo == "official":
        return _ek_install_official(addon_id, repo_id, source_url, nombre)
    if modo == "proxy":
        return _ek_install_proxy(addon_id, repo_id, zip_url, nombre)
    if not zip_url:
        # Las dependencias sin zip son las de un repositorio que ya está en el aparato; si pierden
        # su entrada en EK_MODO, este camino intentaría bajarse una URL vacía sin decir nada.
        xbmc.log("[EspaTV] {0} no tiene zip de repositorio y su modo no es official".format(addon_id),
                 xbmc.LOGERROR)
        _ek_error_instalacion(nombre, Exception("no hay repositorio del que bajarlo"))
        return False
    return _ek_install_repo_and_addon(addon_id, repo_id, zip_url, nombre)


def _ek_kodi_version():
    """La versión mayor de Kodi, o None si no se puede leer.

    `System.BuildVersion` da cosas como "21.0.3 (21.0.3) git:...". Si viene vacío o en un formato
    raro se devuelve None, y quien pregunte trata eso como "no bloquear": quedarse sin poder
    instalar por no saber la versión sería peor que intentarlo."""
    m = re.match(r"\s*(\d+)", str(xbmc.getInfoLabel("System.BuildVersion") or ""))
    return int(m.group(1)) if m else None


def _ek_kodi_admite_skin():
    version = _ek_kodi_version()
    return version is None or version >= EK_SKIN_KODI_MINIMO


def _ek_preguntar_e_instalar(entry):
    """Pregunta al usuario y, si dice que sí, instala la fila del catálogo con el modo que le toque.
    False si dice que no, o si la instalación no se completó."""
    if _ek_es_skin(entry[0]) and not _ek_kodi_admite_skin():
        # En un Kodi anterior la instalación se rechaza sola y el usuario se queda sin saber por
        # qué. Mejor decirlo antes de descargar el repositorio.
        xbmcgui.Dialog().ok(
            "EspaTV",
            "{0} necesita Kodi 21 Omega o superior.\n\n"
            "Este Kodi es la versión {1}, así que la skin no se puede instalar aquí.".format(
                entry[4], _ek_kodi_version()))
        return False
    if not xbmcgui.Dialog().yesno(
            "EspaTV",
            "{0} no está instalado.\n\n¿Descargar e instalar automáticamente?".format(entry[4]),
            nolabel="No", yeslabel="Instalar"):
        return False
    return _ek_dispatch_install(entry)


def _ek_install_repo_and_addon(addon_id, repo_id, repo_zip_url, friendly_name):
    if _ek_addon_is_installed(addon_id):
        xbmcgui.Dialog().notification("EspaTV", "{0} ya está instalado".format(friendly_name), xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin("Container.Refresh")
        return True
    if _ek_try_recover_addon(addon_id):
        xbmcgui.Dialog().notification("EspaTV", "{0} reactivado correctamente".format(friendly_name), xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin("Container.Refresh")
        return True

    # Omitir extracción si el repositorio ya está instalado para evitar problemas de concurrencia.
    repo_already_present = _ek_addon_is_installed(repo_id)
    dp = xbmcgui.DialogProgress()
    dp.create(
        "EspaTV",
        "Descargando repositorio de {0}...".format(friendly_name) if not repo_already_present
        else "Instalando {0}...".format(friendly_name)
    )
    zip_path = None
    bg = None
    try:
        if not repo_already_present:
            dp.update(5, "Descargando repositorio...")
            zip_path = _ek_bajar_zip(repo_zip_url, repo_id, EK_MAX_REPO_ZIP_BYTES)
            dp.update(20, "Extrayendo repositorio...")
            _ek_extraer_zip(zip_path)
            dp.update(35, "Registrando repositorio en Kodi...")
            xbmc.executebuiltin("UpdateLocalAddons()")
            _ek_esperar_repo(repo_id, dp)
            dp.update(55, "Activando repositorio...")
            xbmc.executebuiltin("EnableAddon({0})".format(repo_id))
            xbmc.sleep(1500)
        dp.update(65, "Actualizando índice del repositorio...")
        xbmc.executebuiltin("UpdateAddonRepos()")
        xbmc.sleep(3000)
        # Cerrar progreso antes de la instalación nativa para evitar colisiones de interfaz.
        dp.close()
        addon_ready = _ek_pedir_a_kodi(addon_id, friendly_name)
        if addon_ready:
            xbmcgui.Dialog().notification("EspaTV", "{0} instalado correctamente".format(friendly_name), xbmcgui.NOTIFICATION_INFO, 4000)
            xbmc.executebuiltin("Container.Refresh")
            return True
        # Kodi no lo ha instalado: puede que el usuario le haya dicho que no. Antes se lanzaba
        # el plan B igual y se instalaba sin permiso; ahora hace falta confirmarlo.
        if not xbmcgui.Dialog().yesno(
                "EspaTV",
                "Kodi no ha instalado {0}.\n\n¿Instalarlo ahora por el método alternativo?".format(friendly_name),
                nolabel="No", yeslabel="Instalar"):
            return False
        bg = xbmcgui.DialogProgressBG()
        bg.create("EspaTV", "Instalación automática de {0} (fallback)...".format(friendly_name))
        bg.update(50)
        ok = _ek_install_addon_zip_directly(addon_id, repo_id, friendly_name)
        bg.close()
        bg = None
        if ok:
            xbmcgui.Dialog().notification("EspaTV", "{0} instalado correctamente".format(friendly_name), xbmcgui.NOTIFICATION_INFO, 4000)
            xbmc.executebuiltin("Container.Refresh")
            return True
        xbmcgui.Dialog().ok(
            "EspaTV",
            "El repositorio de {0} se instaló, pero la instalación del addon no se completó.\n\n"
            "Para terminarla manualmente:\nAddons - Instalar desde repositorio - {0} - Instalar".format(friendly_name)
        )
        return False
    except _Cancelado:
        # El usuario pulsó Cancelar: no falló nada y no hay nada que decir. Sin esto, el "Error: "
        # salía vacío y parecía que algo se había roto.
        try:
            dp.close()
        except Exception:
            pass
        if bg:
            try:
                bg.close()
            except Exception:
                pass
        return False
    except Exception as e:
        try:
            dp.close()
        except Exception:
            pass
        if bg:
            try:
                bg.close()
            except Exception:
                pass
        xbmc.log("[EspaTV] Error instalando {0}: {1}".format(friendly_name, e), xbmc.LOGERROR)
        xbmcgui.Dialog().ok(
            "Error de instalación",
            "No se pudo instalar {0} automáticamente.\n\nError: {1}\n\n"
            "Puede que necesites activar Orígenes desconocidos en Ajustes.".format(friendly_name, e)
        )
        return False
    finally:
        if zip_path and os.path.exists(zip_path):
            try:
                os.remove(zip_path)
            except OSError:
                pass


def entry_nombre(addon_id):
    """El nombre que se le enseña al usuario, o None si el addon no está en el catálogo."""
    fila = _EK_BY_ID.get(addon_id)
    return fila[4] if fila else None


def instalar_si_falta(addon_id):
    """Se asegura de que un addon del ecosistema esté instalado y activado. True si lo está.

    A diferencia de launch_by_id(), no lo abre si ya está instalado. Respeta el "No" de Kodi
    (el plan B pide confirmación) y no pregunta dos veces por activar."""
    if xbmc.getCondVisibility("System.AddonIsEnabled({0})".format(addon_id)):
        return True
    # Instalado/en el aparato pero desactivado: reactivar es más rápido que reinstalar.
    # Se avisa y se refresca porque, en la lista clásica (que no se repinta sola), si no, la fila
    # seguiría diciendo "Deshabilitado" hasta que el usuario refresque a mano.
    if _ek_addon_is_known(addon_id) or _ek_addon_dir_present(addon_id):
        if not _ek_try_recover_addon(addon_id):
            return False
        nombre = (entry_nombre(addon_id) if entry_nombre(addon_id) else addon_id)
        xbmcgui.Dialog().notification("EspaTV", "{0} reactivado".format(nombre),
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        xbmc.executebuiltin("Container.Refresh")
        return True

    entry = next((row for row in EK_ADDONS if row[0] == addon_id), None)
    if entry is None:
        entry = _ek_extra_entry(addon_id)
    if entry is None:
        xbmc.log("[EspaTV] instalar_si_falta: addon desconocido {0}".format(addon_id), xbmc.LOGWARNING)
        return False

    if not _ek_preguntar_e_instalar(entry):
        return False
    return bool(xbmc.getCondVisibility("System.AddonIsEnabled({0})".format(addon_id)))


def _ek_abre_o_activa(addon_id, nombre):
    """Estado de un addon que el usuario ha pedido abrir:

    'activo'    -> instalado y encendido; el llamante lo abre.
    'instalado' -> instalado pero desactivado: se ofrece activarlo (ui_utils.addon_listo) y no
                   hay que instalarlo (respetando que el usuario diga que no).
    'falta'     -> no está instalado: el llamante enseña su instalación.

    Se usa AddonIsEnabled (no HasAddon, que también es cierto con el addon desactivado)."""
    if xbmc.getCondVisibility("System.AddonIsEnabled({0})".format(addon_id)):
        return "activo"
    if xbmc.getCondVisibility("System.HasAddon({0})".format(addon_id)):
        import ui_utils
        ui_utils.addon_listo(addon_id, nombre)
        return "instalado"
    return "falta"


def _launch_espatv():
    addon_id = EK_OWN_ADDON_ID
    source   = "https://espakodi.github.io/espatv/"
    estado = _ek_abre_o_activa(addon_id, "EspaTV")
    if estado == "activo":
        xbmc.executebuiltin("Container.Update(plugin://{0}/,replace)".format(addon_id))
        return
    if estado == "instalado":
        return
    idx = xbmcgui.Dialog().select("EspaTV - instalación",
        ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"])
    if idx == 0:
        if xbmcgui.Dialog().yesno("EspaTV", "EspaTV no está instalado.\n\n¿Descargar e instalar automáticamente?"):
            _ek_install_repo_and_addon(addon_id, "repository.espatv",
                "https://raw.githubusercontent.com/espakodi/espatv/main/repository.espatv-1.0.0.zip", "EspaTV")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones EspaTV",
            "[B]Cómo instalar EspaTV[/B]\n\n"
            "1. Ajustes - Sistema - Addons - activa Orígenes desconocidos\n\n"
            "2. Ajustes - Explorador de archivos - Añadir fuente:\n   {0}\n\n"
            "3. Addons - Instalar desde un archivo zip - EspaTV\n   repository.espatv-x.x.x.zip\n\n"
            "4. Instalar desde repositorio - EspaTV - Addons de vídeo - EspaTV".format(source))


def _launch_espadaily():
    addon_id = "plugin.video.espadaily"
    source   = "https://fullstackcurso.github.io/espadaily/"
    estado = _ek_abre_o_activa(addon_id, "EspaDaily")
    if estado == "activo":
        xbmc.executebuiltin("Container.Update(plugin://{0}/,replace)".format(addon_id))
        return
    if estado == "instalado":
        return
    idx = xbmcgui.Dialog().select("EspaDaily - instalación",
        ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"])
    if idx == 0:
        if xbmcgui.Dialog().yesno("EspaTV", "EspaDaily no está instalado.\n\n¿Descargar e instalar automáticamente?"):
            _ek_install_repo_and_addon(addon_id, "repository.espadaily",
                "https://fullstackcurso.github.io/espadaily/repository.espadaily-1.0.2.zip", "EspaDaily")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones EspaDaily",
            "[B]Cómo instalar EspaDaily[/B]\n\n"
            "1. Ajustes - Sistema - Addons - activa Orígenes desconocidos\n\n"
            "2. Ajustes - Explorador de archivos - Añadir fuente:\n   {0}\n\n"
            "3. Addons - Instalar desde un archivo zip - EspaDaily\n   repository.espadaily-x.x.x.zip\n\n"
            "4. Instalar desde repositorio - EspaDaily - Addons de vídeo - EspaDaily".format(source))


def _launch_atresdaily():
    addon_id = "plugin.video.atresdaily"
    source   = "https://espatv.github.io/atresdaily/"
    estado = _ek_abre_o_activa(addon_id, "AtresDaily")
    if estado == "activo":
        xbmc.executebuiltin("Container.Update(plugin://{0}/,replace)".format(addon_id))
        return
    if estado == "instalado":
        return
    idx = xbmcgui.Dialog().select("AtresDaily - instalación",
        ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"])
    if idx == 0:
        if xbmcgui.Dialog().yesno("EspaTV", "AtresDaily no está instalado.\n\n¿Descargar e instalar automáticamente?"):
            _ek_install_repo_and_addon(addon_id, "repository.atresdaily",
                "https://espatv.github.io/atresdaily/repository.atresdaily-1.0.1.zip", "AtresDaily")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones AtresDaily",
            "[B]Cómo instalar AtresDaily[/B]\n\n"
            "1. Ajustes - Sistema - Addons - activa Orígenes desconocidos\n\n"
            "2. Ajustes - Explorador de archivos - Añadir fuente:\n   {0}\n\n"
            "3. Addons - Instalar desde un archivo zip - AtresDaily\n   repository.atresdaily-x.x.x.zip\n\n"
            "4. Instalar desde repositorio - AtresDaily - Addons de vídeo - AtresDaily".format(source))


def _launch_loiolog():
    addon_id = "plugin.program.loiolog"
    source   = "https://loioloio.github.io/loiolog/"
    estado = _ek_abre_o_activa(addon_id, "LoioLog")
    if estado == "activo":
        xbmcgui.Dialog().notification("EspaTV", "Abriendo LoioLog...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("RunAddon({0})".format(addon_id))
        return
    if estado == "instalado":
        return
    idx = xbmcgui.Dialog().select("LoioLog - instalación",
        ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"])
    if idx == 0:
        if xbmcgui.Dialog().yesno("EspaTV", "LoioLog no está instalado.\n\n¿Descargar e instalar automáticamente?"):
            _ek_install_repo_and_addon(addon_id, "repository.loiolog",
                "https://raw.githubusercontent.com/loioloio/loiolog/main/repository.loiolog-1.0.0.zip", "LoioLog")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones LoioLog",
            "[B]Cómo instalar LoioLog[/B]\n\n"
            "1. Ajustes - Sistema - Addons - activa Orígenes desconocidos\n\n"
            "2. Ajustes - Explorador de archivos - Añadir fuente:\n   {0}\n\n"
            "3. Addons - Instalar desde un archivo zip - LoioLog\n   repository.loiolog-x.x.x.zip\n\n"
            "4. Instalar desde repositorio - LoioLog - Addons de programa - LoioLog".format(source))


def _launch_flowfav():
    addon_id = "plugin.program.flowfavmanager"
    source   = "https://loioloio.github.io/flowfav/"
    estado = _ek_abre_o_activa(addon_id, "Flow Fav Manager")
    if estado == "activo":
        xbmcgui.Dialog().notification("EspaTV", "Abriendo Flow FavManager...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("RunAddon({0})".format(addon_id))
        return
    if estado == "instalado":
        return
    idx = xbmcgui.Dialog().select("Flow FavManager - instalación",
        ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"])
    if idx == 0:
        if xbmcgui.Dialog().yesno("EspaTV", "Flow FavManager no está instalado.\n\n¿Descargar e instalar automáticamente?"):
            _ek_install_repo_and_addon(addon_id, "repository.flowfavmanager",
                "https://loioloio.github.io/flowfav/repository.flowfavmanager-1.0.0.zip", "Flow FavManager")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones Flow FavManager",
            "[B]Flow FavManager[/B] - gestor avanzado de favoritos para Kodi.\n\n"
            "1. Ajustes - Sistema - Addons - activa Orígenes desconocidos\n\n"
            "2. Ajustes - Explorador de archivos - Añadir fuente:\n   {0}\n\n"
            "3. Addons - cajita - Instalar desde archivo zip - flowfav\n   repository.flowfavmanager-1.0.0.zip\n\n"
            "4. Instalar desde repositorio - Flow FavManager Repository\n   Program add-ons - Flow FavManager".format(source))


def _launch_streamninja():
    addon_id = "plugin.video.streamninja"
    source   = "https://fullstackcurso.github.io/estreamninja/"
    estado = _ek_abre_o_activa(addon_id, "StreamNinja")
    if estado == "activo":
        xbmcgui.Dialog().notification("EspaTV", "Abriendo StreamNinja...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("RunAddon({0})".format(addon_id))
        return
    if estado == "instalado":
        return
    idx = xbmcgui.Dialog().select("StreamNinja - instalación",
        ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"])
    if idx == 0:
        if xbmcgui.Dialog().yesno("EspaTV", "StreamNinja no está instalado.\n\n¿Descargar e instalar automáticamente?"):
            _ek_install_repo_and_addon(addon_id, "repository.streamninja",
                "https://raw.githubusercontent.com/fullstackcurso/estreamninja/main/repository.streamninja-1.0.0.zip", "StreamNinja")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones StreamNinja",
            "[B]Cómo instalar StreamNinja[/B]\n\n"
            "1. Ajustes - Sistema - Addons - activa Orígenes desconocidos\n\n"
            "2. Ajustes - Explorador de archivos - Añadir fuente:\n   {0}\n\n"
            "3. Addons - Instalar desde un archivo zip - StreamNinja\n   repository.streamninja-x.x.x.zip\n\n"
            "4. Instalar desde repositorio - StreamNinja - Addons de vídeo - StreamNinja".format(source))


def _launch_topzilla():
    addon_id = "plugin.video.topzilla"
    source   = "https://espatv.github.io/topzilla/"
    estado = _ek_abre_o_activa(addon_id, "TopZilla")
    if estado == "activo":
        xbmcgui.Dialog().notification("EspaTV", "Abriendo TopZilla...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("RunAddon({0})".format(addon_id))
        return
    if estado == "instalado":
        return
    idx = xbmcgui.Dialog().select("TopZilla - instalación",
        ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"])
    if idx == 0:
        if xbmcgui.Dialog().yesno("EspaTV", "TopZilla no está instalado.\n\n¿Descargar e instalar automáticamente?"):
            _ek_install_repo_and_addon(addon_id, "repository.topzilla",
                "https://raw.githubusercontent.com/espatv/topzilla/main/repository.topzilla-1.0.0.zip", "TopZilla")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones TopZilla",
            "[B]Cómo instalar TopZilla[/B]\n\n"
            "1. Ajustes - Sistema - Addons - activa Orígenes desconocidos\n\n"
            "2. Ajustes - Explorador de archivos - Añadir fuente:\n   {0}\n\n"
            "3. Addons - Instalar desde un archivo zip - TopZilla\n   repository.topzilla-x.x.x.zip\n\n"
            "4. Instalar desde repositorio - TopZilla - Addons de vídeo - TopZilla".format(source))


def _launch_loiolink():
    addon_id = "plugin.program.loiolink"
    source   = "https://loiolo.io/"
    estado = _ek_abre_o_activa(addon_id, "loiolink")
    if estado == "activo":
        xbmcgui.Dialog().notification("EspaTV", "Abriendo loiolink...", xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("RunAddon({0})".format(addon_id))
        return
    if estado == "instalado":
        return
    idx = xbmcgui.Dialog().select("loiolink - instalación",
        ["Instalador automático (puede fallar)", "Ver instrucciones de instalación manual"])
    if idx == 0:
        if xbmcgui.Dialog().yesno("EspaTV", "loiolink no está instalado.\n\n¿Descargar e instalar automáticamente?"):
            _ek_install_repo_and_addon(addon_id, "repository.loiolink",
                "https://loiolo.io/repository.loiolink-1.0.0.zip", "loiolink")
    elif idx == 1:
        xbmcgui.Dialog().textviewer("Instrucciones loiolink",
            "[B]Cómo instalar loiolink[/B]\n\n"
            "1. Ajustes - Sistema - Addons - activa Orígenes desconocidos\n\n"
            "2. Ajustes - Explorador de archivos - Añadir fuente:\n   {0}\n\n"
            "3. Addons - Instalar desde un archivo zip - loiolink\n   repository.loiolink-x.x.x.zip\n\n"
            "4. Instalar desde repositorio - loiolink - Addons de programa - loiolink".format(source))


_LAUNCH_HANDLERS = {
    "plugin.video.espatv":            _launch_espatv,
    "plugin.video.espadaily":         _launch_espadaily,
    "plugin.video.atresdaily":        _launch_atresdaily,
    "plugin.program.loiolog":         _launch_loiolog,
    "plugin.program.flowfavmanager":  _launch_flowfav,
    "plugin.video.streamninja":       _launch_streamninja,
    "plugin.video.topzilla":          _launch_topzilla,
    "plugin.program.loiolink":        _launch_loiolink,
}


def launch_by_id(addon_id):
    fn = _LAUNCH_HANDLERS.get(addon_id)
    if fn:
        fn()
        return
    # Una dependencia no tiene lanzador propio (no tiene ni menú): si está, se avisa; si falta o
    # está apagada, se instala por su modo. Sin esto, la lista clásica la dejaría como una fila
    # que no hace nada.
    entry = _EK_BY_ID.get(addon_id)
    if entry is None:
        xbmc.log("[EspaTV] launch_by_id: addon desconocido {0}".format(addon_id), xbmc.LOGWARNING)
        return
    if _ek_addon_is_enabled(addon_id):
        _ek_open_installed(entry)
        return
    if _ek_es_skin(addon_id):
        # Instalar una skin no la activa: si no se ofrece aquí, el usuario se queda con la de
        # siempre y con la impresión de que no ha pasado nada. En la lista clásica no hay ventana
        # modal detrás, así que preguntar y recargar la interfaz aquí es seguro.
        #
        # Se mira si quedó instalada, no lo que devuelve instalar_si_falta(): eso acaba en
        # System.AddonIsEnabled, que recién instalada una skin todavía no se ha refrescado y negaría
        # el falso.
        instalar_si_falta(addon_id)
        if _ek_addon_is_installed(addon_id):
            _ek_activar_skin(addon_id, entry[4])
        return
    instalar_si_falta(addon_id)


def open_repo_unificado():
    url = 'https://loiolo.io'
    abrir = xbmcgui.Dialog().yesno(
        'Repositorio Unificado',
        f'Añade esta URL como fuente en Kodi para instalar los addons de EspaKodi:\n\n[B]{url}[/B]\n\n¿Abrir en el navegador?',
        nolabel='Cerrar',
        yeslabel='Abrir navegador',
    )
    if abrir:
        _abrir_en_navegador(url, 'Abriendo repositorio...')


def _abrir_en_navegador(url, aviso):
    if xbmc.getCondVisibility('System.Platform.Android'):
        xbmc.executebuiltin(f'StartAndroidActivity("","android.intent.action.VIEW","","{url}")')
        xbmcgui.Dialog().notification('EspaTV', aviso, xbmcgui.NOTIFICATION_INFO, 2000)
        return
    import webbrowser
    try:
        ok = webbrowser.open(url)
    except webbrowser.Error:
        ok = False
    if not ok:
        xbmcgui.Dialog().ok('EspaTV', f'No se pudo abrir el navegador.\n\nAccede manualmente a:\n{url}')


def abrir_url(url, titulo, pregunta, aviso_android):
    """Pregunta si abrir la URL en el navegador y la abre. Lo usa la descarga de la app EspaKodi."""
    if xbmcgui.Dialog().yesno(
            titulo, f"{pregunta}\n\n[B]{url}[/B]\n\n¿Abrir en el navegador?",
            nolabel="Cerrar", yeslabel="Abrir navegador"):
        _abrir_en_navegador(url, aviso_android)


def open_web():
    url = 'https://espatv.github.io'
    abrir = xbmcgui.Dialog().yesno(
        'EspaKodi en la web',
        f'Portal de EspaKodi: todos los addons del ecosistema y la app, en un solo sitio.\n\n[B]{url}[/B]\n\n'
        '¿Abrir en el navegador?',
        nolabel='Cerrar',
        yeslabel='Abrir navegador',
    )
    if abrir:
        _abrir_en_navegador(url, 'Abriendo la web...')


def open_apk_latest():
    url = 'https://espakodi.github.io/apk/'
    abrir = xbmcgui.Dialog().yesno(
        'Última versión EspaKodi app',
        f'Descarga la última versión de la app EspaKodi:\n\n[B]{url}[/B]\n\n'
        '¿Abrir en el navegador?',
        nolabel='Cerrar',
        yeslabel='Abrir navegador',
    )
    if abrir:
        _abrir_en_navegador(url, 'Abriendo descarga...')


# Los canales de Telegram del ecosistema. Ahí se avisa de lo que sale y, de vez en cuando,
# aparecen addons y versiones que no llegan a esta pantalla (o llegan antes).
EK_TELEGRAM = 'https://t.me/espakodi'
EK_TELEGRAM_ESPADAILY = 'https://t.me/espadaily'

# El orden manda: es el que sale en el selector de open_telegram().
_EK_TELEGRAM_CANALES = (
    ('EspaKodi', EK_TELEGRAM),
    ('EspaDaily', EK_TELEGRAM_ESPADAILY),
)

_PLOT_TELEGRAM = (
    'En los canales de Telegram se publican addons y versiones especiales que a veces no llegan '
    'a esta lista.\n\n'
    '· EspaKodi, t.me/espakodi\n'
    '· EspaDaily, t.me/espadaily'
)


def open_telegram():
    """Ofrece los canales de Telegram del ecosistema y abre el que se elija.

    Los dos van en una sola fila con su selector: en el mensaje se ven las dos direcciones, y al
    elegir una se abre directo, sin volver a preguntar."""
    idx = xbmcgui.Dialog().select(
        'Telegram: ¿qué canal abro?',
        ['{0}  ·  {1}'.format(nombre, url) for nombre, url in _EK_TELEGRAM_CANALES])
    # -1 es Escape o Atrás: no se abre nada.
    if idx < 0:
        return
    _abrir_en_navegador(_EK_TELEGRAM_CANALES[idx][1], 'Abriendo Telegram...')


_PLOT_REPO_UNIFICADO = (
    'Fuente para instalar todos los addons del ecosistema EspaKodi. '
    'Añade loiolo.io como fuente en Kodi para tener acceso al repositorio con '
    'EspaTV, EspaDaily, AtresDaily, StreamNinja, LoioLog, Flow FavManager, '
    'TopZilla y loiolink en un solo lugar.'
)


def _ek_anadir_item(handle, media_dir, af, addon_id, name, plot, fallback_icon):
    """Una fila de la lista clásica: nombre, estado e icono, y la acción de lanzarla."""
    fallback_path = (os.path.join(media_dir, fallback_icon) if fallback_icon
                     else os.path.join(media_dir, "play_generic.png"))
    icon = _ek_addon_icon(addon_id, fallback=fallback_path)
    if addon_id == EK_OWN_ADDON_ID:
        own_icon = os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "icon.png")
        if not os.path.exists(own_icon):
            own_icon = os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "icon.jpg")
        if os.path.exists(own_icon):
            icon = own_icon
    li = xbmcgui.ListItem(label="{0} · {1}".format(name, _ek_addon_status_label(addon_id)))
    li.setArt({"icon": icon, "fanart": af})
    li.setInfo("video", {"plot": plot})
    url = sys.argv[0] + "?" + urllib.parse.urlencode({"action": "ek_launch", "addon_id": addon_id})
    xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)


def render_menu(handle):
    media_dir = os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "resources", "media")
    af = _addon_fanart()

    li_web = xbmcgui.ListItem(label='EspaKodi en la web')
    li_web.setArt({'icon': os.path.join(media_dir, 'portal.png'), 'fanart': af})
    li_web.setInfo('video', {'plot': 'Portal de EspaKodi: acceso a todos los addons del ecosistema y a la '
                                     'app EspaKodi lista para usar. Se abre en el navegador (espatv.github.io).'})
    url_web = sys.argv[0] + '?' + urllib.parse.urlencode({'action': 'ek_open_web'})
    xbmcplugin.addDirectoryItem(handle=handle, url=url_web, listitem=li_web, isFolder=False)

    repo_icon = os.path.join(media_dir, "info_repo.png")
    li_repo = xbmcgui.ListItem(label='Repositorio Unificado')
    li_repo.setArt({'icon': repo_icon, 'fanart': af})
    li_repo.setInfo('video', {'plot': _PLOT_REPO_UNIFICADO})
    url_repo = sys.argv[0] + '?' + urllib.parse.urlencode({'action': 'ek_open_repo'})
    xbmcplugin.addDirectoryItem(handle=handle, url=url_repo, listitem=li_repo, isFolder=False)

    li_apk = xbmcgui.ListItem(label='Última versión EspaKodi app')
    li_apk.setArt({'icon': os.path.join(media_dir, 'apk.png'), 'fanart': af})
    li_apk.setInfo('video', {'plot': 'Descarga la última versión de la app EspaKodi desde espakodi.github.io/apk.'})
    url_apk = sys.argv[0] + '?' + urllib.parse.urlencode({'action': 'ek_open_apk'})
    xbmcplugin.addDirectoryItem(handle=handle, url=url_apk, listitem=li_apk, isFolder=False)

    for addon_id, _repo_id, _zip, _src, name, plot, fallback_icon in EK_ADDONS:
        _ek_anadir_item(handle, media_dir, af, addon_id, name, plot, fallback_icon)

    # Las dependencias también se ofrecen aquí, en el MISMO orden que en la ventana: el de
    # EK_BLOQUES, no el del diccionario. Sin separador, que en una lista normal de Kodi el único
    # separador del addon (action="separador") dispara el Easter egg de los minijuegos y no
    # corresponde aquí; la otra lista clásica del addon (espakodi_app) tampoco los usa.
    ids_ecosistema = set(row[0] for row in EK_ADDONS)
    for _titulo, ids in EK_BLOQUES:
        for addon_id in ids:
            if addon_id in ids_ecosistema:
                continue
            fila = _EK_BY_ID.get(addon_id)
            if fila:
                _ek_anadir_item(handle, media_dir, af, addon_id, fila[4], fila[5], fila[6])
    # Y lo que quedara fuera de los bloques ("Otros"), que si no, escondería un addon.
    for addon_id, fila in _EK_BY_ID.items():
        if addon_id in ids_ecosistema or any(addon_id in ids for _t, ids in EK_BLOQUES):
            continue
        _ek_anadir_item(handle, media_dir, af, addon_id, fila[4], fila[5], fila[6])

    # El bloque Extra: apps de Android que no son addons, con su propia acción.
    for clave, (titulo, icono, plot) in _EK_EXTRA_UI.items():
        li_extra = xbmcgui.ListItem(label=titulo)
        li_extra.setArt({'icon': os.path.join(media_dir, icono), 'fanart': af})
        li_extra.setInfo('video', {'plot': plot})
        url_extra = sys.argv[0] + '?' + urllib.parse.urlencode(
            {'action': 'ek_extra', 'clave': clave})
        xbmcplugin.addDirectoryItem(handle=handle, url=url_extra, listitem=li_extra, isFolder=False)

    # Abajo del todo, igual que en la ventana: el aviso de que en el Telegram se publican addons
    # y versiones especiales que no salen en esta lista.
    li_tg = xbmcgui.ListItem(label='Más addons y versiones especiales en Telegram')
    li_tg.setArt({'icon': os.path.join(media_dir, 'ek_telegram.png'), 'fanart': af})
    li_tg.setInfo('video', {'plot': _PLOT_TELEGRAM})
    url_tg = sys.argv[0] + '?' + urllib.parse.urlencode({'action': 'ek_open_telegram'})
    xbmcplugin.addDirectoryItem(handle=handle, url=url_tg, listitem=li_tg, isFolder=False)

    xbmcplugin.endOfDirectory(handle)


# Estado de actualización del repositorio oficial del addon

_EK_OWN_REPO_PREFIX = "repository.espatv"


def _find_own_repo():
    addons_dir = xbmcvfs.translatePath("special://home/addons/")
    try:
        dirs, _ = xbmcvfs.listdir(addons_dir)
    except Exception:
        dirs = []
    for d in dirs:
        if d.startswith(_EK_OWN_REPO_PREFIX):
            addon_xml = os.path.join(addons_dir, d, "addon.xml")
            if xbmcvfs.exists(addon_xml):
                return d
    return None


def repo_status_label():
    if _find_own_repo():
        return "Actualizaciones: [COLOR lime]● INSTALADO[/COLOR]"
    return "Actualizaciones: [COLOR orange]○ NO DETECTADO[/COLOR]"


def check_repo_status():
    repo_id = _find_own_repo()
    if repo_id:
        xbmcgui.Dialog().ok(
            "EspaTV · Actualizaciones",
            "El repositorio oficial está instalado.\n\n"
            "Las actualizaciones de EspaTV llegarán automáticamente a través de él.\n\n"
            "Si quieres forzar una comprobación: Addons - Mis addons - {0} - Actualizar".format(repo_id)
        )
    else:
        xbmcgui.Dialog().ok(
            "EspaTV · Actualizaciones",
            "El repositorio oficial [B]no está detectado[/B].\n\n"
            "Sin él, EspaTV no recibirá actualizaciones automáticas.\n\n"
            "Instálalo manualmente desde el repositorio oficial de EspaTV."
        )


# --- Bloques y ventana propia de EspaKodi Addons ------------------------------------------------

_EK_BY_ID = {row[0]: row for row in EK_ADDONS}
for _extra_id in EK_EXTRA:
    _extra = _ek_extra_entry(_extra_id)
    if _extra:
        _EK_BY_ID[_extra_id] = _extra

# El orden de pantalla vive aparte del catálogo para poder mover cosas sin tocar las tuplas.
EK_BLOQUE_ECOSISTEMA = "Addons de EspaKodi"

# Las skins no son "addons del ecosistema": no hacen nada, cambian cómo se ve Kodi. Van aparte
# para que quepan más sin tocar el bloque de arriba.
EK_BLOQUE_ASPECTO = "Aspecto"

# Apps de Android de terceros (Cloudflare WARP, AceStream) que no son addons: no se instalan desde
# un repositorio, se descargan como los APK de la app EspaKodi. Van en su bloque al final, y los
# datos de cada descarga están en espakodi_app; aquí solo cómo se pintan y cómo se eligen.
EK_BLOQUE_EXTRA = "Extra"

# Las APK del bloque Extra se descargan con el mismo descargador que las de la app EspaKodi, así
# que acaban en el mismo diálogo de instalación: dentro de EspaKodi sale "Instalar ahora" y no
# hace falta gestor de archivos.
_AVISO_INSTALAR_APK = (
    'Si tienes la app EspaKodi, al terminar la descarga se instala desde aquí pulsando '
    '"Instalar ahora", sin necesidad de un gestor de archivos.'
)

_EK_EXTRA_UI = {
    "warp": ("Cloudflare WARP", "info_vpn.png",
             "Cifra la conexión del dispositivo a internet mediante Cloudflare (1.1.1.1).\n\n"
             "Versiones para Fire TV y Android TV con soporte para mando a distancia.\n\n"
             + _AVISO_INSTALAR_APK),
    "acestream": ("AceStream", "adv_acestream.png",
                  "Motor de streaming P2P para enlaces acestream://, utilizado por EKHorus y otros "
                  "reproductores multimedia.\n\n"
                  + _AVISO_INSTALAR_APK),
}

EK_BLOQUES = [
    (EK_BLOQUE_ECOSISTEMA, [
        "plugin.video.espatv",
        "plugin.video.espadaily",
        "plugin.video.atresdaily",
        "plugin.program.loiolink",
        "plugin.program.flowfavmanager",
        "plugin.video.streamninja",
        "plugin.video.topzilla",
        "plugin.program.loiolog",
        "plugin.program.ekgames",
        "plugin.program.gamesek",
    ]),
    (EK_BLOQUE_ASPECTO, [
        "skin.retrostuary",
        "skin.ekskin",
    ]),
    ("Dependencias y motores", [
        "script.module.youtube.dl",
        "plugin.video.elementum",
        "inputstream.adaptive",
        "script.module.resolveurl",
        "script.module.horus",
    ]),
]


def _ek_bloques():
    """(título, entradas) de cada bloque. Lo que esté en el catálogo y en ningún bloque cae en uno
    final, para que añadir un addon y olvidarse de la lista no lo esconda."""
    colocados = set()
    bloques = []
    for titulo, ids in EK_BLOQUES:
        entradas = [_EK_BY_ID[i] for i in ids if i in _EK_BY_ID]
        colocados.update(row[0] for row in entradas)
        if entradas:
            bloques.append((titulo, entradas))
    sueltos = [row for row in _EK_BY_ID.values() if row[0] not in colocados]
    if sueltos:
        bloques.append(("Otros", sueltos))
    return bloques


_PLOT_PORTAL = (
    "El portal de EspaKodi, con todos los addons del ecosistema y la app EspaKodi lista "
    "para usar. Se abre en el navegador (espatv.github.io)."
)

_PLOT_APP = (
    "La app EspaKodi es Kodi en español con los addons del ecosistema ya instalados.\n\n"
    "Aquí se descarga sin salir de Kodi la última versión del APK para Android, de 32 o de 64 "
    "bits, EspaKodi LaRoja y el instalador de EspaKodi para Windows.\n\n"
    "En el Telegram de EspaKodi (t.me/espakodi) hay más versiones, para LibreELEC, CoreELEC y "
    "una distribución Linux, y variantes de la app de Android."
)

_PLOT_SECCION = {
    EK_BLOQUE_ECOSISTEMA: "Los addons del ecosistema EspaKodi. Cada uno hace lo suyo y ninguno "
                          "depende de los demás; instala solo los que vayas a usar.",
    "Dependencias y motores": "Piezas que otros addons necesitan por debajo. La mayoría no tienen "
                              "menú propio: se instalan y ya está.",
    EK_BLOQUE_ASPECTO: "Skins para cambiar cómo se ve Kodi. Se instalan y luego se activan desde "
                       "aquí; el cambio es inmediato y se puede volver atrás cuando quieras.",
    EK_BLOQUE_EXTRA: "Apps de Android que no son addons y hacen falta para que otros funcionen. "
                     "Se descargan aquí, igual que los APK de EspaKodi.",
    "Otros": "Lo que hay en el catálogo y no encaja en las secciones de arriba.",
}


def _ek_es_skin(addon_id):
    """Si es una skin. Una skin no tiene menú que abrir: se instala y luego se activa, y activarla
    recarga toda la interfaz de Kodi."""
    return addon_id.startswith("skin.")


def _ek_activar_skin(addon_id, nombre):
    """Activa una skin ya instalada, preguntando antes. Se pregunta siempre, también al terminar
    de instalarla, porque una skin instalada y sin activar no cambia nada.

    Se ofrece reiniciar, y no es un adorno: al activarla Kodi recarga la interfaz al momento, pero
    lo que se ha instalado en esta misma sesión (el repositorio y la skin) no acaba de asentarse
    hasta que Kodi vuelve a arrancar. Quien active sin reiniciar puede quedarse con la interfaz a
    medias y sin saber por qué, así que se ofrece la salida en el mismo diálogo."""
    idx = xbmcgui.Dialog().select(
        "¿Activar {0} como skin de Kodi?".format(nombre),
        ["Activar y reiniciar Kodi",
         "Activar sin reiniciar",
         "Ahora no"])
    if idx not in (0, 1):
        # -1 (Escape o Atrás) y 2 son las dos formas de decir que no: ninguna activa nada.
        return False
    # Las dos builtins van seguidas y sin espera por el medio. Un xbmc.sleep() para "dar tiempo"
    # sería contraproducente: duerme el mismo hilo que procesa la cola, así que retrasaría la
    # activación y congelaría la interfaz. Kodi encola y ejecuta en orden, que es lo que se quiere.
    xbmc.executebuiltin("ActivateSkin({0})".format(addon_id))
    if idx == 0:
        xbmc.executebuiltin("RestartApp()")
    return True


def _ek_se_abre(addon_id):
    """Si tiene menú propio. Un módulo (EKHorus, youtube-dl, InputStream Adaptive, ResolveURL) no
    se puede abrir; se instala y ya está."""
    return addon_id != EK_OWN_ADDON_ID and addon_id.startswith("plugin.")


def _ek_open_installed(entry):
    addon_id, name = entry[0], entry[4]
    if addon_id == EK_OWN_ADDON_ID:
        xbmcgui.Dialog().notification("EspaTV", "Ya estás en EspaTV",
                                      xbmcgui.NOTIFICATION_INFO, 3000)
    elif addon_id in _LAUNCH_HANDLERS:
        launch_by_id(addon_id)
    elif _ek_es_skin(addon_id):
        # Una skin instalada no se "abre": lo que le queda es activarse.
        _ek_activar_skin(addon_id, name)
    elif _ek_se_abre(addon_id):
        xbmcgui.Dialog().notification("EspaTV", "Abriendo {0}...".format(name),
                                      xbmcgui.NOTIFICATION_INFO, 2000)
        xbmc.executebuiltin("RunAddon({0})".format(addon_id))
    else:
        xbmcgui.Dialog().notification("EspaTV", "{0} ya está instalado".format(name),
                                      xbmcgui.NOTIFICATION_INFO, 3000)


def _ek_estado(addon_id, encendido):
    """(texto de la pastilla, tinta, pista) según cómo está el addon.

    `encendido` es si está instalado y funcionando: uno puesto pero apagado no cuenta como
    instalado, o la ventana no podría ofrecer ni encenderlo ni instalarlo. La lista clásica usa
    otra comprobación (`_ek_addon_status_label`), pero las dos dicen lo mismo en los tres estados."""
    if encendido:
        if addon_id == EK_OWN_ADDON_ID:
            pista = "Es el que estás usando"
        elif _ek_es_skin(addon_id):
            pista = "Pulsa para activarla"
        elif _ek_se_abre(addon_id):
            pista = "Pulsa para abrirlo"
        else:
            pista = "Lo usan otros addons por debajo"
        return list_screen.color("Instalado", list_screen.TINTA_VERDE), "on", pista

    if _ek_addon_dir_present(addon_id):
        return (list_screen.color("Deshabilitado", list_screen.AZUL), "gris",
                "Pulsa para encenderlo")

    return list_screen.color("No instalado", list_screen.GRIS), "gris", "Pulsa para instalarlo"


def _ek_extra_filas():
    """Las apps del bloque Extra.

    No son addons, así que no tienen estado de instalado que consultar: lo único que se puede
    enseñar es si el fichero está ya descargado en la carpeta."""
    import espakodi_app  # aquí y no arriba porque espakodi_app importa este módulo
    media_dir = os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "resources", "media")
    variantes = {}
    for e in espakodi_app.descargas_extra():
        variantes.setdefault(e["clave"], []).append(e)

    filas = []
    for clave, (titulo, icono, plot) in _EK_EXTRA_UI.items():
        entradas = variantes.get(clave) or []
        if not entradas:
            # Una app sin nada que descargar no se pinta: sería una fila que no hace nada.
            continue
        descargada = any(espakodi_app.esta_descargado(e["nombre"]) for e in entradas)
        filas.append(list_screen.Fila(
            clave=clave, titulo=titulo,
            pista="Pulsa para descargarla" if not descargada else "Descargada",
            icono=os.path.join(media_dir, icono), plot=plot,
            pastilla=(list_screen.color("Descargado", list_screen.TINTA_VERDE), "on")
            if descargada else None))
    return filas


def abrir_extra(clave):
    """Elige variante de una app del bloque Extra y la descarga con la descarga de siempre.

    Si solo hay una variante (AceStream) se descarga sin preguntar: un diálogo con una opción es un
    diálogo de más."""
    import espakodi_app  # aquí y no arriba porque espakodi_app importa este módulo
    entradas = [e for e in espakodi_app.descargas_extra() if e["clave"] == clave]
    if not entradas:
        xbmc.log("[EspaTV] abrir_extra: descarga desconocida {0}".format(clave), xbmc.LOGWARNING)
        return
    titulo = _EK_EXTRA_UI.get(clave, (clave,))[0]
    if espakodi_app.descarga_en_marcha(*[e["nombre"] for e in entradas]):
        xbmcgui.Dialog().notification("EspaTV",
                                      "Ya se está descargando {0}".format(titulo),
                                      xbmcgui.NOTIFICATION_INFO, 3000)
        return
    if len(entradas) == 1:
        espakodi_app.descargar(entradas[0]["nombre"])
        return
    idx = xbmcgui.Dialog().select("Descargar {0}".format(titulo),
                                  [e["etiqueta"] for e in entradas] + ["Ahora no"])
    # -1 es Escape o Atrás, y el último es "Ahora no": en ninguno de los dos se descarga nada.
    if idx < 0 or idx >= len(entradas):
        return
    espakodi_app.descargar(entradas[idx]["nombre"])


def _ek_filas():
    media_dir = os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "resources", "media")
    filas = [
        list_screen.Fila(clave="web", titulo="EspaKodi en la web", pista="espatv.github.io",
                         icono=os.path.join(media_dir, "ek_web.png"), plot=_PLOT_PORTAL),
        list_screen.Fila(clave="repo", titulo="Repositorio Unificado",
                         pista="Cinco addons desde una sola fuente",
                         icono=os.path.join(media_dir, "info_repo.png"), plot=_PLOT_REPO_UNIFICADO),
        list_screen.Fila(clave="app", titulo="Descargar EspaKodi",
                         pista="EspaKodi, LaRoja y Windows",
                         icono=os.path.join(media_dir, "ek_apk.png"), plot=_PLOT_APP),
    ]

    for titulo, entradas in _ek_bloques():
        filas.append(list_screen.Fila(clave="", titulo=titulo, sep=True,
                                      plot=_PLOT_SECCION.get(titulo, "")))
        for addon_id, _repo, _zip, _src, name, plot, icono in entradas:
            etiqueta, tinta, pista = _ek_estado(addon_id, _ek_addon_is_enabled(addon_id))
            filas.append(list_screen.Fila(
                clave=addon_id, titulo=name, pista=pista,
                icono=_ek_addon_icon(addon_id, fallback=os.path.join(media_dir, icono)),
                pastilla=(etiqueta, tinta), plot=plot))

    filas.append(list_screen.Fila(clave="", titulo=EK_BLOQUE_EXTRA, sep=True,
                                  plot=_PLOT_SECCION.get(EK_BLOQUE_EXTRA, "")))
    filas.extend(_ek_extra_filas())

    # Abajo del todo a propósito: no es un addon que instalar, es el aviso de que en los canales
    # de Telegram se publican addons y versiones especiales que no salen en esta lista.
    filas.append(list_screen.Fila(
        clave="telegram", titulo="Más addons y versiones especiales en Telegram",
        pista="EspaKodi y EspaDaily",
        icono=os.path.join(media_dir, "ek_telegram.png"), plot=_PLOT_TELEGRAM))

    return filas


def mostrar_ventana():
    """EspaKodi addons en ventana propia. False si no se pudo abrir."""
    abrir_luego = []

    def pulsar(fila):
        if fila.clave == "web":
            open_web()
        elif fila.clave == "repo":
            open_repo_unificado()
        elif fila.clave == "telegram":
            # Sin esto, la clave caería en instalar_si_falta() y trataría de instalar un addon
            # con ese nombre.
            open_telegram()
        elif fila.clave == "app":
            # Solo cabe una ventana propia a la vez, así que esta se cierra y la otra se abre al
            # salir de doModal().
            abrir_luego.append("app")
            return "cerrar"
        elif fila.clave in _EK_EXTRA_UI:
            # Una app de Android, no un addon: se descarga como los APK de la app EspaKodi.
            abrir_extra(fila.clave)
        elif _ek_es_skin(fila.clave):
            # Una skin no se abre: se activa, y activarla recarga toda la interfaz. Instalarla y
            # ofrecer activarla desde dentro de doModal() lo dejaría a medias, así que la
            # instalación va aquí y el ofrecimiento al salir, igual que con la app.
            if not _ek_addon_is_enabled(fila.clave):
                instalar_si_falta(fila.clave)
            abrir_luego.append(fila.clave)
            return "cerrar"
        elif not _ek_addon_is_enabled(fila.clave):
            # Falta o está apagado. instalar_si_falta() distingue los dos casos y, si solo está
            # apagado, lo enciende sin preguntar (encender un addon no es instalar nada).
            instalar_si_falta(fila.clave)
        elif _ek_se_abre(fila.clave):
            # Un addon lanzado por debajo de una ventana modal se queda detrás de ella. Se cierra
            # la ventana y se abre al salir de doModal().
            abrir_luego.append(fila.clave)
            return "cerrar"
        else:
            # Un módulo no tiene pantalla propia; cerrar la ventana por él sería una sorpresa.
            _ek_open_installed(_EK_BY_ID[fila.clave])
        return None

    abierta = list_screen.mostrar(
        titulo=list_screen.titulo_ventana("EspaKodi Addons"),
        subtitulo="Todo el ecosistema",
        hacer_filas=_ek_filas,
        al_pulsar=pulsar,
        botones=(("EspaKodi en la web", open_web), ("Repositorio", open_repo_unificado)),
        estado="Pulsa un addon para abrirlo, para instalarlo si te falta o para activar una skin")

    for clave in abrir_luego:
        if clave == "app":
            import espakodi_app  # aquí y no arriba porque espakodi_app importa este módulo
            list_screen.abrir_o_lista("espakodi_app_menu", espakodi_app.mostrar_ventana)
        elif _ek_es_skin(clave):
            # Solo si quedó instalada: si la instalación falló, activar no tiene sentido. Se mira
            # que esté instalada, no System.AddonIsEnabled, que tras instalarla puede ir con
            # retraso y negaría la oferta sin razón.
            if _ek_addon_is_installed(clave):
                _ek_activar_skin(clave, entry_nombre(clave) or clave)
        elif clave in _LAUNCH_HANDLERS:
            launch_by_id(clave)
        else:
            xbmc.executebuiltin("RunAddon({0})".format(clave))

    return abierta
