# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Sección «Debrid Test»: busca una película o serie por texto, pide las fuentes a Torrentio
y las reproduce con la cuenta Debrid del usuario.

La sección no propone títulos: lo que se busca lo escribe el usuario. Cada acción entra por
``dispatch`` (llamado desde default_dispatch_extras) en su propio proceso de plugin.
"""
import os
import sys
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin

import cinemeta_api
import core_settings
import debrid_filesel
import debrid_resolver
import torrentio

_PLUGIN_ID = "plugin.video.espatv"
_LOG = "[EspaTV/DebridTest]"
_BUSY_PROP = "espatv.debrid_test.busy"
_BUSY_SECONDS = 90
_COPIED_PROP = "espatv.clipboard.title"

_PROVIDERS = ("AllDebrid", "Real-Debrid", "TorBox", "Premiumize")
_KEY_PAGES = {
    "AllDebrid": "alldebrid.com/apikeys",
    "Real-Debrid": "real-debrid.com/apitoken",
    "TorBox": "torbox.app/settings",
    "Premiumize": "premiumize.me/account",
}
_QUALITIES = ("2160p", "1080p", "720p")
_LANG_MODES = ("Priorizar español", "Solo español", "Sin preferencia")

_SHOWN_MAX = 30
_RELEASE_CHARS = 45
# «Reproducir la mejor» prueba fuentes sin esperar descargas. Con caché consultable (TorBox,
# Premiumize) bastan 3 en caché; sin ella (AllDebrid, Real-Debrid) probar cuesta 1-2 s por
# fuente y con solo 3 era fácil no dar con la que sí estaba.
_TRIES_KNOWN_CACHE = 3
_TRIES_UNKNOWN_CACHE = 6
_TRIES_BUDGET_S = 20
# Con menos semillas la descarga en la nube puede no llegar a empezar.
_MIN_SEEDS_TO_DOWNLOAD = 5

_VIDEO_MIME = {".mkv": "video/x-matroska", ".mp4": "video/mp4", ".m4v": "video/mp4", ".avi": "video/x-msvideo"}


def _log(msg, level=xbmc.LOGINFO):
    xbmc.log(f"{_LOG} {msg}", level)


def _addon():
    return xbmcaddon.Addon(_PLUGIN_ID)


def _u(**kw):
    return sys.argv[0] + "?" + urllib.parse.urlencode(kw)


def _notify(msg, level=xbmcgui.NOTIFICATION_INFO, ms=3500):
    xbmcgui.Dialog().notification("Debrid Test", msg, level, ms)


def _refresh():
    xbmc.executebuiltin("Container.Refresh")


# --- ajustes (ocultos; se cambian desde la propia sección) ---

def _setting(key, default):
    return _addon().getSetting(key) or default


def _quality():
    value = _setting("debrid_test_quality", "1080p")
    return value if value in _QUALITIES else "1080p"


def _lang_mode():
    value = _setting("debrid_test_lang", "0")
    return int(value) if value in ("0", "1", "2") else 0


def _torrentio_url():
    stored = _setting("debrid_test_torrentio_url", torrentio.DEFAULT_URL)
    try:
        return torrentio.validate_base_url(stored)
    except ValueError:
        _log("dirección de Torrentio guardada no válida; se usa la de fábrica", xbmc.LOGWARNING)
        return torrentio.DEFAULT_URL


def _provider_name():
    return _setting("debrid_provider", "AllDebrid")


def _copied_title():
    """Último título copiado desde los menús del addon (portapapeles interno, vale en cualquier plataforma)."""
    try:
        return xbmcgui.Window(10000).getProperty(_COPIED_PROP).strip()
    except RuntimeError:
        return ""


# --- cuenta ---

def _resolver():
    return debrid_resolver.get_resolver()


def _is_linked():
    return _resolver().is_authorized()


def _ask_text(prompt):
    """Texto por teclado o desde el móvil/PC, según el ajuste de búsqueda del addon."""
    sel = core_settings.get_search_input_sel("¿Cómo lo introduces?")
    if sel < 0:
        return ""
    if sel == 1:
        import url_remote
        text = url_remote.receive_text(prompt)
    else:
        kb = xbmc.Keyboard("", prompt)
        kb.doModal()
        text = kb.getText() if kb.isConfirmed() else ""
    return (text or "").strip()


def vincular_cuenta():
    """Elige proveedor y vincula la cuenta sin salir de la sección. True si queda vinculada."""
    addon = _addon()
    prev = _provider_name()
    pre = _PROVIDERS.index(prev) if prev in _PROVIDERS else 0
    sel = xbmcgui.Dialog().select("Proveedor Debrid (hace falta una cuenta de pago)", list(_PROVIDERS), preselect=pre)
    if sel < 0:
        return False
    name = _PROVIDERS[sel]
    if name != prev:
        addon.setSetting("debrid_provider", name)
        addon.setSetting("debrid_hosts_cache", "")
        debrid_resolver.reset_resolver()

    resolver = _resolver()
    use_pin = False
    if resolver.SUPPORTS_PIN:
        how = xbmcgui.Dialog().select(
            f"Vincular {name}", ["Código en pantalla (recomendado)", "Pegar API key"])
        if how < 0:
            return _revert_provider(prev)
        use_pin = how == 0
    try:
        if use_pin:
            done = resolver.authorize_pin()
        else:
            key = _ask_text(f"API key de {name} ({_KEY_PAGES[name]})")
            done = bool(key) and resolver.authorize_apikey(key)
    except debrid_resolver.DebridError as e:
        # authorize_* avisan de sus propios fallos, pero un corte de red puede salirse de ellos.
        _log(f"vincular {name}: {e}", xbmc.LOGWARNING)
        xbmcgui.Dialog().ok("Debrid Test", f"No se pudo conectar con {name}. Inténtalo de nuevo.")
        done = False
    debrid_resolver.reset_resolver()
    if not done:
        return _revert_provider(prev)
    _notify(f"Cuenta {name} vinculada")
    return True


def _revert_provider(prev):
    """Si no se llegó a vincular, se deja el proveedor que había (y su cuenta) como estaba."""
    if _provider_name() != prev:
        _addon().setSetting("debrid_provider", prev)
        _addon().setSetting("debrid_hosts_cache", "")
        debrid_resolver.reset_resolver()
    return False


def _show_account_info():
    try:
        info = _resolver().account_info()
    except debrid_resolver.DebridError as e:
        xbmcgui.Dialog().ok("Cuenta Debrid", f"No se pudo consultar la cuenta:\n{e}")
        return
    lines = [f"Usuario: {info.get('username', '?')}",
             f"Estado: {'Premium' if info.get('premium') else 'No premium'}"]
    if info.get("expiry_text"):
        days = info.get("days")
        lines.append(f"Válida hasta: {info['expiry_text']}" + (f" ({days} días)" if isinstance(days, int) else ""))
    if info.get("extra"):
        lines.append(info["extra"])
    xbmcgui.Dialog().ok(f"Cuenta {_resolver().name}", "\n".join(lines))


def account():
    sel = xbmcgui.Dialog().select(
        f"Cuenta {_resolver().name}", ["Comprobar cuenta", "Cambiar de cuenta o de proveedor", "Desvincular"])
    if sel == 0:
        _show_account_info()
    elif sel == 1:
        vincular_cuenta()
    elif sel == 2 and xbmcgui.Dialog().yesno("Debrid Test", "¿Desvincular la cuenta de este addon?"):
        _resolver().deauthorize()
        debrid_resolver.reset_resolver()
        _notify("Cuenta desvinculada")
    _refresh()


def link_account():
    vincular_cuenta()
    _refresh()


def explain_account():
    xbmcgui.Dialog().ok(
        "Necesitas una cuenta Debrid",
        "Un servicio Debrid (AllDebrid, Real-Debrid, TorBox o Premiumize) es una suscripción de pago que "
        "guarda los torrents en su nube y te los da como un enlace directo para ver.\n\n"
        "Puedes buscar y navegar sin cuenta; para reproducir hace falta vincularla. Se hace desde aquí, "
        "con «Vincular cuenta Debrid».")


# --- pantalla de la sección ---

def _icon(nombre):
    return os.path.join(xbmcaddon.Addon().getAddonInfo("path"), "resources", "media", f"debrid_{nombre}.png")


def _action_item(h, label, icon, plot, **kw):
    li = xbmcgui.ListItem(label=label)
    li.setArt({"icon": icon, "thumb": icon})
    li.setInfo("video", {"plot": plot})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(**kw), listitem=li, isFolder=False)


def menu(handle):
    if _is_linked():
        user = _resolver().stored_user()
        _action_item(
            handle, f"Cuenta: [COLOR limegreen]{_resolver().name}{' · ' + user if user else ''}[/COLOR]",
            _icon("cuenta"), "Comprueba el estado de la cuenta, cámbiala o desvincúlala.", action="debrid_test_account")
    else:
        _action_item(
            handle, "[COLOR gold]Necesitas una cuenta Debrid[/COLOR]", _icon("info"),
            "Para reproducir hace falta una cuenta de AllDebrid, Real-Debrid, TorBox o Premiumize. "
            "Pulsa para ver qué es.", action="debrid_test_info")
        _action_item(
            handle, "[COLOR limegreen][B]Vincular cuenta Debrid[/B][/COLOR]", _icon("vincular"),
            "Elige tu proveedor y vincula la cuenta sin salir de esta sección.", action="debrid_test_link")

    _action_item(
        handle, "[B]Buscar título de película o serie[/B]", _icon("buscar"),
        "Escribe el nombre y busca fuentes.\n\n[C] en caché (reproducción inmediata)\n"
        "[NO] habría que descargarla primero\nSin marca: tu proveedor no permite comprobarlo",
        action="debrid_test_search")
    copied = _copied_title()
    if copied:
        # Carpeta: abre directamente el listado de resultados.
        li = xbmcgui.ListItem(label=f"Pegar título copiado: [COLOR limegreen]{_clean(copied)}[/COLOR]")
        li.setArt({"icon": _icon("pegar"), "thumb": _icon("pegar")})
        li.setInfo("video", {"plot": "Busca con el título que copiaste desde el menú de una película o serie."})
        xbmcplugin.addDirectoryItem(handle=handle, url=_u(action="debrid_test_results", q=copied),
                                    listitem=li, isFolder=True)
    else:
        # Siempre visible para que se sepa que existe; sin título copiado explica cómo copiarlo.
        _action_item(
            handle, "Pegar título copiado: [COLOR gold]ninguno[/COLOR]", _icon("pegar"),
            "En Modo Cine, pulsa una película o serie y elige «Copiar título al portapapeles». "
            "El título aparecerá aquí para buscarlo.", action="debrid_test_paste_help")
    _action_item(
        handle, "Buscar por IMDb ID (tt...)", _icon("imdb"),
        "Si ya conoces el identificador de IMDb de la película o serie.", action="debrid_test_imdb")
    if _is_linked():
        li = xbmcgui.ListItem(label=f"Mi nube {_resolver().name}")
        li.setArt({"icon": _icon("nube"), "thumb": _icon("nube")})
        li.setInfo("video", {"plot": "Vídeos que tienes en tu cuenta. Reproduce o borra su contenido."})
        xbmcplugin.addDirectoryItem(handle=handle, url=_u(action="debrid_library"), listitem=li, isFolder=True)

    _action_item(handle, f"Calidad preferida: [COLOR limegreen]{_quality()}[/COLOR]", _icon("calidad"),
                 "Las fuentes más cercanas a esta calidad salen primero.", action="debrid_test_set_quality")
    _action_item(handle, f"Idioma: [COLOR limegreen]{_LANG_MODES[_lang_mode()]}[/COLOR]", _icon("idioma"),
                 "Priorizar español sube las fuentes en castellano o latino; Solo español oculta el resto.",
                 action="debrid_test_set_lang")
    url = _torrentio_url()
    de_fabrica = url == torrentio.DEFAULT_URL
    origen = "Torrentio (de fábrica)" if de_fabrica else urllib.parse.urlparse(url).netloc
    uso = "Estás usando Torrentio, el índice de fábrica." if de_fabrica else f"Dirección en uso: {url}"
    _action_item(handle, f"Índice de fuentes: [COLOR limegreen]{origen}[/COLOR]", _icon("indice"),
                 f"{uso}\nPuedes cambiarla o volver a la de fábrica. Solo para usuarios avanzados.",
                 action="debrid_test_set_url")
    xbmcplugin.endOfDirectory(handle, cacheToDisc=False)


# --- búsqueda ---

def _end_failed(handle):
    if handle >= 0:
        try:
            xbmcplugin.endOfDirectory(handle, succeeded=False)
        except RuntimeError:
            pass


def paste_help():
    xbmcgui.Dialog().ok(
        "Pegar título copiado",
        "1. En Modo Cine, pulsa una película o serie.\n"
        "2. Elige «Copiar título al portapapeles».\n"
        "3. Vuelve aquí y pulsa este botón.")


def search_prompt(handle):
    query = _ask_text("Introduce el título de la película o serie")
    _end_failed(handle)
    if query:
        xbmc.executebuiltin(f"Container.Update({_u(action='debrid_test_results', q=query)})")


def _search_titles(query):
    """TMDB (títulos en español) y, si falla o no da nada, Cinemeta. None si no se pudo buscar."""
    import metadata_enricher as me
    found = me.search_multi(query)
    if found:
        return found
    out, failed = [], 0
    for kind, media_type in (("movie", "movie"), ("series", "show")):
        try:
            for r in cinemeta_api.search(kind, query):
                out.append({"tmdb_id": "", "imdb_id": r["imdb_id"], "title": r["title"],
                            "year": r["year"][:4], "poster": r["poster"], "overview": "", "media_type": media_type})
        except cinemeta_api.CinemetaError as e:
            failed += 1
            _log(f"Cinemeta {kind}: {e}", xbmc.LOGWARNING)
    return None if failed == 2 else out


def _title_label(title, year):
    return f"{title} ({year})" if year else title


def results(handle, query):
    found = _search_titles(query)
    if found is None:
        _notify("No se pudo buscar. Prueba con el IMDb ID", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    if not found:
        _notify("Sin resultados")
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    for r in found:
        is_show = r["media_type"] == "show"
        li = xbmcgui.ListItem(label=_title_label(r["title"], r["year"]) + (" · serie" if is_show else ""))
        li.setArt({"icon": r["poster"] or "DefaultVideo.png", "thumb": r["poster"], "poster": r["poster"]})
        li.setInfo("video", {"title": r["title"], "plot": r.get("overview", ""),
                             "mediatype": "tvshow" if is_show else "movie"})
        common = {"title": r["title"], "year": r["year"], "poster": r["poster"],
                  "tmdb_id": r["tmdb_id"], "imdb_id": r.get("imdb_id", "")}
        if is_show:
            url, folder = _u(action="debrid_test_seasons", **common), True
        else:
            url, folder = _u(action="debrid_test_play", mode="movie", **common), False
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=folder)
    # Sin setContent: la skin pinta la carátula en la fila en vez de la marca de visto.
    # Con caché, volver atrás desde una serie no repite la búsqueda.
    xbmcplugin.endOfDirectory(handle)


def _cinemeta_imdb(kind, title, year):
    """IMDb de Cinemeta por título; solo si coincide el año (evita otra película con el mismo nombre)."""
    try:
        for r in cinemeta_api.search(kind, title):
            if year and r["year"].startswith(year):
                return r["imdb_id"]
    except cinemeta_api.CinemetaError as e:
        _log(f"Cinemeta {kind}: {e}", xbmc.LOGWARNING)
    return ""


def _imdb_of(params, media_type):
    """IMDb del título: el que ya viene, el de TMDB o, si TMDB no lo tiene, el de Cinemeta."""
    if params.get("imdb_id"):
        return params["imdb_id"]
    import metadata_enricher as me
    imdb = me.imdb_for(params.get("tmdb_id"), media_type) if params.get("tmdb_id") else ""
    return imdb or _cinemeta_imdb("series" if media_type == "show" else "movie",
                                  params.get("title", ""), params.get("year", ""))


# --- series: temporadas y episodios (numeración de IMDb, la misma que usa Torrentio) ---

def _manual_item(handle, params, imdb):
    li = xbmcgui.ListItem(label="[COLOR gold]Escribir temporada y episodio[/COLOR]")
    li.setArt({"icon": "DefaultAddonsSearch.png"})
    li.setInfo("video", {"plot": "No se pudo obtener la lista de episodios. Escribe la temporada y el episodio con la numeración de IMDb."})
    keep = {k: params.get(k, "") for k in ("title", "year", "poster")}
    xbmcplugin.addDirectoryItem(
        handle=handle, url=_u(action="debrid_test_manual", imdb_id=imdb, **keep), listitem=li, isFolder=False)


def seasons(handle, params):
    imdb = _imdb_of(params, "show")
    if not imdb:
        _notify("No se encontró este título en IMDb", xbmcgui.NOTIFICATION_WARNING)
        xbmcplugin.endOfDirectory(handle, succeeded=False)
        return
    try:
        listing = cinemeta_api.seasons(imdb)
    except cinemeta_api.CinemetaError as e:
        _log(f"Cinemeta temporadas: {e}", xbmc.LOGWARNING)
        _manual_item(handle, params, imdb)
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return
    if not listing:
        _manual_item(handle, params, imdb)
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return
    poster = params.get("poster", "")
    for season, episodes in listing:
        name = "Especiales" if season == 0 else f"Temporada {season}"
        li = xbmcgui.ListItem(label=f"{name} ({len(episodes)})")
        li.setArt({"icon": poster or "DefaultVideo.png", "thumb": poster, "poster": poster})
        li.setInfo("video", {"title": name, "mediatype": "season"})
        url = _u(action="debrid_test_episodes", imdb_id=imdb, season=season,
                 **{k: params.get(k, "") for k in ("title", "year", "poster")})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=True)
    xbmcplugin.setContent(handle, "seasons")
    xbmcplugin.endOfDirectory(handle)


def episodes(handle, params):
    imdb, season = params.get("imdb_id", ""), int(params.get("season") or 0)
    try:
        listing = dict(cinemeta_api.seasons(imdb))
    except cinemeta_api.CinemetaError as e:
        _log(f"Cinemeta episodios: {e}", xbmc.LOGWARNING)
        listing = {}
    if not listing.get(season):
        _manual_item(handle, params, imdb)
        xbmcplugin.endOfDirectory(handle, cacheToDisc=False)
        return
    poster = params.get("poster", "")
    for ep in listing[season]:
        label = f"{season}x{ep['episode']:02d} · {ep['title'] or 'Episodio ' + str(ep['episode'])}"
        if not ep["aired"]:
            label = f"{label} [COLOR gold](sin emitir)[/COLOR]"
        li = xbmcgui.ListItem(label=label)
        thumb = ep["thumbnail"] or poster
        li.setArt({"icon": thumb or "DefaultVideo.png", "thumb": thumb, "poster": poster})
        li.setInfo("video", {"title": ep["title"], "plot": ep["overview"], "season": season,
                             "episode": ep["episode"], "aired": ep["released"], "mediatype": "episode"})
        url = _u(action="debrid_test_play", mode="show", imdb_id=imdb, season=season, episode=ep["episode"],
                 ep_title=ep["title"], **{k: params.get(k, "") for k in ("title", "year", "poster")})
        xbmcplugin.addDirectoryItem(handle=handle, url=url, listitem=li, isFolder=False)
    xbmcplugin.setContent(handle, "episodes")
    xbmcplugin.endOfDirectory(handle)


def manual_episode(params):
    season = xbmcgui.Dialog().numeric(0, "Temporada (numeración de IMDb)")
    if not season:
        return
    episode = xbmcgui.Dialog().numeric(0, "Episodio (numeración de IMDb)")
    if not episode:
        return
    play(dict(params, mode="show", season=season, episode=episode))


def imdb_prompt(handle):
    _end_failed(handle)
    text = _ask_text("IMDb ID de la película o serie (tt1234567)")
    if not text:
        return
    imdb = torrentio.normalize_imdb_id(text)
    if imdb is None:
        _notify("ID de IMDb no válido", xbmcgui.NOTIFICATION_WARNING)
        return
    kind = None
    for candidate in ("movie", "series"):
        try:
            found = cinemeta_api.meta(candidate, imdb)
        except cinemeta_api.CinemetaError as e:
            _log(f"Cinemeta meta: {e}", xbmc.LOGWARNING)
            break
        if found:
            kind = candidate
            break
    if kind is None:
        sel = xbmcgui.Dialog().select("Cinemeta no conoce este ID. ¿Qué es?", ["Película", "Serie"])
        if sel < 0:
            return
        kind, found = ("movie", "series")[sel], None
    info = found or {}
    params = {"imdb_id": imdb, "title": info.get("title") or imdb, "year": info.get("year", "")[:4],
              "poster": info.get("poster", "")}
    if kind == "movie":
        play(dict(params, mode="movie"))
    else:
        xbmc.executebuiltin(f"Container.Update({_u(action='debrid_test_seasons', **params)})")


# --- ajustes ---

def set_quality():
    nxt = _QUALITIES[(_QUALITIES.index(_quality()) + 1) % len(_QUALITIES)]
    _addon().setSetting("debrid_test_quality", nxt)
    _notify(f"Calidad: {nxt}", ms=1800)
    _refresh()


def set_lang():
    nxt = (_lang_mode() + 1) % len(_LANG_MODES)
    _addon().setSetting("debrid_test_lang", str(nxt))
    _notify(f"Idioma: {_LANG_MODES[nxt]}", ms=1800)
    _refresh()


def set_torrentio_url():
    sel = xbmcgui.Dialog().select("Índice de fuentes", ["Cambiar la dirección", "Restaurar la de fábrica"])
    if sel == 1:
        _addon().setSetting("debrid_test_torrentio_url", torrentio.DEFAULT_URL)
    elif sel == 0:
        text = _ask_text("Dirección del índice de fuentes (https://...)")
        if not text:
            return
        try:
            _addon().setSetting("debrid_test_torrentio_url", torrentio.validate_base_url(text))
        except ValueError as e:
            xbmcgui.Dialog().ok("Debrid Test", str(e))
            return
    else:
        return
    _refresh()


# --- reproducir ---

def _acquire():
    """Marca de la búsqueda en curso, o None si ya hay otra reciente."""
    win = xbmcgui.Window(10000)
    started = win.getProperty(_BUSY_PROP)
    try:
        if started and time.time() - float(started) < _BUSY_SECONDS:
            return None
    except ValueError:
        pass
    token = repr(time.time())
    win.setProperty(_BUSY_PROP, token)
    return token


def _release(token):
    # Solo si sigue siendo la nuestra: pasados 90 s otra invocación ha podido quedársela.
    win = xbmcgui.Window(10000)
    if win.getProperty(_BUSY_PROP) == token:
        win.clearProperty(_BUSY_PROP)


def _clean(text):
    # Los corchetes de un nombre de release se leerían como etiquetas de formato de Kodi.
    return text.replace("[", "(").replace("]", ")")


def _fmt_size(size):
    if not size:
        return ""
    return f"{size / 1e9:.1f} GB" if size >= 1e9 else f"{size / 1e6:.0f} MB"


def _source_line(s):
    tags = []
    if s.cached is True:
        tags.append("[COLOR lime][B][C][/B][/COLOR]")
    elif s.cached is False:
        tags.append("[COLOR tomato][B][NO][/B][/COLOR]")
    if s.is_pack:
        tags.append("[COLOR plum][PACK][/COLOR]")
    parts = [" ".join(tags)] if tags else []
    parts.append(s.quality)
    if s.size_bytes:
        parts.append(_fmt_size(s.size_bytes))
    badge = torrentio.LANG_BADGES[s.lang_rank]
    if badge:
        parts.append(f"[COLOR gold]{badge}[/COLOR]")
    parts.append(f"{s.seeders} seeds")
    if s.provider:
        parts.append(s.provider)
    release = _clean(s.release)
    if len(release) > _RELEASE_CHARS:
        release = release[:_RELEASE_CHARS - 1] + "…"
    parts.append(release)
    return " · ".join(parts)


def _header(params, provider, shown, total):
    title = _title_label(params.get("title", ""), params.get("year", ""))
    if params.get("mode") == "show":
        title = f"{params.get('title', '')} T{int(params['season'])}E{int(params['episode']):02d}"
    return f"{title} · {provider} · {shown} de {total}"


def _mime_for(url):
    return _VIDEO_MIME.get(os.path.splitext(urllib.parse.urlsplit(url).path)[1].lower())


def _start_player(url, params):
    is_movie = params.get("mode") != "show"
    title = params.get("title", "")
    if not is_movie:
        title = f"{title} {params['season']}x{int(params['episode']):02d}"
    li = xbmcgui.ListItem(label=title, path=url)
    info = {"title": params.get("ep_title") or title, "mediatype": "movie" if is_movie else "episode"}
    if params.get("year", "")[:4].isdigit():
        info["year"] = int(params["year"][:4])
    if not is_movie:
        info.update({"tvshowtitle": params.get("title", ""), "season": int(params["season"]),
                     "episode": int(params["episode"])})
    li.setInfo("video", info)
    poster = params.get("poster", "")
    if poster:
        li.setArt({"thumb": poster, "poster": poster})
    mime = _mime_for(url)
    if mime:
        li.setMimeType(mime)
    li.setContentLookup(False)
    xbmc.Player().play(url, li)


def _resolve_stream(resolver, stream, ep_key, allow_uncached):
    """URL directa de una fuente, con la caché de enlaces de «Abrir URL»."""
    import url_player
    key = f"{stream.info_hash}|{ep_key or ''}"
    url = url_player._debrid_cache_get(resolver.name, key)
    if url:
        return url
    url = resolver.resolve_source(stream.info_hash, stream.file_hint, ep_key, allow_uncached)
    if url:
        url_player._debrid_cache_put(resolver.name, key, url)
    return url


def _best_to_download(streams, provider):
    """La primera en el orden normal con semillas suficientes y sin ser un pack (que bajaría la
    temporada entera; solo Real-Debrid elige un fichero). Si ninguna cumple, la de más semillas."""
    for s in streams:
        if s.seeders >= _MIN_SEEDS_TO_DOWNLOAD and not (s.is_pack and provider != "Real-Debrid"):
            return s
    return max(streams, key=lambda s: s.seeders)


def _confirm_download(stream, provider):
    text = (f"No está en la caché de {provider}: hay que descargarla primero en tu nube. "
            f"Con {stream.seeders} semillas puede tardar de minutos a horas.")
    if stream.is_pack and provider != "Real-Debrid":
        text += "\nSe descargará la temporada completa."
    return xbmcgui.Dialog().yesno("Debrid Test", text + "\n\n¿Continuar?")


def _explain_failure(resolver, reason):
    # Sin cuenta, el resolver ya ha avisado; con FAIL_BUSY también («Ya se está descargando»).
    if not resolver.is_authorized() or reason == resolver.FAIL_BUSY:
        return
    if reason == resolver.FAIL_MISSING:
        _notify("Esta fuente no trae el vídeo pedido", xbmcgui.NOTIFICATION_WARNING)
    else:
        _notify("No se ha podido reproducir esta fuente", xbmcgui.NOTIFICATION_WARNING)


def _try_best(resolver, streams, ep_key):
    """(url, cancelado, descartadas). La URL es la de la primera fuente que ya esté lista; nunca
    espera una descarga. ``descartadas`` son los hashes que fallaron por algo que descargarlos no
    arregla (no traen el episodio, ya se descargan, error)."""
    cache_known = any(s.cached is not None for s in streams)
    if cache_known:
        candidates = [s for s in streams if s.cached is True][:_TRIES_KNOWN_CACHE]
    else:
        candidates = [s for s in streams if s.cached is None][:_TRIES_UNKNOWN_CACHE]
    discarded = set()
    if not candidates:
        return None, False, discarded
    dlg = xbmcgui.DialogProgress()
    dlg.create("Debrid Test", "Buscando una fuente lista...")
    started = time.time()
    try:
        for i, s in enumerate(candidates, 1):
            if dlg.iscanceled():
                return None, True, discarded
            if not resolver.is_authorized():
                return None, False, discarded
            if not cache_known and i > 1 and time.time() - started > _TRIES_BUDGET_S:
                break
            dlg.update(int(i / len(candidates) * 100), f"Probando fuente {i} de {len(candidates)}...")
            url = _resolve_stream(resolver, s, ep_key, allow_uncached=False)
            if url:
                return url, False, discarded
            if resolver.last_failure != resolver.FAIL_UNCACHED:
                discarded.add(s.info_hash)
    finally:
        dlg.close()
    return None, False, discarded


def _play_best(resolver, streams, ep_key, params):
    """True si empezó a reproducir."""
    url, canceled, discarded = _try_best(resolver, streams, ep_key)
    if url:
        _start_player(url, params)
        return True
    if canceled or not resolver.is_authorized():
        return False
    pool = [s for s in streams if s.info_hash not in discarded]
    if not pool:
        _notify("Ninguna de estas fuentes sirve", xbmcgui.NOTIFICATION_WARNING)
        return False
    best = _best_to_download(pool, resolver.name)
    summary = " · ".join(p for p in (best.quality, _fmt_size(best.size_bytes),
                                     torrentio.LANG_BADGES[best.lang_rank], f"{best.seeders} seeds") if p)
    if not xbmcgui.Dialog().yesno(
            "Debrid Test",
            f"Ninguna está lista al momento.\n¿Descargar en tu nube la mejor?\n{summary}\n\n"
            "Puede tardar unos minutos."):
        return False
    url = _resolve_stream(resolver, best, ep_key, allow_uncached=True)
    if url:
        _start_player(url, params)
        return True
    _explain_failure(resolver, resolver.last_failure)
    return False


def _check_ready(resolver, stream, ep_key):
    """Prueba la fuente sin descargar nada. Tarda 1-2 s: con progreso, la pantalla no parece colgada."""
    dlg = xbmcgui.DialogProgress()
    dlg.create("Debrid Test", "Comprobando si está lista...")
    try:
        return _resolve_stream(resolver, stream, ep_key, allow_uncached=False)
    finally:
        dlg.close()


def _play_one(resolver, stream, ep_key, params):
    """True si empezó a reproducir una fuente elegida a mano."""
    if stream.cached is False:
        url, reason = None, resolver.FAIL_UNCACHED
    else:
        url = _check_ready(resolver, stream, ep_key)
        reason = resolver.last_failure
    if not url and reason == resolver.FAIL_UNCACHED and resolver.is_authorized():
        if not _confirm_download(stream, resolver.name):
            return False
        url = _resolve_stream(resolver, stream, ep_key, allow_uncached=True)
        reason = resolver.last_failure
    if url:
        _start_player(url, params)
        return True
    _explain_failure(resolver, reason)
    return False


def _choose_and_play(resolver, streams, total, params, ep_key):
    shown = min(len(streams), _SHOWN_MAX)
    streams = streams[:_SHOWN_MAX]
    labels = ["[COLOR limegreen][B]Reproducir la mejor[/B][/COLOR]"] + [_source_line(s) for s in streams]
    header = _header(params, resolver.name, shown, total)
    while True:
        sel = xbmcgui.Dialog().select(header, labels)
        if sel < 0:
            return
        played = (_play_best(resolver, streams, ep_key, params) if sel == 0
                  else _play_one(resolver, streams[sel - 1], ep_key, params))
        if played or not resolver.is_authorized():
            return


def _torrentio_message(e):
    if e.http_status:
        return f"El índice de fuentes no responde (HTTP {e.http_status}). Puede ser un bloqueo temporal"
    return "El índice de fuentes tarda demasiado o no hay conexión"


def _collect(resolver, imdb, params, dlg):
    """(fuentes ordenadas con su estado de caché, episodio, aviso si no queda ninguna).
    None si se canceló o falló (ya avisado)."""
    is_show = params.get("mode") == "show"
    kind = "series" if is_show else "movie"
    ep_key = debrid_filesel.episode_key(params["season"], params["episode"]) if is_show else None
    dlg.update(30, "Buscando fuentes...")
    try:
        client = torrentio.TorrentioClient(_torrentio_url())
        raw = client.get_streams(kind, imdb, params.get("season"), params.get("episode"))
    except torrentio.TorrentioError as e:
        _log(f"Torrentio: {e}", xbmc.LOGWARNING)
        dlg.close()
        xbmcgui.Dialog().ok("Debrid Test", _torrentio_message(e))
        return None
    if dlg.iscanceled():
        return None
    usable = torrentio.filter_streams(raw, kind, ep_key)
    only_spanish = _lang_mode() == 1
    streams = torrentio.filter_streams(raw, kind, ep_key, only_spanish=True) if only_spanish else usable
    dlg.update(60, "Comprobando caché...")
    try:
        cached = resolver.check_cached([s.info_hash for s in streams])
    except debrid_resolver.DebridAuthError:
        dlg.close()
        xbmcgui.Dialog().ok("Debrid Test", "La cuenta Debrid no está autorizada. Vuelve a vincularla.")
        return None
    for s in streams:
        s.cached = cached.get(s.info_hash)
    in_language = streams
    if _addon().getSetting("debrid_cached_only") == "true":
        streams = [s for s in streams if s.cached is not False]

    # Si un filtro lo deja todo fuera, se dice cuál: «Sin fuentes» sería falso.
    if not usable:
        note = "Sin fuentes para este título."
    elif not in_language:
        note = ("Hay fuentes, pero ninguna en español. Cambia «Idioma» a «Priorizar español» "
                "en la sección para verlas todas.")
    else:
        note = (f"Hay fuentes, pero ninguna está en la caché de {resolver.name} y tienes activado "
                "«Solo caché» (Abrir URL › Configuración › Resolver Debrid).")
    return torrentio.sort_streams(streams, _quality(), _lang_mode() != 2), ep_key, note


def _identify(params, dlg):
    dlg.update(5, "Identificando título...")
    return _imdb_of(params, "show" if params.get("mode") == "show" else "movie")


def _play(params):
    resolver = _resolver()
    if not resolver.is_authorized():
        if not xbmcgui.Dialog().yesno(
                "Debrid Test",
                "Para reproducir hace falta una cuenta Debrid (AllDebrid, Real-Debrid, TorBox o Premiumize).\n"
                "¿Vincularla ahora?"):
            return
        if not vincular_cuenta():
            return
        resolver = _resolver()

    dlg = xbmcgui.DialogProgress()
    dlg.create("Debrid Test", "Identificando título...")
    try:
        imdb = _identify(params, dlg)
        if not imdb:
            dlg.close()
            xbmcgui.Dialog().ok("Debrid Test", "No se encontró este título en IMDb.")
            return
        if dlg.iscanceled():
            return
        collected = _collect(resolver, imdb, params, dlg)
    finally:
        dlg.close()
    if collected is None:
        return
    streams, ep_key, note = collected
    if not streams:
        xbmcgui.Dialog().ok("Debrid Test", note)
        return
    _choose_and_play(resolver, streams, len(streams), params, ep_key)


def play(params):
    token = _acquire()
    if token is None:
        _notify("Ya hay una búsqueda en curso")
        return
    try:
        _play(params)
    finally:
        _release(token)


# --- entrada desde default_dispatch_extras ---

def _safe(fn, *args):
    # Un fallo aquí se registra y se avisa sin tumbar el addon.
    try:
        fn(*args)
    except Exception as e:  # noqa: BLE001  (frontera de la acción: registrar y avisar)
        _log(f"{fn.__name__}: {type(e).__name__}: {e}", xbmc.LOGERROR)
        _notify("Algo ha fallado. Inténtalo de nuevo", xbmcgui.NOTIFICATION_ERROR)


def _handle():
    try:
        return int(sys.argv[1])
    except (IndexError, ValueError):
        return -1


def dispatch(action, params):
    h = _handle()
    table = {
        "debrid_test_menu": (menu, h),
        "debrid_test_info": (explain_account,),
        "debrid_test_link": (link_account,),
        "debrid_test_account": (account,),
        "debrid_test_search": (search_prompt, h),
        "debrid_test_results": (results, h, params.get("q", "")),
        "debrid_test_seasons": (seasons, h, params),
        "debrid_test_episodes": (episodes, h, params),
        "debrid_test_manual": (manual_episode, params),
        "debrid_test_imdb": (imdb_prompt, h),
        "debrid_test_play": (play, params),
        "debrid_test_set_quality": (set_quality,),
        "debrid_test_set_lang": (set_lang,),
        "debrid_test_set_url": (set_torrentio_url,),
        "debrid_test_paste_help": (paste_help,),
    }
    call = table.get(action)
    if call is None:
        return False
    _safe(*call)
    return True
