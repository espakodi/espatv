# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Playlists de YouTube guardadas por el usuario y reproducción nativa."""

import json
import os
import re
import sys
import time
import urllib.parse

import xbmc
import xbmcaddon
import xbmcgui
import xbmcplugin
import xbmcvfs

import core_settings
import yt_innertube

try:
    from ui_utils import media_icon
except ImportError:
    def media_icon(name):
        return None

try:
    import yt_watched_tracker
except ImportError:
    yt_watched_tracker = None


def _u(**k):
    return sys.argv[0] + "?" + urllib.parse.urlencode(k)



def _open_browser(url, name=""):
    url = url.replace('"', "").replace("'", "") if url else ""
    try:
        if xbmc.getCondVisibility("System.Platform.Android"):
            xbmc.executebuiltin(f'StartAndroidActivity("","android.intent.action.VIEW","text/html","{url}")')
        else:
            import webbrowser
            webbrowser.open(url)
        xbmcgui.Dialog().notification("EspaTV", "Abriendo en el navegador...", xbmcgui.NOTIFICATION_INFO, 2000)
    except (ImportError, OSError):
        xbmcgui.Dialog().ok("Abrir en navegador", f"No se pudo abrir automáticamente.\n\nAbre esta URL:\n{url}")


def _open_yt_app(url, name=""):
    url = url.replace('"', "").replace("'", "") if url else ""
    try:
        xbmc.executebuiltin(f'StartAndroidActivity("com.google.android.youtube","android.intent.action.VIEW","","{url}")')
        xbmcgui.Dialog().notification("EspaTV", "Abriendo app YouTube...", xbmcgui.NOTIFICATION_INFO, 2000)
    except (RuntimeError, OSError):
        xbmcgui.Dialog().ok("App YouTube", "No se pudo abrir la app YouTube.\nAsegúrate de que está instalada.")


def _get_yt_playlists_file():
    p = xbmcvfs.translatePath(xbmcaddon.Addon().getAddonInfo("profile"))
    if not os.path.exists(p):
        os.makedirs(p)
    return os.path.join(p, "yt_playlists.json")


def _load_yt_playlists():
    path = _get_yt_playlists_file()
    if not os.path.exists(path):
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            return json.load(f)
    except (OSError, ValueError):
        return []


def _save_yt_playlists(data):
    path = _get_yt_playlists_file()
    core_settings.atomic_write_json(path, data)


def _extract_yt_playlist_id(url):
    m = re.search(r"[?&]list=([A-Za-z0-9_-]+)", url)
    if m:
        return m.group(1)
    return None


def _fetch_yt_playlist_title(list_id):
    try:
        _, _, title = yt_innertube.browse_playlist(list_id)
        if title:
            return title
    except (OSError, ValueError) as exc:
        xbmc.log(f"[EspaTV/yt_playlists] Error al obtener título de playlist {list_id}: {exc}", xbmc.LOGWARNING)
    return None


def add_from_url(url):
    if not url:
        return False
    list_id = _extract_yt_playlist_id(url)
    if not list_id:
        xbmcgui.Dialog().ok(
            "EspaTV",
            "No se pudo extraer el ID de la playlist.\n\n"
            "Asegúrate de pegar una URL válida de playlist de YouTube.\n"
            "Ejemplo: https://www.youtube.com/playlist?list=PLxxxxxx",
        )
        return False
    saved = _load_yt_playlists()
    for s in saved:
        if s.get("list_id") == list_id:
            xbmcgui.Dialog().notification("EspaTV", "Esta playlist ya está guardada", xbmcgui.NOTIFICATION_WARNING)
            return False
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Obteniendo información de la playlist...")
    title = _fetch_yt_playlist_title(list_id)
    dp.close()
    if not title:
        kb = xbmc.Keyboard("", "Nombre para esta playlist")
        kb.doModal()
        if not kb.isConfirmed() or not kb.getText().strip():
            title = f"Playlist {list_id[:12]}"
        else:
            title = kb.getText().strip()
    saved.append({
        "list_id": list_id,
        "name": title,
        "url": url.strip(),
        "ts": int(time.time()),
    })
    _save_yt_playlists(saved)
    xbmcgui.Dialog().notification("EspaTV", f"Playlist guardada: {title}", xbmcgui.NOTIFICATION_INFO)
    return True


def remove_playlist(list_id):
    saved = _load_yt_playlists()
    saved = [s for s in saved if s.get("list_id") != list_id]
    _save_yt_playlists(saved)


def menu():
    h = int(sys.argv[1])

    li = xbmcgui.ListItem(label="[COLOR limegreen][B]Añadir playlist (teclado)[/B][/COLOR]")
    icon_pl_key = media_icon("yt_pl_add_key.png") or "DefaultAddSource.png"
    li.setArt({"icon": icon_pl_key, "thumb": icon_pl_key, "poster": icon_pl_key, "banner": icon_pl_key})
    li.setInfo("video", {"plot": "Pega la URL de una playlist de YouTube usando el teclado de Kodi.\nEjemplo: https://www.youtube.com/playlist?list=PLxxxxxx"})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="yt_playlist_add"), listitem=li, isFolder=False)

    li = xbmcgui.ListItem(label="[COLOR lightskyblue][B]Añadir desde móvil/PC[/B][/COLOR]")
    icon_pl_remote = media_icon("yt_pl_add_remote.png") or "DefaultNetwork.png"
    li.setArt({"icon": icon_pl_remote, "thumb": icon_pl_remote, "poster": icon_pl_remote, "banner": icon_pl_remote})
    li.setInfo("video", {"plot": "Abre un servidor temporal en tu red local.\nDesde el navegador de tu móvil o PC, pega la URL de la playlist de YouTube.\nMás cómodo para URLs largas."})
    xbmcplugin.addDirectoryItem(handle=h, url=_u(action="yt_playlist_add_remote"), listitem=li, isFolder=False)

    saved = _load_yt_playlists()
    if not saved:
        li = xbmcgui.ListItem(label="[COLOR grey]No tienes playlists de YouTube guardadas[/COLOR]")
        li.setInfo("video", {
            "plot": (
                "Para guardar una playlist de YouTube:\n"
                "1. Copia la URL de la playlist en YouTube\n"
                "2. Usa 'Añadir playlist (teclado)' o 'Añadir desde móvil/PC'\n"
                "3. La playlist aparecerá aquí para acceder rápidamente\n\n"
                "Para eliminar una playlist guardada:\n"
                "Mantén pulsado sobre ella y elige 'Eliminar playlist'"
            )
        })
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
    else:
        for s in saved:
            list_id = s.get("list_id", "")
            name = s.get("name", "Sin nombre")
            li = xbmcgui.ListItem(label=name)
            pl_icon = media_icon("yt_hub_playlists.png") or "DefaultVideoPlaylists.png"
            li.setArt({"icon": pl_icon, "thumb": pl_icon, "poster": pl_icon})
            li.setInfo("video", {"plot": f"Playlist de YouTube\nID: {list_id}\n\nPulsa para abrir."})
            ctx = [
                ("Eliminar playlist", f"RunPlugin({_u(action='yt_playlist_remove', list_id=list_id)})"),
            ]
            li.addContextMenuItems(ctx)
            xbmcplugin.addDirectoryItem(handle=h, url=_u(action="yt_playlist_open", list_id=list_id, name=name), listitem=li, isFolder=True)

    xbmcplugin.endOfDirectory(h)


def add_action():
    kb = xbmc.Keyboard("", "Pega la URL de la playlist de YouTube")
    kb.doModal()
    if not kb.isConfirmed():
        return
    url = kb.getText().strip()
    if not url:
        return
    if add_from_url(url):
        xbmc.executebuiltin("Container.Refresh")


def add_remote():
    import url_remote
    url = url_remote.receive_text("Pegar playlist de YouTube")
    if not url:
        return
    if add_from_url(url):
        xbmc.executebuiltin("Container.Refresh")


def fetch_videos(list_id, include_extra=False):
    items, _, _ = yt_innertube.browse_playlist(list_id)
    videos = []
    for it in items:
        if it.get("type") == "video":
            v = {
                "vid": it.get("vid", ""),
                "title": it.get("title", ""),
            }
            if include_extra:
                v["channel"] = it.get("channel", "")
                v["views"] = it.get("views", "")
                v["duration"] = it.get("duration", "")
                v["date"] = it.get("published", "")
                v["description"] = ""
            videos.append(v)
    return videos


def show_list(list_id, name="", continuation=""):
    h = int(sys.argv[1]) if len(sys.argv) > 1 else -1
    if not list_id:
        if h >= 0:
            xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    dp = xbmcgui.DialogProgress()
    dp.create("EspaTV", "Cargando vídeos de la playlist...")
    try:
        items, next_cont, pl_title = yt_innertube.browse_playlist(list_id, continuation=continuation)
        dp.close()
    except (OSError, ValueError) as exc:
        dp.close()
        xbmc.log(f"[EspaTV/yt_playlists] Error al cargar lista: {exc}", xbmc.LOGERROR)
        items, next_cont = [], ""

    if not items:
        li = xbmcgui.ListItem(label="[COLOR grey]No se pudieron obtener los vídeos[/COLOR]")
        li.setInfo("video", {"plot": "No se pudo cargar la playlist.\nPrueba a abrirla en el navegador."})
        xbmcplugin.addDirectoryItem(handle=h, url="", listitem=li, isFolder=False)
        xbmcplugin.endOfDirectory(h)
        return

    watched_ids = set()
    if yt_watched_tracker:
        try:
            watched_ids = yt_watched_tracker.load()
        except (OSError, ValueError):
            watched_ids = set()

    for i, it in enumerate(items):
        if it.get("type") != "video":
            continue
        vid = it.get("vid", "")
        title = it.get("title", "Vídeo")
        channel = it.get("channel", "")
        channel_id = it.get("channel_id", "")
        dur = it.get("duration", "")
        thumb = f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg"
        is_watched = vid in watched_ids
        lbl = f"{i + 1}. [COLOR limegreen][Visto][/COLOR] {title}" if is_watched else f"{i + 1}. {title}"

        li = xbmcgui.ListItem(label=lbl)
        li.setArt({"icon": thumb, "thumb": thumb, "poster": thumb, "fanart": thumb})
        li.setProperty("IsPlayable", "true")

        plot = f"Canal: {channel}\nDuración: {dur}" if channel else title
        info_dict = {"title": title, "plot": plot, "studio": channel}
        if is_watched:
            info_dict["playcount"] = 1
        li.setInfo("video", info_dict)

        fav_params = json.dumps({"yt_id": vid, "name": title, "ctype": "video", "burl": ""})
        ctx = [
            ("Añadir a Ver más tarde", f"RunPlugin({_u(action='yt_watch_later_add', video_id=vid, title=title, channel=channel, channel_id=channel_id, duration=dur)})"),
            ("Añadir a Mis Favoritos (EspaTV)", f"RunPlugin({_u(action='add_favorite', title=title, fav_url=f'yt_{vid}', icon=thumb, platform='youtube', fav_action='felicidad_play', params=fav_params)})"),
            ("Solo audio", f"RunPlugin({_u(action='yt_play_audio', video_id=vid, title=title)})"),
            ("Vídeos relacionados (Radio)", f"Container.Update({_u(action='yt_related', video_id=vid, title=title)})"),
        ]
        if channel_id:
            ctx.append(("Ir al canal", f"Container.Update({_u(action='yt_channel_view', channel_id=channel_id, channel_name=channel)})"))
        ctx.append(("Añadir a cola de reproducción", f"RunPlugin({_u(action='yt_queue_add', video_id=vid, title=title)})"))
        toggle_lbl = "Desmarcar como visto" if is_watched else "Marcar como visto"
        ctx.append((toggle_lbl, f"RunPlugin({_u(action='yt_toggle_watched', yt_id=vid)})"))
        ctx.append(("Opciones de reproducción (App / Navegador / yt-dlp)", f"Container.Update({_u(action='felicidad_play', yt_id=vid, name=title, ctype='video')})"))
        li.addContextMenuItems(ctx)

        play_url = _u(action="yt_play_video", video_id=vid, title=title)
        xbmcplugin.addDirectoryItem(handle=h, url=play_url, listitem=li, isFolder=False)

    if next_cont:
        li_next = xbmcgui.ListItem(label="[COLOR yellow][B]Página siguiente >>[/B][/COLOR]")
        li_next.setArt({"icon": "DefaultFolderBack.png"})
        li_next.setInfo("video", {"plot": "Carga los siguientes vídeos de esta playlist."})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="yt_playlist_list", list_id=list_id, name=name, continuation=next_cont),
            listitem=li_next,
            isFolder=True,
        )

    xbmcplugin.endOfDirectory(h)


def open_playlist(list_id, name=""):
    h = int(sys.argv[1]) if len(sys.argv) > 1 else -1
    if not list_id:
        if h >= 0:
            xbmcplugin.endOfDirectory(h, succeeded=False)
        return
    is_android = xbmc.getCondVisibility("System.Platform.Android")

    li = xbmcgui.ListItem(label="[COLOR FF38BDF8][B]Modo Cine[/B][/COLOR]")
    icon_pl_cin = media_icon("yt_cinema_mode.png") or "DefaultMovies.png"
    li.setArt({"icon": icon_pl_cin, "thumb": icon_pl_cin})
    li.setInfo("video", {"plot": "Navega los vídeos con miniaturas grandes, metadata completa y fondo dinámico."})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="yt_cinema_mode", list_id=list_id, name=name),
        listitem=li,
        isFolder=False,
    )

    li = xbmcgui.ListItem(label="[COLOR limegreen][B]Ver playlist[/B][/COLOR]")
    icon_pl_ver = media_icon("yt_tab_playlists.png") or "DefaultVideoPlaylists.png"
    li.setArt({"icon": icon_pl_ver, "thumb": icon_pl_ver})
    li.setInfo("video", {"plot": "Muestra todos los vídeos de la playlist.\nElige cuál reproducir."})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="yt_playlist_list", list_id=list_id, name=name),
        listitem=li,
        isFolder=True,
    )

    li = xbmcgui.ListItem(label="[COLOR limegreen]Reproducir todo[/COLOR]")
    icon_pl_all = media_icon("yt_wl_play_all.png") or "DefaultVideo.png"
    li.setArt({"icon": icon_pl_all, "thumb": icon_pl_all})
    li.setInfo("video", {"plot": "Reproduce todos los vídeos de la playlist en cola nativa de Kodi."})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="yt_playlist_open_exec", list_id=list_id, name=name, method="addon"),
        listitem=li,
        isFolder=False,
    )

    if is_android:
        li = xbmcgui.ListItem(label="[COLOR lightskyblue]Abrir en la app YouTube[/COLOR]")
        li.setArt({"icon": "DefaultAddonProgram.png"})
        li.setInfo("video", {"plot": "Abre la playlist en la aplicación YouTube de Android."})
        xbmcplugin.addDirectoryItem(
            handle=h,
            url=_u(action="yt_playlist_open_exec", list_id=list_id, name=name, method="yt_app"),
            listitem=li,
            isFolder=False,
        )

    li = xbmcgui.ListItem(label="[COLOR orange]Abrir en el navegador[/COLOR]")
    li.setArt({"icon": "DefaultNetwork.png"})
    li.setInfo("video", {"plot": "Abre la playlist en el navegador web."})
    xbmcplugin.addDirectoryItem(
        handle=h,
        url=_u(action="yt_playlist_open_exec", list_id=list_id, name=name, method="browser"),
        listitem=li,
        isFolder=False,
    )

    xbmcplugin.endOfDirectory(h)


def open_exec(list_id, name="", method="addon"):
    if not list_id:
        return
    web_url = f"https://www.youtube.com/playlist?list={list_id}"
    if method == "addon":
        xbmcgui.Dialog().notification("EspaTV", "Cargando playlist...", xbmcgui.NOTIFICATION_INFO, 2000)
        videos = fetch_videos(list_id)
        if not videos:
            xbmcgui.Dialog().ok("EspaTV", "No se pudieron obtener los vídeos de la playlist.\n\nPrueba a abrirla en el navegador.")
            return
        playlist = xbmc.PlayList(xbmc.PLAYLIST_VIDEO)
        playlist.clear()
        for v in videos:
            vid = v.get("vid", "")
            title = v.get("title", "")
            thumb = f"https://i.ytimg.com/vi/{vid}/hqdefault.jpg"
            play_url = _u(action="yt_play_video", video_id=vid, title=title)
            li = xbmcgui.ListItem(label=title)
            li.setArt({"icon": thumb, "thumb": thumb, "poster": thumb, "fanart": thumb})
            li.setProperty("IsPlayable", "true")
            playlist.add(play_url, li)
        xbmc.Player().play(playlist)
        xbmcgui.Dialog().notification("EspaTV", f"{len(videos)} vídeos en cola", xbmcgui.NOTIFICATION_INFO, 2000)
    elif method == "yt_app":
        _open_yt_app(web_url, name)
    elif method == "browser":
        _open_browser(web_url, name)
