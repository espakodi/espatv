# -*- coding: utf-8 -*-
# EspaTV - Copyright (C) 2024-2026 RubénSDFA1laberot (github.com/espakodi)
# Licencia: Consulta el archivo LICENSE.
"""Elige el fichero de vídeo correcto dentro de un torrent (sin Kodi, testeable)."""
import re
import unicodedata

# Los índices usan muchas grafías: S01E01, S01.E01, S01E.01, S01 - E01, S01EP01, 1x01, 2s-1 y Cap.101.
_EP_RES = (
    re.compile(r"(?<![a-z0-9])s(\d{1,2})[ ._-]{0,3}ep?[ ._-]?(\d{1,3})(?:[ ._-]?ep?(\d{1,3}))?(?!\d)", re.I),
    re.compile(r"(?<![a-z0-9])(\d{1,2})x(\d{2,3})(?!\d)", re.I),
    re.compile(r"(?<![a-z0-9])(\d{1,2})s[ ._-]?(\d{1,3})(?!\d)", re.I),
    re.compile(r"(?<![a-z0-9])cap(?:itulo)?[ ._]?(\d{1,2})(\d{2})(?!\d)", re.I),
)
_SAMPLE_RE = re.compile(r"(?<![a-z0-9])(sample|trailer|muestra)(?![a-z0-9])", re.I)
# Una muestra pesa mucho menos que la película; por debajo de esta fracción del mayor se descarta.
_SAMPLE_FRACTION = 0.1


def episode_key(season, episode):
    return f"S{int(season):02d}E{int(episode):02d}"


def episode_keys(name):
    """Episodios que nombra un fichero; 'S01E01E02' nombra dos."""
    keys = set()
    for rx in _EP_RES:
        for m in rx.finditer(name or ""):
            for ep in m.groups()[1:]:
                if ep:
                    keys.add(episode_key(m.group(1), ep))
    return keys


def basename(path):
    return str(path or "").replace("\\", "/").rsplit("/", 1)[-1]


def _strip_ext(name):
    base, dot, _ = name.rpartition(".")
    return base if dot and base else name


def _normalize(text):
    # Tolera diferencias de puntos, espacios, guiones y acentos entre el índice y el proveedor.
    plain = unicodedata.normalize("NFKD", text or "")
    plain = "".join(c for c in plain if not unicodedata.combining(c))
    return re.sub(r"\W+", "", plain.casefold())


def _size(video):
    return video.get("size") or 0


def _match_hint(videos, file_hint):
    wanted = basename(file_hint).casefold()
    wanted_base = _strip_ext(wanted)
    wanted_norm = _normalize(wanted_base)
    for video in videos:
        got = basename(video.get("name")).casefold()
        if got == wanted or (wanted_base and _strip_ext(got) == wanted_base):
            return video
        if wanted_norm and _normalize(_strip_ext(got)) == wanted_norm:
            return video
    return None


def _drop_samples(videos):
    biggest = max(_size(v) for v in videos)
    real = [
        v for v in videos
        if not _SAMPLE_RE.search(basename(v.get("name")))
        and (not biggest or _size(v) >= biggest * _SAMPLE_FRACTION)
    ]
    return real or videos


def pick_video(videos, file_hint=None, episode_key=None, select_fn=None):
    """Elige el vídeo de ``videos`` ([{name, size, ...}]) o None si no hay uno fiable.

    Con ``episode_key`` ('S01E03') nunca devuelve otro episodio: sin coincidencia
    es None. ``select_fn(candidatos)`` decide entre varias películas; sin él, la mayor.
    """
    videos = list(videos or [])
    if not videos:
        return None

    if file_hint:
        hint_eps = episode_keys(file_hint)
        if not (episode_key and hint_eps and episode_key not in hint_eps):
            found = _match_hint(videos, file_hint)
            if found:
                return found

    if episode_key:
        matches = [v for v in videos if episode_key in episode_keys(basename(v.get("name")))]
        return max(matches, key=_size) if matches else None

    videos = _drop_samples(videos)
    if len(videos) > 1 and select_fn is not None:
        return select_fn(videos)
    return max(videos, key=_size)
